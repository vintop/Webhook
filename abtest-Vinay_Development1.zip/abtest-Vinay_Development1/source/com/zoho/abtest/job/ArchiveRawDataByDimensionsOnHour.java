//$Id$
package com.zoho.abtest.job;

import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.sas.ds.SASThreadLocal;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.report.ArchieveTableMeta;
import com.zoho.abtest.report.RawDataTableDetails;
import com.zoho.abtest.report.ReportArchieveDimension;
import com.zoho.abtest.report.ReportArchieveDimensionConstants;
import com.zoho.abtest.report.ReportRawDataConstants;
import com.zoho.abtest.report.ReportArchieveDimensionConstants.ReportModuleType;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.scheduler.RunnableJob;

public class ArchiveRawDataByDimensionsOnHour implements RunnableJob{
	
	private static final Logger LOGGER = Logger.getLogger(ArchiveRawDataByDimensionsOnHour.class.getName());
	
	public void run(long l)
	{
		/*
		//int hourOfDay = ZABUtil.getHourOfDay(jobScheduleStartTime) ;
		try
		{
			Long jobScheduleStartTime = ZABUtil.getCurrentTimeInMilliSeconds();
			String dbspaceId = SASThreadLocal.getLoginName();
			LOGGER.log(Level.INFO, "ArchiveVisitorRawDataOnHour - Schedule Job starts running. DBSPACE:"+dbspaceId+" Timeinmillis:"+jobScheduleStartTime);
			ZABUtil.setIsSchedulerJob(Boolean.TRUE);
			List<ArchieveTableMeta> archieveTableMetaDetails = ArchieveTableMeta.getHourlyArchieveTableMetaDetails();
			String visitorRawDataTable;
			String goalAchievedRawDataTable;
			
			
			for(ArchieveTableMeta archieveTableMeta:archieveTableMetaDetails)
			{
				Long lastArchievedTime = archieveTableMeta.getLastArchievedTime();

				Long startHourInMs = null;
				Long endHourInMs = null; 
				
				if(lastArchievedTime == null || lastArchievedTime.equals(0l))
				{
					startHourInMs = ZABUtil.getPrevHourTimeInMilliSeconds(jobScheduleStartTime) + 1;
					endHourInMs = ZABUtil.getHourTimeInMilliSeconds(jobScheduleStartTime);
				}
				else
				{
					startHourInMs = ZABUtil.getHourTimeInMilliSeconds(lastArchievedTime)+1;
					endHourInMs = ZABUtil.getNthHourInLong(startHourInMs, 1);
				}
				
				String rawTableDate = ZABUtil.getNthDayDate(startHourInMs, 0);
				
				visitorRawDataTable = ReportRawDataConstants.VISITOR_DATA_RAW + ZABConstants.UNDERSCORE + rawTableDate + ZABConstants.UNDERSCORE + dbspaceId;
				goalAchievedRawDataTable = ReportRawDataConstants.GOAL_DATA_RAW + ZABConstants.UNDERSCORE + rawTableDate + ZABConstants.UNDERSCORE + dbspaceId; 
			
				
				String columnName = archieveTableMeta.getColumnName();
				String groupByColumns = archieveTableMeta.getGroupByColumns();
				String[] groupByColumnnArr = groupByColumns.split(",");
				String resultArchieveTable = archieveTableMeta.getResultArchieveTable();
				String visitorIdsTable = archieveTableMeta.getVisitorIdsTable()+ZABConstants.UNDERSCORE + dbspaceId;
				int durationType = archieveTableMeta.getDurationType();
				int moduleType = archieveTableMeta.getModuleType();
				boolean isStandardDimension = archieveTableMeta.getIsStandardDimension();
				
				//Update last archived time in the meta table
				HashMap<String, String> updateMetaHs = new HashMap<String, String>();
				updateMetaHs.put(ReportArchieveDimensionConstants.ARCHIEVE_TABLE_ID, archieveTableMeta.getArchieveTableId().toString());
				updateMetaHs.put(ReportArchieveDimensionConstants.LAST_ARCHIEVED_TIME, endHourInMs.toString());
				ArchieveTableMeta.updateArchieveTableMeta(updateMetaHs);
				
				if(moduleType == ReportModuleType.VISIT.getModuleCode())
				{
					if(isStandardDimension)
					{
						ReportArchieveDimension.archieveIndividualReportOnStandardDimension(visitorRawDataTable, columnName, groupByColumnnArr, resultArchieveTable, visitorIdsTable, durationType, startHourInMs, endHourInMs);
					}
					else
					{
						ReportArchieveDimension.archieveIndividualReportOnDynamicAttributes(visitorRawDataTable, columnName, groupByColumnnArr, resultArchieveTable, visitorIdsTable, durationType, startHourInMs, endHourInMs);
					}
				}
				else if(moduleType == ReportModuleType.GOALACHIEVED.getModuleCode())
				{
					if(isStandardDimension)
					{
						ReportArchieveDimension.archieveIndividualReportOnStandardDimension(goalAchievedRawDataTable, columnName, groupByColumnnArr, resultArchieveTable, visitorIdsTable, durationType, startHourInMs, endHourInMs);
					}
					else
					{
						ReportArchieveDimension.archieveIndividualReportOnDynamicAttributes(goalAchievedRawDataTable, columnName, groupByColumnnArr, resultArchieveTable, visitorIdsTable, durationType, startHourInMs, endHourInMs);
					}
				}
				
			}
			
			LOGGER.log(Level.INFO, "ArchiveVisitorRawDataOnHour - Schedule Job successfully finished. DBSPACE:"+dbspaceId+" Timeinmillis:"+ZABUtil.getCurrentTimeInMilliSeconds());
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in ArchiveVisitorRawDataOnHour", ex);
		}
		*/
	}
}
