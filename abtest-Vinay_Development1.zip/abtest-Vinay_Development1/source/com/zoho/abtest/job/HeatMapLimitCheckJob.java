//$Id$
package com.zoho.abtest.job;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.zoho.abtest.heatmaps.HeatMapVisitorLimitVerification;
import com.zoho.abtest.sessionrecording.SessionRecordingVisitorLimitVerification;
import com.zoho.scheduler.RunnableJob;

public class HeatMapLimitCheckJob implements RunnableJob
{
	private static final Logger LOGGER = Logger.getLogger(HeatMapLimitCheckJob.class.getName());
	
	@Override
	public void run(long l) 
	{
		LOGGER.log(Level.INFO, "HeatMapLimitCheckJob - Schedule Job starts running");
		try
		{
			HeatMapVisitorLimitVerification.verifyHeatMapVisitorLimitForABSplit();
			SessionRecordingVisitorLimitVerification.verifyVisitorLimitForSessionRecording();
			LOGGER.log(Level.INFO, "HeatMapLimitCheckJob - Schedule Job completed successfully");
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "HeatMapLimitCheckJob - Schedule Job exception occurred",ex);
		}
	}

}
