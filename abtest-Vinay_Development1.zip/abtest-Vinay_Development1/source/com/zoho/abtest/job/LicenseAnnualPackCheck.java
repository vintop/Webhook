//$Id$
package com.zoho.abtest.job;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.zoho.abtest.license.LicenseVerification;
import com.zoho.scheduler.RunnableJob;

public class LicenseAnnualPackCheck implements RunnableJob
{
	private static final Logger LOGGER = Logger.getLogger(LicenseAnnualPackCheck.class.getName());
	
	@Override
	public void run(long l) 
	{
		LOGGER.log(Level.INFO, "LicenseAnnualPackCheck - Schedule Job starts running");
		try
		{
			//LicenseVerification.reActivateAnnualUserMonthlyPack();
			LOGGER.log(Level.INFO, "LicenseAnnualPackCheck - Schedule Job completed successfully");
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "LicenseAnnualPackCheck - Schedule Job exception occurred",ex);
		}
	}
}
