//$Id$
package com.zoho.abtest.job;

import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.sas.ds.SASThreadLocal;
import com.zoho.abtest.GOAL_DIMENSION_HOUR;
import com.zoho.abtest.VISITOR_DIMENSION_HOUR;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.report.RawDataTableDetails;
import com.zoho.abtest.report.ReportRawDataConstants;
import com.zoho.abtest.report.CumulativeReportConstants.CumulativeTableMetaValues;
import com.zoho.abtest.report.ReportArchieveDimensionConstants.ReportModuleType;
import com.zoho.abtest.revenue.RevenueConstants;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.scheduler.RunnableJob;

public class CumulativeHourTablePopulation implements RunnableJob{

	private static final Logger LOGGER = Logger.getLogger(CumulativeHourTablePopulation.class.getName());

	public void run(long l)
	{
		/*
		try{
			LOGGER.log(Level.INFO,"CumulativeHourTablePopulation SCHEDULE START" );
			ZABUtil.setIsSchedulerJob(Boolean.TRUE);
			String dbspaceId = SASThreadLocal.getLoginName();
			// HOURLY ONCE SCHEDULE TO UPDATE VISITOR_REPORT_DAY AND GOAL_REPORT_DAY_TABLE
			Long scheduleTime = ZABUtil.getCurrentTimeInMilliSeconds();
			String visitorRawDataTable ;
			String goalAchievedRawDataTable;
			String revenueRawTable =null; 
			String timeSpentRawTable = null;
			int hourOfDay = ZABUtil.getHourOfDay(scheduleTime);
			if(hourOfDay == 0)
			{
				String previousDaydate = ZABUtil.getNthDayDate(scheduleTime, -1);
				visitorRawDataTable = ReportRawDataConstants.VISITOR_DATA_RAW + ZABConstants.UNDERSCORE + previousDaydate + ZABConstants.UNDERSCORE + dbspaceId;
				goalAchievedRawDataTable = ReportRawDataConstants.GOAL_DATA_RAW + ZABConstants.UNDERSCORE + previousDaydate + ZABConstants.UNDERSCORE + dbspaceId; 
				revenueRawTable = RevenueConstants.REVENUE_RAW + ZABConstants.UNDERSCORE + previousDaydate + ZABConstants.UNDERSCORE + dbspaceId; 
				timeSpentRawTable =  ReportRawDataConstants.TIME_SPENT_DATA_RAW + ZABConstants.UNDERSCORE + previousDaydate + ZABConstants.UNDERSCORE + dbspaceId;
			}else{
				HashMap<Integer, String> hs = RawDataTableDetails.getAllActiveRawTables();
				visitorRawDataTable = hs.get(ReportModuleType.VISIT.getModuleCode());
				goalAchievedRawDataTable = hs.get(ReportModuleType.GOALACHIEVED.getModuleCode());
				if(visitorRawDataTable!=null){
					revenueRawTable = visitorRawDataTable.replace(ReportRawDataConstants.VISITOR_DATA_RAW, RevenueConstants.REVENUE_RAW );
					timeSpentRawTable = visitorRawDataTable.replace(ReportRawDataConstants.VISITOR_DATA_RAW, ReportRawDataConstants.TIME_SPENT_DATA_RAW );
					//heatmapRawTable = visitorRawDataTable.replace(ReportRawDataConstants.VISITOR_DATA_RAW,ReportRawDataConstants.HEATMAP_DATA_RAW);
				}else{
					return;
				}

			}

			//FUNNEL 
			//		lastArchivedTime = cumulativeTableMetaDetails.get(FUNNEL_DATA_RAW_HOUR.TABLE);
			//		startendtimeHs = getArchiveTimeDetails(lastArchivedTime, scheduleTime);
			//		startHourInMs = startendtimeHs.get(ReportArchieveDimensionConstants.START_HOUR_IN_MILLIS);
			//		endHourInMs = startendtimeHs.get(ReportArchieveDimensionConstants.END_HOUR_IN_MILLIS);
			//		
			//		FunnelReportDataInHandler.archiveFunnelData(startHourInMs, endHourInMs, dbspaceId);


			CumulativeDayTablePopulation.cumulativeReportPopulation(visitorRawDataTable,CumulativeTableMetaValues.VISITOR_REPORT_HOUR,scheduleTime,dbspaceId);
			CumulativeDayTablePopulation.cumulativeReportPopulation(goalAchievedRawDataTable,CumulativeTableMetaValues.GOAL_REPORT_HOUR,scheduleTime,dbspaceId);


			
			CumulativeDayTablePopulation.populateCondildatedDimensionTable(visitorRawDataTable, null , timeSpentRawTable, VISITOR_DIMENSION_HOUR.TABLE,scheduleTime,dbspaceId);
			CumulativeDayTablePopulation.populateCondildatedDimensionTable(goalAchievedRawDataTable,revenueRawTable , null , GOAL_DIMENSION_HOUR.TABLE,scheduleTime,dbspaceId);


			CumulativeDayTablePopulation.revenueCumulativeReport(goalAchievedRawDataTable,revenueRawTable , CumulativeTableMetaValues.REVENUE_REPORT_HOUR,scheduleTime,dbspaceId);
			CumulativeDayTablePopulation.timeSpentCumulativeReport(visitorRawDataTable, timeSpentRawTable, CumulativeTableMetaValues.TIME_SPENT_REPORT_HOUR,scheduleTime,dbspaceId);
			
			
			LOGGER.log(Level.INFO,"CumulativeHourTablePopulation SCHEDULE END" );

		}catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
	*/
	}
}