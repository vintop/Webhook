//$Id$
package com.zoho.abtest.job;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Array;

import org.postgresql.util.PGobject;

import com.adventnet.db.api.RelationalAPI;
import com.adventnet.persistence.DataObject;
import com.adventnet.sas.ds.SASThreadLocal;
import com.zoho.abtest.GOAL_DIMENSION_DAY;
import com.zoho.abtest.GOAL_DIMENSION_HOUR;
import com.zoho.abtest.GOAL_REPORT_DAY;
import com.zoho.abtest.GOAL_REPORT_HOUR;
import com.zoho.abtest.REVENUE_REPORT_DAY;
import com.zoho.abtest.REVENUE_REPORT_HOUR;
import com.zoho.abtest.TIME_SPENT_REPORT_HOUR;
import com.zoho.abtest.VISITOR_DIMENSION_DAY;
import com.zoho.abtest.VISITOR_DIMENSION_HOUR;
import com.zoho.abtest.VISITOR_REPORT_DAY;
import com.zoho.abtest.VISITOR_REPORT_HOUR;
import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.goal.GoalConstants;
import com.zoho.abtest.report.CumulativeReportConstants.CumulativeTableMetaValues;
import com.zoho.abtest.report.ReportArchieveDimension;
import com.zoho.abtest.report.ReportArchieveDimensionConstants.ReportDurationType;
import com.zoho.abtest.report.CumulativeReportConstants;
import com.zoho.abtest.report.ReportArchieveDimensionConstants;
import com.zoho.abtest.report.ReportConstants;
import com.zoho.abtest.report.ReportRawDataConstants;
import com.zoho.abtest.revenue.RevenueConstants;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.scheduler.RunnableJob;

public class CumulativeDayTablePopulation implements RunnableJob{

	private static final Logger LOGGER = Logger.getLogger(RawdataTableGeneration.class.getName());

	public void run(long l)
	{
		/*
		try
		{
			ZABUtil.setIsSchedulerJob(Boolean.TRUE);
			String dbspaceId = SASThreadLocal.getLoginName();
			// DAILY ONCE SCHEDULE TO UPDATE VISITOR_REPORT_DAY AND GOAL_REPORT_DAY_TABLE

			Long scheduleTime = ZABUtil.getCurrentTimeInMilliSeconds();

			String previousDaydate = ZABUtil.getNthDayDate(scheduleTime, -1);
			String visitorRawDataTable = ReportRawDataConstants.VISITOR_DATA_RAW + ZABConstants.UNDERSCORE + previousDaydate;
			String goalAchievedRawDataTable = ReportRawDataConstants.GOAL_DATA_RAW + ZABConstants.UNDERSCORE + previousDaydate; 
			String revenueRawTable =  RevenueConstants.REVENUE_RAW + ZABConstants.UNDERSCORE +previousDaydate;

			cumulativeReportPopulation(visitorRawDataTable,CumulativeTableMetaValues.VISITOR_REPORT_DAY,scheduleTime,dbspaceId);
			cumulativeReportPopulation(goalAchievedRawDataTable,CumulativeTableMetaValues.GOAL_REPORT_DAY,scheduleTime,dbspaceId);

			populateCondildatedDimensionTable(visitorRawDataTable, null ,null, VISITOR_DIMENSION_DAY.TABLE,scheduleTime,dbspaceId);
			populateCondildatedDimensionTable(goalAchievedRawDataTable,revenueRawTable , null,GOAL_DIMENSION_DAY.TABLE,scheduleTime,dbspaceId);

			//REVENUE CUMULATIVE TABLE 
			revenueCumulativeReport(visitorRawDataTable,revenueRawTable , CumulativeTableMetaValues.REVENUE_REPORT_DAY,scheduleTime, dbspaceId);

		}
		catch(Exception e)
		{
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		*/
	}

	public static void cumulativeReportPopulation(String rawTable, final CumulativeTableMetaValues metaDetails,Long scheduleTime, String dbspaceId)
	{

		try
		{
			String groupByClause = " group by "+metaDetails.getGroupByColumns()+";";	// NO I18N
			String whereString  = " ";
			String query ="select "+metaDetails.getGroupByColumns() +",ARRAY_AGG("+ReportArchieveDimensionConstants.VISITOR_ID+") AS VISITOR_IDS, sum("+ReportArchieveDimensionConstants.TOTALCOUNT_FLAG+") AS "+ReportArchieveDimensionConstants.TOTAL_COUNT+" from "+rawTable ;//NO I18N

			if(metaDetails.getDurationType() ==  ReportDurationType.HOUR.getDurationCode()) {

				Long startHourInMs = ZABUtil.getPrevHourTimeInMilliSeconds(scheduleTime);
				Long endHourInMs = ZABUtil.getHourTimeInMilliSeconds(scheduleTime);
				whereString =  " where "+ReportArchieveDimensionConstants.TIME +" between "+startHourInMs +" and "+endHourInMs+" ";	//NO I18N
				cumulativeReportPopulationFromQuery(query+whereString+groupByClause,metaDetails,endHourInMs,dbspaceId);

			}
			else if(metaDetails.getDurationType() ==  ReportDurationType.DAY.getDurationCode()){

				// GET DATE VALUE FROM RAW TABLE NAME 
				int index = rawTable.indexOf("RAW_");			// NO I18N
				String dateString  =  rawTable.substring(index+4);
				SimpleDateFormat sd= new SimpleDateFormat("yyyy_MM_dd");		// NO I18N
				Date date = sd.parse(dateString);
				Long dateInMillis = date.getTime();
				cumulativeReportPopulationFromQuery(query+groupByClause,metaDetails,dateInMillis,dbspaceId);
			}

		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occured: ",ex);
		}

	}

	public static void cumulativeReportPopulationFromQuery(String query ,final CumulativeTableMetaValues metaDetails,Long time,String dbSpaceId) throws Exception{


		String idColumnName = null;
		String visitorIdsTable  = null;
		String mappingColumnName = null;
		Connection connection = null;
		ResultSet res = null;
		PreparedStatement stmt= null;

		Boolean isRevenue = false;
		Boolean isTimeSpent = false;
		List<Constants> resultTableConstants = null; 

		switch (metaDetails.getResultTable()){
		case REVENUE_REPORT_DAY.TABLE:
			resultTableConstants=RevenueConstants.REVEMUE_REPORT_DAY_CONSTANTS;
			isRevenue= true;
		
		
			break;
		case REVENUE_REPORT_HOUR.TABLE:

			resultTableConstants=RevenueConstants.REVEMUE_REPORT_HOUR_CONSTANTS;
			isRevenue= true;
			
		case TIME_SPENT_REPORT_HOUR.TABLE:

			resultTableConstants=CumulativeReportConstants.TIME_SPENT_HOUR_CONSTANTS;
			isRevenue= false;
			isTimeSpent= true;
		

			break;
		case VISITOR_REPORT_HOUR.TABLE:
			resultTableConstants=CumulativeReportConstants.VISITOR_REPORT_HOUR_CONSTANTS;
			idColumnName = "HOUR_ID";		// NO I18N
			visitorIdsTable = VISITOR_REPORT_HOUR.TABLE+"_VISITORS_"+dbSpaceId;		// NO I18N
			mappingColumnName = VISITOR_REPORT_HOUR.TABLE+"_ID";		// NO I18N
			break;
		case VISITOR_REPORT_DAY.TABLE:
			resultTableConstants=CumulativeReportConstants.VISITOR_REPORT_DAY_CONSTANTS;
			idColumnName = "DAY_ID";		// NO I18N
			visitorIdsTable = VISITOR_REPORT_DAY.TABLE+"_VISITORS_"+dbSpaceId;		// NO I18N
			mappingColumnName = VISITOR_REPORT_DAY.TABLE+"_ID";		// NO I18N
			break;
		case GOAL_REPORT_HOUR.TABLE:
			resultTableConstants=CumulativeReportConstants.GOAL_REPORT_HOUR_CONSTANTS;
			idColumnName = "HOUR_ID";		// NO I18N
			visitorIdsTable = GOAL_REPORT_HOUR.TABLE+"_VISITORS_"+dbSpaceId;		// NO I18N
			mappingColumnName = GOAL_REPORT_HOUR.TABLE+"_ID";		// NO I18N
			break;
		case GOAL_REPORT_DAY.TABLE:
			resultTableConstants=CumulativeReportConstants.GOAL_REPORT_DAY_CONSTANTS;
			idColumnName = "DAY_ID";		// NO I18N
			visitorIdsTable = GOAL_REPORT_DAY.TABLE+"_VISITORS_"+dbSpaceId;		// NO I18N
			mappingColumnName = GOAL_REPORT_DAY.TABLE+"_ID";		// NO I18N
			break;
		}
		ArrayList<HashMap<String, String>> tempCachingHs = new ArrayList<HashMap<String, String>>();
		ArrayList<Array> visitorsArray = new ArrayList<Array>();
		try
		{
			RelationalAPI relationalApi = RelationalAPI.getInstance();
			connection = relationalApi.getConnection();
			stmt = connection.prepareStatement(query);
			res = stmt.executeQuery();


			ResultSetMetaData meta = res.getMetaData();
			int colCount = meta.getColumnCount();
			while(res.next()) {
				HashMap<String , String> hs = new HashMap<String,String>();
				for (int col=1; col <= colCount; col++) 
				{
					Object value = res.getObject(col);
					if (value != null) 
					{
						hs.put(meta.getColumnName(col), value.toString());
					}
				}
				if(metaDetails.getDurationType() ==  ReportDurationType.HOUR.getDurationCode()) {
					hs.put(CumulativeReportConstants.HOUR, time.toString());
				}else if(metaDetails.getDurationType() ==  ReportDurationType.DAY.getDurationCode()) {
					// ADD DATE
					hs.put(CumulativeReportConstants.DATE, time.toString());
				}

				if(!(isRevenue || isTimeSpent)){
					visitorsArray.add(res.getArray("VISITOR_IDS"));	// NO I18N
					
				}
				tempCachingHs.add(hs);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occured: ",ex);
		}
		finally
		{
			try {
				if(res!=null) {
					res.close();
				}
			} catch (Exception e) {
				LOGGER.log(Level.SEVERE, "Exception occured: ",e);
			}
			if (stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.log(Level.SEVERE, "Exception occured: ",e);
				}
			}
			try
			{
				if(connection != null)
				{
					connection.close();
				}
			}
			catch(SQLException ex)
			{
				LOGGER.log(Level.SEVERE, "Exception occured: ",ex);
			}
		}
		
		for(int i=0;i<tempCachingHs.size();i++){
			HashMap<String , String> hs = tempCachingHs.get(i);
			DataObject dobj = ZABModel.createRow(resultTableConstants,metaDetails.getResultTable() , hs);
			if(!(isRevenue || isTimeSpent)){
				Array visitorIdsArr = visitorsArray.get(i);
				Long idColumnValue = (Long) dobj.getFirstValue(metaDetails.getResultTable(), mappingColumnName);
				ReportArchieveDimension.addReportVisitorIdsMapping(visitorIdsTable,idColumnName,idColumnValue,visitorIdsArr);

			}
			
		}


	}

	
	public static  void populateCondildatedDimensionTable(String rawTablename,String revenueRawTable  , String timeSpentRawTable  ,String reportTableName,Long time, String dbSpaceId){

		Connection connection = null;
		ResultSet res = null;
		PreparedStatement stmt= null;



		String idColumn =  null;
		String jsVarCombinationTable= null;
		String cookieCombiTable = null;
		String customDimenCombiTable = null;
		String urlParamCombiTbale= null;
		String visitorsIdColumn = null;
		String visitorIdsTable = null;
		Boolean isGoalTable= false;
		Boolean isHourTable= false;
		String revenueTable =  null;
		String timeSpentTable = null;
		List<Constants> constant =  null;

		switch(reportTableName){
		case VISITOR_DIMENSION_DAY.TABLE:
			idColumn=VISITOR_DIMENSION_DAY.VISITOR_DIMENSION_DAY_ID;
			urlParamCombiTbale = "URLPARAM_COMBINATION_VISIT_DAY_"+dbSpaceId;			// NO I18N   
			jsVarCombinationTable = "JSVAR_COMBINATION_VISIT_DAY_"+dbSpaceId;		// NO I18N
			cookieCombiTable = "COOKIE_COMBINATION_VISIT_DAY_"+dbSpaceId;				// NO I18N
			customDimenCombiTable = "CUSTOMDIMEN_COMBINATION_VISIT_DAY_"+dbSpaceId;		// NO I18N
			constant = CumulativeReportConstants.VISITOR_DIMENSION_DAY_CONSTANTS;
			visitorsIdColumn = "DAY_ID";				// NO I18N

			visitorIdsTable = VISITOR_DIMENSION_DAY.TABLE+"_VISITORS_"+dbSpaceId;		// NO I18N

			break;
		case VISITOR_DIMENSION_HOUR.TABLE:
			idColumn=VISITOR_DIMENSION_HOUR.VISITOR_DIMENSION_HOUR_ID;
			urlParamCombiTbale = "URLPARAM_COMBINATION_VISIT_HOUR_"+dbSpaceId;			// NO I18N		
			jsVarCombinationTable = "JSVAR_COMBINATION_VISIT_HOUR_"+dbSpaceId;		// NO I18N
			cookieCombiTable = "COOKIE_COMBINATION_VISIT_HOUR_"+dbSpaceId;				// NO I18N
			customDimenCombiTable = "CUSTOMDIMEN_COMBINATION_VISIT_HOUR_"+dbSpaceId;		// NO I18N
			constant = CumulativeReportConstants.VISITOR_DIMENSION_HOUR_CONSTANTS;
			isHourTable=true;
			visitorsIdColumn = "HOUR_ID";				// NO I18N
			visitorIdsTable = VISITOR_DIMENSION_HOUR.TABLE+"_VISITORS_"+dbSpaceId;		// NO I18N
			
			timeSpentTable = "TIME_SPENT_DIMENSION_HOUR_"+dbSpaceId;	// NO I18N
			break;
		case GOAL_DIMENSION_HOUR.TABLE:
			idColumn=GOAL_DIMENSION_HOUR.GOAL_DIMENSION_HOUR_ID;
			urlParamCombiTbale = "URLPARAM_COMBINATION_GOAL_HOUR_"+dbSpaceId;			// NO I18N  
			jsVarCombinationTable = "JSVAR_COMBINATION_GOAL_HOUR_"+dbSpaceId;		// NO I18N
			cookieCombiTable = "COOKIE_COMBINATION_GOAL_HOUR_"+dbSpaceId;				// NO I18N
			customDimenCombiTable = "CUSTOMDIMEN_COMBINATION_GOAL_HOUR_"+dbSpaceId;		// NO I18N
			isGoalTable=true;
			isHourTable=true;
			visitorsIdColumn = "HOUR_ID";				// NO I18N

			constant = CumulativeReportConstants.GOAL_DIMENSION_HOUR_CONSTANTS;
			visitorIdsTable = GOAL_DIMENSION_HOUR.TABLE+"_VISITORS_"+dbSpaceId;		// NO I18N
			revenueTable = "REVENUE_DIMENSION_HOUR_VISITORS_"+dbSpaceId;	// NO I18N
			break;
		case GOAL_DIMENSION_DAY.TABLE:
			idColumn=GOAL_DIMENSION_DAY.GOAL_DIMENSION_DAY_ID;
			urlParamCombiTbale = "URLPARAM_COMBINATION_GOAL_DAY_"+dbSpaceId;			// NO I18N		
			jsVarCombinationTable = "JSVAR_COMBINATION_GOAL_DAY_"+dbSpaceId;		// NO I18N
			cookieCombiTable = "COOKIE_COMBINATION_GOAL_DAY_"+dbSpaceId;				// NO I18N
			customDimenCombiTable = "CUSTOMDIMEN_COMBINATION_GOAL_DAY_"+dbSpaceId;		// NO I18N
			isGoalTable=true;
			constant = CumulativeReportConstants.GOAL_DIMENSION_DAY_CONSTANTS;
			visitorsIdColumn = "DAY_ID";				// NO I18N
			visitorIdsTable = GOAL_DIMENSION_DAY.TABLE+"_VISITORS_"+dbSpaceId;		// NO I18N
			revenueTable = "REVENUE_DIMENSION_DAY_VISITORS_"+dbSpaceId;	// NO I18N

			break;


		}
		
		try{
			String query = null;
			String groupByClause = null;
			String whereClause = "";
			String joinclause  = "";
			if(isGoalTable){
				query = "SELECT  experiment_id, variation_id, goal_id ,browser_code, device_code, country_code, language_code, usertype_code, os_code, trafficsource_code, reffererurl_code, currenturl_code, dayofweek_code,"+ 	// NO I18N
						"hourofday_code, cookie_json, urlparam_json, js_variable_json,  custom_dimension_json,ARRAY_AGG("+ReportArchieveDimensionConstants.VISITOR_ID+") AS VISITOR_IDS, sum(totalcount_flag)  AS "+ReportArchieveDimensionConstants.TOTAL_COUNT+", sum("+RevenueConstants.REVENUE+") AS "+RevenueConstants.REVENUE+" , count(*) as "+RevenueConstants.PAYING_VISITORS_COUNT+		// NO I18N
						" FROM "+rawTablename;		// NO I18N

				groupByClause = " group by  experiment_id, variation_id,goal_id , browser_code, device_code, country_code, language_code, usertype_code, os_code, "+		// NO I18N
						" trafficsource_code, reffererurl_code, currenturl_code, dayofweek_code, hourofday_code, cookie_json, urlparam_json, js_variable_json, "+		// NO I18N
						"custom_dimension_json;";		// NO I18N
				joinclause  = " left join "+revenueRawTable+"  on "+rawTablename+"."+ReportConstants.GOAL_DATA_RAW_ID+"="+revenueRawTable+"."+ReportConstants.GOAL_DATA_RAW_ID;		// NO I18N



			}else{
				query = "SELECT  experiment_id, variation_id, browser_code, device_code, country_code, language_code, usertype_code, os_code, trafficsource_code, reffererurl_code, currenturl_code, dayofweek_code,"+ 	// NO I18N
						"hourofday_code, cookie_json, urlparam_json, js_variable_json,  custom_dimension_json,ARRAY_AGG("+ReportArchieveDimensionConstants.VISITOR_ID+") AS VISITOR_IDS, sum(totalcount_flag) AS "+ReportArchieveDimensionConstants.TOTAL_COUNT+", sum("+ReportArchieveDimensionConstants.TIME_SPENT+") AS "+ReportArchieveDimensionConstants.TIME_SPENT+" "+ 	// NO I18N
						" FROM "+rawTablename;		// NO I18N
				groupByClause = " group by  experiment_id, variation_id , browser_code, device_code, country_code, language_code, usertype_code, os_code, "+		// NO I18N
						" trafficsource_code, reffererurl_code, currenturl_code, dayofweek_code, hourofday_code, cookie_json, urlparam_json, js_variable_json, "+		// NO I18N
						"custom_dimension_json;";		// NO I18N
				joinclause  = " left join "+timeSpentRawTable+"  on "+rawTablename+"."+ReportConstants.VISITOR_DATA_RAW_ID+"="+timeSpentRawTable+"."+ReportConstants.VISITOR_DATA_RAW_ID;		// NO I18N



			}
			if(isHourTable){

				Long startHourInMs = ZABUtil.getPrevHourTimeInMilliSeconds(time);
				Long endHourInMs = ZABUtil.getHourTimeInMilliSeconds(time);
				whereClause =  " where "+ReportArchieveDimensionConstants.TIME +" between "+startHourInMs +" and "+endHourInMs+" ";	//NO I18N
				time=endHourInMs;

			}else{
				int index = rawTablename.indexOf("RAW_");			// NO I18N
				String dateString  =  rawTablename.substring(index+4);
				SimpleDateFormat sd= new SimpleDateFormat("yyyy_MM_dd");		// NO I18N
				Date date = sd.parse(dateString);
				time = date.getTime();
			}
			query=query+joinclause + whereClause+groupByClause;


			ArrayList<HashMap <String , String >> tempCacheHs = new ArrayList<HashMap<String , String>>();
			ArrayList<Array> visitorIdArray  = new ArrayList<Array>();
			try{
				RelationalAPI relationalApi = RelationalAPI.getInstance();
				connection = relationalApi.getConnection();
				stmt = connection.prepareStatement(query);
				res = stmt.executeQuery();


				ResultSetMetaData meta = res.getMetaData();
				int colCount = meta.getColumnCount();

				while(res.next()) {
					HashMap<String , String> columnValueMap = new HashMap<String,String>();
					for (int col=1; col <= colCount; col++) 
					{
						Object value = res.getObject(col);
						if (value != null) 
						{

							columnValueMap.put(meta.getColumnName(col), value.toString());
						}
					}
					columnValueMap.put(CumulativeReportConstants.TIME, time.toString());

					tempCacheHs.add(columnValueMap);
					visitorIdArray.add(res.getArray("VISITOR_IDS"));// NO I18N

				}



			}catch(Exception ex)
			{
				LOGGER.log(Level.SEVERE, "Exception occured: ",ex);
			}
			finally
			{
				try {
					if(res!=null) {
						res.close();
					}
				} catch (Exception e) {
					LOGGER.log(Level.SEVERE, "Exception occured: ",e);
				}
				if (stmt != null)
				{
					try {
						stmt.close();
					} catch (SQLException e) {
						LOGGER.log(Level.SEVERE, "Exception occured: ",e);
					}
				}
				try
				{
					if(connection != null)
					{
						connection.close();
					}
				}
				catch(SQLException ex)
				{
					LOGGER.log(Level.SEVERE, "Exception occured: ",ex);
				}
			}


			for(int index=0;index<tempCacheHs.size();index++){
				HashMap<String , String > columnValueMap =  tempCacheHs.get(index);

				DataObject dobj = ZABModel.createRow(constant, reportTableName, columnValueMap);
				Long reportId  =(Long) dobj.getFirstValue(reportTableName, idColumn);

				String jsVarJson = columnValueMap.get("js_variable_json");		//  NO I18N
				String urlParamJson = columnValueMap.get("urlparam_json");		//  NO I18N
				String cusDimJson = columnValueMap.get("custom_dimension_json");		//  NO I18N
				String cookieJson = columnValueMap.get("cookie_json");		//  NO I18N

				insertInCombinationJsonTable(jsVarCombinationTable,idColumn,"JSVAR_JSON",reportId,jsVarJson);		// NO I18N
				insertInCombinationJsonTable(urlParamCombiTbale,idColumn,"URLPARAM_JSON",reportId,urlParamJson);		// NO I18N
				insertInCombinationJsonTable(customDimenCombiTable,idColumn,"CUSTOMDIMEN_JSON",reportId,cusDimJson);		// NO I18N
				insertInCombinationJsonTable(cookieCombiTable,idColumn,"COOKIE_JSON",reportId,cookieJson);		// NO I18N

				Array visitorIdsArr = visitorIdArray.get(index);
				ReportArchieveDimension.addReportVisitorIdsMapping(visitorIdsTable,visitorsIdColumn,reportId,visitorIdsArr);


				// adding to revenue table
				// check if it is goal based consolidaiton.. if yes then put value in consolidated revenue ids table


				if(isGoalTable &&  columnValueMap.containsKey(RevenueConstants.REVENUE)){

					Long revenue  = Long.parseLong(columnValueMap.get(RevenueConstants.REVENUE));
					Long payingVisitors  = Long.parseLong(columnValueMap.get(RevenueConstants.PAYING_VISITORS_COUNT));
					addRevenueVisitorIdsMapping(revenueTable ,visitorsIdColumn , reportId , revenue,visitorIdsArr,payingVisitors);
				}
				if(!isGoalTable && columnValueMap.containsKey(ReportArchieveDimensionConstants.TIME_SPENT)){
					Long time_spent  = Long.parseLong(columnValueMap.get(ReportArchieveDimensionConstants.TIME_SPENT));
					addTimeSpentMapping(  timeSpentTable, visitorsIdColumn, reportId, time_spent);
				}
			}

		}catch(Exception e){
			LOGGER.log(Level.SEVERE, "Exception occured: ",e);
		}
		


	}
	public static void addRevenueVisitorIdsMapping( String tableName ,String idColumnName , Long pkey, Long revenue , Array visitorIdsArr, Long payingVisitors)
	{

		Connection connection = null;
		PreparedStatement insertstmt = null;
		try
		{
			RelationalAPI relationalApi = RelationalAPI.getInstance();
			connection = relationalApi.getConnection();
			String insertSql = "INSERT INTO "+ tableName+ "("+idColumnName+",REVENUE ,PAYING_VISITORS_COUNT , VISITOR_IDS) VALUES (?,?,?,?)"; //No I18N
			insertstmt = connection.prepareStatement(insertSql);
			insertstmt.setLong(1, pkey);
			insertstmt.setLong(2, revenue);
			insertstmt.setLong(3, payingVisitors);
			insertstmt.setArray(4, visitorIdsArr);
			insertstmt.executeUpdate();
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occured: ",ex);
		}
		finally
		{
			try
			{
				if(insertstmt != null)
				{
					insertstmt.close();
				}
				if(connection != null)
				{
					connection.close();
				}
			}
			catch(SQLException ex)
			{
				LOGGER.log(Level.SEVERE, "Exception occured: ",ex);
			}

		}
		

	}
	public static void addTimeSpentMapping( String tableName ,String idColumnName , Long pkey, Long timeSpent)
	{

		Connection connection = null;
		PreparedStatement insertstmt = null;
		try
		{
			RelationalAPI relationalApi = RelationalAPI.getInstance();
			connection = relationalApi.getConnection();
			String insertSql = "INSERT INTO "+ tableName+ "("+idColumnName+",TIME_SPENT ) VALUES (?,?)"; //No I18N
			insertstmt = connection.prepareStatement(insertSql);
			insertstmt.setLong(1, pkey);
			insertstmt.setLong(2, timeSpent);
			insertstmt.executeUpdate();
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occured: ",ex);
		}
		finally
		{
			try
			{
				if(insertstmt != null)
				{
					insertstmt.close();
				}
				if(connection != null)
				{
					connection.close();
				}
			}
			catch(SQLException ex)
			{
				LOGGER.log(Level.SEVERE, "Exception occured: ",ex);
			}

		}
	}

	public static  void insertInCombinationJsonTable(String tablename, String idColumnName, String jsonColumnNmae, Long id , String jsonValue){


		Connection connection = null;
		PreparedStatement insertstmt = null;
		try
		{
			RelationalAPI relationalApi = RelationalAPI.getInstance();
			connection = relationalApi.getConnection();

			PGobject json = new PGobject();
			json.setType("jsonb"); // No I18N
			json.setValue(jsonValue);

			String insertSql = "INSERT INTO "+tablename+" ("+idColumnName+","+jsonColumnNmae+") values (?,?)";  //No I18N
			insertstmt = connection.prepareStatement(insertSql);
			insertstmt.setLong(1, id);
			insertstmt.setObject(2, json);
			insertstmt.executeUpdate();
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occured: ",ex);
		}
		finally
		{
			try
			{
				if(insertstmt != null)
				{
					insertstmt.close();
				}
				if(connection != null)
				{
					connection.close();
				}
			}
			catch(SQLException ex)
			{
				LOGGER.log(Level.SEVERE, "Exception occured: ",ex);
			}

		}

	}

	public static void revenueCumulativeReport(String rawTable,String revenueRawTable,  final CumulativeTableMetaValues metaDetails,Long scheduleTime, String dbspaceId){


		try
		{
			String groupByClause = " group by "+metaDetails.getGroupByColumns()+";";	// NO I18N
			String whereString  = " ";
			String query ="select "+metaDetails.getGroupByColumns() +", sum("+RevenueConstants.REVENUE+") AS "+RevenueConstants.REVENUE+" , count(*) as "+RevenueConstants.PAYING_VISITORS_COUNT+" from "+rawTable ;//NO I18N
			String joinclause  = " inner join "+revenueRawTable+"  on "+rawTable+"."+ReportConstants.GOAL_DATA_RAW_ID+"="+revenueRawTable+"."+ReportConstants.GOAL_DATA_RAW_ID;		// NO I18N

			if(metaDetails.getDurationType() ==  ReportDurationType.HOUR.getDurationCode()) {

				Long startHourInMs = ZABUtil.getPrevHourTimeInMilliSeconds(scheduleTime);
				Long endHourInMs = ZABUtil.getHourTimeInMilliSeconds(scheduleTime);
				whereString =  " where "+ReportArchieveDimensionConstants.TIME +" between "+startHourInMs +" and "+endHourInMs+" ";	//NO I18N
				cumulativeReportPopulationFromQuery(query+joinclause+whereString+groupByClause,metaDetails,endHourInMs,dbspaceId);

			}
			else if(metaDetails.getDurationType() ==  ReportDurationType.DAY.getDurationCode()){

				// GET DATE VALUE FROM RAW TABLE NAME 
				int index = rawTable.indexOf("RAW_");			// NO I18N
				String dateString  =  rawTable.substring(index+4);
				SimpleDateFormat sd= new SimpleDateFormat("yyyy_MM_dd");		// NO I18N
				Date date = sd.parse(dateString);
				Long dateInMillis = date.getTime();
				cumulativeReportPopulationFromQuery(query+joinclause+groupByClause,metaDetails,dateInMillis,dbspaceId);
			}

		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occured: ",ex);
		}



	}
	public static void timeSpentCumulativeReport(String rawTable,String timeSpentRawTable,  final CumulativeTableMetaValues metaDetails,Long scheduleTime, String dbspaceId){


		try
		{
			String groupByClause = " group by "+metaDetails.getGroupByColumns()+";";	// NO I18N
			String whereString  = " ";
			String query ="select "+metaDetails.getGroupByColumns() +", sum("+ReportArchieveDimensionConstants.TIME_SPENT+") AS "+ReportArchieveDimensionConstants.TIME_SPENT+" from "+rawTable ;//NO I18N
			String joinclause  = " inner join "+timeSpentRawTable+"  on "+rawTable+"."+ReportRawDataConstants.VISITOR_DATA_RAW_ID+"="+timeSpentRawTable+"."+ReportRawDataConstants.VISITOR_DATA_RAW_ID;		// NO I18N

			if(metaDetails.getDurationType() ==  ReportDurationType.HOUR.getDurationCode()) {

				Long startHourInMs = ZABUtil.getPrevHourTimeInMilliSeconds(scheduleTime);
				Long endHourInMs = ZABUtil.getHourTimeInMilliSeconds(scheduleTime);
				whereString =  " where "+ReportArchieveDimensionConstants.TIME +" between "+startHourInMs +" and "+endHourInMs+" ";	//NO I18N
				cumulativeReportPopulationFromQuery(query+joinclause+whereString+groupByClause,metaDetails,endHourInMs,dbspaceId);

			}

		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occured: ",ex);
		}



	}
}