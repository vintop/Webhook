//$Id$
package com.zoho.abtest.job;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.TimeZone;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.zoho.abtest.adminconsole.AdminConsole;
import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.utility.ApplicationProperty;
import com.zoho.abtest.utility.ZABHTTPClient;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.scheduler.RunnableJob;

public class PSAdminStatsJob implements RunnableJob
{
	private static final Logger LOGGER = Logger.getLogger(PSAdminStatsJob.class.getName());

	public static final String MAIL_FROM_ADDRESS = ApplicationProperty.getString("com.abtest.transmail.mail_from"); // No I18N
	public static final String MAIL_TO_ADDRESS = ApplicationProperty.getString("com.abtest.transmail.es.mail_to"); // No I18N
	
	@Override
	public void run(long l) 
	{
		LOGGER.log(Level.INFO, "PSAdminStatsJob - Schedule Job starts running");
		try
		{
			getAndMailAdminStatDetails();
			LOGGER.log(Level.INFO, "PSAdminStatsJob - Schedule Job completed successfully");
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "PSAdminStatsJob - Schedule Job exception occurred",ex);
		}
	}
	
	public void getAndMailAdminStatDetails() throws Exception
	{
		Long startTime = null;
		Long endTime = null;
		
		//For yesterday
		Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("Asia/Kolkata"));
		cal.add(Calendar.DATE, -1);
		
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		startTime = cal.getTimeInMillis();
		
		SimpleDateFormat format1 = new SimpleDateFormat("dd-MM-yyyy");  // No I18N
		format1.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));  // No I18N
		String statsDate = format1.format(cal.getTime());
				
		cal.set(Calendar.HOUR_OF_DAY, 23);
		cal.set(Calendar.MINUTE, 59);
		cal.set(Calendar.SECOND, 59);
		cal.set(Calendar.MILLISECOND, 999);
		endTime = cal.getTimeInMillis();
		
		AdminConsole yesterdayAdminConsoleObj = AdminConsole.getAdminConsoleDashboardDetails(startTime, endTime, false);
		
		//For last 30 days
		cal.add(Calendar.DATE, -29);
		
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		startTime = cal.getTimeInMillis();
		
		AdminConsole monthdaysAdminConsoleObj = AdminConsole.getAdminConsoleDashboardDetails(startTime, endTime, false);
		
		String templatePath = "/../../mailtemplate/adminstats.html"; //No I18N
		String url = PSAdminStatsJob.class.getResource(templatePath).getPath();
		String mailTemplate = new String(Files.readAllBytes(Paths.get(url)));
		mailTemplate = mailTemplate.replace("${yportals}", yesterdayAdminConsoleObj.getTotalPortalCount().toString());  //No I18N
		mailTemplate = mailTemplate.replace("${yprojects}", yesterdayAdminConsoleObj.getTotalProjectCount().toString());  //No I18N
		mailTemplate = mailTemplate.replace("${yexperiments}", yesterdayAdminConsoleObj.getTotalExpCount().toString());  //No I18N
		mailTemplate = mailTemplate.replace("${yvisitors}", yesterdayAdminConsoleObj.getTotalVisitorsCount().toString());  //No I18N
		mailTemplate = mailTemplate.replace("${yaccounts}", yesterdayAdminConsoleObj.getTotalAccountCount().toString());  //No I18N
		
		mailTemplate = mailTemplate.replace("${l30portals}", monthdaysAdminConsoleObj.getTotalPortalCount().toString());  //No I18N
		mailTemplate = mailTemplate.replace("${l30projects}", monthdaysAdminConsoleObj.getTotalProjectCount().toString());  //No I18N
		mailTemplate = mailTemplate.replace("${l30experiments}", monthdaysAdminConsoleObj.getTotalExpCount().toString());  //No I18N
		mailTemplate = mailTemplate.replace("${l30visitors}", monthdaysAdminConsoleObj.getTotalVisitorsCount().toString());  //No I18N
		mailTemplate = mailTemplate.replace("${l30accounts}", monthdaysAdminConsoleObj.getTotalAccountCount().toString());  //No I18N
		
		if(ElasticSearchUtil.IS_PRODUCTION_MODE)
		{
			String subject = "PageSense app stats - " + statsDate + " IST"; // No I18N
			ZABUtil.sendEmail(mailTemplate, MAIL_FROM_ADDRESS, MAIL_TO_ADDRESS, subject);
			// Pushing daily stats to Zoho reports
		    try {
			    sendDailyStatsToReports(yesterdayAdminConsoleObj);
		    } catch (Exception e) {
			    LOGGER.log(Level.SEVERE, "Exception occured while pushing daily stats to Zoho Reports: ",e);
		    }
		}
		
		
	}

	private void sendDailyStatsToReports(AdminConsole yesterdayAdminConsoleObj) {
		final String authToken = ApplicationProperty.getString("zohoReports.authtoken"); // No I18N 
		final String zreportsURL = ApplicationProperty.getString("zohoReports.url"); // No I18N 
		
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy"); // No I18N
		Date date = new Date();
		
		Properties params=new Properties();
		params.setProperty("authtoken", authToken);
		params.setProperty("ZOHO_ACTION", "ADDROW");
		params.setProperty("ZOHO_OUTPUT_FORMAT", "JSON");
		params.setProperty("ZOHO_ERROR_FORMAT", "JSON");
		params.setProperty("ZOHO_API_VERSION", "1.0");
		params.setProperty("Portals", yesterdayAdminConsoleObj.getTotalPortalCount().toString());
		params.setProperty("Projects", yesterdayAdminConsoleObj.getTotalProjectCount().toString());
		params.setProperty("Experiments", yesterdayAdminConsoleObj.getTotalExpCount().toString());
		params.setProperty("Visitors", yesterdayAdminConsoleObj.getTotalVisitorsCount().toString());
		params.setProperty("Date", dateFormat.format(date));
		
		ZABHTTPClient httpClient = new ZABHTTPClient();
		httpClient.setUrl(zreportsURL);
		httpClient.setParams(params);
		httpClient.setMethod("POST"); // No I18N
		String result=null;
		try {
			result=httpClient.sendRequest();
		} catch (IOException e) {
			LOGGER.log(Level.SEVERE, "Zoho Reports daily stats pushing exception : ",e);
		}
	}
	
}
