//$Id$
package com.zoho.abtest.job;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;

import com.adventnet.mfw.bean.BeanUtil;
import com.adventnet.sas.ds.SASThreadLocal;
import com.zoho.abtest.utility.ZABTableCreationBean;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.scheduler.RunnableJob;

public class RawdataTableGeneration implements RunnableJob{

	private static final Logger LOGGER = Logger.getLogger(RawdataTableGeneration.class.getName());
	
	public void run(long l)
	{
		// Commented out this since raw tables will be generated on the first hit of the data
		/*
		try
		{
			String dbspaceId = SASThreadLocal.getLoginName();
			LOGGER.log(Level.INFO, "RawdataTableGeneration - Schedule Job starts running:"+ dbspaceId);
			ZABUtil.setIsSchedulerJob(Boolean.TRUE);
			ZABTableCreationBean userAction = (ZABTableCreationBean)BeanUtil.lookup("ZABTableCreationBean");
			if(StringUtils.isNotEmpty(dbspaceId))
			{
				userAction.createReportRawDataTables(dbspaceId);
				//TODO commented temporarily for localzoho as heatmap is not required
				//userAction.createHeatmapDataTable();
			}
			LOGGER.log(Level.INFO, "RawdataTableGeneration - Schedule Job successfully completed:"+ dbspaceId);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "RawdataTableGeneration - Excepion occurred", ex);
		}
		*/
	}
}
