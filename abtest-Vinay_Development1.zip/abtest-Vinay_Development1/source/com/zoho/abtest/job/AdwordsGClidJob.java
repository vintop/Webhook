//$Id$
package com.zoho.abtest.job;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.zoho.abtest.integration.GoogleAdwords;
import com.zoho.scheduler.RunnableJob;

public class AdwordsGClidJob implements RunnableJob
{
	private static final Logger LOGGER = Logger.getLogger(AdwordsGClidJob.class.getName());
	
	@Override
	public void run(long l) 
	{
		LOGGER.log(Level.INFO, "AdwordsGClidJob - Schedule Job starts running");
		try
		{
			GoogleAdwords.addGClidJob();
			LOGGER.log(Level.INFO, "AdwordsGClidJob - Schedule Job completed successfully");
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "AdwordsGClidJob - Schedule Job exception occurred",ex);
		}
	}
}
