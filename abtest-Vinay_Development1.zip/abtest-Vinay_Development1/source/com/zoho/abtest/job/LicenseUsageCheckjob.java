//$Id$
package com.zoho.abtest.job;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.zoho.abtest.license.LicenseVerification;
import com.zoho.scheduler.RunnableJob;

public class LicenseUsageCheckjob implements RunnableJob
{
	private static final Logger LOGGER = Logger.getLogger(LicenseUsageCheckjob.class.getName());
	
	@Override
	public void run(long l) 
	{
		LOGGER.log(Level.INFO, "LicenseUsageCheckjob - Schedule Job starts running");
		try
		{
			LicenseVerification.verifyUserLicenseStatus();
			LOGGER.log(Level.INFO, "LicenseUsageCheckjob - Schedule Job completed successfully");
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "LicenseUsageCheckjob - Schedule Job exception occurred",ex);
		}
	}
}
