//$Id$
package com.zoho.abtest.job;

import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.report.ArchieveTableMeta;
import com.zoho.abtest.report.ReportArchieveDimension;
import com.zoho.abtest.report.ReportArchieveDimensionConstants;
import com.zoho.abtest.report.ReportRawDataConstants;
import com.zoho.abtest.report.ReportArchieveDimensionConstants.ReportModuleType;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.scheduler.RunnableJob;

public class ArchiveRawDataByDimensionsOnDay implements RunnableJob {

	private static final Logger LOGGER = Logger.getLogger(ArchiveRawDataByDimensionsOnDay.class.getName());
	
	public void run(long l)
	{
		/*
		LOGGER.log(Level.INFO, "ArchiveVisitorRawDataOnDay - Schedule Job starts running");
		ZABUtil.setIsSchedulerJob(Boolean.TRUE);
		Long jobScheduleStartTime = ZABUtil.getCurrentTimeInMilliSeconds();
		Long dateOfData = ZABUtil.getNthDayDateInLong(jobScheduleStartTime, -1);
		try
		{
			List<ArchieveTableMeta> archieveTableMetaDetails = ArchieveTableMeta.getDailyArchieveTableMetaDetails();
			
			String visitorRawDataTable;
			String goalAchievedRawDataTable;
			String previousDaydate = ZABUtil.getNthDayDate(jobScheduleStartTime, -1);
			visitorRawDataTable = ReportRawDataConstants.VISITOR_DATA_RAW + ZABConstants.UNDERSCORE + previousDaydate;
			goalAchievedRawDataTable = ReportRawDataConstants.GOAL_DATA_RAW + ZABConstants.UNDERSCORE + previousDaydate; 
			
			for(ArchieveTableMeta archieveTableMeta:archieveTableMetaDetails)
			{
				String columnName = archieveTableMeta.getColumnName();
				String groupByColumns = archieveTableMeta.getGroupByColumns();
				String[] groupByColumnnArr = groupByColumns.split(",");
				String resultArchieveTable = archieveTableMeta.getResultArchieveTable();
				String visitorIdsTable = archieveTableMeta.getVisitorIdsTable();
				int durationType = archieveTableMeta.getDurationType();
				int moduleType = archieveTableMeta.getModuleType();
				boolean isStandardDimension = archieveTableMeta.getIsStandardDimension();
				
				if(moduleType == ReportModuleType.VISIT.getModuleCode())
				{
					if(isStandardDimension)
					{
						ReportArchieveDimension.archieveIndividualReportOnStandardDimension(visitorRawDataTable, columnName, groupByColumnnArr, resultArchieveTable, visitorIdsTable, durationType, null, dateOfData);
					}
					else
					{
						ReportArchieveDimension.archieveIndividualReportOnDynamicAttributes(visitorRawDataTable, columnName, groupByColumnnArr, resultArchieveTable, visitorIdsTable, durationType, null, dateOfData);
					}
				}
				else if(moduleType == ReportModuleType.GOALACHIEVED.getModuleCode())
				{
					if(isStandardDimension)
					{
						ReportArchieveDimension.archieveIndividualReportOnStandardDimension(goalAchievedRawDataTable, columnName, groupByColumnnArr, resultArchieveTable, visitorIdsTable, durationType, null, dateOfData);
					}
					else
					{
						ReportArchieveDimension.archieveIndividualReportOnDynamicAttributes(goalAchievedRawDataTable, columnName, groupByColumnnArr, resultArchieveTable, visitorIdsTable, durationType, null, dateOfData);
					}
				}
				
				//Update last archived time in the meta table
				HashMap<String, String> updateMetaHs = new HashMap<String, String>();
				updateMetaHs.put(ReportArchieveDimensionConstants.ARCHIEVE_TABLE_ID, archieveTableMeta.getArchieveTableId().toString());
				updateMetaHs.put(ReportArchieveDimensionConstants.LAST_ARCHIEVED_TIME, jobScheduleStartTime.toString());
				ArchieveTableMeta.updateArchieveTableMeta(updateMetaHs);
				
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in ArchiveVisitorRawDataOnDay", ex);
		}
		LOGGER.log(Level.INFO, "ArchiveVisitorRawDataOnDay - Schedule Job successfully finished");
		*/
	}

}
