//$Id$
package com.zoho.abtest.job;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.zoho.abtest.sessionrecording.playlist.SessionPlayList;
import com.zoho.scheduler.RunnableJob;

public class ConsentOptOutDeleteJob implements RunnableJob
{
	private static final Logger LOGGER = Logger.getLogger(HeatMapLimitCheckJob.class.getName());
	
	@Override
	public void run(long l) 
	{
		LOGGER.log(Level.INFO, "ConsentOptOutDeleteJob - Schedule Job starts running");
		try
		{
			//Session Recording 
			SessionPlayList.deleteOptOutRecording();
			
			//For other experiment opted out user deletions handling
			LOGGER.log(Level.INFO, "ConsentOptOutDeleteJob - Schedule Job completed successfully");
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "ConsentOptOutDeleteJob - Schedule Job exception occurred",ex);
		}
	}

}