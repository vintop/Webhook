//$Id$
package com.zoho.abtest.job;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.UpdateQuery;
import com.adventnet.ds.query.UpdateQueryImpl;
import com.adventnet.iam.ServiceOrg;
import com.adventnet.iam.User;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.AC_PORTAL;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.elastic.ElasticSearchStatistics;
import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.user.ZABUser;
import com.zoho.abtest.utility.ApplicationProperty;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.abtest.zcampaigns.ZCampaignBridge;
import com.zoho.scheduler.RunnableJob;

public class ZCampaignScriptVerifyJob  implements RunnableJob
{

	private static final Logger LOGGER = Logger.getLogger(ZCampaignScriptVerifyJob.class.getName());
	
	private static final Boolean PRODUCION_MODE = ApplicationProperty.getBoolean("com.abtest.productionmode"); //NO I18N
	
	@Override
	public void run(long arg0) throws Exception {
		LOGGER.log(Level.INFO, "ZCampaignScriptVerifyJob - Schedule Job starts running");
		try
		{
			if(PRODUCION_MODE)
			{
				sendScriptVerificationToZCampaigns();
			}
			LOGGER.log(Level.INFO, "ZCampaignScriptVerifyJob - Schedule Job completed successfully. Prod Mode:"+ElasticSearchUtil.IS_PRODUCTION_MODE);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "ZCampaignScriptVerifyJob - Schedule Job exception occurred",ex);
		}
	}
	
	public static Long sendScriptVerificationToZCampaigns()
	{
		try {			
			AggregationBuilder aggrBuilder = ElasticSearchStatistics.getPortalDataAggr();
			String indexPattern = ElasticSearchConstants.DEFAULT_INDEX_PREFIX + "*";
			String[] typeArray = ElasticSearchConstants.VISITOR_DOC_TYPES;
			String existingDBSpace = ZABUtil.getDBSpace();
			ZABUtil.setDBSpace("sharedspace");	//No I18N
			
			Criteria c = new Criteria(new Column(AC_PORTAL.TABLE, AC_PORTAL.SCRIPT_VERIFIED), Boolean.FALSE, QueryConstants.EQUAL);
			DataObject dobj = ZABModel.getRow(AC_PORTAL.TABLE, c);
			Iterator<Row> it = dobj.getRows(AC_PORTAL.TABLE);
			
			List<List<String>> batches = new ArrayList<List<String>>();
			
			int maxValue = 100;
			List<String> buffer = new ArrayList<String>();
			while(it.hasNext()) {
				Row r = (Row)it.next();
				String portalId = (String) r.get(AC_PORTAL.PORTAL_DOMAIN);
				buffer.add(portalId);
				if(buffer.size() >= maxValue || !it.hasNext()) {
					batches.add(buffer);
					buffer = new ArrayList<String>();
				}
			}
			
			LOGGER.log(Level.INFO, "Script unverified portals:"+batches+", Batch size:"+batches.size());
			
			for(List portalIds: batches) {
				
				LOGGER.log(Level.INFO, "ZCampaign Batched data:"+portalIds.size());
				
				QueryBuilder query = QueryBuilders.boolQuery().must(QueryBuilders.termsQuery(ElasticSearchConstants.PORTAL, portalIds));
				SearchResponse response = ElasticSearchUtil.getData(indexPattern, typeArray, 0, query, aggrBuilder);
				LOGGER.log(Level.INFO, "Script verification elastic response"+response);
				Aggregations visitorAggrResponse = response.getAggregations();
				Terms termAgg = visitorAggrResponse.get("portal_entries");
				
				ArrayList<Long> scriptVerifiedZOIDs = new ArrayList<Long>();
				ArrayList<String> scriptVerifiedEmails = new ArrayList<String>();
				for (Terms.Bucket entry : termAgg.getBuckets()) {
					String key = entry.getKeyAsString();
					long docCount = entry.getDocCount();
					if(docCount > 0) {
						ServiceOrg org = ZABServiceOrgUtil.getServiceOrgForDomain(key);
						if(org!=null) {
							Long ownerId = org.getCreatedBy();
							User user = ZABUser.getUserByZUID(ownerId);
							scriptVerifiedZOIDs.add(org.getZSOID());
							scriptVerifiedEmails.add(user.getPrimaryEmail());
						}
					}
				}
				
				LOGGER.log(Level.INFO, "Script verified portals:"+scriptVerifiedEmails+", Verified count:"+scriptVerifiedEmails.size());
				
				if(scriptVerifiedEmails.size() > 0 && scriptVerifiedZOIDs.size() > 0) {				
					
					ZCampaignBridge.pushScriptVerifiedEvent(scriptVerifiedEmails);
					
					Criteria c2 = new Criteria(new Column(AC_PORTAL.TABLE,
							AC_PORTAL.ZSOID),
							scriptVerifiedZOIDs.toArray(new Long[scriptVerifiedZOIDs
							                                     .size()]), QueryConstants.IN);
					
					UpdateQuery updateQuery = new UpdateQueryImpl(AC_PORTAL.TABLE);
					updateQuery.setUpdateColumn(AC_PORTAL.SCRIPT_VERIFIED, Boolean.TRUE);
					updateQuery.setCriteria(c2);
					ZABModel.updateRow(updateQuery);
				}
			}
			
			ZABUtil.setDBSpace(existingDBSpace);
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}
		
		
		return null;
	}

}
