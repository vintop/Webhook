//$Id$
package com.zoho.abtest.job;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.zoho.abtest.dataretention.DataRetention;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.scheduler.RunnableJob;

public class DataExpiredDeletionJob implements RunnableJob
{
	private static final Logger LOGGER = Logger.getLogger(DataExpiredDeletionJob.class.getName());

	@Override
	public void run(long l) 
	{
		LOGGER.log(Level.INFO, "DataExpiredDeletionJob - Schedule Job starts running");
		try
		{
			ZABUtil.setDBSpace("sharedspace");	//No I18N
			//DataRetention.deleteExpiredData();
			DataRetention.cleanupTrialExpiredData();
			LOGGER.log(Level.INFO, "DataExpiredDeletionJob - Schedule Job completed successfully");
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "DataExpiredDeletionJob - Schedule Job exception occurred",ex);
		}
	}
}
