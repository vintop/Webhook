//$Id$
package com.zoho.abtest.job;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.scheduler.RunnableJob;

public class ESFailedEntryPushJob implements RunnableJob
{
	private static final Logger LOGGER = Logger.getLogger(ESFailedEntryPushJob.class.getName());
	
	@Override
	public void run(long l) 
	{
		LOGGER.log(Level.INFO, "ESFailedEntryPushJob - Schedule Job starts running");
		try
		{
			ElasticSearchUtil.pushFailedEntryIntoES(0);
			LOGGER.log(Level.INFO, "ESFailedEntryPushJob - Schedule Job completed successfully");
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "ESFailedEntryPushJob - Schedule Job exception occurred",ex);
		}
	}
}
