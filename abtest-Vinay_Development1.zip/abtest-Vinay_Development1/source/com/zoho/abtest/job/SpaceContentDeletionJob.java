//$Id$
package com.zoho.abtest.job;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.zoho.abtest.portal.SpaceDeletionDetails;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.scheduler.RunnableJob;

public class SpaceContentDeletionJob implements RunnableJob
{
	private static final Logger LOGGER = Logger.getLogger(SpaceContentDeletionJob.class.getName());

	@Override
	public void run(long l) 
	{
		LOGGER.log(Level.INFO, "SpaceContentDeletionJob - Schedule Job starts running");
		try
		{
			ZABUtil.setDBSpace("sharedspace");	//No I18N
			SpaceDeletionDetails.cleanupDeletedSpaceData();
			LOGGER.log(Level.INFO, "SpaceContentDeletionJob - Schedule Job completed successfully");
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "SpaceContentDeletionJob - Schedule Job exception occurred",ex);
		}
	}
}
