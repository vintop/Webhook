//$Id$
package com.zoho.abtest.job;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.sas.ds.SASThreadLocal;
import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.scheduler.RunnableJob;

public class ESHealthCheckJob implements RunnableJob
{
	private static final Logger LOGGER = Logger.getLogger(ESHealthCheckJob.class.getName());

	@Override
	public void run(long l) 
	{
		LOGGER.log(Level.INFO, "ESHealthCheckJob - Schedule Job starts running");
		try
		{
			String dbspaceId = SASThreadLocal.getLoginName();
			ElasticSearchUtil.reportClusterIndicesHealth();
			LOGGER.log(Level.INFO, "ESHealthCheckJob - Schedule Job completed successfully");
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "ESHealthCheckJob - Schedule Job exception occurred",ex);
		}
	}
}
