//$Id$
package com.zoho.abtest.job;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.mfw.bean.BeanUtil;
import com.adventnet.sas.ds.SASThreadLocal;
import com.zoho.abtest.utility.ZABTableCreationBean;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.scheduler.RunnableJob;

public class RawdataTableCleanup implements RunnableJob{

	private static final Logger LOGGER = Logger.getLogger(RawdataTableCleanup.class.getName());
	
	public void run(long arg0) throws Exception {
		/*
		try
		{
			String dbspaceId = SASThreadLocal.getLoginName();
			LOGGER.log(Level.INFO, "RawdataTableCleanup - Schedule Job starts running:"+dbspaceId);
			ZABUtil.setIsSchedulerJob(Boolean.TRUE);
			ZABTableCreationBean userAction = (ZABTableCreationBean)BeanUtil.lookup("ZABTableCreationBean");
			userAction.dropUnusedRawdataTables(dbspaceId);
			
			LOGGER.log(Level.INFO, "RawdataTableCleanup - Schedule Job successfully finished:"+dbspaceId);
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in RawdataTableCleanup", ex);
		}
		*/
	}
	
}
