//$Id$
package com.zoho.abtest.job;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.zoho.abtest.GOAL_REPORT_HOUR;
import com.zoho.abtest.VISITOR_REPORT_HOUR;
import com.zoho.abtest.report.ArchieveTableMeta;
import com.zoho.abtest.report.ReportArchieveDimension;
import com.zoho.abtest.utility.ApplicationProperty;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.conf.Configuration;
import com.zoho.scheduler.RunnableJob;

public class ReportHourTableCleanup implements RunnableJob{

	private static final Logger LOGGER = Logger.getLogger(ReportHourTableCleanup.class.getName());
	
	public void run(long l)
	{
		/*try
		{
			LOGGER.log(Level.INFO, "ReportHourTableCleanup - Schedule Job starts running");
			ZABUtil.setIsSchedulerJob(Boolean.TRUE);
			cleanOldDataFromReportHourTable();
			LOGGER.log(Level.INFO, "ReportHourTableCleanup - Schedule Job successfully finished");
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in ReportHourTableCleanup", ex);
		}*/
	}
	
	public void cleanOldDataFromReportHourTable()
	{
		try
		{
			List<ArchieveTableMeta> archieveTableMetaDetails = ArchieveTableMeta.getHourlyArchieveTableMetaDetails();
			List<String> hourTablesToBeCleaned = new ArrayList<String>();
			hourTablesToBeCleaned.add(VISITOR_REPORT_HOUR.TABLE);
			hourTablesToBeCleaned.add(GOAL_REPORT_HOUR.TABLE);
			for(ArchieveTableMeta archieveTableMeta:archieveTableMetaDetails)
			{
				hourTablesToBeCleaned.add(archieveTableMeta.getResultArchieveTable());
			}
			Integer nthDayTobeCleaned = ApplicationProperty.getInteger("max.hourreporttable.duration"); // No I18N
			Long startDate = ZABUtil.getNthDayDateInLong(ZABUtil.getCurrentTimeInMilliSeconds(), -nthDayTobeCleaned);
			Long nextDate = ZABUtil.getNthDayDateInLong(startDate, 1);
			long startTime = startDate + 1;
			long endTime = nextDate;
			ReportArchieveDimension.cleanUpReportHourTable(hourTablesToBeCleaned, startTime, endTime);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occured: ",ex);
		}
	}
	
}
