//$Id$
package com.zoho.abtest.crmplus;

import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

import com.adventnet.zoho.bundle.action.ZohoBundleAccount;
import com.adventnet.zoho.bundle.action.ZohoBundleAccountMember;
import com.adventnet.zoho.bundle.action.ZohoBundleException;
import com.adventnet.zoho.bundle.action.ZohoBundleException.ErrorCode;
import com.adventnet.zoho.bundle.bean.ZohoBundleHandler;
import com.zoho.abtest.utility.ZABUtil;

public class ZohoBundleHandlerImpl extends ZohoBundleHandler
{

	@Override
	public boolean changeDomainName(long zid, String newDomainName, JSONObject params)
			throws ZohoBundleException {
		// We wont allow updating the domain name - as report rawdatas need to be updated and adminconsole tables needs to be updated
		throw new ZohoBundleException(ErrorCode.DOMAIN_UPDATE_NOT_ALLOWED);
	}

	@Override
	public boolean changeInvitationStatus(long zid, String[] emailIds, boolean enable, JSONObject params) throws ZohoBundleException {
		ZABUtil.setCurrentUser(null);
		return CRMPlusUtil.changeInvitationStatus(zid, emailIds, enable);
	}

	@Override
	public boolean changeMemberStatus(long zid, Long[] zuids, boolean enable,
			JSONObject params) throws ZohoBundleException {
		ZABUtil.setCurrentUser(null);
		return CRMPlusUtil.changeMemberStatus(zid, zuids, enable, params);
	}

	@Override
	public boolean changeOwner(long zid, ZohoBundleAccountMember newOwner, JSONObject params) throws ZohoBundleException {
		ZABUtil.setCurrentUser(null);
		Long newOwnerZuid = newOwner.getZuid();
		return CRMPlusUtil.changeOwner(zid, newOwnerZuid);
	}
	
	@Override
	public boolean confirmInvitation(long zid, long inviteeZUID, String emailId,
			JSONObject params) throws ZohoBundleException {
		ZABUtil.setCurrentUser(null);
		return CRMPlusUtil.confirmInvitation(zid, inviteeZUID, emailId);
	}

	@Override
	public long createAccount(ZohoBundleAccount zAccount,
			List<ZohoBundleAccountMember> admins,
			List<ZohoBundleAccountMember> members, JSONObject params)
			throws ZohoBundleException {
		ZABUtil.setCurrentUser(null);
		return CRMPlusUtil.createAccount(zAccount, admins, members, params);
	}

	@Override
	public boolean deleteInvitation(long zid, String emailId)
			throws ZohoBundleException {
		ZABUtil.setCurrentUser(null);
		return CRMPlusUtil.deleteInvitation(zid, emailId);
	}

	@Override
	public boolean deleteMember(long zid, long zuid, JSONObject params)
			throws ZohoBundleException {
		ZABUtil.setCurrentUser(null);
		return CRMPlusUtil.deleteMember(zid, zuid);
	}

	@Override
	public JSONObject getAccountInfo(long zid, String action, JSONObject params) throws ZohoBundleException 
	{
		ZABUtil.setCurrentUser(null);
		return CRMPlusUtil.getAccountInfo(zid, action, params);
	}
	
	@Override
	public List<JSONObject> getMembersInfo(long zid, String action, JSONObject params, Long[] zuids) throws ZohoBundleException 
	{
		ZABUtil.setCurrentUser(null);
		return CRMPlusUtil.getMembersInfo(zid, action, params, zuids);
	}

	@Override
	public List<JSONObject> getMembersInfo(long zid, String action, JSONObject params, String[] emailIds) throws ZohoBundleException {
		ZABUtil.setCurrentUser(null);
		return CRMPlusUtil.getMembersInfo(zid, action, params, emailIds);
	}
	
	@Override
	public boolean handleSubscriptionChange(long zid, JSONArray changeArray,JSONObject params) throws ZohoBundleException {
		ZABUtil.setCurrentUser(null);
		return CRMPlusUtil.handleSubscriptionChange(zid, changeArray, params);
	}

	@Override
	public boolean isDomainExists(String domainName, JSONObject params)
			throws ZohoBundleException {
		return CRMPlusUtil.isDomainExists(domainName, params);
	}

	@Override
	public boolean isInvitedMember(long zid, String emailId)
			throws ZohoBundleException {
		ZABUtil.setCurrentUser(null);
		return CRMPlusUtil.isInvitedMember(zid, emailId);
	}

	@Override
	public boolean isServiceAdmin(long zid, long zuid)
			throws ZohoBundleException {
		ZABUtil.setCurrentUser(null);
		return CRMPlusUtil.isServiceAdmin(zid, zuid);
	}

	@Override
	public boolean updateAccount(long zid, ZohoBundleAccount zAccount,
			JSONObject params) throws ZohoBundleException {
		ZABUtil.setCurrentUser(null);
		return CRMPlusUtil.updateAccount(zid, zAccount, params);
	}

	@Override
	public boolean updateMembers(long zid, List<ZohoBundleAccountMember> members,
			JSONObject params) throws ZohoBundleException {
		ZABUtil.setCurrentUser(null);
		return CRMPlusUtil.updateMembers(zid, members, params);
	}

	@Override
	public boolean updatePendingMember(long zid, String firstName, String lastName,
			String emailId, ZohoBundleAccountMember member, JSONObject params)
			throws ZohoBundleException {
		ZABUtil.setCurrentUser(null);
		return CRMPlusUtil.updatePendingMember(zid, firstName, lastName, emailId, member, params);
	}
	
	@Override
	public Map<Long, List<JSONObject>> getUsedAccounts(Long[] arg0,
			JSONObject arg1) throws ZohoBundleException {
		// TODO Auto-generated method stub
		return null;
	}
}
