//$Id$
package com.zoho.abtest.crmplus;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONObject;

import com.adventnet.iam.User;
import com.adventnet.iam.ServiceOrgMember.UserRole;
import com.adventnet.zoho.bundle.action.ZohoBundleAccount;
import com.adventnet.zoho.bundle.action.ZohoBundleAccountMember;
import com.adventnet.zoho.bundle.action.ZohoBundleException;
import com.adventnet.zoho.bundle.action.ZohoBundleException.ErrorCode;
import com.zoho.abtest.adminconsole.AdminConsoleConstants;
import com.zoho.abtest.adminconsole.AdminConsoleWrapper;
import com.zoho.abtest.adminconsole.AdminConsoleConstants.AcOperationType;
import com.zoho.abtest.license.LicenseConstants;
import com.zoho.abtest.license.PortalLicenseMapping;
import com.zoho.abtest.license.LicenseConstants.License;
import com.zoho.abtest.listener.ZABNotifier;
import com.zoho.abtest.portal.Portal;
import com.zoho.abtest.portal.PortalAction;
import com.zoho.abtest.portal.PortalConstants;
import com.zoho.abtest.user.ProjectUserRole;
import com.zoho.abtest.user.ProjectUserRoleConstants;
import com.zoho.abtest.user.Role;
import com.zoho.abtest.user.ZABUser;
import com.zoho.abtest.user.ZABUserAction;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.abtest.zohoone.ZohoOneUtil;
import com.zoho.abtest.zohoone.ZohoOneUtil.ZohoOneProjectRoles;

public class CRMPlusUtil 
{
	private static final Logger LOGGER = Logger.getLogger(CRMPlusUtil.class.getName());
	
	public static boolean changeMemberStatus(Long zsoid, Long[] zuids, boolean enable,JSONObject params) throws ZohoBundleException
	{
		ZABUtil.setDBSpace(zsoid.toString());
		boolean success = false;
		/*
		//Check for the zohoone user license allowed count
		if(enable)
		{
			//TODO
			HashMap<String, String> zohooneHs = PortalLicenseMapping.getPortalZohoOneLicenseDetails(zsoid);
			if(zohooneHs.containsKey("planId"))
			{
				Long planId = Long.parseLong(zohooneHs.get("planId"));
				//TODO
				if(planId.equals(License.ZOHOONE.getStorePlanId()) && zohooneHs.containsKey("totalCount"))
				{
					int usersTobeAddedCount = zuids.length;
					if(usersTobeAddedCount > 0)
					{
						int alloweduserCount = Integer.parseInt(zohooneHs.get("totalCount"));
						int existingActiveUserCount = ZABUser.getActiveAppUsersCount();
						if(existingActiveUserCount+usersTobeAddedCount > alloweduserCount)
						{
							throw new ZohoBundleException(ErrorCode.MORE_THAN_ALLOWED_MEMBERS);
						}
					}
				}
			}
		}
		*/	
		try
		{
			if(zuids != null && zuids.length > 0)
			{
				success = ZABUserAction.changeMembersStatus(zsoid, zuids, enable);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			success = false;
		}
		return success;
	}
	
	public static boolean confirmInvitation(Long zsoid, long inviteeZUID, String emailId)
	{
		return ZohoOneUtil.confirmInvitation(zsoid, inviteeZUID, emailId);
	}
	
	public static Long createAccount(ZohoBundleAccount zAccount,List<ZohoBundleAccountMember> admins, List<ZohoBundleAccountMember> members,JSONObject params) throws ZohoBundleException
	{
		Long zsoid = null;
		try
		{
			ZohoBundleAccountMember createdUserObj = admins.get(0);
			Long createdZuid = createdUserObj.getZuid();
			User iamUser = new User();
			iamUser.setZUID(createdZuid);
			String portalName = zAccount.getDisplayName();
			String domainName = zAccount.getDomainName();
			
			//Check portal domain availability
			boolean isPortalExists = ZABServiceOrgUtil.isPortalExists(domainName);
			if(isPortalExists) 
			{
				throw new ZohoBundleException(ErrorCode.DOMAIN_ALREADY_EXIST);
			}
			//Add the service org
			zsoid = ZABServiceOrgUtil.addServiceOrg(portalName, createdZuid);
			if(zsoid != null)
			{
				//Add the domain
				ZABServiceOrgUtil.addDomain(domainName, zsoid);
				HashMap<String,String> hs = new HashMap<String,String>();
				hs.put(PortalConstants.ZSOID, zsoid.toString());
				hs.put(PortalConstants.DOMAINNAME, domainName);
				//Set it as default portal
				Portal.setDefaultPortal(hs, createdZuid);
				
				//Admin console record
				HashMap<String, String> acHs = new HashMap<String, String>();
				acHs.put(AdminConsoleConstants.ZSOID, zsoid.toString());
				acHs.put(AdminConsoleConstants.PORTAL_NAME, portalName);
				acHs.put(AdminConsoleConstants.PORTAL_DOMAIN, domainName);
				acHs.put(AdminConsoleConstants.CREATED_ZUID, createdZuid.toString());
				acHs.put(AdminConsoleConstants.CREATED_TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
				acHs.put(AdminConsoleConstants.IS_ZOHOONE, Boolean.TRUE.toString()); //Known
				AdminConsoleWrapper acWrapper = new AdminConsoleWrapper();
				acWrapper.setValueHs(acHs);
				acWrapper.setOperationType(AcOperationType.PORTAL_CREATE);
				ZABNotifier.notifyListeners(AdminConsoleConstants.ADMIN_CONSOLE_MODULE_NAME,acWrapper);
				
				ZABUtil.setPortaldomain(domainName);
				
				//Reserve dbspace and popuate values
				new PortalAction().dbSpaceCreation(iamUser, zsoid.toString(), null,"");
				
				//Once the portal is created - assign trial license for that portal
				Integer licenseTimespan = LicenseConstants.MONTH_DAYS_COUNT;
				Long startTime = ZABUtil.getCurrentTimeInMilliSeconds();
				Long endTime = ZABUtil.getNthServerDayInLong(startTime, licenseTimespan) - 1;
				//TODO - set zoho one license trial
				//PortalLicenseMapping.assignLicenseToPortal(License.TRIAL.getLicenseType(), zsoid, false,LicenseConstants.TRIAL_VISITOR_COUNT,null,startTime,endTime,null,null);
			
			}
		}
		catch(ZohoBundleException ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			throw ex;
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		return zsoid;
	}
			
	public static boolean deleteInvitation(Long zsoid, String emailId)
	{
		return ZohoOneUtil.deleteInvitation(zsoid, emailId);
	}
	
	public static boolean deleteMember(Long zsoid, Long zuid)
	{
		return ZohoOneUtil.deleteMember(zsoid, zuid);
	}
	
	public static boolean isDomainExists(String domainName, JSONObject params) throws ZohoBundleException
	{
		return ZohoOneUtil.isDomainExists(domainName, params);
	}
	
	public static boolean isInvitedMember(Long zsoid, String emailId)
	{
		return ZohoOneUtil.isInvitedMember(zsoid, emailId);
	}
	
	public static boolean isServiceAdmin(Long zsoid, Long zuid) throws ZohoBundleException
	{
		return ZohoOneUtil.isServiceAdmin(zsoid, zuid);
	}
	
	public static boolean updateAccount(Long zsoid, ZohoBundleAccount zAccount, JSONObject params)
			throws ZohoBundleException
	{
		String newPortalName = zAccount.getDisplayName();
		boolean success = false;
		try
		{
			success = ZABServiceOrgUtil.updateServiceOrg(zsoid, newPortalName);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		return success;
	}
	
	public static boolean changeOwner(Long zsoid, Long newOwnerZuid) 
	{
		return ZohoOneUtil.changeOwner(zsoid, newOwnerZuid);
	}
	
	public static boolean handleSubscriptionChange(Long zsoid, JSONArray changeArray,JSONObject params)
	{
		return ZohoOneUtil.handleSubscriptionChange(zsoid, changeArray, params);
	}
	
	public static boolean updateMembers(Long zsoid, List<ZohoBundleAccountMember> members,JSONObject params) throws ZohoBundleException 
	{
		ZABUtil.setDBSpace(zsoid.toString());
		boolean success = false;
		
		/*
		//Check for the zohoone user license allowed count
		//TODO
		HashMap<String, String> zohooneHs = PortalLicenseMapping.getPortalZohoOneLicenseDetails(zsoid);
		if(zohooneHs.containsKey("planId"))
		{
			Long planId = Long.parseLong(zohooneHs.get("planId"));
			//TODO
			if(planId.equals(License.ZOHOONE.getStorePlanId()) && zohooneHs.containsKey("totalCount"))
			{
				List<Long> updateZuids = new ArrayList<Long>();
				for(ZohoBundleAccountMember member:members)
				{
					updateZuids.add(member.getZuid());
				}
				Long[] updateZuidArr = updateZuids.toArray(new Long[updateZuids.size()]);
				int existingupdateZuidsCount = ZABUser.getExistingUsersCount(updateZuidArr);
				int usersTobeAddedCount = updateZuidArr.length - existingupdateZuidsCount;
				if(usersTobeAddedCount > 0)
				{
					int alloweduserCount = Integer.parseInt(zohooneHs.get("totalCount"));
					int existingActiveUserCount = ZABUser.getActiveAppUsersCount();
					if(existingActiveUserCount+usersTobeAddedCount > alloweduserCount)
					{
						throw new ZohoBundleException(ErrorCode.MORE_THAN_ALLOWED_MEMBERS);
					}
				}
			}
		}
		*/
		
		try
		{
			Long currentUserZuid = null;
			if(params != null && params.has("filter_currentuser"))
			{
				currentUserZuid = params.optLong("filter_currentuser"); // No I18N
			}
			List<Long> currentUserManagableProjectIds = null;
			if(currentUserZuid != null)
			{
				currentUserManagableProjectIds = ProjectUserRole.getUserManagableProjectIds(currentUserZuid);
			}
			if(members != null)
			{
				for(ZohoBundleAccountMember member:members)
				{
					Long zuid = member.getZuid();
					Long memberRoleId = member.getRoleId();
					boolean isMemberAdmin = (memberRoleId == 1) ? true : false;
					ZABUser appUserObj = ZABUser.getAppUserByZuid(zuid);
					Long appUserId = null;
					if(appUserObj != null && appUserObj.getUserId() != null)
					{
						appUserId = appUserObj.getUserId();
						if(!appUserObj.getIsActive())
						{
							ZABUser.makeUserActive(appUserId);
						}
					}
					else
					{
						appUserObj = ZABUser.createAppUser(zuid, isMemberAdmin);
						appUserId = appUserObj.getUserId();
						if(isMemberAdmin)
						{
							ProjectUserRole.makeAllProjectsAccessToAdmin(appUserId);
							int userPortalCount = Portal.getUserPortalsCount(zuid);
							ZABServiceOrgUtil.manageMemberRole(zsoid, zuid, UserRole.ADMIN);
							//If the invited user has no other portal, make this portal as Default
							if(userPortalCount == 0)
							{
								ZABServiceOrgUtil.setDefaultPortal(zsoid, zuid);
							}
							//Since Admin all project access will be given and no need to proceed further 
							continue;
						}
					}
					
					//Check if upgrade to admin or degrade to member 
					if(isMemberAdmin == appUserObj.getIsAdmin())
					{
						if(isMemberAdmin == true)
						{
							//Already admin
							continue;
						}
					}
					else
					{
						if(isMemberAdmin)
						{
							//Upgrade to admin
							ProjectUserRole.upgradeUserToAdmin(appUserId);
							int userPortalCount = Portal.getUserPortalsCount(zuid);
							ZABServiceOrgUtil.manageMemberRole(zsoid, zuid, UserRole.ADMIN);
							//If the invited user has no other portal, make this portal as Default
							if(userPortalCount == 0)
							{
								ZABServiceOrgUtil.setDefaultPortal(zsoid, zuid);
							}
							continue;
						}
						else
						{
							//Degrade to Member
							ZABUser.removeUserRoleFromAdmin(appUserId);
						}
					}
					
					//Remove projects that were assigned prev
					if(currentUserZuid != null)
					{
						if(currentUserManagableProjectIds.size() > 0)
						{
							ProjectUserRole.removeProjectUserRoleMapping(appUserId, currentUserManagableProjectIds);
						}
					}
					else
					{
						ProjectUserRole.removeAllProjectAccessFromUser(appUserId);
					}
					
					//Map projects
					JSONArray deptArr = member.getDepartments();
					if(deptArr != null && deptArr.length() > 0)
					{
						for(int i = 0; i < deptArr.length(); i++)
						{
							JSONObject deptObj = deptArr.getJSONObject(i);
							Long projectId = deptObj.getLong("department_id"); // No I18N
							Long roleId = deptObj.getLong("role_id"); // No I18N
							ZohoOneProjectRoles projectRole = ZohoOneProjectRoles.getProjectRoleByNumber(roleId.intValue());
							Long appRoleId = Role.getRoleIdByName(projectRole.getAppRoleName());
							
							if(currentUserZuid != null && !currentUserManagableProjectIds.contains(projectId))
							{
								continue;
							}
							
							boolean isAlreadyMapped = ProjectUserRole.isProjectUserRoleExists(projectId, appUserId);
							if(isAlreadyMapped)
							{
								ProjectUserRole.updateProjectUserRole(projectId, appUserId, appRoleId);
							}
							else
							{
								HashMap<String, String> projectUserRoleHs = new HashMap<String, String>();
								projectUserRoleHs.put(ProjectUserRoleConstants.PROJECT_ID, projectId.toString());
								projectUserRoleHs.put(ProjectUserRoleConstants.USER_ID, appUserId.toString());
								projectUserRoleHs.put(ProjectUserRoleConstants.ROLE_ID, appRoleId.toString());
								ProjectUserRole.createProjectUserRoleMapping(projectUserRoleHs);
							}
							
						}
					}
					
					//Update in Service Org also
					int userRole = UserRole.NORMAL;
					if(isMemberAdmin)
					{
						userRole = UserRole.ADMIN;
					}
					else
					{
						boolean isProjOwner = ProjectUserRole.isUseraProjectOwner(appUserId);
						if(isProjOwner)
						{
							userRole = UserRole.MODERATOR;
						}
					}
					int userPortalCount = Portal.getUserPortalsCount(zuid);
					ZABServiceOrgUtil.manageMemberRole(zsoid, zuid, userRole);
					//If the invited user has no other portal, make this portal as Default
					if(userPortalCount == 0)
					{
						ZABServiceOrgUtil.setDefaultPortal(zsoid, zuid);
					}
				}
			}
			success = true;
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			success = false;
		}
		return success;
	}
	
	public static boolean updatePendingMember(Long zsoid, String firstName, String lastName,String emailId, ZohoBundleAccountMember member, JSONObject params) throws ZohoBundleException
	{
		ZABUtil.setDBSpace(zsoid.toString());
		boolean success = false;
		/*
		//Check for the zohoone user license allowed count
		//TODO
		HashMap<String, String> zohooneHs = PortalLicenseMapping.getPortalZohoOneLicenseDetails(zsoid);
		if(zohooneHs.containsKey("planId"))
		{
			Long planId = Long.parseLong(zohooneHs.get("planId"));
			if(planId.equals(License.ZOHOONE.getStorePlanId()) && zohooneHs.containsKey("totalCount"))
			{
				ZABUser appUserObj = ZABUser.getAppUserByEmail(emailId);
				if(appUserObj == null || !appUserObj.getIsActive())
				{
					int alloweduserCount = Integer.parseInt(zohooneHs.get("totalCount"));
					int existingActiveUserCount = ZABUser.getActiveAppUsersCount();
					if(existingActiveUserCount+1 > alloweduserCount)
					{
						throw new ZohoBundleException(ErrorCode.MORE_THAN_ALLOWED_MEMBERS);
					}
				}
			}
		}
		*/
		try
		{
			Long currentUserZuid = null;
			if(params != null && params.has("filter_currentuser"))
			{
				currentUserZuid = params.optLong("filter_currentuser"); // No I18N
			}
			List<Long> currentUserManagableProjectIds = null;
			if(currentUserZuid != null)
			{
				currentUserManagableProjectIds = ProjectUserRole.getUserManagableProjectIds(currentUserZuid);
			}
			if(member != null)
			{
				Long memberRoleId = member.getRoleId();
				boolean isMemberAdmin = (memberRoleId == 1) ? true : false;
				ZABUser appUserObj = ZABUser.getAppUserByEmail(emailId);
				Long appUserId = null;
				if(appUserObj != null && appUserObj.getUserId() != null)
				{
					appUserId = appUserObj.getUserId();
					if(!appUserObj.getIsActive())
					{
						ZABUser.makeUserActive(appUserId);
					}
				}
				else
				{
					appUserId = ZABUser.createUser(emailId,isMemberAdmin);
					appUserObj = ZABUser.getAppUserByEmail(emailId);
					if(isMemberAdmin)
					{
						ProjectUserRole.makeAllProjectsAccessToAdmin(appUserId);
						//Since Admin all project access will be given and no need to proceed further 
						success = true;
						return success;
					}
				}
				
				//Check if upgrade to admin or degrade to member 
				if(isMemberAdmin == appUserObj.getIsAdmin())
				{
					if(isMemberAdmin == true)
					{
						//Already admin
						success = true;
						return success;
					}
				}
				else
				{
					if(isMemberAdmin)
					{
						//Upgrade to admin
						ProjectUserRole.upgradeUserToAdmin(appUserId);
						success = true;
						return success;
					}
					else
					{
						//Degrade to Member
						ZABUser.removeUserRoleFromAdmin(appUserId);
					}
				}
				
				//Remove projects that were assigned prev
				if(currentUserZuid != null)
				{
					if(currentUserManagableProjectIds.size() > 0)
					{
						ProjectUserRole.removeProjectUserRoleMapping(appUserId, currentUserManagableProjectIds);
					}
				}
				else
				{
					ProjectUserRole.removeAllProjectAccessFromUser(appUserId);
				}
				
				//Map projects
				JSONArray deptArr = member.getDepartments();
				if(deptArr != null && deptArr.length() > 0)
				{
					for(int i = 0; i < deptArr.length(); i++)
					{
						JSONObject deptObj = deptArr.getJSONObject(i);
						Long projectId = deptObj.getLong("department_id"); // No I18N
						Long roleId = deptObj.getLong("role_id"); // No I18N
						ZohoOneProjectRoles projectRole = ZohoOneProjectRoles.getProjectRoleByNumber(roleId.intValue());
						Long appRoleId = Role.getRoleIdByName(projectRole.getAppRoleName());
						
						if(currentUserZuid != null && !currentUserManagableProjectIds.contains(projectId))
						{
							continue;
						}
						
						boolean isAlreadyMapped = ProjectUserRole.isProjectUserRoleExists(projectId, appUserId);
						if(isAlreadyMapped)
						{
							ProjectUserRole.updateProjectUserRole(projectId, appUserId, appRoleId);
						}
						else
						{
							HashMap<String, String> projectUserRoleHs = new HashMap<String, String>();
							projectUserRoleHs.put(ProjectUserRoleConstants.PROJECT_ID, projectId.toString());
							projectUserRoleHs.put(ProjectUserRoleConstants.USER_ID, appUserId.toString());
							projectUserRoleHs.put(ProjectUserRoleConstants.ROLE_ID, appRoleId.toString());
							ProjectUserRole.createProjectUserRoleMapping(projectUserRoleHs);
						}
						
					}
				}
			}
			success = true;
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			success = false;
		}
		return success;
	}
	
	public static JSONObject getAccountInfo(Long zsoid, String action, JSONObject params)
	{
		return ZohoOneUtil.getAccountInfo(zsoid, action, params);
	}
	
	public static List<JSONObject> getMembersInfo(Long zsoid, String action, JSONObject params, Long[] zuids)
	{
		return ZohoOneUtil.getMembersInfo(zsoid, action, params, zuids);
	}
	
	public static List<JSONObject> getMembersInfo(Long zsoid, String action, JSONObject params, String[] emailIds)
	{
		return ZohoOneUtil.getMembersInfo(zsoid, action, params, emailIds);
	}
	
	public static boolean changeInvitationStatus(Long zsoid, String[] emailIds, boolean enable) throws ZohoBundleException 
	{
		ZABUtil.setDBSpace(zsoid.toString());
		boolean success = false;
		/*
		//Check for the zohoone user license allowed count
		if(enable)
		{
			//TODO
			HashMap<String, String> zohooneHs = PortalLicenseMapping.getPortalZohoOneLicenseDetails(zsoid);
			if(zohooneHs.containsKey("planId"))
			{
				Long planId = Long.parseLong(zohooneHs.get("planId"));
				//TODO
				if(planId.equals(License.ZOHOONE.getStorePlanId()) && zohooneHs.containsKey("totalCount"))
				{
					int usersTobeAddedCount = emailIds.length;
					if(usersTobeAddedCount > 0)
					{
						int alloweduserCount = Integer.parseInt(zohooneHs.get("totalCount"));
						int existingActiveUserCount = ZABUser.getActiveAppUsersCount();
						if(existingActiveUserCount+usersTobeAddedCount > alloweduserCount)
						{
							throw new ZohoBundleException(ErrorCode.MORE_THAN_ALLOWED_MEMBERS);
						}
					}
				}
			}
		}
		*/
		try
		{
			success = ZABUserAction.changeInvitationStatus(zsoid, emailIds, enable);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			success = false;
		}
		return success;
	}
}
