//$Id$
package com.zoho.abtest.datamigration;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.sas.ds.SASThreadLocal;
import com.adventnet.sas.upgrade.isu.UpgradeHandler;
import com.zoho.abtest.sessionrecording.SessionPageResources;
import com.zoho.abtest.utility.ZABUtil;

public class SessionPageResourceMigrationHandler extends UpgradeHandler 
{
	private static final Logger LOGGER = Logger.getLogger(SessionPageResourceMigrationHandler.class.getName());
	
	public void handleTableUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into handleTableUpdates :" + oldVersion + ":" + isReverting);
	}
	
	public void handleCustomerDataUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
//		ZABUtil.setIsSchedulerJob(Boolean.TRUE);
		try
		{
			String dbSpaceName = SASThreadLocal.getLoginName();
			ZABUtil.setDBSpace(dbSpaceName);
			SessionPageResources.migrateFromPostgresToElastic(dbSpaceName);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in handleCustomerDataUpdates : "+ex.getMessage(), ex);
		}
		LOGGER.log(Level.INFO, "Completed handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
	}
	
}
