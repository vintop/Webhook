//$Id$
package com.zoho.abtest.datamigration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;

import com.adventnet.db.api.RelationalAPI;
import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.mfw.bean.BeanUtil;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.sas.ds.SASThreadLocal;
import com.adventnet.sas.upgrade.isu.UpgradeHandler;
import com.zoho.abtest.RAW_DATA_TABLE_DETAILS;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.report.RawDataTableDetails;
import com.zoho.abtest.report.ReportArchieveDimensionConstants.ReportModuleType;
import com.zoho.abtest.utility.ZABTableCreationBean;
import com.zoho.abtest.utility.ZABUtil;

public class ConstraintReferenceUpgradeHandler extends UpgradeHandler
{
	private static final Logger LOGGER = Logger.getLogger(ConstraintReferenceUpgradeHandler.class.getName());
	
	public void handleTableUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into handleTableUpdates :" + oldVersion + ":" + isReverting);
	}
	
	public void handleCustomerDataUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		ZABUtil.setIsSchedulerJob(Boolean.TRUE);
		try
		{
			LOGGER.log(Level.INFO, "Entered into handleCustomerDataUpdates :" + oldVersion + ":" + isReverting + ":" + SASThreadLocal.getLoginName());
			removeUnusedRawTables();
			updateCurrentRawTables();
			
			deleteCurrentDynamicTable();
			
			String dbspaceId = SASThreadLocal.getLoginName();
			if(StringUtils.isNotEmpty(dbspaceId))
			{
				ZABTableCreationBean userAction = (ZABTableCreationBean)BeanUtil.lookup("ZABTableCreationBean");
				userAction.createCombinationJsonTables(dbspaceId);
				userAction.createReportArchiveVisitorIdsTables(dbspaceId);
			}
			
			deleteUnusedVisitorTables();
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in handleCustomerDataUpdates : "+ex.getMessage(), ex);
		}
		LOGGER.log(Level.INFO, "Completed handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
	}
	
	public void deleteUnusedVisitorTables()
	{
		String tablename = "VISITOR_REPORT_HOUR_VISITORS";
		droptable(tablename);
		
		tablename = "GOAL_REPORT_HOUR_VISITORS";
		droptable(tablename);
		
		tablename = "VISITOR_DIMENSION_HOUR_VISITORS";
		droptable(tablename);
		
		tablename = "GOAL_DIMENSION_HOUR_VISITORS";
		droptable(tablename);
		
		tablename = "BROWSER_VISIT_HOUR_VISITORS";
		droptable(tablename);
		
		tablename = "DEVICE_VISIT_HOUR_VISITORS";
		droptable(tablename);
		tablename = "COUNTRY_VISIT_HOUR_VISITORS";
		droptable(tablename);
		tablename = "LANG_VISIT_HOUR_VISITORS";
		droptable(tablename);
		tablename = "OS_VISIT_HOUR_VISITORS";
		droptable(tablename);
		tablename = "TRAFSOUR_VISIT_HOUR_VISITORS";
		droptable(tablename);
		tablename = "REFURL_VISIT_HOUR_VISITORS";
		droptable(tablename);
		tablename = "DAYOFWK_VISIT_HOUR_VISITORS";
		droptable(tablename);
		tablename = "HOURODY_VISIT_HOUR_VISITORS";
		droptable(tablename);
		tablename = "COOKIE_VISIT_HOUR_VISITORS";
		droptable(tablename);
		tablename = "URLPARM_VISIT_HOUR_VISITORS";
		droptable(tablename);
		tablename = "JSVAR_VISIT_HOUR_VISITORS";
		droptable(tablename);
		tablename = "CUSTDIM_VISIT_HOUR_VISITORS";
		droptable(tablename);
		
		

		tablename = "BROWSER_GOAL_HOUR_VISITORS";
		droptable(tablename);
		tablename = "DEVICE_GOAL_HOUR_VISITORS";
		droptable(tablename);
		tablename = "COUNTRY_GOAL_HOUR_VISITORS";
		droptable(tablename);
		tablename = "LANG_GOAL_HOUR_VISITORS";
		droptable(tablename);
		tablename = "OS_GOAL_HOUR_VISITORS";
		droptable(tablename);
		tablename = "TRAFSOUR_GOAL_HOUR_VISITORS";
		droptable(tablename);
		tablename = "REFURL_GOAL_HOUR_VISITORS";
		droptable(tablename);
		tablename = "DAYOFWK_GOAL_HOUR_VISITORS";
		droptable(tablename);
		tablename = "HOURODY_GOAL_HOUR_VISITORS";
		droptable(tablename);
		tablename = "COOKIE_GOAL_HOUR_VISITORS";
		droptable(tablename);
		tablename = "URLPARM_GOAL_HOUR_VISITORS";
		droptable(tablename);
		tablename = "JSVAR_GOAL_HOUR_VISITORS";
		droptable(tablename);
		tablename = "CUSTDIM_GOAL_HOUR_VISITORS";
		droptable(tablename);
		
		
		tablename = "REVENUE_REPORT_HOUR_VISITORS";
		droptable(tablename);
		tablename = "REVENUE_DIMENSION_HOUR_VISITORS";
		droptable(tablename);
		
		
		tablename = "JSVAR_COMBINATION_VISIT_HOUR";
		droptable(tablename);
		tablename = "URLPARAM_COMBINATION_VISIT_HOUR";
		droptable(tablename);
		tablename = "COOKIE_COMBINATION_VISIT_HOUR";
		droptable(tablename);
		tablename = "CUSTOMDIMEN_COMBINATION_VISIT_HOUR";
		droptable(tablename);
		
		tablename = "JSVAR_COMBINATION_GOAL_HOUR";
		droptable(tablename);
		tablename = "URLPARAM_COMBINATION_GOAL_HOUR";
		droptable(tablename);
		tablename = "COOKIE_COMBINATION_GOAL_HOUR";
		droptable(tablename);
		tablename = "CUSTOMDIMEN_COMBINATION_GOAL_HOUR";
		droptable(tablename);
		
	}
	
	public void droptable(String tableName)
	{
		String query = "DROP TABLE IF EXISTS " + tableName ; // No I18N
		executeQuery(query);
	}
	
	public void deleteCurrentDynamicTable()
	{
		try
		{
			String dbspaceId = SASThreadLocal.getLoginName();
				String tablename = "VISITOR_REPORT_HOUR_VISITORS_"+dbspaceId;
				droptable(tablename);
				
				tablename = "GOAL_REPORT_HOUR_VISITORS_"+dbspaceId;
				droptable(tablename);
				
				tablename = "VISITOR_DIMENSION_HOUR_VISITORS_"+dbspaceId;
				droptable(tablename);
				
				tablename = "GOAL_DIMENSION_HOUR_VISITORS_"+dbspaceId;
				droptable(tablename);
				
				tablename = "BROWSER_VISIT_HOUR_VISITORS_"+dbspaceId;
				droptable(tablename);
				
				tablename = "DEVICE_VISIT_HOUR_VISITORS_"+dbspaceId;
				droptable(tablename);
				tablename = "COUNTRY_VISIT_HOUR_VISITORS_"+dbspaceId;
				droptable(tablename);
				tablename = "LANG_VISIT_HOUR_VISITORS_"+dbspaceId;
				droptable(tablename);
				tablename = "OS_VISIT_HOUR_VISITORS_"+dbspaceId;
				droptable(tablename);
				tablename = "TRAFSOUR_VISIT_HOUR_VISITORS_"+dbspaceId;
				droptable(tablename);
				tablename = "REFURL_VISIT_HOUR_VISITORS_"+dbspaceId;
				droptable(tablename);
				tablename = "DAYOFWK_VISIT_HOUR_VISITORS_"+dbspaceId;
				droptable(tablename);
				tablename = "HOURODY_VISIT_HOUR_VISITORS_"+dbspaceId;
				droptable(tablename);
				tablename = "COOKIE_VISIT_HOUR_VISITORS_"+dbspaceId;
				droptable(tablename);
				tablename = "URLPARM_VISIT_HOUR_VISITORS_"+dbspaceId;
				droptable(tablename);
				tablename = "JSVAR_VISIT_HOUR_VISITORS_"+dbspaceId;
				droptable(tablename);
				tablename = "CUSTDIM_VISIT_HOUR_VISITORS_"+dbspaceId;
				droptable(tablename);
				
				

				tablename = "BROWSER_GOAL_HOUR_VISITORS_"+dbspaceId;
				droptable(tablename);
				tablename = "DEVICE_GOAL_HOUR_VISITORS_"+dbspaceId;
				droptable(tablename);
				tablename = "COUNTRY_GOAL_HOUR_VISITORS_"+dbspaceId;
				droptable(tablename);
				tablename = "LANG_GOAL_HOUR_VISITORS_"+dbspaceId;
				droptable(tablename);
				tablename = "OS_GOAL_HOUR_VISITORS_"+dbspaceId;
				droptable(tablename);
				tablename = "TRAFSOUR_GOAL_HOUR_VISITORS_"+dbspaceId;
				droptable(tablename);
				tablename = "REFURL_GOAL_HOUR_VISITORS_"+dbspaceId;
				droptable(tablename);
				tablename = "DAYOFWK_GOAL_HOUR_VISITORS_"+dbspaceId;
				droptable(tablename);
				tablename = "HOURODY_GOAL_HOUR_VISITORS_"+dbspaceId;
				droptable(tablename);
				tablename = "COOKIE_GOAL_HOUR_VISITORS_"+dbspaceId;
				droptable(tablename);
				tablename = "URLPARM_GOAL_HOUR_VISITORS_"+dbspaceId;
				droptable(tablename);
				tablename = "JSVAR_GOAL_HOUR_VISITORS_"+dbspaceId;
				droptable(tablename);
				tablename = "CUSTDIM_GOAL_HOUR_VISITORS_"+dbspaceId;
				droptable(tablename);
				
				
				tablename = "REVENUE_REPORT_HOUR_VISITORS_"+dbspaceId;
				droptable(tablename);
				tablename = "REVENUE_DIMENSION_HOUR_VISITORS_"+dbspaceId;
				droptable(tablename);
				
				
				tablename = "JSVAR_COMBINATION_VISIT_HOUR_"+dbspaceId;
				droptable(tablename);
				tablename = "URLPARAM_COMBINATION_VISIT_HOUR_"+dbspaceId;
				droptable(tablename);
				tablename = "COOKIE_COMBINATION_VISIT_HOUR_"+dbspaceId;
				droptable(tablename);
				tablename = "CUSTOMDIMEN_COMBINATION_VISIT_HOUR_"+dbspaceId;
				droptable(tablename);
				
				tablename = "JSVAR_COMBINATION_GOAL_HOUR_"+dbspaceId;
				droptable(tablename);
				tablename = "URLPARAM_COMBINATION_GOAL_HOUR_"+dbspaceId;
				droptable(tablename);
				tablename = "COOKIE_COMBINATION_GOAL_HOUR_"+dbspaceId;
				droptable(tablename);
				tablename = "CUSTOMDIMEN_COMBINATION_GOAL_HOUR_"+dbspaceId;
				droptable(tablename);
				
				
			
				
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in updateCurrentDynamicTable: "+ex.getMessage(), ex);
		}
	}
	
	public void updateCurrentRawTables()
	{
		try
		{
			Criteria criteria1 = new Criteria(new Column(RAW_DATA_TABLE_DETAILS.TABLE,RAW_DATA_TABLE_DETAILS.IS_ACTIVE), Boolean.TRUE, QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(RAW_DATA_TABLE_DETAILS.TABLE, criteria1);
			Iterator<?> iterator = dataObj.getRows(RAW_DATA_TABLE_DETAILS.TABLE);
			while(iterator.hasNext())
			{
				Row row = (Row) iterator.next();
				String rawTableName = (String)row.get(RAW_DATA_TABLE_DETAILS.RAW_TABLE_NAME);
				Integer moduleType = (Integer)row.get(RAW_DATA_TABLE_DETAILS.MODULE_TYPE);
				if(ReportModuleType.VISIT.getModuleCode().equals(moduleType))
				{
					String expconstraintName = rawTableName + "_EXPERIMENT_ID_FKEY";
					String dropQuery = "ALTER TABLE "+rawTableName+ " DROP CONSTRAINT "+ expconstraintName;
					String alterQuery = "ALTER TABLE "+rawTableName+ " ADD CONSTRAINT "+ expconstraintName + " FOREIGN KEY (EXPERIMENT_ID)  REFERENCES EXPERIMENT(EXPERIMENT_ID) ON DELETE CASCADE ";
					executeQuery(dropQuery);
					executeQuery(alterQuery);
					
					String varconstraintName = rawTableName + "_VARIATION_ID_FKEY";
					dropQuery = "ALTER TABLE "+rawTableName+ " DROP CONSTRAINT "+ varconstraintName;
					alterQuery = "ALTER TABLE "+rawTableName+ " ADD CONSTRAINT "+ varconstraintName + " FOREIGN KEY (VARIATION_ID)  REFERENCES VARIATION(VARIATION_ID) ON DELETE CASCADE ";
					executeQuery(dropQuery);
					executeQuery(alterQuery);
					
					String visitorconstraintName = rawTableName + "_VISITOR_ID_FKEY";
					dropQuery = "ALTER TABLE "+rawTableName+ " DROP CONSTRAINT "+ visitorconstraintName;
					alterQuery = "ALTER TABLE "+rawTableName+ " ADD CONSTRAINT "+ visitorconstraintName + " FOREIGN KEY (VISITOR_ID)  REFERENCES VISITOR_DETAIL(VISITOR_ID) ON DELETE CASCADE ";
					executeQuery(dropQuery);
					executeQuery(alterQuery);
				}
				else if(ReportModuleType.GOALACHIEVED.getModuleCode().equals(moduleType))
				{
					String expconstraintName = rawTableName + "_EXPERIMENT_ID_FKEY";
					String dropQuery = "ALTER TABLE "+rawTableName+ " DROP CONSTRAINT "+ expconstraintName;
					String alterQuery = "ALTER TABLE "+rawTableName+ " ADD CONSTRAINT "+ expconstraintName + " FOREIGN KEY (EXPERIMENT_ID)  REFERENCES EXPERIMENT(EXPERIMENT_ID) ON DELETE CASCADE ";
					executeQuery(dropQuery);
					executeQuery(alterQuery);
					
					String varconstraintName = rawTableName + "_VARIATION_ID_FKEY";
					dropQuery = "ALTER TABLE "+rawTableName+ " DROP CONSTRAINT "+ varconstraintName;
					alterQuery = "ALTER TABLE "+rawTableName+ " ADD CONSTRAINT "+ varconstraintName + " FOREIGN KEY (VARIATION_ID)  REFERENCES VARIATION(VARIATION_ID) ON DELETE CASCADE ";
					executeQuery(dropQuery);
					executeQuery(alterQuery);
					
					String visitorconstraintName = rawTableName + "_VISITOR_ID_FKEY";
					dropQuery = "ALTER TABLE "+rawTableName+ " DROP CONSTRAINT "+ visitorconstraintName;
					alterQuery = "ALTER TABLE "+rawTableName+ " ADD CONSTRAINT "+ visitorconstraintName + " FOREIGN KEY (VISITOR_ID)  REFERENCES VISITOR_DETAIL(VISITOR_ID) ON DELETE CASCADE ";
					executeQuery(dropQuery);
					executeQuery(alterQuery);
					
					String goalconstraintName = rawTableName + "_GOAL_ID_FKEY";
					dropQuery = "ALTER TABLE "+rawTableName+ " DROP CONSTRAINT "+ goalconstraintName;
					alterQuery = "ALTER TABLE "+rawTableName+ " ADD CONSTRAINT "+ goalconstraintName + " FOREIGN KEY (GOAL_ID)  REFERENCES GOAL(GOAL_ID) ON DELETE CASCADE ";
					executeQuery(dropQuery);
					executeQuery(alterQuery);
					
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in updateCurrentRawTables : "+ex.getMessage(), ex);
		}
	}
	
	public void removeUnusedRawTables()
	{
		try
		{
			Criteria criteria1 = new Criteria(new Column(RAW_DATA_TABLE_DETAILS.TABLE,RAW_DATA_TABLE_DETAILS.IS_ACTIVE), Boolean.FALSE, QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(RAW_DATA_TABLE_DETAILS.TABLE, criteria1);
			Iterator<?> iterator = dataObj.getRows(RAW_DATA_TABLE_DETAILS.TABLE);
			
			while(iterator.hasNext())
			{
				Row row = (Row) iterator.next();
				String rawTableName = (String)row.get(RAW_DATA_TABLE_DETAILS.RAW_TABLE_NAME);
				String query = "DROP TABLE IF EXISTS " + rawTableName ; // No I18N
				executeQuery(query);
				RawDataTableDetails.deleteUnusedRawtableDetails(rawTableName);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in removeUnusedRawTables : "+ex.getMessage(), ex);
		}
	}
	
	public void executeQuery(String query)
	{
		Connection conn = null;
		PreparedStatement stmt = null;
		try
		{
			LOGGER.log(Level.INFO,SASThreadLocal.getLoginName()+" Query execute started:" +query);
			RelationalAPI relapi = RelationalAPI.getInstance();
			conn = relapi.getConnection();
			stmt = conn.prepareStatement(query);
			stmt.execute();
			LOGGER.log(Level.INFO,SASThreadLocal.getLoginName()+" Query executed successfully:" +query);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
			LOGGER.log(Level.SEVERE,"Query execution failed:" +query);
		}
		finally
		{
			if (stmt != null)
			{
				try 
				{
					stmt.close();
				} catch (SQLException e) 
				{
					LOGGER.log(Level.SEVERE,e.getMessage(),e);
				}
			}
			if(conn!=null){
				try 
				{
					conn.close();
				} catch (SQLException e)
				{
					LOGGER.log(Level.SEVERE,e.getMessage(),e);
				}
			}
		}
	}
	
	/*public void updateCurrentDynamicTable0()
	{
		try
		{
			String dbspaceId = SASThreadLocal.getLoginName();
			if(StringUtils.isNotEmpty(dbspaceId))
			{
				String tablename = "VISITOR_REPORT_HOUR_VISITORS_"+dbspaceId;
				String constarintname = tablename + "_HOUR_ID_FKEY";
				String referenceValue = "VISITOR_REPORT_HOUR(VISITOR_REPORT_HOUR_ID)";
				String dropQuery = "ALTER TABLE "+tablename+ " DROP CONSTRAINT "+ constarintname;
				String alterQuery = "ALTER TABLE "+tablename+ " ADD CONSTRAINT "+ constarintname + " FOREIGN KEY (HOUR_ID)  REFERENCES "+referenceValue+" ON DELETE CASCADE ";
				executeQuery(dropQuery);
				executeQuery(alterQuery);
				
				tablename = "GOAL_REPORT_HOUR_VISITORS_"+dbspaceId;
				constarintname = tablename + "_HOUR_ID_FKEY";
				referenceValue = "GOAL_REPORT_HOUR(GOAL_REPORT_HOUR_ID)";
				dropQuery = "ALTER TABLE "+tablename+ " DROP CONSTRAINT "+ constarintname;
				alterQuery = "ALTER TABLE "+tablename+ " ADD CONSTRAINT "+ constarintname + " FOREIGN KEY (HOUR_ID)  REFERENCES "+referenceValue+" ON DELETE CASCADE ";
				executeQuery(dropQuery);
				executeQuery(alterQuery);
				
				tablename = "VISITOR_DIMENSION_HOUR_VISITORS_"+dbspaceId;
				constarintname = tablename + "_HOUR_ID_FKEY";
				referenceValue = "VISITOR_DIMENSION_HOUR(VISITOR_DIMENSION_HOUR_ID)";
				dropQuery = "ALTER TABLE "+tablename+ " DROP CONSTRAINT "+ constarintname;
				alterQuery = "ALTER TABLE "+tablename+ " ADD CONSTRAINT "+ constarintname + " FOREIGN KEY (HOUR_ID)  REFERENCES "+referenceValue+" ON DELETE CASCADE ";
				executeQuery(dropQuery);
				executeQuery(alterQuery);
				
				tablename = "GOAL_DIMENSION_HOUR_VISITORS_"+dbspaceId;
				constarintname = tablename + "_HOUR_ID_FKEY";
				referenceValue = "GOAL_DIMENSION_HOUR(GOAL_DIMENSION_HOUR_ID)";
				dropQuery = "ALTER TABLE "+tablename+ " DROP CONSTRAINT "+ constarintname;
				alterQuery = "ALTER TABLE "+tablename+ " ADD CONSTRAINT "+ constarintname + " FOREIGN KEY (HOUR_ID)  REFERENCES "+referenceValue+" ON DELETE CASCADE ";
				executeQuery(dropQuery);
				executeQuery(alterQuery);
				
				tablename = "BROWSER_VISIT_HOUR_VISITORS_"+dbspaceId;
				constarintname = tablename + "_HOUR_ID_FKEY";
				referenceValue = "BROWSER_VISIT_REPORT_HOUR(BROWSER_VISIT_REPORT_HOUR_ID)";
				dropQuery = "ALTER TABLE "+tablename+ " DROP CONSTRAINT "+ constarintname;
				alterQuery = "ALTER TABLE "+tablename+ " ADD CONSTRAINT "+ constarintname + " FOREIGN KEY (HOUR_ID)  REFERENCES "+referenceValue+" ON DELETE CASCADE ";
				executeQuery(dropQuery);
				executeQuery(alterQuery);
				
				tablename = "DEVICE_VISIT_HOUR_VISITORS_"+dbspaceId;
				constarintname = tablename + "_HOUR_ID_FKEY";
				referenceValue = "DEVICE_VISIT_REPORT_HOUR(DEVICE_VISIT_REPORT_HOUR_ID)";
				dropQuery = "ALTER TABLE "+tablename+ " DROP CONSTRAINT "+ constarintname;
				alterQuery = "ALTER TABLE "+tablename+ " ADD CONSTRAINT "+ constarintname + " FOREIGN KEY (HOUR_ID)  REFERENCES "+referenceValue+" ON DELETE CASCADE ";
				executeQuery(dropQuery);
				executeQuery(alterQuery);
				
				tablename = "COUNTRY_VISIT_HOUR_VISITORS_"+dbspaceId;
				constarintname = tablename + "_HOUR_ID_FKEY";
				referenceValue = "COUNTRY_VISIT_REPORT_HOUR(COUNTRY_VISIT_REPORT_HOUR_ID)";
				dropQuery = "ALTER TABLE "+tablename+ " DROP CONSTRAINT "+ constarintname;
				alterQuery = "ALTER TABLE "+tablename+ " ADD CONSTRAINT "+ constarintname + " FOREIGN KEY (HOUR_ID)  REFERENCES "+referenceValue+" ON DELETE CASCADE ";
				executeQuery(dropQuery);
				executeQuery(alterQuery);
				
				tablename = "LANG_VISIT_HOUR_VISITORS_"+dbspaceId;
				constarintname = tablename + "_HOUR_ID_FKEY";
				referenceValue = "LANG_VISIT_REPORT_HOUR(LANG_VISIT_REPORT_HOUR_ID)";
				dropQuery = "ALTER TABLE "+tablename+ " DROP CONSTRAINT "+ constarintname;
				alterQuery = "ALTER TABLE "+tablename+ " ADD CONSTRAINT "+ constarintname + " FOREIGN KEY (HOUR_ID)  REFERENCES "+referenceValue+" ON DELETE CASCADE ";
				executeQuery(dropQuery);
				executeQuery(alterQuery);
				
				tablename = "OS_VISIT_HOUR_VISITORS_"+dbspaceId;
				constarintname = tablename + "_HOUR_ID_FKEY";
				referenceValue = "OS_VISIT_REPORT_HOUR(OS_VISIT_REPORT_HOUR_ID)";
				dropQuery = "ALTER TABLE "+tablename+ " DROP CONSTRAINT "+ constarintname;
				alterQuery = "ALTER TABLE "+tablename+ " ADD CONSTRAINT "+ constarintname + " FOREIGN KEY (HOUR_ID)  REFERENCES "+referenceValue+" ON DELETE CASCADE ";
				executeQuery(dropQuery);
				executeQuery(alterQuery);
				
				tablename = "TRAFSOUR_VISIT_HOUR_VISITORS_"+dbspaceId;
				constarintname = tablename + "_HOUR_ID_FKEY";
				referenceValue = "TRAFSOUR_VISIT_REPORT_HOUR(TRAFSOUR_VISIT_REPORT_HOUR_ID)";
				dropQuery = "ALTER TABLE "+tablename+ " DROP CONSTRAINT "+ constarintname;
				alterQuery = "ALTER TABLE "+tablename+ " ADD CONSTRAINT "+ constarintname + " FOREIGN KEY (HOUR_ID)  REFERENCES "+referenceValue+" ON DELETE CASCADE ";
				executeQuery(dropQuery);
				executeQuery(alterQuery);
				
				tablename = "REFURL_VISIT_HOUR_VISITORS_"+dbspaceId;
				constarintname = tablename + "_HOUR_ID_FKEY";
				referenceValue = "REFURL_VISIT_REPORT_HOUR(REFURL_VISIT_REPORT_HOUR_ID)";
				dropQuery = "ALTER TABLE "+tablename+ " DROP CONSTRAINT "+ constarintname;
				alterQuery = "ALTER TABLE "+tablename+ " ADD CONSTRAINT "+ constarintname + " FOREIGN KEY (HOUR_ID)  REFERENCES "+referenceValue+" ON DELETE CASCADE ";
				executeQuery(dropQuery);
				executeQuery(alterQuery);
				
				tablename = "DAYOFWK_VISIT_HOUR_VISITORS_"+dbspaceId;
				constarintname = tablename + "_HOUR_ID_FKEY";
				referenceValue = "DAYOFWK_VISIT_REPORT_HOUR(DAYOFWK_VISIT_REPORT_HOUR_ID)";
				dropQuery = "ALTER TABLE "+tablename+ " DROP CONSTRAINT "+ constarintname;
				alterQuery = "ALTER TABLE "+tablename+ " ADD CONSTRAINT "+ constarintname + " FOREIGN KEY (HOUR_ID)  REFERENCES "+referenceValue+" ON DELETE CASCADE ";
				executeQuery(dropQuery);
				executeQuery(alterQuery);
				
				tablename = "HOURODY_VISIT_HOUR_VISITORS_"+dbspaceId;
				constarintname = tablename + "_HOUR_ID_FKEY";
				referenceValue = "HOURODY_VISIT_REPORT_HOUR(HOURODY_VISIT_REPORT_HOUR_ID)";
				dropQuery = "ALTER TABLE "+tablename+ " DROP CONSTRAINT "+ constarintname;
				alterQuery = "ALTER TABLE "+tablename+ " ADD CONSTRAINT "+ constarintname + " FOREIGN KEY (HOUR_ID)  REFERENCES "+referenceValue+" ON DELETE CASCADE ";
				executeQuery(dropQuery);
				executeQuery(alterQuery);
				
				tablename = "COOKIE_VISIT_HOUR_VISITORS_"+dbspaceId;
				constarintname = tablename + "_HOUR_ID_FKEY";
				referenceValue = "COOKIE_VISIT_REPORT_HOUR(COOKIE_VISIT_REPORT_HOUR_ID)";
				dropQuery = "ALTER TABLE "+tablename+ " DROP CONSTRAINT "+ constarintname;
				alterQuery = "ALTER TABLE "+tablename+ " ADD CONSTRAINT "+ constarintname + " FOREIGN KEY (HOUR_ID)  REFERENCES "+referenceValue+" ON DELETE CASCADE ";
				executeQuery(dropQuery);
				executeQuery(alterQuery);
				
				tablename = "URLPARM_VISIT_HOUR_VISITORS_"+dbspaceId;
				constarintname = tablename + "_HOUR_ID_FKEY";
				referenceValue = "URLPARM_VISIT_REPORT_HOUR(URLPARM_VISIT_REPORT_HOUR_ID)";
				dropQuery = "ALTER TABLE "+tablename+ " DROP CONSTRAINT "+ constarintname;
				alterQuery = "ALTER TABLE "+tablename+ " ADD CONSTRAINT "+ constarintname + " FOREIGN KEY (HOUR_ID)  REFERENCES "+referenceValue+" ON DELETE CASCADE ";
				executeQuery(dropQuery);
				executeQuery(alterQuery);
				
				tablename = "JSVAR_VISIT_HOUR_VISITORS_"+dbspaceId;
				constarintname = tablename + "_HOUR_ID_FKEY";
				referenceValue = "JSVAR_VISIT_REPORT_HOUR(JSVAR_VISIT_REPORT_HOUR_ID)";
				dropQuery = "ALTER TABLE "+tablename+ " DROP CONSTRAINT "+ constarintname;
				alterQuery = "ALTER TABLE "+tablename+ " ADD CONSTRAINT "+ constarintname + " FOREIGN KEY (HOUR_ID)  REFERENCES "+referenceValue+" ON DELETE CASCADE ";
				executeQuery(dropQuery);
				executeQuery(alterQuery);
				
				tablename = "CUSTDIM_VISIT_HOUR_VISITORS_"+dbspaceId;
				constarintname = tablename + "_HOUR_ID_FKEY";
				referenceValue = "CUSTDIM_VISIT_REPORT_HOUR(CUSTDIM_VISIT_REPORT_HOUR_ID)";
				dropQuery = "ALTER TABLE "+tablename+ " DROP CONSTRAINT "+ constarintname;
				alterQuery = "ALTER TABLE "+tablename+ " ADD CONSTRAINT "+ constarintname + " FOREIGN KEY (HOUR_ID)  REFERENCES "+referenceValue+" ON DELETE CASCADE ";
				executeQuery(dropQuery);
				executeQuery(alterQuery);
				
				
				

				tablename = "BROWSER_GOAL_HOUR_VISITORS_"+dbspaceId;
				constarintname = tablename + "_HOUR_ID_FKEY";
				referenceValue = "BROWSER_GOAL_REPORT_HOUR(BROWSER_GOAL_REPORT_HOUR_ID)";
				dropQuery = "ALTER TABLE "+tablename+ " DROP CONSTRAINT "+ constarintname;
				alterQuery = "ALTER TABLE "+tablename+ " ADD CONSTRAINT "+ constarintname + " FOREIGN KEY (HOUR_ID)  REFERENCES "+referenceValue+" ON DELETE CASCADE ";
				executeQuery(dropQuery);
				executeQuery(alterQuery);
				
				tablename = "DEVICE_GOAL_HOUR_VISITORS_"+dbspaceId;
				constarintname = tablename + "_HOUR_ID_FKEY";
				referenceValue = "DEVICE_GOAL_REPORT_HOUR(DEVICE_GOAL_REPORT_HOUR_ID)";
				dropQuery = "ALTER TABLE "+tablename+ " DROP CONSTRAINT "+ constarintname;
				alterQuery = "ALTER TABLE "+tablename+ " ADD CONSTRAINT "+ constarintname + " FOREIGN KEY (HOUR_ID)  REFERENCES "+referenceValue+" ON DELETE CASCADE ";
				executeQuery(dropQuery);
				executeQuery(alterQuery);
				
				tablename = "COUNTRY_GOAL_HOUR_VISITORS_"+dbspaceId;
				constarintname = tablename + "_HOUR_ID_FKEY";
				referenceValue = "COUNTRY_GOAL_REPORT_HOUR(COUNTRY_GOAL_REPORT_HOUR_ID)";
				dropQuery = "ALTER TABLE "+tablename+ " DROP CONSTRAINT "+ constarintname;
				alterQuery = "ALTER TABLE "+tablename+ " ADD CONSTRAINT "+ constarintname + " FOREIGN KEY (HOUR_ID)  REFERENCES "+referenceValue+" ON DELETE CASCADE ";
				executeQuery(dropQuery);
				executeQuery(alterQuery);
				
				tablename = "LANG_GOAL_HOUR_VISITORS_"+dbspaceId;
				constarintname = tablename + "_HOUR_ID_FKEY";
				referenceValue = "LANG_GOAL_REPORT_HOUR(LANG_GOAL_REPORT_HOUR_ID)";
				dropQuery = "ALTER TABLE "+tablename+ " DROP CONSTRAINT "+ constarintname;
				alterQuery = "ALTER TABLE "+tablename+ " ADD CONSTRAINT "+ constarintname + " FOREIGN KEY (HOUR_ID)  REFERENCES "+referenceValue+" ON DELETE CASCADE ";
				executeQuery(dropQuery);
				executeQuery(alterQuery);
				
				tablename = "OS_GOAL_HOUR_VISITORS_"+dbspaceId;
				constarintname = tablename + "_HOUR_ID_FKEY";
				referenceValue = "OS_GOAL_REPORT_HOUR(OS_GOAL_REPORT_HOUR_ID)";
				dropQuery = "ALTER TABLE "+tablename+ " DROP CONSTRAINT "+ constarintname;
				alterQuery = "ALTER TABLE "+tablename+ " ADD CONSTRAINT "+ constarintname + " FOREIGN KEY (HOUR_ID)  REFERENCES "+referenceValue+" ON DELETE CASCADE ";
				executeQuery(dropQuery);
				executeQuery(alterQuery);
				
				tablename = "TRAFSOUR_GOAL_HOUR_VISITORS_"+dbspaceId;
				constarintname = tablename + "_HOUR_ID_FKEY";
				referenceValue = "TRAFSOUR_GOAL_REPORT_HOUR(TRAFSOUR_GOAL_REPORT_HOUR_ID)";
				dropQuery = "ALTER TABLE "+tablename+ " DROP CONSTRAINT "+ constarintname;
				alterQuery = "ALTER TABLE "+tablename+ " ADD CONSTRAINT "+ constarintname + " FOREIGN KEY (HOUR_ID)  REFERENCES "+referenceValue+" ON DELETE CASCADE ";
				executeQuery(dropQuery);
				executeQuery(alterQuery);
				
				tablename = "REFURL_GOAL_HOUR_VISITORS_"+dbspaceId;
				constarintname = tablename + "_HOUR_ID_FKEY";
				referenceValue = "REFURL_GOAL_REPORT_HOUR(REFURL_GOAL_REPORT_HOUR_ID)";
				dropQuery = "ALTER TABLE "+tablename+ " DROP CONSTRAINT "+ constarintname;
				alterQuery = "ALTER TABLE "+tablename+ " ADD CONSTRAINT "+ constarintname + " FOREIGN KEY (HOUR_ID)  REFERENCES "+referenceValue+" ON DELETE CASCADE ";
				executeQuery(dropQuery);
				executeQuery(alterQuery);
				
				tablename = "DAYOFWK_GOAL_HOUR_VISITORS_"+dbspaceId;
				constarintname = tablename + "_HOUR_ID_FKEY";
				referenceValue = "DAYOFWK_GOAL_REPORT_HOUR(DAYOFWK_GOAL_REPORT_HOUR_ID)";
				dropQuery = "ALTER TABLE "+tablename+ " DROP CONSTRAINT "+ constarintname;
				alterQuery = "ALTER TABLE "+tablename+ " ADD CONSTRAINT "+ constarintname + " FOREIGN KEY (HOUR_ID)  REFERENCES "+referenceValue+" ON DELETE CASCADE ";
				executeQuery(dropQuery);
				executeQuery(alterQuery);
				
				tablename = "HOURODY_GOAL_HOUR_VISITORS_"+dbspaceId;
				constarintname = tablename + "_HOUR_ID_FKEY";
				referenceValue = "HOURODY_GOAL_REPORT_HOUR(HOURODY_GOAL_REPORT_HOUR_ID)";
				dropQuery = "ALTER TABLE "+tablename+ " DROP CONSTRAINT "+ constarintname;
				alterQuery = "ALTER TABLE "+tablename+ " ADD CONSTRAINT "+ constarintname + " FOREIGN KEY (HOUR_ID)  REFERENCES "+referenceValue+" ON DELETE CASCADE ";
				executeQuery(dropQuery);
				executeQuery(alterQuery);
				
				tablename = "COOKIE_GOAL_HOUR_VISITORS_"+dbspaceId;
				constarintname = tablename + "_HOUR_ID_FKEY";
				referenceValue = "COOKIE_GOAL_REPORT_HOUR(COOKIE_GOAL_REPORT_HOUR_ID)";
				dropQuery = "ALTER TABLE "+tablename+ " DROP CONSTRAINT "+ constarintname;
				alterQuery = "ALTER TABLE "+tablename+ " ADD CONSTRAINT "+ constarintname + " FOREIGN KEY (HOUR_ID)  REFERENCES "+referenceValue+" ON DELETE CASCADE ";
				executeQuery(dropQuery);
				executeQuery(alterQuery);
				
				tablename = "URLPARM_GOAL_HOUR_VISITORS_"+dbspaceId;
				constarintname = tablename + "_HOUR_ID_FKEY";
				referenceValue = "URLPARM_GOAL_REPORT_HOUR(URLPARM_GOAL_REPORT_HOUR_ID)";
				dropQuery = "ALTER TABLE "+tablename+ " DROP CONSTRAINT "+ constarintname;
				alterQuery = "ALTER TABLE "+tablename+ " ADD CONSTRAINT "+ constarintname + " FOREIGN KEY (HOUR_ID)  REFERENCES "+referenceValue+" ON DELETE CASCADE ";
				executeQuery(dropQuery);
				executeQuery(alterQuery);
				
				tablename = "JSVAR_GOAL_HOUR_VISITORS_"+dbspaceId;
				constarintname = tablename + "_HOUR_ID_FKEY";
				referenceValue = "JSVAR_GOAL_REPORT_HOUR(JSVAR_GOAL_REPORT_HOUR_ID)";
				dropQuery = "ALTER TABLE "+tablename+ " DROP CONSTRAINT "+ constarintname;
				alterQuery = "ALTER TABLE "+tablename+ " ADD CONSTRAINT "+ constarintname + " FOREIGN KEY (HOUR_ID)  REFERENCES "+referenceValue+" ON DELETE CASCADE ";
				executeQuery(dropQuery);
				executeQuery(alterQuery);
				
				tablename = "CUSTDIM_GOAL_HOUR_VISITORS_"+dbspaceId;
				constarintname = tablename + "_HOUR_ID_FKEY";
				referenceValue = "CUSTDIM_GOAL_REPORT_HOUR(CUSTDIM_GOAL_REPORT_HOUR_ID)";
				dropQuery = "ALTER TABLE "+tablename+ " DROP CONSTRAINT "+ constarintname;
				alterQuery = "ALTER TABLE "+tablename+ " ADD CONSTRAINT "+ constarintname + " FOREIGN KEY (HOUR_ID)  REFERENCES "+referenceValue+" ON DELETE CASCADE ";
				executeQuery(dropQuery);
				executeQuery(alterQuery);
				
				
				
				tablename = "REVENUE_REPORT_HOUR_VISITORS_"+dbspaceId;
				constarintname = tablename + "_HOUR_ID_FKEY";
				referenceValue = "REVENUE_REPORT_HOUR(REVENUE_REPORT_HOUR_ID)";
				dropQuery = "ALTER TABLE "+tablename+ " DROP CONSTRAINT "+ constarintname;
				alterQuery = "ALTER TABLE "+tablename+ " ADD CONSTRAINT "+ constarintname + " FOREIGN KEY (HOUR_ID)  REFERENCES "+referenceValue+" ON DELETE CASCADE ";
				executeQuery(dropQuery);
				executeQuery(alterQuery);
				
				tablename = "REVENUE_DIMENSION_HOUR_VISITORS_"+dbspaceId;
				constarintname = tablename + "_HOUR_ID_FKEY";
				referenceValue = "GOAL_DIMENSION_HOUR(GOAL_DIMENSION_HOUR_ID)";
				dropQuery = "ALTER TABLE "+tablename+ " DROP CONSTRAINT "+ constarintname;
				alterQuery = "ALTER TABLE "+tablename+ " ADD CONSTRAINT "+ constarintname + " FOREIGN KEY (HOUR_ID)  REFERENCES "+referenceValue+" ON DELETE CASCADE ";
				executeQuery(dropQuery);
				executeQuery(alterQuery);
				
				
				
				
				tablename = "REVENUE_DIMENSION_HOUR_VISITORS_"+dbspaceId;
				constarintname = tablename + "_HOUR_ID_FKEY";
				referenceValue = "";
				dropQuery = "ALTER TABLE "+tablename+ " DROP CONSTRAINT "+ constarintname;
				alterQuery = "ALTER TABLE "+tablename+ " ADD CONSTRAINT "+ constarintname + " FOREIGN KEY (HOUR_ID)  REFERENCES "+referenceValue+" ON DELETE CASCADE ";
				executeQuery(dropQuery);
				executeQuery(alterQuery);
				
				
				
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in updateCurrentDynamicTable : "+ex.getMessage(), ex);
		}
	}*/
}
