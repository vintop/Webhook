//$Id$
package com.zoho.abtest.datamigration;

import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.sas.upgrade.isu.UpgradeHandler;
import com.zoho.abtest.AUDIENCE_ATTRIBUTE;
import com.zoho.abtest.audience.AudienceAttributeConstants;
import com.zoho.abtest.audience.AudienceAttributeConstants.AudienceAttributes;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.utility.ZABUtil;

public class AudienceAttributeUpgradeHandler extends UpgradeHandler{
	
	private static final Logger LOGGER = Logger.getLogger(AudienceAttributeUpgradeHandler.class.getName());
	
	public void handleTableUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into handleTableUpdates :" + oldVersion + ":" + isReverting);
	}
	
	public void handleCustomerDataUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "START handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
		//Setting this to use the existing dbpace set by SASa
		ZABUtil.setIsSchedulerJob(Boolean.TRUE);
		try
		{
				HashMap<String, String> data = new HashMap<String, String>();
				data.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.GOALS.getAudienceAttrId().toString());
				data.put(AudienceAttributeConstants.ATTRIBUTE_DISPLAYNAME, AudienceAttributes.GOALS.getDisplayName());
				data.put(AudienceAttributeConstants.ATTRIBUTE_KEYNAME, AudienceAttributes.GOALS.getKeyName());
				data.put(AudienceAttributeConstants.ATTRIBUTE_DESCRIPTION, AudienceAttributes.GOALS.getDescription());
				data.put(AudienceAttributeConstants.IS_DYNAMIC_ATTRIBUTE, AudienceAttributes.GOALS.getIsDynamicAttribute());

				ZABModel.createRow(AudienceAttributeConstants.AUDIENCE_ATTRIBUTE_TABLE, AUDIENCE_ATTRIBUTE.TABLE, data);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in handleCustomerDataUpdates : "+ex.getMessage(), ex);
		}
		LOGGER.log(Level.INFO, "END handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
	}
}
