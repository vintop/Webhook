//$Id$
package com.zoho.abtest.datamigration;


import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.sas.ds.SASThreadLocal;
import com.adventnet.sas.upgrade.isu.UpgradeHandler;
import com.zoho.abtest.goal.Goal;
import com.zoho.abtest.utility.ZABUtil;

public class ProjectGoalUpgradeHandler extends UpgradeHandler {
	
	private static final Logger LOGGER = Logger.getLogger(ProjectGoalUpgradeHandler.class.getName());
	
	public void handleTableUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into handleTableUpdates :" + oldVersion + ":" + isReverting);
	}
	
	public void handleCustomerDataUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "START handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
		String loginName = SASThreadLocal.getLoginName();

		try
		{
			String dbSpaceName = SASThreadLocal.getLoginName();
			ZABUtil.setDBSpace(dbSpaceName);
			Goal.migrateAcProjectGoalDetails();
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in handleCustomerDataUpdates : "+loginName+" "+ex.getMessage(), ex);
		}
		LOGGER.log(Level.INFO, "END handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
	}

}



