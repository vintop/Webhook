//$Id$
package com.zoho.abtest.datamigration;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;

import com.adventnet.sas.ds.SASThreadLocal;
import com.adventnet.sas.upgrade.isu.UpgradeHandler;
import com.zoho.abtest.elastic.ESIndexMeta;
import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.utility.ZABUtil;

public class ESDefaultIndexesUpgradeHandler extends UpgradeHandler
{
	private static final Logger LOGGER = Logger.getLogger(ESDefaultIndexesUpgradeHandler.class.getName());
	
	public void handleTableUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into handleTableUpdates :" + oldVersion + ":" + isReverting);
	}
	
	public void handleCustomerDataUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
		try
		{
			ZABUtil.setIsSchedulerJob(Boolean.TRUE);
			String dbSpaceName = SASThreadLocal.getLoginName();
			if(StringUtils.isNotEmpty(dbSpaceName) && dbSpaceName.equals("sharedspace"))
			{
				boolean isIndexMetaExists = ESIndexMeta.isESIndexMetaExists();
				if(!isIndexMetaExists)
				{
					ElasticSearchUtil.populateDefaultIndexes();
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in handleCustomerDataUpdates : "+ex.getMessage(), ex);
		}
		LOGGER.log(Level.INFO, "Completed handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
	}
}
