//$Id$
package com.zoho.abtest.datamigration;

import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.sas.upgrade.isu.UpgradeHandler;
import com.zoho.abtest.user.Feature;
import com.zoho.abtest.user.FeatureConstants;
import com.zoho.abtest.user.Role;
import com.zoho.abtest.user.RoleFeature;
import com.zoho.abtest.user.RoleFeatureConstants;
import com.zoho.abtest.user.FeatureConstants.AppFeatures;
import com.zoho.abtest.user.RoleConstants.UserRoles;
import com.zoho.abtest.utility.ZABUtil;

public class PageSenseNewFeaturesUpgradeHandler extends UpgradeHandler
{
	private static final Logger LOGGER = Logger.getLogger(OptimizeNewFeaturesUpgradeHandler.class.getName());
	
	public void handleTableUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into handleTableUpdates :" + oldVersion + ":" + isReverting);
	}
	
	public void handleCustomerDataUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "START handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
		//Setting this to use the existing dbpace set by SAS
		ZABUtil.setIsSchedulerJob(Boolean.TRUE);
		try
		{
			Long adminRoleId = Role.getRoleIdByName(UserRoles.ADMIN.getRole());
			if(adminRoleId!=null) {				
				createNewFeature(AppFeatures.CREATEFUNNELSTEP, AppFeatures.EDITFUNNELSTEP, AppFeatures.DELETEFUNNELSTEP);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in handleCustomerDataUpdates : "+ex.getMessage(), ex);
			throw ex;
		}
		LOGGER.log(Level.INFO, "END handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
	}
	
	private void createRoleFeatureMapping(Long roleId, Long featureId) {
		if(roleId!=null && featureId!=null) {			
			HashMap<String, String> hs = new HashMap<String, String>();
			hs = new HashMap<String, String>();
			hs.put(RoleFeatureConstants.ROLE_ID, roleId.toString());
			hs.put(RoleFeatureConstants.FEATURE_ID, featureId.toString());
			RoleFeature.createRoleFeature(hs);
		}
	}
	
	public void createNewFeature(AppFeatures... features) throws Exception
	{
			int length = features.length;
			for(int i = 0; i < length; i++) {
				try
				{
					AppFeatures feat = features[i];
					UserRoles featureRole = UserRoles.getRoleByValue(feat.getRoleValue());
					boolean isFeatureAlreadyExists = Feature.isFeatureExistsInDB(feat.getFeature());
					if(!isFeatureAlreadyExists)
					{
						LOGGER.log(Level.INFO, "Feature creation started for "+ feat.getFeature());
						HashMap<String, String> hs = new HashMap<String, String>();
						hs.put(FeatureConstants.FEATURE_NAME, feat.getFeature());
						hs.put(FeatureConstants.FEATURE_DESCRIPTION, feat.getFeatureDescription());
						hs.put(FeatureConstants.ROLE_VALUE,feat.getRoleValue().toString());
						Feature feature = Feature.createFeature(hs);
						
						if(feature.getFeatureId() != null)
						{
							Long editorRoleId = Role.getRoleIdByName(UserRoles.EDITOR.getRole());
							Long projAdminRoleId = Role.getRoleIdByName(UserRoles.PROJECTADMIN.getRole());
							Long adminRoleId = Role.getRoleIdByName(UserRoles.ADMIN.getRole());
							Long specRoleId = Role.getRoleIdByName(UserRoles.SPECTATOR.getRole());
							
							switch (featureRole) {
								case ADMIN:
									createRoleFeatureMapping(adminRoleId, feature.getFeatureId());
									break;
								case PROJECTADMIN:
									createRoleFeatureMapping(adminRoleId, feature.getFeatureId());
									createRoleFeatureMapping(projAdminRoleId, feature.getFeatureId());
									break;
								case EDITOR:
									createRoleFeatureMapping(adminRoleId, feature.getFeatureId());
									createRoleFeatureMapping(projAdminRoleId, feature.getFeatureId());
									createRoleFeatureMapping(editorRoleId, feature.getFeatureId());
									break;
								case SPECTATOR:
									createRoleFeatureMapping(adminRoleId, feature.getFeatureId());
									createRoleFeatureMapping(projAdminRoleId, feature.getFeatureId());
									createRoleFeatureMapping(editorRoleId, feature.getFeatureId());
									createRoleFeatureMapping(specRoleId, feature.getFeatureId());
									break;
								default:
									break;
							}
						}
						
						LOGGER.log(Level.INFO, "Feature created and mapped successfully:"+feature.getFeatureId());
					}
			}
			catch(Exception ex)
			{
				LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
				throw ex;
			}
		}
	}
}
