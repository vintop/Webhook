//$Id$
package com.zoho.abtest.datamigration;

import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.iam.ServiceOrg;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.sas.ds.SASThreadLocal;
import com.adventnet.sas.upgrade.isu.UpgradeHandler;
import com.zoho.abtest.PROJECT_GOAL;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.portal.Portal;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUtil;

public class GoalUrlUpgradeHandler extends UpgradeHandler
{
	private static final Logger LOGGER = Logger.getLogger(GoalUrlUpgradeHandler.class.getName());

	public void handleTableUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into GoalUrlUpgradeHandler :" + oldVersion + ":" + isReverting);
	}
	
	public void handleCustomerDataUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into GoalUrlUpgradeHandler :" + oldVersion + ":" + isReverting);
		try
		{
			String dbSpaceName = SASThreadLocal.getLoginName();
			ZABUtil.setIsSchedulerJob(Boolean.TRUE);
		
			if(StringUtils.isNotEmpty(dbSpaceName) && !dbSpaceName.equals("sharedspace"))
			{
				ServiceOrg org = ZABServiceOrgUtil.getServiceOrg(dbSpaceName);
				if(org!=null) {
					Boolean changed = Boolean.FALSE;
					Criteria c = new Criteria(new Column(PROJECT_GOAL.TABLE,PROJECT_GOAL.GOAL_URL),"*",QueryConstants.EQUAL);
					DataObject dobj = ZABModel.getRow(PROJECT_GOAL.TABLE, c);
					Iterator<?> it = dobj.getRows(PROJECT_GOAL.TABLE);
					while(it.hasNext()){
						
						Row r = (Row) it.next();
						String includeurl = (String) r.get(PROJECT_GOAL.INCLUDE_URLS);
						JSONArray includeJsonArray = new JSONArray(includeurl);
						if(includeJsonArray.length()>0){
							r.set(PROJECT_GOAL.GOAL_URL, null);
							dobj.updateRow(r);
							changed = Boolean.TRUE;
						}
					}
					ZABModel.updateDataObject(dobj);
					if(changed){
						Portal.regenerateScriptsinPortal(dbSpaceName);
					}
				}
			}
			LOGGER.log(Level.INFO, "Completed GoalUrlUpgradeHandler :" + oldVersion + ":" + isReverting);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in GoalUrlUpgradeHandler : "+ex.getMessage(), ex);
		}
	}
	
}
