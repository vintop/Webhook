//$Id$
package com.zoho.abtest.datamigration;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;

import com.adventnet.sas.ds.SASThreadLocal;
import com.adventnet.sas.upgrade.isu.UpgradeHandler;
import com.zoho.abtest.utility.ZABSchedulerUtil;

public class SpaceDeletionJobUpgradeHandler extends UpgradeHandler
{
	private static final Logger LOGGER = Logger.getLogger(SpaceDeletionJobUpgradeHandler.class.getName());
	
	public void handleTableUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into handleTableUpdates :" + oldVersion + ":" + isReverting);
	}
	
	public void handleCustomerDataUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
		try
		{
			String dbSpaceName = SASThreadLocal.getLoginName();
			if(StringUtils.isNotEmpty(dbSpaceName) && dbSpaceName.equals("sharedspace"))
			{
				ZABSchedulerUtil.submitSpaceContentDeletionJob();
			}
			LOGGER.log(Level.INFO, "Completed handleCustomerDataUpdates for :" + dbSpaceName);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in handleCustomerDataUpdates : "+ex.getMessage(), ex);
		}
	}
}
