//$Id$
package com.zoho.abtest.datamigration;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.sas.ds.SASThreadLocal;
import com.adventnet.sas.upgrade.isu.UpgradeHandler;
import com.zoho.abtest.ATTRIBUTE_MATCHTYPE_MAPPING;
import com.zoho.abtest.AUDIENCE;
import com.zoho.abtest.AUDIENCE_ATTRIBUTE;
import com.zoho.abtest.BROWSER_DETAIL;
import com.zoho.abtest.COUNTRY_DETAIL;
import com.zoho.abtest.DEVICE_DETAIL;
import com.zoho.abtest.EXPERIMENT_PROJECT_INTEGRATION;
import com.zoho.abtest.GOOGLE_ANALYTICS_DETAILS;
import com.zoho.abtest.INTEGRATION;
import com.zoho.abtest.LANGUAGE_DETAIL;
import com.zoho.abtest.MOBILE_DEVICE_DETAIL;
import com.zoho.abtest.OS_DETAIL;
import com.zoho.abtest.PROJECT_INTEGRATION;
import com.zoho.abtest.audience.Audience;
import com.zoho.abtest.audience.AudienceAttributeConstants;
import com.zoho.abtest.audience.AudienceConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.dimension.DimensionConstants;
import com.zoho.abtest.integration.GoogleAnalytics;
import com.zoho.abtest.integration.IntegrationConstants;
import com.zoho.abtest.portal.PortalAction;
import com.zoho.abtest.report.ReportRawDataConstants;
import com.zoho.abtest.user.Feature;
import com.zoho.abtest.user.FeatureConstants;
import com.zoho.abtest.user.RoleFeature;
import com.zoho.abtest.user.RoleFeatureConstants;
import com.zoho.abtest.user.FeatureConstants.AppFeatures;
import com.zoho.abtest.user.Role;
import com.zoho.abtest.user.RoleConstants.UserRoles;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.abtest.CITIES_JSON;
import com.zoho.abtest.audience.LocationConstants;

public class IntegrationFeatureUpgradeHandler extends UpgradeHandler
{
	private static final Logger LOGGER = Logger.getLogger(IntegrationFeatureUpgradeHandler.class.getName());
	
	public void handleTableUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into handleTableUpdates :" + oldVersion + ":" + isReverting);
	}
	
	public void handleCustomerDataUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "START handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
		//Setting this to use the existing dbpace set by SAS
		//ZABUtil.setIsSchedulerJob(Boolean.TRUE);
		try
		{

//			deleteIntegrations();
//			addIntegration();
			locationPopulation();
		
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in handleCustomerDataUpdates : "+ex.getMessage(), ex);
			throw ex;
		}
		LOGGER.log(Level.INFO, "END handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
	}
	
	public void deleteIntegrations() throws Exception
	{
		try{
			Criteria c1 = null;
			
			DataObject dobj = ZABModel.getRow(PROJECT_INTEGRATION.TABLE, c1);
			int size = dobj.size(PROJECT_INTEGRATION.TABLE);
			for(int i=0;i<size;i++){
				DataObject dobj1 = ZABModel.getRow(PROJECT_INTEGRATION.TABLE, c1);
				if(dobj1.containsTable(PROJECT_INTEGRATION.TABLE)) {
					Row row = dobj1.getFirstRow(PROJECT_INTEGRATION.TABLE);
					ZABModel.deleteResource(row);
				}
			}
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE, "Exception occured in deleteGoogleAdwords "+ex.getMessage(),ex);
			throw ex;
		}
	}

	public void addIntegration() throws Exception
	{
		try
		{
			Criteria c = null;
			DataObject dobj = ZABModel.getRow(INTEGRATION.TABLE,c);
			if(dobj.containsTable(INTEGRATION.TABLE)) {
				int size = dobj.size(INTEGRATION.TABLE);
				if(size == 4){
					ArrayList<HashMap<String, String>> myList = new ArrayList<HashMap<String, String>>();

					HashMap<String, String> data2 = new HashMap<String, String>();
					data2.put(IntegrationConstants.INTEGRATION_ID, "5");
					data2.put(IntegrationConstants.INTEGRATION_NAME, "Clicky");
					data2.put(IntegrationConstants.INTEGRATION_DESCRIPTION, " ");
			
					myList.add(data2);
					
					ZABModel.createRow(IntegrationConstants.INTEGRATION_TABLE, INTEGRATION.TABLE, myList);
				}
				
			}
			
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE, "Exception occured in IntegrationPopulation "+ex.getMessage(),ex);
			throw ex;
		}
	}
	public void addAudienceMatchType() throws Exception{
		
		try{
			String dbSpaceName = SASThreadLocal.getLoginName();
			if(StringUtils.isNotEmpty(dbSpaceName) && dbSpaceName.equals("sharedspace"))
			{
				ArrayList<HashMap<String, String>> myList = new ArrayList<HashMap<String, String>>();
				
				HashMap<String, String> data1 = new HashMap<String, String>();
				data1.put(AudienceAttributeConstants.ATTRIBUTE_ID, "16");
				data1.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

				HashMap<String, String> data2 = new HashMap<String, String>();
				data2.put(AudienceAttributeConstants.ATTRIBUTE_ID, "16");
				data2.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");

				HashMap<String, String> data3 = new HashMap<String, String>();
				data3.put(AudienceAttributeConstants.ATTRIBUTE_ID, "17");
				data3.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

				HashMap<String, String> data4 = new HashMap<String, String>();
				data4.put(AudienceAttributeConstants.ATTRIBUTE_ID, "17");
				data4.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");
				
				myList.add(data1);
				myList.add(data2);
				myList.add(data3);
				myList.add(data4);
				
				ZABModel.createRow(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_MAPPING_TABLE, ATTRIBUTE_MATCHTYPE_MAPPING.TABLE, myList);
			}
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE, "Exception occured in addAudienceMatchType "+ex.getMessage(),ex);
			throw ex;
		}
		
	}
	
	public void addCustomAudience() throws Exception
	{
		try{

			Criteria c = null;
			DataObject dobj = ZABModel.getRow(AUDIENCE_ATTRIBUTE.TABLE,c);
			int size = dobj.size(AUDIENCE_ATTRIBUTE.TABLE);
			if(size == 15) {
				ArrayList<HashMap<String, String>> myList = new ArrayList<HashMap<String, String>>();
				
				HashMap<String, String> data1 = new HashMap<String, String>();
				data1.put(AudienceAttributeConstants.ATTRIBUTE_ID, "16");
				data1.put(AudienceAttributeConstants.ATTRIBUTE_DISPLAYNAME, "Adwords Campaign");
				data1.put(AudienceAttributeConstants.ATTRIBUTE_KEYNAME, "adwords_campaign");
				data1.put(AudienceAttributeConstants.ATTRIBUTE_DESCRIPTION, " ");
				data1.put(AudienceAttributeConstants.IS_DYNAMIC_ATTRIBUTE, Boolean.FALSE.toString());
				myList.add(data1);
				
				HashMap<String, String> data = new HashMap<String, String>();
				data.put(AudienceAttributeConstants.ATTRIBUTE_ID, "17");
				data.put(AudienceAttributeConstants.ATTRIBUTE_DISPLAYNAME, "Adwords Group");
				data.put(AudienceAttributeConstants.ATTRIBUTE_KEYNAME, "adwords_group");
				data.put(AudienceAttributeConstants.ATTRIBUTE_DESCRIPTION, " ");
				data.put(AudienceAttributeConstants.IS_DYNAMIC_ATTRIBUTE, Boolean.FALSE.toString());
				myList.add(data);
				
				ZABModel.createRow(AudienceAttributeConstants.AUDIENCE_ATTRIBUTE_TABLE, AUDIENCE_ATTRIBUTE.TABLE, myList);
				
			}
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE, "Exception occured in addCustomAudience "+ex.getMessage(),ex);
			throw ex;
		}
	}
	
	public void updateAudienceDescription() throws Exception
	{
		try{
			
			Criteria c = null;
			DataObject dobj = ZABModel.getRow(AUDIENCE.TABLE,c);
			if(dobj.containsTable(AUDIENCE.TABLE)) {
				Iterator<?> it = dobj.getRows(AUDIENCE.TABLE);
				HashMap<String, String> hs = new HashMap<String, String>();
				while(it.hasNext()) {
					Row row = (Row)it.next();
					String audience_linkname = (String)row.get(AUDIENCE.AUDIENCE_LINK_NAME);
					String audience_name = null;
					if(audience_linkname != null && audience_linkname.equals("referral")){
						audience_name = "Referral Traffic";
						hs.put(AudienceConstants.AUDIENCE_NAME, audience_name);
						Criteria c1 = new Criteria(new Column(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME), audience_linkname, QueryConstants.EQUAL);
						ZABModel.updateRow(AudienceConstants.AUDIENCE_TABLE, AUDIENCE.TABLE, hs, c1, AudienceConstants.API_RESOURCE);
					}
				}
			}
		
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE, "Exception occured in updateAudienceDescription "+ex.getMessage(),ex);
			throw ex;
		}
	}
	
	public void createGoogleAnalytics() throws Exception
	{
		String pid = null;
		String epid = null;
		Integer integration_id = 0;		
		try{
			Criteria c = null;
			String e = null;
			DataObject dobj = ZABModel.getRow(EXPERIMENT_PROJECT_INTEGRATION.TABLE,c);
			if(dobj.containsTable(EXPERIMENT_PROJECT_INTEGRATION.TABLE)) {
				Iterator<?> it = dobj.getRows(EXPERIMENT_PROJECT_INTEGRATION.TABLE);
				while(it.hasNext()) {
					Row row = (Row)it.next();
					epid = (String)row.get(EXPERIMENT_PROJECT_INTEGRATION.EXPERIMENT_PROJECT_INTEGRATION_ID).toString();
					pid = (String)row.get(EXPERIMENT_PROJECT_INTEGRATION.PROJECT_INTEGRATION_ID).toString();
					Criteria c1 = new Criteria(new Column(PROJECT_INTEGRATION.TABLE,PROJECT_INTEGRATION.PROJECT_INTEGRATION_ID),pid, QueryConstants.EQUAL);
					DataObject dobj1 = ZABModel.getRow(PROJECT_INTEGRATION.TABLE,c1);
					if(dobj1.containsTable(PROJECT_INTEGRATION.TABLE)) {
						Iterator<?> it1 = dobj1.getRows(PROJECT_INTEGRATION.TABLE);
						while(it1.hasNext()) {
							Row row1 = (Row)it1.next();
							integration_id = (Integer)row1.get(PROJECT_INTEGRATION.INTEGRATION_ID);
							if(integration_id == 1){
								HashMap<String, String> hs = new HashMap<String, String>();
								hs.put(IntegrationConstants.EXPERIMENT_PROJECT_INTEGRATION_ID, epid);
								hs.put(IntegrationConstants.CUSTOM_DIMENSION,"1");
								hs.put(IntegrationConstants.CUSTOM_TRACKER,"");
								ZABModel.createRow(IntegrationConstants.GOOGLE_ANALYTICS_TABLE, GOOGLE_ANALYTICS_DETAILS.TABLE, hs);
							}
						}
					}
				}
			}
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE, "Exception occured in createGoogleAnalytics "+ex.getMessage(),ex);
			throw ex;
		}
	}
	
	public void deletedimensionvalues() throws Exception
	{
		
		//String dbSpaceId = SASThreadLocal.getLoginName();
		//ZABUtil.setDBSpace("sharedspace");	
		//if(dbSpaceId!=null && dbSpaceId.equals("sharedspace")){
			
			try{
				Criteria c = null;
				DataObject dobj = ZABModel.getRow(BROWSER_DETAIL.TABLE,c);
				if(dobj.containsTable(BROWSER_DETAIL.TABLE)) {
					Iterator<?> it = dobj.getRows(BROWSER_DETAIL.TABLE);
					while(it.hasNext()) {
						Row row = (Row)it.next();
						ZABModel.deleteResource(row);
					}
				}
				
				dobj = ZABModel.getRow(OS_DETAIL.TABLE,c);
				if(dobj.containsTable(OS_DETAIL.TABLE)) {
					Iterator<?> it = dobj.getRows(OS_DETAIL.TABLE);
					while(it.hasNext()) {
						Row row = (Row)it.next();
						ZABModel.deleteResource(row);
					}
				}
				
				dobj = ZABModel.getRow(DEVICE_DETAIL.TABLE,c);
				if(dobj.containsTable(DEVICE_DETAIL.TABLE)) {
					Iterator<?> it = dobj.getRows(DEVICE_DETAIL.TABLE);
					while(it.hasNext()) {
						Row row = (Row)it.next();
						ZABModel.deleteResource(row);
					}
				}
				
				dobj = ZABModel.getRow(MOBILE_DEVICE_DETAIL.TABLE,c);
				if(dobj.containsTable(MOBILE_DEVICE_DETAIL.TABLE)) {
					Iterator<?> it = dobj.getRows(MOBILE_DEVICE_DETAIL.TABLE);
					while(it.hasNext()) {
						Row row = (Row)it.next();
						ZABModel.deleteResource(row);
					}
				}
				
				dobj = ZABModel.getRow(COUNTRY_DETAIL.TABLE,c);
				if(dobj.containsTable(COUNTRY_DETAIL.TABLE)) {
					Iterator<?> it = dobj.getRows(COUNTRY_DETAIL.TABLE);
					while(it.hasNext()) {
						Row row = (Row)it.next();
						ZABModel.deleteResource(row);
					}
				}
				
				dobj = ZABModel.getRow(LANGUAGE_DETAIL.TABLE,c);
				if(dobj.containsTable(LANGUAGE_DETAIL.TABLE)) {
					Iterator<?> it = dobj.getRows(LANGUAGE_DETAIL.TABLE);
					while(it.hasNext()) {
						Row row = (Row)it.next();
						ZABModel.deleteResource(row);
					}
				}
			}catch(Exception ex){
				LOGGER.log(Level.SEVERE, "Exception occured in deletedimensionvalues "+ex.getMessage(),ex);
				throw ex;
			}
		//}
	}
	
	public void createdimensionvalues() throws Exception
	{
		
		String dbSpaceId = SASThreadLocal.getLoginName();
		if(dbSpaceId!=null && dbSpaceId.equals("sharedspace")){
			try{
				browserDataPopulation();
				platformDataPopulation();
				deviceDataPopulation();
				mobileDeviceDataPopulation();
				countryDataPopulation();
				languageDataPopulation();
			}catch(Exception ex){
				LOGGER.log(Level.SEVERE, "Exception occured in createdimensionvalues "+ex.getMessage(),ex);
				throw ex;
			}
		}
	}
	
	public  void browserDataPopulation(){
		try{
			
			ArrayList<HashMap<String, String>> myList = new ArrayList<HashMap<String, String>>();

			String browserValue[]={"Firefox","Chrome","Internet Explorer","Safari","Edge","UCBrowser","Netscape"};
			for(int i=0;i<browserValue.length;i++){
				HashMap<String, String> data = new HashMap<String, String>();
				data.put(DimensionConstants.BROWSER_VALUE, browserValue[i]); //TODO
				data.put(DimensionConstants.BROWSER_CODE, i+"");
				myList.add(data);
			}
			
			ZABModel.createRow(DimensionConstants.BROWSER_DETAIL_CONSTANTS, BROWSER_DETAIL.TABLE, myList);

		}catch(Exception ex){
			ex.printStackTrace();
		}
		
	}
	

	public static void platformDataPopulation(){
		try{
			
			ArrayList<HashMap<String, String>> myList = new ArrayList<HashMap<String, String>>();
			
			String osValue[] = {"Linux","UNIX","MacOS","Windows"}; //No I18N

			for(int i=0;i<osValue.length;i++){
				HashMap<String, String> data = new HashMap<String, String>();
				data.put(DimensionConstants.OS_VALUE, osValue[i]); //TODO
				data.put(DimensionConstants.OS_CODE, i+"");
				myList.add(data);
			}
			
			ZABModel.createRow(DimensionConstants.OS_DETAIL_CONSTANTS, OS_DETAIL.TABLE, myList);

		}catch(Exception ex){
			ex.printStackTrace();
		}
		
	}
	
	public static void deviceDataPopulation(){
		try{
			
			ArrayList<HashMap<String, String>> myList = new ArrayList<HashMap<String, String>>();
			
			String deviceValue[] = {"Desktop","Mobile","Tablet"}; //No I18N

			for(int i=0;i<deviceValue.length;i++){
				HashMap<String, String> data = new HashMap<String, String>();
				data.put(DimensionConstants.DEVICE_VALUE, deviceValue[i]); //TODO
				data.put(DimensionConstants.DEVICE_CODE, i+"");
				myList.add(data);
			}
			
			ZABModel.createRow(DimensionConstants.DEVICE_DETAIL_CONSTANTS, DEVICE_DETAIL.TABLE, myList);
		}catch(Exception ex){
			ex.printStackTrace();
		}
	
	}
	
	public static void mobileDeviceDataPopulation(){
		try{
			
			ArrayList<HashMap<String, String>> myList = new ArrayList<HashMap<String, String>>();
			
			String mobileDeviceValue[] = {"Android","BlackBerry","IOS","Opera","Windows"};  //No I18N
			
			for(int i=0;i<mobileDeviceValue.length;i++){
				HashMap<String, String> data = new HashMap<String, String>();
				data.put(DimensionConstants.MOBILE_DEVICE_VALUE, mobileDeviceValue[i]); //TODO
				data.put(DimensionConstants.MOBILE_DEVICE_CODE, i+"");
				myList.add(data);
			}
			
			ZABModel.createRow(DimensionConstants.MOBILE_DEVICE_DETAIL_CONSTANTS, MOBILE_DEVICE_DETAIL.TABLE, myList);

		}catch(Exception ex){
			ex.printStackTrace();
		}
	
	}
	
	public static void countryDataPopulation(){
		try{
			
			ArrayList<HashMap<String, String>> myList = new ArrayList<HashMap<String, String>>();
			
			HashMap<String, String> data = new HashMap<String, String>();
			data.put(DimensionConstants.COUNTRY_VALUE , ReportRawDataConstants.UNKNOWN_VALUE); //TODO
			data.put(DimensionConstants.COUNTRY_DISPLAY_NAME, ReportRawDataConstants.UNKNOWN_VALUE);
			data.put(DimensionConstants.COUNTRY_CODE, "0");
			myList.add(data);
			
			String[] locales = Locale.getISOCountries();
			int i = 1;
			for (String countryCode : locales) {
				Locale obj = new Locale("", countryCode);
				HashMap<String, String> data1 = new HashMap<String, String>();
				data1.put(DimensionConstants.COUNTRY_VALUE , obj.getDisplayCountry()); //TODO
				data1.put(DimensionConstants.COUNTRY_DISPLAY_NAME, obj.getDisplayCountry());
				data1.put(DimensionConstants.COUNTRY_CODE, ""+i++);
				myList.add(data1);
				
			}
	
			
			ZABModel.createRow(DimensionConstants.COUNTRY_DETAIL_CONSTANTS, COUNTRY_DETAIL.TABLE, myList);

		}catch(Exception ex){
			ex.printStackTrace();
		}
	
	}
	
	public static void languageDataPopulation(){
		try{
			
			ArrayList<HashMap<String, String>> myList = new ArrayList<HashMap<String, String>>();
			
			HashMap<String, String> data = new HashMap<String, String>();
			data.put(DimensionConstants.LANGUAGE_VALUE , ReportRawDataConstants.UNKNOWN_VALUE); //TODO
			data.put(DimensionConstants.LANGUAGE_DISPLAY_NAME, ReportRawDataConstants.UNKNOWN_VALUE);
			data.put(DimensionConstants.LANGUAGE_CODE, "0");
			
			myList.add(data);
			
			String[] languages = Locale.getISOLanguages();
			Locale obj = null;
			int i = 1;
			for (String languageCode : languages) {
				
				obj = new Locale(languageCode);
				
				HashMap<String, String> data1 = new HashMap<String, String>();
				data1.put(DimensionConstants.LANGUAGE_VALUE , obj.getDisplayLanguage());
				data1.put(DimensionConstants.LANGUAGE_DISPLAY_NAME, obj.getDisplayLanguage());
				data1.put(DimensionConstants.LANGUAGE_CODE, ""+i++);
				myList.add(data1);
				
			}
			
			ZABModel.createRow(DimensionConstants.LANGUAGE_DETAIL_CONSTANTS, LANGUAGE_DETAIL.TABLE, myList);

		}catch(Exception ex){
			ex.printStackTrace();
		}
	
	}
	
	public static void locationPopulation() throws Exception{
			
			try
			{
				String dbSpaceId = SASThreadLocal.getLoginName();
				ZABUtil.setDBSpace("sharedspace");	 //No I18N
				if(dbSpaceId!=null && dbSpaceId.equals("sharedspace")){
					//PortalAction.locationDataPopulation();
					HashMap<String,String> hs1 = new HashMap<String,String>();
					hs1.put(LocationConstants.COUNTRY_ID, "38"); //No I18N
					hs1.put(LocationConstants.NAME, "Victoria"); //No I18N 
					hs1.put(LocationConstants.STATE_ID, "664"); //No I18N
					hs1.put(LocationConstants.ID, "48315"); //No I18N
					ZABModel.createRow(LocationConstants.CITIES_TABLE,CITIES_JSON.TABLE,hs1);
				}
			}catch(Exception ex){
				LOGGER.log(Level.SEVERE, "Exception occured in locationDataPopulation "+ex.getMessage(),ex);
			}
		}
	
	/*public Feature createNewFeature() throws Exception
	{
		Feature feature = null;
		String rolename = null;
		try
		{
			Criteria c = null;
			DataObject dobj = ZABModel.getRow(ROLES.TABLE,c);
			if(dobj.containsTable(ROLES.TABLE)) {
				Iterator<?> it = dobj.getRows(ROLES.TABLE);
				Row row = (Row)it.next();
				rolename = (String)row.get(ROLES.ROLE_NAME);
			}
			boolean isFeatureAlreadyExists = false;
			if(rolename != null){
				 isFeatureAlreadyExists = Feature.isFeatureExistsInDB(AppFeatures.CREATEPROJECTINTEGRATIONS.getFeature());
				if(!isFeatureAlreadyExists)
				{
					LOGGER.log(Level.INFO, "Feature creation started");
					HashMap<String, String> hs = new HashMap<String, String>();
					hs.put(FeatureConstants.FEATURE_NAME, AppFeatures.CREATEPROJECTINTEGRATIONS.getFeature());
					hs.put(FeatureConstants.FEATURE_DESCRIPTION, AppFeatures.CREATEPROJECTINTEGRATIONS.getFeatureDescription());
					hs.put(FeatureConstants.ROLE_VALUE,AppFeatures.CREATEPROJECTINTEGRATIONS.getRoleValue().toString());
					feature = Feature.createFeature(hs);
					addRoleFeatureMapping(feature.getFeatureId());
					
				}
				
				isFeatureAlreadyExists = Feature.isFeatureExistsInDB(AppFeatures.GETPROJECTINTEGRATIONS.getFeature());
				if(!isFeatureAlreadyExists)
				{
					HashMap<String, String> hs = new HashMap<String, String>();
					hs.put(FeatureConstants.FEATURE_NAME, AppFeatures.GETPROJECTINTEGRATIONS.getFeature());
					hs.put(FeatureConstants.FEATURE_DESCRIPTION, AppFeatures.GETPROJECTINTEGRATIONS.getFeatureDescription());
					hs.put(FeatureConstants.ROLE_VALUE,AppFeatures.GETPROJECTINTEGRATIONS.getRoleValue().toString());
					feature = Feature.createFeature(hs);
					addRoleFeatureMapping(feature.getFeatureId());
					
				}
				
				isFeatureAlreadyExists = Feature.isFeatureExistsInDB(AppFeatures.DELETEPROJECTINTEGRATIONS.getFeature());
				if(!isFeatureAlreadyExists)
				{
					HashMap<String, String> hs = new HashMap<String, String>();
					hs.put(FeatureConstants.FEATURE_NAME, AppFeatures.DELETEPROJECTINTEGRATIONS.getFeature());
					hs.put(FeatureConstants.FEATURE_DESCRIPTION, AppFeatures.DELETEPROJECTINTEGRATIONS.getFeatureDescription());
					hs.put(FeatureConstants.ROLE_VALUE,AppFeatures.DELETEPROJECTINTEGRATIONS.getRoleValue().toString());
					feature = Feature.createFeature(hs);
					addRoleFeatureMapping(feature.getFeatureId());
					
				}
				LOGGER.log(Level.INFO, "Feature created and mapped successfully:"+feature.getFeatureId());
				}
						
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occured in CreateNewFeature "+ex.getMessage(),ex);
			throw ex;
		}
		return feature;
	}
	
	public void addRoleFeatureMapping(Long featureId){
		try{
			HashMap<String, String> hs = new HashMap<String, String>();
			if(featureId != null)
			{
				Long editorRoleId = Role.getRoleIdByName(UserRoles.EDITOR.getRole());
				Long projAdminRoleId = Role.getRoleIdByName(UserRoles.PROJECTADMIN.getRole());
				Long adminRoleId = Role.getRoleIdByName(UserRoles.ADMIN.getRole());
				
				if(editorRoleId != null)
				{
					hs = new HashMap<String, String>();
					hs.put(RoleFeatureConstants.ROLE_ID, editorRoleId.toString());
					hs.put(RoleFeatureConstants.FEATURE_ID, featureId.toString());
					RoleFeature.createRoleFeature(hs);
				}
				
				if(projAdminRoleId != null)
				{
					hs = new HashMap<String, String>();
					hs.put(RoleFeatureConstants.ROLE_ID, projAdminRoleId.toString());
					hs.put(RoleFeatureConstants.FEATURE_ID, featureId.toString());
					RoleFeature.createRoleFeature(hs);
				}
				
				if(adminRoleId != null)
				{
					hs = new HashMap<String, String>();
					hs.put(RoleFeatureConstants.ROLE_ID, adminRoleId.toString());
					hs.put(RoleFeatureConstants.FEATURE_ID, featureId.toString());
					RoleFeature.createRoleFeature(hs);
				}
			}
		}
		catch(Exception ex){
			LOGGER.log(Level.SEVERE, "Exception occured in addRoleFeatureMapping "+ex.getMessage(),ex);
			ex.printStackTrace();
		}
		
		}*/
	
	
}
