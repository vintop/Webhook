//$Id$
package com.zoho.abtest.datamigration;

import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.sas.upgrade.isu.UpgradeHandler;
import com.zoho.abtest.ABSPLITEXPERIMENT;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentType;
import com.zoho.abtest.utility.ZABUtil;

public class ExperimentHierarchyUgradeHandler extends UpgradeHandler
{
	private static final Logger LOGGER = Logger.getLogger(ExperimentHierarchyUgradeHandler.class.getName());
	
	public void handleTableUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into handleTableUpdates :" + oldVersion + ":" + isReverting);
	}
	
	public void handleCustomerDataUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
		try
		{
			ZABUtil.setIsSchedulerJob(Boolean.TRUE);
			migrateExperimentHierarchyData();
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in handleCustomerDataUpdates : "+ex.getMessage(), ex);
		}
		LOGGER.log(Level.INFO, "Completed handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
	}
	
	public void migrateExperimentHierarchyData()
	{
		try
		{
			LOGGER.log(Level.INFO, "Commented as it is no longer needed");
			/*
			Criteria criteria = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_TYPE), new Integer[]{ExperimentType.ABTEST.getTypeNumber(),ExperimentType.SPLITURL.getTypeNumber()}, QueryConstants.IN);
			DataObject dataObj = ZABModel.getRow(EXPERIMENT.TABLE, criteria);
			Iterator<?> iterator = dataObj.getRows(EXPERIMENT.TABLE);
			while(iterator.hasNext())
			{
				Row row = (Row)iterator.next();
				HashMap<String, String> hs = new HashMap<String, String>();
				
				Long experimentId = (Long)row.get(EXPERIMENT.EXPERIMENT_ID);
				String experimentUrl = (String)row.get(EXPERIMENT.EXPERIMENT_URL);
				String excludedUrls = (String)row.get(EXPERIMENT.EXCLUDE_URLS);
				String includedUrls = (String)row.get(EXPERIMENT.INCLUDE_URLS);
				Integer permittedTraffic = (Integer)row.get(EXPERIMENT.PERMITTED_TRAFFIC);
				Integer statisticalSignificance = (Integer)row.get(EXPERIMENT.SIGNIFICANCE_LEVEL);
				Integer expectedImprovement = (Integer)row.get(EXPERIMENT.EXPECTED_IMPROVEMENT);
				Integer conversionRate = (Integer)row.get(EXPERIMENT.CONVERSION_RATE);
				Long dailyVisitors = (Long)row.get(EXPERIMENT.DAILY_VISITORS);
				
				if(experimentId != null)
				{
					hs.put(ExperimentConstants.EXPERIMENT_ID, experimentId.toString());
				}
				hs.put(ExperimentConstants.EXPERIMENT_URL, experimentUrl);
				hs.put(ExperimentConstants.EXCLUDE_URLS, excludedUrls);
				hs.put(ExperimentConstants.INCLUDE_URLS, includedUrls);
				if(permittedTraffic != null)
				{
					hs.put(ExperimentConstants.PERMITTED_TRAFFIC, permittedTraffic.toString());
				}
				if(statisticalSignificance != null)
				{
					hs.put(ExperimentConstants.STATISTICAL_SIGNIFICANCE, statisticalSignificance.toString());
				}
				if(expectedImprovement != null)
				{
					hs.put(ExperimentConstants.EXPECTED_IMPROVEMENT, expectedImprovement.toString());
				}
				if(conversionRate != null)
				{
					hs.put(ExperimentConstants.CONVERSION_RATE, conversionRate.toString());
				}
				if(dailyVisitors != null)
				{
					hs.put(ExperimentConstants.DAILY_VISITORS, dailyVisitors.toString());
				}
				
				try
				{
					ZABModel.createRow(ExperimentConstants.ABSPLITEXPERIMENT_TABLE, ABSPLITEXPERIMENT.TABLE, hs);
				}
				catch(Exception ex)
				{
					LOGGER.log(Level.SEVERE, " Exception While creating ABSplit row ExpId:"+experimentId);
					LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
				}
			}
		*/}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, " Exception occurred in migrateExperimentHierarchyData");
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
	}
}
