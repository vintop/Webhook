//$Id$
package com.zoho.abtest.datamigration;

import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.iam.ServiceOrg;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.sas.ds.SASThreadLocal;
import com.adventnet.sas.upgrade.isu.UpgradeHandler;
import com.zoho.abtest.PORTAL_LICENSE_MAPPING;
import com.zoho.abtest.PROJECT;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.portal.Portal;
import com.zoho.abtest.project.ProjectJSONService;
import com.zoho.abtest.project.ProjectTreeEventConstants.Module;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUtil;

public class AWSScriptUpdgradeHandler extends UpgradeHandler
{
	private static final Logger LOGGER = Logger.getLogger(AWSScriptUpdgradeHandler.class.getName());

	public void handleTableUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into handleTableUpdates :" + oldVersion + ":" + isReverting);
	}
	
	public void handleCustomerDataUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
		try
		{
			String dbSpaceName = SASThreadLocal.getLoginName();
//			ZABUtil.setIsSchedulerJob(Boolean.TRUE);
			//TODO
			if(StringUtils.isNotEmpty(dbSpaceName) && !dbSpaceName.equals("sharedspace"))
			{
				Portal.regenerateScriptsinPortal(dbSpaceName);
			}
			LOGGER.log(Level.INFO, "Completed handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in handleCustomerDataUpdates : "+ex.getMessage(), ex);
		}
	}
	
}
