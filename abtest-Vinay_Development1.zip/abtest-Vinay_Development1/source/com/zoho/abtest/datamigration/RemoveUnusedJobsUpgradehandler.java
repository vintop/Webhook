//$Id$
package com.zoho.abtest.datamigration;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.sas.ds.SASThreadLocal;
import com.adventnet.sas.upgrade.isu.UpgradeHandler;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.scheduler.Job;
import com.zoho.scheduler.JobScheduler;

public class RemoveUnusedJobsUpgradehandler  extends UpgradeHandler
{
	private static final Logger LOGGER = Logger.getLogger(RemoveUnusedJobsUpgradehandler.class.getName());
	
	public void handleTableUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into handleTableUpdates :" + oldVersion + ":" + isReverting);
	}
	
	public void handleCustomerDataUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "START handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
		//Setting this to use the existing dbpace set by SAS
		ZABUtil.setIsSchedulerJob(Boolean.TRUE);
		try
		{
			removeJob("RawTableGenerationSchedule"); //No I18N
			removeJob("RawTableCleanupSchedule"); //No I18N
			removeJob("CumulateRawdataSummaryOnHourSchedule"); //No I18N
			removeJob("ArchiveRawDataByDimensionsOnHourSchedule"); //No I18N
			removeJob("ReportHourTableCleanupOnDaySchedule"); //No I18N
			removeJob("CumulateRawdataSummaryOnDaySchedule"); //No I18N
			removeJob("ArchiveRawDataByDimensionsOnDaySchedule"); //No I18N
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in handleCustomerDataUpdates : "+ex.getMessage(), ex);
		}
		LOGGER.log(Level.INFO, "END handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
	}
	
	public void removeJob(String repetitionName)
	{
		String schemaName = "";
		try
		{
			schemaName = SASThreadLocal.getLoginName();
			JobScheduler jobScheduler = JobScheduler.getInstance("abtestthreadpool");
			Job job = jobScheduler.fetchJob(repetitionName);
			Long jobId = job.getJobID();
			jobScheduler.delete(jobId);
			LOGGER.log(Level.INFO, "{0} - {1} - Job deleted successfully ", new String[]{schemaName,jobId.toString()});
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, schemaName + " - Exception occurred in removeJob : "+ex.getMessage(), ex);
		}
	}
}
