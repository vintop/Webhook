//$Id$
package com.zoho.abtest.datamigration;

import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.iam.ServiceOrg;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.sas.ds.SASThreadLocal;
import com.adventnet.sas.upgrade.isu.UpgradeHandler;
import com.zoho.abtest.PORTAL_LICENSE_MAPPING;
import com.zoho.abtest.PROJECT;
import com.zoho.abtest.cdn.AWSCDN;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUtil;

public class AWSLExpirationPurgeUpgradeHandler  extends UpgradeHandler {
	
	private static final Logger LOGGER = Logger.getLogger(AWSScriptUpdgradeHandler.class.getName());

	public void handleTableUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into handleTableUpdates :" + oldVersion + ":" + isReverting);
	}
	
	public void handleCustomerDataUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
		try
		{
			String dbSpaceName = SASThreadLocal.getLoginName();
			//ZABUtil.setIsSchedulerJob(Boolean.TRUE);
			//TODO
			if(StringUtils.isNotEmpty(dbSpaceName) && !dbSpaceName.equals("sharedspace"))
			{
				ServiceOrg org = ZABServiceOrgUtil.getServiceOrg(dbSpaceName);
				if(org!=null) {
					Long zsoid = Long.parseLong(dbSpaceName);
					Criteria c1 = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.ZSOID), zsoid, QueryConstants.EQUAL);
					ZABUtil.setDBSpace("sharedspace"); //NO I18N
					DataObject dobj1 = ZABModel.getRow(PORTAL_LICENSE_MAPPING.TABLE, c1);
					
					if(dobj1.containsTable(PORTAL_LICENSE_MAPPING.TABLE)) {
						Row row = dobj1.getFirstRow(PORTAL_LICENSE_MAPPING.TABLE);
						Boolean isAppActive = (Boolean)row.get(PORTAL_LICENSE_MAPPING.IS_APP_ACTIVE);
						LOGGER.log(Level.INFO, "Checking license for portal::"+org.getDomains().get(0));
						if(!isAppActive) {
							String portalName = org.getDomains().get(0).getDomain();
							ZABUtil.setDBSpace(dbSpaceName);
							LOGGER.log(Level.INFO, "License expired for portal:"+portalName+"::zsoid:"+zsoid);
							DataObject dobj = ZABModel.getRow(PROJECT.TABLE, null);
							Iterator it = dobj.getRows(PROJECT.TABLE);
							int totalcounter = 0;
							int successcounter = 0;
							while(it.hasNext()) {
								totalcounter++;
								Row rowpro = (Row)it.next();
								String projectName = (String)rowpro.get(PROJECT.PROJECT_NAME);
								String projectKey = (String)rowpro.get(PROJECT.PROJECT_KEY);
								try {							
									String path = "js/" +Project.getAbsoluteScriptUrl(projectKey, portalName);
									AWSCDN cdn = new AWSCDN();
									cdn.deleteFile(path);
									successcounter++;
									LOGGER.log(Level.INFO, "Deleted file::"+path);
								} catch (Exception e) {
									LOGGER.log(Level.SEVERE, "Failed to upload script for project:" + projectName);
								}
							}
							
							LOGGER.log(Level.INFO, "Deleted file success stats" + successcounter + "/" + totalcounter+" for portal:"+portalName);
							
						}
					}
				}
			}
			LOGGER.log(Level.INFO, "Completed handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in handleCustomerDataUpdates : "+ex.getMessage(), ex);
		}
	}
	

}
