//$Id$
package com.zoho.abtest.datamigration;

import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.sas.upgrade.isu.UpgradeHandler;
import com.zoho.abtest.PROJECT;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.project.ProjectConstants;
import com.zoho.abtest.utility.ZABUtil;

public class ProjectkeyUpgradeHandler extends UpgradeHandler 
{
	private static final Logger LOGGER = Logger.getLogger(ProjectkeyUpgradeHandler.class.getName());
	
	public void handleTableUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into handleTableUpdates :" + oldVersion + ":" + isReverting);
	}
	
	public void handleCustomerDataUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
		ZABUtil.setIsSchedulerJob(Boolean.TRUE);
		try
		{
			DataObject dobj = ZABModel.getRow(PROJECT.TABLE, null);
			if(!dobj.isEmpty())
			{
				Iterator<?> it = dobj.getRows(PROJECT.TABLE);
				while(it.hasNext()) {
					Row row = (Row)it.next();
					String projectKey = (String)row.get(PROJECT.PROJECT_KEY);
					if(StringUtils.isEmpty(projectKey))
					{
						Long projectId = (Long)row.get(PROJECT.PROJECT_ID);
						projectKey = ZABModel.generateUniqueId(PROJECT.TABLE, PROJECT.PROJECT_KEY);
						HashMap<String, String> hs = new HashMap<String, String>();
						hs.put(ProjectConstants.PROJECT_KEY, projectKey);
						Criteria c = new Criteria(new Column(PROJECT.TABLE, PROJECT.PROJECT_ID), projectId, QueryConstants.EQUAL);
						ZABModel.updateRow(ProjectConstants.PROJECT_TABLE, PROJECT.TABLE, hs, c, ProjectConstants.API_MODULE);
					}
					
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in handleCustomerDataUpdates : "+ex.getMessage(), ex);
		}
		LOGGER.log(Level.INFO, "Completed handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
	}
	
}
