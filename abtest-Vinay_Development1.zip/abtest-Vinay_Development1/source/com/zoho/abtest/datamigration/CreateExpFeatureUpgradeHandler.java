//$Id$
package com.zoho.abtest.datamigration;

import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.sas.upgrade.isu.UpgradeHandler;
import com.zoho.abtest.user.Feature;
import com.zoho.abtest.user.Role;
import com.zoho.abtest.user.RoleFeature;
import com.zoho.abtest.user.RoleFeatureConstants;
import com.zoho.abtest.user.FeatureConstants.AppFeatures;
import com.zoho.abtest.user.RoleConstants.UserRoles;
import com.zoho.abtest.utility.ZABUtil;

public class CreateExpFeatureUpgradeHandler extends UpgradeHandler
{
	private static final Logger LOGGER = Logger.getLogger(CreateExpFeatureUpgradeHandler.class.getName());
	
	public void handleTableUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into handleTableUpdates :" + oldVersion + ":" + isReverting);
	}
	
	public void handleCustomerDataUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "START handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
		//Setting this to use the existing dbpace set by SAS
		ZABUtil.setIsSchedulerJob(Boolean.TRUE);
		try
		{
			updateExperimentFeature();
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in handleCustomerDataUpdates : "+ex.getMessage(), ex);
		}
		LOGGER.log(Level.INFO, "END handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
	}
	
	public void updateExperimentFeature() throws Exception
	{
		try
		{
			Long featureId = Feature.getFeatureId(AppFeatures.CREATEEXPERIMENT.getFeature());
			Long editorRoleId = Role.getRoleIdByName(UserRoles.EDITOR.getRole());
			if(editorRoleId != null && featureId != null)
			{
				boolean isMappingAlreadyExists = RoleFeature.isRoleFeatureExistsInDB(editorRoleId, featureId);
				if(!isMappingAlreadyExists)
				{
					LOGGER.log(Level.INFO, "Feature Role Update started");
					HashMap<String, String> hs = new HashMap<String, String>();
					
					hs.put(RoleFeatureConstants.ROLE_ID, editorRoleId.toString());
					hs.put(RoleFeatureConstants.FEATURE_ID, featureId.toString());
					RoleFeature.createRoleFeature(hs);
					
					LOGGER.log(Level.INFO, "Feature updated successfully");
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			throw ex;
		}
	}
}
