//$Id$
package com.zoho.abtest.datamigration;

import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.sas.upgrade.isu.UpgradeHandler;
import com.zoho.abtest.user.Feature;
import com.zoho.abtest.user.FeatureConstants;
import com.zoho.abtest.user.RoleFeature;
import com.zoho.abtest.user.RoleFeatureConstants;
import com.zoho.abtest.user.FeatureConstants.AppFeatures;
import com.zoho.abtest.user.Role;
import com.zoho.abtest.user.RoleConstants.UserRoles;
import com.zoho.abtest.utility.ZABUtil;

public class PublishExperimentUpgradeHandler extends UpgradeHandler
{
	private static final Logger LOGGER = Logger.getLogger(PublishExperimentUpgradeHandler.class.getName());
	
	public void handleTableUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into handleTableUpdates :" + oldVersion + ":" + isReverting);
	}
	
	public void handleCustomerDataUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "START handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
		//Setting this to use the existing dbpace set by SAS
		ZABUtil.setIsSchedulerJob(Boolean.TRUE);
		try
		{
			createNewFeature();
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in handleCustomerDataUpdates : "+ex.getMessage(), ex);
		}
		LOGGER.log(Level.INFO, "END handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
	}
	
	public Feature createNewFeature() throws Exception
	{
		Feature feature = null;
		try
		{
			boolean isFeatureAlreadyExists = Feature.isFeatureExistsInDB(AppFeatures.PUBLISHEXPERIMENT.getFeature());
			Long adminRoleId = Role.getRoleIdByName(UserRoles.ADMIN.getRole());
			if(adminRoleId != null && !isFeatureAlreadyExists)
			{
				LOGGER.log(Level.INFO, "Feature creation started");
				HashMap<String, String> hs = new HashMap<String, String>();
				hs.put(FeatureConstants.FEATURE_NAME, AppFeatures.PUBLISHEXPERIMENT.getFeature());
				hs.put(FeatureConstants.FEATURE_DESCRIPTION, AppFeatures.PUBLISHEXPERIMENT.getFeatureDescription());
				hs.put(FeatureConstants.ROLE_VALUE,AppFeatures.PUBLISHEXPERIMENT.getRoleValue().toString());
				feature = Feature.createFeature(hs);
				
				if(feature.getFeatureId() != null)
				{
					Long projAdminRoleId = Role.getRoleIdByName(UserRoles.PROJECTADMIN.getRole());
					
					if(projAdminRoleId != null)
					{
						hs = new HashMap<String, String>();
						hs.put(RoleFeatureConstants.ROLE_ID, projAdminRoleId.toString());
						hs.put(RoleFeatureConstants.FEATURE_ID, feature.getFeatureId().toString());
						RoleFeature.createRoleFeature(hs);
					}
					
					if(adminRoleId != null)
					{
						hs = new HashMap<String, String>();
						hs.put(RoleFeatureConstants.ROLE_ID, adminRoleId.toString());
						hs.put(RoleFeatureConstants.FEATURE_ID, feature.getFeatureId().toString());
						RoleFeature.createRoleFeature(hs);
					}
				}
				
				LOGGER.log(Level.INFO, "Feature created and mapped successfully:"+feature.getFeatureId());
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			throw ex;
		}
		return feature;
	}
}
