//$Id$
package com.zoho.abtest.datamigration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;

import com.adventnet.db.api.RelationalAPI;
import com.adventnet.sas.upgrade.isu.UpgradeHandler;
import com.zoho.abtest.report.RawDataTableDetails;
import com.zoho.abtest.report.ReportArchieveDimensionConstants.ReportModuleType;
import com.zoho.abtest.utility.ZABUtil;

public class GoalActivityIDUpgradeHandler extends UpgradeHandler
{
	private static final Logger LOGGER = Logger.getLogger(GoalActivityIDUpgradeHandler.class.getName());
	
	public void handleTableUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into handleTableUpdates :" + oldVersion + ":" + isReverting);
	}
	
	public void handleCustomerDataUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
		ZABUtil.setIsSchedulerJob(Boolean.TRUE);
		try
		{
			HashMap<Integer, String> hs = RawDataTableDetails.getAllActiveRawTables();
			String goalAchievedRawDataTable = hs.get(ReportModuleType.GOALACHIEVED.getModuleCode());
			if(StringUtils.isNotEmpty(goalAchievedRawDataTable))
			{
				String query = "ALTER TABLE "+goalAchievedRawDataTable+" ADD COLUMN ACTIVITY_ID CITEXT NOT NULL DEFAULT '0'";
				executeQuery(query);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in handleCustomerDataUpdates : "+ex.getMessage(), ex);
		}
		LOGGER.log(Level.INFO, "Completed handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
	}
	
	public void executeQuery(String query)
	{
		Connection conn = null;
		PreparedStatement stmt = null;
		try
		{
			RelationalAPI relapi = RelationalAPI.getInstance();
			conn = relapi.getConnection();
			stmt = conn.prepareStatement(query);
			stmt.execute();
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
		}
		finally
		{
			if (stmt != null)
			{
				try 
				{
					stmt.close();
				} catch (SQLException e) 
				{
					LOGGER.log(Level.SEVERE,e.getMessage(),e);
				}
			}
			if(conn!=null){
				try 
				{
					conn.close();
				} catch (SQLException e)
				{
					LOGGER.log(Level.SEVERE,e.getMessage(),e);
				}
			}
		}
	}
	
}
