//$Id$
package com.zoho.abtest.datamigration;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.iam.IAMUtil;
import com.adventnet.iam.User;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.sas.ds.SASThreadLocal;
import com.adventnet.sas.upgrade.isu.UpgradeHandler;
import com.zoho.abtest.ABSPLITEXPERIMENT;
import com.zoho.abtest.APP_USER;
import com.zoho.abtest.EXPERIMENT_HEATMAP;
import com.zoho.abtest.PROJECT;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.experiment.ABSplitExperiment;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.heatmaps.ExperimentEnabledHeatmap;
import com.zoho.abtest.heatmaps.HeatmapConstants;
import com.zoho.abtest.heatmaps.HeatmapExperiment;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.user.ZABUser;
import com.zoho.abtest.utility.ZABUtil;

public class ABHeatmapEnabledMigration  extends UpgradeHandler {
	
	private static final Logger LOGGER = Logger.getLogger(ABHeatmapEnabledMigration.class.getName());
	
	public void handleTableUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into handleTableUpdates :" + oldVersion + ":" + isReverting);
	}
	
	public void handleCustomerDataUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		String dbSpaceName = SASThreadLocal.getLoginName();
		LOGGER.log(Level.INFO, "Entered into handleCustomerDataUpdates : "+ dbSpaceName + ":" + oldVersion + ":" + isReverting);
		try
		{
			//ZABUtil.setIsSchedulerJob(Boolean.TRUE);
			ZABUtil.setDBSpace(dbSpaceName);
			if(StringUtils.isNotEmpty(dbSpaceName) && !dbSpaceName.equals("sharedspace"))
			{
				poplulateHeatmapExperiment();
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in handleCustomerDataUpdates : "+ dbSpaceName + ":" +ex.getMessage(), ex);
		}
		LOGGER.log(Level.INFO, "Completed handleCustomerDataUpdates :  "+ dbSpaceName + ":"  + oldVersion + ":" + isReverting);
	}
	
	public static void poplulateHeatmapExperiment() throws DataAccessException, Exception {
		
		//TOTAL CRUFT.. Added these chunk of code as hotfix
		Criteria c = new Criteria(new Column(ABSPLITEXPERIMENT.TABLE, ABSPLITEXPERIMENT.IS_HEATMAP_ENABLED), Boolean.TRUE, QueryConstants.EQUAL);
		DataObject dobj = ZABModel.getRow(ABSPLITEXPERIMENT.TABLE, c);
		if(dobj.containsTable(ABSPLITEXPERIMENT.TABLE)) {
			Iterator it = dobj.getRows(ABSPLITEXPERIMENT.TABLE);
			LOGGER.log(Level.INFO, "Heatmap Rows::"+dobj);
			while(it.hasNext()) {
				Row row = (Row)it.next();
				Long experimentId = (Long)row.get(ABSPLITEXPERIMENT.EXPERIMENT_ID);
				Criteria c1 = new Criteria(new Column(EXPERIMENT_HEATMAP.TABLE, EXPERIMENT_HEATMAP.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
				DataObject dobj1 =  ZABModel.getRow(EXPERIMENT_HEATMAP.TABLE, c1);
				if(!dobj1.containsTable(EXPERIMENT_HEATMAP.TABLE)) {
					LOGGER.log(Level.INFO, "Issue Dup Heatmap Rows::"+dobj1);
					HashMap<String, String> hs = new HashMap<String, String>();
					Experiment abexp = ABSplitExperiment.getExperimentById(experimentId);
					Criteria c2 = new Criteria(new Column(PROJECT.TABLE, PROJECT.PROJECT_ID), abexp.getProjectId(), QueryConstants.EQUAL);
					ArrayList<Project> pro = Project.getProjectByCriteria(c2);
					abexp.setProjectLinkname(pro.get(0).getProjectLinkName());
					
					Long uid = abexp.getCreateBy();
					
					LOGGER.log(Level.INFO, "Created ZUID "+uid);
					Criteria c3 = new Criteria(new Column(APP_USER.TABLE, APP_USER.USER_ID), uid, QueryConstants.EQUAL);
					ZABUser zabuser = ZABUser.getUserWithCriteria(c3).get(0);
					
					LOGGER.log(Level.INFO, "Current user"+zabuser);
					ZABUtil.setCurrentUser(zabuser);
					
					HashMap<String, String> heatmap = ABSplitExperiment.generateHashMapFromAbSplitExperimentObjForHeatmapExp(abexp,hs);
					if(abexp.getExperimentStatus()!=null) {						
						heatmap.put(ExperimentConstants.EXPERIMENT_STATUS, abexp.getExperimentStatus().toString());
					}
					heatmap.put(HeatmapConstants.HEATMAP_ENABLED_EXPERIMENT_ID.toLowerCase(),experimentId.toString());
					HeatmapExperiment hmExp = ExperimentEnabledHeatmap.createEnabledHeatmapExperiment(heatmap);
					if(hmExp.getSuccess()) {
						LOGGER.log(Level.INFO, "Heatmap mapping generated successfully");
					} else {
						LOGGER.log(Level.INFO, "Error creating heatmap experiment" + hmExp.getResponseString());
					}
				}
			}
		}
	}
}
