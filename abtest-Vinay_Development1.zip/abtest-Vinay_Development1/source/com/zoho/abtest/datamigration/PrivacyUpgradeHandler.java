//$Id$
package com.zoho.abtest.datamigration;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.sas.ds.SASThreadLocal;
import com.adventnet.sas.upgrade.isu.UpgradeHandler;
import com.zoho.abtest.privacyconsent.Privacy;
import com.zoho.abtest.utility.ZABUtil;

public class PrivacyUpgradeHandler extends UpgradeHandler{
	
private static final Logger LOGGER = Logger.getLogger(PrivacyUpgradeHandler.class.getName());
	
	public void handleTableUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into handleTableUpdates :" + oldVersion + ":" + isReverting);
	}
	
	public void handleCustomerDataUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "START handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
		String loginName = SASThreadLocal.getLoginName();
		//Setting this to use the existing dbpace set by SAS
		ZABUtil.setIsSchedulerJob(Boolean.TRUE);
		try
		{
			Privacy.migratePrivacyDetails();
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in handleCustomerDataUpdates : "+loginName+" "+ex.getMessage(), ex);
		}
		LOGGER.log(Level.INFO, "END handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
	}

}
