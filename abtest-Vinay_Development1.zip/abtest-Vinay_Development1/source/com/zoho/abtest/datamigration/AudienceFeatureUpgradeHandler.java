//$Id$
package com.zoho.abtest.datamigration;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.sas.ds.SASThreadLocal;
import com.adventnet.sas.upgrade.isu.UpgradeHandler;
import com.zoho.abtest.ATTRIBUTE_MATCHTYPE_MAPPING;
import com.zoho.abtest.AUDIENCE;
import com.zoho.abtest.AUDIENCE_ATTRIBUTE;
import com.zoho.abtest.AUDIENCE_ATTRIBUTE_MATCHTYPE;
import com.zoho.abtest.BROWSER_DETAIL;
import com.zoho.abtest.COUNTRY_DETAIL;
import com.zoho.abtest.DEVICE_DETAIL;
import com.zoho.abtest.INTEGRATION;
import com.zoho.abtest.LANGUAGE_DETAIL;
import com.zoho.abtest.MOBILE_DEVICE_DETAIL;
import com.zoho.abtest.OS_DETAIL;
import com.zoho.abtest.PROJECT_INTEGRATION;
import com.zoho.abtest.ROLES;
import com.zoho.abtest.audience.Audience;
import com.zoho.abtest.audience.AudienceAttribute;
import com.zoho.abtest.audience.AudienceAttributeConstants;
import com.zoho.abtest.audience.AudienceAttributeConstants.AudienceAttributes;
import com.zoho.abtest.audience.AudienceConstants;
import com.zoho.abtest.audience.AudienceMatchTypeConstants;
import com.zoho.abtest.audience.ProjectAudience;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.dimension.DimensionConstants;
import com.zoho.abtest.integration.IntegrationConstants;
import com.zoho.abtest.portal.PortalAction;
import com.zoho.abtest.user.Feature;
import com.zoho.abtest.user.FeatureConstants.AppFeatures;
import com.zoho.abtest.utility.ZABUtil;

public class AudienceFeatureUpgradeHandler extends UpgradeHandler
{
	private static final Logger LOGGER = Logger.getLogger(AudienceFeatureUpgradeHandler.class.getName());
	
	public void handleTableUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into handleTableUpdates :" + oldVersion + ":" + isReverting);
	}
	
	public void handleCustomerDataUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "START handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
		//Setting this to use the existing dbpace set by SASa
		ZABUtil.setIsSchedulerJob(Boolean.TRUE);
		try
		{
			//updateProjectAudience();
			//audienceDataPopulation();
			//updateAttributeKey();
			//deletedimensionvalues();
			//createAttributePreset();
			updateAudience();
			//updateSegment();
			//integrationPopulation();

			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in handleCustomerDataUpdates : "+ex.getMessage(), ex);
		}
		LOGGER.log(Level.INFO, "END handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
	}
	
	public void updateProjectAudience() throws Exception
	{
		Audience audience = null;
		Long audience_id = 0L;
		Boolean isPreSet = false;
		Long project_id = 0L;
				
		try{
			
			Criteria c = null;
			DataObject dobj = ZABModel.getRow(AUDIENCE.TABLE,c);
			if(dobj.containsTable(AUDIENCE.TABLE)) {
				Iterator<?> it = dobj.getRows(AUDIENCE.TABLE);
				while(it.hasNext()) {
					Row row = (Row)it.next();
					isPreSet = (Boolean)row.get(AUDIENCE.AUDIENCE_IS_PRESET);	
					audience_id = (Long)row.get(AUDIENCE.AUDIENCE_ID);
					if(isPreSet == null){
						Criteria c1 = new Criteria(new Column(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_ID), audience_id, QueryConstants.EQUAL);
						HashMap<String, String> hs = new HashMap<String, String>();
						hs.put(AudienceConstants.AUDIENCE_IS_PRESET, Boolean.FALSE.toString());
						Audience.updateRow(AudienceConstants.AUDIENCE_TABLE, AUDIENCE.TABLE, hs, c1, AudienceConstants.API_RESOURCE);
					}
					
					//ProjectAudience.createProjectAudienceWithoutEvent(audience_id,project_id);
				}
			}
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE, "Exception occured in updateProjectAudience "+ex.getMessage(),ex);
			throw ex;
		}
	}
	
	
	public static void audienceDataPopulation() throws Exception{
		
		Feature feature = null;
		String rolename = null;
		try
		{
			Criteria c = null;
			DataObject dobj = ZABModel.getRow(ROLES.TABLE,c);
			if(dobj.containsTable(ROLES.TABLE)) {
				Iterator<?> it = dobj.getRows(ROLES.TABLE);
				Row row = (Row)it.next();
				rolename = (String)row.get(ROLES.ROLE_NAME);
			}
			if(rolename != null){
				audiencePresetPopulation();
			}
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE, "Exception occured in audienceDataPopulation "+ex.getMessage(),ex);
			throw ex;
		}
		
	}
	
	public static void audiencePresetPopulation() throws Exception{
		
		try{			
			ArrayList<HashMap<String, String>> myList = new ArrayList<HashMap<String, String>>();
			
			String linkName = null;
			HashMap<String, String> data1 = new HashMap<String, String>();
			
			data1.put(AudienceConstants.AUDIENCE_NAME, "All"); //No I18N
			linkName = ZABModel.generateLinkName(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME, null, null, "All");//No I18N
			data1.put(AudienceConstants.AUDIENCE_LINKNAME, linkName);
			data1.put(AudienceConstants.AUDIENCE_DESCRIPTION, "All Visitors");
			data1.put(AudienceConstants.AUDIENCE_CONDITION_JSON, "{}");
			data1.put(AudienceConstants.AUDIENCE_IS_COUNTRY, Boolean.FALSE.toString());
			data1.put(AudienceConstants.AUDIENCE_IS_PRESET, Boolean.TRUE.toString());
					
			HashMap<String, String> data2 = new HashMap<String, String>();
			data2.put(AudienceConstants.AUDIENCE_NAME, "Direct Visitors"); //No I18N
			linkName = ZABModel.generateLinkName(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME, null, null, "Direct");//No I18N
			data2.put(AudienceConstants.AUDIENCE_LINKNAME, linkName);
			data2.put(AudienceConstants.AUDIENCE_DESCRIPTION, "Visitors who come to your website using bookmarks, browser history, favourites or direct URL entry.");
			data2.put(AudienceConstants.AUDIENCE_CONDITION_JSON, "{\"conditions\":[{\"conditions\":[{\"values\":[\"\"],\"type\":\"referral_url\",\"operator\":1}],\"condition_type\":1}],\"condition_type\":1}");
			data2.put(AudienceConstants.AUDIENCE_IS_COUNTRY, Boolean.FALSE.toString());
			data2.put(AudienceConstants.AUDIENCE_IS_PRESET, Boolean.TRUE.toString());

			HashMap<String, String> data3 = new HashMap<String, String>();
			data3.put(AudienceConstants.AUDIENCE_NAME, "Referral"); //No I18N
			linkName = ZABModel.generateLinkName(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME, null, null, "Referral");//No I18N
			data3.put(AudienceConstants.AUDIENCE_LINKNAME, linkName);
			data3.put(AudienceConstants.AUDIENCE_DESCRIPTION, "Visitors from links, buttons or ads put up in other websites");
			data3.put(AudienceConstants.AUDIENCE_CONDITION_JSON, "{\"conditions\":[{\"conditions\":[{\"values\":[\"\"],\"type\":\"referral_url\",\"operator\":2}],\"condition_type\":1}],\"condition_type\":1}");
			data3.put(AudienceConstants.AUDIENCE_IS_COUNTRY, Boolean.FALSE.toString());
			data3.put(AudienceConstants.AUDIENCE_IS_PRESET, Boolean.TRUE.toString());

					
			HashMap<String, String> data4 = new HashMap<String, String>();
			data4.put(AudienceConstants.AUDIENCE_NAME, "Social Traffic"); //No I18N
			linkName = ZABModel.generateLinkName(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME, null, null, "Social");//No I18N
			data4.put(AudienceConstants.AUDIENCE_LINKNAME, linkName);
			data4.put(AudienceConstants.AUDIENCE_DESCRIPTION, "Visitors from social media sites (Facebook, Linkedin, Twitter and Google Plus)");
			data4.put(AudienceConstants.AUDIENCE_CONDITION_JSON, "{\"conditions\":[{\"conditions\":[{\"values\":[\"facebook.com\",\"messenger.com\",\"plus.google.com\",\"plus.url.google.com\",\"t.co\",\"twitter.com\",\"instagram.com\",\"linkedin.com\",\"pinterest.com\",\"vk.com\"],\"type\":\"referral_url\",\"operator\":1}],\"condition_type\":1}],\"condition_type\":1}");
			data4.put(AudienceConstants.AUDIENCE_IS_COUNTRY, Boolean.FALSE.toString());
			data4.put(AudienceConstants.AUDIENCE_IS_PRESET, Boolean.TRUE.toString());

					
			HashMap<String, String> data5 = new HashMap<String, String>();
			data5.put(AudienceConstants.AUDIENCE_NAME, "Search Engine Traffic"); //No I18N
			linkName = ZABModel.generateLinkName(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME, null, null, "Search Engine");//No I18N
			data5.put(AudienceConstants.AUDIENCE_LINKNAME, linkName);
			data5.put(AudienceConstants.AUDIENCE_DESCRIPTION, "Visitors who landed on your website by clicking on web search results"); //No I18N
			data5.put(AudienceConstants.AUDIENCE_CONDITION_JSON, "{\"conditions\":[{\"conditions\":[{\"values\":[\"google.com\",\"yahoo.com\",\"bing.com\",\"aol.com\",\"aolsearch.com\",\"ask.com\",\"lycos.com\",\"about.com\",\"baidu.com\",\"yandex.\",\"seznam.cz\"],\"type\":\"referral_url\",\"operator\":1}],\"condition_type\":1}],\"condition_type\":1}");
			data5.put(AudienceConstants.AUDIENCE_IS_COUNTRY, Boolean.FALSE.toString());
			data5.put(AudienceConstants.AUDIENCE_IS_PRESET, Boolean.TRUE.toString());

					
			HashMap<String, String> data6 = new HashMap<String, String>();
			data6.put(AudienceConstants.AUDIENCE_NAME, "Mobile and Tablet Traffic"); //No I18N
			linkName = ZABModel.generateLinkName(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME, null, null, "Mobile and Tablet");//No I18N
			data6.put(AudienceConstants.AUDIENCE_LINKNAME, linkName);
			data6.put(AudienceConstants.AUDIENCE_DESCRIPTION, "Visitors from mobiles and tablets"); //No I18N
			data6.put(AudienceConstants.AUDIENCE_CONDITION_JSON, "{\"conditions\":[{\"conditions\":[{\"values\":[\"mobile\",\"tablet\"],\"type\":\"device_type\",\"operator\":1}],\"condition_type\":1}],\"condition_type\":1}");
			data6.put(AudienceConstants.AUDIENCE_IS_COUNTRY, Boolean.FALSE.toString());
			data6.put(AudienceConstants.AUDIENCE_IS_PRESET, Boolean.TRUE.toString());

					
			HashMap<String, String> data7 = new HashMap<String, String>();
			data7.put(AudienceConstants.AUDIENCE_NAME, "Desktop Visitors"); //No I18N
			linkName = ZABModel.generateLinkName(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME, null, null, "Desktop");//No I18N
			data7.put(AudienceConstants.AUDIENCE_LINKNAME, linkName);
			data7.put(AudienceConstants.AUDIENCE_DESCRIPTION, "Visitors from Desktop Devices"); //No I18N
			data7.put(AudienceConstants.AUDIENCE_CONDITION_JSON, "{\"conditions\":[{\"conditions\":[{\"values\":[\"desktop\"],\"type\":\"device_type\",\"operator\":1}],\"condition_type\":1}],\"condition_type\":1}");
			data7.put(AudienceConstants.AUDIENCE_IS_COUNTRY, Boolean.FALSE.toString());
			data7.put(AudienceConstants.AUDIENCE_IS_PRESET, Boolean.TRUE.toString());

					
			HashMap<String, String> data8 = new HashMap<String, String>();
			data8.put(AudienceConstants.AUDIENCE_NAME, "New Visitors"); //No I18N
			linkName = ZABModel.generateLinkName(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME, null, null, "New");//No I18N
			data8.put(AudienceConstants.AUDIENCE_LINKNAME, linkName);
			data8.put(AudienceConstants.AUDIENCE_DESCRIPTION, "Visitors who are landing on your website for the first time."); //No I18N
			data8.put(AudienceConstants.AUDIENCE_CONDITION_JSON, "{\"conditions\":[{\"conditions\":[{\"values\":[\"new\"],\"type\":\"visitor_type\",\"operator\":1}],\"condition_type\":1}],\"condition_type\":1}");
			data8.put(AudienceConstants.AUDIENCE_IS_COUNTRY, Boolean.FALSE.toString());
			data8.put(AudienceConstants.AUDIENCE_IS_PRESET, Boolean.TRUE.toString());

			HashMap<String, String> data9 = new HashMap<String, String>();
			data9.put(AudienceConstants.AUDIENCE_NAME, "Returning Visitors"); //No I18N
			linkName = ZABModel.generateLinkName(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME, null, null, "Returning");//No I18N
			data9.put(AudienceConstants.AUDIENCE_LINKNAME, linkName);
			data9.put(AudienceConstants.AUDIENCE_DESCRIPTION, "Prior visitors, who return to your website."); //No I18N
			data9.put(AudienceConstants.AUDIENCE_CONDITION_JSON, "{\"conditions\":[{\"conditions\":[{\"values\":[\"returning\"],\"type\":\"visitor_type\",\"operator\":1}],\"condition_type\":1}],\"condition_type\":1}");
			data9.put(AudienceConstants.AUDIENCE_IS_COUNTRY, Boolean.FALSE.toString());
			data9.put(AudienceConstants.AUDIENCE_IS_PRESET, Boolean.TRUE.toString());	
			
			myList.add(data1);
			myList.add(data2);
			myList.add(data3);
			myList.add(data4);
			myList.add(data5);
			myList.add(data6);
			myList.add(data7);
			myList.add(data8);
			myList.add(data9);

			
			ZABModel.createRow(AudienceConstants.AUDIENCE_TABLE, AUDIENCE.TABLE, myList);
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE, "Exception occured in AudiecePresetPopulation "+ex.getMessage(),ex);
			ex.printStackTrace();
		}
	}
	

	public static void createAttributePreset() throws Exception{
		
		try{		
			
			Criteria c = null;
			DataObject dobj = ZABModel.getRow(AUDIENCE_ATTRIBUTE_MATCHTYPE.TABLE,c);
			if(dobj.containsTable(AUDIENCE_ATTRIBUTE_MATCHTYPE.TABLE)) {
			int size = dobj.size(AUDIENCE_ATTRIBUTE_MATCHTYPE.TABLE);
			if(size < 5  && size >0){
				ArrayList<HashMap<String, String>> myList = new ArrayList<HashMap<String, String>>();
				
	
				HashMap<String, String> data1 = new HashMap<String, String>();
				data1.put(AudienceMatchTypeConstants.ATTRIBUTE_MATCHTYPE_ID, "5");
				data1.put(AudienceMatchTypeConstants.ATTRIBUTE_MATCHTYPE_NAME, "is empty");
				myList.add(data1);
	
				HashMap<String, String> data2 = new HashMap<String, String>();
				data2.put(AudienceMatchTypeConstants.ATTRIBUTE_MATCHTYPE_ID, "6");
				data2.put(AudienceMatchTypeConstants.ATTRIBUTE_MATCHTYPE_NAME, "is not empty");
				myList.add(data2);
				
				HashMap<String, String> data3 = new HashMap<String, String>();
				data3.put(AudienceMatchTypeConstants.ATTRIBUTE_MATCHTYPE_ID, "7");
				data3.put(AudienceMatchTypeConstants.ATTRIBUTE_MATCHTYPE_NAME, "is undefined");
				myList.add(data3);
				
				ZABModel.createRow(AudienceAttributeConstants.AUDIENCE_ATTRIBUTE_MATCHTYPE_TABLE, AUDIENCE_ATTRIBUTE_MATCHTYPE.TABLE, myList);
				
				ArrayList<HashMap<String, String>> myList1 = new ArrayList<HashMap<String, String>>();
				
				HashMap<String, String> data45 = new HashMap<String, String>();
				data45.put(AudienceAttributeConstants.ATTRIBUTE_ID, "14");
				data45.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "5");
	
				HashMap<String, String> data46 = new HashMap<String, String>();
				data46.put(AudienceAttributeConstants.ATTRIBUTE_ID, "14");
				data46.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "6");
				
				HashMap<String, String> data47 = new HashMap<String, String>();
				data47.put(AudienceAttributeConstants.ATTRIBUTE_ID, "14");
				data47.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "7");
	
				
				myList1.add(data45);
				myList1.add(data46);
				myList1.add(data47);
				
				
				ZABModel.createRow(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_MAPPING_TABLE, ATTRIBUTE_MATCHTYPE_MAPPING.TABLE, myList1);

				}
			}
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE, "Exception occured in createAttributePreset "+ex.getMessage(),ex);
			ex.printStackTrace();
		}
	}
	
	public static void updateAudience() throws Exception{
		
		try{		
			
//			Criteria c1 = new Criteria(new Column(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME), "all", QueryConstants.EQUAL); 
//			HashMap<String, String> hs1 = new HashMap<String, String>();
//			hs1.put(AudienceConstants.AUDIENCE_DESCRIPTION, "All the visitors reaching your website");
//			Audience.updateRow(AudienceConstants.AUDIENCE_TABLE, AUDIENCE.TABLE, hs1, c1, AudienceConstants.API_RESOURCE);
//			
//			Criteria c2 = new Criteria(new Column(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME), "direct", QueryConstants.EQUAL); 
//			HashMap<String, String> hs2 = new HashMap<String, String>();
//			//hs2.put(AudienceConstants.AUDIENCE_DESCRIPTION, "Visitors who reach your website using direct URL entry, browser history, bookmarks or favourites");
//			//hs2.put(AudienceConstants.AUDIENCE_CONDITION_JSON, "{\"conditions\":[{\"conditions\":[{\"values\":[\"direct visitors\"],\"type\":\"source\",\"operator\":1}],\"condition_type\":1}],\"condition_type\":1}");  //NO I18N
//			Audience.updateRow(AudienceConstants.AUDIENCE_TABLE, AUDIENCE.TABLE, hs2, c2, AudienceConstants.API_RESOURCE);
//			
//			Criteria c3 = new Criteria(new Column(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME), "referral", QueryConstants.EQUAL); 
//			HashMap<String, String> hs3 = new HashMap<String, String>();
//			//hs3.put(AudienceConstants.AUDIENCE_DESCRIPTION, "Visitors from ads, buttons or links on other sites");
//			hs3.put(AudienceConstants.AUDIENCE_CONDITION_JSON, "{\"conditions\":[{\"conditions\":[{\"values\":[\"referral traffic\"],\"type\":\"source\",\"operator\":2}],\"condition_type\":1}],\"condition_type\":1}");  //NO I18N
//			Audience.updateRow(AudienceConstants.AUDIENCE_TABLE, AUDIENCE.TABLE, hs3, c3, AudienceConstants.API_RESOURCE);
//			
//			Criteria c4 = new Criteria(new Column(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME), "social", QueryConstants.EQUAL); 
//			HashMap<String, String> hs4 = new HashMap<String, String>();
//			hs4.put(AudienceConstants.AUDIENCE_CONDITION_JSON, "{\"conditions\":[{\"conditions\":[{\"values\":[\"social traffic\"],\"type\":\"source\",\"operator\":1}],\"condition_type\":1}],\"condition_type\":1}");  //NO I18N
//			Audience.updateRow(AudienceConstants.AUDIENCE_TABLE, AUDIENCE.TABLE, hs4, c4, AudienceConstants.API_RESOURCE);
//			
//			Criteria c5 = new Criteria(new Column(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME), "mobile-and-tablet", QueryConstants.EQUAL); 
//			HashMap<String, String> hs5 = new HashMap<String, String>();
//			hs5.put(AudienceConstants.AUDIENCE_CONDITION_JSON, "{\"conditions\":[{\"conditions\":[{\"values\":[\"mobile\",\"tablet\"],\"type\":\"device_type\",\"operator\":1}],\"condition_type\":1}],\"condition_type\":1}");  //NO I18N
//			Audience.updateRow(AudienceConstants.AUDIENCE_TABLE, AUDIENCE.TABLE, hs5, c5, AudienceConstants.API_RESOURCE);
//			
//			Criteria c6 = new Criteria(new Column(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME), "desktop", QueryConstants.EQUAL); 
//			HashMap<String, String> hs6 = new HashMap<String, String>();
//			hs6.put(AudienceConstants.AUDIENCE_CONDITION_JSON, "{\"conditions\":[{\"conditions\":[{\"values\":[\"desktop\"],\"type\":\"device_type\",\"operator\":1}],\"condition_type\":1}],\"condition_type\":1}");  //NO I18N
//			Audience.updateRow(AudienceConstants.AUDIENCE_TABLE, AUDIENCE.TABLE, hs6, c6, AudienceConstants.API_RESOURCE);
//			
//			Criteria c7 = new Criteria(new Column(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME), "new", QueryConstants.EQUAL); 
//			HashMap<String, String> hs7 = new HashMap<String, String>();
//			hs7.put(AudienceConstants.AUDIENCE_DESCRIPTION, "Visitors who reach your website for the first time");
//			Audience.updateRow(AudienceConstants.AUDIENCE_TABLE, AUDIENCE.TABLE, hs7, c7, AudienceConstants.API_RESOURCE);
//			
//			Criteria c8 = new Criteria(new Column(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME), "returning", QueryConstants.EQUAL); 
//			HashMap<String, String> hs8 = new HashMap<String, String>();
//			hs8.put(AudienceConstants.AUDIENCE_DESCRIPTION, "Visitors returning to your website");
//			Audience.updateRow(AudienceConstants.AUDIENCE_TABLE, AUDIENCE.TABLE, hs8, c8, AudienceConstants.API_RESOURCE);
//			
//			Criteria c9 = new Criteria(new Column(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME), "organic-search", QueryConstants.EQUAL); 
//			HashMap<String, String> hs9 = new HashMap<String, String>();
//			hs9.put(AudienceConstants.AUDIENCE_CONDITION_JSON, "{\"conditions\":[{\"conditions\":[{\"values\":[\"organic search\"],\"type\":\"source\",\"operator\":1}],\"condition_type\":1}],\"condition_type\":1}");  //NO I18N
//			Audience.updateRow(AudienceConstants.AUDIENCE_TABLE, AUDIENCE.TABLE, hs9, c9, AudienceConstants.API_RESOURCE);
//			
			Criteria c10 = new Criteria(new Column(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME), "paid-search", QueryConstants.EQUAL); 
			HashMap<String, String> hs10 = new HashMap<String, String>();
			//hs10.put(AudienceConstants.AUDIENCE_CONDITION_JSON, "{\"conditions\":[{\"conditions\":[{\"values\":[\"paid search\"],\"type\":\"source\",\"operator\":1}],\"condition_type\":1}],\"condition_type\":1}");  //NO I18N
			hs10.put(AudienceConstants.AUDIENCE_NAME, "Paid Campaigns");  //NO I18N
			Audience.updateRow(AudienceConstants.AUDIENCE_TABLE, AUDIENCE.TABLE, hs10, c10, AudienceConstants.API_RESOURCE);
			
			
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE, "Exception occured in updateAudience "+ex.getMessage(),ex);
			ex.printStackTrace();
		}
	}	
	
	public static void updateSegment() throws Exception{
		try{		
			
			Criteria c1 = new Criteria(new Column(AUDIENCE_ATTRIBUTE.TABLE, AUDIENCE_ATTRIBUTE.ATTRIBUTE_ID), "11", QueryConstants.EQUAL); 
			HashMap<String, String> hs1 = new HashMap<String, String>();
			hs1.put(AudienceAttributeConstants.ATTRIBUTE_DISPLAYNAME, AudienceAttributes.LOCATION.getDisplayName());
			hs1.put(AudienceAttributeConstants.ATTRIBUTE_KEYNAME, AudienceAttributes.LOCATION.getKeyName());
			AudienceAttribute.updateRow(AudienceAttributeConstants.AUDIENCE_ATTRIBUTE_TABLE, AUDIENCE_ATTRIBUTE.TABLE, hs1, c1, AudienceAttributeConstants.API_RESOURCE);
		
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE, "Exception occured in updateSegment "+ex.getMessage(),ex);
			ex.printStackTrace();
		}
		
	}
	public static void updateAttributeKey() throws Exception{
		
		AudienceAttribute audienceattribute = null;
		int attribute_id = 0;
		String attribute_keyname = "";
		String attribute_displayname = "";
		try{
			
			Criteria c = null;
			DataObject dobj = ZABModel.getRow(AUDIENCE_ATTRIBUTE.TABLE,c);
			if(dobj.containsTable(AUDIENCE_ATTRIBUTE.TABLE)) {
				Iterator<?> it = dobj.getRows(AUDIENCE_ATTRIBUTE.TABLE);
				while(it.hasNext()) {
					Row row = (Row)it.next();
					attribute_id = (Integer)row.get(AUDIENCE_ATTRIBUTE.ATTRIBUTE_ID);
					if(attribute_id == 8){
						attribute_keyname = "mobile_os"; //No I18N
						attribute_displayname = "Mobile OS"; //No I18N
						
						Criteria c1 = new Criteria(new Column(AUDIENCE_ATTRIBUTE.TABLE, AUDIENCE_ATTRIBUTE.ATTRIBUTE_ID), attribute_id, QueryConstants.EQUAL);
						HashMap<String, String> hs = new HashMap<String, String>();
						hs.put(AudienceAttributeConstants.ATTRIBUTE_KEYNAME, attribute_keyname);
						hs.put(AudienceAttributeConstants.ATTRIBUTE_DISPLAYNAME, attribute_displayname);
						AudienceAttribute.updateRow(AudienceAttributeConstants.AUDIENCE_ATTRIBUTE_TABLE, AUDIENCE_ATTRIBUTE.TABLE, hs, c1, AudienceAttributeConstants.API_RESOURCE);
					}
					
				}
			}
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE, "Exception occured in updateProjectKey"+ex.getMessage(),ex);
			throw ex;
		}
		
	}
	
	public void deletedimensionvalues() throws Exception
	{
		
		String dbSpaceId = SASThreadLocal.getLoginName();
		//ZABUtil.setDBSpace("sharedspace");	
		if(dbSpaceId!=null && dbSpaceId.equals("sharedspace")){ 
			
			try{
				
				Criteria c1 = new Criteria(new Column(BROWSER_DETAIL.TABLE, BROWSER_DETAIL.BROWSER_CODE), "7", QueryConstants.EQUAL);
				DataObject dobj1 = ZABModel.getRow(BROWSER_DETAIL.TABLE, c1);
				if(dobj1.containsTable(BROWSER_DETAIL.TABLE)) {
					Row row = dobj1.getFirstRow(BROWSER_DETAIL.TABLE);
					ZABModel.deleteResource(row);
				}
				
				
				Criteria c2 = new Criteria(new Column(BROWSER_DETAIL.TABLE, BROWSER_DETAIL.BROWSER_CODE), "8", QueryConstants.EQUAL);
				DataObject dobj2 = ZABModel.getRow(BROWSER_DETAIL.TABLE, c2);
				if(dobj2.containsTable(BROWSER_DETAIL.TABLE)) {
					Row row = dobj2.getFirstRow(BROWSER_DETAIL.TABLE);
					ZABModel.deleteResource(row);
				}
				
				Criteria c3 = new Criteria(new Column(BROWSER_DETAIL.TABLE, BROWSER_DETAIL.BROWSER_CODE), "9", QueryConstants.EQUAL);
				DataObject dobj3 = ZABModel.getRow(BROWSER_DETAIL.TABLE, c3);
				if(dobj3.containsTable(BROWSER_DETAIL.TABLE)) {
					Row row = dobj3.getFirstRow(BROWSER_DETAIL.TABLE);
					ZABModel.deleteResource(row);
				}
				
				Criteria c4 = new Criteria(new Column(BROWSER_DETAIL.TABLE, BROWSER_DETAIL.BROWSER_CODE), "10", QueryConstants.EQUAL);
				DataObject dobj4 = ZABModel.getRow(BROWSER_DETAIL.TABLE, c4);
				if(dobj4.containsTable(BROWSER_DETAIL.TABLE)) {
					Row row = dobj4.getFirstRow(BROWSER_DETAIL.TABLE);
					ZABModel.deleteResource(row);
				}
			
				//Criteria c1 = new Criteria(new Column(BROWSER_DETAIL.TABLE, BROWSER_DETAIL.BROWSER_CODE), "6", QueryConstants.EQUAL);
				//HashMap<String, String> hs1 = new HashMap<String, String>();
				//hs1.put(DimensionConstants.BROWSER_VALUE, "Others");
				//AudienceAttribute.updateRow(DimensionConstants.BROWSER_DETAIL_CONSTANTS, BROWSER_DETAIL.TABLE, hs1, c1, DimensionConstants.API_MODULE);
				
			}catch(Exception ex){
				LOGGER.log(Level.SEVERE, "Exception occured in deletedimensionvalues "+ex.getMessage(),ex);
				throw ex;
			}
		}
	}
	
	
	public static void integrationPopulation() throws Exception{
		
		try
		{
			Criteria c = null;
			DataObject dobj = ZABModel.getRow(INTEGRATION.TABLE,c);
			if(dobj.containsTable(INTEGRATION.TABLE)) {
				int size = dobj.size(INTEGRATION.TABLE);
				if(size == 5){
					ArrayList<HashMap<String, String>> myList = new ArrayList<HashMap<String, String>>();

					HashMap<String, String> data2 = new HashMap<String, String>();
					data2.put(IntegrationConstants.INTEGRATION_ID, "6");
					data2.put(IntegrationConstants.INTEGRATION_NAME, "Google Tag Manager");
					data2.put(IntegrationConstants.INTEGRATION_DESCRIPTION, " ");
			
					myList.add(data2);
					
					ZABModel.createRow(IntegrationConstants.INTEGRATION_TABLE, INTEGRATION.TABLE, myList);
				}
				
			}
			
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE, "Exception occured in IntegrationPopulation "+ex.getMessage(),ex);
			throw ex;
		}
	}
	
	
}
