//$Id$
package com.zoho.abtest.datamigration;

import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.iam.ServiceOrg;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.sas.ds.SASThreadLocal;
import com.adventnet.sas.upgrade.isu.UpgradeHandler;
import com.zoho.abtest.CUSTOM_EVENT_GOAL;
import com.zoho.abtest.EVENTS;
import com.zoho.abtest.GOAL;
import com.zoho.abtest.PROJECT;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.customevent.CustomEvent;
import com.zoho.abtest.customevent.CustomEventConstants;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUtil;

public class CustomEventUpgradeHandler extends UpgradeHandler
{
	private static final Logger LOGGER = Logger.getLogger(AWSScriptUpdgradeHandler.class.getName());

	public void handleTableUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into CustomEventUpgradeHandler :" + oldVersion + ":" + isReverting);
	}
	
	public void handleCustomerDataUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into CustomEventUpgradeHandler :" + oldVersion + ":" + isReverting);
		try
		{
			String dbSpaceName = SASThreadLocal.getLoginName();
			ZABUtil.setIsSchedulerJob(Boolean.TRUE);
		
			if(StringUtils.isNotEmpty(dbSpaceName) && !dbSpaceName.equals("sharedspace"))
			{
				ServiceOrg org = ZABServiceOrgUtil.getServiceOrg(dbSpaceName);
				if(org!=null) {
				
					DataObject dobj = ZABModel.getRow(CUSTOM_EVENT_GOAL.TABLE, null);
					Iterator<?> it = dobj.getRows(CUSTOM_EVENT_GOAL.TABLE);
					while(it.hasNext()){
						
						try{
							Row row  = (Row)it.next();
							Long eventId =  (Long)row.get(CUSTOM_EVENT_GOAL.EVENT_ID);
							
							if(eventId == null ){
								String eventName = (String)row.get(CUSTOM_EVENT_GOAL.CUSTOM_EVENT_NAME);
								
								Join join1 = new Join(GOAL.TABLE, CUSTOM_EVENT_GOAL.TABLE, new String[]{GOAL.GOAL_ID}, new String[]{CUSTOM_EVENT_GOAL.GOAL_ID}, Join.INNER_JOIN);
								Join join2 = new Join(GOAL.TABLE, PROJECT.TABLE, new String[]{GOAL.PROJECT_ID}, new String[]{PROJECT.PROJECT_ID}, Join.INNER_JOIN);
								Criteria c = new Criteria(new Column(CUSTOM_EVENT_GOAL.TABLE, CUSTOM_EVENT_GOAL.CUSTOM_EVENT_NAME), eventName, QueryConstants.EQUAL);
						
								DataObject projDobj  = ZABModel.getRow(GOAL.TABLE, c, new Join[]{join1,join2});
								String projLinkName = (String)projDobj.getFirstValue(PROJECT.TABLE, PROJECT.PROJECT_LINK_NAME);
								
								HashMap<String, String> cusEventHs = new HashMap<String,String>();
								cusEventHs.put(CustomEventConstants.EVENT_NAME, eventName);
								cusEventHs.put(CustomEventConstants.PROJECT_LINKNAME, projLinkName);
								CustomEvent event = CustomEvent.createCustomEvent(cusEventHs);
								if(event.getSuccess()){
									Long cuseventId = event.getCustomEventId();
									row.set(CUSTOM_EVENT_GOAL.EVENT_ID, cuseventId);
									dobj.updateRow(row);
									
								}else{
									c = new Criteria(new Column(EVENTS.TABLE, EVENTS.EVENT_NAME), eventName, QueryConstants.EQUAL);
									DataObject cusDobj = ZABModel.getRow(EVENTS.TABLE, c);
									if(cusDobj.containsTable(EVENTS.TABLE)){
										Long cuseventId = (Long)cusDobj.getFirstValue(EVENTS.TABLE, EVENTS.EVENT_ID);
										row.set(CUSTOM_EVENT_GOAL.EVENT_ID, cuseventId);
										dobj.updateRow(row);
									}
								
								}
							
							}
						}catch(Exception e){
							LOGGER.log(Level.SEVERE, "Exception occurred in CustomEventUpgradeHandler : "+e.getMessage(), e);
						}
						
					}
					ZABModel.updateDataObject(dobj);
				}
			}
			LOGGER.log(Level.INFO, "Completed CustomEventUpgradeHandler :" + oldVersion + ":" + isReverting);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in CustomEventUpgradeHandler : "+ex.getMessage(), ex);
		}
	}
	
}
