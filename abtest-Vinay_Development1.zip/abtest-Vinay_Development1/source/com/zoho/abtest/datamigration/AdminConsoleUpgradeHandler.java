//$Id$
package com.zoho.abtest.datamigration;

import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.iam.ServiceOrg;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.sas.ds.SASThreadLocal;
import com.adventnet.sas.upgrade.isu.UpgradeHandler;
import com.zoho.abtest.APP_USER;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.PROJECT;
import com.zoho.abtest.adminconsole.AdminConsole;
import com.zoho.abtest.adminconsole.AdminConsoleConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentType;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUtil;

public class AdminConsoleUpgradeHandler extends UpgradeHandler
{
	private static final Logger LOGGER = Logger.getLogger(AdminConsoleUpgradeHandler.class.getName());
	
	public void handleTableUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into handleTableUpdates :" + oldVersion + ":" + isReverting);
	}
	
	public void handleCustomerDataUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		String dbSpaceName = SASThreadLocal.getLoginName();
		LOGGER.log(Level.INFO, "Entered into handleCustomerDataUpdates : "+ dbSpaceName + ":" + oldVersion + ":" + isReverting);
		try
		{
			//ZABUtil.setIsSchedulerJob(Boolean.TRUE);
			ZABUtil.setDBSpace(dbSpaceName);
			if(StringUtils.isNotEmpty(dbSpaceName) && !dbSpaceName.equals("sharedspace"))
			{
				Long zsoid = Long.parseLong(dbSpaceName);
				addSpaceDetailsToAdminConsole(zsoid);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in handleCustomerDataUpdates : "+ dbSpaceName + ":" +ex.getMessage(), ex);
		}
		LOGGER.log(Level.INFO, "Completed handleCustomerDataUpdates :  "+ dbSpaceName + ":"  + oldVersion + ":" + isReverting);
	}
	
	public void addSpaceDetailsToAdminConsole(Long zsoid)throws Exception
	{
		try
		{
			ServiceOrg serviceOrg = ZABServiceOrgUtil.getServiceOrg(zsoid);
			if(serviceOrg != null)
			{
				LOGGER.log(Level.INFO, "STARTED MIGRATION FOR {0}", new String[]{zsoid.toString()});
				//Adding Space details to AC
				HashMap<String, String> acHs = new HashMap<String, String>();
				acHs.put(AdminConsoleConstants.ZSOID, String.valueOf(serviceOrg.getZSOID()));
				acHs.put(AdminConsoleConstants.PORTAL_NAME, serviceOrg.getOrgName());
				if(serviceOrg.getDomains() != null)
				{
					acHs.put(AdminConsoleConstants.PORTAL_DOMAIN, serviceOrg.getDomains().get(0).getDomain());
				}
				acHs.put(AdminConsoleConstants.CREATED_ZUID, String.valueOf(serviceOrg.getCreatedBy()));
				acHs.put(AdminConsoleConstants.CREATED_TIME, String.valueOf(serviceOrg.getCreatedTime()));
				AdminConsole.createAcPortal(acHs);
				
				//Adding Project details to AC
				Join join1 = new Join(PROJECT.TABLE, APP_USER.TABLE, new String[]{PROJECT.CREATED_BY}, new String[]{APP_USER.USER_ID}, Join.INNER_JOIN);
				DataObject dataObj = ZABModel.getRow(PROJECT.TABLE, null, join1);
				Iterator<?> iterator = dataObj.getRows(PROJECT.TABLE);
				while(iterator.hasNext())
				{
					Row row= (Row)iterator.next();
					Long projectId = (Long)row.get(PROJECT.PROJECT_ID);
					Integer projectStatus = (Integer)row.get(PROJECT.STATUS);
					Long createdTime = (Long)row.get(PROJECT.CREATED_TIME);
					Long createdBy = (Long)row.get(PROJECT.CREATED_BY);
					Criteria criteria1 = new Criteria(new Column(APP_USER.TABLE, APP_USER.USER_ID), createdBy, QueryConstants.EQUAL);
					Long zuid = (Long)dataObj.getValue(APP_USER.TABLE, APP_USER.ZUID, criteria1);
					
					HashMap<String, String> projacHs = new HashMap<String, String>();
					projacHs.put(AdminConsoleConstants.PROJECT_ID, projectId.toString());
					projacHs.put(AdminConsoleConstants.PROJECT_STATUS, projectStatus.toString());
					projacHs.put(AdminConsoleConstants.ZSOID, zsoid.toString());
					projacHs.put(AdminConsoleConstants.CREATED_ZUID, zuid.toString());
					projacHs.put(AdminConsoleConstants.CREATED_TIME, createdTime.toString());
					AdminConsole.createAcProject(projacHs);
				}
				
				//Adding Experiment details to AC
				Join join2 = new Join(EXPERIMENT.TABLE, APP_USER.TABLE, new String[]{EXPERIMENT.CREATED_BY}, new String[]{APP_USER.USER_ID}, Join.INNER_JOIN);
				Integer[] types = new Integer[]{ExperimentType.ENABLED_HEATMAP.getTypeNumber()};
				Criteria criteria2 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_TYPE), types, QueryConstants.NOT_IN);
				DataObject dataObj2 = ZABModel.getRow(EXPERIMENT.TABLE, criteria2, join2);
				Iterator<?> iterator2 = dataObj2.getRows(EXPERIMENT.TABLE);
				while(iterator2.hasNext())
				{
					Row row= (Row)iterator2.next();
					Long expId = (Long)row.get(EXPERIMENT.EXPERIMENT_ID);
					Integer expStatus = (Integer)row.get(EXPERIMENT.EXPERIMENT_STATUS);
					Boolean isActive = (Boolean)row.get(EXPERIMENT.IS_ACTIVE);
					Integer expType = (Integer)row.get(EXPERIMENT.EXPERIMENT_TYPE);
					Long projId = (Long)row.get(EXPERIMENT.PROJECT_ID);
					Long createdTime = (Long)row.get(EXPERIMENT.CREATED_TIME);
					Long modifiedTime = (Long)row.get(EXPERIMENT.MODIFIED_TIME);
					if(modifiedTime == null)
					{
						modifiedTime = createdTime;
					}
					Long createdBy = (Long)row.get(EXPERIMENT.CREATED_BY);
					Criteria criteria3 = new Criteria(new Column(APP_USER.TABLE, APP_USER.USER_ID), createdBy, QueryConstants.EQUAL);
					Long zuid = (Long)dataObj2.getValue(APP_USER.TABLE, APP_USER.ZUID, criteria3);
					
					HashMap<String, String> expacHs = new HashMap<String, String>();
					expacHs.put(AdminConsoleConstants.EXPERIMENT_ID, expId.toString());
					expacHs.put(AdminConsoleConstants.EXPERIMENT_TYPE, expType.toString());
					expacHs.put(AdminConsoleConstants.EXPERIMENT_STATUS, expStatus.toString());
					expacHs.put(AdminConsoleConstants.IS_ACTIVE, isActive.toString());
					expacHs.put(AdminConsoleConstants.ZSOID, zsoid.toString());
					expacHs.put(AdminConsoleConstants.PROJECT_ID, projId.toString());
					expacHs.put(AdminConsoleConstants.CREATED_ZUID, zuid.toString());
					expacHs.put(AdminConsoleConstants.CREATED_TIME, createdTime.toString());
					expacHs.put(AdminConsoleConstants.MODIFIED_TIME, modifiedTime.toString());
					AdminConsole.createAcExperiment(expacHs);
				}
				LOGGER.log(Level.INFO, "COMPLETED MIGRATION FOR {0}", new String[]{zsoid.toString()});
			}
			else
			{
				LOGGER.log(Level.SEVERE, "No such service org exists - {0}", new String[]{zsoid.toString()});
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			throw ex;
		}
	}
}
