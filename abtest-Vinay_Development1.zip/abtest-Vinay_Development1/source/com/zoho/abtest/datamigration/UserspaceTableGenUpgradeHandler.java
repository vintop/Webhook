//$Id$
package com.zoho.abtest.datamigration;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.mfw.bean.BeanUtil;
import com.adventnet.sas.ds.SASThreadLocal;
import com.adventnet.sas.upgrade.isu.UpgradeHandler;
import com.zoho.abtest.utility.ZABTableCreationBean;
import com.zoho.abtest.utility.ZABUtil;

public class UserspaceTableGenUpgradeHandler extends UpgradeHandler
{
	private static final Logger LOGGER = Logger.getLogger(UserspaceTableGenUpgradeHandler.class.getName());
	
	public void handleTableUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into handleTableUpdates :" + oldVersion + ":" + isReverting);
	}
	
	public void handleCustomerDataUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
		ZABUtil.setIsSchedulerJob(Boolean.TRUE);
		try
		{
			if(!isReverting)
			{
				LOGGER.log(Level.INFO, "Table creation started for this DBSpace" + SASThreadLocal.getLoginName());
				createRawTables();
				LOGGER.log(Level.INFO, "Table creation completed for this DBSpace" + SASThreadLocal.getLoginName());
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in handleCustomerDataUpdates : "+ex.getMessage(), ex);
		}
		LOGGER.log(Level.INFO, "Completed handleCustomerDataUpdates :" + oldVersion + ":" + isReverting);
	}
	
	public void createRawTables() throws Exception
	{
		String dbSpaceId = SASThreadLocal.getLoginName();
		ZABTableCreationBean userAction = (ZABTableCreationBean)BeanUtil.lookup("ZABTableCreationBean");
		userAction.createReportRawDataTables(dbSpaceId);
		userAction.createCombinationJsonTables(dbSpaceId);
		userAction.createReportArchiveVisitorIdsTables(dbSpaceId);
	}
}

