//$Id$
package com.zoho.abtest.datamigration;

import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.iam.ServiceOrg;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.sas.ds.SASThreadLocal;
import com.adventnet.sas.upgrade.isu.UpgradeHandler;
import com.zoho.abtest.GOAL;
import com.zoho.abtest.PROJECT_GOAL;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.goal.GoalConstants;
import com.zoho.abtest.goal.GoalConstants.GoalType;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUtil;

public class ProjectGoalUrlTargettingHandler extends UpgradeHandler
{
	private static final Logger LOGGER = Logger.getLogger(ProjectGoalUrlTargettingHandler.class.getName());

	public void handleTableUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into ProjectGoalUrlTargettingHandler :" + oldVersion + ":" + isReverting);
	}
	
	public void handleCustomerDataUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		LOGGER.log(Level.INFO, "Entered into ProjectGoalUrlTargettingHandler :" + oldVersion + ":" + isReverting);
		try
		{
			
			String dbSpaceName = SASThreadLocal.getLoginName();
			ZABUtil.setIsSchedulerJob(Boolean.TRUE);
		
			if(StringUtils.isNotEmpty(dbSpaceName) && !dbSpaceName.equals("sharedspace"))
			{
				ServiceOrg org = ZABServiceOrgUtil.getServiceOrg(dbSpaceName);
				if(org!=null) {
				
					Criteria projGoalCri = new Criteria(new Column(GOAL.TABLE,GOAL.IS_PROJECT_LEVEL),Boolean.TRUE,QueryConstants.EQUAL);
					Criteria customGoalCri = new Criteria(new Column(GOAL.TABLE,GOAL.GOAL_TYPE_FLAG),GoalType.CUSTOM_EVENT_GOAL.getGoalTypeId() ,QueryConstants.EQUAL);
					DataObject dobj = ZABModel.getRow(GOAL.TABLE, projGoalCri.and(customGoalCri));
					Iterator<?> it = dobj.getRows(GOAL.TABLE);
					while(it.hasNext()){
						try{
							Row row  = (Row)it.next();
							Long goalid =  (Long)row.get(GOAL.GOAL_ID);
							
							Criteria checkvalidationExists = new Criteria(new Column(PROJECT_GOAL.TABLE,PROJECT_GOAL.GOAL_ID),goalid,QueryConstants.EQUAL);
							DataObject validationDobj = ZABModel.getRow(PROJECT_GOAL.TABLE, checkvalidationExists);
							if(!validationDobj.containsTable(PROJECT_GOAL.TABLE)){
								HashMap<String,String> urlTragetHs = new HashMap<String,String>();
								urlTragetHs.put(GoalConstants.GOAL_ID, goalid.toString());
								urlTragetHs.put(GoalConstants.GOAL_URL, "*");
								urlTragetHs.put(GoalConstants.INCLUDE_URLS, "[]");
								urlTragetHs.put(GoalConstants.EXCLUDE_URLS, "[]");
								ZABModel.createRow(GoalConstants.PROJECT_GOAL_TABLE, PROJECT_GOAL.TABLE, urlTragetHs);
							}	
							
						}catch(Exception e){
							LOGGER.log(Level.SEVERE, "Exception occurred in ProjectGoalUrlTargettingHandler : "+e.getMessage(), e);
						}
						
					}
				
				}
			}
			LOGGER.log(Level.INFO, "Completed ProjectGoalUrlTargettingHandler :" + oldVersion + ":" + isReverting);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in ProjectGoalUrlTargettingHandler : "+ex.getMessage(), ex);
		}
	}
	
}
