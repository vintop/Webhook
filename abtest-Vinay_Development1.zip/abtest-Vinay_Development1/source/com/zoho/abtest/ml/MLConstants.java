//$Id$
package com.zoho.abtest.ml;

public class MLConstants {

	public static final String ML_ERROR = "zo.forecast.error.general";	//NO I18N
	public static final String ML_LESS_VISITORS = "zo.forecast.error.less_visitors";//NO I18N
	public static final String ML_NON_RUNNING = "zo.forecast.error.not_running";//NO I18N
	public static final String ML_PAST_DATE = "zo.forecast.error.past_dates";//NO I18N
	public static final String ML_MIN_10_HRS = "zo.forecast.error.min_ten_hrs";//NO I18N
	public static final String ML_MIN_3_DAYS = "zo.forecast.error.min_three_days";//NO I18N
	
	
}
