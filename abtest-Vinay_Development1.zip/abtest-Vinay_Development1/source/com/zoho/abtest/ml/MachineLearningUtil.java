//$Id$
package com.zoho.abtest.ml;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.json.JSONArray;
import org.json.JSONObject;

import com.adventnet.iam.IAMUtil;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentStatus;
import com.zoho.abtest.report.ReportArchieveDimensionConstants;
import com.zoho.abtest.utility.ApplicationProperty;
import com.zoho.abtest.utility.ZABUtil;

public class MachineLearningUtil {
	
	private static final Logger LOGGER = Logger.getLogger(MachineLearningUtil.class.getName());
	public static Long accessTokenGeneratedTime = 0l ; 
	public static String accessToken = null; 
	public static Boolean shouldPredict(Long expId,  Long totalVisitorCount,Long filterEndDate ){
		
		/** Predict future trend only if 
		 * 
		 * Non Shared Report
		 * Minimum there are 500 visitors
		 * After three days of starting experiment
		 * If before three days, visitors count crosses 1000 => predict
		 * Experiment must be in running status
		 * Experiment report filter must contain, current end date
		 *
		 *
		 */
		//return true;
		
		if(IAMUtil.getCurrentTicket()==null){
			return false;
		}
		if(totalVisitorCount <= 500){	// If visitor count is less than 500 dont predict future trend
			return false;
		}
		Experiment exp = Experiment.getExperimentById(expId);
		if(!exp.getExperimentStatus().equals(ExperimentStatus.RUNNING.getStatusCode())){
			return false;
		}
		Long currentDate = ZABUtil.getDateInLongFromTime(ZABUtil.getCurrentTimeInMilliSeconds());
		filterEndDate = ZABUtil.getDateInLongFromTime(filterEndDate);
		if(!currentDate.equals(filterEndDate)){
			return false;
		}
		
		Long timeGapinMillis = Experiment.getActiveDurationOfExp(expId);
		Long hours = TimeUnit.MILLISECONDS.toHours(timeGapinMillis);
		
		if(totalVisitorCount>1000 &&  hours >10){
			return true;
		}
		
		//find experiment run duration
		if(hours>72){
			return true;
		}
		
		return false;
		
	}
	
	public static String predictFailureReason(Long expId,  Long totalVisitorCount,Long filterEndDate ){
		
		if(totalVisitorCount < 500){	// If visitor count is less than 500 dont predict future trend
			return MLConstants.ML_LESS_VISITORS;
		}
		Experiment exp = Experiment.getExperimentById(expId);
		if(!exp.getExperimentStatus().equals(ExperimentStatus.RUNNING.getStatusCode())){
			return  MLConstants.ML_NON_RUNNING;
		}
		Long currentDate = ZABUtil.getDateInLongFromTime(ZABUtil.getCurrentTimeInMilliSeconds());
		filterEndDate = ZABUtil.getDateInLongFromTime(filterEndDate);
		if(!currentDate.equals(filterEndDate)){
			return MLConstants.ML_PAST_DATE;
		}
		
		Long timeGapinMillis = Experiment.getActiveDurationOfExp(expId);
		Long hours = TimeUnit.MILLISECONDS.toHours(timeGapinMillis);
		
		if(totalVisitorCount>1000){
			if(hours<10){
				return MLConstants.ML_MIN_10_HRS;
			}
		}else{
			return MLConstants.ML_MIN_3_DAYS;
		}
		
		return MLConstants.ML_ERROR;
		
	}
	public static Long findTotalVisitorCount(HashMap<Long, HashMap<Long, HashMap<String, Long>>> visitorMeta){
		
		Long totalVisitorCount = 0l;
		Set<Long> variationIds  = visitorMeta.keySet();
		Iterator<Long> variationItr = variationIds.iterator();
		while(variationItr.hasNext()){
			Long varid = variationItr.next();
			HashMap<Long, HashMap<String, Long>> val = visitorMeta.get(varid);
			Set<Long> timeKeys = val.keySet();
			Iterator<Long> timeItr = timeKeys.iterator();
			while(timeItr.hasNext()){
				Long time  = timeItr.next();
				HashMap<String, Long> visitorDetails = val.get(time);
				Long count = visitorDetails.get(ReportArchieveDimensionConstants.UNIQUE_COUNT);
				totalVisitorCount += count;
			}
		}
		return totalVisitorCount;
	}

	/*public static JSONArray forecastPoints(JSONArray jsonarray){
		String accesstoken  = genacesstoken();
		return forecastPoints(jsonarray,"Zoho-oauthtoken "+accesstoken);	// NO I18N
				
	}*/
	
	public static JSONArray forecastPoints(JSONArray jsonarray) throws Exception{

		JSONArray forecastArray = new JSONArray();
		String postResp = null;
		HttpURLConnection httpcon = null;
		
		try{	
			//String targetURL = "https://ml.zoho.com/api/v1/algorithm/timeseries";  //No I18N

			String mlurl =  ApplicationProperty.getString("com.zoho.abtest.ml.url");
			if(mlurl.equals("XXX")){
				mlurl = "http://192.168.239.3:8080/Dynamic_Project";  //No I18N
			}
			
			mlurl = mlurl+"/api/v1/algorithm/timeseries";  //No I18N
		
			String postParams = "forecast=5&queryList="+jsonarray.toString()+"&frequency=4&ticket="+IAMUtil.getCurrentTicket();	// NO I18N
			
			URL obj = new URL(mlurl);
			httpcon = (HttpURLConnection) obj.openConnection();
			httpcon.setRequestMethod("POST");	// NO I18N
		//	httpcon.setRequestProperty("Authorization","Zoho-oauthtoken 1000.3ca83edf938fbfb20d745b8edd1197c4.332504d4731f77bb2da0401f67cd75e2");
			httpcon.setRequestProperty("User-Agent", "Mozilla/5.0");	// NO I18N
			httpcon.setRequestProperty("Accept-Charset",  java.nio.charset.StandardCharsets.UTF_8.name());	// NO I18N
			httpcon.setConnectTimeout(2000);
			
			// For POST only - START
			httpcon.setDoOutput(true);
			OutputStream os = httpcon.getOutputStream();
			os.write(postParams.getBytes());
			os.flush();
			os.close();
			// For POST only - END

			int responseCode = httpcon.getResponseCode();
			StringBuilder sb = new StringBuilder();
			if (responseCode == HttpURLConnection.HTTP_OK) { //success
				BufferedReader in = new BufferedReader(new InputStreamReader(httpcon.getInputStream(),"UTF-16"));	// NO I18N
			
				while ((postResp = in.readLine()) != null) {
					sb.append(postResp);
				}
				in.close();

				
			} else {
				LOGGER.log(Level.SEVERE,"Machine Learning Request Failed ");
				throw new Exception();
				
			}
			
			postResp = sb.toString();
			
	        JSONObject postresponse = new JSONObject(sb.toString());
		
			JSONObject dataJson =  postresponse.getJSONObject("data"); //No I18N
	        JSONArray itemsarray = dataJson.getJSONArray("items"); //No I18N
	        JSONObject predictedJson = (JSONObject) ((JSONObject) itemsarray.get(0)).get("1");
	        
	       if(predictedJson.has("bestFitModel")){
	    	   String bestFitModel = (String)predictedJson.get("bestFitModel"); //No I18N
		        if(bestFitModel.equals("ADDITIVE_MODEL")){
		        	forecastArray = predictedJson.getJSONArray("additiveForecasting"); //No I18N
		        }else if (bestFitModel.equals("MULTIPLICATIVE_MODEL")){
		        	forecastArray = predictedJson.getJSONArray("multiplicativeForecasting"); //No I18N
		        }
	       }else{
	    	   forecastArray = predictedJson.getJSONArray("nonSeasonalForecast"); //No I18N
	       }
	       
		}catch(Exception e){
			LOGGER.log(Level.SEVERE,"Machine Learning Forecast Response "+postResp,e);
			throw new Exception();
		}
		return forecastArray;
	
	}
	public static HashMap<Long,Long> convertJSONResponseToHMLL(JSONArray array){
		HashMap<Long,Long> forecastVisitorsHs = new HashMap<Long,Long>();
		
		try{
			for(int a=0;a<array.length();a++){
				String forecastpoint  = (String) array.get(a);
				StringTokenizer str = new StringTokenizer(forecastpoint, ",");
				Long date  = Long.parseLong(str.nextToken());
				Double visitorstemp = Double.parseDouble(str.nextToken());
				if(visitorstemp<0){
					visitorstemp = 0d;
				}
				forecastVisitorsHs.put(date, Math.round(visitorstemp));
			}
		}catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		
		return forecastVisitorsHs;
	}
	
	/*public static String getAccessTokenFromRefreshToken(){
		String accesstoken = null;
		try{

			
			
			 * com.zoho.abtest.ml.refresh_token=1000.4742fec6fb41cbf0b0c73615fafa94f3.d8d83e99a36bd21262f631c471cfc02d
			   com.zoho.abtest.ml.client_id=1000.AK5G0JQ67WG9029779DF0M0SU9BKRB
			   com.zoho.abtest.ml.client_secret=7cb3137b6a79daa1345c06e64276b20967dabb34ac
			   com.zoho.abtest.ml.redirect_uri=http://pagesense.zoho.com
			 * 
			 * 
			
			HttpClient httpclient = null;
			PostMethod post = null;
			String targetURL = "https://accounts.zoho.com/oauth/v2/token";  //No I18N
			post = new PostMethod(targetURL);
			
			post.setParameter("client_id",ApplicationProperty.getString("com.zoho.abtest.ml.client_id"));  //No I18N
			post.setParameter("client_secret",ApplicationProperty.getString("com.zoho.abtest.ml.client_secret"));  //No I18N
			post.setParameter("grant_type","refresh_token");  //No I18N
			post.setParameter("redirect_uri",ApplicationProperty.getString("com.zoho.abtest.ml.redirect_uri"));  //No I18N
			post.setParameter("refresh_token",ApplicationProperty.getString("com.zoho.abtest.ml.refresh_token"));  //No I18N
		
			httpclient = new HttpClient();
			httpclient.executeMethod(post);
			String postResp = post.getResponseBodyAsString();
			JSONObject json = new JSONObject(postResp);
			accesstoken =(String) json.get("access_token");	// NO I18N
			accessTokenGeneratedTime =  ZABUtil.getCurrentTimeInMilliSeconds();
			accessToken =accesstoken;

		}catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		return accesstoken;
	}
	public static  String genacesstoken(){
		if(accessToken == null){
			return getAccessTokenFromRefreshToken();
		}
		if(ZABUtil.getCurrentTimeInMilliSeconds()
		        - accessTokenGeneratedTime > 3000000){	// Acess token is valid for 1 hr. But we are replacing accesstoken at 55 minutes
			return getAccessTokenFromRefreshToken();
		}
		return accessToken;
	}*/
}
