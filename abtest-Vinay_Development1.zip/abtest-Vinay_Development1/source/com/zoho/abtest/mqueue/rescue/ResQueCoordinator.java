//$Id$
package com.zoho.abtest.mqueue.rescue;

import com.adventnet.persistence.Row;
import com.zoho.abtest.MQUEUE_RESCUE;
import com.zoho.abtest.common.ZABModel;

public class ResQueCoordinator {
	
	public static void addMqueueData(String module, String message) throws Exception {
		Row row = new Row(MQUEUE_RESCUE.TABLE);
		row.set(MQUEUE_RESCUE.MODULE_NAME, module);
		row.set(MQUEUE_RESCUE.MESSAGE, message);
		ZABModel.createResource(row);
	}
	
	public static void registerResQueThread(String module) throws Exception {
		ResQueHandler handler = new ResQueHandler(module);
		Thread t = new Thread(handler);
		t.start();
	}
}
