//$Id$
package com.zoho.abtest.mqueue.rescue;

public class ResQueConstants {

	public static final Integer SLEEP_TIMEOUT = 300000;
	
}
	