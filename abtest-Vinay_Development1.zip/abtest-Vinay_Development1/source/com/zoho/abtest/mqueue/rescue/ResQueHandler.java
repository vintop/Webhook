//$Id$
package com.zoho.abtest.mqueue.rescue;


import static com.zoho.abtest.mqueue.rescue.ResQueConstants.SLEEP_TIMEOUT;

import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.persistence.WritableDataObject;
import com.zoho.abtest.MQUEUE_RESCUE;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.listener.ZABListener;
import com.zoho.abtest.listener.ZABNotifier;
import com.zoho.abtest.utility.ZABUtil;

public class ResQueHandler implements Runnable {
	
	private static final Logger LOGGER = Logger.getLogger(ResQueHandler.class.getName());
	
	
	private String module;
	
	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	ResQueHandler(String module) {
		LOGGER.log(Level.INFO, "Registering ResQue thread for module:"+this.getModule());
		this.module = module;
	}
	
	private DataObject formDobj() throws Exception {
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		Criteria c = new Criteria(new Column(MQUEUE_RESCUE.TABLE, MQUEUE_RESCUE.MODULE_NAME), this.getModule(), QueryConstants.EQUAL);
		Criteria c2 = new Criteria(new Column(MQUEUE_RESCUE.TABLE, MQUEUE_RESCUE.IS_UPDATING), Boolean.FALSE, QueryConstants.EQUAL);
		DataObject dobj2 = ZABModel.getRow(MQUEUE_RESCUE.TABLE, c.and(c2));
		return dobj2;
	}
	
	private void processMessages(DataObject dobj) throws Exception {
		if(dobj.containsTable(MQUEUE_RESCUE.TABLE)) {
			LOGGER.log(Level.INFO, "Processing data in ResQue thread for module:"+this.getModule());
			Iterator it = dobj.getRows(MQUEUE_RESCUE.TABLE);
			while(it.hasNext()) {
				Row row = (Row)it.next();
				Long id = (Long)row.get(MQUEUE_RESCUE.MQUEUE_RESCUE_ID);
				Criteria c = new Criteria(new Column(MQUEUE_RESCUE.TABLE, MQUEUE_RESCUE.MQUEUE_RESCUE_ID), id, QueryConstants.EQUAL);
				DataObject dobj2 = ZABModel.getRow(MQUEUE_RESCUE.TABLE, c);
				if(dobj2.containsTable(MQUEUE_RESCUE.TABLE)) {
					row = dobj2.getFirstRow(MQUEUE_RESCUE.TABLE);					
					Boolean isUpdating = (Boolean) row.get(MQUEUE_RESCUE.IS_UPDATING);
					if(!isUpdating) {
						row.set(MQUEUE_RESCUE.IS_UPDATING, Boolean.TRUE);
						WritableDataObject wdobj = new WritableDataObject();
						wdobj.updateBlindly(row);
						ZABModel.updateDataObject(wdobj);
						String module = (String) row.get(MQUEUE_RESCUE.MODULE_NAME);
						String message = (String) row.get(MQUEUE_RESCUE.MESSAGE);
						Object object = ZABUtil.fromBase64String(message);
						ZABListener listener = ZABNotifier.getObservers().get(module);
						listener.processObject(object);
						ZABUtil.setDBSpace("sharedspace");	//No I18N
						ZABModel.deleteResource(row);
					}
				}
			}
			processMessages(formDobj());
		} else {
			LOGGER.log(Level.INFO, "No data in queue. Going to sleep mode. Will process data after:"+SLEEP_TIMEOUT+" ms");
			Thread.sleep(SLEEP_TIMEOUT);
			LOGGER.log(Level.INFO, "Woke up!!!! Going to process data");
			processMessages(formDobj());
		}
	}
	
	@Override
	public void run() {
		try {
			LOGGER.log(Level.INFO, "Starting ResQue for "+this.getModule());
			processMessages(formDobj());
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Exception occured", e);
			LOGGER.log(Level.SEVERE, "Resque thread is killed. Module name:"+this.getModule()+", Exception Trace:", e);
		}
	}

}
