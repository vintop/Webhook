//$Id$
package com.zoho.abtest.license;

import org.json.JSONArray;
import org.json.JSONObject;

import com.zoho.store.bean.SubscriptionBean;

public class SubscriptionImpl implements SubscriptionBean{

	@Override
	public JSONObject addSubscription(String arg0, JSONObject arg1)
			throws Exception {
		return SubscriptionUtil.addSubscription(arg0, arg1);
	}

	@Override
	public JSONObject cancelSubscription(String arg0, JSONObject arg1)
			throws Exception {
		return SubscriptionUtil.cancelSubscription(arg0);
	}

	@Override
	public JSONObject getServiceSubscriptionInfo(String arg0, long arg1)
			throws Exception {
		return SubscriptionUtil.getServiceSubscriptionInfo(arg0);
	}

	@Override
	public JSONObject modifySubscription(String arg0, JSONObject arg1)
			throws Exception {
		return SubscriptionUtil.modifySubscription(arg0, arg1);
	}
	
	@Override
	public JSONObject renewSubscription(JSONArray arg0) throws Exception {
		return SubscriptionUtil.renewSubscription(arg0);
	}
	
	@Override
	public JSONObject userPrivilege(long arg0, long arg1) throws Exception {
		return SubscriptionUtil.userPrivilege(arg0);
	}
	
	@Override
	public JSONObject setTrial(String arg0, JSONObject arg1) throws Exception {
		return SubscriptionUtil.setTrial(arg0, arg1);
	}
	
	@Override
	public JSONObject cancelTrial(String arg0, JSONObject arg1)
			throws Exception {
		return SubscriptionUtil.cancelTrial(arg0);
	}

	@Override
	public JSONObject cancelTrialInquiry(JSONArray arg0) throws Exception {
		return SubscriptionUtil.cancelTrialInquiry(arg0);
	}

	@Override
	public JSONObject extendTrialDuration(String arg0, JSONObject arg1)
			throws Exception {
		return SubscriptionUtil.extendTrialDuration(arg0, arg1);
	}
	
	@Override
	public JSONObject addUserToService(JSONObject arg0) throws Exception {
		return SubscriptionUtil.addUserToService(arg0);
	}
	
	@Override
	public JSONObject checkPortalName(String arg0, JSONObject arg1)
			throws Exception {
		return SubscriptionUtil.checkPortalName(arg0);
	}
	
	@Override
	public JSONObject changeProfileId(JSONArray arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JSONObject propagationSuccess(JSONObject arg0) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JSONObject subscriptionFromIntegService(JSONArray arg0)
			throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
