//$Id$
package com.zoho.abtest.license;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;
import org.apache.lucene.search.join.ScoreMode;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.NestedQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.cardinality.CardinalityAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.cardinality.InternalCardinality;
import org.json.JSONArray;
import org.json.JSONObject;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.iam.IAMProxy;
import com.adventnet.iam.IAMUtil;
import com.adventnet.iam.ServiceOrg;
import com.adventnet.iam.UserEmail;
import com.adventnet.iam.User;
import com.adventnet.iam.UserEmail;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.GOAL;
import com.zoho.abtest.LICENSE_DETAIL;
import com.zoho.abtest.PORTAL_LICENSE_MAPPING;
import com.zoho.abtest.PORTAL_LICENSE_YEARLY_DETAIL;
import com.zoho.abtest.adminconsole.AdminConsole;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.elastic.ElasticSearchStatistics;
import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentStatus;
import com.zoho.abtest.experiment.ExperimentHandler;
import com.zoho.abtest.forms.ElasticFormReport;
import com.zoho.abtest.forms.FormReportConstants;
import com.zoho.abtest.goal.Goal;
import com.zoho.abtest.goal.GoalConstants;
import com.zoho.abtest.goal.GoalConstants.GoalStatus;
import com.zoho.abtest.license.LicenseConstants.BCCMailers;
import com.zoho.abtest.license.LicenseConstants.License;
import com.zoho.abtest.license.LicenseConstants.MailToSendType;
import com.zoho.abtest.portal.Portal;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.project.ProjectConstants;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.sessionrecording.SessionElasticBand;
import com.zoho.abtest.sessionrecording.playlist.SessionPlayList;
import com.zoho.abtest.user.ZABUser;
import com.zoho.abtest.utility.ApplicationProperty;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUtil;

public class LicenseVerification
{
	private static final Logger LOGGER = Logger.getLogger(LicenseVerification.class.getName());
	private static final Integer VISITOR_PERCENTAGE_TO_MAIL = ApplicationProperty.getInteger("com.abtest.license.visitorpercent.mail"); //No I18N
	private static final String SENDER_SIGNATURE = ApplicationProperty.getString("com.abtest.mailer.signature"); //No I18N
	private static final String SENDER_MAIL_ID = ApplicationProperty.getString("com.abtest.mailer.id"); //No I18N
	private static final String SERVICE_URL = ApplicationProperty.getString("com.zoho.pagesense.serviceurl"); //No I18N
	
	//JOB 1
	public static void verifyUserLicenseStatus()
	{
		ZABUtil.setDBSpace("sharedspace");	//No I18N 
		try
		{
			//Do the check process based on portal
			Criteria criteria1 = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.IS_APP_ACTIVE), Boolean.TRUE, QueryConstants.EQUAL);
			Join join1 = new Join(PORTAL_LICENSE_MAPPING.TABLE, LICENSE_DETAIL.TABLE, new String[]{PORTAL_LICENSE_MAPPING.LICENSE_DETAIL_ID}, new String[]{LICENSE_DETAIL.LICENSE_DETAIL_ID}, Join.INNER_JOIN);
			//Join join2 = new Join(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_YEARLY_DETAIL.TABLE, new String[]{PORTAL_LICENSE_MAPPING.PORTAL_LICENSE_MAPPING_ID}, new String[]{PORTAL_LICENSE_YEARLY_DETAIL.PORTAL_LICENSE_MAPPING_ID}, Join.LEFT_JOIN);
			DataObject dataObj = ZABModel.getRow(PORTAL_LICENSE_MAPPING.TABLE, criteria1, new Join[]{join1});
			Iterator<?> iterator = dataObj.getRows(PORTAL_LICENSE_MAPPING.TABLE);
			while(iterator.hasNext())
			{
				Row row = (Row)iterator.next();
				PortalLicenseMapping portalLicenseMappingObj =  PortalLicenseMapping.getPortalLicenseMappingFromRow(row);
				Long zsoid = portalLicenseMappingObj.getZsoid();
				try
				{
					LOGGER.log(Level.INFO, "License verifiation started for - {0}", new String[]{zsoid.toString()});
					
					Long startTime = portalLicenseMappingObj.getStartTime();
					Long endTime = portalLicenseMappingObj.getEndTime();
					
					Criteria criteria2 = new Criteria(new Column(LICENSE_DETAIL.TABLE, LICENSE_DETAIL.LICENSE_DETAIL_ID), portalLicenseMappingObj.getLicenseDetailId(), QueryConstants.EQUAL);
					Row licenseDetailRow = dataObj.getRow(LICENSE_DETAIL.TABLE, criteria2);
					LicenseDetail licenseDetail = LicenseDetail.getLicenseDetailFromRow(licenseDetailRow);
					Integer licenseType = licenseDetail.getLicenseType();
					String licenseName = licenseDetail.getLicenseName();
					
					Long licenseVisitorCount = PortalLicenseAddon.getPlanVisitorCount(portalLicenseMappingObj.getPortalLicenseMappingId(), licenseDetail.getStorePlanId(),portalLicenseMappingObj.getIsAnnual());
					Long countToMail = (licenseVisitorCount * VISITOR_PERCENTAGE_TO_MAIL)/100;
					
					/*
					Long yearlyEndTime = null;
					if(portalLicenseMappingObj.getIsAnnual())
					{
						Criteria criteria3 = new Criteria(new Column(PORTAL_LICENSE_YEARLY_DETAIL.TABLE, PORTAL_LICENSE_YEARLY_DETAIL.PORTAL_LICENSE_MAPPING_ID), portalLicenseMappingObj.getPortalLicenseMappingId(), QueryConstants.EQUAL);
						Row yearlyRow = dataObj.getRow(PORTAL_LICENSE_YEARLY_DETAIL.TABLE, criteria3);
						yearlyEndTime = (Long)yearlyRow.get(PORTAL_LICENSE_YEARLY_DETAIL.YEAR_END_TIME);
					}*/
					
					Long currentTime = ZABUtil.getCurrentTimeInMilliSeconds();
					
					//If trial user check his end time expiry
					if(licenseType.equals(License.TRIAL.getLicenseType()) && endTime <= currentTime)
					{
						//For early access users, we made the user trial as annual with end time in 2 months, since are giving 2 months for them
						//if( !portalLicenseMappingObj.getIsAnnual() || (portalLicenseMappingObj.getIsAnnual() && yearlyEndTime <= currentTime))
						//{
							
							inActivateUserLicense(portalLicenseMappingObj,licenseDetail,licenseVisitorCount, BCCMailers.NO_BCC.getType()); 
							LOGGER.log(Level.INFO, "License verifiation - End time expired - Trial pack - Inactivated - {0}", new String[]{zsoid.toString()});
							LOGGER.log(Level.INFO, "License verifiation completed for - {0}", new String[]{zsoid.toString()});
							continue;
						//}
					}
				
					String portalDomain =  AdminConsole.getPortalDomain(zsoid);
					List<String> userPortalList = new ArrayList<String>();
					userPortalList.add(portalDomain);
					if(StringUtils.isNotEmpty(portalDomain) && userPortalList.size() > 0)
					{
						Long expsVisitorCount = getVisitorsCount(userPortalList, startTime, endTime);
						if(expsVisitorCount >= licenseVisitorCount)
						{
							inActivateUserLicense(portalLicenseMappingObj,licenseDetail,licenseVisitorCount, BCCMailers.TEAM_BCC.getType());
							
							
							LOGGER.log(Level.INFO, "License verifiation - Visitorcount exceeded - Monthly - Inactivated - {0} - Visitorcount - {1}", new String[]{zsoid.toString(),expsVisitorCount.toString()});
							
							//Update if it is annual
							/*if(portalLicenseMappingObj.getIsAnnual())
							{
								Long nextMonthStartTime = ZABUtil.getNthServerDayInLong(startTime, LicenseConstants.MONTH_DAYS_COUNT);
								HashMap<String, String> ymHs = new HashMap<String, String>();
								//Update next month start time
								if(nextMonthStartTime < yearlyEndTime)
								{
									ymHs.put(LicenseConstants.NEXT_MONTH_START_TIME,nextMonthStartTime.toString());
								}
								else
								{
									ymHs.put(LicenseConstants.NEXT_MONTH_START_TIME,null);
								}
								PortalLicenseYearlyDetail.updatePortalLicenseYearlyDetail(portalLicenseMappingObj.getPortalLicenseMappingId(), ymHs);
							}*/
						}
						else if(expsVisitorCount >= countToMail)
						{
							//Sending mail to created ZUID
							ServiceOrg sOrg = ZABServiceOrgUtil.getServiceOrg(zsoid);
							if(!portalLicenseMappingObj.getIsVisitorLimitWarned())
							{
								mailLicenseStatusToUser(sOrg, licenseType, MailToSendType.VISITOR_ABOUT_TO_REACH, licenseVisitorCount, portalLicenseMappingObj.getIsAnnual(), licenseName, BCCMailers.TEAM_AND_SALES_BCC.getType());
								
								//Update the warned mail status
								HashMap<String, String> warnHs = new HashMap<String, String>();
								warnHs.put(LicenseConstants.IS_VISITORLIMIT_WARNED, Boolean.TRUE.toString());
								PortalLicenseMapping.updatePortalLicense(portalLicenseMappingObj.getPortalLicenseMappingId(), warnHs);
								LOGGER.log(Level.INFO, "License verifiation - Visitorcount nearing - Alert sent - {0} - Visitorcount - {1}", new String[]{zsoid.toString(),expsVisitorCount.toString()});
							}
							LOGGER.log(Level.INFO, "License verifiation - Visitorcount nearing  - {0} - Visitorcount - {1}", new String[]{zsoid.toString(),expsVisitorCount.toString()});
						}
					}
					
					LOGGER.log(Level.INFO, "License verifiation completed for - {0}", new String[]{zsoid.toString()});
				}
				catch(Exception ex)
				{
					LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
					LOGGER.log(Level.INFO, "License verifiation error for - {0}", new String[]{zsoid.toString()});
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "License Verification generic Error",ex);
		}
	}
	
	//JOB 2
	public static void reActivateAnnualUserMonthlyPack()
	{
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N 
		
		//Update the monthly status for the annual pack
		try
		{
			Long currentTime = ZABUtil.getCurrentTimeInMilliSeconds();
			Criteria criteria1 = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.IS_ANNUAL), Boolean.TRUE, QueryConstants.EQUAL);
			Criteria criteria2 = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.IS_APP_ACTIVE), Boolean.TRUE, QueryConstants.EQUAL);
			Criteria criteria6 = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.IS_STORE_ACTIVE), Boolean.TRUE, QueryConstants.EQUAL);
			Criteria criteria3 = new Criteria(new Column(PORTAL_LICENSE_YEARLY_DETAIL.TABLE, PORTAL_LICENSE_YEARLY_DETAIL.YEAR_END_TIME), currentTime, QueryConstants.GREATER_THAN);
			Criteria criteria4 = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.END_TIME), currentTime, QueryConstants.LESS_EQUAL);
			Join join1 = new Join(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_YEARLY_DETAIL.TABLE, new String[]{PORTAL_LICENSE_MAPPING.PORTAL_LICENSE_MAPPING_ID}, new String[]{PORTAL_LICENSE_YEARLY_DETAIL.PORTAL_LICENSE_MAPPING_ID}, Join.INNER_JOIN);
			DataObject dataObj = ZABModel.getRow(PORTAL_LICENSE_MAPPING.TABLE, criteria1.and(criteria6).and(criteria2).and(criteria3).and(criteria4) , join1);
			Iterator<?> iterator = dataObj.getRows(PORTAL_LICENSE_MAPPING.TABLE);
			while(iterator.hasNext())
			{
				Row row = (Row)iterator.next();
				Long existingEndTime =  (Long)row.get(PORTAL_LICENSE_MAPPING.END_TIME);
				Long portalLicMappingId = (Long)row.get(PORTAL_LICENSE_MAPPING.PORTAL_LICENSE_MAPPING_ID);
				Criteria criteria7 = new Criteria(new Column(PORTAL_LICENSE_YEARLY_DETAIL.TABLE, PORTAL_LICENSE_YEARLY_DETAIL.PORTAL_LICENSE_MAPPING_ID), portalLicMappingId, QueryConstants.EQUAL);
				Row yearRow = dataObj.getRow(PORTAL_LICENSE_YEARLY_DETAIL.TABLE, criteria7);
				Long yearlyEndTime = (Long)yearRow.get(PORTAL_LICENSE_YEARLY_DETAIL.YEAR_END_TIME);
				Long newStartTime = existingEndTime + 1;
				Long newEndTime = ZABUtil.getNthServerDayInLong(newStartTime, LicenseConstants.MONTH_DAYS_COUNT)-1;
				if(newEndTime > yearlyEndTime)
				{
					newEndTime = yearlyEndTime;
				}
				HashMap<String, String> umHs = new HashMap<String, String>();
				umHs.put(LicenseConstants.START_TIME, newStartTime.toString());
				umHs.put(LicenseConstants.END_TIME, newEndTime.toString());
				PortalLicenseMapping.updatePortalLicense(portalLicMappingId, umHs); 
				
				LOGGER.log(Level.INFO, "Annual package monthly renewal completed for - userMappingId - {0}", new String[]{portalLicMappingId.toString()});
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		
		//Re-Activating the next month annual pack
		try
		{
			Long currentTime = ZABUtil.getCurrentTimeInMilliSeconds();
			Criteria criteria1 = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.IS_ANNUAL), Boolean.TRUE, QueryConstants.EQUAL);
			Criteria criteria2 = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.IS_APP_ACTIVE), Boolean.FALSE, QueryConstants.EQUAL);
			Criteria criteria6 = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.IS_STORE_ACTIVE), Boolean.TRUE, QueryConstants.EQUAL);
			Criteria criteria3 = new Criteria(new Column(PORTAL_LICENSE_YEARLY_DETAIL.TABLE, PORTAL_LICENSE_YEARLY_DETAIL.YEAR_END_TIME), currentTime, QueryConstants.GREATER_THAN);
			Criteria criteria4 = new Criteria(new Column(PORTAL_LICENSE_YEARLY_DETAIL.TABLE, PORTAL_LICENSE_YEARLY_DETAIL.NEXT_MONTH_START_TIME), null, QueryConstants.NOT_EQUAL);
			Criteria criteria5 = new Criteria(new Column(PORTAL_LICENSE_YEARLY_DETAIL.TABLE, PORTAL_LICENSE_YEARLY_DETAIL.NEXT_MONTH_START_TIME), currentTime, QueryConstants.LESS_EQUAL);
			Join join1 = new Join(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_YEARLY_DETAIL.TABLE, new String[]{PORTAL_LICENSE_MAPPING.PORTAL_LICENSE_MAPPING_ID}, new String[]{PORTAL_LICENSE_YEARLY_DETAIL.PORTAL_LICENSE_MAPPING_ID}, Join.INNER_JOIN);
			DataObject dataObj = ZABModel.getRow(PORTAL_LICENSE_MAPPING.TABLE, criteria1.and(criteria6).and(criteria2).and(criteria3).and(criteria4).and(criteria5) , join1);
			Iterator<?> iterator = dataObj.getRows(PORTAL_LICENSE_YEARLY_DETAIL.TABLE);
			while(iterator.hasNext())
			{
				Row row = (Row)iterator.next();
				Long portalLicMappingId = (Long)row.get(PORTAL_LICENSE_YEARLY_DETAIL.PORTAL_LICENSE_MAPPING_ID);
				Long yearlyEndTime = (Long)row.get(PORTAL_LICENSE_YEARLY_DETAIL.YEAR_END_TIME);
				Long newStartTime = (Long)row.get(PORTAL_LICENSE_YEARLY_DETAIL.NEXT_MONTH_START_TIME);
				Long newEndTime = ZABUtil.getNthServerDayInLong(newStartTime, LicenseConstants.MONTH_DAYS_COUNT)-1;
				if(newEndTime > yearlyEndTime)
				{
					newEndTime = yearlyEndTime;
				}
				HashMap<String, String> umHs = new HashMap<String, String>();
				umHs.put(LicenseConstants.IS_APP_ACTIVE, Boolean.TRUE.toString());
				umHs.put(LicenseConstants.START_TIME, newStartTime.toString());
				umHs.put(LicenseConstants.END_TIME, newEndTime.toString());
				PortalLicenseMapping.updatePortalLicense(portalLicMappingId, umHs); 
				
				HashMap<String, String> ymHs = new HashMap<String, String>();
				ymHs.put(LicenseConstants.NEXT_MONTH_START_TIME,null);
				PortalLicenseYearlyDetail.updatePortalLicenseYearlyDetail(portalLicMappingId, ymHs);
				
				LOGGER.log(Level.INFO, "Annual package monthly renewal completed for - userMappingId - {0}", new String[]{portalLicMappingId.toString()});
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		
		ZABUtil.setDBSpace(existingDBSpace);
	}
	
	public static void inActivateUserLicense(PortalLicenseMapping portalLicenseMappingObj, LicenseDetail licenseDetailObj, Long visitorLimitCap, int sendBccType) throws Exception
	{
		Long zsoid = portalLicenseMappingObj.getZsoid();
		//Pause the license
		HashMap<String, String> umHs = new HashMap<String, String>();
		umHs.put(LicenseConstants.IS_APP_ACTIVE, Boolean.FALSE.toString());
		umHs.put(LicenseConstants.PAUSED_TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
		PortalLicenseMapping.updatePortalLicense(portalLicenseMappingObj.getPortalLicenseMappingId(), umHs);
		
		//Pause all the running experiments
		pausePortalRunningExperiments(zsoid);
		
		//Deleting scripts
		Portal.deleteScriptsWithinPortal(zsoid);
		
		//Mail the user regarding the license paused
		//Sending mail to created ZUID
		ServiceOrg sOrg = ZABServiceOrgUtil.getServiceOrg(zsoid);
		mailLicenseStatusToUser(sOrg, licenseDetailObj.getLicenseType(), MailToSendType.VISITOR_OR_TIME_EXPIRED, visitorLimitCap, portalLicenseMappingObj.getIsAnnual(), licenseDetailObj.getLicenseName(), sendBccType);
	}
	
	public static void mailLicenseStatusToUser(ServiceOrg sOrg, int licenseType, MailToSendType mailToSendType, Long visitorLimitCap, Boolean isAnnual, String planName, int sendBccType)
	{
		try
		{	
			Long zuid  = sOrg.getCreatedBy();
			String portalName = sOrg.getOrgName();
			String domainName = sOrg.getDomains().get(0).getDomain();
			String usageUrl = SERVICE_URL + "/pagesense/#/space/" + domainName + "/usage"; //No I18N
			
			//Do not mail for Zohoone users
			if(License.ZOHOONETRIAL.getLicenseType().equals(licenseType) || License.ZOHOONE.getLicenseType().equals(licenseType))
			{
				return;
			}
			
			UserEmail userEmail = IAMProxy.getInstance().getUserAPI().getPrimaryEmail(zuid);
			User user = IAMProxy.getInstance().getUserAPI().getUser(zuid);
			String templatePath="";
			//subject = ZABAction.getMessage(LicenseConstants.LICENSE_WARNING_MAIL_SUBJECT);
			String subject = "";
			
			if(License.TRIAL.getLicenseType().equals(licenseType) || License.ZOHOONETRIAL.getLicenseType().equals(licenseType))
			{
				switch(mailToSendType)
				{
				case VISITOR_ABOUT_TO_REACH:
					templatePath = "/../../mailtemplate/trial_80_consumed.html"; // No I18N
					subject = "Your free trial is about to expire"; // No I18N
					break;
				case VISITOR_OR_TIME_EXPIRED:
					templatePath = "/../../mailtemplate/trial_expired.html"; // No I18N
					subject = "Your free trial has expired"; // No I18N
					break;
				}
			}
			else
			{
				switch(mailToSendType)
				{
				case VISITOR_ABOUT_TO_REACH:
					templatePath = "/../../mailtemplate/subscription_80_consumed.html"; // No I18N
					subject = "Your Subscription is About to Expire"; // No I18N
					break;
				case VISITOR_OR_TIME_EXPIRED:
					templatePath = "/../../mailtemplate/subscription_expired.html"; // No I18N
					subject = "Your Subscription has Expired"; // No I18N
					break;
				}
			}
			
			String toAddress = userEmail.getEmailId();
			String userName = user.getDisplayName();
			String fromAddress = SENDER_MAIL_ID;
			 
			String url = ZABUser.class.getResource(templatePath).getPath();
			String mailTemplate = new String(Files.readAllBytes(Paths.get(url)));
			
			
			if(visitorLimitCap != null)
			{
				mailTemplate = mailTemplate.replace("${visitorCountCap}", visitorLimitCap.toString()); // No I18N
			}
			if(planName != null)
			{
				planName = LicenseDetail.getReadablePlanName(planName);
				mailTemplate = mailTemplate.replace("${planName}", planName.toString()); // No I18N
			}
			if(isAnnual != null)
			{
				String durationHolder = "monthly"; // No I18N
				if(isAnnual)
				{
					durationHolder = "annual"; // No I18N
				}
				mailTemplate = mailTemplate.replace("${durationHolder}", durationHolder.toString()); // No I18N
			}
			if(portalName != null)
			{
				mailTemplate = mailTemplate.replace("${spaceName}", portalName); // No I18N
			}
			mailTemplate = mailTemplate.replace("${subsUrl}", usageUrl); // No I18N
			mailTemplate = mailTemplate.replace("${userName}", userName); // No I18N
			mailTemplate = mailTemplate.replace("${senderSignature}", SENDER_SIGNATURE); // No I18N
			ZABUtil.sendEmail(mailTemplate, fromAddress, toAddress, subject, sendBccType);
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
	}
	
	public static void pausePortalRunningExperiments(Long zsoid)
	{
		String existingDBSpace = ZABUtil.getDBSpace();
		//Set the respective DBSpace
		ZABUtil.setDBSpace(zsoid.toString());
		String domainName = ZABServiceOrgUtil.getServiceOrgDomainName(zsoid);
		ZABUtil.setPortaldomain(domainName);
		try
		{
			Criteria criteria2 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_STATUS), ExperimentStatus.RUNNING.getStatusCode(), QueryConstants.EQUAL);
			DataObject databj = ZABModel.getRow(EXPERIMENT.TABLE, criteria2);
			Iterator<?> iterator = databj.getRows(EXPERIMENT.TABLE);
			while(iterator.hasNext())
			{
				Row row = (Row)iterator.next();
				Long experimentId = (Long)row.get(EXPERIMENT.EXPERIMENT_ID);
				String expLinkName = (String)row.get(EXPERIMENT.EXPERIMENT_LINK_NAME);
				try
				{
					HashMap<String, String> experimentHs = new HashMap<String, String>();
					experimentHs.put(ExperimentConstants.EXPERIMENT_LINKNAME, expLinkName);
					experimentHs.put(ExperimentConstants.EXPERIMENT_STATUS, ExperimentStatus.PAUSED.getStatusCode().toString());
					ExperimentHandler.handleExperimentUpdation(experimentHs);
					LOGGER.log(Level.INFO, "Completed pausing exp - {0} - zsoid - {1}", new String[]{experimentId.toString(), zsoid.toString()});
				}
				catch(Exception ex)
				{
					LOGGER.log(Level.SEVERE, "Exception in pausing exp - {0} - zsoid - {1}", new String[]{experimentId.toString(), zsoid.toString()});
					LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		try{
			Criteria criteria2 = new Criteria(new Column(GOAL.TABLE, GOAL.GOAL_STATUS), GoalStatus.RUNNING.getStatusCode(), QueryConstants.EQUAL);
			DataObject databj = ZABModel.getRow(GOAL.TABLE, criteria2);
			Iterator<?> iterator = databj.getRows(GOAL.TABLE);
			while(iterator.hasNext())
			{
				Row row = (Row)iterator.next();
				Long goalId = (Long)row.get(GOAL.GOAL_ID);
				String goalLinkName = (String)row.get(GOAL.GOAL_LINK_NAME);
				try
				{
					HashMap<String, String> goalHs = new HashMap<String, String>();
					goalHs.put(ZABConstants.LINKNAME, goalLinkName);
					goalHs.put(GoalConstants.GOAL_STATUS, GoalStatus.PAUSED.getStatusCode().toString());
					Goal.updateGoal(goalHs , Boolean.FALSE);
					LOGGER.log(Level.INFO, "Completed pausing goal - {0} - zsoid - {1}", new String[]{goalId.toString(), zsoid.toString()});
				}
				catch(Exception ex)
				{
					LOGGER.log(Level.SEVERE, "Exception in pausing goal - {0} - zsoid - {1}", new String[]{goalId.toString(), zsoid.toString()});
					LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
				}
			}
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		ZABUtil.setDBSpace(existingDBSpace);
	}
	
	//This will be called from a manual api to pause the 
	//running experiments(which were missed due to exceptions or something) in the license expired portals
	public static void pauseAllExpsInExpiredPortals()
	{
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		try
		{
			LOGGER.log(Level.INFO, "Started checking exp for expired portals ");
			Criteria criteria1 = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.IS_APP_ACTIVE), Boolean.FALSE, QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(PORTAL_LICENSE_MAPPING.TABLE, criteria1);
			Iterator<?> iterator = dataObj.getRows(PORTAL_LICENSE_MAPPING.TABLE);
			while(iterator.hasNext())
			{
				Row row = (Row)iterator.next();
				Long zsoid = (Long)row.get(PORTAL_LICENSE_MAPPING.ZSOID);
				pausePortalRunningExperiments(zsoid);
			}	
			LOGGER.log(Level.INFO, "Completed pausing exp for expired portals ");
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception in checking exp for expired portals ");
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
	}
	
	public static Long getVisitorsCount(List<String> portalList, Long startTime, Long endTime)
	{
		Long visitorCount = 0l;
		try
		{
			//Getting data for AB,SPLIT,HEATMAP
			String indexPattern = ElasticSearchConstants.DEFAULT_INDEX_PREFIX + "*";
			String[] typeArray = {ElasticSearchConstants.VISITOR_RAW_TYPE};
			//Query
			BoolQueryBuilder query = QueryBuilders.boolQuery();
			List<QueryBuilder> conditionList = new ArrayList<QueryBuilder>();
			QueryBuilder portalsQuery = QueryBuilders.termsQuery(ElasticSearchConstants.PORTAL, portalList);
			QueryBuilder timeQuery = QueryBuilders.rangeQuery("time").gte(startTime).lte(endTime); // No I18N
			conditionList.add(portalsQuery);
			conditionList.add(timeQuery);
			query.must().addAll(conditionList);
			//Aggreggation
			String portalTermsLabel = "portals"; // No I18N
			String expTermsLabel = "experiments"; // No I18N
			
			TermsAggregationBuilder portalAggr = AggregationBuilders.terms(portalTermsLabel).  
					field(ElasticSearchConstants.PORTAL).
					size(ElasticSearchConstants.INTEGER_MAX_COUNT);
			TermsAggregationBuilder expAggr = AggregationBuilders.terms(expTermsLabel).  
					field(ElasticSearchConstants.EXPERIMENTID).
					size(ElasticSearchConstants.INTEGER_MAX_COUNT);
			CardinalityAggregationBuilder cardAggr = ElasticSearchStatistics.getVisitorCardinalityAggr();
			CardinalityAggregationBuilder uuidCardAggr = ElasticSearchStatistics.getUUIDVisitorCardinalityAggr();
			
			AggregationBuilder finalAggr = portalAggr.subAggregation(expAggr.subAggregation(cardAggr).subAggregation(uuidCardAggr));

			//Response
			SearchResponse visitorResponse = ElasticSearchUtil.getData(indexPattern, typeArray, 0, query, finalAggr);
			visitorCount = readVisitorResponseData(visitorResponse,"distinct_visitors",portalTermsLabel,expTermsLabel);// No I18N

			//Getting data for FUNNEL
			String[] funneltypeArray = {ElasticSearchConstants.FUNNEL_RAW_TYPE};
			//Query
			BoolQueryBuilder funnelQuery = QueryBuilders.boolQuery();
			List<QueryBuilder> funConditionList = new ArrayList<QueryBuilder>();
			NestedQueryBuilder funTimeQuery = QueryBuilders.nestedQuery("steps", QueryBuilders.rangeQuery(ElasticSearchConstants.STEPS+ "."+ElasticSearchConstants.TIME).gte(startTime).lte(endTime), ScoreMode.None); // No I18N
			funConditionList.add(portalsQuery);
			funConditionList.add(funTimeQuery);
			funnelQuery.must().addAll(funConditionList);
			
			String portalTermsLabel1 = "portals1"; // No I18N
			String expTermsLabel1 = "experiments1"; // No I18N
			TermsAggregationBuilder portalAggr1 = AggregationBuilders.terms(portalTermsLabel1).  
					field(ElasticSearchConstants.PORTAL).
					size(ElasticSearchConstants.INTEGER_MAX_COUNT);
			TermsAggregationBuilder expAggr1 = AggregationBuilders.terms(expTermsLabel1).  
					field(ElasticSearchConstants.EXPERIMENTID).
					size(ElasticSearchConstants.INTEGER_MAX_COUNT);
			//Aggregation
			AggregationBuilder sessionCardAggr = ElasticSearchStatistics.getFunnelSessionCardinalityAggr();
			AggregationBuilder funFinalAggr = portalAggr1.subAggregation(expAggr1.subAggregation(sessionCardAggr));
			//Response
			SearchResponse funnelResponse = ElasticSearchUtil.getData(indexPattern, funneltypeArray, 0, funnelQuery, funFinalAggr);
			Long sessionCount = readVisitorResponseData(funnelResponse,"distinct_sessions",portalTermsLabel1,expTermsLabel1);// No I18N
			visitorCount = visitorCount + sessionCount;
			// For Form Analytics
			String[] formtypeArray = {ElasticSearchConstants.FORM_ANALYTICS_RAW_TYPE};
			TermsAggregationBuilder portalAggr2 = AggregationBuilders.terms(portalTermsLabel).  
					field(ElasticSearchConstants.PORTAL).
					size(ElasticSearchConstants.INTEGER_MAX_COUNT);
			TermsAggregationBuilder expAggr2 = AggregationBuilders.terms(expTermsLabel).  
					field(ElasticSearchConstants.EXPERIMENTID).
					size(ElasticSearchConstants.INTEGER_MAX_COUNT);
			CardinalityAggregationBuilder cardAggr2 = ElasticFormReport.getVisitorCardinalityAggr();
			finalAggr = portalAggr2.subAggregation(expAggr2.subAggregation(cardAggr2));
			visitorResponse = ElasticSearchUtil.getData(indexPattern, formtypeArray, 0, query, finalAggr);
			visitorCount = visitorCount + readVisitorResponseData(visitorResponse,FormReportConstants.FORM_UNIQUE_VISITOR_COUNT,portalTermsLabel,expTermsLabel); 
			//Session Recording
			
			visitorCount = visitorCount + SessionElasticBand.getSessionCount(portalList, startTime, endTime);
			

			if(portalList!=null && portalList.size() > 0) {				
				Long zsoid = ZABServiceOrgUtil.getZSOIDFromDomain(portalList.get(0));
				Long deletedCount = SessionPlayList.getDeletedSessionCounts(startTime, endTime, zsoid);
				visitorCount = visitorCount + deletedCount;
			}
			
			//For other features we have to implement it here
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			visitorCount = 0l;
		}
		return visitorCount;
	}
	
	public static JSONArray getVisitorsCountForProject(List<String> portalList, Long startTime, Long endTime)
	{
		//Initialize HashMap<ProjectId,VisitorsCount> 
		HashMap<Long,Long> visitorsCountForProject = new HashMap<Long,Long>();
		JSONArray visitorsCountForProjectName = new JSONArray();
		ArrayList<Project> project = Project.getProjectsForCurrentPortal();
		for(int i = 0; i < project.size(); i++){
			Project p = project.get(i);
			visitorsCountForProject.put(p.getProjectId(), 0L);
		}
		try
		{
			//Getting data for AB,SPLIT,HEATMAP
			String indexPattern = ElasticSearchConstants.DEFAULT_INDEX_PREFIX + "*";
			String[] typeArray = {ElasticSearchConstants.VISITOR_RAW_TYPE};
			//Query
			BoolQueryBuilder query = QueryBuilders.boolQuery();
			List<QueryBuilder> conditionList = new ArrayList<QueryBuilder>();
			QueryBuilder portalsQuery = QueryBuilders.termsQuery(ElasticSearchConstants.PORTAL, portalList);
			QueryBuilder timeQuery = QueryBuilders.rangeQuery("time").gte(startTime).lte(endTime); // No I18N
			conditionList.add(portalsQuery);
			conditionList.add(timeQuery);
			query.must().addAll(conditionList);
			//Aggreggation
			String portalTermsLabel = "portals"; // No I18N
			String expTermsLabel = "experiments"; // No I18N
			
			TermsAggregationBuilder portalAggr = AggregationBuilders.terms(portalTermsLabel).  
					field(ElasticSearchConstants.PORTAL).
					size(ElasticSearchConstants.INTEGER_MAX_COUNT);
			TermsAggregationBuilder expAggr = AggregationBuilders.terms(expTermsLabel).  
					field(ElasticSearchConstants.EXPERIMENTID).
					size(ElasticSearchConstants.INTEGER_MAX_COUNT);
			CardinalityAggregationBuilder cardAggr = ElasticSearchStatistics.getVisitorCardinalityAggr();
			AggregationBuilder finalAggr = portalAggr.subAggregation(expAggr.subAggregation(cardAggr));
			//Response
			SearchResponse visitorResponse = ElasticSearchUtil.getData(indexPattern, typeArray, 0, query, finalAggr);
			readVisitorResponseDataForProject(visitorResponse,"distinct_visitors",portalTermsLabel,expTermsLabel,visitorsCountForProject);// No I18N


			//Getting data for FUNNEL
			String[] funneltypeArray = {ElasticSearchConstants.FUNNEL_RAW_TYPE};
			//Query
			BoolQueryBuilder funnelQuery = QueryBuilders.boolQuery();
			List<QueryBuilder> funConditionList = new ArrayList<QueryBuilder>();
			NestedQueryBuilder funTimeQuery = QueryBuilders.nestedQuery("steps", QueryBuilders.rangeQuery(ElasticSearchConstants.STEPS+ "."+ElasticSearchConstants.TIME).gte(startTime).lte(endTime), ScoreMode.None); // No I18N
			funConditionList.add(portalsQuery);
			funConditionList.add(funTimeQuery);
			funnelQuery.must().addAll(funConditionList);
			
			String portalTermsLabel1 = "portals1"; // No I18N
			String expTermsLabel1 = "experiments1"; // No I18N
			TermsAggregationBuilder portalAggr1 = AggregationBuilders.terms(portalTermsLabel1).  
					field(ElasticSearchConstants.PORTAL).
					size(ElasticSearchConstants.INTEGER_MAX_COUNT);
			TermsAggregationBuilder expAggr1 = AggregationBuilders.terms(expTermsLabel1).  
					field(ElasticSearchConstants.EXPERIMENTID).
					size(ElasticSearchConstants.INTEGER_MAX_COUNT);
			//Aggregation
			AggregationBuilder sessionCardAggr = ElasticSearchStatistics.getFunnelSessionCardinalityAggr();
			AggregationBuilder funFinalAggr = portalAggr1.subAggregation(expAggr1.subAggregation(sessionCardAggr));
			//Response
			SearchResponse funnelResponse = ElasticSearchUtil.getData(indexPattern, funneltypeArray, 0, funnelQuery, funFinalAggr);
			readVisitorResponseDataForProject(funnelResponse,"distinct_sessions",portalTermsLabel1,expTermsLabel1,visitorsCountForProject);// No I18N			
			//For other features we have to implement it here
			Iterator<Map.Entry<Long, Long>> it = visitorsCountForProject.entrySet().iterator();
		    while (it.hasNext()) {
		        Map.Entry<Long,Long> pair = it.next();
		        Long projectId = pair.getKey();
		        Project p = Project.getProjectByProjectId(projectId);
		        JSONObject json = new JSONObject();
		        int expCount = Project.getExperimentsCountForProject(projectId);
		        expCount = (expCount==-1)?0:expCount;
		        json.put(ProjectConstants.EXPERIMENT_COUNT,expCount);
		        json.put(ProjectConstants.PROJECT_NAME, p.getProjectName());
		        json.put(ProjectConstants.VISITORS_COUNT,pair.getValue());
		        visitorsCountForProjectName.put(json);
		    }
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		return visitorsCountForProjectName;
	}
	
	public static Long readVisitorResponseData(SearchResponse response, String countLabel, String portalLabel, String experimentLabel)
	{
		Long visitorCount = 0l;
		try
		{
			Aggregations aggrResponse = response.getAggregations();
			Terms terms = aggrResponse.get(portalLabel);
			List<? extends Bucket> buckets = terms.getBuckets();
			for(Bucket bucket:buckets)
			{
				//String portal = (String)bucket.getKey();
				Aggregations buckaggrResponse = bucket.getAggregations();
				Terms expterms = buckaggrResponse.get(experimentLabel);
				List<? extends Bucket> expbuckets = expterms.getBuckets();
				for(Bucket expbucket:expbuckets)
				{
					//String experiment = (String)expbucket.getKey();
					Long uniqueCount = 0l;
					Aggregations expaggrResponse = expbucket.getAggregations();
					InternalCardinality cardinality = expaggrResponse.get(countLabel);
					uniqueCount = cardinality.getValue();
					if("distinct_visitors".equals(countLabel)) {
						InternalCardinality uuidCardinality = expaggrResponse.get("distinct_uuid_visitors");
						uniqueCount = uniqueCount + uuidCardinality.getValue();
					}
					visitorCount = visitorCount + uniqueCount;
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred in readVisitorResponseData",ex);
			visitorCount = 0l;
		}
		return visitorCount;
	}
	
	public static HashMap<Long,Long> readVisitorResponseDataForProject(SearchResponse response, String countLabel, String portalLabel, String experimentLabel,HashMap<Long,Long> visitorsCountForProject)
	{
		
		HashMap<Long,Long> projectExperimentIdMapping = Project.getProjectExperimentMapping();
		try
		{
			Aggregations aggrResponse = response.getAggregations();
			Terms terms = aggrResponse.get(portalLabel);
			List<? extends Bucket> buckets = terms.getBuckets();
			for(Bucket bucket:buckets)
			{
				//String portal = (String)bucket.getKey();
				Aggregations buckaggrResponse = bucket.getAggregations();
				Terms expterms = buckaggrResponse.get(experimentLabel);
				List<? extends Bucket> expbuckets = expterms.getBuckets();
				for(Bucket expbucket:expbuckets)
				{
					Long experiment = (Long)expbucket.getKey();
					Long projectId = projectExperimentIdMapping.get(experiment);
					Long visitorCount = visitorsCountForProject.get(projectId);
					Long uniqueCount = 0l;
					Aggregations expaggrResponse = expbucket.getAggregations();
					InternalCardinality cardinality = expaggrResponse.get(countLabel);
					uniqueCount = cardinality.getValue();
					visitorCount = visitorCount + uniqueCount;
					visitorsCountForProject.put(projectId, visitorCount);
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred in readVisitorResponseData",ex);
		}
		return visitorsCountForProject;
	}
}
