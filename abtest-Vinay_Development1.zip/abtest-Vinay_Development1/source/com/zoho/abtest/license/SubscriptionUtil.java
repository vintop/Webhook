//$Id$
package com.zoho.abtest.license;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONObject;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.iam.IAMUtil;
import com.adventnet.iam.ServiceOrg;
import com.adventnet.iam.ServiceOrgMember;
import com.adventnet.iam.User;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.LICENSE_DETAIL;
import com.zoho.abtest.PORTAL_LICENSE_ADDON;
import com.zoho.abtest.PORTAL_LICENSE_MAPPING;
import com.zoho.abtest.PORTAL_LICENSE_YEARLY_DETAIL;
import com.zoho.abtest.adminconsole.AdminConsole;
import com.zoho.abtest.adminconsole.AdminConsoleConstants;
import com.zoho.abtest.adminconsole.AdminConsoleWrapper;
import com.zoho.abtest.adminconsole.AdminConsoleConstants.AcOperationType;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.filter.PageSenseOrgFilter;
import com.zoho.abtest.license.LicenseConstants.BCCMailers;
import com.zoho.abtest.license.LicenseConstants.License;
import com.zoho.abtest.license.LicenseConstants.MailToSendType;
import com.zoho.abtest.listener.ZABNotifier;
import com.zoho.abtest.portal.Portal;
import com.zoho.abtest.portal.PortalAction;
import com.zoho.abtest.portal.PortalConstants;
import com.zoho.abtest.user.ZABUser;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.abtest.zcampaigns.ZCampaignBridge;

public class SubscriptionUtil 
{
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(SubscriptionUtil.class.getName());
	
	public static JSONObject addSubscription(String zsoidStr, JSONObject inputJson) throws Exception {
		JSONObject outputJson = new JSONObject();
		try
		{
			LOGGER.log(Level.INFO, "Add subscription started for {0}",new String[]{zsoidStr});
			LOGGER.log(Level.INFO, "Add subscription of {0} store object received {1}",new String[]{zsoidStr,inputJson.toString()});
			Long zsoid = Long.parseLong(zsoidStr);
			//String planName = inputJson.getString("planname");
			String planId = inputJson.optString("planid"); //No I18N
			String profileId = inputJson.optString("profileid"); //No I18N
			Long expiryDate = inputJson.optLong("expirydate"); //No I18N
			String frequency = inputJson.optString("frequency"); //No I18N
			boolean isAnnual = isYearly(frequency);
            Integer licenseTimespan = LicenseConstants.MONTH_DAYS_COUNT;
 			Long startTime = ZABUtil.getCurrentTimeInMilliSeconds();
 			Long endTime = null;
 			Long yearEndTime = null;
 			/*if(isAnnual)
 			{
 				endTime = ZABUtil.getNthServerDayInLong(startTime, licenseTimespan) - 1;
 				if(endTime > expiryDate)
 				{
 					endTime = expiryDate;
 				}
 				yearEndTime = expiryDate;
 			}
 			else
 			{
 				endTime = expiryDate;
 			}*/
 			endTime = expiryDate;
 			LicenseDetail licenseDetailObj = LicenseDetail.getLicenseDetailByPlanId(Long.parseLong(planId));
 			Integer licenseType = licenseDetailObj.getLicenseType();
 			
 			JSONArray addonJsonArr = inputJson.has("addons") ? inputJson.getJSONArray("addons") : null; //No I18N
 			ArrayList<HashMap<String, String>> addonList = null;
			if(addonJsonArr != null)
			{
				addonList = new ArrayList<HashMap<String,String>>();
				for(int i=0;i<addonJsonArr.length();i++)
				{
					JSONObject addonObj = addonJsonArr.getJSONObject(i);
					Long storeAddonId = Long.parseLong(addonObj.getString("id"));
	                Integer totalCount = Integer.parseInt(addonObj.getString("total"));
	                HashMap<String,String> hs = new HashMap<String, String>();
	                hs.put(LicenseConstants.STORE_ADDON_ID, storeAddonId.toString());
	                hs.put(LicenseConstants.TOTAL_COUNT, totalCount.toString());
	                addonList.add(hs);
				}
				
			}
			
			Long portalLicenseMappingId = PortalLicenseMapping.getPortalLicenseMappingIdByZsoid(zsoid);
            if(portalLicenseMappingId != null)
            {
            	PortalLicenseMapping.updateLicenseToPortal(portalLicenseMappingId, licenseType, zsoid, isAnnual, startTime, endTime, yearEndTime,profileId, addonList, true);
            }
            else
            {
            	PortalLicenseMapping.assignLicenseToPortal(licenseType, zsoid, isAnnual, startTime, endTime, yearEndTime,profileId, addonList);
            }
            ZCampaignBridge.checkAndPushZohoOneSubscription(zsoid, licenseType);

            Portal.onPortalLicenseResurrection(zsoid);
            
            outputJson.put("result", "success");
			LOGGER.log(Level.INFO, "Add subscription completed for {0}",new String[]{zsoidStr});
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Add subscription error for {0}",new String[]{zsoidStr});
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			outputJson.put("result", "failure");
		}
		return outputJson;
	}
	
	public static JSONObject setTrial(String zsoidStr, JSONObject inputJson) throws Exception 
	{
		return addSubscription(zsoidStr, inputJson);
	}
	
	public static JSONObject extendTrialDuration(String zsoidStr, JSONObject inputJson) throws Exception 
	{
		JSONObject outputJson = new JSONObject();
		try
		{
			Long zsoid = Long.parseLong(zsoidStr);
			Long expiryDate = inputJson.optLong("expirydate"); //No I18N
			Long portalLicenseMappingId = PortalLicenseMapping.getPortalLicenseMappingIdByZsoid(zsoid);
			PortalLicenseMapping.extendPortalLicenseEndTime(portalLicenseMappingId, expiryDate);
			outputJson.put("result", "success");
			LOGGER.log(Level.INFO, "extendTrialDuration completed for {0}",new String[]{zsoidStr});
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "extendTrialDuration error for {0}",new String[]{zsoidStr});
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			outputJson.put("result", "failure");
		}
		return outputJson;
	}
	
	public static JSONObject cancelTrial(String zId)throws Exception
	{
		JSONObject resultJsonObj = new JSONObject();
		try
		{
			Long zsoid = Long.parseLong(zId);
			ZABUtil.setDBSpace("sharedspace");	//No I18N
			
			Long pausedTime = ZABUtil.getCurrentTimeInMilliSeconds();
			LicenseDetail freeLiceObj = LicenseDetail.getLicenseDetail(License.FREE.getLicenseType());
			
			PortalLicenseMapping mappingObj = PortalLicenseMapping.getPortalLicense(zsoid);
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(LicenseConstants.LICENSE_DETAIL_ID, freeLiceObj.getLicenseDetailId().toString());
			hs.put(LicenseConstants.IS_STORE_ACTIVE, Boolean.FALSE.toString());
			hs.put(LicenseConstants.IS_APP_ACTIVE, Boolean.FALSE.toString());
			hs.put(LicenseConstants.PAUSED_TIME, pausedTime.toString());
			PortalLicenseMapping.updatePortalLicense(mappingObj.getPortalLicenseMappingId(), hs);
			//Remove the user license add-ons also
			PortalLicenseAddon.deletePortalLicenseAddons(mappingObj.getPortalLicenseMappingId());
			
			//The exp are not paused, since this method will be called at the time of upgrade from zohoonetrial to license,
			//and by that time exp should not be paused
			
			resultJsonObj.put("result", "success");
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "cancelSubscription error for {0}",new String[]{zId});
			resultJsonObj.put("result", "failure");
		}
		return resultJsonObj;
	}

	public static JSONObject cancelTrialInquiry(JSONArray inputJsonArr) throws Exception 
	{
		JSONObject outputJson = new JSONObject();
		try
		{
			JSONArray resultJsonArr = new JSONArray();
			// ANd zsoid will be the key in the result
			cancelPortalLicense(inputJsonArr, resultJsonArr);
			outputJson.put("result", resultJsonArr);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "cancelTrialInquiry error");
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			throw ex;
		}
		return outputJson;
	}
	
	public static JSONObject modifySubscription(String zsoidStr, JSONObject inputJson) throws Exception
	{
		JSONObject outputJson = new JSONObject();
		try
		{
			LOGGER.log(Level.INFO, "Modify subscription started for {0}",new String[]{zsoidStr});
			LOGGER.log(Level.INFO, "Modify subscription of {0} store object received {1}",new String[]{zsoidStr,inputJson.toString()});
			ZABUtil.setDBSpace("sharedspace");	//No I18N
			Long zsoid = Long.parseLong(zsoidStr);
			String planName = inputJson.getString("planname");
			String planId = inputJson.getString("planid");
			String profileId = inputJson.getString("profileid");
			Long expiryDate = inputJson.getLong("expirydate"); //No I18N
			String frequency = inputJson.getString("frequency");
			boolean isAnnual = isYearly(frequency);
			Long endTime = null;
            Long yearEndTime = null;
            /*if(isAnnual)
 			{
             	yearEndTime = expiryDate;
 			}
            else
            {
            	endTime = expiryDate;
            }*/
            endTime = expiryDate;
            LicenseDetail licenseDetailObj = LicenseDetail.getLicenseDetailByPlanId(Long.parseLong(planId));
 			Integer licenseType = licenseDetailObj.getLicenseType();
 			Long portalLicenseMappingId = PortalLicenseMapping.getPortalLicenseMappingIdByZsoid(zsoid);
 			
			JSONArray addonJsonArr = inputJson.opt("addons") != null ? inputJson.getJSONArray("addons") : null; //No I18N
			ArrayList<HashMap<String, String>> addonList = null;
			if(addonJsonArr != null)
			{
				addonList = new ArrayList<HashMap<String,String>>();
				for(int i=0;i<addonJsonArr.length();i++)
				{
					JSONObject addonObj = addonJsonArr.getJSONObject(i);
					Long storeAddonId = Long.parseLong(addonObj.getString("id"));
	                Integer totalCount = Integer.parseInt(addonObj.getString("total"));
	                HashMap<String,String> hs = new HashMap<String, String>();
	                hs.put(LicenseConstants.STORE_ADDON_ID, storeAddonId.toString());
	                hs.put(LicenseConstants.TOTAL_COUNT, totalCount.toString());
	                addonList.add(hs);
				}
			}
			//TODO check for upgrade to zohoone - so what will be end time scenario
			PortalLicenseMapping.updateLicenseToPortal(portalLicenseMappingId, licenseType, zsoid, isAnnual, null, endTime, yearEndTime,profileId,addonList,true);
			outputJson.put("result", "success");
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Modify subscription error for {0}",new String[]{zsoidStr});
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			outputJson.put("result", "failure");
		}
		return outputJson;
	}
	
	public static JSONObject getServiceSubscriptionInfo(String zId) throws Exception
	{
		JSONObject outputJson = new JSONObject();
		try
		{
			ZABUtil.setDBSpace("sharedspace");//No I18N
			Long zsoid = Long.parseLong(zId);
			Criteria criteria1 = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.ZSOID), zsoid, QueryConstants.EQUAL);
			Join join1 = new Join(PORTAL_LICENSE_MAPPING.TABLE, LICENSE_DETAIL.TABLE, new String[]{PORTAL_LICENSE_MAPPING.LICENSE_DETAIL_ID}, new String[]{LICENSE_DETAIL.LICENSE_DETAIL_ID}, Join.INNER_JOIN);
			//Join join2 = new Join(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_YEARLY_DETAIL.TABLE, new String[]{PORTAL_LICENSE_MAPPING.PORTAL_LICENSE_MAPPING_ID}, new String[]{PORTAL_LICENSE_YEARLY_DETAIL.PORTAL_LICENSE_MAPPING_ID}, Join.LEFT_JOIN);
			Join join3 = new Join(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_ADDON.TABLE, new String[]{PORTAL_LICENSE_MAPPING.PORTAL_LICENSE_MAPPING_ID}, new String[]{PORTAL_LICENSE_ADDON.PORTAL_LICENSE_MAPPING_ID}, Join.LEFT_JOIN);
			DataObject dataObj = ZABModel.getRow(PORTAL_LICENSE_MAPPING.TABLE, criteria1, new Join[]{join1,join3});
			
			Row portalLicenseMappingRow = dataObj.getFirstRow(PORTAL_LICENSE_MAPPING.TABLE);
			Row licenseDetailRow = dataObj.getFirstRow(LICENSE_DETAIL.TABLE);
			
			String planName = (String)licenseDetailRow.get(LICENSE_DETAIL.LICENSE_NAME);
			Long planId = (Long)licenseDetailRow.get(LICENSE_DETAIL.STORE_PLAN_ID);
			Long endTime = (Long)portalLicenseMappingRow.get(PORTAL_LICENSE_MAPPING.END_TIME);
			boolean isAnnual = (Boolean)portalLicenseMappingRow.get(PORTAL_LICENSE_MAPPING.IS_ANNUAL);
			Long expiryTime = endTime;
			int frequency = 1;
			if(isAnnual)
			{
				frequency = 4;
				/*
				Row yearRow = dataObj.getFirstRow(PORTAL_LICENSE_YEARLY_DETAIL.TABLE);
				Long yearEndTime = (Long)yearRow.get(PORTAL_LICENSE_YEARLY_DETAIL.YEAR_END_TIME);
				expiryTime = yearEndTime;
				*/
			}
			
			JSONArray addonJsonArr = new JSONArray();
			//Get addon details
			if(dataObj.containsTable(PORTAL_LICENSE_ADDON.TABLE))
			{
				Iterator<?> addonIterator = dataObj.getRows(PORTAL_LICENSE_ADDON.TABLE);
				while(addonIterator.hasNext())
				{
					Row addonRow = (Row)addonIterator.next();
					Long addonId = (Long)addonRow.get(PORTAL_LICENSE_ADDON.STORE_ADDON_ID);
					Integer visitorCount = (Integer)addonRow.get(PORTAL_LICENSE_ADDON.TOTAL_COUNT);
					JSONObject addonJsonObj = new JSONObject();
					addonJsonObj.put("id", addonId);
					addonJsonObj.put("total", visitorCount);
					addonJsonArr.put(addonJsonObj);
				}
			}
			
			ServiceOrg  serviceOrg = ZABServiceOrgUtil.getServiceOrg(zsoid);
			String companyName = serviceOrg.getOrgName();
			Long createdTime = serviceOrg.getCreatedTime();
			Long createdZuid = serviceOrg.getCreatedBy();
			
			ZABUtil.setDBSpace(zsoid.toString());
			List<Long> adminzuids = ZABUser.getAdminZuids();
			ZABUtil.setDBSpace("sharedspace");//No I18N
			//Long[] adminZuidArr = adminzuids.toArray(new Long[adminzuids.size()]);
			JSONArray adminZuidArr = new JSONArray();
			for(Long zuid:adminzuids)
			{
				adminZuidArr.put(zuid);
			}
			
			outputJson.put("zId", zsoid);
			if(planId == 0l)
			{
				planId = License.FREE.getStorePlanId();
				planName = License.FREE.getLicenseName();
			}
				
			outputJson.put("planname", planName);
			outputJson.put("planid", planId);
			outputJson.put("addons", addonJsonArr);
			outputJson.put("companyname", companyName);
			outputJson.put("admin_zuid", adminZuidArr);
			outputJson.put("primary_zuid", createdZuid);
			outputJson.put("frequency", frequency);
			outputJson.put("expirydate", expiryTime);
			outputJson.put("orgcreatedtime", createdTime);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "getServiceSubscriptionInfo error for {0}",new String[]{zId});
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			outputJson.put("result", "failure");
		}
		return outputJson;
	}
	
	public static JSONObject renewSubscription(JSONArray inputJsonArr) throws Exception 
	{
		JSONObject outputJson = new JSONObject();
		try
		{
			LOGGER.log(Level.INFO, "Renew subscription store object received {0}",new String[]{inputJsonArr.toString()});
			JSONObject jsonObj = (JSONObject) inputJsonArr.get(0);
			JSONArray resultJsonArr = new JSONArray();
			if(jsonObj != null)
			{
				String existingDBSpace = ZABUtil.getDBSpace();
				ZABUtil.setDBSpace("sharedspace");	//No I18N
				
				// Recurring Success
				if(jsonObj.opt("RecurringSuccess")!=null){
					JSONArray portalList = jsonObj.getJSONArray("RecurringSuccess"); //No I18N
					renewPortalLicense(portalList,resultJsonArr);
				}
				
				// RecurringFail
				if(jsonObj.opt("RecurringFail")!=null){
					JSONArray portalList = jsonObj.getJSONArray("RecurringFail"); //No I18N
					renewPortalLicense(portalList,resultJsonArr);
				}
				
				// RetrySuccess
				if(jsonObj.opt("RetrySuccess")!=null){
					JSONArray portalList = jsonObj.getJSONArray("RetrySuccess"); //No I18N
					retrySuccessPortalLicense(portalList,resultJsonArr);
				}
				
				/*
				// RetryFail	
				if(jsonObj.opt("RetryFail")!=null){
					// No need to handle
				}
				*/
				
				// CancelLicense
				if(jsonObj.opt("CancelLicense")!=null){
					JSONArray portalList = jsonObj.getJSONArray("CancelLicense"); //No I18N
					cancelPortalLicense(portalList, resultJsonArr);
				}
			}
			outputJson.put("result", resultJsonArr);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Renew subscription error");
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			throw ex;
		}
		return outputJson;
	}
	
	public static void cancelPortalLicense(JSONArray portalList,JSONArray resultJsonArr) throws Exception
	{
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		for (int i = 0; i < portalList.length(); i++) 
		{
			JSONObject portalLicObj = (JSONObject) portalList.get(i);
			if(portalLicObj.get("zId") != null)
			{
				JSONObject resultJsonObj = new JSONObject();
				Long zsoid = Long.parseLong(portalLicObj.getString("zId"));
				try
				{
					cancelSubscriptionByZsoid(zsoid);
					resultJsonObj.put(zsoid.toString(), "success");
				}
				catch(Exception ex)
				{
					LOGGER.log(Level.SEVERE, "Cancel License error for {0}",new String[]{zsoid.toString()});
					LOGGER.log(Level.SEVERE, "Cancel License error",ex);
					resultJsonObj.put(zsoid.toString(), "failure");
				}
				resultJsonArr.put(resultJsonObj);
			}
		}
		ZABUtil.setDBSpace(existingDBSpace);
	}
	
	public static void cancelSubscriptionByZsoid(Long zsoid) throws Exception
	{
		Long pausedTime = ZABUtil.getCurrentTimeInMilliSeconds();
		LicenseDetail freeLiceObj = LicenseDetail.getLicenseDetail(License.FREE.getLicenseType());
		
		PortalLicenseMapping mappingObj = PortalLicenseMapping.getPortalLicense(zsoid);
		HashMap<String, String> hs = new HashMap<String, String>();
		hs.put(LicenseConstants.LICENSE_DETAIL_ID, freeLiceObj.getLicenseDetailId().toString());
		hs.put(LicenseConstants.IS_STORE_ACTIVE, Boolean.FALSE.toString());
		hs.put(LicenseConstants.IS_APP_ACTIVE, Boolean.FALSE.toString());
		hs.put(LicenseConstants.PAUSED_TIME, pausedTime.toString());
		PortalLicenseMapping.updatePortalLicense(mappingObj.getPortalLicenseMappingId(), hs);
		//Remove the user license add-ons also
		PortalLicenseAddon.deletePortalLicenseAddons(mappingObj.getPortalLicenseMappingId());
		
		//Pause running experiments
		LicenseVerification.pausePortalRunningExperiments(zsoid);
		//Delete scripts once license is expired
		Portal.deleteScriptsWithinPortal(zsoid);
		
		
		//Mail the portal owner
		ServiceOrg sOrg = ZABServiceOrgUtil.getServiceOrg(zsoid);
		LicenseDetail licenseDetailObj = LicenseDetail.getLicenseDetail(mappingObj.getLicenseDetailId());
		LicenseVerification.mailLicenseStatusToUser(sOrg, licenseDetailObj.getLicenseType() ,MailToSendType.VISITOR_OR_TIME_EXPIRED,null,mappingObj.getIsAnnual(),licenseDetailObj.getLicenseName(), BCCMailers.TEAM_BCC.getType()); 
	}
	
	public static JSONObject cancelSubscription(String zId)throws Exception
	{
		JSONObject resultJsonObj = new JSONObject();
		try
		{
			Long zsoid = Long.parseLong(zId);
			ZABUtil.setDBSpace("sharedspace");	//No I18N
			cancelSubscriptionByZsoid(zsoid);
			resultJsonObj.put("result", "success");
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "cancelSubscription error for {0}",new String[]{zId});
			resultJsonObj.put("result", "failure");
		}
		return resultJsonObj;
	}
	
	//Called for both recurring success and fail
	public static void renewPortalLicense(JSONArray portalList,JSONArray resultJsonArr) throws Exception
	{
		Integer licenseTimespan = LicenseConstants.MONTH_DAYS_COUNT;
		Long startTime = ZABUtil.getCurrentTimeInMilliSeconds();
		Long endTime = ZABUtil.getNthServerDayInLong(startTime, licenseTimespan) - 1;
		Long yearEndTime = ZABUtil.getNthServerDayInLong(startTime, LicenseConstants.YEAR_DAYS_COUNT) - 1;
		for (int i = 0; i < portalList.length(); i++) 
		{
			JSONObject portalLicObj = (JSONObject) portalList.get(i);
			if(portalLicObj.get("zId") != null)
			{
				JSONObject resultJsonObj = new JSONObject();
				Long zsoid = Long.parseLong(portalLicObj.getString("zId"));
				String profileId = portalLicObj.getString("profileid");
				Long expiryDate = null;
				if(portalLicObj.has("nextduedateInLong"))
				{
					expiryDate = portalLicObj.getLong("nextduedateInLong"); // No I18N
				}
				
				try
				{
					PortalLicenseMapping mappingObj = PortalLicenseMapping.getPortalLicense(zsoid);
					
					Long portalEndTime = null;
					
					if(mappingObj.getIsAnnual())
					{
						portalEndTime = (expiryDate != null) ? expiryDate : yearEndTime;
					}
					else
					{
						portalEndTime = (expiryDate != null) ? expiryDate : endTime;
					}
					
					HashMap<String, String> hs = new HashMap<String, String>();
					hs.put(LicenseConstants.STORE_PROFILE_ID, profileId);
					hs.put(LicenseConstants.IS_STORE_ACTIVE, Boolean.TRUE.toString());
					hs.put(LicenseConstants.IS_APP_ACTIVE, Boolean.TRUE.toString());
					hs.put(LicenseConstants.IS_VISITORLIMIT_WARNED, Boolean.FALSE.toString());
					hs.put(LicenseConstants.START_TIME, startTime.toString());
					hs.put(LicenseConstants.END_TIME, portalEndTime.toString());
					PortalLicenseMapping.updatePortalLicense(mappingObj.getPortalLicenseMappingId(), hs);

					Portal.onPortalLicenseResurrection(zsoid);
					/*
					if(mappingObj.getIsAnnual())
					{
						HashMap<String, String> yearHs = new HashMap<String, String>();
						yearHs.put(LicenseConstants.YEAR_START_TIME, startTime.toString());
						yearHs.put(LicenseConstants.YEAR_END_TIME, portalYearEndTime.toString());
						yearHs.put(LicenseConstants.NEXT_MONTH_START_TIME, null);
						PortalLicenseYearlyDetail.updatePortalLicenseYearlyDetail(mappingObj.getPortalLicenseMappingId(), yearHs);
					}
					*/
					resultJsonObj.put(zsoid.toString(), "success");
				}
				catch(Exception ex)
				{
					LOGGER.log(Level.SEVERE, "Renew subscription error for {0}",new String[]{zsoid.toString()});
					LOGGER.log(Level.SEVERE, "Renew subscription error",ex);
					resultJsonObj.put(zsoid.toString(), "failure");
				}
				resultJsonArr.put(resultJsonObj);
			}
		}
	}
	
	public static void retrySuccessPortalLicense(JSONArray portalList,JSONArray resultJsonArr) throws Exception
	{
		Integer licenseTimespan = LicenseConstants.MONTH_DAYS_COUNT;
		//Long startTime = ZABUtil.getCurrentTimeInMilliSeconds();
		//Long endTime = ZABUtil.getNthServerDayInLong(startTime, licenseTimespan) - 1;
		
		for (int i = 0; i < portalList.length(); i++) 
		{
			JSONObject portalLicObj = (JSONObject) portalList.get(i);
			if(portalLicObj.get("zId") != null)
			{
				JSONObject resultJsonObj = new JSONObject();
				Long zsoid = Long.parseLong(portalLicObj.getString("zId"));
				//String profileId = portalLicObj.getString("profileid");
				Long expiryDate = portalLicObj.getLong("nextduedateInLong"); //No I18N
				try
				{
					PortalLicenseMapping mappingObj = PortalLicenseMapping.getPortalLicense(zsoid);
					HashMap<String, String> hs = new HashMap<String, String>();
					hs.put(LicenseConstants.END_TIME, expiryDate.toString());
					PortalLicenseMapping.updatePortalLicense(mappingObj.getPortalLicenseMappingId(), hs);
					resultJsonObj.put(zsoid.toString(), "success");
				}
				catch(Exception ex)
				{
					LOGGER.log(Level.SEVERE, "Renew subscription error for {0}",new String[]{zsoid.toString()});
					LOGGER.log(Level.SEVERE, "Renew subscription error",ex);
					resultJsonObj.put(zsoid.toString(), "failure");
				}
				resultJsonArr.put(resultJsonObj);
			}
		}
	}
	
	public static JSONObject userPrivilege(Long zuid) throws Exception
	{
		JSONObject outputJson = new JSONObject();
		try
		{
			JSONArray adminPrivledgeArr = new JSONArray();
			List<ServiceOrg> serviceOrgList = ZABServiceOrgUtil.getServiceOrgs(zuid, ServiceOrgMember.UserRole.ADMIN);
			if(serviceOrgList != null && serviceOrgList.size() > 0)
			{
				for(ServiceOrg serviceOrg :serviceOrgList)
				{
					if(serviceOrg.getCreatedBy() == zuid)
					{
						JSONObject jsonObj = new JSONObject();
						jsonObj.put("id", serviceOrg.getZSOID());
						jsonObj.put("name", serviceOrg.getOrgName());
						adminPrivledgeArr.put(jsonObj);
					}
				}
			}
			outputJson.put("zuid", zuid);
			outputJson.put("admin_privilege", adminPrivledgeArr);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "userPrivilege error for {0}",new String[]{zuid.toString()});
			throw ex;
		}
		return outputJson;
	}
	
	public static boolean isYearly(String frequency)
	{
		boolean isYearly = false;
		try
		{
			if(frequency.equals("4"))
			{
				isYearly = true;
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			isYearly = false;
		}
		return isYearly;
	}
	
	public static JSONObject checkPortalName(String portalName)throws Exception
	{
		JSONObject resultJson = new JSONObject();
		try
		{
			LOGGER.log(Level.INFO,"Into checkPortalName start - {0}", new String[]{portalName.toString()});
			String domainName = portalName.trim().toLowerCase().replaceAll("[^a-z0-9]",""); //No I18N
			boolean isPortalAlreadyExists = ZABServiceOrgUtil.isPortalExists(domainName);
			resultJson.put("result", "success");
			resultJson.put("availability", !isPortalAlreadyExists);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			throw ex;
		}
		return resultJson;
	}
	
	public static JSONObject addUserToService(JSONObject inputJson)throws Exception
	{
		JSONObject resultJson = new JSONObject();
		Long zuid = null;
		try
		{
			zuid = inputJson.getLong("zuid"); //No I18N
			LOGGER.log(Level.INFO,"Into addUserToService start - {0}", new String[]{zuid.toString()});
			LOGGER.log(Level.INFO, inputJson.toString());
			
			String portalName = inputJson.getString("companyname");
			String domainName = portalName.trim().toLowerCase().replaceAll("[^a-z0-9]",""); //No I18N
			
			Long zsoid = ZABServiceOrgUtil.addServiceOrg(portalName, zuid);
			if(zsoid != null)
			{
				boolean isPortalExists = ZABServiceOrgUtil.isPortalExists(domainName);
				
				if(domainName.length() > 0 && !isPortalExists)
				{
					//Add the domain
					ZABServiceOrgUtil.addDomain(domainName, zsoid);
				}
				else
				{
					domainName = Portal.mapDomainToPortal(zsoid);
				}
				
				HashMap<String,String> hs = new HashMap<String,String>();
				hs.put(PortalConstants.ZSOID, zsoid.toString());
				hs.put(PortalConstants.DOMAINNAME, domainName);
				//Set it as default portal
				Portal.setDefaultPortal(hs, zuid);
				
				
				//Admin console record
				HashMap<String, String> acHs = new HashMap<String, String>();
				acHs.put(AdminConsoleConstants.ZSOID, zsoid.toString());
				acHs.put(AdminConsoleConstants.PORTAL_NAME, portalName);
				acHs.put(AdminConsoleConstants.PORTAL_DOMAIN, domainName);
				acHs.put(AdminConsoleConstants.CREATED_ZUID, zuid.toString());
				acHs.put(AdminConsoleConstants.CREATED_TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
				
				AdminConsoleWrapper acWrapper = new AdminConsoleWrapper();
				acWrapper.setValueHs(acHs);
				acWrapper.setOperationType(AcOperationType.PORTAL_CREATE);
				ZABNotifier.notifyListeners(AdminConsoleConstants.ADMIN_CONSOLE_MODULE_NAME,acWrapper);
				
				ZABUtil.setPortaldomain(domainName);
				User iamUser = new User();
				iamUser.setZUID(zuid);
				//Reserve dbspace and popuate values
				new PortalAction().dbSpaceCreation(iamUser, zsoid.toString(), null, null);
				
				//No Special referrer
				int specialReferrer = 0;
				PortalAction.assignTrialLicenseToZsoid(zsoid,specialReferrer);
				LOGGER.log(Level.INFO,"Into addUserToService success - {0} - {1}", new String[]{zuid.toString(), zsoid.toString()});
				
				resultJson.put("result", "success");
				resultJson.put("zId", zsoid);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.INFO,"Into addUserToService error - {0}", new String[]{zuid.toString()});
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			throw ex;
		}
		return resultJson;
	}
}
