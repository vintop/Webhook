//$Id$
package com.zoho.abtest.license;

import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.zoho.abtest.PORTAL_LICENSE_YEARLY_DETAIL;
import com.zoho.abtest.common.ZABModel;

public class PortalLicenseYearlyDetail 
{
	private static final Logger LOGGER = Logger.getLogger(PortalLicenseYearlyDetail.class.getName());
	
	private Long portalLicenseMappingId;
	private Long yearStartTime;
	private Long yearEndTime;
	private Long nextMonthStartTime;
	public Long getPortalLicenseMappingId() {
		return portalLicenseMappingId;
	}
	public void setPortalLicenseMappingId(Long portalLicenseMappingId) {
		this.portalLicenseMappingId = portalLicenseMappingId;
	}
	public Long getYearStartTime() {
		return yearStartTime;
	}
	public void setYearStartTime(Long yearStartTime) {
		this.yearStartTime = yearStartTime;
	}
	public Long getYearEndTime() {
		return yearEndTime;
	}
	public void setYearEndTime(Long yearEndTime) {
		this.yearEndTime = yearEndTime;
	}
	public Long getNextMonthStartTime() {
		return nextMonthStartTime;
	}
	public void setNextMonthStartTime(Long nextMonthStartTime) {
		this.nextMonthStartTime = nextMonthStartTime;
	}
	
	public static void createPortalLicenseYearlyDetail(HashMap<String, String> hs) 
	{
		try
		{
			ZABModel.createRow(LicenseConstants.PORTAL_LICENSE_YEARLY_DETAIL_CONSTANTS, PORTAL_LICENSE_YEARLY_DETAIL.TABLE, hs);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
	
	public static void updatePortalLicenseYearlyDetail(Long portalLicenseMappingId, HashMap<String, String> hs)
	{
		try
		{
			Criteria criteria1 = new Criteria(new Column(PORTAL_LICENSE_YEARLY_DETAIL.TABLE, PORTAL_LICENSE_YEARLY_DETAIL.PORTAL_LICENSE_MAPPING_ID), portalLicenseMappingId, QueryConstants.EQUAL);
			ZABModel.updateRow(LicenseConstants.PORTAL_LICENSE_YEARLY_DETAIL_CONSTANTS, PORTAL_LICENSE_YEARLY_DETAIL.TABLE, hs, criteria1, null);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
	
	public static boolean isAnnualMappingExists(Long portalLicenseMappingId)
	{
		boolean isExists = false;
		try
		{
			Criteria criteria1 = new Criteria(new Column(PORTAL_LICENSE_YEARLY_DETAIL.TABLE, PORTAL_LICENSE_YEARLY_DETAIL.PORTAL_LICENSE_MAPPING_ID), portalLicenseMappingId, QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(PORTAL_LICENSE_YEARLY_DETAIL.TABLE, criteria1);
			if(dataObj.size(PORTAL_LICENSE_YEARLY_DETAIL.TABLE) > 0)
			{
				isExists = true;
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			isExists = false;
		}
		return isExists;
	}
}
