//$Id$
package com.zoho.abtest.license;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.DataSet;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.ds.query.SelectQueryImpl;
import com.adventnet.ds.query.Table;
import com.adventnet.mfw.bean.BeanUtil;
import com.adventnet.persistence.DataObject;
import com.zoho.abtest.AC_PORTAL;
import com.zoho.abtest.PORTAL_LICENSE_MAPPING;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.license.LicenseConstants.License;
import com.zoho.abtest.utility.DataSetWrapper;
import com.zoho.abtest.utility.ZABUserBean;
import com.zoho.abtest.utility.ZABUtil;

public class LicenseMigrationWorks 
{
	private static final Logger LOGGER = Logger.getLogger(LicenseMigrationWorks.class.getName());
	
	public static void migrationACPortalsToLicensemapping()
	{
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N 
		try
		{
			//Check that the mapping table does not contains any users mapped and then Proceed
			DataObject dataObj = ZABModel.getRow(PORTAL_LICENSE_MAPPING.TABLE, null);
			if(dataObj.isEmpty())
			{
				Table portalTable = new Table(AC_PORTAL.TABLE);
				SelectQuery selectQuery = new SelectQueryImpl(portalTable);
				//However only one entry will be there for one zsoid 
				Column uniqueZSOIDCol = Column.getColumn(AC_PORTAL.TABLE, AC_PORTAL.ZSOID).distinct();
				uniqueZSOIDCol.setColumnAlias("UNIQUE_ZSOIDS");
				selectQuery.addSelectColumn(uniqueZSOIDCol);
				ZABUserBean bean= (ZABUserBean)BeanUtil.lookup(ZABUserBean.BEAN_NAME, "sharedspace");
				final List<Long> zsoidList = new ArrayList<Long>();
				bean.executeQuery(selectQuery, new DataSetWrapper() {
					@Override
					public void execute(DataSet ds) throws Exception {
						while(ds.next()) {	
							Long zsoid = (Long)ds.getValue("UNIQUE_ZSOIDS"); //No I18N
							zsoidList.add(zsoid);
						}
					}
				});
				LicenseDetail licenseDetail = LicenseDetail.getLicenseDetail(License.TRIAL.getLicenseType());
				Integer licenseTimespan = LicenseConstants.MONTH_DAYS_COUNT;
				Long startTime = ZABUtil.getCurrentTimeInMilliSeconds();
				Long endTime = ZABUtil.getNthServerDayInLong(startTime, licenseTimespan) - 1;
				Long yearEndTime = ZABUtil.getNthServerDayInLong(startTime, LicenseConstants.EXISTING_PARTNER_DAYS_COUNT) - 1;
				for(Long zsoid:zsoidList)
				{
					HashMap<String, String> hs = new HashMap<String, String>();
					hs.put(LicenseConstants.ZSOID, zsoid.toString());
					hs.put(LicenseConstants.LICENSE_DETAIL_ID, licenseDetail.getLicenseDetailId().toString());
					hs.put(LicenseConstants.IS_STORE_ACTIVE, Boolean.TRUE.toString());
					hs.put(LicenseConstants.IS_APP_ACTIVE, Boolean.TRUE.toString());
					hs.put(LicenseConstants.START_TIME, startTime.toString());
					hs.put(LicenseConstants.END_TIME, endTime.toString());
					hs.put(LicenseConstants.IS_ANNUAL,Boolean.TRUE.toString());
					hs.put(LicenseConstants.PROJECT_COUNT,licenseDetail.getProjectCount().toString());
					Long portalLicMappingId = PortalLicenseMapping.createPortalLicenseMapping(hs);
					
					//60 days with 50k per month for existing early access users
					HashMap<String, String> yearHs = new HashMap<String, String>();
					yearHs.put(LicenseConstants.PORTAL_LICENSE_MAPPING_ID, portalLicMappingId.toString());
					yearHs.put(LicenseConstants.YEAR_START_TIME, startTime.toString());
					yearHs.put(LicenseConstants.YEAR_END_TIME, yearEndTime.toString());
					yearHs.put(LicenseConstants.NEXT_MONTH_START_TIME, null);
					PortalLicenseYearlyDetail.createPortalLicenseYearlyDetail(yearHs);
					
					//Assign trial addon as 50k for early access users
					Long storeAddonId = 0l;
		            Integer totalCount = LicenseConstants.EXISTING_PARTNER_VISITOR_COUNT;
					HashMap<String,String> addonHs = new HashMap<String, String>();
					addonHs.put(LicenseConstants.STORE_ADDON_ID, storeAddonId.toString());
					addonHs.put(LicenseConstants.TOTAL_COUNT, totalCount.toString());
					addonHs.put(LicenseConstants.PORTAL_LICENSE_MAPPING_ID, portalLicMappingId.toString());
					PortalLicenseAddon.createPortalLicenseAddon(addonHs);
				}
				LOGGER.log(Level.INFO, "License mapping completed for {0} users",new Integer[]{zsoidList.size()});
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		ZABUtil.setDBSpace(existingDBSpace);
	}
}
