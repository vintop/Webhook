//$Id$
package com.zoho.abtest.license;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;

public class PortalLicenseMappingResponse 
{
	private static final Logger LOGGER = Logger.getLogger(PortalLicenseMappingResponse.class.getName());
	
	public static String jsonResponse(HttpServletRequest request,List<PortalLicenseMapping> portalLicenseMappingList) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(portalLicenseMappingList);			
			JSONObject json = ZABResponse.updateMetaInfo(request, LicenseConstants.PORTAL_LICENSE_MAPPING_API_MODULE, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		return returnBuffer.toString();
	}
	
	public static JSONArray getJSONArray(List<PortalLicenseMapping> portalLicenseMappingList) throws JSONException {
		JSONArray array = new JSONArray();
		int size =portalLicenseMappingList.size();
		for (int i=0;i<size;i++) {
			PortalLicenseMapping portalLicenseMapping = portalLicenseMappingList.get(i);
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(LicenseConstants.ZSOID, portalLicenseMapping.getZsoid());
			jsonObj.put(LicenseConstants.START_TIME, portalLicenseMapping.getStartTime());
			jsonObj.put(LicenseConstants.END_TIME, portalLicenseMapping.getEndTime());
			jsonObj.put(LicenseConstants.IS_STORE_ACTIVE, portalLicenseMapping.getIsStoreActive());
			jsonObj.put(LicenseConstants.IS_APP_ACTIVE, portalLicenseMapping.getIsAppActive());
			jsonObj.put(LicenseConstants.PAUSED_TIME, portalLicenseMapping.getPausedTime());
			jsonObj.put(ZABConstants.SUCCESS, portalLicenseMapping.getSuccess());
			jsonObj.put(ZABConstants.RESPONSE_STRING, portalLicenseMapping.getResponseString());
			array.put(jsonObj);
		}
		return array;
	}
}
