//$Id$
package com.zoho.abtest.license;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.PORTAL_LICENSE_ADDON;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.license.LicenseConstants.License;

public class PortalLicenseAddon 
{
	private static final long serialVersionUID = 1L;

	private static final Logger LOGGER = Logger.getLogger(PortalLicenseAddon.class.getName());
	
	private Long portalLicenseAddonId;
	private Long portalLicenseMappingId;
	private Long storeAddonId;
	private Integer totalCount;
	public Long getPortalLicenseAddonId() {
		return portalLicenseAddonId;
	}
	public void setPortalLicenseAddonId(Long portalLicenseAddonId) {
		this.portalLicenseAddonId = portalLicenseAddonId;
	}
	public Long getPortalLicenseMappingId() {
		return portalLicenseMappingId;
	}
	public void setPortalLicenseMappingId(Long portalLicenseMappingId) {
		this.portalLicenseMappingId = portalLicenseMappingId;
	}
	public Long getStoreAddonId() {
		return storeAddonId;
	}
	public void setStoreAddonId(Long storeAddonId) {
		this.storeAddonId = storeAddonId;
	}
	public Integer getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}
	
	public static void createPortalLicenseAddon(ArrayList<HashMap<String, String>> hsList) 
	{
		try
		{
			ZABModel.createRow(LicenseConstants.PORTAL_LICENSE_ADDON_CONSTANTS, PORTAL_LICENSE_ADDON.TABLE, hsList);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
	
	public static void createPortalLicenseAddon(HashMap<String, String> hs) 
	{
		try
		{
			ZABModel.createRow(LicenseConstants.PORTAL_LICENSE_ADDON_CONSTANTS, PORTAL_LICENSE_ADDON.TABLE, hs);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
	
	public static void updatePortalLicenseAddon(Long portalLicenseMappingId, HashMap<String, String> hs) 
	{
		try
		{
			Criteria criteria = new Criteria(new Column(PORTAL_LICENSE_ADDON.TABLE, PORTAL_LICENSE_ADDON.PORTAL_LICENSE_MAPPING_ID), portalLicenseMappingId,QueryConstants.EQUAL);
			ZABModel.updateRow(LicenseConstants.PORTAL_LICENSE_ADDON_CONSTANTS, PORTAL_LICENSE_ADDON.TABLE, hs, criteria, null);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
	
	public static void deletePortalLicenseAddons(Long portalLicenseMappingId)
	{
		try
		{
			Criteria criteria = new Criteria(new Column(PORTAL_LICENSE_ADDON.TABLE, PORTAL_LICENSE_ADDON.PORTAL_LICENSE_MAPPING_ID), portalLicenseMappingId,QueryConstants.EQUAL);
			ZABModel.deleteRow(PORTAL_LICENSE_ADDON.TABLE, criteria, null);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
	
	public static Long getPlanVisitorCount(Long portalLicenseMappingId, Long storePlanId, boolean isAnnual)
	{
		Long allowedCount = 0l;
		try
		{
			if(storePlanId.equals(License.ZOHOONETRIAL.getStorePlanId()))
			{
				//If Zohoone license then the default value
				allowedCount = LicenseConstants.ZOHONE_TRIAL_VISITOR_COUNT.longValue();
			}
			else
			{
				Criteria criteria1 = new Criteria(new Column(PORTAL_LICENSE_ADDON.TABLE, PORTAL_LICENSE_ADDON.PORTAL_LICENSE_MAPPING_ID), portalLicenseMappingId,QueryConstants.EQUAL);
				DataObject dataObj = ZABModel.getRow(PORTAL_LICENSE_ADDON.TABLE, criteria1);
				if(dataObj.containsTable(PORTAL_LICENSE_ADDON.TABLE))
				{
					Iterator<?> addonIterator = dataObj.getRows(PORTAL_LICENSE_ADDON.TABLE);
					while(addonIterator.hasNext())
					{
						Row addonRow = (Row)addonIterator.next();
						Long addonId = (Long)addonRow.get(PORTAL_LICENSE_ADDON.STORE_ADDON_ID);
						Integer addonCount = (Integer)addonRow.get(PORTAL_LICENSE_ADDON.TOTAL_COUNT);
						if(addonId != null && addonId.equals(License.ZOHOONE.getAddonId()))
						{
							//TODO check if any restriction on maximum number of users
							addonCount = addonCount * LicenseConstants.ZOHONE_PER_USER_VISITOR_COUNT;
						}
						allowedCount = allowedCount + addonCount;
					}
				}
				
				if(isAnnual)
				{
					allowedCount = allowedCount * LicenseConstants.YEAR_MONTH_COUNT;
				}
				
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		return allowedCount;
	}
}
