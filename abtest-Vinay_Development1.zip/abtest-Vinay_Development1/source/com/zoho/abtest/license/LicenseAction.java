//$Id$
package com.zoho.abtest.license;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;

import com.opensymphony.xwork2.ActionSupport;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentHandler;
import com.zoho.abtest.utility.ZABUtil;

public class LicenseAction extends ActionSupport implements ServletResponseAware, ServletRequestAware
{
	private static final Logger LOGGER = Logger.getLogger(LicenseAction.class.getName());
	
	private static final long serialVersionUID = 1L;

	private HttpServletRequest request;
	
	private HttpServletResponse response;
	
	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		request = arg0;
	}

	@Override
	public void setServletResponse(HttpServletResponse arg0) {
		response = arg0;
	}
	
	public String assignLicenseToExistingUsers()throws Exception
	{
		ZABUtil.setCurrentRequest(request);
		ZABUtil.setDBCallCountMap(null);
		Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
		ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
		try
		{
			ArrayList<PortalLicenseMapping> userLicenseMappingList = new ArrayList<PortalLicenseMapping>();
			
			LicenseMigrationWorks.migrationACPortalsToLicensemapping();
			
			PortalLicenseMapping userLicenseMappingObj = new PortalLicenseMapping();
			userLicenseMappingObj.setSuccess(true);
			userLicenseMappingList.add(userLicenseMappingObj);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getPortalLicenseMappingResponse(request, userLicenseMappingList));
		}
		catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), LicenseConstants.PORTAL_LICENSE_MAPPING_API_MODULE));
		}	
		return null;
	}
	
	public String extendLicenseToEarlyAccessUsers()throws Exception
	{
		ZABUtil.setCurrentRequest(request);
		ZABUtil.setDBCallCountMap(null);
		Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
		ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
		try
		{
			ArrayList<PortalLicenseMapping> userLicenseMappingList = new ArrayList<PortalLicenseMapping>();
			
			PortalLicenseMapping.processEarlyAccessUserTrials();
			
			PortalLicenseMapping userLicenseMappingObj = new PortalLicenseMapping();
			userLicenseMappingObj.setSuccess(true);
			userLicenseMappingList.add(userLicenseMappingObj);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getPortalLicenseMappingResponse(request, userLicenseMappingList));
		}
		catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), LicenseConstants.PORTAL_LICENSE_MAPPING_API_MODULE));
		}	
		return null;
	} 
	
	public String populateLicenseMetaInSharedSpace()throws Exception
	{
		ZABUtil.setCurrentRequest(request);
		ZABUtil.setDBCallCountMap(null);
		Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
		ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
		try
		{
			ArrayList<PortalLicenseMapping> userLicenseMappingList = new ArrayList<PortalLicenseMapping>();
			
			ZABUtil.setDBSpace("sharedspace");	//No I18N 
			
			LicenseDetail.populateLicenseDetailsInDB();
			
			PortalLicenseMapping userLicenseMappingObj = new PortalLicenseMapping();
			userLicenseMappingObj.setSuccess(true);
			userLicenseMappingList.add(userLicenseMappingObj);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getPortalLicenseMappingResponse(request, userLicenseMappingList));
		}
		catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), LicenseConstants.PORTAL_LICENSE_MAPPING_API_MODULE));
		}	
		return null;
	}

	public String mapLicenseYearlyDetails()throws Exception
	{
		ZABUtil.setCurrentRequest(request);
		ZABUtil.setDBCallCountMap(null);
		Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
		ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
		try
		{
			ArrayList<PortalLicenseMapping> userLicenseMappingList = new ArrayList<PortalLicenseMapping>();
			
			PortalLicenseMapping.mapLicenseYearlyDetail();
			
			PortalLicenseMapping userLicenseMappingObj = new PortalLicenseMapping();
			userLicenseMappingObj.setSuccess(true);
			userLicenseMappingList.add(userLicenseMappingObj);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getPortalLicenseMappingResponse(request, userLicenseMappingList));
		}
		catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), LicenseConstants.PORTAL_LICENSE_MAPPING_API_MODULE));
		}	
		return null;
	}
	
	public String pauseAllExpsInExpiredPortals()throws Exception
	{
		ZABUtil.setCurrentRequest(request);
		ZABUtil.setDBCallCountMap(null);
		Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
		ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
		try
		{
			LicenseVerification.pauseAllExpsInExpiredPortals();
			
			ArrayList<PortalLicenseMapping> userLicenseMappingList = new ArrayList<PortalLicenseMapping>();
			PortalLicenseMapping userLicenseMappingObj = new PortalLicenseMapping();
			userLicenseMappingObj.setSuccess(true);
			userLicenseMappingList.add(userLicenseMappingObj);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getPortalLicenseMappingResponse(request, userLicenseMappingList));
		}
		catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), LicenseConstants.PORTAL_LICENSE_MAPPING_API_MODULE));
		}	
		return null;
	}
	
	//This method will generally used to upgrade the license to trial start and end time for the zsoid
	public String upgradeLicense() throws IOException{
		ArrayList<PortalLicenseMapping> portalLicenseMappingList = new ArrayList<PortalLicenseMapping>();
		try{
			String inputString = null;
			if(ZABAction.getHTTPMethod(request).equals(ZABAction.HTTPMethod.POST) || ZABAction.getHTTPMethod(request).equals(ZABAction.HTTPMethod.PUT))
			{
				inputString = ZABAction.getInputString(request);
			}
			ZABUtil.setCurrentInputString(inputString);
			ZABUtil.setCurrentRequest(request);


			HashMap<String,String> hsPut  = ZABAction.getRequestParser(request).parseLicense(request);
			if(hsPut.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hsPut.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
				PortalLicenseMapping ul = new PortalLicenseMapping();
				ul.setSuccess(Boolean.FALSE);
				ul.setResponseString(hsPut.get(ZABConstants.RESPONSE_STRING));
				portalLicenseMappingList.add(ul);
			}else{
				Long zsoid = Long.parseLong(hsPut.get(LicenseConstants.ZSOID));
				portalLicenseMappingList.add(PortalLicenseMapping.upgradeLicense(zsoid,hsPut));
				ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getPortalLicenseMappingResponse(request, portalLicenseMappingList));
			}
			
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), LicenseConstants.PORTAL_LICENSE_MAPPING_API_MODULE));
		}
		return null;
	}
		
	/*
	public String extendLicenseEndDate() throws IOException{
		ArrayList<PortalLicenseMapping> portalLicenseMappingList = new ArrayList<PortalLicenseMapping>();
		try{
			String inputString = null;
			if(ZABAction.getHTTPMethod(request).equals(ZABAction.HTTPMethod.POST) || ZABAction.getHTTPMethod(request).equals(ZABAction.HTTPMethod.PUT))
			{
				inputString = ZABAction.getInputString(request);
			}
			ZABUtil.setCurrentInputString(inputString);
			ZABUtil.setCurrentRequest(request);

			HashMap<String,String> hsPut  = ZABAction.getRequestParser(request).parseLicense(request);
			if(hsPut.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hsPut.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
				PortalLicenseMapping ul = new PortalLicenseMapping();
				ul.setSuccess(Boolean.FALSE);
				ul.setResponseString(hsPut.get(ZABConstants.RESPONSE_STRING));
				portalLicenseMappingList.add(ul);
			}else{
				Long zsoid = Long.parseLong(hsPut.get(LicenseConstants.ZSOID));
				Integer noOfDaysToExtend = Integer.parseInt(hsPut.get(LicenseConstants.DAYS_TO_EXTEND));
				Long startTime = ZABUtil.getCurrentTimeInMilliSeconds();
				Long endTime = ZABUtil.getNthServerDayInLong(startTime, noOfDaysToExtend) - 1;
				HashMap<String,String> hs= new HashMap<String,String>();
				hs.put(LicenseConstants.ZSOID, zsoid.toString());
				hs.put(LicenseConstants.END_TIME, endTime.toString());
				portalLicenseMappingList.add(PortalLicenseMapping.updatePortalLicenseOfPortal( hs,zsoid));
				ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getPortalLicenseMappingResponse(request, portalLicenseMappingList));
			}
			
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), LicenseConstants.PORTAL_LICENSE_MAPPING_API_MODULE));
		}
		return null;
	}
	*/
}
