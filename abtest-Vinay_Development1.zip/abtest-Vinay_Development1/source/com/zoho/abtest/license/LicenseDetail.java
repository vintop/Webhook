//$Id$
package com.zoho.abtest.license;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.LICENSE_DETAIL;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.license.LicenseConstants.License;
import com.zoho.abtest.utility.ZABUtil;

public class LicenseDetail 
{
	private static final Logger LOGGER = Logger.getLogger(LicenseDetail.class.getName());
	
	private Long licenseDetailId;
	private Long storePlanId;
	private Integer licenseType;
	private String licenseName;
	private Integer projectCount;
	
	public Long getStorePlanId() {
		return storePlanId;
	}
	public void setStorePlanId(Long storePlanId) {
		this.storePlanId = storePlanId;
	}
	public Integer getProjectCount() {
		return projectCount;
	}
	public void setProjectCount(Integer projectCount) {
		this.projectCount = projectCount;
	}
	public Long getLicenseDetailId() {
		return licenseDetailId;
	}
	public void setLicenseDetailId(Long licenseDetailId) {
		this.licenseDetailId = licenseDetailId;
	}
	public Integer getLicenseType() {
		return licenseType;
	}
	public void setLicenseType(Integer licenseType) {
		this.licenseType = licenseType;
	}
	public String getLicenseName() {
		return licenseName;
	}
	public void setLicenseName(String licenseName) {
		this.licenseName = licenseName;
	}
	
	public static void populateLicenseDetailsInDB()
	{
		try
		{
			boolean isExists = isLicenseMetaAlreadyExists();
			if(!isExists)
			{
				ArrayList<HashMap<String, String>> hslist = new ArrayList<HashMap<String, String>>();
				for(License licenseObj:License.values())
				{
					HashMap<String, String> hs = new HashMap<String, String>();
					hs.put(LicenseConstants.STORE_PLAN_ID, licenseObj.getStorePlanId().toString());
					hs.put(LicenseConstants.LICENSE_TYPE, licenseObj.getLicenseType().toString());
					hs.put(LicenseConstants.LICENSE_NAME, licenseObj.getLicenseName());
					hs.put(LicenseConstants.PROJECT_COUNT, licenseObj.getProjectCount().toString());
					hslist.add(hs);
				}
				createLicenseDetail(hslist);
				LOGGER.log(Level.INFO, "License meta populated successfully");
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
	
	public static boolean isLicenseMetaAlreadyExists()
	{
		boolean isExists = false;
		try
		{
			DataObject dataObj = ZABModel.getRow(LICENSE_DETAIL.TABLE, null);
			if(!dataObj.isEmpty())
			{
				isExists = true;
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		return isExists;
	}
	
	public static void createLicenseDetail(ArrayList<HashMap<String, String>> hslist) 
	{
		try
		{
			ZABModel.createRow(LicenseConstants.LICENSE_DETAIL_CONSTANTS, LICENSE_DETAIL.TABLE, hslist);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
	
	public static void createLicenseDetail(HashMap<String, String> hs) 
	{
		try
		{
			ZABModel.createRow(LicenseConstants.LICENSE_DETAIL_CONSTANTS, LICENSE_DETAIL.TABLE, hs);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
	
	public static LicenseDetail getLicenseDetail(Integer licenseType)
	{
		LicenseDetail licenseDetail = null;
		try
		{
			Criteria criteria1 = new Criteria(new Column(LICENSE_DETAIL.TABLE, LICENSE_DETAIL.LICENSE_TYPE), licenseType, QueryConstants.EQUAL);
			Row row = ZABModel.getFirstRow(LICENSE_DETAIL.TABLE, criteria1);
			licenseDetail = getLicenseDetailFromRow(row);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		return licenseDetail;
	}
	
	public static LicenseDetail getLicenseDetailByPlanId(Long storePlanId)
	{
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N 
		LicenseDetail licenseDetail = null;
		try
		{
			Criteria criteria1 = new Criteria(new Column(LICENSE_DETAIL.TABLE, LICENSE_DETAIL.STORE_PLAN_ID), storePlanId, QueryConstants.EQUAL);
			Row row = ZABModel.getFirstRow(LICENSE_DETAIL.TABLE, criteria1);
			licenseDetail = getLicenseDetailFromRow(row);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		ZABUtil.setDBSpace(existingDBSpace);
		return licenseDetail;
	}
	
	public static LicenseDetail getLicenseDetail(Long licenseDetailId)
	{
		LicenseDetail licenseDetail = null;
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		try
		{
			Criteria criteria1 = new Criteria(new Column(LICENSE_DETAIL.TABLE, LICENSE_DETAIL.LICENSE_DETAIL_ID), licenseDetailId, QueryConstants.EQUAL);
			Row row = ZABModel.getFirstRow(LICENSE_DETAIL.TABLE, criteria1);
			licenseDetail = getLicenseDetailFromRow(row);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		ZABUtil.setDBSpace(existingDBSpace);
		return licenseDetail;
	}
	
	public static LicenseDetail getLicenseDetailFromRow(Row row)
	{
		LicenseDetail licenseDetail = new LicenseDetail();
		licenseDetail.setLicenseDetailId((Long)row.get(LICENSE_DETAIL.LICENSE_DETAIL_ID));
		licenseDetail.setStorePlanId((Long)row.get(LICENSE_DETAIL.STORE_PLAN_ID));
		licenseDetail.setLicenseName((String)row.get(LICENSE_DETAIL.LICENSE_NAME));
		licenseDetail.setLicenseType((Integer)row.get(LICENSE_DETAIL.LICENSE_TYPE));
		licenseDetail.setProjectCount((Integer)row.get(LICENSE_DETAIL.PROJECT_COUNT));
		return licenseDetail;
	}
	
	public static String getReadablePlanName(String planName)
	{
		if(planName != null)
		{
			switch(planName)
			{
			case "Zohoone":
				planName = "Zohoone Enterprise"; // No I18N
				break;
			case "ZohooneTrial":
				planName = "Zohoone Trial"; // No I18N
				break;
			}
		}
		return planName;
	}
	
}