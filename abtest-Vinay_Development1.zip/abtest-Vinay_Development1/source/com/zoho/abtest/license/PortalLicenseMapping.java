//$Id$
package com.zoho.abtest.license;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.iam.IAMUtil;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.AC_PORTAL;
import com.zoho.abtest.LICENSE_DETAIL;
import com.zoho.abtest.PORTAL_LICENSE_ADDON;
import com.zoho.abtest.PORTAL_LICENSE_MAPPING;
import com.zoho.abtest.PORTAL_LICENSE_YEARLY_DETAIL;
import com.zoho.abtest.auditlog.AdminConsoleAuditLog;
import com.zoho.abtest.auditlog.AuditLogConstants;
import com.zoho.abtest.auditlog.AuditLogConstants.AuditLogEntityType;
import com.zoho.abtest.auditlog.AuditLogConstants.AuditLogType;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.license.LicenseConstants.License;
import com.zoho.abtest.licenseactivity.LicenseActivityConstants;
import com.zoho.abtest.licenseactivity.LicenseActivityConstants.LicenseLogTypes;
import com.zoho.abtest.licenseactivity.LicenseActivityLog;
import com.zoho.abtest.utility.ZABUtil;

public class PortalLicenseMapping extends ZABModel
{
	private static final long serialVersionUID = 1L;

	private static final Logger LOGGER = Logger.getLogger(PortalLicenseMapping.class.getName());
	
	private Long portalLicenseMappingId;
	private Long zsoid;
	private Long licenseDetailId;
	private String storeProfileId;
	private Boolean isStoreActive;
	private Boolean isAppActive;
	private Long startTime;
	private Long endTime;
	private Long pausedTime;
	private Boolean isAnnual;
	private Integer projectCount;
	private Boolean isVisitorLimitWarned;
	private Boolean trialExpiredDataDeleted;
	
	public Boolean getTrialExpiredDataDeleted() {
		return trialExpiredDataDeleted;
	}
	public void setTrialExpiredDataDeleted(Boolean trialExpiredDataDeleted) {
		this.trialExpiredDataDeleted = trialExpiredDataDeleted;
	}
	public Boolean getIsVisitorLimitWarned() {
		return isVisitorLimitWarned;
	}
	public void setIsVisitorLimitWarned(Boolean isVisitorLimitWarned) {
		this.isVisitorLimitWarned = isVisitorLimitWarned;
	}
	public Integer getProjectCount() {
		return projectCount;
	}
	public void setProjectCount(Integer projectCount) {
		this.projectCount = projectCount;
	}
	public Long getPortalLicenseMappingId() {
		return portalLicenseMappingId;
	}
	public void setPortalLicenseMappingId(Long portalLicenseMappingId) {
		this.portalLicenseMappingId = portalLicenseMappingId;
	}
	public Long getZsoid() {
		return zsoid;
	}
	public void setZsoid(Long zsoid) {
		this.zsoid = zsoid;
	}
	public String getStoreProfileId() {
		return storeProfileId;
	}
	public void setStoreProfileId(String storeProfileId) {
		this.storeProfileId = storeProfileId;
	}
	public Boolean getIsStoreActive() {
		return isStoreActive;
	}
	public void setIsStoreActive(Boolean isStoreActive) {
		this.isStoreActive = isStoreActive;
	}
	public Boolean getIsAppActive() {
		return isAppActive;
	}
	public void setIsAppActive(Boolean isAppActive) {
		this.isAppActive = isAppActive;
	}
	public Long getLicenseDetailId() {
		return licenseDetailId;
	}
	public void setLicenseDetailId(Long licenseDetailId) {
		this.licenseDetailId = licenseDetailId;
	}
	public Long getStartTime() {
		return startTime;
	}
	public void setStartTime(Long startTime) {
		this.startTime = startTime;
	}
	public Long getEndTime() {
		return endTime;
	}
	public void setEndTime(Long endTime) {
		this.endTime = endTime;
	}
	public Long getPausedTime() {
		return pausedTime;
	}
	public void setPausedTime(Long pausedTime) {
		this.pausedTime = pausedTime;
	}
	public Boolean getIsAnnual() {
		return isAnnual;
	}
	public void setIsAnnual(Boolean isAnnual) {
		this.isAnnual = isAnnual;
	}
	
	public static void createPortalLicenseMapping(ArrayList<HashMap<String, String>> hsList) 
	{
		try
		{
			ZABModel.createRow(LicenseConstants.PORTAL_LICENSE_MAPPING_CONSTANTS, PORTAL_LICENSE_MAPPING.TABLE, hsList);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
	
	public static Long createPortalLicenseMapping(HashMap<String, String> hs) 
	{
		Long portalLicenseMappingId = null;
		try
		{
			DataObject dataObj = ZABModel.createRow(LicenseConstants.PORTAL_LICENSE_MAPPING_CONSTANTS, PORTAL_LICENSE_MAPPING.TABLE, hs);
			portalLicenseMappingId = (Long)dataObj.getFirstValue(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.PORTAL_LICENSE_MAPPING_ID);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		return portalLicenseMappingId;
	}
	
	public static void assignLicenseToPortal(Integer licenseType, Long zsoid, Boolean isAnnual, Long startTime, Long endTime, Long yearEndTime, String storeProfileId, ArrayList<HashMap<String, String>> addonList)
	{
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N 
		try
		{
			LicenseDetail licenseDetail = LicenseDetail.getLicenseDetail(licenseType);
			//Integer licenseTimespan = LicenseConstants.MONTH_DAYS_COUNT;
			//Long startTime = ZABUtil.getCurrentTimeInMilliSeconds();
			//Long endTime = ZABUtil.getNthServerDayInLong(startTime, licenseTimespan) - 1;
			
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(LicenseConstants.ZSOID, zsoid.toString());
			hs.put(LicenseConstants.LICENSE_DETAIL_ID, licenseDetail.getLicenseDetailId().toString());
			hs.put(LicenseConstants.STORE_PROFILE_ID, storeProfileId);
			hs.put(LicenseConstants.IS_STORE_ACTIVE, Boolean.TRUE.toString());
			hs.put(LicenseConstants.IS_APP_ACTIVE, Boolean.TRUE.toString());
			hs.put(LicenseConstants.IS_VISITORLIMIT_WARNED, Boolean.FALSE.toString());
			hs.put(LicenseConstants.START_TIME, startTime.toString());
			hs.put(LicenseConstants.END_TIME, endTime.toString());
			hs.put(LicenseConstants.IS_ANNUAL, isAnnual.toString());
			hs.put(LicenseConstants.PROJECT_COUNT, licenseDetail.getProjectCount().toString());
			Long portalLicenseMappingId = PortalLicenseMapping.createPortalLicenseMapping(hs);
			
			//Create addon details
			if(addonList != null)
			{
				for(HashMap<String, String> addonhs:addonList)
				{
					addonhs.put(LicenseConstants.PORTAL_LICENSE_MAPPING_ID, portalLicenseMappingId.toString());
				}
				PortalLicenseAddon.createPortalLicenseAddon(addonList);
			}
			
			/*
			if(isAnnual)
			{
				//Long yearEndTime = ZABUtil.getNthServerDayInLong(startTime, LicenseConstants.YEAR_DAYS_COUNT) - 1;
				HashMap<String, String> yearHs = new HashMap<String, String>();
				yearHs.put(LicenseConstants.PORTAL_LICENSE_MAPPING_ID, portalLicenseMappingId.toString());
				yearHs.put(LicenseConstants.YEAR_START_TIME, startTime.toString());
				yearHs.put(LicenseConstants.YEAR_END_TIME, yearEndTime.toString());
				PortalLicenseYearlyDetail.createPortalLicenseYearlyDetail(yearHs);
			}
			*/
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		ZABUtil.setDBSpace(existingDBSpace);
	}
	
	public static void updateLicenseToPortal(Long portalLicenseMappingId, Integer licenseType, Long zsoid, Boolean isAnnual, Long startTime, Long endTime, Long yearEndTime, String storeProfileId, ArrayList<HashMap<String, String>> addonList, boolean updateAddons)
	{
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N 
		try
		{
			LicenseDetail licenseDetail = LicenseDetail.getLicenseDetail(licenseType);
			//Integer licenseTimespan = LicenseConstants.MONTH_DAYS_COUNT;
			//Long startTime = ZABUtil.getCurrentTimeInMilliSeconds();
			//Long endTime = ZABUtil.getNthServerDayInLong(startTime, licenseTimespan) - 1;
			
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(LicenseConstants.ZSOID, zsoid.toString());
			hs.put(LicenseConstants.LICENSE_DETAIL_ID, licenseDetail.getLicenseDetailId().toString());
			hs.put(LicenseConstants.STORE_PROFILE_ID, storeProfileId);
			hs.put(LicenseConstants.IS_STORE_ACTIVE, Boolean.TRUE.toString());
			hs.put(LicenseConstants.IS_APP_ACTIVE, Boolean.TRUE.toString());
			hs.put(LicenseConstants.IS_VISITORLIMIT_WARNED, Boolean.FALSE.toString());
			//Checking null since there wont be start date and end date from Modify subscriptions
			if(startTime != null)
			{
				hs.put(LicenseConstants.START_TIME, startTime.toString());
			}
			if(endTime != null)
			{
				hs.put(LicenseConstants.END_TIME, endTime.toString());
			}
			hs.put(LicenseConstants.IS_ANNUAL, isAnnual.toString());
			hs.put(LicenseConstants.PROJECT_COUNT, licenseDetail.getProjectCount().toString());
			PortalLicenseMapping.updatePortalLicense(portalLicenseMappingId, hs);
			
			if(updateAddons)
			{
				//delete existing addons
				PortalLicenseAddon.deletePortalLicenseAddons(portalLicenseMappingId);
				
				//Create addon details
				if(addonList != null)
				{
					for(HashMap<String, String> addonhs:addonList)
					{
						addonhs.put(LicenseConstants.PORTAL_LICENSE_MAPPING_ID, portalLicenseMappingId.toString());
					}
					PortalLicenseAddon.createPortalLicenseAddon(addonList);
				}
			}
			
			/*
			if(isAnnual)
			{
				//Long yearEndTime = ZABUtil.getNthServerDayInLong(startTime, LicenseConstants.YEAR_DAYS_COUNT) - 1;
				HashMap<String, String> yearHs = new HashMap<String, String>();
				yearHs.put(LicenseConstants.PORTAL_LICENSE_MAPPING_ID, portalLicenseMappingId.toString());
				if(startTime == null)
				{
					startTime = ZABUtil.getCurrentTimeInMilliSeconds();
				}
				yearHs.put(LicenseConstants.YEAR_START_TIME, startTime.toString());
				yearHs.put(LicenseConstants.YEAR_END_TIME, yearEndTime.toString());
				yearHs.put(LicenseConstants.NEXT_MONTH_START_TIME, null);
				boolean isMappingExists = PortalLicenseYearlyDetail.isAnnualMappingExists(portalLicenseMappingId);
				if(isMappingExists)
				{
					PortalLicenseYearlyDetail.updatePortalLicenseYearlyDetail(portalLicenseMappingId, yearHs);
				}
				else
				{
					PortalLicenseYearlyDetail.createPortalLicenseYearlyDetail(yearHs);
				}
			}
			*/
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		ZABUtil.setDBSpace(existingDBSpace);
	}
	
	public static void processEarlyAccessUserTrials()
	{
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		try
		{
			Integer licenseTimespan = LicenseConstants.MONTH_DAYS_COUNT;
			Long startTime = ZABUtil.getCurrentTimeInMilliSeconds();
			Long endTime = ZABUtil.getNthServerDayInLong(startTime, licenseTimespan) - 1;
			Long yearEndTime = ZABUtil.getNthServerDayInLong(startTime, LicenseConstants.EXISTING_PARTNER_DAYS_COUNT) - 1;
			
			LicenseDetail trialLicObj = LicenseDetail.getLicenseDetail(License.TRIAL.getLicenseType());
			Long trialLicDetailId = trialLicObj.getLicenseDetailId();
			Criteria criteria = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.LICENSE_DETAIL_ID), trialLicDetailId, QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(PORTAL_LICENSE_MAPPING.TABLE, criteria);
			Iterator<?> iterator = dataObj.getRows(PORTAL_LICENSE_MAPPING.TABLE);
			while(iterator.hasNext())
			{
				Row row = (Row)iterator.next();
				Long portalLicenseMappingId = (Long)row.get(PORTAL_LICENSE_MAPPING.PORTAL_LICENSE_MAPPING_ID);
				extendEarlyAccessUserTrial(portalLicenseMappingId, startTime, endTime, yearEndTime);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
	
	public static void extendEarlyAccessUserTrial(Long portalLicenseMappingId,Long startTime, Long endTime,Long yearEndTime)
	{
		try
		{
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(LicenseConstants.IS_STORE_ACTIVE, Boolean.TRUE.toString());
			hs.put(LicenseConstants.IS_APP_ACTIVE, Boolean.TRUE.toString());
			hs.put(LicenseConstants.START_TIME, startTime.toString());
			hs.put(LicenseConstants.END_TIME, endTime.toString());
			hs.put(LicenseConstants.IS_ANNUAL, Boolean.TRUE.toString());
			PortalLicenseMapping.updatePortalLicense(portalLicenseMappingId, hs);
			
			//Create or update early end time
			HashMap<String, String> yearHs = new HashMap<String, String>();
			yearHs.put(LicenseConstants.PORTAL_LICENSE_MAPPING_ID, portalLicenseMappingId.toString());
			yearHs.put(LicenseConstants.YEAR_START_TIME, startTime.toString());
			yearHs.put(LicenseConstants.YEAR_END_TIME, yearEndTime.toString());
			yearHs.put(LicenseConstants.NEXT_MONTH_START_TIME, null);
			boolean isMappingExists = PortalLicenseYearlyDetail.isAnnualMappingExists(portalLicenseMappingId);
			if(isMappingExists)
			{
				PortalLicenseYearlyDetail.updatePortalLicenseYearlyDetail(portalLicenseMappingId, yearHs);
			}
			else
			{
				PortalLicenseYearlyDetail.createPortalLicenseYearlyDetail(yearHs);
			}
			
			//Update visitor count to 50K
			HashMap<String,String> addonHs = new HashMap<String, String>();
            addonHs.put(LicenseConstants.TOTAL_COUNT, LicenseConstants.EXISTING_PARTNER_VISITOR_COUNT.toString());
            PortalLicenseAddon.updatePortalLicenseAddon(portalLicenseMappingId, addonHs);
            
            LOGGER.log(Level.INFO, "extendEarlyAccessUserTrial completed - {0}", new String[]{portalLicenseMappingId.toString()});
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred while extendEarlyAccessUserTrials - {0}", new String[]{portalLicenseMappingId.toString()});
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
	
	//This method will generally used to change the trial license end time or visitor count for the zsoid
	public static PortalLicenseMapping upgradeLicense(Long zsoid , HashMap<String, String> inputHs)
	{
		PortalLicenseMapping resultObj = new PortalLicenseMapping();
		ZABUtil.setDBSpace("sharedspace");//No I18N
		try
		{
			LicenseDetail trialLicObj = LicenseDetail.getLicenseDetail(License.TRIAL.getLicenseType());
			LicenseDetail freeLicObj = LicenseDetail.getLicenseDetail(License.FREE.getLicenseType());
			PortalLicenseMapping portalLicenseMapping = PortalLicenseMapping.getPortalLicense(zsoid);
			HashMap<String, String> oldValues = constructPortalLicenseOldValueForAudit(portalLicenseMapping, inputHs);
			if((portalLicenseMapping.getLicenseDetailId().equals(trialLicObj.getLicenseDetailId())) || 
					(portalLicenseMapping.getLicenseDetailId().equals(freeLicObj.getLicenseDetailId())))
			{
				Boolean isAnnual = false;
				HashMap<String,String> hs= new HashMap<String,String>();
				hs.put(LicenseConstants.IS_STORE_ACTIVE, Boolean.TRUE.toString());
				hs.put(LicenseConstants.IS_APP_ACTIVE, Boolean.TRUE.toString());
				hs.put(LicenseConstants.IS_VISITORLIMIT_WARNED, Boolean.FALSE.toString());
				
				if(portalLicenseMapping.getLicenseDetailId().equals(freeLicObj.getLicenseDetailId()))
				{
					hs.put(LicenseConstants.START_TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
					hs.put(LicenseConstants.LICENSE_DETAIL_ID, trialLicObj.getLicenseDetailId().toString());
				}
				
				if(inputHs.containsKey(LicenseConstants.END_TIME))
				{
					String expiryDateStr = inputHs.get(LicenseConstants.END_TIME);
					Long expiryTime = ZABUtil.getServerTimeInLongFromDateFormStr(expiryDateStr, "yyyy-MM-dd");		// NO I18N
					expiryTime =  ZABUtil.getNthServerDayInLong(expiryTime, 1) - 1;
					hs.put(LicenseConstants.END_TIME, expiryTime.toString());
					//To use in audit log
					inputHs.put(LicenseConstants.END_TIME, expiryTime.toString());
				}
				if(inputHs.containsKey(LicenseConstants.PROJECT_COUNT))
				{
					Integer projectCount = Integer.parseInt(inputHs.get(LicenseConstants.PROJECT_COUNT));
					if(projectCount > 0)
					{
						hs.put(LicenseConstants.PROJECT_COUNT, projectCount.toString());
					}
				}
				if(inputHs.containsKey(LicenseConstants.IS_ANNUAL))
				{
					isAnnual = Boolean.parseBoolean(inputHs.get(LicenseConstants.IS_ANNUAL));
					hs.put(LicenseConstants.IS_ANNUAL, isAnnual.toString());
				}
				PortalLicenseMapping.updatePortalLicense(portalLicenseMapping.getPortalLicenseMappingId(), hs);

				//Update total count
				if(inputHs.containsKey(LicenseConstants.TOTAL_COUNT))
				{
					Long totalCount = Long.parseLong(inputHs.get(LicenseConstants.TOTAL_COUNT));
					if(totalCount > 0)
					{
						HashMap<String,String> addonHs = new HashMap<String, String>();
			            addonHs.put(LicenseConstants.TOTAL_COUNT, totalCount.toString());
			            if(portalLicenseMapping.getLicenseDetailId().equals(freeLicObj.getLicenseDetailId()))
			            {
			            	//delete existing addons
							PortalLicenseAddon.deletePortalLicenseAddons(portalLicenseMapping.getPortalLicenseMappingId());
			            	
			            	Long storeAddonId = 0l;
			            	addonHs.put(LicenseConstants.STORE_ADDON_ID, storeAddonId.toString());
			            	addonHs.put(LicenseConstants.PORTAL_LICENSE_MAPPING_ID, portalLicenseMapping.getPortalLicenseMappingId().toString());
			            	ArrayList<HashMap<String, String>> addonList = new ArrayList<HashMap<String,String>>();
			            	addonList.add(addonHs);
			            	PortalLicenseAddon.createPortalLicenseAddon(addonList);
			            }
			            else
			            {
			            	PortalLicenseAddon.updatePortalLicenseAddon(portalLicenseMapping.getPortalLicenseMappingId(), addonHs);
			            }
					}
				}
				resultObj.setSuccess(true);
				
				//AuditLog starts
				logLicenseUpdate(portalLicenseMapping, inputHs, oldValues);
				//AuditLog ends
			}
			else
			{
				//Update only project count
				if(inputHs.containsKey(LicenseConstants.PROJECT_COUNT))
				{
					HashMap<String,String> hs= new HashMap<String,String>();
					Integer projectCount = Integer.parseInt(inputHs.get(LicenseConstants.PROJECT_COUNT));
					if(projectCount > 0)
					{
						hs.put(LicenseConstants.PROJECT_COUNT, projectCount.toString());
					}
					PortalLicenseMapping.updatePortalLicense(portalLicenseMapping.getPortalLicenseMappingId(), hs);
					
					//AuditLog starts
					logLicenseUpdate(portalLicenseMapping, hs, oldValues);
					//AuditLog ends
				}
				
				resultObj.setSuccess(false);
				resultObj.setResponseString("ZSOID not in trial,hence only project count is updated !"); //No I18N
			}
			
		}
		catch(Exception ex)
		{
			resultObj.setSuccess(false);
			resultObj.setResponseString(ex.getMessage());
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		return resultObj;
	}
	
	public static HashMap<String, String> constructPortalLicenseOldValueForAudit(PortalLicenseMapping portalLicenseMapping, HashMap<String, String> newValues)
	{
		HashMap<String, String> oldValues = new HashMap<String, String>();
		try
		{
			for(String attrName:AuditLogConstants.LICENSE_UPDATE_ATTR_TO_TRACE)
			{
				if(newValues.containsKey(attrName))
				{
					switch(attrName)
					{
					case LicenseConstants.END_TIME:
						oldValues.put(LicenseConstants.END_TIME, portalLicenseMapping.getEndTime().toString());
						break;
					case LicenseConstants.PROJECT_COUNT:
						oldValues.put(LicenseConstants.PROJECT_COUNT, portalLicenseMapping.getProjectCount().toString());
						break;
					case LicenseConstants.TOTAL_COUNT:
						Long totalCount = 0l;
						LicenseDetail detail = LicenseDetail.getLicenseDetail(portalLicenseMapping.getLicenseDetailId());
						totalCount = PortalLicenseAddon.getPlanVisitorCount(portalLicenseMapping.getPortalLicenseMappingId(), detail.getStorePlanId(),portalLicenseMapping.getIsAnnual());
						oldValues.put(LicenseConstants.TOTAL_COUNT, totalCount.toString());
						break;
					}
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		return oldValues;
	}
	
	public static void logLicenseUpdate(PortalLicenseMapping portalLicenseMapping, HashMap<String, String> newValues,HashMap<String, String> oldValues)
	{
		ArrayList<HashMap<String, String>> hsList = new ArrayList<HashMap<String, String>>();
		try
		{
			Long currentTime = ZABUtil.getCurrentTimeInMilliSeconds();
			for(String attrName:AuditLogConstants.LICENSE_UPDATE_ATTR_TO_TRACE)
			{
				if(newValues.containsKey(attrName))
				{
					HashMap<String, String> hs = new HashMap<String, String>();
					hs.put(AuditLogConstants.ENTITY_TYPE, AuditLogEntityType.SPACE.getEntityType().toString());
					hs.put(AuditLogConstants.ENTITY_VALUE, portalLicenseMapping.getZsoid().toString());
					hs.put(AuditLogConstants.TIME, currentTime.toString());
					hs.put(AuditLogConstants.USER_ZUID, String.valueOf(IAMUtil.getCurrentUser().getZUID()));
					switch(attrName)
					{
					case LicenseConstants.END_TIME:
						hs.put(AuditLogConstants.LOG_TYPE, AuditLogType.EDIT_SPACE_LICENSE_ENDDATE.getLogType().toString());
						break;
					case LicenseConstants.PROJECT_COUNT:
						hs.put(AuditLogConstants.LOG_TYPE, AuditLogType.EDIT_SPACE_LICENSE_PROJECTCOUNT.getLogType().toString());
						break;
					case LicenseConstants.TOTAL_COUNT:
						hs.put(AuditLogConstants.LOG_TYPE, AuditLogType.EDIT_SPACE_LICENSE_VISITORCOUNT.getLogType().toString());
						break;
					}
					hs.put(AuditLogConstants.OLD_VALUE, oldValues.get(attrName));
					hs.put(AuditLogConstants.NEW_VALUE, newValues.get(attrName));
					if(!oldValues.get(attrName).equals(newValues.get(attrName)))
					{
						hsList.add(hs);
					}
				}
			}
			
			if(hsList.size() > 0)
			{
				AdminConsoleAuditLog.createAdminConsoleAuditLog(hsList);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
	
	public static void mapLicenseYearlyDetail()
	{
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		try
		{
			LicenseDetail trialObj = LicenseDetail.getLicenseDetail(License.TRIAL.getLicenseType());
			Long trialLicenseDetailId = trialObj.getLicenseDetailId();
			Criteria c1 = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.IS_ANNUAL), Boolean.TRUE, QueryConstants.EQUAL);
			//Join join1 = new Join(PORTAL_LICENSE_MAPPING.TABLE, LICENSE_DETAIL.TABLE, new String[]{PORTAL_LICENSE_MAPPING.LICENSE_DETAIL_ID}, new String[]{LICENSE_DETAIL.LICENSE_DETAIL_ID}, Join.INNER_JOIN);
			Join join2 = new Join(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_YEARLY_DETAIL.TABLE, new String[]{PORTAL_LICENSE_MAPPING.PORTAL_LICENSE_MAPPING_ID}, new String[]{PORTAL_LICENSE_YEARLY_DETAIL.PORTAL_LICENSE_MAPPING_ID}, Join.INNER_JOIN);
			Join join3 = new Join(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_ADDON.TABLE, new String[]{PORTAL_LICENSE_MAPPING.PORTAL_LICENSE_MAPPING_ID}, new String[]{PORTAL_LICENSE_ADDON.PORTAL_LICENSE_MAPPING_ID}, Join.INNER_JOIN);
			DataObject dataObj = ZABModel.getRow(PORTAL_LICENSE_MAPPING.TABLE, c1, new Join[]{join2,join3});
			Iterator<?> iterator = dataObj.getRows(PORTAL_LICENSE_MAPPING.TABLE);
			while(iterator.hasNext())
			{
				Row row = (Row)iterator.next();
				PortalLicenseMapping portalLicenseMappingObj = PortalLicenseMapping.getPortalLicenseMappingFromRow(row);
				try
				{
					LOGGER.log(Level.INFO, "Started for {0}", new String[]{portalLicenseMappingObj.getZsoid().toString()});
					Criteria c3 = new Criteria(new Column(PORTAL_LICENSE_YEARLY_DETAIL.TABLE, PORTAL_LICENSE_YEARLY_DETAIL.PORTAL_LICENSE_MAPPING_ID), portalLicenseMappingObj.getPortalLicenseMappingId(), QueryConstants.EQUAL);
					Long yearEndTime = (Long)dataObj.getValue(PORTAL_LICENSE_YEARLY_DETAIL.TABLE, PORTAL_LICENSE_YEARLY_DETAIL.YEAR_END_TIME, c3);
					if(yearEndTime != null)
					{
						HashMap<String, String> mappingHs = new HashMap<String, String>();
						mappingHs.put(LicenseConstants.END_TIME, yearEndTime.toString());
						if(trialLicenseDetailId.equals(portalLicenseMappingObj.getLicenseDetailId()))
						{
							mappingHs.put(LicenseConstants.IS_ANNUAL, Boolean.FALSE.toString());
						}
						PortalLicenseMapping.updatePortalLicense(portalLicenseMappingObj.getPortalLicenseMappingId(), mappingHs);
					}
					
					if(trialLicenseDetailId.equals(portalLicenseMappingObj.getLicenseDetailId()))
					{
						Criteria c4 = new Criteria(new Column(PORTAL_LICENSE_ADDON.TABLE, PORTAL_LICENSE_ADDON.PORTAL_LICENSE_MAPPING_ID), portalLicenseMappingObj.getPortalLicenseMappingId(), QueryConstants.EQUAL);
						Integer totalCount = (Integer)dataObj.getValue(PORTAL_LICENSE_ADDON.TABLE, PORTAL_LICENSE_ADDON.TOTAL_COUNT, c4);
						if(totalCount != null)
						{
							totalCount = totalCount * 2; 
							HashMap<String, String> addonHs = new HashMap<String, String>();
							addonHs.put(LicenseConstants.TOTAL_COUNT, totalCount.toString());
							PortalLicenseAddon.updatePortalLicenseAddon(portalLicenseMappingObj.getPortalLicenseMappingId(), addonHs);
						}
					}
					LOGGER.log(Level.INFO, "Completed for {0}", new String[]{portalLicenseMappingObj.getZsoid().toString()});
				}
				catch(Exception ex)
				{
					LOGGER.log(Level.INFO, "Error for {0}", new String[]{portalLicenseMappingObj.getZsoid().toString()});
					LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
	
	public static void extendPortalLicenseEndTime(Long portalLicenseMappingId, Long endTime)
	{
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N 
		try
		{
			//Integer licenseTimespan = LicenseConstants.MONTH_DAYS_COUNT;
			//Long startTime = ZABUtil.getCurrentTimeInMilliSeconds();
			//Long endTime = ZABUtil.getNthServerDayInLong(startTime, licenseTimespan) - 1;
			
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(LicenseConstants.IS_STORE_ACTIVE, Boolean.TRUE.toString());
			hs.put(LicenseConstants.IS_APP_ACTIVE, Boolean.TRUE.toString());
			//Checking null since there wont be start date and end date from Modify subscriptions
			hs.put(LicenseConstants.END_TIME, endTime.toString());
			PortalLicenseMapping.updatePortalLicense(portalLicenseMappingId, hs);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		ZABUtil.setDBSpace(existingDBSpace);
	}
	
	public static Long getPortalLicenseMappingIdByZsoid(Long zsoid)
	{
		Long portalLicenseMappingId = null;
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N 
		try
		{
			Criteria criteria1 = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.ZSOID), zsoid, QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(PORTAL_LICENSE_MAPPING.TABLE, criteria1);
			if(!dataObj.isEmpty())
			{
				portalLicenseMappingId = (Long)dataObj.getFirstValue(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.PORTAL_LICENSE_MAPPING_ID);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		ZABUtil.setDBSpace(existingDBSpace);
		return portalLicenseMappingId;
	}
	
	public static int getPortalLicenseProjectLimit(Long zsoid)
	{
		Integer projectCount = 0;
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N 
		try
		{
			Criteria criteria1 = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.ZSOID), zsoid, QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(PORTAL_LICENSE_MAPPING.TABLE, criteria1);
			projectCount = (Integer)dataObj.getFirstValue(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.PROJECT_COUNT);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		ZABUtil.setDBSpace(existingDBSpace);
		return projectCount;
	}
	
	public static int getPortalLicenseWebhookLimit(Long zsoid)
	{
		Integer webhookCount = 0;
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N 
		try
		{
			Criteria criteria1 = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.ZSOID), zsoid, QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(PORTAL_LICENSE_MAPPING.TABLE, criteria1);
			webhookCount = (Integer)dataObj.getFirstValue(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.PROJECT_COUNT);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		ZABUtil.setDBSpace(existingDBSpace);
		return webhookCount;
	}
	
	public static void updatePortalLicense(Long portalLicenseMappingId, HashMap<String, String> hs)
	{
		try
		{
			Criteria criteria1 = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.PORTAL_LICENSE_MAPPING_ID), portalLicenseMappingId, QueryConstants.EQUAL);
			ZABModel.updateRow(LicenseConstants.PORTAL_LICENSE_MAPPING_CONSTANTS, PORTAL_LICENSE_MAPPING.TABLE, hs, criteria1, null);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
	public static PortalLicenseMapping updatePortalLicenseOfPortal( HashMap<String, String> hs,Long zsoid)
	{
		String currentSpace = ZABUtil.getCurrentUserDbSpace();
		ZABUtil.setDBSpace("sharedspace");  //No I18N
		PortalLicenseMapping portallicMapping = new PortalLicenseMapping();
		try
		{
			Criteria criteria1 = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.ZSOID), zsoid, QueryConstants.EQUAL);
			ZABModel.updateRow(LicenseConstants.PORTAL_LICENSE_MAPPING_CONSTANTS, PORTAL_LICENSE_MAPPING.TABLE, hs, criteria1, null);
			portallicMapping = getPortalLicense(zsoid);
		}
		catch(Exception ex)
		{
			portallicMapping.setSuccess(Boolean.FALSE);
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		ZABUtil.setDBSpace(currentSpace);
		return portallicMapping;
	}
	
	public static PortalLicenseMapping getPortalLicense(Long zsoid)
	{
		PortalLicenseMapping portalLicenseMapping = null;
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		try
		{
			Criteria criteria1 = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.ZSOID), zsoid, QueryConstants.EQUAL);
			Row row = ZABModel.getFirstRow(PORTAL_LICENSE_MAPPING.TABLE, criteria1);
			if(row != null)
			{
				portalLicenseMapping = getPortalLicenseMappingFromRow(row);
				portalLicenseMapping.setSuccess(Boolean.TRUE);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		ZABUtil.setDBSpace(existingDBSpace);
		return portalLicenseMapping;
	}
	
	public static PortalLicenseMapping getPortalLicenseMappingFromRow(Row row)
	{
		PortalLicenseMapping portalLicenseMapping = new PortalLicenseMapping();
		portalLicenseMapping.setPortalLicenseMappingId((Long)row.get(PORTAL_LICENSE_MAPPING.PORTAL_LICENSE_MAPPING_ID));
		portalLicenseMapping.setZsoid((Long)row.get(PORTAL_LICENSE_MAPPING.ZSOID));
		portalLicenseMapping.setLicenseDetailId((Long)row.get(PORTAL_LICENSE_MAPPING.LICENSE_DETAIL_ID));
		portalLicenseMapping.setStoreProfileId((String)row.get(PORTAL_LICENSE_MAPPING.STORE_PROFILE_ID));
		portalLicenseMapping.setIsAppActive((Boolean)row.get(PORTAL_LICENSE_MAPPING.IS_APP_ACTIVE));
		portalLicenseMapping.setIsStoreActive((Boolean)row.get(PORTAL_LICENSE_MAPPING.IS_STORE_ACTIVE));
		portalLicenseMapping.setStartTime((Long)row.get(PORTAL_LICENSE_MAPPING.START_TIME));
		portalLicenseMapping.setEndTime((Long)row.get(PORTAL_LICENSE_MAPPING.END_TIME));
		portalLicenseMapping.setPausedTime((Long)row.get(PORTAL_LICENSE_MAPPING.PAUSED_TIME));
		portalLicenseMapping.setIsAnnual((Boolean)row.get(PORTAL_LICENSE_MAPPING.IS_ANNUAL));
		portalLicenseMapping.setProjectCount((Integer)row.get(PORTAL_LICENSE_MAPPING.PROJECT_COUNT));
		portalLicenseMapping.setIsVisitorLimitWarned((Boolean)row.get(PORTAL_LICENSE_MAPPING.IS_VISITORLIMIT_WARNED));
		portalLicenseMapping.setTrialExpiredDataDeleted((Boolean)row.get(PORTAL_LICENSE_MAPPING.TRIALEXPIREDDATA_DELETED));
		return portalLicenseMapping;
	}
	public static Boolean getLicenseStatus(){
		Boolean licenseisActive = false;
	
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		try
		{
			Criteria portalCri =  new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE,PORTAL_LICENSE_MAPPING.ZSOID),existingDBSpace,QueryConstants.EQUAL);
			DataObject dobj = ZABModel.getRow(PORTAL_LICENSE_MAPPING.TABLE, portalCri);
			if(dobj.containsTable(PORTAL_LICENSE_MAPPING.TABLE)){
				licenseisActive = (Boolean) dobj.getFirstValue(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.IS_APP_ACTIVE);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		ZABUtil.setDBSpace(existingDBSpace);
		return licenseisActive;
		
	}
	
	public static LicenseDetail getLicenseDetailOfPortal(Long zsoid){
		LicenseDetail licdetail = null;
		String currentSpace = ZABUtil.getCurrentUserDbSpace();
		ZABUtil.setDBSpace("sharedspace");//No I18N
		try{
			
			Criteria c = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE,PORTAL_LICENSE_MAPPING.ZSOID),zsoid,QueryConstants.EQUAL);
			Join join = new Join(PORTAL_LICENSE_MAPPING.TABLE, LICENSE_DETAIL.TABLE, new String[]{PORTAL_LICENSE_MAPPING.LICENSE_DETAIL_ID},new String[]{LICENSE_DETAIL.LICENSE_DETAIL_ID},Join.INNER_JOIN);
			DataObject dobj = ZABModel.getRow(PORTAL_LICENSE_MAPPING.TABLE, c, join);
			if(dobj.containsTable(LICENSE_DETAIL.TABLE)){
				Row licenseDetailRow = dobj.getFirstRow(LICENSE_DETAIL.TABLE);
				licdetail = LicenseDetail.getLicenseDetailFromRow(licenseDetailRow);
			}
			
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		ZABUtil.setDBSpace(currentSpace);
		return licdetail;
	}
	
	//This will be used from Zohoone util only
	public static HashMap<String, String> getPortalZohoOneLicenseDetails(Long zsoid)
	{
		HashMap<String, String> hs = new HashMap<String, String>();
		String currentSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");//No I18N
		try{
			Long[] zohooneAdddons = new Long[]{License.ZOHOONE.getAddonId(), License.ZOHOONETRIAL.getAddonId()};
			Criteria criteria1 = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE,PORTAL_LICENSE_MAPPING.ZSOID),zsoid,QueryConstants.EQUAL);
			Criteria criteria2 = new Criteria(new Column(PORTAL_LICENSE_ADDON.TABLE,PORTAL_LICENSE_ADDON.STORE_ADDON_ID),zohooneAdddons,QueryConstants.IN);
			Join join1 = new Join(PORTAL_LICENSE_MAPPING.TABLE, LICENSE_DETAIL.TABLE, new String[]{PORTAL_LICENSE_MAPPING.LICENSE_DETAIL_ID},new String[]{LICENSE_DETAIL.LICENSE_DETAIL_ID},Join.INNER_JOIN);
			Join join2 = new Join(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_ADDON.TABLE, new String[]{PORTAL_LICENSE_MAPPING.PORTAL_LICENSE_MAPPING_ID},new String[]{PORTAL_LICENSE_ADDON.PORTAL_LICENSE_MAPPING_ID},Join.LEFT_JOIN);
			DataObject dobj = ZABModel.getRow(PORTAL_LICENSE_MAPPING.TABLE, criteria1.and(criteria2), new Join[]{join1,join2});
			Long planId = (Long)dobj.getFirstValue(LICENSE_DETAIL.TABLE, LICENSE_DETAIL.STORE_PLAN_ID);
			hs.put("planId", planId.toString());
			if(dobj.containsTable(PORTAL_LICENSE_ADDON.TABLE))
			{
				Long addonId = (Long)dobj.getFirstValue(PORTAL_LICENSE_ADDON.TABLE, PORTAL_LICENSE_ADDON.STORE_ADDON_ID);
				Integer totalCount = (Integer)dobj.getFirstValue(PORTAL_LICENSE_ADDON.TABLE, PORTAL_LICENSE_ADDON.TOTAL_COUNT);
				if(addonId != null)
				{
					hs.put("addonId", planId.toString());
				}
				if(totalCount != null)
				{
					hs.put("totalCount", totalCount.toString());
				}
			}
			
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		ZABUtil.setDBSpace(currentSpace);
		return hs;
	}
	
}