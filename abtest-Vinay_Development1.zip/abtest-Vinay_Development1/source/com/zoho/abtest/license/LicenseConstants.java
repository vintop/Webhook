//$Id$
package com.zoho.abtest.license;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.zoho.abtest.LICENSE_DETAIL;
import com.zoho.abtest.PORTAL_LICENSE_MAPPING;
import com.zoho.abtest.PORTAL_LICENSE_YEARLY_DETAIL;
import com.zoho.abtest.PORTAL_LICENSE_ADDON;
import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.ZABConstants;

public class LicenseConstants 
{
	public static final String API_MODULE = "license"; 	// NO I18N
	public static final String TRIAL = "trial"; //No I18N
	public static final String SUBSCRIBED = "subscribed"; //No I18N

	public static final String LICENSE_DETAIL_ID = "license_detail_id"; //No I18N
	public static final String STORE_PLAN_ID = "store_plan_id"; //No I18N
	public static final String LICENSE_TYPE = "license_type"; //No I18N
	public static final String LICENSE_NAME = "license_name"; //No I18N
	public static final String PROJECT_COUNT = "project_count"; //No I18N
	public static final String PORTAL_LICENSE_MAPPING_ID = "portal_license_mapping_id"; //No I18N
	public static final String ZSOID = "zsoid"; //No I18N
	public static final String STORE_PROFILE_ID = "store_profile_id"; //No I18N
	public static final String IS_STORE_ACTIVE = "is_store_active"; //No I18N
	public static final String IS_APP_ACTIVE = "is_app_active"; //No I18N
	public static final String START_TIME = "start_time"; //No I18N
	public static final String END_TIME = "end_time"; //No I18N
	public static final String PAUSED_TIME = "paused_time"; //No I18N
	public static final String IS_ANNUAL = "is_annual"; //No I18N
	public static final String IS_VISITORLIMIT_WARNED = "is_visitorlimit_warned"; //No I18N
	public static final String TRIALEXPIREDDATA_DELETED = "trialexpireddata_deleted"; //No I18N
	public static final String YEAR_START_TIME = "year_start_time"; //No I18N
	public static final String YEAR_END_TIME = "year_end_time"; //No I18N
	public static final String NEXT_MONTH_START_TIME = "next_month_start_time"; //No I18N	
	public static final String PORTAL_LICENSE_ADDON_ID = "portal_license_addon_id"; //No I18N
	public static final String STORE_ADDON_ID = "store_addon_id"; //No I18N
	public static final String TOTAL_COUNT = "total_count"; //No I18N
	public static final Integer YEAR_DAYS_COUNT = 365;
	public static final Integer YEAR_MONTH_COUNT = 12;
	public static final Integer MONTH_DAYS_COUNT = 30;
	public static final Integer EXISTING_PARTNER_DAYS_COUNT = 60;
	public static final Integer PRODUCTHUNT_DAYS_COUNT = 60;
	public static final Integer SWITCHOPTIMIZELY_DAYS_COUNT = 90;
	public static final String DAYS_TO_EXTEND = "days_to_extend";	// NO I18N
	
	public static final Integer TRIAL_VISITOR_COUNT = 5000;
	public static final Integer EXISTING_PARTNER_VISITOR_COUNT = 50000;
	public static final Integer PRODUCTHUNT_VISITOR_COUNT = 40000;
	public static final Integer SWITCHOPTIMIZELY_VISITOR_COUNT = 15000;
	public static final Integer ZOHONE_TRIAL_VISITOR_COUNT = 30000;
	public static final Integer ZOHONE_PER_USER_VISITOR_COUNT = 30000;
	
	public static final Integer ZOHOSTORE_PAGESENSE_ID = 500000;
	public static final String ZOHOSTORE_IAMSERVICENAME = "ZohoPayments"; //No I18N
	
	public static final String LICENSE_WARNING_MAIL_SUBJECT = "license.warning.mail.subject"; //No I18N
	
	public static final String PORTAL_LICENSE_MAPPING_API_MODULE = "portallicensemapping"; //No I18N
	
	public static final String LICENSE_PORTAL_LIMIT_EXCEED = "license.portal.limit.exceed"; //No I18N
	public static final String LICENSE_PROJECT_LIMIT_EXCEED = "license.project.limit.exceed"; //No I18N
	public static final String LICENSE_PORTAL_LIMIT = "license.portal.limit"; //No I18N
	
	public static enum MailToSendType
	{
		VISITOR_ABOUT_TO_REACH(1),
		VISITOR_OR_TIME_EXPIRED(2);
		
		private int type;
		
		private MailToSendType(int type)
		{
			this.setType(type);
		}

		public int getType() {
			return type;
		}

		public void setType(int type) {
			this.type = type;
		}
	}
	
	public static enum BCCMailers
	{
		NO_BCC(0),
		TEAM_BCC(1),
		TEAM_AND_SALES_BCC(2);
		
		private int type;
		
		private BCCMailers(int type)
		{
			this.setType(type);
		}

		public int getType() {
			return type;
		}

		public void setType(int type) {
			this.type = type;
		}
	}
	
	// Addonids will not be used from here, it will be directly took from Subscriptions and put into DB
	// But for ZOHOONETRIAL and ZOHOONE, it will used from here only for Zohoone user count checking in updateMembers and check memebr status
	public static enum License
	{
		TRIAL(0l,0,"Trial",3,0l), //NO I18N
		FREE(500100l,1,"Free",3,0l), //NO I18N
		STANDARD(500101l,2,"Standard",3,500201l), //NO I18N
		PROFESSIONAL(500102l,3,"Professional",5,500202l), //NO I18N
		ENTERPRISE(500103l,4,"Enterprise",25,500203l), //NO I18N
		ZOHOONETRIAL(500306l,5,"ZohooneTrial",3,500406l), //NO I18N
		ZOHOONE(500106l,6,"Zohoone",25,500206l); //NO I18N
		
		private Long storePlanId;
		private Integer licenseType;
		private String licenseName;
		private Integer projectCount;
		private Long addonId;
		
		private License(Long storePlanId, Integer licenseType,String licenseName,Integer projectCount,Long addonId)
		{
			this.storePlanId = storePlanId;
			this.licenseType = licenseType;
			this.licenseName = licenseName;
			this.projectCount = projectCount;
			this.addonId = addonId;
		}

		public Long getStorePlanId() {
			return storePlanId;
		}

		public void setStorePlanId(Long storePlanId) {
			this.storePlanId = storePlanId;
		}

		public Integer getLicenseType() {
			return licenseType;
		}

		public void setLicenseType(Integer licenseType) {
			this.licenseType = licenseType;
		}

		public String getLicenseName() {
			return licenseName;
		}

		public void setLicenseName(String licenseName) {
			this.licenseName = licenseName;
		}

		public Integer getProjectCount() {
			return projectCount;
		}

		public void setProjectCount(Integer projectCount) {
			this.projectCount = projectCount;
		}

		public Long getAddonId() {
			return addonId;
		}

		public void setAddonId(Long addonId) {
			this.addonId = addonId;
		}
	}
	
	public final static List<Constants> LICENSE_DETAIL_CONSTANTS;
	
	static{
		ArrayList<Constants> licenseDetailConsts = new ArrayList<Constants>();
		licenseDetailConsts.add(new Constants(LICENSE_DETAIL_ID,LICENSE_DETAIL.LICENSE_DETAIL_ID,ZABConstants.LONG,Boolean.FALSE));
		licenseDetailConsts.add(new Constants(STORE_PLAN_ID,LICENSE_DETAIL.STORE_PLAN_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.TRUE));
		licenseDetailConsts.add(new Constants(LICENSE_TYPE,LICENSE_DETAIL.LICENSE_TYPE,ZABConstants.INTEGER,Boolean.TRUE));
		licenseDetailConsts.add(new Constants(LICENSE_NAME,LICENSE_DETAIL.LICENSE_NAME,ZABConstants.STRING,Boolean.TRUE));
		licenseDetailConsts.add(new Constants(PROJECT_COUNT,LICENSE_DETAIL.PROJECT_COUNT,ZABConstants.INTEGER,Boolean.TRUE));
		LICENSE_DETAIL_CONSTANTS = (List<Constants>) Collections.unmodifiableList(licenseDetailConsts);
	}
	
	public final static List<Constants> PORTAL_LICENSE_MAPPING_CONSTANTS;
	
	static{
		ArrayList<Constants> portalLicenseMappingConsts = new ArrayList<Constants>();
		portalLicenseMappingConsts.add(new Constants(PORTAL_LICENSE_MAPPING_ID,PORTAL_LICENSE_MAPPING.PORTAL_LICENSE_MAPPING_ID,ZABConstants.LONG,Boolean.FALSE));
		portalLicenseMappingConsts.add(new Constants(ZSOID,PORTAL_LICENSE_MAPPING.ZSOID,ZABConstants.LONG,Boolean.TRUE));
		portalLicenseMappingConsts.add(new Constants(LICENSE_DETAIL_ID,PORTAL_LICENSE_MAPPING.LICENSE_DETAIL_ID,ZABConstants.LONG,Boolean.TRUE));
		portalLicenseMappingConsts.add(new Constants(STORE_PROFILE_ID,PORTAL_LICENSE_MAPPING.STORE_PROFILE_ID,ZABConstants.STRING,Boolean.TRUE,Boolean.TRUE));
		portalLicenseMappingConsts.add(new Constants(IS_STORE_ACTIVE,PORTAL_LICENSE_MAPPING.IS_STORE_ACTIVE,ZABConstants.BOOLEAN,Boolean.TRUE));
		portalLicenseMappingConsts.add(new Constants(IS_APP_ACTIVE,PORTAL_LICENSE_MAPPING.IS_APP_ACTIVE,ZABConstants.BOOLEAN,Boolean.TRUE));
		portalLicenseMappingConsts.add(new Constants(START_TIME,PORTAL_LICENSE_MAPPING.START_TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.TRUE));
		portalLicenseMappingConsts.add(new Constants(END_TIME,PORTAL_LICENSE_MAPPING.END_TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.TRUE));
		portalLicenseMappingConsts.add(new Constants(PAUSED_TIME,PORTAL_LICENSE_MAPPING.PAUSED_TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.TRUE));
		portalLicenseMappingConsts.add(new Constants(IS_ANNUAL,PORTAL_LICENSE_MAPPING.IS_ANNUAL,ZABConstants.BOOLEAN,Boolean.TRUE));
		portalLicenseMappingConsts.add(new Constants(PROJECT_COUNT,PORTAL_LICENSE_MAPPING.PROJECT_COUNT,ZABConstants.INTEGER,Boolean.TRUE));
		portalLicenseMappingConsts.add(new Constants(IS_VISITORLIMIT_WARNED,PORTAL_LICENSE_MAPPING.IS_VISITORLIMIT_WARNED,ZABConstants.BOOLEAN,Boolean.TRUE));
		portalLicenseMappingConsts.add(new Constants(TRIALEXPIREDDATA_DELETED,PORTAL_LICENSE_MAPPING.TRIALEXPIREDDATA_DELETED,ZABConstants.BOOLEAN,Boolean.TRUE));
		PORTAL_LICENSE_MAPPING_CONSTANTS = (List<Constants>) Collections.unmodifiableList(portalLicenseMappingConsts);
	}
	
	public final static List<Constants> PORTAL_LICENSE_ADDON_CONSTANTS;
	
	static{
		ArrayList<Constants> portalLicenseAddonConsts = new ArrayList<Constants>();
		portalLicenseAddonConsts.add(new Constants(PORTAL_LICENSE_ADDON_ID,PORTAL_LICENSE_ADDON.PORTAL_LICENSE_ADDON_ID,ZABConstants.LONG,Boolean.TRUE));
		portalLicenseAddonConsts.add(new Constants(PORTAL_LICENSE_MAPPING_ID,PORTAL_LICENSE_ADDON.PORTAL_LICENSE_MAPPING_ID,ZABConstants.LONG,Boolean.TRUE));
		portalLicenseAddonConsts.add(new Constants(STORE_ADDON_ID,PORTAL_LICENSE_ADDON.STORE_ADDON_ID,ZABConstants.LONG,Boolean.TRUE));
		portalLicenseAddonConsts.add(new Constants(TOTAL_COUNT,PORTAL_LICENSE_ADDON.TOTAL_COUNT,ZABConstants.INTEGER,Boolean.TRUE,Boolean.TRUE));
		PORTAL_LICENSE_ADDON_CONSTANTS = (List<Constants>) Collections.unmodifiableList(portalLicenseAddonConsts);
	}
	
	public final static List<Constants> PORTAL_LICENSE_YEARLY_DETAIL_CONSTANTS;
	
	static{
		ArrayList<Constants> portalLicenseYearlydetailConsts = new ArrayList<Constants>();
		portalLicenseYearlydetailConsts.add(new Constants(PORTAL_LICENSE_MAPPING_ID,PORTAL_LICENSE_YEARLY_DETAIL.PORTAL_LICENSE_MAPPING_ID,ZABConstants.LONG,Boolean.TRUE));
		portalLicenseYearlydetailConsts.add(new Constants(YEAR_START_TIME,PORTAL_LICENSE_YEARLY_DETAIL.YEAR_START_TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.TRUE));
		portalLicenseYearlydetailConsts.add(new Constants(YEAR_END_TIME,PORTAL_LICENSE_YEARLY_DETAIL.YEAR_END_TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.TRUE));
		portalLicenseYearlydetailConsts.add(new Constants(NEXT_MONTH_START_TIME,PORTAL_LICENSE_YEARLY_DETAIL.NEXT_MONTH_START_TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.TRUE));
		PORTAL_LICENSE_YEARLY_DETAIL_CONSTANTS = (List<Constants>) Collections.unmodifiableList(portalLicenseYearlydetailConsts);
	}
}
