//$Id$
package com.zoho.abtest.dimension;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;

import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABRequest;

public class DynamicAttributeRequest extends ZABRequest{
	
	@Override
	public void updateFromRequest(HashMap<String, String> map, HttpServletRequest request) 
	{
		
	}
	
	@Override
	public void specificValidation(HashMap<String, String> map, HttpServletRequest request) throws IOException, JSONException 
	{
		ArrayList<String> fields = new ArrayList<String>();
		String httpMethod = ZABAction.getHTTPMethod(request).toString();
		if(httpMethod.equalsIgnoreCase("POST")){
			if(!map.containsKey(DimensionConstants.ATTRIBUTE_NAME)){
				fields.add(DimensionConstants.ATTRIBUTE_NAME);
			}
			if(!map.containsKey(DimensionConstants.PROJECT_LINK_NAME)){
				fields.add(DimensionConstants.PROJECT_LINK_NAME);
			}
			if(!map.containsKey(DimensionConstants.DYNAMIC_ATTRIBUTE_TYPE)){
				fields.add(DimensionConstants.DYNAMIC_ATTRIBUTE_TYPE);
			}
			if(!fields.isEmpty()) {
				ZABRequest.updateError(map, ZABAction.getAppropriateMessage(ZABConstants.ErrorMessages.MANDATORY_FIELD_MISSING.getErrorString(),fields));
			}
		}
	}

}
