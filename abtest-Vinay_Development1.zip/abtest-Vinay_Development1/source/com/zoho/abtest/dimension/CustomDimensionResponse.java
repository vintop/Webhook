//$Id$
package com.zoho.abtest.dimension;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;

public class CustomDimensionResponse 
{
	public static String jsonResponse(HttpServletRequest request,List<CustomDimension> customDimensions) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(customDimensions);			
			JSONObject json = ZABResponse.updateMetaInfo(request, DimensionConstants.DYNAMIC_ATTRIBUTES_API_MODULE, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){}
		return returnBuffer.toString();
	}
	
	public static JSONArray getJSONArray(List<CustomDimension> customDimensions) throws JSONException {
		JSONArray array = new JSONArray();
		int size =customDimensions.size();
		for (int i=0;i<size;i++) {
			CustomDimension customDimension = customDimensions.get(i);
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(DimensionConstants.DYNAMIC_ATTRIBUTE_ID, customDimension.getDynamicAttributeId());
			jsonObj.put(DimensionConstants.ATTRIBUTE_LINK_NAME, customDimension.getAttributeLinkName());
			jsonObj.put(DimensionConstants.PROJECT_ID, customDimension.getProjectId());
			jsonObj.put(DimensionConstants.ATTRIBUTE_TYPE, customDimension.getAttributeType());
			jsonObj.put(DimensionConstants.ATTRIBUTE_NAME, customDimension.getAttributeName());
			jsonObj.put(DimensionConstants.DIMENSION_API_NAME, customDimension.getDimensionApiName());
			jsonObj.put(DimensionConstants.DIMENSION_DESCRIPTION, customDimension.getDimensionDescription());
			jsonObj.put(ZABConstants.RESPONSE_STRING, customDimension.getResponseString());
			jsonObj.put(ZABConstants.STATUS_CODE, customDimension.getResponseCode());
			jsonObj.put(ZABConstants.SUCCESS, customDimension.getSuccess());
			array.put(jsonObj);
		}
		return array;
	}

}
