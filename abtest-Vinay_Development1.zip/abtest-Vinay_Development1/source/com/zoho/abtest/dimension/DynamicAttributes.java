//$Id$
package com.zoho.abtest.dimension;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.persistence.WritableDataObject;
import com.zoho.abtest.AUDIENCE;
import com.zoho.abtest.DYNAMIC_ATTRIBUTES;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.EXPERIMENT_DYNAMIC_ATTR;
import com.zoho.abtest.EXPERIMENT_GOAL;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.dimension.DimensionConstants.DynamicAttributeType;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentStatus;
import com.zoho.abtest.listener.ZABNotifier;
import com.zoho.abtest.project.ProjectTreeEventConstants;
import com.zoho.abtest.project.ProjectTreeEventWrapper;
import com.zoho.abtest.project.ProjectTreeEventConstants.OperationType;
import com.zoho.abtest.report.ReportRawDataConstants;
import com.zoho.abtest.utility.ZABUtil;

public class DynamicAttributes extends ZABModel{

	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = Logger.getLogger(DynamicAttributes.class.getName());
	
	private Long dynamicAttributeId;
	private String attributeLinkName;
	private Long projectId;
	private Integer attributeType;
	private String attributeName;
	private String description;
	private List<Experiment> experimentList;
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public List<Experiment> getExperimentList() {
		return experimentList;
	}
	public void setExperimentList(List<Experiment> experimentList) {
		this.experimentList = experimentList;
	}
	public String getAttributeLinkName() {
		return attributeLinkName;
	}
	public void setAttributeLinkName(String attributeLinkName) {
		this.attributeLinkName = attributeLinkName;
	}
	public Long getDynamicAttributeId() {
		return dynamicAttributeId;
	}
	public void setDynamicAttributeId(Long dynamicAttributeId) {
		this.dynamicAttributeId = dynamicAttributeId;
	}
	public Long getProjectId() {
		return projectId;
	}
	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}
	public Integer getAttributeType() {
		return attributeType;
	}
	public void setAttributeType(Integer attributeType) {
		this.attributeType = attributeType;
	}
	public String getAttributeName() {
		return attributeName;
	}
	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}
	
	public Boolean isInvolvedRunningExperiments() {
		Boolean flag = false;
		Criteria c = new Criteria(new Column(EXPERIMENT_DYNAMIC_ATTR.TABLE, EXPERIMENT_DYNAMIC_ATTR.DYNAMIC_ATTRIBUTE_ID), this.getDynamicAttributeId(), QueryConstants.EQUAL);
		Criteria c2 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_STATUS), ExperimentStatus.RUNNING.getStatusCode(), QueryConstants.EQUAL);
		Join join1=new Join(EXPERIMENT_DYNAMIC_ATTR.TABLE,EXPERIMENT.TABLE,new String[]{EXPERIMENT_DYNAMIC_ATTR.EXPERIMENT_ID},new String[]{EXPERIMENT.EXPERIMENT_ID},Join.INNER_JOIN);
		try {
			DataObject dobj = getRow(EXPERIMENT_DYNAMIC_ATTR.TABLE, c.and(c2), join1);
			flag = dobj.containsTable(EXPERIMENT_DYNAMIC_ATTR.TABLE);
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Exception occured:", e);
		}
		return flag;
	}
	
	public static DynamicAttributes createDynamicAtribute(HashMap<String, String> hs)
	{
		DynamicAttributes dynamicAttribute = null;
		try
		{
			String linkName = generateLinkName(DYNAMIC_ATTRIBUTES.TABLE, DYNAMIC_ATTRIBUTES.ATTRIBUTE_LINK_NAME, null, null, hs.get(DimensionConstants.ATTRIBUTE_NAME));
			hs.put(DimensionConstants.ATTRIBUTE_LINK_NAME, linkName);
			DataObject dataObj = ZABModel.createRow(DimensionConstants.DYNAMIC_ATTRIBUTES_CONSTANTS, DYNAMIC_ATTRIBUTES.TABLE, hs);
			Long dynamicAttributeId = (Long)dataObj.getFirstValue(DYNAMIC_ATTRIBUTES.TABLE, DYNAMIC_ATTRIBUTES.DYNAMIC_ATTRIBUTE_ID);
			dynamicAttribute = getDynamicAttributesById(dynamicAttributeId);
			
			//Once a dynamic attribute is created, make a default value 'UNKNOWN' in dynamic_attribute_values table
			Dimension.createDynamicAttributeCodeValue(dynamicAttributeId, ReportRawDataConstants.UNKNOWN_VALUE);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			dynamicAttribute = new DynamicAttributes();
			dynamicAttribute.setSuccess(Boolean.FALSE);
		}
		return dynamicAttribute;
	}
	
	public static DynamicAttributes getDynamicAttributesById(Long dynamicAttributeId)
	{
		DynamicAttributes dynamicAttribute = null;
		try
		{
			Criteria criteria1 = new Criteria(new Column(DYNAMIC_ATTRIBUTES.TABLE, DYNAMIC_ATTRIBUTES.DYNAMIC_ATTRIBUTE_ID), dynamicAttributeId, QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(DYNAMIC_ATTRIBUTES.TABLE, criteria1);
			Iterator<?> iterator = dataObj.getRows(DYNAMIC_ATTRIBUTES.TABLE);
			if(iterator.hasNext())
			{
				Row row = (Row)iterator.next();
				dynamicAttribute = getDynamicAttributesFromRow(row);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			dynamicAttribute = new DynamicAttributes();
			dynamicAttribute.setSuccess(Boolean.FALSE);
		}
		return dynamicAttribute;
	}
	
	public static DynamicAttributes getDynamicAttributesByLinkName(String linkName)
	{
		DynamicAttributes dynamicAttribute = null;
		try
		{
			Criteria criteria1 = new Criteria(new Column(DYNAMIC_ATTRIBUTES.TABLE, DYNAMIC_ATTRIBUTES.ATTRIBUTE_LINK_NAME), linkName, QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(DYNAMIC_ATTRIBUTES.TABLE, criteria1);
			Iterator<?> iterator = dataObj.getRows(DYNAMIC_ATTRIBUTES.TABLE);
			if(iterator.hasNext())
			{
				Row row = (Row)iterator.next();
				dynamicAttribute = getDynamicAttributesFromRow(row);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			dynamicAttribute = new DynamicAttributes();
			dynamicAttribute.setSuccess(Boolean.FALSE);
		}
		return dynamicAttribute;
	}
	
	public static Long getDynamicAttributesIdByLinkName(String linkName)
	{
		Long id = null;
		try
		{
			Criteria criteria1 = new Criteria(new Column(DYNAMIC_ATTRIBUTES.TABLE, DYNAMIC_ATTRIBUTES.ATTRIBUTE_LINK_NAME), linkName, QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(DYNAMIC_ATTRIBUTES.TABLE, criteria1);
			id = (Long)dataObj.getFirstValue(DYNAMIC_ATTRIBUTES.TABLE, DYNAMIC_ATTRIBUTES.DYNAMIC_ATTRIBUTE_ID);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			id = 0l;
		}
		return id;
	}
	
	public static Long getProjectIdByAttributeLinkName(String linkName)
	{
		Long id = null;
		try
		{
			Criteria criteria1 = new Criteria(new Column(DYNAMIC_ATTRIBUTES.TABLE, DYNAMIC_ATTRIBUTES.ATTRIBUTE_LINK_NAME), linkName, QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(DYNAMIC_ATTRIBUTES.TABLE, criteria1);
			id = (Long)dataObj.getFirstValue(DYNAMIC_ATTRIBUTES.TABLE, DYNAMIC_ATTRIBUTES.PROJECT_ID);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			id = null;
		}
		return id;
	}
	
	public static List<DynamicAttributes> getDynamicAttributesByType(Long projectId,Integer attributeType)
	{
		List<DynamicAttributes> dynamicAttributes = null;
		Row row = null;
		DynamicAttributes dynamicAttribute = null;
		try
		{
			Criteria criteria1 = new Criteria(new Column(DYNAMIC_ATTRIBUTES.TABLE, DYNAMIC_ATTRIBUTES.PROJECT_ID), projectId, QueryConstants.EQUAL);
			Criteria criteria2 = new Criteria(new Column(DYNAMIC_ATTRIBUTES.TABLE, DYNAMIC_ATTRIBUTES.ATTRIBUTE_TYPE), attributeType, QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(DYNAMIC_ATTRIBUTES.TABLE, criteria1.and(criteria2));
			Iterator<?> iterator = dataObj.getRows(DYNAMIC_ATTRIBUTES.TABLE);
			dynamicAttributes = new ArrayList<DynamicAttributes>();
			while(iterator.hasNext())
			{
				row = (Row)iterator.next();
				dynamicAttribute = getDynamicAttributesFromRow(row);
				dynamicAttributes.add(dynamicAttribute);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			dynamicAttributes = new ArrayList<DynamicAttributes>();
		}
		return dynamicAttributes;
	}
	
	public static List<DynamicAttributes> getDynamicAttributesByType(Integer attributeType)
	{
		List<DynamicAttributes> dynamicAttributes = null;
		Row row = null;
		DynamicAttributes dynamicAttribute = null;
		try
		{
			Criteria criteria1 = new Criteria(new Column(DYNAMIC_ATTRIBUTES.TABLE, DYNAMIC_ATTRIBUTES.ATTRIBUTE_TYPE), attributeType, QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(DYNAMIC_ATTRIBUTES.TABLE, criteria1);
			Iterator<?> iterator = dataObj.getRows(DYNAMIC_ATTRIBUTES.TABLE);
			dynamicAttributes = new ArrayList<DynamicAttributes>();
			while(iterator.hasNext())
			{
				row = (Row)iterator.next();
				dynamicAttribute = getDynamicAttributesFromRow(row);
				dynamicAttributes.add(dynamicAttribute);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			dynamicAttributes = new ArrayList<DynamicAttributes>();
		}
		return dynamicAttributes;
	}
	
	public static DynamicAttributes updateDynamicAttribute(HashMap<String, String> hs)
	{
		DynamicAttributes dynamicAttribute = null;
		String attributeLinkName = null;
		try
		{
			attributeLinkName = hs.get(DimensionConstants.ATTRIBUTE_LINK_NAME);
			Criteria criteria1 = new Criteria(new Column(DYNAMIC_ATTRIBUTES.TABLE, DYNAMIC_ATTRIBUTES.ATTRIBUTE_LINK_NAME), attributeLinkName, QueryConstants.EQUAL);
			ZABModel.updateRow(DimensionConstants.DYNAMIC_ATTRIBUTES_CONSTANTS, DYNAMIC_ATTRIBUTES.TABLE, hs, criteria1, DimensionConstants.DYNAMIC_ATTRIBUTES_API_MODULE);
			dynamicAttribute = getDynamicAttributesByLinkName(attributeLinkName);
			
			if(hs.containsKey(DimensionConstants.ATTRIBUTE_NAME))
			{
				List<Experiment> experimentList = ExperimentDynamicAttribute.getExperimentsByDynamicAttributeId(dynamicAttribute.getDynamicAttributeId());
				if(experimentList.size() > 0)
				{
					//To Update in js embed file
					ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
					wrapper.setModel(dynamicAttribute);
					wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
					wrapper.setType(OperationType.UPDATE);
					ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			dynamicAttribute = new DynamicAttributes();
			dynamicAttribute.setAttributeLinkName(attributeLinkName);
			dynamicAttribute.setSuccess(Boolean.FALSE);
		}
		return dynamicAttribute;
	}
	
	public static DynamicAttributes deleteDynamicAttribute(String attributeLinkName)
	{
		DynamicAttributes dynamicAttribute = null;
		try
		{
			dynamicAttribute = getDynamicAttributesByLinkName(attributeLinkName);
			List<Experiment> experimentList = ExperimentDynamicAttribute.getExperimentsByDynamicAttributeId(dynamicAttribute.getDynamicAttributeId());
			dynamicAttribute.setExperimentList(experimentList);
			
			Criteria criteria1 = new Criteria(new Column(DYNAMIC_ATTRIBUTES.TABLE, DYNAMIC_ATTRIBUTES.ATTRIBUTE_LINK_NAME), attributeLinkName, QueryConstants.EQUAL);
			ZABModel.deleteRow(DYNAMIC_ATTRIBUTES.TABLE, criteria1, DimensionConstants.DYNAMIC_ATTRIBUTES_API_MODULE);
			
			//To Update in js embed file
			ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
			wrapper.setModel(dynamicAttribute);
			wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
			wrapper.setType(OperationType.DELETE);
			ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			dynamicAttribute = new DynamicAttributes();
			dynamicAttribute.setAttributeLinkName(attributeLinkName);
			dynamicAttribute.setSuccess(Boolean.FALSE);
		}
		return dynamicAttribute;
	}
	
	public static DynamicAttributes getDynamicAttributesFromRow(Row row)
	{
		DynamicAttributes dynamicAttribute = new DynamicAttributes();
		dynamicAttribute.setDynamicAttributeId((Long)row.get(DYNAMIC_ATTRIBUTES.DYNAMIC_ATTRIBUTE_ID));
		dynamicAttribute.setAttributeLinkName((String)row.get(DYNAMIC_ATTRIBUTES.ATTRIBUTE_LINK_NAME));
		dynamicAttribute.setProjectId((Long)row.get(DYNAMIC_ATTRIBUTES.PROJECT_ID));
		dynamicAttribute.setAttributeType((Integer)row.get(DYNAMIC_ATTRIBUTES.ATTRIBUTE_TYPE));
		dynamicAttribute.setAttributeName((String)row.get(DYNAMIC_ATTRIBUTES.ATTRIBUTE_NAME));
		dynamicAttribute.setDescription((String)row.get(DYNAMIC_ATTRIBUTES.DESCRIPTION));
		dynamicAttribute.setSuccess(Boolean.TRUE);
		return dynamicAttribute;
	}
	
	public static HashMap<String,DynamicAttributes> getDynamicAttributesOfExperiment(String experimentId){
		HashMap<String,DynamicAttributes> dynamicAttriLinkNmaeIdHs= new HashMap<String,DynamicAttributes>();
		try{
			Criteria c= new Criteria(new Column(EXPERIMENT_DYNAMIC_ATTR.TABLE,EXPERIMENT_DYNAMIC_ATTR.EXPERIMENT_ID),experimentId,QueryConstants.EQUAL);
			Join join = new Join(EXPERIMENT_DYNAMIC_ATTR.TABLE, DYNAMIC_ATTRIBUTES.TABLE, new String []{EXPERIMENT_DYNAMIC_ATTR.DYNAMIC_ATTRIBUTE_ID}, new String[]{DYNAMIC_ATTRIBUTES.DYNAMIC_ATTRIBUTE_ID},Join.INNER_JOIN);
			DataObject dobj = ZABModel.getRow(EXPERIMENT_DYNAMIC_ATTR.TABLE, c, new Join[]{join});
			Iterator<?> itr = dobj.getRows(DYNAMIC_ATTRIBUTES.TABLE);
			while(itr.hasNext()){
				Row r = (Row )itr.next();
				DynamicAttributes da= new DynamicAttributes();
				da.setDynamicAttributeId((Long)r.get(DYNAMIC_ATTRIBUTES.DYNAMIC_ATTRIBUTE_ID));
				da.setAttributeLinkName((String)r.get(DYNAMIC_ATTRIBUTES.ATTRIBUTE_LINK_NAME));
				da.setAttributeType((Integer)r.get(DYNAMIC_ATTRIBUTES.ATTRIBUTE_TYPE));
				da.setAttributeName((String)r.get(DYNAMIC_ATTRIBUTES.ATTRIBUTE_LINK_NAME));
				dynamicAttriLinkNmaeIdHs.put((String)r.get(DYNAMIC_ATTRIBUTES.ATTRIBUTE_LINK_NAME), da);
			}
		}catch(Exception e){
			LOGGER.log(Level.SEVERE,"Exception occurred",e);
		}
		return dynamicAttriLinkNmaeIdHs;
		
	}
	
	public static HashMap<String,DynamicAttributes> getCustomDimensionOfExperiment(String experimentId){
		HashMap<String,DynamicAttributes> dynamicAttriLinkNmaeIdHs= new HashMap<String,DynamicAttributes>();
		try{
			Criteria c= new Criteria(new Column(EXPERIMENT_DYNAMIC_ATTR.TABLE,EXPERIMENT_DYNAMIC_ATTR.EXPERIMENT_ID),experimentId,QueryConstants.EQUAL);
			Criteria c2= new Criteria(new Column(DYNAMIC_ATTRIBUTES.TABLE,DYNAMIC_ATTRIBUTES.ATTRIBUTE_TYPE),DynamicAttributeType.CUSTOMDIMENSION.getAttributeTypeCode(),QueryConstants.EQUAL);
			
			Join join = new Join(EXPERIMENT_DYNAMIC_ATTR.TABLE, DYNAMIC_ATTRIBUTES.TABLE, new String []{EXPERIMENT_DYNAMIC_ATTR.DYNAMIC_ATTRIBUTE_ID}, new String[]{DYNAMIC_ATTRIBUTES.DYNAMIC_ATTRIBUTE_ID},Join.INNER_JOIN);
			DataObject dobj = ZABModel.getRow(EXPERIMENT_DYNAMIC_ATTR.TABLE, c.and(c2), new Join[]{join});
			Iterator<?> itr = dobj.getRows(DYNAMIC_ATTRIBUTES.TABLE);
			while(itr.hasNext()){
				Row r = (Row )itr.next();
				DynamicAttributes da= new DynamicAttributes();
				da.setDynamicAttributeId((Long)r.get(DYNAMIC_ATTRIBUTES.DYNAMIC_ATTRIBUTE_ID));
				da.setAttributeLinkName((String)r.get(DYNAMIC_ATTRIBUTES.ATTRIBUTE_LINK_NAME));
				da.setAttributeType((Integer)r.get(DYNAMIC_ATTRIBUTES.ATTRIBUTE_TYPE));
				da.setAttributeName((String)r.get(DYNAMIC_ATTRIBUTES.ATTRIBUTE_LINK_NAME));
				dynamicAttriLinkNmaeIdHs.put((String)r.get(DYNAMIC_ATTRIBUTES.ATTRIBUTE_LINK_NAME), da);
			}
		}catch(Exception e){
			LOGGER.log(Level.SEVERE,"Exception occurred",e);
		}
		return dynamicAttriLinkNmaeIdHs;
		
	}
	
	public static DynamicAttributes addDuplicateDynamicAttribute(Long attrId) throws Exception {
		Criteria c = new Criteria(new Column(DYNAMIC_ATTRIBUTES.TABLE, DYNAMIC_ATTRIBUTES.DYNAMIC_ATTRIBUTE_ID), attrId, QueryConstants.EQUAL);
		DataObject dj = getRow(DYNAMIC_ATTRIBUTES.TABLE, c);
		Row row = dj.getRow(DYNAMIC_ATTRIBUTES.TABLE);
		DataObject dobj = new WritableDataObject();
		DynamicAttributes attr = null;
		if(row!=null) {			
			Row dupRow = new Row(DYNAMIC_ATTRIBUTES.TABLE);
			String displayName = (String)row.get(DYNAMIC_ATTRIBUTES.ATTRIBUTE_NAME);
			String linkname = generateLinkName(DYNAMIC_ATTRIBUTES.TABLE, DYNAMIC_ATTRIBUTES.ATTRIBUTE_LINK_NAME, null, null, displayName);
			dupRow.set(DYNAMIC_ATTRIBUTES.ATTRIBUTE_NAME, displayName);
			dupRow.set(DYNAMIC_ATTRIBUTES.ATTRIBUTE_LINK_NAME, linkname);
			dupRow.set(DYNAMIC_ATTRIBUTES.ATTRIBUTE_TYPE, (Integer)row.get(DYNAMIC_ATTRIBUTES.ATTRIBUTE_TYPE));
			dupRow.set(DYNAMIC_ATTRIBUTES.DESCRIPTION, (String)row.get(DYNAMIC_ATTRIBUTES.DESCRIPTION));
			dupRow.set(DYNAMIC_ATTRIBUTES.PROJECT_ID, (Long)row.get(DYNAMIC_ATTRIBUTES.PROJECT_ID));
			dobj.addRow(dupRow);
			updateDataObject(dobj);
			attr = getDynamicAttributesFromRow(dupRow);
		}
		return attr;
	}
	
}
