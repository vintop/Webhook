//$Id$
package com.zoho.abtest.dimension;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;

import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.dimension.DimensionConstants.DynamicAttributeType;
import com.zoho.abtest.experiment.Experiment;

public class ExperimentDynamicAttributeAction extends ZABAction implements ServletResponseAware, ServletRequestAware  {

	private static final Logger LOGGER = Logger.getLogger(ExperimentDynamicAttributeAction.class.getName());
	
	private static final long serialVersionUID = 1L;

	private HttpServletRequest request;
	private HttpServletResponse response;
	
	private String experimentLinkName;
	private String attributeLinkName;

	public String getAttributeLinkName() {
		return attributeLinkName;
	}

	public void setAttributeLinkName(String attributeLinkName) {
		this.attributeLinkName = attributeLinkName;
	}

	public String getExperimentLinkName() {
		return experimentLinkName;
	}

	public void setExperimentLinkName(String experimentLinkName) {
		this.experimentLinkName = experimentLinkName;
	}

	@Override
	public void setServletRequest(HttpServletRequest request) {
		this.request = request;
	}

	@Override
	public void setServletResponse(HttpServletResponse response) {
		this.response = response;
	}
	
	public void processExperimentDynamicAttributeMapping() throws Exception
	{
		List<ExperimentDynamicAttribute> expDynamicAttrList = new ArrayList<ExperimentDynamicAttribute>();
		try
		{
			Long experimentId = Experiment.getExperimentId(experimentLinkName); 
			switch(ZABAction.getHTTPMethod(request))
			{
			case POST:	
				List<String> dynamicAttributeIdsToBeMapped = ZABAction.parseJSONArray(request);
				expDynamicAttrList.addAll(ExperimentDynamicAttribute.createExperimentDynamicAttribute(experimentId,dynamicAttributeIdsToBeMapped));
				break;
			case DELETE:
				List<String> dynamicAttributeIds = ZABAction.parseJSONArray(request);
				List<Long> dynamicAttributeIdsToBeUnMapped = new ArrayList<Long>();
				for(String dynamicAttributeId:dynamicAttributeIds)
				{
					dynamicAttributeIdsToBeUnMapped.add(Long.parseLong(dynamicAttributeId));
				}
				expDynamicAttrList.addAll(ExperimentDynamicAttribute.deleteExperimentDynamicAttribute(experimentId, dynamicAttributeIdsToBeUnMapped));
				break;
			case GET:
				break;
			case PUT:
				break;
			}
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExperimentDynamicAttributeResponse(request, expDynamicAttrList));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), DimensionConstants.EXP_DYNAMIC_ATTRIBUTES_API_MODULE));
		}
	}
	
	//Seperate method for GET operation since the Response objects will be differrent from GET and POST/DELETE
	public void getDynamicAttributesByExperiment() throws Exception
	{
		List<DynamicAttributes> dynamicAttributes = new ArrayList<DynamicAttributes>();
		try
		{
			Long experimentId = Experiment.getExperimentId(experimentLinkName);
			String dynamicAttributeType = request.getParameter(DimensionConstants.DYNAMIC_ATTRIBUTE_TYPE);
			if(dynamicAttributeType != null)
			{
				Integer attributeType = null;
				switch(dynamicAttributeType)
				{
				case DimensionConstants.URLPARAMETER_VALUE:
					attributeType = DynamicAttributeType.URLPARAMETER.getAttributeTypeCode();
					break;
				case DimensionConstants.COOKIE_VALUE:
					attributeType = DynamicAttributeType.COOKIE.getAttributeTypeCode();
					break;
				case DimensionConstants.JSVARIABLE_VALUE:
					attributeType = DynamicAttributeType.JSVARIABLE.getAttributeTypeCode();
					break;
				case DimensionConstants.CUSTOMDIMENSION_VALUE:
					attributeType = DynamicAttributeType.CUSTOMDIMENSION.getAttributeTypeCode();
					break;
				}
				dynamicAttributes.addAll(ExperimentDynamicAttribute.getDynamicAttributesByExpAndType(experimentId, attributeType));
			}
			else
			{
				dynamicAttributes.addAll(ExperimentDynamicAttribute.getDynamicAttributesByExperiment(experimentId));
			}
			
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getDynamicAttributesResponse(request, dynamicAttributes));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), DimensionConstants.EXP_DYNAMIC_ATTRIBUTES_API_MODULE));
		}
	}
	
	public void getExperimentsByDynamicAttribute() throws Exception
	{
		ArrayList<Experiment> experimentList = new ArrayList<Experiment>();
		try
		{
			Long dynamicAttributeId = null;
			if(attributeLinkName != null)
			{
				dynamicAttributeId = DynamicAttributes.getDynamicAttributesIdByLinkName(attributeLinkName);
				experimentList.addAll(ExperimentDynamicAttribute.getExperimentsByDynamicAttributeId(dynamicAttributeId));
			}
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExperimentResponse(request, experimentList));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), DimensionConstants.EXP_DYNAMIC_ATTRIBUTES_API_MODULE));
		}
	}
	
}
