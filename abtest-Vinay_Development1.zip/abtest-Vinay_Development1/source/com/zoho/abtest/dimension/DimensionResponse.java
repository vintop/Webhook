//$Id$
package com.zoho.abtest.dimension;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;
import com.zoho.abtest.utility.ZABUtil;

public class DimensionResponse {
	private static final Logger LOGGER = Logger.getLogger(DimensionResponse.class.getName());

	public static String jsonResponse(HttpServletRequest request,ArrayList<Dimension> lst) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(lst);			
			JSONObject json = ZABResponse.updateMetaInfo(request, DimensionConstants.API_MODULE, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){
			
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			
		}
		return returnBuffer.toString();
	}
	
	public static JSONArray getJSONArray(ArrayList<Dimension> lst) throws JSONException {
		JSONArray array = new JSONArray();
		int size =lst.size();
		for (int i=0;i<size;i++) {
			Dimension ld=lst.get(i);
			JSONObject jsonObj = new JSONObject();
			

			jsonObj.put(DimensionConstants.BROWSER_CODE, ld.getBrowserCode());
			jsonObj.put(DimensionConstants.BROWSER_DETAIL_ID, ld.getBrowserId());
			jsonObj.put(DimensionConstants.BROWSER_VALUE, ld.getBrowserValue());
			
			jsonObj.put(DimensionConstants.DEVICE_CODE, ld.getDeviceCode());
			jsonObj.put(DimensionConstants.DEVICE_DETAIL_ID, ld.getDeviceId());
			jsonObj.put(DimensionConstants.DEVICE_VALUE, ld.getDeviceValue());
			
			jsonObj.put(DimensionConstants.COUNTRY_CODE, ld.getCountryCode());
			jsonObj.put(DimensionConstants.COUNTRY_DETAIL_ID, ld.getCountryId());
			jsonObj.put(DimensionConstants.COUNTRY_VALUE, ld.getCountryValue());
			jsonObj.put(DimensionConstants.COUNTRY_DISPLAY_NAME, ld.getCountryDisplayName());
			
			jsonObj.put(DimensionConstants.OS_CODE, ld.getOSCode());
			jsonObj.put(DimensionConstants.OS_DETAIL_ID, ld.getOSId());
			jsonObj.put(DimensionConstants.OS_VALUE, ld.getOSValue());
			
			jsonObj.put(DimensionConstants.TEXT_VALUE, ld.getTextValue());
			jsonObj.put(DimensionConstants.VISITOR_VALUE, ld.getVisitorValue());
			
			jsonObj.put(DimensionConstants.DAY_WEEK, ld.getDayWeek());
			jsonObj.put(DimensionConstants.HOUR_DAY, ld.getHourDay());
			
			jsonObj.put(DimensionConstants.URL_PARAM_NAME, ld.getUrlParam());
			jsonObj.put(DimensionConstants.COOKIE_NAME, ld.getCookie());
			jsonObj.put(DimensionConstants.JS_VARIABLE_NAME, ld.getJsVariable());
			jsonObj.put(DimensionConstants.CUSTOM_DIMENSION_NAME, ld.getCustomDimension());
			
			
			jsonObj.put(ZABConstants.RESPONSE_STRING, ld.getResponseString());
			jsonObj.put(ZABConstants.STATUS_CODE, ld.getResponseCode());
			jsonObj.put(ZABConstants.SUCCESS, ld.getSuccess());
			array.put(jsonObj);
		}
		return array;
	}
}
