//$Id$
package com.zoho.abtest.dimension;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.CUSTOM_DIMENSION;
import com.zoho.abtest.DYNAMIC_ATTRIBUTES;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.dimension.DimensionConstants.DynamicAttributeType;

public class CustomDimension extends DynamicAttributes {

	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = Logger.getLogger(CustomDimension.class.getName());
	
	private String dimensionDescription;
	private String dimensionApiName;
	
	public String getDimensionDescription() {
		return dimensionDescription;
	}
	public void setDimensionDescription(String dimensionDescription) {
		this.dimensionDescription = dimensionDescription;
	}
	public String getDimensionApiName() {
		return dimensionApiName;
	}
	public void setDimensionApiName(String dimensionApiName) {
		this.dimensionApiName = dimensionApiName;
	}
	
	public static CustomDimension createCustomDimension(HashMap<String, String> hs)
	{
		CustomDimension customDimension = null;
		Long dynamicAttributeId = null;
		try
		{
			DynamicAttributes dynamicAttribute = createDynamicAtribute(hs);
			dynamicAttributeId = dynamicAttribute.getDynamicAttributeId();
			hs.put(DimensionConstants.DYNAMIC_ATTRIBUTE_ID, dynamicAttributeId.toString());
			ZABModel.createRow(DimensionConstants.CUSTOM_DIMENSION_CONSTANTS, CUSTOM_DIMENSION.TABLE, hs);
			customDimension = getCustomDimensionById(dynamicAttributeId);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			customDimension = new CustomDimension();
			customDimension.setSuccess(Boolean.FALSE);
		}
		return customDimension;
	}
	
	public static CustomDimension getCustomDimensionById(Long dynamicAttributeId)
	{
		CustomDimension customDimension = null;
		try
		{
			Criteria criteria1 = new Criteria(new Column(DYNAMIC_ATTRIBUTES.TABLE, DYNAMIC_ATTRIBUTES.DYNAMIC_ATTRIBUTE_ID), dynamicAttributeId, QueryConstants.EQUAL);
			Join join = new Join(DYNAMIC_ATTRIBUTES.TABLE, CUSTOM_DIMENSION.TABLE, new String[]{DYNAMIC_ATTRIBUTES.DYNAMIC_ATTRIBUTE_ID}, new String[]{CUSTOM_DIMENSION.DYNAMIC_ATTRIBUTE_ID}, Join.INNER_JOIN);
			DataObject dataObj = ZABModel.getRow(DYNAMIC_ATTRIBUTES.TABLE, criteria1, join);
			Row dynamicAttrRow = dataObj.getFirstRow(DYNAMIC_ATTRIBUTES.TABLE);
			Row custDimRow = dataObj.getFirstRow(CUSTOM_DIMENSION.TABLE);
			
			customDimension = getCustomDimensionFromRow(dynamicAttrRow,custDimRow);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			customDimension = new CustomDimension();
			customDimension.setSuccess(Boolean.FALSE);
		}
		return customDimension;
	}
	
	public static CustomDimension getCustomDimensionByLinkName(String attributeLinkName)
	{
		CustomDimension customDimension = null;
		try
		{
			Criteria criteria1 = new Criteria(new Column(DYNAMIC_ATTRIBUTES.TABLE, DYNAMIC_ATTRIBUTES.ATTRIBUTE_LINK_NAME), attributeLinkName, QueryConstants.EQUAL);
			Join join = new Join(DYNAMIC_ATTRIBUTES.TABLE, CUSTOM_DIMENSION.TABLE, new String[]{DYNAMIC_ATTRIBUTES.DYNAMIC_ATTRIBUTE_ID}, new String[]{CUSTOM_DIMENSION.DYNAMIC_ATTRIBUTE_ID}, Join.INNER_JOIN);
			DataObject dataObj = ZABModel.getRow(DYNAMIC_ATTRIBUTES.TABLE, criteria1, join);
			Row dynamicAttrRow = dataObj.getFirstRow(DYNAMIC_ATTRIBUTES.TABLE);
			Row custDimRow = dataObj.getFirstRow(CUSTOM_DIMENSION.TABLE);
			
			customDimension = getCustomDimensionFromRow(dynamicAttrRow,custDimRow);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage());
			customDimension = new CustomDimension();
			customDimension.setSuccess(Boolean.FALSE);
		}
		return customDimension;
	}
	
	public static List<CustomDimension> getCustomDimensions(Long projectId)
	{
		List<CustomDimension> customDimensionList = null;
		CustomDimension customDimension = null;
		try
		{
			Criteria criteria1 = new Criteria(new Column(DYNAMIC_ATTRIBUTES.TABLE, DYNAMIC_ATTRIBUTES.PROJECT_ID), projectId, QueryConstants.EQUAL);
			Criteria criteria2 = new Criteria(new Column(DYNAMIC_ATTRIBUTES.TABLE, DYNAMIC_ATTRIBUTES.ATTRIBUTE_TYPE), DynamicAttributeType.CUSTOMDIMENSION.getAttributeTypeCode(), QueryConstants.EQUAL);
			
			Join join = new Join(DYNAMIC_ATTRIBUTES.TABLE, CUSTOM_DIMENSION.TABLE, new String[]{DYNAMIC_ATTRIBUTES.DYNAMIC_ATTRIBUTE_ID}, new String[]{CUSTOM_DIMENSION.DYNAMIC_ATTRIBUTE_ID}, Join.INNER_JOIN);
			DataObject dataObj = ZABModel.getRow(DYNAMIC_ATTRIBUTES.TABLE, criteria1.and(criteria2), join);
			
			Iterator<?> dynamicAttrItr =  dataObj.getRows(DYNAMIC_ATTRIBUTES.TABLE);
			customDimensionList = new ArrayList<CustomDimension>();
			
			while(dynamicAttrItr.hasNext())
			{
				Row dynamicAttrRow = (Row)dynamicAttrItr.next();
				Long dynamicAttributeId = (Long)dynamicAttrRow.get(DYNAMIC_ATTRIBUTES.DYNAMIC_ATTRIBUTE_ID);
				Criteria criteria3 = new Criteria(new Column(CUSTOM_DIMENSION.TABLE, CUSTOM_DIMENSION.DYNAMIC_ATTRIBUTE_ID), dynamicAttributeId, QueryConstants.EQUAL);
				Row custDimRow = dataObj.getRow(CUSTOM_DIMENSION.TABLE, criteria3);
				
				customDimension =  getCustomDimensionFromRow(dynamicAttrRow,custDimRow);
				
				customDimensionList.add(customDimension);
			}
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			customDimensionList = new ArrayList<CustomDimension>();
		}
		return customDimensionList;
	}
	
	public static CustomDimension updateCustomDimension(HashMap<String, String> hs)
	{
		CustomDimension customDimension = null;
		Long dynamicAttributeId = null;
		try
		{
			dynamicAttributeId = Long.parseLong(hs.get(DimensionConstants.DYNAMIC_ATTRIBUTE_ID));
			if(hs.containsKey(DimensionConstants.ATTRIBUTE_NAME))
			{
				DynamicAttributes.updateDynamicAttribute(hs);
			}
			if(hs.containsKey(DimensionConstants.DIMENSION_API_NAME) || hs.containsKey(DimensionConstants.DIMENSION_DESCRIPTION))
			{
				Criteria criteria1 = new Criteria(new Column(CUSTOM_DIMENSION.TABLE, CUSTOM_DIMENSION.DYNAMIC_ATTRIBUTE_ID), dynamicAttributeId, QueryConstants.EQUAL);
				ZABModel.updateRow(DimensionConstants.CUSTOM_DIMENSION_CONSTANTS, CUSTOM_DIMENSION.TABLE, hs, criteria1, DimensionConstants.DYNAMIC_ATTRIBUTES_API_MODULE);
			}
			customDimension = CustomDimension.getCustomDimensionById(dynamicAttributeId);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			customDimension = new CustomDimension();
			customDimension.setDynamicAttributeId(dynamicAttributeId);
			customDimension.setSuccess(Boolean.FALSE);
		}
		return customDimension;
	}
	
	public static CustomDimension deleteCustomDimension(String linkName)
	{
		CustomDimension customDimension = null;
		try
		{
			Criteria criteria1 = new Criteria(new Column(DYNAMIC_ATTRIBUTES.TABLE, DYNAMIC_ATTRIBUTES.ATTRIBUTE_LINK_NAME), linkName, QueryConstants.EQUAL);
			ZABModel.deleteRow(DYNAMIC_ATTRIBUTES.TABLE, criteria1, DimensionConstants.DYNAMIC_ATTRIBUTES_API_MODULE);
			customDimension = new CustomDimension();
			customDimension.setAttributeLinkName(linkName);
			customDimension.setSuccess(Boolean.TRUE);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			customDimension = new CustomDimension();
			customDimension.setAttributeLinkName(linkName);
			customDimension.setSuccess(Boolean.FALSE);
		}
		return customDimension;
	}
	
	public static CustomDimension getCustomDimensionFromRow(Row dynamicAttrRow, Row custDimRow)
	{
		CustomDimension customDimension = new CustomDimension();
		customDimension.setDynamicAttributeId((Long)dynamicAttrRow.get(DYNAMIC_ATTRIBUTES.DYNAMIC_ATTRIBUTE_ID));
		customDimension.setAttributeLinkName((String)dynamicAttrRow.get(DYNAMIC_ATTRIBUTES.ATTRIBUTE_LINK_NAME));
		customDimension.setProjectId((Long)dynamicAttrRow.get(DYNAMIC_ATTRIBUTES.PROJECT_ID));
		customDimension.setAttributeType((Integer)dynamicAttrRow.get(DYNAMIC_ATTRIBUTES.ATTRIBUTE_TYPE));
		customDimension.setAttributeName((String)dynamicAttrRow.get(DYNAMIC_ATTRIBUTES.ATTRIBUTE_NAME));
		customDimension.setDimensionDescription((String)custDimRow.get(CUSTOM_DIMENSION.DIMENSION_DESCRIPTION));
		customDimension.setDimensionApiName((String)custDimRow.get(CUSTOM_DIMENSION.DIMENSION_API_NAME));
		customDimension.setSuccess(Boolean.TRUE);
		return customDimension;
	}
	
}
