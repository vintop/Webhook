//$Id$
package com.zoho.abtest.dimension;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;

public class ExperimentDynamicAttributeResponse 
{
	public static String jsonResponse(HttpServletRequest request,List<ExperimentDynamicAttribute> experimentDynamicAttributes) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(experimentDynamicAttributes);			
			JSONObject json = ZABResponse.updateMetaInfo(request, DimensionConstants.EXP_DYNAMIC_ATTRIBUTES_API_MODULE, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){}
		return returnBuffer.toString();
	}
	
	public static JSONArray getJSONArray(List<ExperimentDynamicAttribute> experimentDynamicAttributes) throws JSONException {
		JSONArray array = new JSONArray();
		int size =experimentDynamicAttributes.size();
		for (int i=0;i<size;i++) {
			ExperimentDynamicAttribute expDynamicAttribute = experimentDynamicAttributes.get(i);
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(DimensionConstants.EXPERIMENT_DYNAMIC_ATTR_ID, expDynamicAttribute.getExperimentDynamicAttributeId());
			jsonObj.put(DimensionConstants.DYNAMIC_ATTRIBUTE_ID, expDynamicAttribute.getDynamicAttributeId());
			jsonObj.put(DimensionConstants.EXPERIMENT_ID, expDynamicAttribute.getExperimentId());
			jsonObj.put(ZABConstants.RESPONSE_STRING, expDynamicAttribute.getResponseString());
			jsonObj.put(ZABConstants.STATUS_CODE, expDynamicAttribute.getResponseCode());
			jsonObj.put(ZABConstants.SUCCESS, expDynamicAttribute.getSuccess());
			array.put(jsonObj);
		}
		return array;
	}

}
