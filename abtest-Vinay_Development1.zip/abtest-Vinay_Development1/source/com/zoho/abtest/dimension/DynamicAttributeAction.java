//$Id$
package com.zoho.abtest.dimension;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;

import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.dimension.DimensionConstants.DynamicAttributeType;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.utility.ZABUtil;

public class DynamicAttributeAction extends ZABAction implements ServletResponseAware, ServletRequestAware {
	
	private static final Logger LOGGER = Logger.getLogger(DynamicAttributeAction.class.getName());
	
	private static final long serialVersionUID = 1L;

	private HttpServletRequest request;
	
	private HttpServletResponse response;
	
	private String attributeLinkName;
	
	public String getAttributeLinkName() {
		return attributeLinkName;
	}

	public void setAttributeLinkName(String attributeLinkName) {
		this.attributeLinkName = attributeLinkName;
	}

	@Override
	public void setServletRequest(HttpServletRequest request) {
		this.request = request;
	}

	@Override
	public void setServletResponse(HttpServletResponse response) {
		this.response = response;
	}
	
	public void processDynamicAttributes() throws Exception
	{
		List<DynamicAttributes> dynamicAttributes = new ArrayList<DynamicAttributes>();
		HashMap<String,String> hs;
		try
		{
			switch(ZABAction.getHTTPMethod(request))
			{
			case POST:	
				hs = ZABAction.getRequestParser(request).parseDynamicAttributes(request);
				if(hs.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					DynamicAttributes dynamicAttribute = new DynamicAttributes();
					dynamicAttribute.setSuccess(Boolean.FALSE);
					dynamicAttribute.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
					dynamicAttributes.add(dynamicAttribute);
				}else{
					String projectLinkName = hs.get(DimensionConstants.PROJECT_LINK_NAME);
					Long projectId = Project.getProjectId(projectLinkName);
					String dynamicAttributeType = hs.get(DimensionConstants.DYNAMIC_ATTRIBUTE_TYPE);
					Integer attributeType = null;
					switch(dynamicAttributeType)
					{
					case DimensionConstants.URLPARAMETER_VALUE:
						attributeType = DynamicAttributeType.URLPARAMETER.getAttributeTypeCode();
						break;
					case DimensionConstants.COOKIE_VALUE:
						attributeType = DynamicAttributeType.COOKIE.getAttributeTypeCode();
						break;
					case DimensionConstants.JSVARIABLE_VALUE:
						attributeType = DynamicAttributeType.JSVARIABLE.getAttributeTypeCode();
						break;
					case DimensionConstants.CUSTOMDIMENSION_VALUE:
						attributeType = DynamicAttributeType.CUSTOMDIMENSION.getAttributeTypeCode();
						break;
					}
					hs.put(DimensionConstants.ATTRIBUTE_TYPE, attributeType.toString());
					hs.put(DimensionConstants.PROJECT_ID, projectId.toString());
					dynamicAttributes.add(DynamicAttributes.createDynamicAtribute(hs));
				}
				break;
				
			case GET:
				
				if(attributeLinkName != null)
				{
					dynamicAttributes.add(DynamicAttributes.getDynamicAttributesByLinkName(attributeLinkName));
				}
				else
				{
					String projectLinkName = request.getParameter(DimensionConstants.PROJECT_LINK_NAME);
					Long projectId = Project.getProjectId(projectLinkName);
					String dynamicAttributeType = request.getParameter(DimensionConstants.DYNAMIC_ATTRIBUTE_TYPE);
					Integer attributeType = null;
					switch(dynamicAttributeType)
					{
					case DimensionConstants.URLPARAMETER_VALUE:
						attributeType = DynamicAttributeType.URLPARAMETER.getAttributeTypeCode();
						break;
					case DimensionConstants.COOKIE_VALUE:
						attributeType = DynamicAttributeType.COOKIE.getAttributeTypeCode();
						break;
					case DimensionConstants.JSVARIABLE_VALUE:
						attributeType = DynamicAttributeType.JSVARIABLE.getAttributeTypeCode();
						break;
					case DimensionConstants.CUSTOMDIMENSION_VALUE:
						attributeType = DynamicAttributeType.CUSTOMDIMENSION.getAttributeTypeCode();
						break;
					}
					dynamicAttributes.addAll(DynamicAttributes.getDynamicAttributesByType(projectId, attributeType));
				}
				break;
				
			case PUT:
				hs = ZABAction.getRequestParser(request).parseDynamicAttributes(request);
				if(attributeLinkName != null)
				{
					hs.put(DimensionConstants.ATTRIBUTE_LINK_NAME, attributeLinkName);
					dynamicAttributes.add(DynamicAttributes.updateDynamicAttribute(hs));
				}
				break;
				
			case DELETE:
				if(attributeLinkName != null)
				{
					dynamicAttributes.add(DynamicAttributes.deleteDynamicAttribute(attributeLinkName));
				}
				break;
			
			}
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getDynamicAttributesResponse(request, dynamicAttributes));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), DimensionConstants.DYNAMIC_ATTRIBUTES_API_MODULE));
		}
	}
	
	//TODO this method and CustomDimension class is not used
	/*public void processCustomDimensions() throws Exception
	{
		List<CustomDimension> customDimensions = new ArrayList<CustomDimension>();
		HashMap<String,String> hs;
		Long projectId;
		try
		{
			projectId = Project.getProjectId(projectLinkName);
			switch(ZABAction.getHTTPMethod(request))
			{
			case POST:
				hs = ZABAction.getRequestParser(request).parseDynamicAttributes(request);
				if(hs.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS))
				{
					CustomDimension customDimension = new CustomDimension();
					customDimension.setSuccess(Boolean.FALSE);
					customDimension.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
					customDimensions.add(customDimension);
				}
				else
				{
					hs.put(DimensionConstants.ATTRIBUTE_TYPE, DynamicAttributeType.CUSTOMDIMENSION.getAttributeTypeCode().toString());
					hs.put(DimensionConstants.PROJECT_ID, projectId.toString());
					customDimensions.add(CustomDimension.createCustomDimension(hs));
				}
				break;
				
			case GET:
				if(attributeLinkName != null)
				{
					customDimensions.add(CustomDimension.getCustomDimensionByLinkName(attributeLinkName));
				}
				else
				{
					customDimensions.addAll(CustomDimension.getCustomDimensions(projectId));
				}
				break;
				
			case PUT:
				hs = ZABAction.getRequestParser(request).parseDynamicAttributes(request);
				if(attributeLinkName != null)
				{
					Long dynamicAttributeId = DynamicAttributes.getDynamicAttributesIdByLinkName(attributeLinkName);
					hs.put(DimensionConstants.DYNAMIC_ATTRIBUTE_ID, dynamicAttributeId.toString());
					hs.put(DimensionConstants.ATTRIBUTE_LINK_NAME, attributeLinkName);
					customDimensions.add(CustomDimension.updateCustomDimension(hs));
				}
				break;
				
			case DELETE:
				if(attributeLinkName != null)
				{
					customDimensions.add(CustomDimension.deleteCustomDimension(attributeLinkName));
				}
				break;
			}
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getCustomDimensionResponse(request, customDimensions));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage());
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), DimensionConstants.DYNAMIC_ATTRIBUTES_API_MODULE));
		}
	}*/

}
