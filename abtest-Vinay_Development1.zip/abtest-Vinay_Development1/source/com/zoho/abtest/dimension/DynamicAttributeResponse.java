//$Id$
package com.zoho.abtest.dimension;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;
import com.zoho.abtest.report.ReportRawData;
import com.zoho.abtest.report.ReportRawDataConstants;

public class DynamicAttributeResponse 
{
	public static String jsonResponse(HttpServletRequest request,List<DynamicAttributes> dynamicAttributes) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(dynamicAttributes);			
			JSONObject json = ZABResponse.updateMetaInfo(request, DimensionConstants.DYNAMIC_ATTRIBUTES_API_MODULE, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){}
		return returnBuffer.toString();
	}
	
	public static JSONArray getJSONArray(List<DynamicAttributes> dynamicAttributes) throws JSONException {
		JSONArray array = new JSONArray();
		int size =dynamicAttributes.size();
		for (int i=0;i<size;i++) {
			DynamicAttributes dynamicAttribute = dynamicAttributes.get(i);
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(DimensionConstants.DYNAMIC_ATTRIBUTE_ID, dynamicAttribute.getDynamicAttributeId());
			jsonObj.put(DimensionConstants.ATTRIBUTE_LINK_NAME, dynamicAttribute.getAttributeLinkName());
			jsonObj.put(DimensionConstants.PROJECT_ID, dynamicAttribute.getProjectId());
			jsonObj.put(DimensionConstants.ATTRIBUTE_TYPE, dynamicAttribute.getAttributeType());
			jsonObj.put(DimensionConstants.ATTRIBUTE_NAME, dynamicAttribute.getAttributeName());
			jsonObj.put(DimensionConstants.DESCRIPTION, dynamicAttribute.getDescription());
			jsonObj.put(ZABConstants.RESPONSE_STRING, dynamicAttribute.getResponseString());
			jsonObj.put(ZABConstants.STATUS_CODE, dynamicAttribute.getResponseCode());
			jsonObj.put(ZABConstants.SUCCESS, dynamicAttribute.getSuccess());
			array.put(jsonObj);
		}
		return array;
	}

}
