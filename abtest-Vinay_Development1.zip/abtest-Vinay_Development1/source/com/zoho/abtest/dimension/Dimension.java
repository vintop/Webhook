
//$Id$
package com.zoho.abtest.dimension;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.iam.IAMUtil;
import com.adventnet.mfw.bean.BeanUtil;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.DYNAMIC_ATTRIBUTES;
import com.zoho.abtest.BROWSER_DETAIL;
import com.zoho.abtest.DEVICE_DETAIL;
import com.zoho.abtest.GOAL;
import com.zoho.abtest.MOBILE_DEVICE_DETAIL;
import com.zoho.abtest.OS_DETAIL;
import com.zoho.abtest.COUNTRY_DETAIL;
import com.zoho.abtest.LANGUAGE_DETAIL;
import com.zoho.abtest.DYNAMIC_ATTRIBUTE_VALUES;
import com.zoho.abtest.cache.InMemoryCacheUtil;
import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.integration.GoogleAdwords;
import com.zoho.abtest.jedis.JedisUtil;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.projectgoals.ProjectGoal;
import com.zoho.abtest.utility.ApplicationProperty;
import com.zoho.abtest.utility.ZABUserBean;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.conf.Configuration;

public class Dimension extends ZABModel{

	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = Logger.getLogger(Dimension.class.getName());
	

	private Long browserId;
	private Integer browserCode;
	private String browserValue;
	private String browserDisplayName;
	
	private Long countryId;
	private Integer countryCode;
	private String countryValue;
	private String countryDisplayName;
	
	private Long deviceId;
	private Integer deviceCode;
	private String deviceValue;
	private String deviceDisplayName;
	
	private Long osId;
	private Integer osCode;
	private String osValue;
	private String osDisplayName;
	
	private Long languageId;
	private Integer languageCode;
	private String languageValue;
	private String languageDisplayName;
	
	private String textValue;
	private String visitorValue;
	
	private String dimensionValue;
	private Integer dimensionCode;
	private String dimensionDisplayName;
	
	public Integer getDimensionCode() {
		return dimensionCode;
	}

	public void setDimensionCode(Integer dimensionCode) {
		this.dimensionCode = dimensionCode;
	}
	
	public String getDimensionDisplayName() {
		return dimensionDisplayName;
	}

	public void setDimensionDisplayName(String dimensionDisplayName) {
		this.dimensionDisplayName = dimensionDisplayName;
	}


	private String dayWeek;
	private Integer hourDay;
	
	private String urlParam;
	private String cookie;
	private String jsVariable;
	private String customDimension;
	
	public String getDimensionValue() {
		return dimensionValue;
	}

	public void setDimensionValue(String dimensionValue) {
		this.dimensionValue = dimensionValue;
	}

	
	public String getUrlParam() {
		return urlParam;
	}

	public void setUrlParam(String urlParam) {
		this.urlParam = urlParam;
	}

	public String getCookie() {
		return cookie;
	}

	public void setCookie(String cookie) {
		this.cookie = cookie;
	}
	
	public String getJsVariable() {
		return jsVariable;
	}

	public void setJsVariable(String jsVariable) {
		this.jsVariable = jsVariable;
	}
	
	public String getCustomDimension() {
		return customDimension;
	}

	public void setCustomDimension(String customDimension) {
		this.customDimension = customDimension;
	}
	
	public String getTextValue() {
		return textValue;
	}

	public void setTextValue(String textValue) {
		this.textValue = textValue;
	}

	public String getVisitorValue() {
		return visitorValue;
	}

	public void setVisitorValue(String visitorValue) {
		this.visitorValue = visitorValue;
	}
	
	public String getDayWeek() {
		return dayWeek;
	}

	public void setDayWeek(String dayWeek) {
		this.dayWeek = dayWeek;
	}
	
	public Integer getHourDay() {
		return hourDay;
	}

	public void setHourDay(Integer hourDay) {
		this.hourDay = hourDay;
	}
	
	public Long getBrowserId() {
		return browserId;
	}

	public void setBrowserId(Long browserId) {
		this.browserId = browserId;
	}

	public Integer getBrowserCode() {
		return browserCode;
	}

	public void setBrowserCode(Integer browserCode) {
		this.browserCode = browserCode;
	}
	
	public String getBrowserValue() {
		return browserValue;
	}

	public void setBrowserValue(String browserValue) {
		this.browserValue = browserValue;
	}

	public Long getCountryId() {
		return countryId;
	}

	public void setCountryId(Long countryId) {
		this.countryId = countryId;
	}
	
	public Integer getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(Integer countryCode) {
		this.countryCode = countryCode;
	}
	
	public String getCountryValue() {
		return countryValue;
	}

	public void setCountryValue(String  countryValue) {
		this.countryValue = countryValue;
	}
	
	public String getCountryDisplayName() {
		return countryDisplayName;
	}

	public void setCountryDisplayName(String countryDisplayName) {
		this.countryDisplayName = countryDisplayName;
	}

	public Long getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(Long deviceId) {
		this.deviceId = deviceId;
	}

	public Integer getDeviceCode() {
		return deviceCode;
	}

	public void setDeviceCode(Integer deviceCode) {
		this.deviceCode = deviceCode;
	}
	
	public String getDeviceValue() {
		return deviceValue;
	}

	public void setDeviceValue(String deviceValue) {
		this.deviceValue = deviceValue;
	}

	public Long getOSId() {
		return osId;
	}

	public void setOSId(Long osId) {
		this.osId = osId;
	}

	public Integer getOSCode() {
		return osCode;
	}

	public void setOSCode(Integer osCode) {
		this.osCode = osCode;
	}
	
	public String getOSValue() {
		return osValue;
	}

	public void setOSValue(String osValue) {
		this.osValue = osValue;
	}
	
	public Long getLanguageId() {
		return languageId;
	}

	public void setLanguageId(Long languageId) {
		this.languageId = languageId;
	}
	
	public Integer getLanguageCode() {
		return languageCode;
	}

	public void setLanguageCode(Integer languageCode) {
		this.languageCode = languageCode;
	}
	
	public String getLanguageValue() {
		return languageValue;
	}

	public void setLanguageValue(String  languageValue) {
		this.languageValue = languageValue;
	}
	
	public String getLanguageDisplayName() {
		return languageDisplayName;
	}

	public void setLanguageDisplayName(String languageDisplayName) {
		this.languageDisplayName = languageDisplayName;
	}


	public static Integer getDynamicAttributeCodeByValue(Long dynamicAttributeId, String value)
	{
		Integer code = 0;
		try
		{
			Criteria criteria = new Criteria(new Column(DYNAMIC_ATTRIBUTE_VALUES.TABLE, DYNAMIC_ATTRIBUTE_VALUES.DYNAMIC_ATTRIBUTE_ID),dynamicAttributeId,QueryConstants.EQUAL);
			criteria= criteria.and(new Criteria(new Column(DYNAMIC_ATTRIBUTE_VALUES.TABLE, DYNAMIC_ATTRIBUTE_VALUES.VALUE),value,QueryConstants.EQUAL));
			DataObject dataObject = ZABModel.getRow(DYNAMIC_ATTRIBUTE_VALUES.TABLE, criteria);
			if(dataObject.isEmpty())
			{
				code = createDynamicAttributeCodeValue(dynamicAttributeId, value);
			}
			else
			{
				Iterator<?> iterator = dataObject.getRows(DYNAMIC_ATTRIBUTE_VALUES.TABLE);
				if(iterator.hasNext())
				{
					Row row  = (Row)iterator.next();
					code = (Integer)row.get(DYNAMIC_ATTRIBUTE_VALUES.CODE);
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);

		}
		return code;
	}
	public static Integer getDynamicAttributeCodeByValue(String dynamicAttributeLinkNmae, String value)
	{
		Integer code = 0;
		try
		{
			Join join = new Join(DYNAMIC_ATTRIBUTE_VALUES.TABLE,DYNAMIC_ATTRIBUTES.TABLE,new String[]{DYNAMIC_ATTRIBUTE_VALUES.DYNAMIC_ATTRIBUTE_ID},new String[]{DYNAMIC_ATTRIBUTES.DYNAMIC_ATTRIBUTE_ID},Join.INNER_JOIN);
			Criteria criteria = new Criteria(new Column(DYNAMIC_ATTRIBUTES.TABLE,DYNAMIC_ATTRIBUTES.ATTRIBUTE_LINK_NAME),dynamicAttributeLinkNmae,QueryConstants.EQUAL);
			criteria= criteria.and(new Criteria(new Column(DYNAMIC_ATTRIBUTE_VALUES.TABLE, DYNAMIC_ATTRIBUTE_VALUES.VALUE),value,QueryConstants.EQUAL));
			DataObject dataObject = ZABModel.getRow(DYNAMIC_ATTRIBUTE_VALUES.TABLE, criteria,join);
			if(!dataObject.containsTable(DYNAMIC_ATTRIBUTE_VALUES.TABLE))
			{
				if(dataObject.containsTable(DYNAMIC_ATTRIBUTES.TABLE)){
					code = createDynamicAttributeCodeValue((Long)dataObject.getFirstValue(DYNAMIC_ATTRIBUTES.TABLE, DYNAMIC_ATTRIBUTES.DYNAMIC_ATTRIBUTE_ID), value);
				}else{
					// dynamic atttribute link name given is invalid
					LOGGER.log(Level.SEVERE, "Dynamic attribute with link name "+dynamicAttributeLinkNmae+" not present");
				}
				
			}
			else
			{
				Iterator<?> iterator = dataObject.getRows(DYNAMIC_ATTRIBUTE_VALUES.TABLE);
				if(iterator.hasNext())
				{
					Row row  = (Row)iterator.next();
					code = (Integer)row.get(DYNAMIC_ATTRIBUTE_VALUES.CODE);
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		return code;
	}
	
	
	
	
	public static Integer createDynamicAttributeCodeValue(Long dynamicAttributeId, String value)
	{
		Integer code = 0;
		try
		{
			//Code value will be unique across whole attributes - TODO discuss if needed
			/*Criteria  c = new Criteria(new Column(DYNAMIC_ATTRIBUTE_VALUES.TABLE,DYNAMIC_ATTRIBUTE_VALUES.DYNAMIC_ATTRIBUTE_ID),dynamicAttributeId,QueryConstants.EQUAL);
			ZABUserBean userAction = (ZABUserBean)BeanUtil.lookup("ZABUserBean",ZABUtil.getCurrentUserDbSpace());
			code = userAction.getMaxDimensionCodeValue(DYNAMIC_ATTRIBUTE_VALUES.TABLE, DYNAMIC_ATTRIBUTE_VALUES.CODE,c );
			if(code == null)
			{
				code = 0;
			}
			else
			{
				code = code+1;
			}*/
			HashMap<String,String> hs = new HashMap<String,String>();
			hs.put(DimensionConstants.VALUE, value);
			hs.put(DimensionConstants.DYNAMIC_ATTRIBUTE_ID, dynamicAttributeId.toString());
			//hs.put(DimensionConstants.CODE, code.toString());
			DataObject dataObj = ZABModel.createRow(DimensionConstants.DYNAMIC_ATTRIBUTE_VALUES_CONSTANTS, DYNAMIC_ATTRIBUTE_VALUES.TABLE, hs);
			code = (Integer)dataObj.getFirstValue(DYNAMIC_ATTRIBUTE_VALUES.TABLE, DYNAMIC_ATTRIBUTE_VALUES.CODE);
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		return code;
	}
	

	public static Integer getDimensionCodeByValue(String tableName, String codeColumnName, String codeApiName, String valueColumnName,  String valueApiName, HashMap<String, String> hs, List<Constants> tableDetailsConstants)
	{
		Integer code = null;
		try
		{
			Criteria criteria = new Criteria(new Column(tableName, valueColumnName),hs.get(valueApiName),QueryConstants.EQUAL,Boolean.FALSE);
			DataObject dataObject = ZABModel.getRow(tableName, criteria);
			if(dataObject.isEmpty())
			{
				code = createDimensionCodeValue(tableName,codeColumnName,codeApiName,hs,tableDetailsConstants);
			}
			else
			{
				Iterator<?> iterator = dataObject.getRows(tableName);
				if(iterator.hasNext())
				{
					Row row  = (Row)iterator.next();
					code = (Integer)row.get(codeColumnName);
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		return code;
	}
	
	public static Integer getCommonDimensionCodeByValue(String tableName, String codeColumnName, String codeApiName, String valueColumnName,  String valueApiName, HashMap<String, String> hs, List<Constants> tableDetailsConstants)throws Exception
	{
		Integer code = null;
		try
		{
			//Get from cache first, if not available get from DB and update the same into cache
			code = InMemoryCacheUtil.getFromHash(tableName, hs.get(valueApiName));
			
			if(code == null)
			{
				String existingDBSpace = ZABUtil.getDBSpace();
				ZABUtil.setDBSpace("sharedspace");	//No I18N
				
				Criteria criteria = new Criteria(new Column(tableName, valueColumnName),hs.get(valueApiName),QueryConstants.EQUAL,Boolean.FALSE);
				DataObject dataObject = ZABModel.getRow(tableName, criteria);
				if(dataObject.isEmpty())
				{
					code = createDimensionCodeValue(tableName,codeColumnName,codeApiName,hs,tableDetailsConstants);
				}
				else
				{
					Iterator<?> iterator = dataObject.getRows(tableName);
					if(iterator.hasNext())
					{
						Row row  = (Row)iterator.next();
						code = (Integer)row.get(codeColumnName);
					}
				}
				InMemoryCacheUtil.pushIntoHash(tableName, hs.get(valueApiName), code);
				
				ZABUtil.setDBSpace(existingDBSpace);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			throw ex;
		}
		return code;
	}
	
	public static ArrayList<Dimension> getDimensionCodes(Integer audienceAttribute)
	{
		ArrayList<Dimension> dimensions = new ArrayList<Dimension>();
		String[] WEEKDAY = {"SUNDAY","MONDAY","TUESDAY","WEDNESDAY","THURSDAY","FRIDAY","SATURDAY"}; //No I18N
		try
		{
			
			Dimension dimension1 = new Dimension();
			if(audienceAttribute==1 || audienceAttribute==2 || audienceAttribute==10){
//				Dimension dimension = new Dimension();
//				dimension.setDimensionValue("text");  //No I18N
//				dimension.setSuccess(Boolean.TRUE);
//				dimensions.add(dimension);
			}else if(audienceAttribute == 3){
				Dimension dimension = new Dimension();
				dimension.setDimensionValue("new"); //No I18N
				dimension.setDimensionDisplayName("new"); //No I18N
				dimension.setSuccess(Boolean.TRUE);
				dimension1.setDimensionValue("returning"); //No I18N
				dimension1.setDimensionDisplayName("returning"); //No I18N
				dimension1.setSuccess(Boolean.TRUE);
				dimensions.add(dimension);
				dimensions.add(dimension1);
			}else if(audienceAttribute == 12){
				for(int i=0; i<7;i++){
					Dimension dimension = new Dimension();
					dimension.setDimensionValue(WEEKDAY[i]);
					dimension.setDimensionDisplayName(WEEKDAY[i]); //No I18N
					dimension.setSuccess(Boolean.TRUE);
					dimensions.add(dimension);
				}
			}else if(audienceAttribute == 13){
				for(int i=1; i<=24;i++){
					Dimension dimension = new Dimension();
					dimension.setDimensionValue(Integer.toString(i));
					dimension.setDimensionDisplayName(Integer.toString(i)); //No I18N
					dimension.setSuccess(Boolean.TRUE);
					dimensions.add(dimension);
				}
			}
			else if(audienceAttribute == 19){
				Dimension dimension = new Dimension();
				dimension.setDimensionValue("direct visitors"); //No I18N
				dimension.setDimensionDisplayName("Direct Visitors"); //No I18N
				dimension.setSuccess(Boolean.TRUE);
				dimensions.add(dimension);
				
				dimension1.setDimensionValue("referral traffic"); //No I18N
				dimension1.setDimensionDisplayName("Referral Traffic"); //No I18N
				dimension1.setSuccess(Boolean.TRUE);
				dimensions.add(dimension1);
				
				Dimension dimension2 = new Dimension();
				dimension2.setDimensionValue("social traffic"); //No I18N
				dimension2.setDimensionDisplayName("Social Traffic"); //No I18N
				dimension2.setSuccess(Boolean.TRUE);
				dimensions.add(dimension2);
				
				Dimension dimension3 = new Dimension();
				dimension3.setDimensionValue("organic search"); //No I18N
				dimension3.setDimensionDisplayName("Organic Search"); //No I18N
				dimension3.setSuccess(Boolean.TRUE);
				dimensions.add(dimension3);
				
				Dimension dimension4 = new Dimension();
				dimension4.setDimensionValue("paid search"); //No I18N
				dimension4.setDimensionDisplayName("Paid Campaigns"); //No I18N
				dimension4.setSuccess(Boolean.TRUE);
				dimensions.add(dimension4);
				
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		return dimensions;
	}
	
	public static ArrayList<Dimension> getDimensionCodes(Integer audienceAttribute,Long project_id)
	{
		ArrayList<Dimension> dimensions = new ArrayList<Dimension>();
		try{
			
			Integer attributeType = 0;
			if(audienceAttribute == 4){
				attributeType = 2;
			}else if(audienceAttribute == 5){
				attributeType = 1;
			}else if(audienceAttribute == 14){
				attributeType = 3;
			}else if(audienceAttribute == 15){
				attributeType = 4;
			}
			
			List<DynamicAttributes> dynamicAttributes = null;
			dynamicAttributes = DynamicAttributes.getDynamicAttributesByType(project_id, attributeType);
			int size =dynamicAttributes.size();
			for (int i=0;i<size;i++) {
				Dimension dimension = new Dimension();
				DynamicAttributes dynamicAttribute = dynamicAttributes.get(i);
				if(audienceAttribute == 4){
					dimension.setDimensionValue(dynamicAttribute.getAttributeName());
					dimension.setDimensionDisplayName(dynamicAttribute.getAttributeName()); //No I18N
				}else if(audienceAttribute == 5){
					dimension.setDimensionValue(dynamicAttribute.getAttributeName());
					dimension.setDimensionDisplayName(dynamicAttribute.getAttributeName()); //No I18N
				}else if(audienceAttribute == 14){
					dimension.setDimensionValue(dynamicAttribute.getAttributeName());
					dimension.setDimensionDisplayName(dynamicAttribute.getAttributeName()); //No I18N
				}else if(audienceAttribute == 15){
					dimension.setDimensionValue(dynamicAttribute.getAttributeName());
					dimension.setDimensionDisplayName(dynamicAttribute.getAttributeName()); //No I18N
				}
				dimensions.add(dimension);
			}
			
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		return dimensions;
	}
	
	public static ArrayList<Dimension> getCommonDimensionCodes(String tableName)
	{
		ArrayList<Dimension> dimensions = new ArrayList<Dimension>();
		DataObject dataObject = null;
		try
		{
			String existingDBSpace = ZABUtil.getDBSpace();
			ZABUtil.setDBSpace("sharedspace");	//No I18N
			dataObject = ZABModel.getRow(tableName, null);
			dimensions = Dimension.getCommonDimensionFromDobj(dataObject);
			ZABUtil.setDBSpace(existingDBSpace);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		return dimensions;
	}
	
	public static ArrayList<Dimension> getProjectGoalsAsDimension(String projectLinkname)
	{
		final ArrayList<Dimension> dimensions = new ArrayList<Dimension>();
		try
		{
			ProjectGoal.getJustTheProjectGoalRows(projectLinkname, row -> {
				Dimension dim = new Dimension();
				dim.setDimensionCode(dimensions.size());
				dim.setDimensionDisplayName((String)row.get(GOAL.GOAL_NAME));
				dim.setDimensionValue(((Long)row.get(GOAL.GOAL_ID)).toString());
				dimensions.add(dim);
			});
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		return dimensions;
	}
	
	public static ArrayList<Dimension> getCommonDimensionFromDobj(DataObject dobj) throws DataAccessException {
		ArrayList<Dimension> dimensions = new ArrayList<Dimension>();
		if(dobj.containsTable(BROWSER_DETAIL.TABLE)) {
			Iterator it = dobj.getRows(BROWSER_DETAIL.TABLE);
			if(it.hasNext()) {
				for(int i=0; i < 7; i++){
					Row row = (Row)it.next();
					dimensions.add(getBrowserFromRow(row));
				}
			}
		}else if(dobj.containsTable(MOBILE_DEVICE_DETAIL.TABLE)){
			Iterator it = dobj.getRows(MOBILE_DEVICE_DETAIL.TABLE);
			while(it.hasNext()) {
				Row row = (Row)it.next();
				dimensions.add(getMobileDeviceFromRow(row));
			}
		}
		else if(dobj.containsTable(DEVICE_DETAIL.TABLE)){
			Iterator it = dobj.getRows(DEVICE_DETAIL.TABLE);
			while(it.hasNext()) {
				Row row = (Row)it.next();
				dimensions.add(getDeviceFromRow(row));
			}
		}else if(dobj.containsTable(OS_DETAIL.TABLE)){
			Iterator it = dobj.getRows(OS_DETAIL.TABLE);
			while(it.hasNext()) {
				Row row = (Row)it.next();
				dimensions.add(getOSFromRow(row));
			}
		}else if(dobj.containsTable(COUNTRY_DETAIL.TABLE)){
			Iterator it = dobj.getRows(COUNTRY_DETAIL.TABLE);
			while(it.hasNext()) {
				Row row = (Row)it.next();
				dimensions.add(getCountryFromRow(row));
			}
		}else if(dobj.containsTable(LANGUAGE_DETAIL.TABLE)){
			Iterator it = dobj.getRows(LANGUAGE_DETAIL.TABLE);
			while(it.hasNext()) {
				Row row = (Row)it.next();
				dimensions.add(getLanguageFromRow(row));
			}
		}
		return dimensions;
	}
	
	public static Dimension getBrowserFromRow(Row row) {
		Dimension dimension = new Dimension();
		//dimension.setBrowserId((Long)row.get(BROWSER_DETAIL.BROWSER_DETAIL_ID));
		//dimension.setBrowserCode((Integer)row.get(BROWSER_DETAIL.BROWSER_CODE));
		dimension.setDimensionValue((String)row.get(BROWSER_DETAIL.BROWSER_VALUE));
		dimension.setDimensionDisplayName((String)row.get(BROWSER_DETAIL.BROWSER_VALUE)); //No I18N
		dimension.setDimensionCode((Integer)row.get(BROWSER_DETAIL.BROWSER_CODE));
		dimension.setSuccess(Boolean.TRUE);
		return dimension;
	}
	
	public static Dimension getDeviceFromRow(Row row) {
		Dimension dimension = new Dimension();
		//dimension.setDeviceId((Long)row.get(DEVICE_DETAIL.DEVICE_DETAIL_ID));
		//dimension.setDeviceCode((Integer)row.get(DEVICE_DETAIL.DEVICE_CODE));
		dimension.setDimensionValue(StringUtils.capitalize(((String)row.get(DEVICE_DETAIL.DEVICE_VALUE)).toLowerCase()));
		dimension.setDimensionDisplayName(StringUtils.capitalize(((String)row.get(DEVICE_DETAIL.DEVICE_VALUE)).toLowerCase())); 
		dimension.setDimensionCode((Integer)row.get(DEVICE_DETAIL.DEVICE_CODE));

		dimension.setSuccess(Boolean.TRUE);
		return dimension;
	}
	
	public static Dimension getMobileDeviceFromRow(Row row) {
		Dimension dimension = new Dimension();
		//dimension.setDeviceId((Long)row.get(DEVICE_DETAIL.DEVICE_DETAIL_ID));
		//dimension.setDeviceCode((Integer)row.get(DEVICE_DETAIL.DEVICE_CODE));
		dimension.setDimensionValue((String)row.get(MOBILE_DEVICE_DETAIL.MOBILE_DEVICE_VALUE));
		dimension.setDimensionDisplayName((String)row.get(MOBILE_DEVICE_DETAIL.MOBILE_DEVICE_VALUE));
		dimension.setDimensionCode((Integer)row.get(MOBILE_DEVICE_DETAIL.MOBILE_DEVICE_CODE));

		dimension.setSuccess(Boolean.TRUE);
		return dimension;
	}
	
	public static Dimension getOSFromRow(Row row) {
		Dimension dimension = new Dimension();
		//dimension.setOSId((Long)row.get(OS_DETAIL.OS_DETAIL_ID));
		//dimension.setOSCode((Integer)row.get(OS_DETAIL.OS_CODE));
		dimension.setDimensionValue((String)row.get(OS_DETAIL.OS_VALUE));
		dimension.setDimensionDisplayName((String)row.get(OS_DETAIL.OS_VALUE));
		dimension.setDimensionCode((Integer)row.get(OS_DETAIL.OS_CODE));

		dimension.setSuccess(Boolean.TRUE);
		return dimension;
	}
	
	public static Dimension getCountryFromRow(Row row) {
		Dimension dimension = new Dimension();
		//dimension.setCountryId((Long)row.get(COUNTRY_DETAIL.COUNTRY_DETAIL_ID));
		dimension.setDimensionValue((String)row.get(COUNTRY_DETAIL.COUNTRY_VALUE));
		dimension.setDimensionDisplayName((String)row.get(COUNTRY_DETAIL.COUNTRY_VALUE));
		dimension.setDimensionCode((Integer)row.get(COUNTRY_DETAIL.COUNTRY_CODE));
		dimension.setDimensionDisplayName((String)row.get(COUNTRY_DETAIL.COUNTRY_DISPLAY_NAME));

		//dimension.setCountryDisplayName((String)row.get(COUNTRY_DETAIL.COUNTRY_DISPLAY_NAME));
		dimension.setSuccess(Boolean.TRUE);
		return dimension;
	}
	
	public static Dimension getLanguageFromRow(Row row) {
		Dimension dimension = new Dimension();
		//dimension.setLanguageId((Long)row.get(LANGUAGE_DETAIL.LANGUAGE_DETAIL_ID));
		//dimension.setLanguageCode((Integer)row.get(LANGUAGE_DETAIL.LANGUAGE_CODE));
		dimension.setDimensionValue((String)row.get(LANGUAGE_DETAIL.LANGUAGE_VALUE));
		dimension.setDimensionDisplayName((String)row.get(LANGUAGE_DETAIL.LANGUAGE_VALUE));
		dimension.setDimensionCode((Integer)row.get(LANGUAGE_DETAIL.LANGUAGE_CODE));
		dimension.setDimensionDisplayName((String)row.get(LANGUAGE_DETAIL.LANGUAGE_DISPLAY_NAME));

		//dimension.setLanguageDisplayName((String)row.get(LANGUAGE_DETAIL.LANGUAGE_DISPLAY_NAME));
		dimension.setSuccess(Boolean.TRUE);
		return dimension;
	}
	
	public static Integer createDimensionCodeValue(String tableName, String codeColumnName, String codeApiName, HashMap<String, String> hs, List<Constants> tableDetailsConstants)
	{
		Integer code = 0;
		try
		{
			
			//TODO This is a TEMPORARY Solution. we should not do like this, this will cause synchronization issues
			//Getting maxim value and adding it and inserting entry should be done in a single query
			//If we try the above solution with relational query, there is problem in maintaining with sasid PK
			
			/*get the code maximum value*/
			
			/*ZABUserBean userAction = (ZABUserBean)BeanUtil.lookup("ZABUserBean",ZABUtil.getCurrentUserDbSpace());
			code = userAction.getMaxDimensionCodeValue(tableName, codeColumnName,null);
			if(code == null)
			{
				code = 0;
			}
			else
			{
				code = code+1;
			}
			hs.put(codeApiName, code.toString());*/
			DataObject dataObj = ZABModel.createRow(tableDetailsConstants, tableName, hs);
			code = (Integer)dataObj.getFirstValue(tableName, codeColumnName);
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		return code;
	}
	
	public static ArrayList<Dimension> getAdwordsCampaign(String projectLinkname) {
		
		ArrayList<Dimension> dimensions = new ArrayList<Dimension>();
		String projectId = Project.getProjectId(projectLinkname).toString();
		ArrayList<GoogleAdwords> gadwords = GoogleAdwords.getGoogleAdwords(projectId);
		Long clientId = gadwords.get(0).getClientId();
		String emailId = gadwords.get(0).getEmailId();
		String adwordsCampaignURL = "";
		try{
			emailId = URLEncoder.encode(emailId,"UTF-8"); //No I18N
			String GadgetsURL = ApplicationProperty.getString("com.abtest.gadwords.serverurl");
			adwordsCampaignURL = GadgetsURL+"/api/google/v1/adwords/getcampaigninfo?ticket="+IAMUtil.getCurrentTicket()+"&zservice=ZohoPageSense&response_type=gadgets&clientId="+clientId+"&mailId="+emailId; //No I18N
			String responseJsonStr = ZABUtil.getResponseStrFromURL(adwordsCampaignURL);
			JSONObject responseJson = new JSONObject(responseJsonStr);
			JSONObject clientObj = new JSONObject(responseJson.getString("response"));
			JSONArray jar1 = new JSONArray(clientObj.getString("Success"));
			for(int i=0;i<jar1.length();i++){
				JSONObject success = new JSONObject(jar1.getString(i));
				String campaignId = success.getString("cid");
				String camppaignName = success.getString("cname");
				Dimension dimension = new Dimension();
				dimension.setDimensionValue(campaignId);
				dimension.setDimensionDisplayName(camppaignName);
				dimension.setSuccess(Boolean.TRUE);
				dimensions.add(dimension);
			}
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		
		return dimensions;
	}
	
	public static ArrayList<Dimension> getAdwordsAdGroup(String projectLinkname) {
		ArrayList<Dimension> dimensions = new ArrayList<Dimension>();
		String projectId = Project.getProjectId(projectLinkname).toString();
		ArrayList<GoogleAdwords> gadwords = GoogleAdwords.getGoogleAdwords(projectId);
		Long clientId = gadwords.get(0).getClientId();
		String emailId = gadwords.get(0).getEmailId();
		String adwordsAdGroupURL = "";
		try{
			emailId = URLEncoder.encode(emailId,"UTF-8"); //No I18N
			String GadgetsURL = ApplicationProperty.getString("com.abtest.gadwords.serverurl");
			adwordsAdGroupURL = GadgetsURL+"/api/google/v1/adwords/getadgroupinfo?ticket="+IAMUtil.getCurrentTicket()+"&zservice=ZohoPageSense&response_type=gadgets&clientId="+clientId+"&mailId="+emailId; //No I18N
			String responseJsonStr = ZABUtil.getResponseStrFromURL(adwordsAdGroupURL);
			JSONObject responseJson = new JSONObject(responseJsonStr);
			JSONObject clientObj = new JSONObject(responseJson.getString("response"));
			JSONArray jar1 = new JSONArray(clientObj.getString("Success"));
			for(int i=0;i<jar1.length();i++){
				
				JSONObject success = new JSONObject(jar1.getString(i));
				JSONArray jar2 = new JSONArray(success.getString("adgDetails"));
				JSONObject adg = new JSONObject(jar2.getString(0));
				String adGroupId = adg.getString("adgid");
				String adGroupName = adg.getString("adgname");
				Dimension dimension = new Dimension();
				dimension.setDimensionValue(adGroupId);
				dimension.setDimensionDisplayName(adGroupName);
				dimension.setSuccess(Boolean.TRUE);
				dimensions.add(dimension);
			}
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		
		return dimensions;
	}
	
}
