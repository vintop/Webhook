//$Id$
package com.zoho.abtest.dimension;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.zoho.abtest.BROWSER_DETAIL;
import com.zoho.abtest.COUNTRY_DETAIL;
import com.zoho.abtest.CURRENTURL_DETAIL;
import com.zoho.abtest.DEVICE_DETAIL;
import com.zoho.abtest.MOBILE_DEVICE_DETAIL;
import com.zoho.abtest.LANGUAGE_DETAIL;
import com.zoho.abtest.OS_DETAIL;
import com.zoho.abtest.REFFERERURL_DETAIL;
import com.zoho.abtest.TRAFFICSOURCE_DETAIL;
import com.zoho.abtest.STANDARD_DIMENSION;
import com.zoho.abtest.DYNAMIC_ATTRIBUTES;
import com.zoho.abtest.DYNAMIC_ATTRIBUTE_VALUES;
import com.zoho.abtest.CUSTOM_DIMENSION;
import com.zoho.abtest.EXPERIMENT_DYNAMIC_ATTR;
import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.ZABConstants;

public class DimensionConstants {
	

	public static final String API_MODULE = "dimension"; //No I18N
	public static final String DYNAMIC_ATTRIBUTES_API_MODULE = "dynamicattributes";			// No I18N
	public static final String EXP_DYNAMIC_ATTRIBUTES_API_MODULE = "experimentdynamicattributes";			// No I18N
	
	public static final String BROWSER_DETAIL_ID = "browser_detail_id";			// No I18N
	public static final String BROWSER_CODE = "browser_code";			// No I18N
	public static final String BROWSER_VALUE = "browser_value";			// No I18N
	public static final String BROWSER_DISPLAY_NAME = "browser_display_name";			// No I18N

	public static final String DEVICE_DETAIL_ID = "device_detail_id";			// No I18N
	public static final String DEVICE_CODE = "device_code";			// No I18N
	public static final String DEVICE_VALUE = "device_value";			// No I18N
	public static final String DEVICE_DISPLAY_NAME = "device_display_name";			// No I18N
	
	public static final String MOBILE_DEVICE_DETAIL_ID = "mobile_device_detail_id";			// No I18N
	public static final String MOBILE_DEVICE_CODE = "mobile_device_code";			// No I18N
	public static final String MOBILE_DEVICE_VALUE = "mobile_device_value";			// No I18N
	public static final String MOBILE_DEVICE_DISPLAY_NAME = "mobile_device_display_name";			// No I18N
	
	public static final String COUNTRY_DETAIL_ID = "country_detail_id";			// No I18N
	public static final String COUNTRY_CODE = "country_code";			// No I18N
	public static final String COUNTRY_VALUE = "country_value";			// No I18N
	public static final String COUNTRY_DISPLAY_NAME = "country_display_name";			// No I18N
	
	public static final String LANGUAGE_DETAIL_ID = "language_detail_id";			// No I18N
	public static final String LANGUAGE_CODE = "language_code";			// No I18N
	public static final String LANGUAGE_VALUE = "language_value";			// No I18N
	public static final String LANGUAGE_DISPLAY_NAME = "language_display_name";			// No I18N
	
	/*
	public static final String USERTYPE_DETAIL_ID = "usertype_detail_id";			// No I18N
	public static final String USERTYPE_CODE = "usertype_code";			// No I18N
	public static final String USERTYPE_VALUE = "usertype_value";			// No I18N
	*/
	public static final String IS_NEW_VISITOR = "is_new_visitor";			// No I18N
	public static final String IS_GOAL_ACHIEVED_FIRST_TIME = "is_goal_achieved_first_time";			// No I18N
	
	public static final String OS_DETAIL_ID = "os_detail_id";			// No I18N
	public static final String OS_CODE = "os_code";			// No I18N
	public static final String OS_VALUE = "os_value";			// No I18N
	public static final String OS_DISPLAY_NAME = "os_DISPLAY_NAME";			// No I18N
	
	public static final String TRAFFICSOURCE_DETAIL_ID = "trafficsource_detail_id";			// No I18N
	public static final String TRAFFICSOURCE_CODE = "trafficsource_code";			// No I18N
	public static final String TRAFFICSOURCE_VALUE = "trafficsource_value";			// No I18N
	
	public static final String REFFERERURL_DETAIL_ID = "reffererurl_detail_id";			// No I18N
	public static final String REFFERERURL_CODE = "reffererurl_code";			// No I18N
	public static final String REFFERERURL_VALUE = "reffererurl_value";			// No I18N
	
	public static final String CURRENTURL_DETAIL_ID = "currenturl_detail_id";			// No I18N
	public static final String CURRENTURL_CODE = "currenturl_code";			// No I18N
	public static final String CURRENTURL_VALUE = "currenturl_value";			// No I18N
	
	public static final String NEW_VISITORTYPE_VALUE = "NEW"; // No I18N
	public static final String RETURNING_VISTORTYPE_VALUE = "RETURNING"; // No I18N
	
	public static final String DIMENSION_ID = "dimension_id"; // No I18N
	public static final String DIMENSION_NAME = "dimension_name"; // No I18N
	public static final String DIMENSION_VALUE = "dimension_value"; // No I18N
	public static final String DIMENSION_CODE = "dimension_code"; // No I18N
	public static final String DIMENSION_DISPLAY_NAME = "dimension_display_name";


	public static final String DIMENSION_DESCRIPTION = "dimension_description"; // No I18N
	
	public static final String DYNAMIC_ATTRIBUTE_ID = "dynamic_attribute_id"; // No I18N
	public static final String PROJECT_ID = "project_id"; // No I18N
	public static final String PROJECT_LINK_NAME = "project_link_name"; // No I18N
	public static final String DYNAMIC_ATTRIBUTE_TYPE = "dynamic_attribute_type"; // No I18N
	public static final String ATTRIBUTE_TYPE = "attribute_type"; // No I18N
	public static final String ATTRIBUTE_NAME = "attribute_name"; // No I18N
	public static final String ATTRIBUTE_LINK_NAME = "attribute_link_name"; // No I18N
	public static final String DESCRIPTION = "description"; // No I18N
	public static final String DIMENSION_API_NAME = "dimension_api_name"; // No I18N
	
	public static final String DYNAMIC_ATTRIBUTE_VALUE_ID = "dynamic_attribute_value_id"; // No I18N
	public static final String VALUE = "value"; // No I18N
	public static final String CODE = "code"; // No I18N
	
	public static final String URLPARAMETER_VALUE = "urlparameter"; // No I18N
	public static final String COOKIE_VALUE = "cookie"; // No I18N
	public static final String JSVARIABLE_VALUE = "jsvariable"; // No I18N
	public static final String CUSTOMDIMENSION_VALUE = "customdimension"; // No I18N
	
	public static final String EXPERIMENT_DYNAMIC_ATTR_ID = "experiment_dynamic_attr_id"; // No I18N
	public static final String EXPERIMENT_ID = "experiment_id"; // No I18N
	public static final String TEXT_VALUE = "dimension_value"; // No I18N
	public static final String VISITOR_VALUE = "visitor_value"; // No I18N
	
	public static final String DAY_WEEK = "day_week"; // No I18N
	public static final String HOUR_DAY = "hour_day"; // No I18N
	
	public static final String URL_PARAM_NAME = "url_param_name"; // No I18N
	public static final String COOKIE_NAME = "cookie_name"; // No I18N
	public static final String JS_VARIABLE_NAME = "js_variable_name"; // No I18N
	public static final String CUSTOM_DIMENSION_NAME = "custome_dimension_name"; // No I18N
	
	
	public enum VisitorType
	{
		NEW_VISITOR(NEW_VISITORTYPE_VALUE,1),
		RETURNING_VISITOR(RETURNING_VISTORTYPE_VALUE,2);
		
		private String visitorTypeValue;
		private Integer visitorTypeCode;
		
		public Integer getVisitorTypeCode() {
			return visitorTypeCode;
		}
		public void setVisitorTypeCode(Integer visitorTypeCode) {
			this.visitorTypeCode = visitorTypeCode;
		}
		public String getVisitorTypeValue() {
			return visitorTypeValue;
		}
		public void setVisitorTypeValue(String visitorTypeValue) {
			this.visitorTypeValue = visitorTypeValue;
		}
		
		private VisitorType(String visitorTypeValue,Integer visitorTypeCode)
		{
			this.visitorTypeValue = visitorTypeValue;
			this.visitorTypeCode = visitorTypeCode;
		}
		
	}
	
	public enum DynamicAttributeType
	{
		URLPARAMETER(URLPARAMETER_VALUE,1),
		COOKIE(COOKIE_VALUE,2), 
		JSVARIABLE(JSVARIABLE_VALUE,3),  
		CUSTOMDIMENSION(CUSTOMDIMENSION_VALUE,4);  
		
		private String attributeTypeValue;
		private Integer attributeTypeCode;
		
		public String getAttributeTypeValue() {
			return attributeTypeValue;
		}
		public void setAttributeTypeValue(String attributeTypeValue) {
			this.attributeTypeValue = attributeTypeValue;
		}
		public Integer getAttributeTypeCode() {
			return attributeTypeCode;
		}
		public void setAttributeTypeCode(Integer attributeTypeCode) {
			this.attributeTypeCode = attributeTypeCode;
		}
		
		private DynamicAttributeType(String attributeTypeValue, Integer attributeTypeCode)
		{
			this.attributeTypeValue = attributeTypeValue;
			this.attributeTypeCode = attributeTypeCode; 
		}
		
	}
	
	public static final List<Constants> EXPERIMENT_DYNAMIC_ATTR_CONSTANTS;
	
	static{
		List<Constants> experimentDynamicAttrConstants = new ArrayList<Constants>();
		experimentDynamicAttrConstants.add(new Constants(EXPERIMENT_DYNAMIC_ATTR_ID,EXPERIMENT_DYNAMIC_ATTR.EXPERIMENT_DYNAMIC_ATTR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		experimentDynamicAttrConstants.add(new Constants(EXPERIMENT_ID,EXPERIMENT_DYNAMIC_ATTR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		experimentDynamicAttrConstants.add(new Constants(DYNAMIC_ATTRIBUTE_ID,EXPERIMENT_DYNAMIC_ATTR.DYNAMIC_ATTRIBUTE_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		EXPERIMENT_DYNAMIC_ATTR_CONSTANTS = Collections.unmodifiableList(experimentDynamicAttrConstants);
	}
	
	public static final List<Constants> CUSTOM_DIMENSION_CONSTANTS;
	
	static{
		List<Constants> customDimensionConstants = new ArrayList<Constants>();
		customDimensionConstants.add(new Constants(DYNAMIC_ATTRIBUTE_ID,CUSTOM_DIMENSION.DYNAMIC_ATTRIBUTE_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		customDimensionConstants.add(new Constants(DIMENSION_DESCRIPTION,CUSTOM_DIMENSION.DIMENSION_DESCRIPTION,ZABConstants.STRING,Boolean.TRUE,Boolean.TRUE));
		customDimensionConstants.add(new Constants(DIMENSION_API_NAME,CUSTOM_DIMENSION.DIMENSION_API_NAME,ZABConstants.STRING,Boolean.TRUE,Boolean.TRUE));
		CUSTOM_DIMENSION_CONSTANTS = Collections.unmodifiableList(customDimensionConstants);
	}
	
	public static final List<Constants> DYNAMIC_ATTRIBUTE_VALUES_CONSTANTS;
	
	static{
		List<Constants> dynamicAttributeValueConstants = new ArrayList<Constants>();
		dynamicAttributeValueConstants.add(new Constants(DYNAMIC_ATTRIBUTE_VALUE_ID,DYNAMIC_ATTRIBUTE_VALUES.DYNAMIC_ATTRIBUTE_VALUE_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		dynamicAttributeValueConstants.add(new Constants(DYNAMIC_ATTRIBUTE_ID,DYNAMIC_ATTRIBUTE_VALUES.DYNAMIC_ATTRIBUTE_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		dynamicAttributeValueConstants.add(new Constants(VALUE,DYNAMIC_ATTRIBUTE_VALUES.VALUE,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
		dynamicAttributeValueConstants.add(new Constants(CODE,DYNAMIC_ATTRIBUTE_VALUES.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		DYNAMIC_ATTRIBUTE_VALUES_CONSTANTS = Collections.unmodifiableList(dynamicAttributeValueConstants);
	}
	
	public static final List<Constants> DYNAMIC_ATTRIBUTES_CONSTANTS;
	
	static{
		List<Constants> dynamicAttributesConstants = new ArrayList<Constants>();
		dynamicAttributesConstants.add(new Constants(DYNAMIC_ATTRIBUTE_ID,DYNAMIC_ATTRIBUTES.DYNAMIC_ATTRIBUTE_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		dynamicAttributesConstants.add(new Constants(ATTRIBUTE_LINK_NAME,DYNAMIC_ATTRIBUTES.ATTRIBUTE_LINK_NAME,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
		dynamicAttributesConstants.add(new Constants(PROJECT_ID,DYNAMIC_ATTRIBUTES.PROJECT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		dynamicAttributesConstants.add(new Constants(ATTRIBUTE_TYPE,DYNAMIC_ATTRIBUTES.ATTRIBUTE_TYPE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		dynamicAttributesConstants.add(new Constants(ATTRIBUTE_NAME,DYNAMIC_ATTRIBUTES.ATTRIBUTE_NAME,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
		dynamicAttributesConstants.add(new Constants(DESCRIPTION,DYNAMIC_ATTRIBUTES.DESCRIPTION,ZABConstants.STRING,Boolean.TRUE,Boolean.TRUE));
		DYNAMIC_ATTRIBUTES_CONSTANTS = Collections.unmodifiableList(dynamicAttributesConstants);
	}
	
	public static final List<Constants> STANDARD_DIMENSION_CONSTANTS;
	
	static{
		List<Constants> standardDimensionConstants = new ArrayList<Constants>();
		standardDimensionConstants.add(new Constants(DIMENSION_ID,STANDARD_DIMENSION.DIMENSION_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		standardDimensionConstants.add(new Constants(DIMENSION_NAME,STANDARD_DIMENSION.DIMENSION_NAME,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
		standardDimensionConstants.add(new Constants(DIMENSION_DESCRIPTION,STANDARD_DIMENSION.DIMENSION_DESCRIPTION,ZABConstants.STRING,Boolean.TRUE,Boolean.TRUE));
		STANDARD_DIMENSION_CONSTANTS = Collections.unmodifiableList(standardDimensionConstants);
	}
	
	public static final List<Constants> CURRENTURL_DETAIL_CONSTANTS;
	
	static{
		List<Constants> currenturlDetailConstants = new ArrayList<Constants>();
		currenturlDetailConstants.add(new Constants(CURRENTURL_DETAIL_ID,CURRENTURL_DETAIL.CURRENTURL_DETAIL_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		currenturlDetailConstants.add(new Constants(CURRENTURL_CODE,CURRENTURL_DETAIL.CURRENTURL_CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		currenturlDetailConstants.add(new Constants(CURRENTURL_VALUE,CURRENTURL_DETAIL.CURRENTURL_VALUE,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
		CURRENTURL_DETAIL_CONSTANTS = Collections.unmodifiableList(currenturlDetailConstants);
	}
	
	public static final List<Constants> REFFERERURL_DETAIL_CONSTANTS;
	
	static{
		List<Constants> reffererurlDetailConstants = new ArrayList<Constants>();
		reffererurlDetailConstants.add(new Constants(REFFERERURL_DETAIL_ID,REFFERERURL_DETAIL.REFFERERURL_DETAIL_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		reffererurlDetailConstants.add(new Constants(REFFERERURL_CODE,REFFERERURL_DETAIL.REFFERERURL_CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		reffererurlDetailConstants.add(new Constants(REFFERERURL_VALUE,REFFERERURL_DETAIL.REFFERERURL_VALUE,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
		REFFERERURL_DETAIL_CONSTANTS = Collections.unmodifiableList(reffererurlDetailConstants);
	}
	
	public static final List<Constants> TRAFFICSOURCE_DETAIL_CONSTANTS;
	
	static{
		List<Constants> trafficsourceDetailConstants = new ArrayList<Constants>();
		trafficsourceDetailConstants.add(new Constants(TRAFFICSOURCE_DETAIL_ID,TRAFFICSOURCE_DETAIL.TRAFFICSOURCE_DETAIL_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		trafficsourceDetailConstants.add(new Constants(TRAFFICSOURCE_CODE,TRAFFICSOURCE_DETAIL.TRAFFICSOURCE_CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		trafficsourceDetailConstants.add(new Constants(TRAFFICSOURCE_VALUE,TRAFFICSOURCE_DETAIL.TRAFFICSOURCE_VALUE,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
		TRAFFICSOURCE_DETAIL_CONSTANTS = Collections.unmodifiableList(trafficsourceDetailConstants);
	}
	
	public static final List<Constants> OS_DETAIL_CONSTANTS;
	
	static{
		List<Constants> osDetailConstants = new ArrayList<Constants>();
		osDetailConstants.add(new Constants(OS_DETAIL_ID,OS_DETAIL.OS_DETAIL_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		osDetailConstants.add(new Constants(OS_CODE,OS_DETAIL.OS_CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		osDetailConstants.add(new Constants(OS_VALUE,OS_DETAIL.OS_VALUE,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
		OS_DETAIL_CONSTANTS = Collections.unmodifiableList(osDetailConstants);
	}
	
	/*public static final List<Constants> USERTYPE_DETAIL_CONSTANTS;
	
	static{
		List<Constants> usertypeDetailConstants = new ArrayList<Constants>();
		usertypeDetailConstants.add(new Constants(USERTYPE_DETAIL_ID,USERTYPE_DETAIL.USERTYPE_DETAIL_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		usertypeDetailConstants.add(new Constants(USERTYPE_CODE,USERTYPE_DETAIL.USERTYPE_CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		usertypeDetailConstants.add(new Constants(USERTYPE_VALUE,USERTYPE_DETAIL.USERTYPE_VALUE,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
		USERTYPE_DETAIL_CONSTANTS = Collections.unmodifiableList(usertypeDetailConstants);
	}*/
	
	public static final List<Constants> LANGUAGE_DETAIL_CONSTANTS;
	
	static{
		List<Constants> languageDetailConstants = new ArrayList<Constants>();
		languageDetailConstants.add(new Constants(LANGUAGE_DETAIL_ID,LANGUAGE_DETAIL.LANGUAGE_DETAIL_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		languageDetailConstants.add(new Constants(LANGUAGE_CODE,LANGUAGE_DETAIL.LANGUAGE_CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		languageDetailConstants.add(new Constants(LANGUAGE_VALUE,LANGUAGE_DETAIL.LANGUAGE_VALUE,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
		languageDetailConstants.add(new Constants(LANGUAGE_DISPLAY_NAME,LANGUAGE_DETAIL.LANGUAGE_DISPLAY_NAME,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
		LANGUAGE_DETAIL_CONSTANTS = Collections.unmodifiableList(languageDetailConstants);
	}
	
	public static final List<Constants> BROWSER_DETAIL_CONSTANTS;
	
	static{
		List<Constants> browserDetailConstants = new ArrayList<Constants>();
		browserDetailConstants.add(new Constants(BROWSER_DETAIL_ID,BROWSER_DETAIL.BROWSER_DETAIL_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		browserDetailConstants.add(new Constants(BROWSER_CODE,BROWSER_DETAIL.BROWSER_CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		browserDetailConstants.add(new Constants(BROWSER_VALUE,BROWSER_DETAIL.BROWSER_VALUE,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
		BROWSER_DETAIL_CONSTANTS = Collections.unmodifiableList(browserDetailConstants);
	}
	
	public static final List<Constants> DEVICE_DETAIL_CONSTANTS;
	
	static{
		List<Constants> deviceDetailConstants = new ArrayList<Constants>();
		deviceDetailConstants.add(new Constants(DEVICE_DETAIL_ID,DEVICE_DETAIL.DEVICE_DETAIL_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		deviceDetailConstants.add(new Constants(DEVICE_CODE,DEVICE_DETAIL.DEVICE_CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		deviceDetailConstants.add(new Constants(DEVICE_VALUE,DEVICE_DETAIL.DEVICE_VALUE,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
		DEVICE_DETAIL_CONSTANTS = Collections.unmodifiableList(deviceDetailConstants);
	}
	
	public static final List<Constants> MOBILE_DEVICE_DETAIL_CONSTANTS;
	
	static{
		List<Constants> deviceDetailConstants = new ArrayList<Constants>();
		deviceDetailConstants.add(new Constants(MOBILE_DEVICE_DETAIL_ID,MOBILE_DEVICE_DETAIL.MOBILE_DEVICE_DETAIL_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		deviceDetailConstants.add(new Constants(MOBILE_DEVICE_CODE,MOBILE_DEVICE_DETAIL.MOBILE_DEVICE_CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		deviceDetailConstants.add(new Constants(MOBILE_DEVICE_VALUE,MOBILE_DEVICE_DETAIL.MOBILE_DEVICE_VALUE,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
		MOBILE_DEVICE_DETAIL_CONSTANTS = Collections.unmodifiableList(deviceDetailConstants);
	}
	
	
	public static final List<Constants> COUNTRY_DETAIL_CONSTANTS;
	
	static{
		List<Constants> countryDetailConstants = new ArrayList<Constants>();
		countryDetailConstants.add(new Constants(COUNTRY_DETAIL_ID,COUNTRY_DETAIL.COUNTRY_DETAIL_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		countryDetailConstants.add(new Constants(COUNTRY_CODE,COUNTRY_DETAIL.COUNTRY_CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		countryDetailConstants.add(new Constants(COUNTRY_VALUE,COUNTRY_DETAIL.COUNTRY_VALUE,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
		countryDetailConstants.add(new Constants(COUNTRY_DISPLAY_NAME,COUNTRY_DETAIL.COUNTRY_DISPLAY_NAME,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
		COUNTRY_DETAIL_CONSTANTS = Collections.unmodifiableList(countryDetailConstants);
	}

	
}
