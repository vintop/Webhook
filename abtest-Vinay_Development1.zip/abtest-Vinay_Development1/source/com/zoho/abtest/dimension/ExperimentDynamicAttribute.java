//$Id$
package com.zoho.abtest.dimension;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.persistence.WritableDataObject;
import com.zoho.abtest.DYNAMIC_ATTRIBUTES;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.EXPERIMENT_DYNAMIC_ATTR;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.eventactivity.EventActivityConstants;
import com.zoho.abtest.eventactivity.EventActivityWrapper;
import com.zoho.abtest.eventactivity.EventActivityConstants.Module;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentStatus;
import com.zoho.abtest.listener.ZABNotifier;
import com.zoho.abtest.project.ProjectTreeEventConstants;
import com.zoho.abtest.project.ProjectTreeEventWrapper;
import com.zoho.abtest.project.ProjectTreeEventConstants.OperationType;
import com.zoho.abtest.utility.ZABUtil;

public class ExperimentDynamicAttribute extends ZABModel{

	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(ExperimentDynamicAttribute.class.getName());
	
	private Long experimentDynamicAttributeId;
	private Long experimentId;
	private Long dynamicAttributeId;
	
	private List<Long> dynamicAttributeIdList;
	
	public List<Long> getDynamicAttributeIdList() {
		return dynamicAttributeIdList;
	}

	public void setDynamicAttributeIdList(List<Long> dynamicAttributeIdList) {
		this.dynamicAttributeIdList = dynamicAttributeIdList;
	}

	public Long getExperimentDynamicAttributeId() {
		return experimentDynamicAttributeId;
	}

	public void setExperimentDynamicAttributeId(Long experimentDynamicAttributeId) {
		this.experimentDynamicAttributeId = experimentDynamicAttributeId;
	}

	public Long getExperimentId() {
		return experimentId;
	}

	public void setExperimentId(Long experimentId) {
		this.experimentId = experimentId;
	}

	public Long getDynamicAttributeId() {
		return dynamicAttributeId;
	}

	public void setDynamicAttributeId(Long dynamicAttributeId) {
		this.dynamicAttributeId = dynamicAttributeId;
	}

	public static ExperimentDynamicAttribute createExperimentDynamicAttribute(HashMap<String, String> hs)
	{
		ExperimentDynamicAttribute experimentDynamicAttribute = null;
		try
		{
			DataObject dataObj =  ZABModel.createRow(DimensionConstants.EXPERIMENT_DYNAMIC_ATTR_CONSTANTS, EXPERIMENT_DYNAMIC_ATTR.TABLE, hs);
			Long experimentDynamicAttributeId = (Long)dataObj.getFirstValue(EXPERIMENT_DYNAMIC_ATTR.TABLE, EXPERIMENT_DYNAMIC_ATTR.EXPERIMENT_DYNAMIC_ATTR_ID);
			experimentDynamicAttribute = new ExperimentDynamicAttribute();
			experimentDynamicAttribute.setExperimentDynamicAttributeId(experimentDynamicAttributeId);
			experimentDynamicAttribute.setSuccess(Boolean.TRUE);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			experimentDynamicAttribute = new ExperimentDynamicAttribute();
			experimentDynamicAttribute.setSuccess(Boolean.FALSE);
		}
		return experimentDynamicAttribute;
	}
	
	public static List<ExperimentDynamicAttribute> createExperimentDynamicAttribute(Long experimentId, List<String> dynamicAttributeIdsToBeMapped)
	{
		List<ExperimentDynamicAttribute> expDynamicAttrList = null;
		ExperimentDynamicAttribute experimentDynamicAttribute = null;
		try
		{
			ArrayList<HashMap<String, String>> hsList = new ArrayList<HashMap<String, String>>();
			HashMap<String, String> hs = null;
			for(String dynamicAttributeId:dynamicAttributeIdsToBeMapped)
			{
				hs = new HashMap<String, String>();
				hs.put(DimensionConstants.EXPERIMENT_ID, experimentId.toString());
				hs.put(DimensionConstants.DYNAMIC_ATTRIBUTE_ID, dynamicAttributeId);
				hsList.add(hs);
			}
			
			DataObject dataObj =  ZABModel.createRow(DimensionConstants.EXPERIMENT_DYNAMIC_ATTR_CONSTANTS, EXPERIMENT_DYNAMIC_ATTR.TABLE, hsList);
			Iterator<?> iter = dataObj.getRows(EXPERIMENT_DYNAMIC_ATTR.TABLE);
			expDynamicAttrList = new ArrayList<ExperimentDynamicAttribute>();
			while(iter.hasNext())
			{
				Row row = (Row)iter.next();
				experimentDynamicAttribute = getExperimentDynamicAttributeFromRow(row);
				expDynamicAttrList.add(experimentDynamicAttribute);
			}
			
			//To Update in js embed file
			List<Long> dynamicAttributeIdList = new ArrayList<Long>();
			for(String dynamicAttributeId:dynamicAttributeIdsToBeMapped)
			{
				dynamicAttributeIdList.add(Long.parseLong(dynamicAttributeId));
			}
			ExperimentDynamicAttribute expDynamicAttributeTemp = new ExperimentDynamicAttribute();
			expDynamicAttributeTemp.setExperimentId(experimentId);
			expDynamicAttributeTemp.setDynamicAttributeIdList(dynamicAttributeIdList);
			ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
			wrapper.setModel(expDynamicAttributeTemp);
			wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
			wrapper.setType(OperationType.CREATE);
			ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);
			
			//Event Activity Log
			HashMap<String, String> updatedValues = new HashMap<String, String>();
			updatedValues.put(EventActivityConstants.EXPERIMENT_ID, experimentId.toString());
			updatedValues.put(EventActivityConstants.USER_ID, ZABUtil.getCurrentUser().getUserId().toString());
			updatedValues.put(EventActivityConstants.TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
			EventActivityWrapper activityWrapper = new EventActivityWrapper();
			activityWrapper.setModule(Module.EXPERIMENT_DYNAMIC_ATTRIBUTE);
			activityWrapper.setOperationType(com.zoho.abtest.eventactivity.EventActivityConstants.OperationType.CREATE);
			activityWrapper.setDbSpace(ZABUtil.getCurrentUserDbSpace());
			activityWrapper.setUpdatedValues(updatedValues);
			activityWrapper.setCustomObject(dynamicAttributeIdList);
			ZABNotifier.notifyListeners(EventActivityConstants.EVENT_MODULE_NAME, activityWrapper);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			expDynamicAttrList = new ArrayList<ExperimentDynamicAttribute>();
			experimentDynamicAttribute = new ExperimentDynamicAttribute();
			experimentDynamicAttribute.setSuccess(Boolean.FALSE);
			expDynamicAttrList.add(experimentDynamicAttribute);
		}
		return expDynamicAttrList;
	}
	
	public static List<ExperimentDynamicAttribute> deleteExperimentDynamicAttribute(Long experimentId, List<Long> dynamicAttributeIds)
	{
		List<ExperimentDynamicAttribute> expDynamicAttrList = null;
		ExperimentDynamicAttribute experimentDynamicAttribute = null;
		try
		{
			Long[] arr = dynamicAttributeIds.toArray(new Long[dynamicAttributeIds.size()]);
			Criteria criteria1 = new Criteria(new Column(EXPERIMENT_DYNAMIC_ATTR.TABLE, EXPERIMENT_DYNAMIC_ATTR.EXPERIMENT_ID),experimentId,QueryConstants.EQUAL);
			Criteria criteria2 = new Criteria(new Column(EXPERIMENT_DYNAMIC_ATTR.TABLE, EXPERIMENT_DYNAMIC_ATTR.DYNAMIC_ATTRIBUTE_ID),arr,QueryConstants.IN);
			ZABModel.deleteRow(EXPERIMENT_DYNAMIC_ATTR.TABLE, criteria1.and(criteria2), null);
			
			//TODO once the rows are deleted - each status of each row and update it in response
			expDynamicAttrList = new ArrayList<ExperimentDynamicAttribute>();
			experimentDynamicAttribute = new ExperimentDynamicAttribute();
			experimentDynamicAttribute.setSuccess(Boolean.TRUE);
			expDynamicAttrList.add(experimentDynamicAttribute);
			
			//To Update in js embed file
			ExperimentDynamicAttribute expDynamicAttributeTemp = new ExperimentDynamicAttribute();
			expDynamicAttributeTemp.setExperimentId(experimentId);
			expDynamicAttributeTemp.setDynamicAttributeIdList(dynamicAttributeIds);
			ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
			wrapper.setModel(expDynamicAttributeTemp);
			wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
			wrapper.setType(OperationType.DELETE);
			ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);
			
			//Event Activity Log
			HashMap<String, String> updatedValues = new HashMap<String, String>();
			updatedValues.put(EventActivityConstants.EXPERIMENT_ID, experimentId.toString());
			updatedValues.put(EventActivityConstants.USER_ID, ZABUtil.getCurrentUser().getUserId().toString());
			updatedValues.put(EventActivityConstants.TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
			EventActivityWrapper activityWrapper = new EventActivityWrapper();
			activityWrapper.setModule(Module.EXPERIMENT_DYNAMIC_ATTRIBUTE);
			activityWrapper.setOperationType(com.zoho.abtest.eventactivity.EventActivityConstants.OperationType.DELETE);
			activityWrapper.setDbSpace(ZABUtil.getCurrentUserDbSpace());
			activityWrapper.setUpdatedValues(updatedValues);
			activityWrapper.setCustomObject(dynamicAttributeIds);
			ZABNotifier.notifyListeners(EventActivityConstants.EVENT_MODULE_NAME, activityWrapper);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			expDynamicAttrList = new ArrayList<ExperimentDynamicAttribute>();
			experimentDynamicAttribute = new ExperimentDynamicAttribute();
			experimentDynamicAttribute.setSuccess(Boolean.FALSE);
			expDynamicAttrList.add(experimentDynamicAttribute);
		}
		return expDynamicAttrList;
	}
	
	public static ExperimentDynamicAttribute getExperimentDynamicAttributeFromRow(Row row)
	{
		ExperimentDynamicAttribute experimentDynamicAttribute = new ExperimentDynamicAttribute();
		experimentDynamicAttribute.setExperimentDynamicAttributeId((Long)row.get(EXPERIMENT_DYNAMIC_ATTR.EXPERIMENT_DYNAMIC_ATTR_ID));
		experimentDynamicAttribute.setExperimentId((Long)row.get(EXPERIMENT_DYNAMIC_ATTR.EXPERIMENT_ID));
		experimentDynamicAttribute.setDynamicAttributeId((Long)row.get(EXPERIMENT_DYNAMIC_ATTR.DYNAMIC_ATTRIBUTE_ID));
		experimentDynamicAttribute.setSuccess(Boolean.TRUE);
		return experimentDynamicAttribute;
	}
	
	public static List<DynamicAttributes> getDynamicAttributesByExperiment(Long experimentId)
	{
		List<DynamicAttributes> dynamicAttributeList = null;
		DynamicAttributes dynamicAttribute = null;
		try
		{
			Criteria criteria1 = new Criteria(new Column(EXPERIMENT_DYNAMIC_ATTR.TABLE, EXPERIMENT_DYNAMIC_ATTR.EXPERIMENT_ID),experimentId,QueryConstants.EQUAL);
			Join join = new Join(EXPERIMENT_DYNAMIC_ATTR.TABLE, DYNAMIC_ATTRIBUTES.TABLE, new String[]{EXPERIMENT_DYNAMIC_ATTR.DYNAMIC_ATTRIBUTE_ID}, new String[]{DYNAMIC_ATTRIBUTES.DYNAMIC_ATTRIBUTE_ID}, Join.INNER_JOIN);
			DataObject dataObj = ZABModel.getRow(EXPERIMENT_DYNAMIC_ATTR.TABLE, criteria1, join);
			Iterator<?> dynamicAttrItr =  dataObj.getRows(DYNAMIC_ATTRIBUTES.TABLE);
			
			dynamicAttributeList = new ArrayList<DynamicAttributes>();
			while(dynamicAttrItr.hasNext())
			{
				Row row = (Row)dynamicAttrItr.next();
				dynamicAttribute = DynamicAttributes.getDynamicAttributesFromRow(row);
				dynamicAttributeList.add(dynamicAttribute);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			dynamicAttributeList = new ArrayList<DynamicAttributes>();
		}
		return dynamicAttributeList;
	}
	
	public static List<DynamicAttributes> getDynamicAttributesByExpAndType(Long experimentId, Integer dynamicAttributeType)
	{
		List<DynamicAttributes> dynamicAttributeList = null;
		DynamicAttributes dynamicAttribute = null;
		try
		{
			Criteria criteria1 = new Criteria(new Column(EXPERIMENT_DYNAMIC_ATTR.TABLE, EXPERIMENT_DYNAMIC_ATTR.EXPERIMENT_ID),experimentId,QueryConstants.EQUAL);
			Criteria criteria2 = new Criteria(new Column(DYNAMIC_ATTRIBUTES.TABLE, DYNAMIC_ATTRIBUTES.ATTRIBUTE_TYPE),dynamicAttributeType,QueryConstants.EQUAL);
			Join join = new Join(EXPERIMENT_DYNAMIC_ATTR.TABLE, DYNAMIC_ATTRIBUTES.TABLE, new String[]{EXPERIMENT_DYNAMIC_ATTR.DYNAMIC_ATTRIBUTE_ID}, new String[]{DYNAMIC_ATTRIBUTES.DYNAMIC_ATTRIBUTE_ID}, Join.INNER_JOIN);
			DataObject dataObj = ZABModel.getRow(EXPERIMENT_DYNAMIC_ATTR.TABLE, criteria1.and(criteria2), join);
			Iterator<?> dynamicAttrItr =  dataObj.getRows(DYNAMIC_ATTRIBUTES.TABLE);
			
			dynamicAttributeList = new ArrayList<DynamicAttributes>();
			while(dynamicAttrItr.hasNext())
			{
				Row row = (Row)dynamicAttrItr.next();
				dynamicAttribute = DynamicAttributes.getDynamicAttributesFromRow(row);
				dynamicAttributeList.add(dynamicAttribute);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			dynamicAttributeList = new ArrayList<DynamicAttributes>();
		}
		return dynamicAttributeList;
	}
	
	public static List<Experiment> getExperimentsByDynamicAttributeId(Long dynamicAttributeId)
	{
		List<Experiment> experimentList = null;
		Experiment experiment = null;
		try
		{
			Criteria criteria1 = new Criteria(new Column(EXPERIMENT_DYNAMIC_ATTR.TABLE, EXPERIMENT_DYNAMIC_ATTR.DYNAMIC_ATTRIBUTE_ID),dynamicAttributeId,QueryConstants.EQUAL);
			Join join = new Join(EXPERIMENT_DYNAMIC_ATTR.TABLE, EXPERIMENT.TABLE, new String[]{EXPERIMENT_DYNAMIC_ATTR.EXPERIMENT_ID}, new String[]{EXPERIMENT.EXPERIMENT_ID}, Join.INNER_JOIN);
			DataObject dataObj = ZABModel.getRow(EXPERIMENT_DYNAMIC_ATTR.TABLE, criteria1, join);
			Iterator<?> experimentItr =  dataObj.getRows(EXPERIMENT.TABLE);
			
			experimentList = new ArrayList<Experiment>();
			while(experimentItr.hasNext())
			{
				Row row = (Row)experimentItr.next();
				experiment = Experiment.getExperimentFromRow(row);
				experimentList.add(experiment);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			experimentList = new ArrayList<Experiment>();
		}
		return experimentList;
	}
	
	public static List<Long> getExperimentIdsByDynamicAttributeId(Long dynamicAttributeId)
	{
		List<Long> experimentIds = null;
		try
		{
			Criteria criteria1 = new Criteria(new Column(EXPERIMENT_DYNAMIC_ATTR.TABLE, EXPERIMENT_DYNAMIC_ATTR.DYNAMIC_ATTRIBUTE_ID),dynamicAttributeId,QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(EXPERIMENT_DYNAMIC_ATTR.TABLE, criteria1);
			Iterator<?> experimentItr =  dataObj.getRows(EXPERIMENT_DYNAMIC_ATTR.TABLE);
			
			experimentIds = new ArrayList<Long>();
			while(experimentItr.hasNext())
			{
				Row row = (Row)experimentItr.next();
				experimentIds.add((Long)row.get(EXPERIMENT_DYNAMIC_ATTR.EXPERIMENT_ID));
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			experimentIds = new ArrayList<Long>();
		}
		return experimentIds;
	}
	
	public static List<Experiment> getActiveExperimentsByDynamicAttributeId(Long dynamicAttributeId)
	{
		List<Experiment> experimentList = null;
		Experiment experiment = null;
		try
		{
			Criteria criteria1 = new Criteria(new Column(EXPERIMENT_DYNAMIC_ATTR.TABLE, EXPERIMENT_DYNAMIC_ATTR.DYNAMIC_ATTRIBUTE_ID),dynamicAttributeId,QueryConstants.EQUAL);
			Criteria criteria2 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_STATUS), ExperimentStatus.RUNNING.getStatusCode(), QueryConstants.EQUAL);
			Join join = new Join(EXPERIMENT_DYNAMIC_ATTR.TABLE, EXPERIMENT.TABLE, new String[]{EXPERIMENT_DYNAMIC_ATTR.EXPERIMENT_ID}, new String[]{EXPERIMENT.EXPERIMENT_ID}, Join.INNER_JOIN);
			DataObject dataObj = ZABModel.getRow(EXPERIMENT_DYNAMIC_ATTR.TABLE, criteria1.and(criteria2), join);
			Iterator<?> experimentItr =  dataObj.getRows(EXPERIMENT.TABLE);
			
			experimentList = new ArrayList<Experiment>();
			while(experimentItr.hasNext())
			{
				Row row = (Row)experimentItr.next();
				experiment = Experiment.getExperimentFromRow(row);
				experimentList.add(experiment);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			experimentList = new ArrayList<Experiment>();
		}
		return experimentList;
	}
	
	public static List<Experiment> getActiveExperimentsByDynamicAttributeLinkName(String linkName)
	{
		List<Experiment> experimentList = null;
		Experiment experiment = null;
		try
		{
			Criteria criteria1 = new Criteria(new Column(DYNAMIC_ATTRIBUTES.TABLE, DYNAMIC_ATTRIBUTES.ATTRIBUTE_LINK_NAME),linkName,QueryConstants.EQUAL);
			Criteria criteria2 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_STATUS), ExperimentStatus.RUNNING.getStatusCode(), QueryConstants.EQUAL);
			Join join1 = new Join(DYNAMIC_ATTRIBUTES.TABLE,EXPERIMENT_DYNAMIC_ATTR.TABLE, new String[]{DYNAMIC_ATTRIBUTES.DYNAMIC_ATTRIBUTE_ID}, new String[]{EXPERIMENT_DYNAMIC_ATTR.DYNAMIC_ATTRIBUTE_ID}, Join.INNER_JOIN);
			Join join2 = new Join(EXPERIMENT_DYNAMIC_ATTR.TABLE, EXPERIMENT.TABLE, new String[]{EXPERIMENT_DYNAMIC_ATTR.EXPERIMENT_ID}, new String[]{EXPERIMENT.EXPERIMENT_ID}, Join.INNER_JOIN);
			DataObject dataObj = ZABModel.getRow(DYNAMIC_ATTRIBUTES.TABLE, criteria1.and(criteria2), new Join[]{join1,join2});
			Iterator<?> experimentItr =  dataObj.getRows(EXPERIMENT.TABLE);
			
			experimentList = new ArrayList<Experiment>();
			while(experimentItr.hasNext())
			{
				Row row = (Row)experimentItr.next();
				experiment = Experiment.getExperimentFromRow(row);
				experimentList.add(experiment);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			experimentList = new ArrayList<Experiment>();
		}
		return experimentList;
	}
	
	public static void createDynamicAttributeMappingWithoutEvent(Long dynAttrId, Long expId) throws Exception {
		DataObject dobj = new WritableDataObject();
		Row dupRow = new Row(EXPERIMENT_DYNAMIC_ATTR.TABLE);
		dupRow.set(EXPERIMENT_DYNAMIC_ATTR.EXPERIMENT_ID, expId);
		dupRow.set(EXPERIMENT_DYNAMIC_ATTR.DYNAMIC_ATTRIBUTE_ID, dynAttrId);
		dobj.addRow(dupRow);
		updateDataObject(dobj);
	}
	
}
