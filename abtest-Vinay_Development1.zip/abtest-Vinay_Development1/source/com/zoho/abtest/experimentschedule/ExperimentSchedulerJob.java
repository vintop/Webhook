//$Id$
package com.zoho.abtest.experimentschedule;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.sas.ds.SASThreadLocal;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.scheduler.RunnableJob;

public class ExperimentSchedulerJob implements RunnableJob
{
	private static final Logger LOGGER = Logger.getLogger(ExperimentSchedulerJob.class.getName());
	@Override
	public void run(long id) throws Exception 
	{
		LOGGER.log(Level.INFO, "ExperimentSchedulerJob - Schedule Job starts running");
		try
		{
			//ZABUtil.setIsSchedulerJob(Boolean.TRUE);
			String userName = SASThreadLocal.getLoginName(); 
			ZABUtil.setDBSpace(userName);
			//String dbSpaceId = ExperimentSchedule.getDBSpaceFromScheduleMappingId(id);
			//ZABUtil.setDBSpace(dbSpaceId);
			ExperimentSchedule.scheduleExperiment(id);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in ExperimentSchedulerJob");
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		LOGGER.log(Level.INFO, "ExperimentSchedulerJob - Schedule Job successfully finished");
	}

}
