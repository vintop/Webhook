//$Id$
package com.zoho.abtest.experimentschedule;

import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.sas.ds.SASThreadLocal;
import com.adventnet.sas.sqgen.ExtendedSequenceGeneratorRepository;
import com.zoho.abtest.EXPERIMENT_SCHEDULE;
import com.zoho.abtest.SCHEDULE_MAPPING;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentStatus;
import com.zoho.abtest.experiment.ExperimentHandler;
import com.zoho.abtest.listener.ZABNotifier;
import com.zoho.abtest.project.ProjectTreeEventConstants;
import com.zoho.abtest.project.ProjectTreeEventWrapper;
import com.zoho.abtest.project.ProjectTreeEventConstants.OperationType;
import com.zoho.abtest.utility.ZABSchedulerUtil;
import com.zoho.abtest.utility.ZABUtil;


public class ExperimentSchedule {
	
	private static final Logger LOGGER = Logger.getLogger(ExperimentSchedule.class.getName());
	
	private Long scheduleId;
	private Long origScheduleId;
	private Long experimentId;
	private Integer scheduleType;
	private Long scheduleTime;
	private boolean isCompleted;
	
	public boolean isCompleted() {
		return isCompleted;
	}
	public void setCompleted(boolean isCompleted) {
		this.isCompleted = isCompleted;
	}
	public Long getOrigScheduleId() {
		return origScheduleId;
	}
	public void setOrigScheduleId(Long origScheduleId) {
		this.origScheduleId = origScheduleId;
	}
	public Long getScheduleId() {
		return scheduleId;
	}
	public void setScheduleId(Long scheduleId) {
		this.scheduleId = scheduleId;
	}
	public Long getExperimentId() {
		return experimentId;
	}
	public void setExperimentId(Long experimentId) {
		this.experimentId = experimentId;
	}
	public Integer getScheduleType() {
		return scheduleType;
	}
	public void setScheduleType(Integer scheduleType) {
		this.scheduleType = scheduleType;
	}
	public Long getScheduleTime() {
		return scheduleTime;
	}
	public void setScheduleTime(Long scheduleTime) {
		this.scheduleTime = scheduleTime;
	}
	
	public static void processExperimentSchedule(HashMap<String, String> hs) throws Exception
	{
		try
		{
			Long experimentId = Long.parseLong(hs.get(ExperimentScheduleConstants.EXPERIMENT_ID));
			Integer scheduleType = Integer.parseInt(hs.get(ExperimentScheduleConstants.SCHEDULE_TYPE));
			
			//Check if the schedule exists
			Criteria criteria1 = new Criteria(new Column(EXPERIMENT_SCHEDULE.TABLE, EXPERIMENT_SCHEDULE.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
			Criteria criteria2 = new Criteria(new Column(EXPERIMENT_SCHEDULE.TABLE, EXPERIMENT_SCHEDULE.SCHEDULE_TYPE), scheduleType, QueryConstants.EQUAL);
			
			DataObject dataObj = ZABModel.getRow(EXPERIMENT_SCHEDULE.TABLE, criteria1.and(criteria2));
			
			if(dataObj.isEmpty())
			{
				//Long scheduleMappingId = generateScheduleId();
				//Long sasUserId = SASThreadLocal.getUserId();
				Long scheduleMappingId = (Long)ExtendedSequenceGeneratorRepository.getSequenceGenerator().nextValue();
				hs.put(ExperimentScheduleConstants.ORIG_SCHEDULE_ID, scheduleMappingId.toString());
				hs.put(ExperimentScheduleConstants.IS_COMPLETED, Boolean.FALSE.toString());
				ZABModel.createRow(ExperimentScheduleConstants.EXPERIMENT_SCHEDULE_CONSTANTS, EXPERIMENT_SCHEDULE.TABLE, hs);
				Long timeOfExecution =  Long.parseLong(hs.get(ExperimentScheduleConstants.SCHEDULE_TIME));
				ZABSchedulerUtil.submitOneTimeJob(timeOfExecution, scheduleMappingId, ExperimentSchedulerJob.class.getName());
			}
			else
			{
				//Long sasUserId = SASThreadLocal.getUserId();
				Long scheduleMappingId = (Long)dataObj.getFirstValue(EXPERIMENT_SCHEDULE.TABLE, EXPERIMENT_SCHEDULE.ORIG_SCHEDULE_ID);
				boolean isCompleted = (Boolean)dataObj.getFirstValue(EXPERIMENT_SCHEDULE.TABLE, EXPERIMENT_SCHEDULE.IS_COMPLETED);
				Long timeOfExecution =  Long.parseLong(hs.get(ExperimentScheduleConstants.SCHEDULE_TIME));
				if(isCompleted)
				{
					ZABSchedulerUtil.submitOneTimeJob(timeOfExecution, scheduleMappingId, ExperimentSchedulerJob.class.getName());
				}
				else
				{
					ZABSchedulerUtil.updateOneTimeJob(timeOfExecution, scheduleMappingId, ExperimentSchedulerJob.class.getName());
				}
				hs.put(ExperimentScheduleConstants.IS_COMPLETED, Boolean.FALSE.toString());
				Criteria criteria3 = new Criteria(new Column(EXPERIMENT_SCHEDULE.TABLE, EXPERIMENT_SCHEDULE.ORIG_SCHEDULE_ID), scheduleMappingId, QueryConstants.EQUAL);
				ZABModel.updateRow(ExperimentScheduleConstants.EXPERIMENT_SCHEDULE_CONSTANTS, EXPERIMENT_SCHEDULE.TABLE, hs, criteria3, ExperimentScheduleConstants.API_MODULE, Boolean.FALSE);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			throw ex;
		}
	}
	
	public static void deleteExperimentSchedule(HashMap<String, String> hs) throws Exception
	{
		try
		{
			Long experimentId = Long.parseLong(hs.get(ExperimentScheduleConstants.EXPERIMENT_ID));
			Integer scheduleType = Integer.parseInt(hs.get(ExperimentScheduleConstants.SCHEDULE_TYPE));
			
			//Check if the schedule exists
			Criteria criteria1 = new Criteria(new Column(EXPERIMENT_SCHEDULE.TABLE, EXPERIMENT_SCHEDULE.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
			Criteria criteria2 = new Criteria(new Column(EXPERIMENT_SCHEDULE.TABLE, EXPERIMENT_SCHEDULE.SCHEDULE_TYPE), scheduleType, QueryConstants.EQUAL);
			
			DataObject dataObj = ZABModel.getRow(EXPERIMENT_SCHEDULE.TABLE, criteria1.and(criteria2));
			if(!dataObj.isEmpty())
			{
				Long scheduleMappingId = (Long)dataObj.getFirstValue(EXPERIMENT_SCHEDULE.TABLE, EXPERIMENT_SCHEDULE.ORIG_SCHEDULE_ID);
				boolean isCompleted = (Boolean)dataObj.getFirstValue(EXPERIMENT_SCHEDULE.TABLE, EXPERIMENT_SCHEDULE.IS_COMPLETED); 
				Criteria criteria3 = new Criteria(new Column(EXPERIMENT_SCHEDULE.TABLE, EXPERIMENT_SCHEDULE.ORIG_SCHEDULE_ID), scheduleMappingId, QueryConstants.EQUAL);
				if(!isCompleted)
				{
					ZABSchedulerUtil.deleteOneTimeJob(scheduleMappingId);
				}
				ZABModel.deleteRow(EXPERIMENT_SCHEDULE.TABLE, criteria3, ExperimentScheduleConstants.API_MODULE);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			throw ex;
		}
	}
	
	public static Long generateScheduleId() throws Exception
	{
		HashMap<String, String> hs = new HashMap<String, String>();
		String dbspace= ZABUtil.getCurrentUserDbSpace();
		hs.put(ExperimentScheduleConstants.DBSPACE_ID, dbspace);
		ZABUtil.setDBSpace("admin");  //NO I18N
		DataObject dobj = ZABModel.createRow(ExperimentScheduleConstants.SCHEDULE_MAPPING_CONSTANTS, SCHEDULE_MAPPING.TABLE, hs);
		Long scheduleId = (Long)dobj.getFirstValue(SCHEDULE_MAPPING.TABLE, SCHEDULE_MAPPING.SCHEDULE_MAPPING_ID);
		ZABUtil.setDBSpace(dbspace);
		return scheduleId;
	}
	
	public static String getDBSpaceFromScheduleMappingId(Long scheduleMappingId) throws Exception
	{
		String dbSpaceId = "";
		String dbspace= ZABUtil.getCurrentUserDbSpace();
		ZABUtil.setDBSpace("admin");  //NO I18N
		Criteria criteria1 = new Criteria(new Column(SCHEDULE_MAPPING.TABLE, SCHEDULE_MAPPING.SCHEDULE_MAPPING_ID), scheduleMappingId, QueryConstants.EQUAL);
		DataObject dataObj = ZABModel.getRow(SCHEDULE_MAPPING.TABLE, criteria1);
		dbSpaceId = (String)dataObj.getFirstValue(SCHEDULE_MAPPING.TABLE, SCHEDULE_MAPPING.DBSPACE_ID);
		ZABUtil.setDBSpace(dbspace);
		return dbSpaceId;
	}
	
	public static void scheduleExperiment(Long origScheduleId) throws Exception
	{
		try
		{
			boolean flag = false;
			Criteria criteria1 = new Criteria(new Column(EXPERIMENT_SCHEDULE.TABLE, EXPERIMENT_SCHEDULE.ORIG_SCHEDULE_ID), origScheduleId, QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(EXPERIMENT_SCHEDULE.TABLE, criteria1);
			if(!dataObj.isEmpty())
			{
				Row row = dataObj.getFirstRow(EXPERIMENT_SCHEDULE.TABLE);
				ExperimentSchedule experimentSchedule = getExperimentScheduleFromRow(row);
				Experiment experiment =	Experiment.getExperimentById(experimentSchedule.getExperimentId());
				String expLinkName = experiment.getExperimentLinkname();
				Integer currentExpStatus = experiment.getExperimentStatus();
				HashMap<String, String> experimentHs = new HashMap<String, String>();
				experimentHs.put(ExperimentConstants.EXPERIMENT_LINKNAME, expLinkName);
				Integer statusCode = null;
				if(experimentSchedule.getScheduleType().equals(ExperimentScheduleConstants.ExperimentScheduleType.EXPERIMENT_START.getScheduleType()))
				{
					statusCode =  ExperimentStatus.RUNNING.getStatusCode();
					if(!currentExpStatus.equals(ExperimentStatus.RUNNING.getStatusCode()))
					{
						flag = true;
					}
				}
				else if(experimentSchedule.getScheduleType().equals(ExperimentScheduleConstants.ExperimentScheduleType.EXPERIMENT_STOP.getScheduleType()))
				{
					statusCode =  ExperimentStatus.PAUSED.getStatusCode();
					if(!currentExpStatus.equals(ExperimentStatus.PAUSED.getStatusCode()))
					{
						flag = true;
					}
				}
				
				//Update Job completed status
				HashMap<String, String> hs = new HashMap<String, String>();
				hs.put(ExperimentScheduleConstants.IS_COMPLETED, Boolean.TRUE.toString());
				ZABModel.updateRow(ExperimentScheduleConstants.EXPERIMENT_SCHEDULE_CONSTANTS, EXPERIMENT_SCHEDULE.TABLE, hs, criteria1, ExperimentScheduleConstants.API_MODULE, Boolean.FALSE);
			
				//Update the experiment status
				if(flag)
				{
					experimentHs.put(ExperimentConstants.EXPERIMENT_STATUS, statusCode.toString());
					ExperimentHandler.handleExperimentUpdation(experimentHs);
				}
				
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			throw ex;
		}
	}
	
	public static ExperimentSchedule getExperimentScheduleFromRow(Row row)
	{
		ExperimentSchedule experimentSchedule = new ExperimentSchedule();
		experimentSchedule.setScheduleId((Long)row.get(EXPERIMENT_SCHEDULE.SCHEDULE_ID));
		experimentSchedule.setOrigScheduleId((Long)row.get(EXPERIMENT_SCHEDULE.ORIG_SCHEDULE_ID));
		experimentSchedule.setExperimentId((Long)row.get(EXPERIMENT_SCHEDULE.EXPERIMENT_ID));
		experimentSchedule.setScheduleType((Integer)row.get(EXPERIMENT_SCHEDULE.SCHEDULE_TYPE));
		experimentSchedule.setScheduleTime((Long)row.get(EXPERIMENT_SCHEDULE.SCHEDULE_TIME));
		experimentSchedule.setCompleted((Boolean)row.get(EXPERIMENT_SCHEDULE.IS_COMPLETED));
		return experimentSchedule;
	}

}
