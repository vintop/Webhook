//$Id$
package com.zoho.abtest.experimentschedule;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.zoho.abtest.EXPERIMENT_SCHEDULE;
import com.zoho.abtest.SCHEDULE_MAPPING;
import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.ZABConstants;

public class ExperimentScheduleConstants {
	
	public static final String API_MODULE = "experimentschedule"; //No I18N
	
	public static final String EXPERIMENT_ID = "experiment_id"; //No I18N
	public static final String SCHEDULE_ID = "schedule_id"; //No I18N
	public static final String ORIG_SCHEDULE_ID = "orig_schedule_id"; //No I18N
	public static final String SCHEDULE_TYPE = "schedule_type"; //No I18N
	public static final String SCHEDULE_TIME = "schedule_time"; //No I18N
	public static final String IS_COMPLETED = "is_completed"; //No I18N 
	public static final String SCHEDULE_MAPPING_ID = "schedule_mapping_id"; //No I18N
	public static final String DBSPACE_ID = "dbspace_id"; //No I18N
	
	public static enum ExperimentScheduleType
	{
		EXPERIMENT_START(1),
		EXPERIMENT_STOP(2);
		
		private Integer scheduleType;
		
		private ExperimentScheduleType(Integer scheduleType)
		{
			this.scheduleType = scheduleType;
		}

		public Integer getScheduleType() {
			return scheduleType;
		}

		public void setScheduleType(Integer scheduleType) {
			this.scheduleType = scheduleType;
		}
	}
	
	public final static List<Constants> EXPERIMENT_SCHEDULE_CONSTANTS;
	
	static
	{
		List<Constants> scheduleList = new ArrayList<Constants>();
		scheduleList.add(new Constants(SCHEDULE_ID,EXPERIMENT_SCHEDULE.SCHEDULE_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		scheduleList.add(new Constants(ORIG_SCHEDULE_ID,EXPERIMENT_SCHEDULE.ORIG_SCHEDULE_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		scheduleList.add(new Constants(EXPERIMENT_ID,EXPERIMENT_SCHEDULE.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		scheduleList.add(new Constants(SCHEDULE_TYPE,EXPERIMENT_SCHEDULE.SCHEDULE_TYPE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		scheduleList.add(new Constants(SCHEDULE_TIME,EXPERIMENT_SCHEDULE.SCHEDULE_TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		scheduleList.add(new Constants(IS_COMPLETED,EXPERIMENT_SCHEDULE.IS_COMPLETED,ZABConstants.BOOLEAN,Boolean.TRUE,Boolean.FALSE));
		EXPERIMENT_SCHEDULE_CONSTANTS = (List<Constants>) Collections.unmodifiableList(scheduleList);
	}
	
	//This is a dead table code -SCHEDULE_MAPPING
	public final static List<Constants> SCHEDULE_MAPPING_CONSTANTS;
	
	static
	{
		List<Constants> scheduleMappingConstants = new ArrayList<Constants>();
		scheduleMappingConstants.add(new Constants(SCHEDULE_MAPPING_ID,SCHEDULE_MAPPING.SCHEDULE_MAPPING_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		scheduleMappingConstants.add(new Constants(DBSPACE_ID,SCHEDULE_MAPPING.DBSPACE_ID,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
		SCHEDULE_MAPPING_CONSTANTS = (List<Constants>) Collections.unmodifiableList(scheduleMappingConstants);
	}

}
