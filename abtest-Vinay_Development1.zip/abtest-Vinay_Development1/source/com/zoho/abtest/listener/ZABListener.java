//$Id$
package com.zoho.abtest.listener;

import java.util.Observable;
import java.util.Observer;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.mqueue.rescue.ResQueCoordinator;
import com.zoho.abtest.project.ProjectIPFilter;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.mqueue.consumer.ConsumerRecord;
import com.zoho.mqueue.producer.MessageProducer;

public abstract class ZABListener implements Observer {
	
	private Object obj;
	
	private static final Logger LOGGER = Logger.getLogger(ZABListener.class.getName());
	
	public Object getObj() {
		return obj;
	}

	public void setObj(Object obj) {
		this.obj = obj;
	}
	
	/**
	 * Please provide details for validating IPRestriction
	 * If IPRestriction is not required for your module just return null
	 * @return String
	 */
	public abstract IPRestrictionData getIPRestrictionData(Object message) throws ZABException ;
	
	/**
	 * Whenever Kafka message is received the below function is invoked with the data
	 * Throwing exception out of this function prevents
	 * @throws Exception
	 */
	public abstract void consumeMessage(Object object) throws Exception;
	
	public void setDBSpace(String portal) throws ZABException {
		Long zsoid = ZABServiceOrgUtil.getZSOIDFromDomain(portal);
		if(zsoid != null)
		{
			ZABUtil.setDBSpace(zsoid.toString());
		}
		else
		{
			throw new ZABException("Invalid portal provided :"+portal); //NO I18N
		}
	}
	
	public void processMessage(ConsumerRecord<String, String> record)
			throws Exception {
		String message = record.getMessage();
		Object wrapper = ZABUtil.fromBase64String(message);
		LOGGER.log(Level.INFO, "Message Received:"+wrapper);
		if(wrapper!=null) {
			//Validation IP
			try {
				IPRestrictionData restriction = getIPRestrictionData(wrapper);
				if(restriction!=null) {
					ZABUtil.setDBSpace(restriction.getDbSpace());
					Boolean validIP = ProjectIPFilter.validateIP(restriction.getIpAddress(), restriction.getProjectId());
					LOGGER.log(Level.INFO, "Receiving IP:****");
					if(validIP) {	
						LOGGER.log(Level.INFO, "Discarding message as IP:**** is excluded:");
						record.commit();
						return;
					}
				}
				
			} catch (Exception e) {
				LOGGER.log(Level.SEVERE, "Exception occured while validating IPRestriction", e);
			}
			consumeMessage(wrapper);
		}
		record.commit();
	}
	
	public void processObject(Object obj) throws Exception {
		try {
			Object wrapper = getObj();
			IPRestrictionData restriction = getIPRestrictionData(wrapper);
			if(restriction!=null) {
				ZABUtil.setDBSpace(restriction.getDbSpace());
				Boolean validIP = ProjectIPFilter.validateIP(restriction.getIpAddress(), restriction.getProjectId());
				if(!validIP) {	
					LOGGER.log(Level.INFO, "Discarding message as IP is not valid:"+wrapper);
					return;
				}
			}
			
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Exception occured while validating IPRestriction", e);
		}
		consumeMessage(obj);
	}

	@Override
	public void update(Observable o, Object arg) {
		String clsName=this.getClass().getName();
		Class listenerClass= null;
		ZABListener listenerObject= null;
		ZABNotifier notifier = null;
		String message = null;
		try {
			listenerClass=Class.forName(clsName);
			listenerObject=(ZABListener) listenerClass.newInstance();
			notifier = (ZABNotifier)o;
			//TODO: revamp this producer creation
			message = ZABUtil.toBase64String(arg);
			MessageProducer<String, String> producer  = ProducerBeanManager.getProducer(notifier.getTopicName());
            producer.send(message);
            LOGGER.log(Level.SEVERE, "Message Sent:"+arg);
			
//			Thread messaging is migrated to Kafka messaging
//			listenerObject.setObj(arg);
//			new Thread(listenerObject).start();
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Exception occured while sending message to mqueue:", e);
			if(notifier!=null && message!=null) {				
				String existingDBSpace = ZABUtil.getDBSpace();
				ZABUtil.setDBSpace("sharedspace");	//No I18N
				try {
					ResQueCoordinator.addMqueueData(notifier.getModuleName(), message);
				} catch (Exception e1) {
					LOGGER.log(Level.SEVERE, "Mqueue ResQue Plan failed:", e1);
				}
				ZABUtil.setDBSpace(existingDBSpace);
			} else {
				LOGGER.log(Level.SEVERE, "Unable to call the ResQue as notifier or message is null. Exception:", e);
			}
			
			LOGGER.log(Level.SEVERE, "Exception occured: ",e);
		}
	}
}
