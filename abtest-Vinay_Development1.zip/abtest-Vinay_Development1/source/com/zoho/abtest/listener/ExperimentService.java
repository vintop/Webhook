//$Id$
package com.zoho.abtest.listener;

import com.adventnet.mfw.message.Messenger;
import com.adventnet.mfw.service.Service;
import com.adventnet.persistence.DataObject;

public class ExperimentService implements Service {

	@Override
	public void create(DataObject serviceDO) throws Exception {
System.out.println();
	}

	@Override
	public void start() throws Exception {
		
		
		ExperimentMessageListener tml = new ExperimentMessageListener();
		ExperimentMessageFilter tmf = new ExperimentMessageFilter();
		
		Messenger.subscribe("DataModelTopic", tml, true, tmf);  //No I18N
		
	}

	@Override
	public void stop() throws Exception {
		
	}

	@Override
	public void destroy() throws Exception {

	}

}
