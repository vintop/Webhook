//$Id$
package com.zoho.abtest.listener;

import java.util.HashMap;
import java.util.Observable;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ZABNotifier extends Observable {
	
	private static HashMap<String, ZABNotifier> registeredListeners=new HashMap<String, ZABNotifier>();
	
	private static HashMap<String, ZABListener> registeredObservers=new HashMap<String, ZABListener>();
	
	private static final Logger LOGGER = Logger.getLogger(ZABNotifier.class.getName());
	
	private String topicName;
	
	private String moduleName;
	
	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public String getTopicName() {
		return topicName;
	}

	public void setTopicName(String topicName) {
		this.topicName = topicName;
	}

	public static HashMap<String, ZABNotifier> getListeners() {
		return registeredListeners;
	}

	public static HashMap<String, ZABListener> getObservers() {
		return registeredObservers;
	}

	public static void setRegisteredObservers(
			HashMap<String, ZABListener> registeredObservers) {
		ZABNotifier.registeredObservers = registeredObservers;
	}

	public static void setListeners( String module,ZABNotifier notifier) {
		notifier.setModuleName(module);
		registeredListeners.put(module, notifier);
	}
	
	public static void setObservers(String module,ZABListener notifier) {
		registeredObservers.put(module, notifier);
	}

	@Override
	public void notifyObservers() {
		setChanged();
		super.notifyObservers();
	}

	@Override
	public void notifyObservers(Object obj) {
		setChanged();
		super.notifyObservers(obj);
	}
	
	public static void notifyListeners(String module,Object obj) {
		ZABNotifier zabNotifier=(ZABNotifier) registeredListeners.get(module);
		if(zabNotifier!=null) {			
			zabNotifier.notifyObservers(obj);
		} else {
			LOGGER.log(Level.SEVERE, "No listener registered for module:"+module);
		}
	}
	
	public static void notifyListeners(String module) {
		ZABNotifier zabNotifier=(ZABNotifier) registeredListeners.get(module);
		if(zabNotifier!=null) {			
			zabNotifier.notifyObservers();
		} else {
			LOGGER.log(Level.SEVERE, "No listener registered for module:"+module);
		}
	}
}
