//$Id$
package com.zoho.abtest.listener;

import com.adventnet.mfw.message.MessageListener;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.OperationInfo;
import com.zoho.abtest.experiment.ExperimentEventHandler;

public class ExperimentMessageListener implements MessageListener {

	@Override
	public void onMessage(Object msg) {
		OperationInfo oinfo = (OperationInfo)msg;
		DataObject dobj = oinfo.getDataObject();
		ExperimentEventHandler.doHandle(dobj, oinfo.getOperation());
	}

}
