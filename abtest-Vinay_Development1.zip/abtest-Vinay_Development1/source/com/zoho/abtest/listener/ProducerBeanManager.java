//$Id$
package com.zoho.abtest.listener;

import com.zoho.mqueue.producer.MessageProducer;

public class ProducerBeanManager {
	
	/**
	 * Topic name, Producer object
	 */
//	private static HashMap<String, MessageProducer<String, String>> producerList = new HashMap<String, MessageProducer<String,String>>();
	
	
	public static MessageProducer<String, String> getProducer(String topicName) throws Exception {
//		if(producerList.containsKey(topicName)) {
//			return producerList.get(topicName);
//		} else {
			MessageProducer<String, String> producer  =  MessageProducer.getInstance(topicName);
//			producerList.put(topicName, producer);
			return producer;
//		}
	}
}
