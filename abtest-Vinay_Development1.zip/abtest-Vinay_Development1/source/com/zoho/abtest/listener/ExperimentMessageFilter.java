//$Id$
package com.zoho.abtest.listener;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import com.adventnet.mfw.message.MessageFilter;
import com.adventnet.persistence.OperationInfo;
import com.zoho.abtest.AUDIENCE;
import com.zoho.abtest.ELEMENT_CLICK_GOAL;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.EXPERIMENT_AUDIENCE;
import com.zoho.abtest.EXPERIMENT_GOAL;
import com.zoho.abtest.FORM_SUBMIT_GOAL;
import com.zoho.abtest.GOAL;
import com.zoho.abtest.LINK_CLICK_GOAL;
import com.zoho.abtest.PAGE_VISIT_GOAL;
import com.zoho.abtest.PROJECT;
import com.zoho.abtest.VARIATION;

public class ExperimentMessageFilter implements MessageFilter {

	private static final List<String> FILTER_TABLES = Arrays.asList(PROJECT.TABLE,
																   EXPERIMENT.TABLE, 
																   AUDIENCE.TABLE, 
																   EXPERIMENT_AUDIENCE.TABLE, 
																   GOAL.TABLE, 
																   EXPERIMENT_GOAL.TABLE, 
																   PAGE_VISIT_GOAL.TABLE, 
																   LINK_CLICK_GOAL.TABLE, 
																   FORM_SUBMIT_GOAL.TABLE, 
																   ELEMENT_CLICK_GOAL.TABLE, 
																   VARIATION.TABLE);
	
	@Override
	public boolean matches(Object obj) {
		
		OperationInfo oi = (OperationInfo)obj;
		List<String> tables = (List<String>)oi.getTableNames();
		if(oi.getTableNames()!=null && !Collections.disjoint(tables, FILTER_TABLES)) {
			return true;
		}
		return false;
	}
}
