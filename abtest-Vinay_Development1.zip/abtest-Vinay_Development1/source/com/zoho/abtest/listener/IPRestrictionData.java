//$Id$
package com.zoho.abtest.listener;

import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.utility.ZABServiceOrgUtil;

public class IPRestrictionData {

	private Long projectId;
	
	private String dbSpace;
	
	private String ipAddress;

	public Long getProjectId() {
		return projectId;
	}

	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}

	public String getDbSpace() {
		return dbSpace;
	}

	public void setDbSpace(String dbSpace) {
		this.dbSpace = dbSpace;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	
	public IPRestrictionData(String portal, Long projectId, String ipAddress) throws ZABException {
		if(portal == null || projectId == null || ipAddress == null || ipAddress.isEmpty() || portal.isEmpty()) {
			throw new ZABException("Please provide proper values for dbSpace, projectId, ipAddress. " //NO I18N
					+ "Values provided(dbSpace, projectId, ipAddress):"+portal+", "+projectId+", ***");  //NO I18N
		}
		this.projectId = projectId;
		this.ipAddress = ipAddress;
		
		Long zsoid = ZABServiceOrgUtil.getZSOIDFromDomain(portal);
		if(zsoid != null)
		{
			this.dbSpace = zsoid.toString();
		}
		else
		{
			throw new ZABException("Invalid portal provided :"+portal); //NO I18N
		}
	}
}
