//$Id$
package com.zoho.abtest.schedule;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.zoho.scheduler.RunnableJob;

public class ArchieveVisitorrawData implements RunnableJob{
	
	private static final Logger LOGGER = Logger.getLogger(ArchieveVisitorrawData.class.getName());
	
	public void run(long l)
	{
		LOGGER.log(Level.INFO, "ArchieveVisitorrawData - Schedule Job starts running");
	}
}
