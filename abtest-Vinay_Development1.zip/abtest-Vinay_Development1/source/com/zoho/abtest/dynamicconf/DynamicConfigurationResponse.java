//$Id$
package com.zoho.abtest.dynamicconf;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;

public class DynamicConfigurationResponse 
{
	public static String jsonResponse(HttpServletRequest request,List<DynamicConfiguration> dynamicConfigurations) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(dynamicConfigurations);			
			JSONObject json = ZABResponse.updateMetaInfo(request, DynamicConfigurationConstants.API_MODULE, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){}
		return returnBuffer.toString();
	}
	
	public static JSONArray getJSONArray(List<DynamicConfiguration> dynamicConfigurations) throws JSONException {
		JSONArray array = new JSONArray();
		int size =dynamicConfigurations.size();
		for (int i=0;i<size;i++) {
			DynamicConfiguration dynamicConf = dynamicConfigurations.get(i);
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(DynamicConfigurationConstants.CONFIGURATION_ID, dynamicConf.getConfigurationId());
			jsonObj.put(DynamicConfigurationConstants.PROPERTY_NAME, dynamicConf.getPropertyName());
			jsonObj.put(DynamicConfigurationConstants.PROPERTY_VALUE, dynamicConf.getPropertyValue());
			jsonObj.put(ZABConstants.RESPONSE_STRING, dynamicConf.getResponseString());
			jsonObj.put(ZABConstants.STATUS_CODE, dynamicConf.getResponseCode());
			jsonObj.put(ZABConstants.SUCCESS, dynamicConf.getSuccess());
			array.put(jsonObj);
		}
		return array;
	}
}
