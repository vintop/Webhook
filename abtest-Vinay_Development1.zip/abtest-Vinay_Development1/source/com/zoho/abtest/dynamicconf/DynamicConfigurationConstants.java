//$Id$
package com.zoho.abtest.dynamicconf;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.zoho.abtest.DYNAMIC_CONFIGURATIONS;
import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.ZABConstants;

public class DynamicConfigurationConstants 
{
	
	public static final String API_MODULE = "dynamicconfiguration"; //No I18N
	
	public static final String CONFIGURATION_ID = "configuration_id";			// No I18N
	public static final String PROPERTY_NAME = "property_name";			// No I18N
	public static final String PROPERTY_VALUE = "property_value";			// No I18N
	
	public static final String ES_CARDINALITY_THRESHOLD = "es_cardinality_threshold";			// No I18N
	public static final Integer ES_CARDINALITY_THRESHOLD_VALUE = 40000;
	
	public static final List<Constants> DYNAMIC_CONFIGURAION_CONSTANTS;
	
	static{
		List<Constants> dynamicConfigurationConstants = new ArrayList<Constants>();
		dynamicConfigurationConstants.add(new Constants(CONFIGURATION_ID,DYNAMIC_CONFIGURATIONS.CONFIGURATION_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		dynamicConfigurationConstants.add(new Constants(PROPERTY_NAME,DYNAMIC_CONFIGURATIONS.PROPERTY_NAME,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
		dynamicConfigurationConstants.add(new Constants(PROPERTY_VALUE,DYNAMIC_CONFIGURATIONS.PROPERTY_VALUE,ZABConstants.STRING,Boolean.TRUE,Boolean.TRUE));
		DYNAMIC_CONFIGURAION_CONSTANTS = Collections.unmodifiableList(dynamicConfigurationConstants);
	}
}
