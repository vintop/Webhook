//$Id$
package com.zoho.abtest.dynamicconf;

import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.DYNAMIC_CONFIGURATIONS;
import com.zoho.abtest.common.ZABModel;

public class DynamicConfiguration extends ZABModel
{
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(DynamicConfiguration.class.getName());
	
	private Long configurationId;
	private String propertyName;
	private String propertyValue;
	
	public Long getConfigurationId() {
		return configurationId;
	}
	public void setConfigurationId(Long configurationId) {
		this.configurationId = configurationId;
	}
	public String getPropertyName() {
		return propertyName;
	}
	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}
	public String getPropertyValue() {
		return propertyValue;
	}
	public void setPropertyValue(String propertyValue) {
		this.propertyValue = propertyValue;
	}
	
	public static DynamicConfiguration createDynamicConfiguration(HashMap<String, String> hs)
	{
		DynamicConfiguration configuration = null;
		try
		{
			DataObject dataObj = ZABModel.createRow(DynamicConfigurationConstants.DYNAMIC_CONFIGURAION_CONSTANTS, DYNAMIC_CONFIGURATIONS.TABLE, hs);
			Row row = dataObj.getFirstRow(DYNAMIC_CONFIGURATIONS.TABLE);
			configuration = getDynamicConfigurationFromRow(row);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			configuration = new DynamicConfiguration();
			configuration.setSuccess(Boolean.FALSE);
		}
		return configuration;
	}
	
	public static String getPropertyValueByName(String propName)
	{
		String value = null;
		try
		{
			Criteria criteria1 = new Criteria(new Column(DYNAMIC_CONFIGURATIONS.TABLE, DYNAMIC_CONFIGURATIONS.PROPERTY_NAME), propName, QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(DYNAMIC_CONFIGURATIONS.TABLE, criteria1);
			value = (String)dataObj.getFirstValue(DYNAMIC_CONFIGURATIONS.TABLE, DYNAMIC_CONFIGURATIONS.PROPERTY_VALUE);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			value = null;
		}
		return value;
	}
	
	public static DynamicConfiguration updateDynamicConfiguration(String propName, String newValue)
	{
		DynamicConfiguration configuration = new DynamicConfiguration();
		try
		{
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(DynamicConfigurationConstants.PROPERTY_VALUE, newValue);
			Criteria criteria1 = new Criteria(new Column(DYNAMIC_CONFIGURATIONS.TABLE, DYNAMIC_CONFIGURATIONS.PROPERTY_NAME), propName, QueryConstants.EQUAL);
			boolean isUpdated = ZABModel.updateRow(DynamicConfigurationConstants.DYNAMIC_CONFIGURAION_CONSTANTS, DYNAMIC_CONFIGURATIONS.TABLE, hs, criteria1, null);
			configuration.setSuccess(isUpdated);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			configuration.setSuccess(Boolean.FALSE);
		}
		return configuration;
	}
	
	public static DynamicConfiguration getDynamicConfigurationFromRow(Row row)
	{
		DynamicConfiguration configuration = new DynamicConfiguration();
		configuration.setConfigurationId((Long)row.get(DYNAMIC_CONFIGURATIONS.CONFIGURATION_ID));
		configuration.setPropertyName((String)row.get(DYNAMIC_CONFIGURATIONS.PROPERTY_NAME));
		configuration.setPropertyValue((String)row.get(DYNAMIC_CONFIGURATIONS.PROPERTY_VALUE));
		configuration.setSuccess(Boolean.TRUE);
		return configuration;
	}
}
