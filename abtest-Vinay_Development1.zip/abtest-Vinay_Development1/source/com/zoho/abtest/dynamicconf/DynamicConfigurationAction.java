//$Id$
package com.zoho.abtest.dynamicconf;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;

import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.dimension.DimensionConstants;
import com.zoho.abtest.dimension.DynamicAttributes;
import com.zoho.abtest.utility.ZABUtil;

public class DynamicConfigurationAction extends ZABAction implements ServletResponseAware, ServletRequestAware 
{
	private static final Logger LOGGER = Logger.getLogger(DynamicConfigurationAction.class.getName());
	
	private static final long serialVersionUID = 1L;

	private HttpServletRequest request;
	
	private HttpServletResponse response;
	
	private String propertyName;
	
	public String getPropertyName() {
		return propertyName;
	}

	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}

	@Override
	public void setServletRequest(HttpServletRequest request) {
		this.request = request;
	}

	@Override
	public void setServletResponse(HttpServletResponse response) {
		this.response = response;
	}
	
	public String execute()throws IOException
	{
		List<DynamicConfiguration> dynamicConfList = new ArrayList<DynamicConfiguration>();
		HashMap<String,String> hs;
		try
		{
			ZABUtil.setCurrentRequest(request);
			String inputString = null;
			if(ZABAction.getHTTPMethod(request).equals(ZABAction.HTTPMethod.POST) || ZABAction.getHTTPMethod(request).equals(ZABAction.HTTPMethod.PUT))
			{
				inputString = ZABAction.getInputString(request);
			}
			ZABUtil.setCurrentInputString(inputString);
			switch(ZABAction.getHTTPMethod(request))
			{
			case PUT:
				
				hs = ZABAction.getRequestParser(request).parseDynamicConfiguration(request);
				if(propertyName != null)
				{
					String propertyValue = hs.get(DynamicConfigurationConstants.PROPERTY_VALUE);
					DynamicConfiguration dynamicConf = DynamicConfigurationUtil.updateDynamicConfiguration(propertyName, propertyValue);
					dynamicConfList.add(dynamicConf);
				}
				break;
			}
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getDynamicConfigurationResponse(request, dynamicConfList));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), DynamicConfigurationConstants.API_MODULE));
		}
		return null;
	}
}
