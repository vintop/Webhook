//$Id$
package com.zoho.abtest.dynamicconf;

import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.zoho.abtest.utility.ZABUtil;

public class DynamicConfigurationUtil 
{
	private static final Logger LOGGER = Logger.getLogger(DynamicConfiguration.class.getName());
	
	public static void createDefaultDynamicConfigurations()
	{
		try
		{
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(DynamicConfigurationConstants.PROPERTY_NAME, DynamicConfigurationConstants.ES_CARDINALITY_THRESHOLD);
			hs.put(DynamicConfigurationConstants.PROPERTY_VALUE, DynamicConfigurationConstants.ES_CARDINALITY_THRESHOLD_VALUE.toString());
			DynamicConfiguration.createDynamicConfiguration(hs);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
	}
	
	public static String getDynamicPropertyValueByName(String propertyName)
	{
		String value = null;
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		try
		{
			value = DynamicConfiguration.getPropertyValueByName(propertyName);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			value = null;
		}
		ZABUtil.setDBSpace(existingDBSpace);
		return value;
	}
	
	public static DynamicConfiguration updateDynamicConfiguration(String propName, String newValue) throws Exception
	{
		DynamicConfiguration configuration = null;
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		configuration = DynamicConfiguration.updateDynamicConfiguration(propName, newValue);
		ZABUtil.setDBSpace(existingDBSpace);
		return configuration;
	}
}
