//$Id$
package com.zoho.abtest.experiment;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.PROJECT;
import com.zoho.abtest.SHARED_REPORT_DETAILS;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentType;
import com.zoho.abtest.forms.FormAnalyticsExperiment;
import com.zoho.abtest.funnel.FunnelAnalysis;
import com.zoho.abtest.heatmaps.HeatmapExperiment;
import com.zoho.abtest.sessionrecording.SessionRecording;
import com.zoho.abtest.utility.ApplicationProperty;
import com.zoho.abtest.utility.ZABUtil;

public class ExperimentHandler
{
	private static final long serialVersionUID = 1L;

	private static final Logger LOGGER = Logger.getLogger(ExperimentHandler.class.getName());
	
	public static Experiment handleExperimentCreation(HashMap<String,String> hs) throws Exception
	{
		Experiment experiment = null;
		Integer experimentTypeNo = Integer.parseInt(hs.get(ExperimentConstants.EXPERIMENT_TYPE));
		ExperimentType experimentType = ExperimentType.getExperimentTypeByNumber(experimentTypeNo);
		switch(experimentType)
		{
		case ABTEST:
		case SPLITURL:
			experiment = ABSplitExperiment.createABSplitExperiment(hs);
			break;
		case FORMANALYTICS:
			experiment= FormAnalyticsExperiment.createFormAnalyticsExperiment(hs);
			break;
		case FUNNEL:
			experiment = FunnelAnalysis.createFunnelAnalysis(hs);
			break;
		case HEATMAP:
			experiment = HeatmapExperiment.createHeatmapExperiment(hs);
			break;
		case ENABLED_HEATMAP:
			experiment = HeatmapExperiment.createHeatmapExperiment(hs);
			break;
		case SESSION_RECORDING:
			experiment = SessionRecording.createSessionRecording(hs);
			break;
		default:
			break;
		}
		return experiment;
	}
	
	public static ArrayList<Experiment> handleExperimentFetch(String linkName) throws Exception
	{
		ArrayList<Experiment> experiments = new ArrayList<Experiment>();
		if(StringUtils.isEmpty(linkName))
		{
			experiments.addAll(Experiment.getExperimentsWithDetails());
		}
		else
		{
			Experiment result = null ;
			
			Integer experimentTypeNo = Experiment.getExperimentTypeByLinkname(linkName);
			ExperimentType experimentType = ExperimentType.getExperimentTypeByNumber(experimentTypeNo);
			switch(experimentType)
			{
			case ABTEST:
			case SPLITURL:
				result = ABSplitExperiment.getABSplitExperimentDetailsByLinkname(linkName);
				break;
			case HEATMAP:
				result = HeatmapExperiment.getHeatmapExperimentDetailsFromLinkname(linkName);
				break;
			case FORMANALYTICS:
				result = FormAnalyticsExperiment.getFormAnalyticsExperimentByLinkName(linkName);
				break;
			case FUNNEL:
				result = FunnelAnalysis.getFunnelAnalysisWithSteps(linkName);
				break;
			case SESSION_RECORDING:
				result = SessionRecording.getSessionRecordingWithLinkname(linkName);
				break;
			default:
				break;
			}
			result = Experiment.getShareUrlOfExperiment(result);
			experiments.add(result);
			
		}
		return experiments;
	}
	
	public static Experiment handleExperimentMetaFetch(String linkName,Integer experimentTypeNo) throws Exception
	{
		Experiment experiment = null;
		ExperimentType experimentType = ExperimentType.getExperimentTypeByNumber(experimentTypeNo);
		switch(experimentType)
		{
		case ABTEST:
		case SPLITURL:
			experiment = ABSplitExperiment.getABSplitExperimentMeta(linkName);
			break;
		case HEATMAP:
			experiment = HeatmapExperiment.getHeatmapExperimentDetailsFromLinkname(linkName);
			break;
		case FUNNEL:
			experiment = FunnelAnalysis.getFunnelAnalysisMeta(linkName);
			break;
		case SESSION_RECORDING:
			experiment = SessionRecording.getSessionRecordingMeta(linkName);
			break;
		case FORMANALYTICS:
			experiment = FormAnalyticsExperiment.getExperimentMetaData(linkName);
			break;
		default:
			break;
		}
		return experiment;
	}
	
	public static ArrayList<Experiment> handleExperimentMetaFetch(Integer experimentTypeNo, String projectLinkName) throws Exception
	{
		ArrayList<Experiment> experiments = new ArrayList<Experiment>(); 
		ExperimentType experimentType = ExperimentType.getExperimentTypeByNumber(experimentTypeNo);
		
		Criteria c1 = new Criteria(new Column(PROJECT.TABLE, PROJECT.PROJECT_LINK_NAME), projectLinkName, QueryConstants.EQUAL);
		Criteria c2 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_TYPE), experimentTypeNo, QueryConstants.EQUAL);
		Join join1 = new Join(EXPERIMENT.TABLE, PROJECT.TABLE, new String[]{EXPERIMENT.PROJECT_ID}, new String[]{PROJECT.PROJECT_ID}, Join.INNER_JOIN);
		DataObject dataObj = ZABModel.getRow(EXPERIMENT.TABLE, c1.and(c2), join1);
		if(dataObj.containsTable(EXPERIMENT.TABLE))
		{
			Iterator<?> iter = dataObj.getRows(EXPERIMENT.TABLE);
			while(iter.hasNext())
			{
				Row row = (Row)iter.next();
				String expLinkName = (String)row.get(EXPERIMENT.EXPERIMENT_LINK_NAME);
				
				//Fetch exp meta details
				Experiment experiment = null;
				switch(experimentType)
				{
				case ABTEST:
				case SPLITURL:
					experiment = ABSplitExperiment.getABSplitExperimentMeta(expLinkName);
					break;
				case HEATMAP:
					experiment = HeatmapExperiment.getHeatmapExperimentDetailsFromLinkname(expLinkName);
					break;
				case FUNNEL:
					experiment = FunnelAnalysis.getFunnelAnalysisMeta(expLinkName);
					break;
				case SESSION_RECORDING:
					experiment = SessionRecording.getSessionRecordingMeta(expLinkName);
					break;
				case FORMANALYTICS:
					experiment = FormAnalyticsExperiment.getExperimentMetaData(expLinkName);
					break;
				default:
					break;
				}
				if(experiment != null)
				{
					experiments.add(experiment);
				}
			}
		}
		return experiments;
	}
	
	public static ArrayList<Experiment> handleExperimentDeletion(String linkName) throws Exception
	{
		ArrayList<Experiment> experiments = new ArrayList<Experiment>();
		if(!StringUtils.isEmpty(linkName)) {					
			experiments.add(Experiment.deleteExperiment(linkName));
		}
		return experiments;
	}
	
	public static Experiment handleExperimentUpdation(HashMap<String,String> hs) throws Exception
	{
		Experiment experiment = null;
		
		//TEMP START - If Exp type comes from client then it's not needed to fetch here - check it
		String linkName = hs.get(ExperimentConstants.EXPERIMENT_LINKNAME);
		Integer experimentTypeNo = Experiment.getExperimentTypeByLinkname(linkName);
		//TEMP END
		
		//Integer experimentTypeNo = Integer.parseInt(hs.get(ExperimentConstants.EXPERIMENT_TYPE));
		ExperimentType experimentType = ExperimentType.getExperimentTypeByNumber(experimentTypeNo);
		switch(experimentType)
		{
		case ABTEST:
		case SPLITURL:
			experiment = ABSplitExperiment.updateABSplitExperiment(hs);
			break;
		case FORMANALYTICS:
			experiment = FormAnalyticsExperiment.updateFormAnalyticsExperiment(hs);
			break;
		case FUNNEL:
			experiment = FunnelAnalysis.updateFunnelAnalysis(hs);
			break;
		case HEATMAP:
			experiment = HeatmapExperiment.updateHeatmapExperiment(hs);
			break;
		case SESSION_RECORDING:
			experiment = SessionRecording.updateSessionRecording(hs);
			break;
		default:
			break;
		}
		return experiment;
	}
	
	public static Experiment handleExperimentDuplication(String linkName) throws Exception
	{
		Experiment experiment = null;
		Integer experimentTypeNo = Experiment.getExperimentTypeByLinkname(linkName);
		ExperimentType experimentType = ExperimentType.getExperimentTypeByNumber(experimentTypeNo);
		switch(experimentType)
		{
		case ABTEST:
		case SPLITURL:
			experiment = ABSplitExperiment.duplicateABSplitExperiment(linkName);
			break;
		case HEATMAP:
			experiment = HeatmapExperiment.duplicateHeatmapExperiment(linkName);
			break;
		case FUNNEL:
			experiment = FunnelAnalysis.duplicateExperiment(linkName);
			break;
		case SESSION_RECORDING:
			experiment = SessionRecording.duplicateSessionRecording(linkName);
			break;
		case FORMANALYTICS:
			experiment = FormAnalyticsExperiment.duplicateFormAnalyticsExperiment(linkName);
			break;
		default:
			break;
		}
		return experiment;
	}
}
