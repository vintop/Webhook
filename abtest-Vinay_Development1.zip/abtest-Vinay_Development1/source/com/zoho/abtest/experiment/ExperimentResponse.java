//$Id$
package com.zoho.abtest.experiment;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;
import com.zoho.abtest.forms.Form;
import com.zoho.abtest.forms.FormAnalyticsExperiment;
import com.zoho.abtest.forms.FormConstants;
import com.zoho.abtest.forms.FormReportConstants;
import com.zoho.abtest.funnel.FunnelAnalysis;
import com.zoho.abtest.funnel.FunnelAnalysisConstants;
import com.zoho.abtest.funnel.FunnelStepResponse;
import com.zoho.abtest.heatmaps.HeatmapConstants;
import com.zoho.abtest.heatmaps.HeatmapExperiment;
import com.zoho.abtest.sessionrecording.SessionRecording;
import com.zoho.abtest.sessionrecording.SessionRecordingConstants;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.abtest.variation.VariationResponse;

import java.util.logging.Logger;

public class ExperimentResponse {
	
	private static final Logger LOGGER = Logger.getLogger(ExperimentResponse.class.getName());
	
	public static String jsonResponse(HttpServletRequest request,ArrayList<Experiment> lst) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(lst);			
			JSONObject json = ZABResponse.updateMetaInfo(request, ExperimentConstants.API_MODULE_PLURAL, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){
			
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
			
		}
		return returnBuffer.toString();
	}
	
	public static JSONArray getJSONArray(ArrayList<Experiment> lst) throws JSONException {
		JSONArray array = new JSONArray();
		int size =lst.size();
		for (int i=0;i<size;i++) {
			Experiment ld=lst.get(i);
			JSONObject jsonObj = new JSONObject();
			jsonObj = getSingleExperimentResponse(ld);
			
			array.put(jsonObj);
		}
		return array;
	}
	public static JSONObject getSingleExperimentResponse(Experiment ld)  throws JSONException {
		JSONObject jsonObj = new JSONObject();
		jsonObj.put(ExperimentConstants.EXPERIMENT_ID, ld.getExperimentId());
		jsonObj.put(ExperimentConstants.EXPERIMENT_NAME, ld.getExperimentName());
		jsonObj.put(ExperimentConstants.EXPERIMENT_KEY, ld.getExperimentKey());
		jsonObj.put(ExperimentConstants.EXPERIMENT_TYPE, ld.getExperimentType());
		jsonObj.put(ExperimentConstants.EXPERIMENT_LINKNAME, ld.getExperimentLinkname());
		jsonObj.put(ExperimentConstants.EXPERIMENT_STATUS, ld.getExperimentStatus());
		jsonObj.put(ExperimentConstants.EXPERIMENT_SMALL_THUMBNAIL_URL, ld.getSmallThumbnailUrl());
		jsonObj.put(ExperimentConstants.EXPERIMENT_LARGE_THUMBNAIL_URL, ld.getLargeThumbnailUrl());
		jsonObj.put(ExperimentConstants.ACTIVE_DURATION, ld.getActiveDuration());
		jsonObj.put(ExperimentConstants.IS_ACTIVE, ld.getIsActive());
		jsonObj.put(ExperimentConstants.MAKE_PUBLIC, ld.getMakePublic());
		jsonObj.put(ExperimentConstants.SHARE_URL, ld.getShareUrl());
		jsonObj.put(ExperimentConstants.PROJECT_ID, ld.getProjectId());
		jsonObj.put(ExperimentConstants.ACTIVATION_MODE, ld.getActivationMode());
		jsonObj.put(ExperimentConstants.ACTIVATON_CONDITION, ld.getActivationCondition());
		jsonObj.put(ExperimentConstants.PROJECT_LINKNAME, ld.getProjectLinkname());
		jsonObj.put(ZABConstants.STATUS_CODE, ld.getResponseCode());
		jsonObj.put(ZABConstants.SUCCESS, ld.getSuccess());
		jsonObj.put(ZABConstants.RESPONSE_STRING, ld.getResponseString());
		jsonObj.put(ExperimentConstants.CREATED_BY, ld.getCreatedByName());
		
		if(ld.getStartDate() != null)
		{
			jsonObj.put(ExperimentConstants.START_DATE, ZABUtil.getDateTimeFormatted(ld.getStartDate(), ExperimentConstants.DATE_FORMAT));
		}
		else
		{
			jsonObj.put(ExperimentConstants.START_DATE, "");
		}
		
		if(ld.getEndDate() != null)
		{
			jsonObj.put(ExperimentConstants.END_DATE, ZABUtil.getDateTimeFormatted(ld.getEndDate(), ExperimentConstants.DATE_FORMAT));
		}
		else
		{
			jsonObj.put(ExperimentConstants.END_DATE, "");
		}
		
		if(ld.getActualStartTime() != null)
		{
			jsonObj.put(ExperimentConstants.ACTUAL_START_TIME, ZABUtil.getDateTimeFormatted(ld.getActualStartTime()));
		}
		if(ld.getActualEndTime() != null)
		{
			jsonObj.put(ExperimentConstants.ACTUAL_END_TIME, ZABUtil.getDateTimeFormatted(ld.getActualEndTime()));
		}
		
		if(ld.getCreatedTime() != null)
		{
			HashMap<String, String> formattedTimes = ZABUtil.getDateTimeAllFormatted(ld.getCreatedTime());
			String formattedTime = formattedTimes.get(ZABConstants.DATETIME);
			String formattedTimeOnly = formattedTimes.get(ZABConstants.TIME);
			String formattedDateOnly = formattedTimes.get(ZABConstants.DATE);
			jsonObj.put(ExperimentConstants.CREATED_TIME, formattedTimeOnly);
			jsonObj.put(ExperimentConstants.CREATED_DATE, formattedDateOnly);
			jsonObj.put(ExperimentConstants.CREATED_DATETIME, formattedTime);
		}
		
		if(ld.getModifiedTime()!=null) 
		{
			HashMap<String, String> formattedModTimes = ZABUtil.getDateTimeAllFormatted(ld.getModifiedTime());
			String formattedModTime = formattedModTimes.get(ZABConstants.DATETIME);
			String formattedModTimeOnly = formattedModTimes.get(ZABConstants.TIME);
			String formattedModDateOnly = formattedModTimes.get(ZABConstants.DATE);
			jsonObj.put(ExperimentConstants.MODIFIED_TIME, formattedModTimeOnly);
			jsonObj.put(ExperimentConstants.MODIFIED_DATE, formattedModDateOnly);
			jsonObj.put(ExperimentConstants.MODIFIED_DATETIME, formattedModTime);
		}
		
		//For ABSplitExperiment Details
		if(ld instanceof ABSplitExperiment)
		{
			ABSplitExperiment ld1 = (ABSplitExperiment)ld;
			jsonObj.put(ExperimentConstants.EXPERIMENT_URL, ld1.getExperimentUrl());
			jsonObj.put(ExperimentConstants.PRIMARY_GOAL, ld1.getPrimaryGoal());
			jsonObj.put(ExperimentConstants.PERMITTED_TRAFFIC, ld1.getPermittedTraffic());
			jsonObj.put(ExperimentConstants.EXCLUDE_URLS, getObjectFromString(ld1.getExcludeUrls()));
			jsonObj.put(ExperimentConstants.INCLUDE_URLS, getObjectFromString(ld1.getIncludeUrls()));
			jsonObj.put(ExperimentConstants.STATISTICAL_SIGNIFICANCE, ld1.getStatisticalSignificance());
			jsonObj.put(ExperimentConstants.EXPECTED_IMPROVEMENT, ld1.getExpectedImprovement());
			jsonObj.put(ExperimentConstants.CONVERSION_RATE, ld1.getConversionRate());
			jsonObj.put(ExperimentConstants.DAILY_VISITORS, ld1.getDailyVisitors());
			jsonObj.put(ExperimentConstants.VARIATION_COUNT, ld1.getVariationCount());
			jsonObj.put(ExperimentConstants.GOAL_COUNT, ld1.getGoalsCount());
			jsonObj.put(ExperimentConstants.VISITOR_COUNT, ld1.getVisitorCount());
			jsonObj.put(ExperimentConstants.IS_WINNER_DECLARED, ld1.getIsWinnerDeclared());
			jsonObj.put(ExperimentConstants.IS_HEATMAP_ENABLED, ld1.getIsHeatmapEnabled());
			jsonObj.put(ExperimentConstants.IS_HEATMAP_ACTIVATED, ld1.getIsHeatmapActive());
			jsonObj.put(ExperimentConstants.HEATMAP_MAX_VISITORS, ld1.getMaxHeatmapVisitorsCount());
			jsonObj.put(ExperimentConstants.REDIRECT_PARAMS, ld1.getRedirectParams());
			jsonObj.put(ExperimentConstants.GLOBAL_CSS, ld1.getGlobalCss());
			jsonObj.put(ExperimentConstants.GLOBAL_JS, ld1.getGlobalJs());
			
			jsonObj.put(ExperimentConstants.WINNING_VARIATION, ld1.getWinningVariation());
            
			if(ld1.getVariations()!=null && ld1.getVariations().size() > 0) {				
				jsonObj.put(ExperimentConstants.VARIATION, VariationResponse.getJSONArray(ld1.getVariations()));
			}
		}
		
		//For FormAnalytics Experiment
		if(ld instanceof FormAnalyticsExperiment)
		{
			FormAnalyticsExperiment ld1 = (FormAnalyticsExperiment)ld;
			if(ld1.getForm().size()>0){
				JSONObject json = Form.getJsonObject(ld1.getForm().get(0)); 
				if(json.has(FormConstants.INCLUDE_URLS)) {
					jsonObj.put(FormConstants.INCLUDE_URLS, getObjectFromString(json.get(FormConstants.INCLUDE_URLS).toString()));
				}
				if(json.has(FormConstants.EXCLUDE_URLS)) {
					jsonObj.put(FormConstants.EXCLUDE_URLS, getObjectFromString(json.get(FormConstants.EXCLUDE_URLS).toString()));
				}
				json.remove(FormConstants.INCLUDE_URLS);
				json.remove(FormConstants.EXCLUDE_URLS);
				jsonObj.put(ExperimentConstants.FORM_DETAILS, json);
			}
			jsonObj.put(FormReportConstants.FORM_VISITOR_COUNT, ld1.getVisitsCount());
			jsonObj.put(FormReportConstants.FORM_STARTER_COUNT,ld1.getStartersCount());
			jsonObj.put(FormReportConstants.FORM_CONVERSION_RATE, ld1.getConversionRate());
		}
		
		if(ld instanceof HeatmapExperiment)
		{
			HeatmapExperiment ld1 = (HeatmapExperiment)ld;
			jsonObj.put(ExperimentConstants.EXPERIMENT_URL, ld1.getExperimentUrl());
			jsonObj.put(ExperimentConstants.VISITOR_COUNT.toLowerCase(), ld1.getVisitorCount());
			jsonObj.put(HeatmapConstants.VISITS_COUNT.toLowerCase(), ld1.getVisitsCount());
			jsonObj.put(HeatmapConstants.TOTAL_CLICKS.toLowerCase(), ld1.getTotalClicks());
			jsonObj.put(HeatmapConstants.CLICKS_PER_VISIT.toLowerCase(), ld1.getClicksPerVisit());
			jsonObj.put(ExperimentConstants.EXCLUDE_URLS, getObjectFromString(ld1.getExcludedUrls()));
			jsonObj.put(ExperimentConstants.INCLUDE_URLS, getObjectFromString(ld1.getIncludedUrls()));
		}
		
		if(ld instanceof FunnelAnalysis)
		{
			FunnelAnalysis ld1 = (FunnelAnalysis)ld;
			jsonObj.put(FunnelAnalysisConstants.SESSION_TIME, ld1.getSessionTime());
			jsonObj.put(ExperimentConstants.VISITOR_COUNT, ld1.getVisitorCount());
			if(ld1.getSteps().size() > 0) {				
				jsonObj.put(FunnelAnalysisConstants.STEPS, FunnelStepResponse.getJSONArray(ld1.getSteps()));
			}
			jsonObj.put(FunnelAnalysisConstants.STEP_COUNT, ld1.getStepCount());
			if(ld1.getConversionRate()!=null) {				
				DecimalFormat f = new DecimalFormat("##.#");
				jsonObj.put(FunnelAnalysisConstants.FUNNEL_CONVERSION_RATE, f.format(ld1.getConversionRate()));
			}
		}
		
		if(ld instanceof SessionRecording)
		{
			SessionRecording ld1 = (SessionRecording)ld;
			jsonObj.put(SessionRecordingConstants.MASKED_ELEM_SELECTORS, ld1.getMaskedElementSelectors());
			jsonObj.put(ExperimentConstants.TOTAL_RECORDINGS, ld1.getTotalSessionsCount());
			jsonObj.put(SessionRecordingConstants.MAX_RECORDING_COUNT, ld1.getMaxRecordingCount());	
			
			JSONArray exclude = getObjectFromString(ld1.getExcludeUrl());
			
			if(exclude.length() > 0) {				
				jsonObj.put(ExperimentConstants.EXCLUDE_URLS, getObjectFromString(ld1.getExcludeUrl()));
			}
			
			JSONArray include = getObjectFromString(ld1.getIncludeUrl());
			
			if(include.length() > 0) {				
				jsonObj.put(ExperimentConstants.INCLUDE_URLS, getObjectFromString(ld1.getIncludeUrl()));
			}
		}
		
		return jsonObj;
	}

	public static JSONArray getObjectFromString(String urls) {
		
		JSONArray arr = new JSONArray();
		try {
			
				if(urls == null || urls.isEmpty()){
					return new JSONArray();
				}
			
				arr = new JSONArray(urls);
				
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			arr = new JSONArray();
			e.printStackTrace();
		}
		return arr;
	}
}
