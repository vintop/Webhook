//$Id$
package com.zoho.abtest.experiment;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;

import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABRequest;
import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentStatus;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentType;
import com.zoho.abtest.sessionrecording.SessionRecordingConstants;
import com.zoho.abtest.utility.ZABUtil;

public class ExperimentRequest extends ZABRequest{

	@Override
	public void updateFromRequest(HashMap<String, String> map,
			HttpServletRequest request) {
		String linkName = (String)request.getAttribute(ZABConstants.LINKNAME);
		if(linkName!=null) {			
			map.put(ZABConstants.LINKNAME, linkName);
		}

	}

	@Override
	public void specificValidation(HashMap<String, String> map,
			HttpServletRequest request) throws IOException, JSONException {

		String httpMethod = ZABAction.getHTTPMethod(request).toString();
		//Validate url
		if(httpMethod.equalsIgnoreCase("GET")){
			String isActive = request.getParameter(ExperimentConstants.IS_ACTIVE);
			if(isActive!=null) {
				try {
					Boolean.parseBoolean(isActive);
				} catch (Exception e) {
					ZABRequest.updateError(map, ZABAction.getAppropriateMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(),new ArrayList<String>(Arrays.asList(ExperimentConstants.IS_ACTIVE))));
					return;
				}
			}
		}

		if(httpMethod.equalsIgnoreCase("POST")){
			ArrayList<String> fields = new ArrayList<String>();
			if(isNullOrEmpty(map, ExperimentConstants.EXPERIMENT_NAME)){
				fields.add(ExperimentConstants.EXPERIMENT_NAME);
			}
			
			if(isNullOrEmpty(map, ExperimentConstants.EXPERIMENT_TYPE)){
				fields.add(ExperimentConstants.EXPERIMENT_TYPE);
			}
			
			if(isNullOrEmpty(map, ExperimentConstants.PROJECT_LINKNAME)){
				fields.add(ExperimentConstants.PROJECT_LINKNAME);
			}

			if(!fields.isEmpty()) {
				ZABRequest.updateError(map, ZABAction.getAppropriateMessage(ZABConstants.ErrorMessages.MANDATORY_FIELD_MISSING.getErrorString(),fields));
			}

			if(map.containsKey(ExperimentConstants.EXPERIMENT_TYPE)) {
				String experimentType = map.get(ExperimentConstants.EXPERIMENT_TYPE);
				try {
					Integer experimentTypeNum = Integer.parseInt(experimentType);
					ExperimentType type = ExperimentType.getExperimentTypeByNumber(experimentTypeNum);
					if(type==null) {
						ZABRequest.updateError(map, ZABAction.getMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{ExperimentConstants.EXPERIMENT_TYPE}));
						return;
					} else {
						//Experiment type specific validations here
						switch (type) {
							case ABTEST:
							case SPLITURL:
								if(isNullOrEmpty(map, ExperimentConstants.EXPERIMENT_URL)){
									fields.add(ExperimentConstants.EXPERIMENT_URL);
								}
							break;
							case SESSION_RECORDING:
								if(isNullOrEmpty(map, SessionRecordingConstants.EXPERIMENT_URL)){
									fields.add(SessionRecordingConstants.EXPERIMENT_URL);
								}
								
								if(isNullOrEmpty(map, SessionRecordingConstants.MATCH_TYPE)){
									fields.add(SessionRecordingConstants.MATCH_TYPE);
								} else {
									try {
										Integer matchType = Integer.parseInt(map.get(SessionRecordingConstants.MATCH_TYPE));
										if(SessionRecordingConstants.MatchTypes.getMatchTypeByNumber(matchType) == null) {
											throw new ZABException("Invalid match type"); //NO I18N
										}
									} catch (NumberFormatException|ZABException e) {
										ZABRequest.updateError(map, ZABAction.getMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{SessionRecordingConstants.MATCH_TYPE}));
									}
								}
							break;
							default:
							break;
						}
					}
				} catch (NumberFormatException e) {
					ZABRequest.updateError(map, ZABAction.getMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{ExperimentConstants.EXPERIMENT_TYPE}));
					return;
				}
			}

		}

		if(httpMethod.equalsIgnoreCase("PUT")){
			ArrayList<String> fields = new ArrayList<String>();
			if(!map.containsKey(ExperimentConstants.EXPERIMENT_LINKNAME)) {

				fields.add(ExperimentConstants.EXPERIMENT_LINKNAME);
				ZABRequest.updateError(map, ZABAction.getAppropriateMessage(ZABConstants.ErrorMessages.MANDATORY_FIELD_MISSING.getErrorString(),fields));
				return;

			}

			if(map.containsKey(ExperimentConstants.EXPERIMENT_TYPE)) {
				ZABRequest.updateError(map, ZABAction.getMessage(ExperimentConstants.EXPERIMENT_TYPE_MODIFICATION_ERROR));
			}

		}

		if(httpMethod.equalsIgnoreCase("POST") || httpMethod.equalsIgnoreCase("PUT")) {
			if(map.containsKey(ExperimentConstants.EXPERIMENT_URL)) {
				String url = map.get(ExperimentConstants.EXPERIMENT_URL);
				if(!ZABUtil.validateUrl(url)) {
					ZABRequest.updateError(map, ZABAction.getMessage(ZABConstants.INVALID_URL_MESSAGE));
					return;
				}
			}

			if(map.containsKey(ExperimentConstants.EXPERIMENT_NAME) && map.get(ExperimentConstants.EXPERIMENT_NAME).isEmpty()) {
				ZABRequest.updateError(map, ZABAction.getAppropriateMessage(ZABConstants.ErrorMessages.MANDATORY_FIELD_MISSING.getErrorString(), new ArrayList<String>(Arrays.asList(ExperimentConstants.EXPERIMENT_NAME))));
				return;
			}

			if(map.containsKey(ExperimentConstants.EXPERIMENT_STATUS)) {
				String experimentType = map.get(ExperimentConstants.EXPERIMENT_STATUS);
				try {
					Integer experimentTypeNum = Integer.parseInt(experimentType);
					if(ExperimentStatus.getStatusByNumber(experimentTypeNum)==null) {
						ZABRequest.updateError(map, ZABAction.getMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{ExperimentConstants.EXPERIMENT_STATUS}));
						return;
					}
				} catch (NumberFormatException e) {
					ZABRequest.updateError(map, ZABAction.getMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{ExperimentConstants.EXPERIMENT_STATUS}));
					return;
				}
			}
			Long startTime = null;
			if(map.containsKey(ExperimentConstants.START_DATE)) {
				try {
					if(map.get(ExperimentConstants.START_DATE).isEmpty()) {
						map.put(ExperimentConstants.START_DATE, null);
					} else {							
						startTime = ZABUtil.getTimeInLongFromDateFormStr(map.get(ExperimentConstants.START_DATE), ExperimentConstants.DATE_FORMAT);
						map.put(ExperimentConstants.START_DATE, startTime.toString());
					}
				} catch (ParseException e) {
					String fiedLabel = ZABAction.getMessage(ExperimentConstants.START_DATE);
					ZABRequest.updateError(map, ZABAction.getMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{fiedLabel}));
					return;
				}
			}
			Long endTime = null;
			if(map.containsKey(ExperimentConstants.END_DATE)) {
				try {
					if(map.get(ExperimentConstants.END_DATE).isEmpty()) {
						map.put(ExperimentConstants.END_DATE, null);
					} else {							
						endTime = ZABUtil.getTimeInLongFromDateFormStr(map.get(ExperimentConstants.END_DATE), ExperimentConstants.DATE_FORMAT);
						map.put(ExperimentConstants.END_DATE, endTime.toString());
					}
				} catch (ParseException e) {
					String fiedLabel = ZABAction.getMessage(ExperimentConstants.END_DATE);
					ZABRequest.updateError(map, ZABAction.getMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{fiedLabel}));
					return;
				}
			}

			if(startTime!=null)
			{
				//start time less than current time
				if(startTime < ZABUtil.getCurrentTimeInMilliSeconds())
				{
					String fiedLabel = ZABAction.getMessage(ExperimentConstants.START_DATE);
					ZABRequest.updateError(map, ZABAction.getMessage(ExperimentConstants.EXPERIMENT_SCHEDULE_VALIDATION_ERROR, new String[]{fiedLabel}));
				}
			}
			if(endTime!=null)
			{
				//end time less than current time
				if(endTime < ZABUtil.getCurrentTimeInMilliSeconds())
				{
					String fiedLabel = ZABAction.getMessage(ExperimentConstants.END_DATE);
					ZABRequest.updateError(map, ZABAction.getMessage(ExperimentConstants.EXPERIMENT_SCHEDULE_VALIDATION_ERROR, new String[]{fiedLabel}));
				}
			}
			if(startTime!=null && endTime!=null && startTime > endTime) {
				String fiedLabel = ZABAction.getMessage(ExperimentConstants.START_DATE);
				String fiedLabel1 = ZABAction.getMessage(ExperimentConstants.END_DATE);
				ZABRequest.updateError(map,  ZABAction.getMessage(ExperimentConstants.STARTDATE_LESS_ENDDATE_ERROR, new String[]{fiedLabel,fiedLabel1})); 
			}
		}
	}
}
