//$Id$
package com.zoho.abtest.experiment;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.json.JSONException;

import com.opensymphony.xwork2.ActionSupport;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.goal.ExperimentGoal;
import com.zoho.abtest.utility.ZABUtil;

public class ExperimentAction extends ActionSupport implements ServletResponseAware, ServletRequestAware{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = Logger.getLogger(ExperimentAction.class.getName());

	private HttpServletRequest request;
	
	private HttpServletResponse response;
	
	private String linkname;
	
	private String goalLinkname;
	
	public String getLinkname() {
		return linkname;
	}

	public void setLinkname(String linkname) {
		this.linkname = linkname;
	}

	public String getGoalLinkname() {
		return goalLinkname;
	}

	public void setGoalLinkname(String goalLinkname) {
		this.goalLinkname = goalLinkname;
	}

	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		request = arg0;
	}

	@Override
	public void setServletResponse(HttpServletResponse arg0) {
		response = arg0;
	}
	
	public String execute() throws IOException, JSONException {
		
		
		ArrayList<Experiment> experiments = new ArrayList<Experiment>();
		try {			
			switch(ZABAction.getHTTPMethod(request)) {
			case POST:	
				HashMap<String,String> hs = ZABAction.getRequestParser(request).parseExperiment(request);
				if(hs.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					Experiment experiment = new Experiment();
					experiment.setSuccess(Boolean.FALSE);
					experiment.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
					experiments.add(experiment);
				}else{
					experiments.add(ExperimentHandler.handleExperimentCreation(hs));
				}
				break;
			case GET:
				experiments.addAll(ExperimentHandler.handleExperimentFetch(linkname));
				break;
			case DELETE:
				experiments.addAll(ExperimentHandler.handleExperimentDeletion(linkname));
				break;
			case PUT:
				HashMap<String,String> hsPut = ZABAction.getRequestParser(request).parseExperiment(request);
				if(hsPut.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hsPut.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					Experiment experiment = new Experiment();
					experiment.setSuccess(Boolean.FALSE);
					experiment.setResponseString(hsPut.get(ZABConstants.RESPONSE_STRING));
					experiments.add(experiment);
				}else{
					experiments.add(ExperimentHandler.handleExperimentUpdation(hsPut));
				}
				break;
			}
		}catch(JSONException ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getInvalidInputFormatException(ExperimentConstants.API_MODULE_PLURAL));
			return null; 	
		}
		catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ExperimentConstants.API_MODULE_PLURAL));
			return null; 	
		}		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExperimentResponse(request, experiments));		
	    return null;
	}

	public String duplicateExperiment() throws IOException, JSONException {
		ArrayList<Experiment> experiments = new ArrayList<Experiment>();
		try {			
			switch(ZABAction.getHTTPMethod(request)) {
				case POST:
					experiments.add(ExperimentHandler.handleExperimentDuplication(linkname));
					break;
			}
		}
		catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ExperimentConstants.API_MODULE_PLURAL));
			return null; 	
		}	
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExperimentResponse(request, experiments));
		return null;
	}
	
	public String fetchExperimentMeta() throws IOException, JSONException {
		ArrayList<Experiment> experiments = new ArrayList<Experiment>();
		try {			
			switch(ZABAction.getHTTPMethod(request)) {
				case GET:
					Integer expTypeNo = Integer.parseInt(request.getParameter(ExperimentConstants.EXPERIMENT_TYPE));
					experiments.add(ExperimentHandler.handleExperimentMetaFetch(linkname, expTypeNo));
					break;
			}
		}
		catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ExperimentConstants.API_MODULE_PLURAL));
			return null; 	
		}	
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExperimentResponse(request, experiments));
		return null;
	}
	
	public String fetchExperimentsMeta() throws IOException, JSONException 
	{
		ArrayList<Experiment> experiments = new ArrayList<Experiment>();
		try 
		{
			Integer expTypeNo = Integer.parseInt(request.getParameter(ExperimentConstants.EXPERIMENT_TYPE));
			String projectLinkName = request.getParameter(ExperimentConstants.PROJECT_LINKNAME);
			experiments = ExperimentHandler.handleExperimentMetaFetch(expTypeNo, projectLinkName);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ExperimentConstants.API_MODULE_PLURAL));
			return null; 	
		}
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExperimentResponse(request, experiments));
		return null;
	}
	
	public String deleteExperimentGoal() throws IOException, JSONException {
		ArrayList<Experiment> experiments = new ArrayList<Experiment>();
		try {			
			switch(ZABAction.getHTTPMethod(request)) {
				case DELETE:
					try {
						ExperimentGoal egoal = ExperimentGoal.removeExperimentGoal(getLinkname(), getGoalLinkname());
						if(egoal.getSuccess()) {
							Experiment experiment = new Experiment();
							experiment.setExperimentLinkname(getLinkname());
							experiment.setSuccess(Boolean.TRUE);
							experiments.add(experiment);
						} else {
							Experiment experiment = new Experiment();
							experiment.setExperimentLinkname(getLinkname());
							experiment.setSuccess(Boolean.FALSE);
							experiment.setResponseString(egoal.getResponseString());
							experiments.add(experiment);
						}
						break;
						
					} catch (ZABException e) {
						Experiment experiment = new Experiment();
						experiment.setExperimentLinkname(getLinkname());
						experiment.setSuccess(Boolean.FALSE);
						experiment.setResponseString(e.getMessage());
						experiments.add(experiment);
					}
			}
		}catch(JSONException ex){	
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getInvalidInputFormatException(ExperimentConstants.API_MODULE_PLURAL));
			return null; 	
		}
		catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ExperimentConstants.API_MODULE_PLURAL));
			return null; 	
		}	
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExperimentResponse(request, experiments));
		return null;
	}
	
	public String getAllExperiments() throws Exception {
		ArrayList<Experiment> experiments = new ArrayList<Experiment>();
		try {			
			switch(ZABAction.getHTTPMethod(request)) {
			case POST:	
				break;
			case GET:
				//String url = request.getParameter(ExperimentConstants.EXPERIMENT_URL);
				//TODO commented for Url implementation
				experiments.addAll(Experiment.getAllExperimentsByCurrentUser(null, null));
				break;
			case DELETE:
				break;
			case PUT:
				break;
			}
		}
		catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ExperimentConstants.API_MODULE_PLURAL));
			return null; 	
		}		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExperimentResponse(request, experiments));		
	    return null;
	}
	
	public String getExtensionExperiments() throws Exception {
		ArrayList<Experiment> experiments = new ArrayList<Experiment>();
		try {			
			experiments.addAll(Experiment.getExperimentsForExtensions());
		}
		catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ExperimentConstants.API_MODULE_PLURAL));
			return null; 	
		}		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExperimentResponse(request, experiments));		
	    return null;
	}
	
}
