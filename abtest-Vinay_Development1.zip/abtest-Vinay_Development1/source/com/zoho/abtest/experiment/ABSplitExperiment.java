//$Id$
package com.zoho.abtest.experiment;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.transaction.Transaction;
import javax.transaction.TransactionManager;

import org.json.JSONArray;
import org.json.JSONException;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.DataSet;
import com.adventnet.ds.query.GroupByClause;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.ds.query.SelectQueryImpl;
import com.adventnet.ds.query.SortColumn;
import com.adventnet.ds.query.Table;
import com.adventnet.iam.IAMUtil;
import com.adventnet.iam.ServiceOrg;
import com.adventnet.mfw.bean.BeanUtil;
import com.adventnet.persistence.DataAccess;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.persistence.WritableDataObject;
import com.zoho.abtest.ABSPLITEXPERIMENT;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.EXPERIMENT_GOAL;
import com.zoho.abtest.EXPERIMENT_HEATMAP;
import com.zoho.abtest.GOAL;
import com.zoho.abtest.HEATMAP_EXPERIMENT;
import com.zoho.abtest.PROJECT;
import com.zoho.abtest.VARIATION;
import com.zoho.abtest.VARIATION_VISITS;
import com.zoho.abtest.audience.Audience;
import com.zoho.abtest.audience.ExperimentAudience;
import com.zoho.abtest.audience.ExperimentAudienceConstants;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.dimension.DynamicAttributes;
import com.zoho.abtest.elastic.ElasticSearchStatistics;
import com.zoho.abtest.eventactivity.EventActivityConstants;
import com.zoho.abtest.eventactivity.EventActivityWrapper;
import com.zoho.abtest.eventactivity.EventActivityConstants.Module;
import com.zoho.abtest.exception.ResourceNotFoundException;
import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentStatus;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentType;
import com.zoho.abtest.goal.ExperimentGoal;
import com.zoho.abtest.goal.Goal;
import com.zoho.abtest.goal.GoalConstants.GoalType;
import com.zoho.abtest.heatmaps.ExperimentEnabledHeatmap;
import com.zoho.abtest.heatmaps.HeatmapConstants;
import com.zoho.abtest.heatmaps.HeatmapExperiment;
import com.zoho.abtest.heatmaps.HeatmapExperimentConstants;
import com.zoho.abtest.listener.ZABNotifier;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.project.ProjectTreeEventConstants;
import com.zoho.abtest.project.ProjectTreeEventWrapper;
import com.zoho.abtest.project.ProjectTreeEventConstants.OperationType;
import com.zoho.abtest.report.ReportStatistics;
import com.zoho.abtest.report.CumulativeReportConstants.DecisionType;
import com.zoho.abtest.utility.DataSetWrapper;
import com.zoho.abtest.utility.ZABUserBean;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.abtest.variation.Variation;
import com.zoho.abtest.variation.VariationConstants;
import com.zoho.abtest.variation.VariationRequest;
import com.zoho.logs.apache.commons.lang3.StringEscapeUtils;

public class ABSplitExperiment extends Experiment
{
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(ABSplitExperiment.class.getName());
	
	private String experimentUrl;
	private String includeUrls;
	private String excludeUrls;
	private Integer permittedTraffic;
	private String primaryGoal;
	private Integer variationCount;
	private Integer goalsCount;
	private Long visitorCount;
	private Integer statisticalSignificance;
	private Integer expectedImprovement;
	private Integer conversionRate;
	private Long dailyVisitors;
	private Boolean isWinnerDeclared;
	private Boolean isHeatmapEnabled;
	private Boolean redirectParams;
	private String winningVariation;
	private String globalJs;
	private String globalCss;
	
	
	private transient ArrayList<Variation> variations = new ArrayList<Variation>();
	private transient ArrayList<Audience> audiences = new ArrayList<Audience>();
	private transient ArrayList<Goal> goals = new ArrayList<Goal>();
	private transient List<DynamicAttributes> dynamicAttributes = new ArrayList<DynamicAttributes>();
	
	public ABSplitExperiment()
	{
		
	}
			
	public ABSplitExperiment(Experiment experiment)
	{
		setExperimentId(experiment.getExperimentId());
		setProjectId(experiment.getProjectId());
		setExperimentName(experiment.getExperimentName());
		setCreateBy(experiment.getCreateBy());
		setCreatedByName(experiment.getCreatedByName());
		setExperimentKey(experiment.getExperimentKey());
		setExperimentLinkname(experiment.getExperimentLinkname());
		setExperimentType(experiment.getExperimentType());
		setExperimentStatus(experiment.getExperimentStatus());
		setDuration(experiment.getDuration());
		setStartDate(experiment.getStartDate());
		setEndDate(experiment.getEndDate());
		setActualStartTime(experiment.getActualStartTime());
		setActualEndTime(experiment.getActualEndTime());
		setCreatedTime(experiment.getCreatedTime());
		setModifiedTime(experiment.getModifiedTime());
		setIsActive(experiment.getIsActive());
		setProjectLinkname(experiment.getProjectLinkname());
		setSmallThumbnailUrl(experiment.getSmallThumbnailUrl());
		setLargeThumbnailUrl(experiment.getLargeThumbnailUrl());
		setIsHeatmapActive(experiment.getIsHeatmapActive());
		setMakePublic(experiment.getMakePublic());
		setShareUrl(experiment.getShareUrl());
		setActivationMode(experiment.getActivationMode());
		setActivationCondition(experiment.getActivationCondition());
		setMaxHeatmapVisitorsCount(experiment.getMaxHeatmapVisitorsCount());
	}
	
	public static void setExperimentValuesInABSplit(ABSplitExperiment abSplitExp, Experiment experiment)
	{
		abSplitExp.setExperimentId(experiment.getExperimentId());
		abSplitExp.setProjectId(experiment.getProjectId());
		abSplitExp.setExperimentName(experiment.getExperimentName());
		abSplitExp.setCreateBy(experiment.getCreateBy());
		abSplitExp.setCreatedByName(experiment.getCreatedByName());
		abSplitExp.setExperimentKey(experiment.getExperimentKey());
		abSplitExp.setExperimentLinkname(experiment.getExperimentLinkname());
		abSplitExp.setExperimentType(experiment.getExperimentType());
		abSplitExp.setExperimentStatus(experiment.getExperimentStatus());
		abSplitExp.setDuration(experiment.getDuration());
		abSplitExp.setStartDate(experiment.getStartDate());
		abSplitExp.setEndDate(experiment.getEndDate());
		abSplitExp.setActualStartTime(experiment.getActualStartTime());
		abSplitExp.setActualEndTime(experiment.getActualEndTime());
		abSplitExp.setCreatedTime(experiment.getCreatedTime());
		abSplitExp.setModifiedTime(experiment.getModifiedTime());
		abSplitExp.setIsActive(experiment.getIsActive());
		abSplitExp.setProjectLinkname(experiment.getProjectLinkname());
		abSplitExp.setSmallThumbnailUrl(experiment.getSmallThumbnailUrl());
		abSplitExp.setLargeThumbnailUrl(experiment.getLargeThumbnailUrl());
		abSplitExp.setIsHeatmapActive(experiment.getIsHeatmapActive());
		abSplitExp.setMaxHeatmapVisitorsCount(experiment.getMaxHeatmapVisitorsCount());
	}
	public String getGlobalJs() {
		return globalJs;
	}

	public void setGlobalJs(String globalJs) {
		this.globalJs = globalJs;
	}

	public String getGlobalCss() {
		return globalCss;
	}

	public void setGlobalCss(String globalCss) {
		this.globalCss = globalCss;
	}

	public String getWinningVariation() {
		return winningVariation;
	}

	public void setWinningVariation(String winningVariation) {
		this.winningVariation = winningVariation;
	}
	

	
	public Integer getVariationCount() {
		return variationCount;
	}
	public void setVariationCount(Integer variationCount) {
		this.variationCount = variationCount;
	}
	public Integer getGoalsCount() {
		return goalsCount;
	}
	public void setGoalsCount(Integer goalsCount) {
		this.goalsCount = goalsCount;
	}
	public Long getVisitorCount() {
		return visitorCount;
	}
	public void setVisitorCount(Long visitorCount) {
		this.visitorCount = visitorCount;
	}
	public Integer getExpectedImprovement() {
		return expectedImprovement;
	}
	public void setExpectedImprovement(Integer expectedImprovement) {
		this.expectedImprovement = expectedImprovement;
	}
	public Integer getConversionRate() {
		return conversionRate;
	}
	public void setConversionRate(Integer conversionRate) {
		this.conversionRate = conversionRate;
	}
	public Long getDailyVisitors() {
		return dailyVisitors;
	}
	public void setDailyVisitors(Long dailyVisitors) {
		this.dailyVisitors = dailyVisitors;
	}
	public List<DynamicAttributes> getDynamicAttributes() {
		return dynamicAttributes;
	}
	public void setDynamicAttributes(List<DynamicAttributes> dynamicAttributes) {
		this.dynamicAttributes = dynamicAttributes;
	}
	public Integer getPermittedTraffic() {
		return permittedTraffic;
	}
	public void setPermittedTraffic(Integer permittedTraffic) {
		this.permittedTraffic = permittedTraffic;
	}
	public ArrayList<Audience> getAudiences() {
		return audiences;
	}
	public void setAudiences(ArrayList<Audience> audiences) {
		this.audiences = audiences;
	}
	public ArrayList<Goal> getGoals() {
		return goals;
	}
	public void setGoals(ArrayList<Goal> goals) {
		this.goals = goals;
	}
	public String getExperimentUrl() {
		return experimentUrl;
	}
	public void setExperimentUrl(String experimentUrl) {
		this.experimentUrl = experimentUrl;
	}
	public ArrayList<Variation> getVariations() {
		return variations;
	}
	public void setVariations(ArrayList<Variation> variations) {
		this.variations = variations;
	}
	public String getPrimaryGoal() {
		return primaryGoal;
	}
	public void setPrimaryGoal(String primaryGoal) {
		this.primaryGoal = primaryGoal;
	}
	public Integer getStatisticalSignificance() {
		return statisticalSignificance;
	}
	public void setStatisticalSignificance(Integer statisticalSignificance) {
		this.statisticalSignificance = statisticalSignificance;
	}
	public Boolean getIsWinnerDeclared() {
		return isWinnerDeclared;
	}
	public void setIsWinnerDeclared(Boolean isWinnerDeclared) {
		this.isWinnerDeclared = isWinnerDeclared;
	}
	public String getExcludeUrls() {
		return excludeUrls;
	}
	public void setExcludeUrls(String excludeUrls) {
		this.excludeUrls = excludeUrls;
	}
	public String getIncludeUrls() {
		return includeUrls;
	}
	public void setIncludeUrls(String includeUrls) {
		this.includeUrls = includeUrls;
	}
	
	public Boolean getIsHeatmapEnabled() {
		return isHeatmapEnabled;
	}

	public void setIsHeatmapEnabled(Boolean isHeatmapEnabled) {
		this.isHeatmapEnabled = isHeatmapEnabled;
	}
	

	public Boolean getRedirectParams() {
		return redirectParams;
	}

	public void setRedirectParams(Boolean redirectParams) {
		this.redirectParams = redirectParams;
	}


	public static ABSplitExperiment getABSplitExperimentFromRow(Row experimentRow, Row abSplitRow) {
		ABSplitExperiment experiment = new ABSplitExperiment();
		
		getExperimentFromRow(experimentRow, experiment);
		
		experiment.setExperimentUrl((String)abSplitRow.get(ABSPLITEXPERIMENT.EXPERIMENT_URL));
		experiment.setPermittedTraffic((Integer)abSplitRow.get(ABSPLITEXPERIMENT.PERMITTED_TRAFFIC));
		experiment.setExcludeUrls((String)abSplitRow.get(ABSPLITEXPERIMENT.EXCLUDE_URLS));
		experiment.setIncludeUrls((String)abSplitRow.get(ABSPLITEXPERIMENT.INCLUDE_URLS));
		experiment.setStatisticalSignificance((Integer)abSplitRow.get(ABSPLITEXPERIMENT.SIGNIFICANCE_LEVEL));
		experiment.setConversionRate((Integer)abSplitRow.get(ABSPLITEXPERIMENT.CONVERSION_RATE));
		experiment.setExpectedImprovement((Integer)abSplitRow.get(ABSPLITEXPERIMENT.EXPECTED_IMPROVEMENT));
		experiment.setDailyVisitors((Long)abSplitRow.get(ABSPLITEXPERIMENT.DAILY_VISITORS));
		experiment.setIsHeatmapEnabled((Boolean)abSplitRow.get(ABSPLITEXPERIMENT.IS_HEATMAP_ENABLED));
		experiment.setRedirectParams((Boolean)abSplitRow.get(ABSPLITEXPERIMENT.REDIRECT_PARAMS));
		experiment.setGlobalCss((String)abSplitRow.get(ABSPLITEXPERIMENT.GLOBAL_CSS));
		experiment.setGlobalJs((String)abSplitRow.get(ABSPLITEXPERIMENT.GLOBAL_JS));
		experiment.setSuccess(Boolean.TRUE);
		return experiment;
	}
	
	public static ABSplitExperiment getABSplitExperimentFromRow(Row abSplitRow, ABSplitExperiment experiment) {
		experiment.setExperimentUrl((String)abSplitRow.get(ABSPLITEXPERIMENT.EXPERIMENT_URL));
		experiment.setPermittedTraffic((Integer)abSplitRow.get(ABSPLITEXPERIMENT.PERMITTED_TRAFFIC));
		experiment.setExcludeUrls((String)abSplitRow.get(ABSPLITEXPERIMENT.EXCLUDE_URLS));
		experiment.setIncludeUrls((String)abSplitRow.get(ABSPLITEXPERIMENT.INCLUDE_URLS));
		experiment.setStatisticalSignificance((Integer)abSplitRow.get(ABSPLITEXPERIMENT.SIGNIFICANCE_LEVEL));
		experiment.setConversionRate((Integer)abSplitRow.get(ABSPLITEXPERIMENT.CONVERSION_RATE));
		experiment.setExpectedImprovement((Integer)abSplitRow.get(ABSPLITEXPERIMENT.EXPECTED_IMPROVEMENT));
		experiment.setDailyVisitors((Long)abSplitRow.get(ABSPLITEXPERIMENT.DAILY_VISITORS));
		experiment.setIsHeatmapEnabled((Boolean)abSplitRow.get(ABSPLITEXPERIMENT.IS_HEATMAP_ENABLED));
		experiment.setRedirectParams((Boolean)abSplitRow.get(ABSPLITEXPERIMENT.REDIRECT_PARAMS));
		experiment.setGlobalCss((String)abSplitRow.get(ABSPLITEXPERIMENT.GLOBAL_CSS));
		experiment.setGlobalJs((String)abSplitRow.get(ABSPLITEXPERIMENT.GLOBAL_JS));
		experiment.setSuccess(Boolean.TRUE);
		return experiment;
	}
	
	public static ABSplitExperiment getABSplitExperimentFromRow(Row abSplitRow) {
		ABSplitExperiment experiment = new ABSplitExperiment();
		experiment.setExperimentId((Long)abSplitRow.get(ABSPLITEXPERIMENT.EXPERIMENT_ID));
		experiment.setExperimentUrl((String)abSplitRow.get(ABSPLITEXPERIMENT.EXPERIMENT_URL));
		experiment.setPermittedTraffic((Integer)abSplitRow.get(ABSPLITEXPERIMENT.PERMITTED_TRAFFIC));
		experiment.setExcludeUrls((String)abSplitRow.get(ABSPLITEXPERIMENT.EXCLUDE_URLS));
		experiment.setIncludeUrls((String)abSplitRow.get(ABSPLITEXPERIMENT.INCLUDE_URLS));
		experiment.setStatisticalSignificance((Integer)abSplitRow.get(ABSPLITEXPERIMENT.SIGNIFICANCE_LEVEL));
		experiment.setConversionRate((Integer)abSplitRow.get(ABSPLITEXPERIMENT.CONVERSION_RATE));
		experiment.setExpectedImprovement((Integer)abSplitRow.get(ABSPLITEXPERIMENT.EXPECTED_IMPROVEMENT));
		experiment.setDailyVisitors((Long)abSplitRow.get(ABSPLITEXPERIMENT.DAILY_VISITORS));
		experiment.setIsHeatmapEnabled((Boolean)abSplitRow.get(ABSPLITEXPERIMENT.IS_HEATMAP_ENABLED));
		experiment.setRedirectParams((Boolean)abSplitRow.get(ABSPLITEXPERIMENT.REDIRECT_PARAMS));
		experiment.setGlobalCss((String)abSplitRow.get(ABSPLITEXPERIMENT.GLOBAL_CSS));
		experiment.setGlobalJs((String)abSplitRow.get(ABSPLITEXPERIMENT.GLOBAL_JS));
		experiment.setSuccess(Boolean.TRUE);
		return experiment;
	}
	
	public static ABSplitExperiment getABSplitExperiment(String expLinkname)
	{
		ABSplitExperiment exp = null;
		try
		{
			Criteria c = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_LINK_NAME), expLinkname, QueryConstants.EQUAL);
			Join join = new Join(EXPERIMENT.TABLE, ABSPLITEXPERIMENT.TABLE, new String[]{EXPERIMENT.EXPERIMENT_ID}, new String[]{ABSPLITEXPERIMENT.EXPERIMENT_ID}, Join.INNER_JOIN);
			DataObject dataObj = ZABModel.getRow(EXPERIMENT.TABLE, c, join);
			Row absplitRow = dataObj.getFirstRow(ABSPLITEXPERIMENT.TABLE);
			exp = getABSplitExperimentFromRow(absplitRow);
		}
		catch(Exception ex)
		{
			exp = new ABSplitExperiment();
			exp.setSuccess(Boolean.FALSE);
		}
		return exp;
	}
	
	public static ABSplitExperiment getABSplitExperimentDetail(String expLinkname)
	{
		ABSplitExperiment exp = null;
		try
		{
			Criteria c = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_LINK_NAME), expLinkname, QueryConstants.EQUAL);
			Join join = new Join(EXPERIMENT.TABLE, ABSPLITEXPERIMENT.TABLE, new String[]{EXPERIMENT.EXPERIMENT_ID}, new String[]{ABSPLITEXPERIMENT.EXPERIMENT_ID}, Join.INNER_JOIN);
			DataObject dataObj = ZABModel.getRow(EXPERIMENT.TABLE, c, join);
			Row absplitRow = dataObj.getFirstRow(ABSPLITEXPERIMENT.TABLE);
			Row expRow = dataObj.getFirstRow(EXPERIMENT.TABLE);
			exp = getABSplitExperimentFromRow(expRow, absplitRow);
		}
		catch(Exception ex)
		{
			exp = new ABSplitExperiment();
			exp.setSuccess(Boolean.FALSE);
		}
		return exp;
	}
	
	public static Row getABSplitExperimentRow(Long expId) throws Exception
	{
		Criteria c = new Criteria(new Column(ABSPLITEXPERIMENT.TABLE, ABSPLITEXPERIMENT.EXPERIMENT_ID), expId, QueryConstants.EQUAL);
		DataObject dataObj = ZABModel.getRow(ABSPLITEXPERIMENT.TABLE, c);
		Row absplitRow = dataObj.getFirstRow(ABSPLITEXPERIMENT.TABLE);
		return absplitRow;
	}
	
	public static Experiment setABSplitHeatmapExperimentDetails(Experiment experiment) throws Exception
	{
		Criteria c = new Criteria(new Column(ABSPLITEXPERIMENT.TABLE, ABSPLITEXPERIMENT.EXPERIMENT_ID), experiment.getExperimentId(), QueryConstants.EQUAL);
		Join join = new Join(ABSPLITEXPERIMENT.TABLE,EXPERIMENT_HEATMAP.TABLE,new String[]{ABSPLITEXPERIMENT.EXPERIMENT_ID},new String[]{EXPERIMENT_HEATMAP.EXPERIMENT_ID},Join.LEFT_JOIN);
		Join join1 = new Join(EXPERIMENT_HEATMAP.TABLE,HEATMAP_EXPERIMENT.TABLE,new String[]{EXPERIMENT_HEATMAP.HEATMAP_EXPERIMENT_ID},new String[]{HEATMAP_EXPERIMENT.EXPERIMENT_ID},Join.LEFT_JOIN);
		
		DataObject dataObj = ZABModel.getRow(ABSPLITEXPERIMENT.TABLE, c,new Join[] {join, join1});
		
		if(dataObj.containsTable(EXPERIMENT_HEATMAP.TABLE))
		{	
			Row expHMRow = dataObj.getFirstRow(EXPERIMENT_HEATMAP.TABLE);
			ExperimentEnabledHeatmap enabledHM = ExperimentEnabledHeatmap.getExperimentHeatmapFromRow(expHMRow);
			Experiment HMexp = getExperimentById(enabledHM.getExperimentHeatmapId());
			if(!ExperimentStatus.DRAFT.getStatusCode().equals(HMexp.getExperimentStatus())){
				experiment.setIsHeatmapActive(Boolean.TRUE);
			}else{
				experiment.setIsHeatmapActive(Boolean.FALSE);
			}
		}else{
			experiment.setIsHeatmapActive(Boolean.FALSE);
		}
		
		if(dataObj.containsTable(HEATMAP_EXPERIMENT.TABLE)){
			Row heatmapRow = dataObj.getFirstRow(HEATMAP_EXPERIMENT.TABLE);
			HeatmapExperiment hmexp  = HeatmapExperiment.getHeatmapExperimentFromRow(heatmapRow);
			experiment.setMaxHeatmapVisitorsCount(hmexp.getMaxVisitors());
		}
		
		return experiment;
	}
	
	public static ABSplitExperiment getABSplitExperiment(Long expId)
	{
		ABSplitExperiment exp = null;
		try
		{
			Row absplitRow =  getABSplitExperimentRow(expId);
			exp = getABSplitExperimentFromRow(absplitRow);
		}
		catch(Exception ex)
		{
			exp = new ABSplitExperiment();
			exp.setSuccess(Boolean.FALSE);
		}
		return exp;
	}
	
	public static ABSplitExperiment getABSplitExperimentFromDataSet(DataSet ds, String prefix) throws SQLException {
		ABSplitExperiment experiment = new ABSplitExperiment();
		String abSplitPrefix = ABSPLITEXPERIMENT.TABLE + ".";
		
		getExperimentFromDataSet(ds, prefix, experiment);
		
		experiment.setExperimentUrl((String)ds.getValue(abSplitPrefix+ABSPLITEXPERIMENT.EXPERIMENT_URL));
		experiment.setPermittedTraffic((Integer)ds.getValue(abSplitPrefix+ABSPLITEXPERIMENT.PERMITTED_TRAFFIC));
		experiment.setStatisticalSignificance((Integer)ds.getValue(abSplitPrefix+ABSPLITEXPERIMENT.SIGNIFICANCE_LEVEL));
		experiment.setConversionRate((Integer)ds.getValue(abSplitPrefix+ABSPLITEXPERIMENT.CONVERSION_RATE));
		experiment.setExpectedImprovement((Integer)ds.getValue(abSplitPrefix+ABSPLITEXPERIMENT.EXPECTED_IMPROVEMENT));
		experiment.setDailyVisitors((Long)ds.getValue(abSplitPrefix+ABSPLITEXPERIMENT.DAILY_VISITORS));
		experiment.setIsHeatmapEnabled((Boolean)ds.getValue(abSplitPrefix+ABSPLITEXPERIMENT.IS_HEATMAP_ENABLED));
		experiment.setRedirectParams((Boolean)ds.getValue(abSplitPrefix+ABSPLITEXPERIMENT.REDIRECT_PARAMS));
		experiment.setGlobalCss((String)ds.getValue(abSplitPrefix+ABSPLITEXPERIMENT.GLOBAL_CSS));
		experiment.setGlobalJs((String)ds.getValue(abSplitPrefix+ABSPLITEXPERIMENT.GLOBAL_JS));
		
		
		Integer variationCount = (Integer)ds.getValue(ExperimentConstants.VARIATION_COUNT);
		experiment.setVariationCount(variationCount);
		experiment.setGoalsCount((Integer)ds.getValue(ExperimentConstants.GOAL_COUNT));

		experiment.setSuccess(Boolean.TRUE);
		return experiment;
	}
	
	public static void setVisitorCountForExperiment(final HashMap<Long, ABSplitExperiment> experimentIdsMap) throws Exception {
		Set<Long> experimentIds = experimentIdsMap.keySet();
		Criteria c = new Criteria(new Column(VARIATION_VISITS.TABLE, VARIATION_VISITS.EXPERIMENT_ID), experimentIds.toArray(new Long[experimentIds.size()]), QueryConstants.IN);
		SelectQuery query = new SelectQueryImpl(new Table(VARIATION_VISITS.TABLE));
		Column sum = new Column(VARIATION_VISITS.TABLE, VARIATION_VISITS.UNIQUE_VISITOR_COUNT).summation();
		Column expId = new Column(VARIATION_VISITS.TABLE, VARIATION_VISITS.EXPERIMENT_ID);
		sum.setColumnAlias(ExperimentConstants.VISITOR_COUNT);
		query.addSelectColumn(sum);
		query.addSelectColumn(expId);
		GroupByClause gc = new GroupByClause(Arrays.asList(new Column(VARIATION_VISITS.TABLE, VARIATION_VISITS.EXPERIMENT_ID)));
		query.setGroupByClause(gc);
		query.setCriteria(c);
		ZABUserBean bean= (ZABUserBean)BeanUtil.lookup(ZABUserBean.BEAN_NAME, ZABUtil.getCurrentUserDbSpace());
		bean.executeQuery(query, new DataSetWrapper() {

			@Override
			public void execute(DataSet ds) throws Exception {
				while(ds.next()) {
					Long experimentId = (Long)ds.getValue(VARIATION_VISITS.EXPERIMENT_ID);
					Long count = (Long)ds.getValue(ExperimentConstants.VISITOR_COUNT);
					experimentIdsMap.get(experimentId).setVisitorCount(count);
				}
			}
		});

	}
	
	public static void setVisitorCountForExperiment(final ABSplitExperiment absplitExperiment) throws Exception {
		
		Long expId = absplitExperiment.getExperimentId();
		String portal = ZABUtil.getPortaldomain();
		Long visitorCount = ElasticSearchStatistics.getExperimentVisitorCount(portal, expId);
		absplitExperiment.setVisitorCount(visitorCount);
		/*
		Criteria c = new Criteria(new Column(VARIATION_VISITS.TABLE, VARIATION_VISITS.EXPERIMENT_ID),absplitExperiment.getExperimentId(), QueryConstants.EQUAL);
		SelectQuery query = new SelectQueryImpl(new Table(VARIATION_VISITS.TABLE));
		Column sum = new Column(VARIATION_VISITS.TABLE, VARIATION_VISITS.UNIQUE_VISITOR_COUNT).summation();
		sum.setColumnAlias(ExperimentConstants.VISITOR_COUNT);
		query.addSelectColumn(sum);
		query.setCriteria(c);
		ZABUserBean bean= (ZABUserBean)BeanUtil.lookup(ZABUserBean.BEAN_NAME, ZABUtil.getCurrentUserDbSpace());
		bean.executeQuery(query, new DataSetWrapper() {

			@Override
			public void execute(DataSet ds) throws Exception {
				if(ds.next()) {
					//Long experimentId = (Long)ds.getValue(VARIATION_VISITS.EXPERIMENT_ID);
					Long count = (Long)ds.getValue(ExperimentConstants.VISITOR_COUNT);
					absplitExperiment.setVisitorCount(count);
				}
			}
		});
		*/
	}

	public static void setExpVisitorCountFromVariation(final ABSplitExperiment experiment) throws Exception
	{
		Long visitorCount = 0l;
		for(Variation variation: experiment.getVariations())
		{
			if(variation.getUniqueVisitors() != null)
			{
				visitorCount = visitorCount + variation.getUniqueVisitors();
			}
		}
		experiment.setVisitorCount(visitorCount);
	}
	
	public static ArrayList<ABSplitExperiment> getABSplitExperimentFromDobj(DataObject dobj) throws DataAccessException {
		ArrayList<ABSplitExperiment> experiments = new ArrayList<ABSplitExperiment>();
		if(dobj.containsTable(ABSPLITEXPERIMENT.TABLE)) {
			Iterator it = dobj.getRows(ABSPLITEXPERIMENT.TABLE);
			while(it.hasNext()) {
				Row absplitrow = (Row)it.next();
				Long experimentId = (Long)absplitrow.get(EXPERIMENT.EXPERIMENT_ID);
				Criteria criteria1 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
				Row experimentRow = dobj.getRow(EXPERIMENT.TABLE, criteria1);
				ABSplitExperiment experiment = getABSplitExperimentFromRow(experimentRow, absplitrow);
				experiment.setProjectLinkname(Project.getProjectLinkname(dobj, experiment.getProjectId()));
				experiments.add(experiment);
			}
		}
		return experiments;
	}
	
	public static ArrayList<Long> getVariationsOfExperiment(Long expId){
		ArrayList<Long> variationIds= new ArrayList<Long>();
		try{
			Criteria  c = new Criteria(new Column(VARIATION.TABLE,VARIATION.EXPERIMENT_ID),expId,QueryConstants.EQUAL);
			DataObject  dobj = ZABModel.getRow(VARIATION.TABLE, c);
			Iterator<?>  itr  = dobj.getRows(VARIATION.TABLE);
			while(itr.hasNext()){
				Row r  = (Row )itr.next();
				Long variationId   = (Long)r.get(VARIATION.VARIATION_ID);
				variationIds.add(variationId);
			}

		}catch(Exception e){
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}

		return variationIds;
	}
	
	public static ArrayList<Long> getGoalsOfExperiment(Long expId){
		ArrayList<Long> goalIds= new ArrayList<Long>();
		try{

			Criteria c = new Criteria(new Column(EXPERIMENT_GOAL.TABLE,EXPERIMENT_GOAL.EXPERIMENT_ID),expId,QueryConstants.EQUAL);
			DataObject dobj = ZABModel.getRow(EXPERIMENT_GOAL.TABLE, c);
			Iterator<?> itr  = dobj.getRows(EXPERIMENT_GOAL.TABLE);
			while(itr.hasNext()){
				Row r  = (Row )itr.next();
				Long gaolId  = (Long)r.get(EXPERIMENT_GOAL.GOAL_ID);
				goalIds.add(gaolId);
			}

		}
		catch(Exception e){
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}

		return goalIds;

	}
	
	public static Long getRevenueGoalOfExperiment(Long expId){
		Long goalId  = null;

		try{
			Criteria c1 = new Criteria(new Column(EXPERIMENT_GOAL.TABLE, EXPERIMENT_GOAL.EXPERIMENT_ID), expId, QueryConstants.EQUAL);
			Criteria c2 = new Criteria(new Column(GOAL.TABLE, GOAL.GOAL_TYPE_FLAG), GoalType.REVENUE_GOAL.getGoalTypeId(), QueryConstants.EQUAL);
			Join join  = new Join(EXPERIMENT_GOAL.TABLE, GOAL.TABLE , new String[]{EXPERIMENT_GOAL.GOAL_ID}, new String[]{GOAL.GOAL_ID},Join.INNER_JOIN);
			DataObject dobj =  ZABModel.getRow(EXPERIMENT_GOAL.TABLE, c1.and(c2), join);
			if(dobj.containsTable(GOAL.TABLE)){
				goalId = (Long)dobj.getFirstValue(GOAL.TABLE, GOAL.GOAL_ID);
			}

		}catch(Exception e ){
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return goalId; 

	}
	public static Long getTimeSpentGoalOfExperiment(Long expId){
		Long goalId  = null;

		try{
			Criteria c1 = new Criteria(new Column(EXPERIMENT_GOAL.TABLE, EXPERIMENT_GOAL.EXPERIMENT_ID), expId, QueryConstants.EQUAL);
			Criteria c2 = new Criteria(new Column(GOAL.TABLE, GOAL.GOAL_TYPE_FLAG), GoalType.TIME_SPENT_GOAL.getGoalTypeId(), QueryConstants.EQUAL);
			Join join  = new Join(EXPERIMENT_GOAL.TABLE, GOAL.TABLE , new String[]{EXPERIMENT_GOAL.GOAL_ID}, new String[]{GOAL.GOAL_ID},Join.INNER_JOIN);
			DataObject dobj =  ZABModel.getRow(EXPERIMENT_GOAL.TABLE, c1.and(c2), join);
			if(dobj.containsTable(GOAL.TABLE)){
				goalId = (Long)dobj.getFirstValue(GOAL.TABLE, GOAL.GOAL_ID);
			}

		}catch(Exception e ){
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return goalId; 

	}
	
	public static ABSplitExperiment createABSplitExperiment(HashMap<String, String> hs) {
		ABSplitExperiment abSplitExp = null;
		TransactionManager mgr = DataAccess.getTransactionManager();
		try {
			mgr.begin();
			
			//Create Experiment
			Experiment experiment = createExperiment(hs);
			
			String projectLinkname = hs.get(ExperimentConstants.PROJECT_LINKNAME);
			Long experimentId = experiment.getExperimentId();
			if(experiment.getSuccess().equals(Boolean.TRUE) && experimentId  != null) {

				hs.put(ExperimentConstants.EXPERIMENT_ID, experimentId.toString());
				addDefaultValueIfNotAvailable(hs, ExperimentConstants.STATISTICAL_SIGNIFICANCE, ExperimentConstants.DEFAULT_STATISTICAL_SIGNIFICANCE);
				addDefaultValueIfNotAvailable(hs, ExperimentConstants.DAILY_VISITORS, ExperimentConstants.DEFAULT_DAILY_VISITORS);
				addDefaultValueIfNotAvailable(hs, ExperimentConstants.CONVERSION_RATE, ExperimentConstants.DEFAULT_CONVERSION_RATE);
				addDefaultValueIfNotAvailable(hs, ExperimentConstants.EXPECTED_IMPROVEMENT, ExperimentConstants.DEFAULT_EXPECTED_IMPROVEMENT);			
				//Create ABSplit details
				DataObject dobj = createRow(ExperimentConstants.ABSPLITEXPERIMENT_TABLE, ABSPLITEXPERIMENT.TABLE, hs);
				
				Row absplitRow = dobj.getFirstRow(ABSPLITEXPERIMENT.TABLE);
				
				abSplitExp = new ABSplitExperiment(experiment);
				getABSplitExperimentFromRow(absplitRow, abSplitExp);

				abSplitExp.setVariationCount(2);
				Integer exptype = abSplitExp.getExperimentType();

				//Creating variation
				abSplitExp.setProjectLinkname(projectLinkname);
				String linkname = abSplitExp.getExperimentLinkname();
				HashMap<String, String> original =  new HashMap<String, String>();
				original.put(VariationConstants.TARGET_URL, abSplitExp.getExperimentUrl());
				original.put(VariationConstants.VARIATION_NAME, VariationConstants.ORIGINAL_VARIATION);
				if(ExperimentType.SPLITURL.getTypeNumber().equals(exptype)){
					original.put(VariationConstants.TRAFFIC_ALLOCATION, 100+"");
				}else{
					original.put(VariationConstants.TRAFFIC_ALLOCATION, 50+"");
				}
				original.put(VariationConstants.EXPERIMENT_LINKNAME, linkname);
				Variation origVar = Variation.createVariation(original, Boolean.TRUE, Boolean.FALSE, Boolean.FALSE);
				if(origVar.getSuccess()) {						
					abSplitExp.getVariations().add(origVar);
				} else {
					throw new ZABException(ZABAction.getMessage(ExperimentConstants.VARIATION_CREATION_ERROR)); 
				}
				Variation var1 = null;
				//Add another variation only if it is abtest
				if(ExperimentType.ABTEST.getTypeNumber().equals(exptype)){
					HashMap<String, String> variation1 =  new HashMap<String, String>();
					variation1.put(VariationConstants.VARIATION_NAME, VariationConstants.VARIATION_1);
					variation1.put(VariationConstants.EXPERIMENT_LINKNAME, linkname);
					variation1.put(VariationConstants.TRAFFIC_ALLOCATION, 50+"");
					var1 = Variation.createVariation(variation1, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
					if(var1.getSuccess()) {						
						abSplitExp.getVariations().add(var1);
					} else {
						throw new ZABException(ZABAction.getMessage(ExperimentConstants.VARIATION_CREATION_ERROR)); 
					}
				}

				//Create Experiment Audience
				Audience audience = Audience.getAudienceByLinkName("all", 0L);//No I18N
				HashMap<String, String> hs_audience =  new HashMap<String, String>();
				hs_audience.put(ExperimentAudienceConstants.EXPERIMENT_ID, experimentId.toString());
				hs_audience.put(ExperimentAudienceConstants.AUDIENCE_ID, audience.getAudienceId().toString());
				ArrayList<ExperimentAudience> expaudience = ExperimentAudience.createExperimentAudience(hs_audience,false);
				
				mgr.commit();

				//Trigger event 
				ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
				wrapper.setModel(abSplitExp);
				wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
				wrapper.setType(OperationType.CREATE);
				Long zsoid;
				ServiceOrg currentServiceOrg = IAMUtil.getCurrentServiceOrg();
				if(currentServiceOrg != null)
				{
					zsoid = currentServiceOrg.getZSOID();
					wrapper.setZsoid(zsoid.toString());
					//return DFSClientPool.getDFSClient("Test", SERVICENAME);
				}
				ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);
				
				//Event Activity Log
				HashMap<String, String> updatedValues = new HashMap<String, String>();
				updatedValues.put(EventActivityConstants.EXPERIMENT_ID, experimentId.toString());
				updatedValues.put(EventActivityConstants.USER_ID, ZABUtil.getCurrentUser().getUserId().toString());
				updatedValues.put(EventActivityConstants.TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
				EventActivityWrapper activityWrapper = new EventActivityWrapper();
				activityWrapper.setModule(Module.EXPERIMENT);
				activityWrapper.setOperationType(com.zoho.abtest.eventactivity.EventActivityConstants.OperationType.CREATE);
				activityWrapper.setDbSpace(ZABUtil.getCurrentUserDbSpace());
				activityWrapper.setUpdatedValues(updatedValues);
				ZABNotifier.notifyListeners(EventActivityConstants.EVENT_MODULE_NAME, activityWrapper);
				
				if(ExperimentType.ABTEST.getTypeNumber().equals(exptype) && var1 != null){
					//Event activity Log for variation1 created
					HashMap<String, String> updatedValues1 = new HashMap<String, String>();
					updatedValues1.put(EventActivityConstants.EXPERIMENT_ID, var1.getExperimentId().toString());
					//updatedValues1.put(EventActivityConstants.USER_ID, ZABUtil.getCurrentUser().getUserId().toString());
					updatedValues1.put(EventActivityConstants.TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
					updatedValues1.put(VariationConstants.VARIATION_ID, var1.getVariationId().toString());
					EventActivityWrapper activityWrapper1 = new EventActivityWrapper();
					activityWrapper1.setModule(com.zoho.abtest.eventactivity.EventActivityConstants.Module.VARIATION);
					activityWrapper1.setOperationType(com.zoho.abtest.eventactivity.EventActivityConstants.OperationType.CREATE);
					activityWrapper1.setDbSpace(ZABUtil.getCurrentUserDbSpace());
					activityWrapper1.setUpdatedValues(updatedValues1);
					ZABNotifier.notifyListeners(EventActivityConstants.EVENT_MODULE_NAME, activityWrapper1);
				}
			}
			else
			{
				mgr.rollback();
				LOGGER.log(Level.SEVERE,"Exception Occurred while creating experiment. Hence rolledback changes.");
				abSplitExp = new ABSplitExperiment();
				abSplitExp.setSuccess(Boolean.FALSE);
				abSplitExp.setResponseString(experiment!=null? experiment.getResponseString():ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			}

		} catch (Exception e) {
			try {
				mgr.rollback();
			} catch (Exception e1) {
				LOGGER.log(Level.SEVERE,"Exception Occurred",e1);
			}
			abSplitExp = new ABSplitExperiment();
			abSplitExp.setSuccess(Boolean.FALSE);
			abSplitExp.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return abSplitExp;
	}
	
	public static void updateABSplitExperimentUrl(HashMap<String, String> hs) throws Exception {
		String linkName = hs.get(ExperimentConstants.EXPERIMENT_LINKNAME);
		
		ABSplitExperiment oldABSplitExperiment = ABSplitExperiment.getABSplitExperiment(linkName);
		//Logging event activity purpose
		HashMap<String,String> oldValues = generateHashMapFromAbSplitExperimentObj(oldABSplitExperiment, hs);

		hs.put(ExperimentConstants.MODIFIED_TIME, ZABUtil.getCurrentTimeInMilliSeconds()+"");
		Criteria c = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_LINK_NAME), linkName, QueryConstants.EQUAL);
		updateRow(ExperimentConstants.EXPERIMENT_TABLE, EXPERIMENT.TABLE, hs, c, ExperimentConstants.API_RESOURCE);
		
		Criteria c1 = new Criteria(new Column(ABSPLITEXPERIMENT.TABLE, ABSPLITEXPERIMENT.EXPERIMENT_ID), oldABSplitExperiment.getExperimentId(), QueryConstants.EQUAL);
		updateRow(ExperimentConstants.ABSPLITEXPERIMENT_TABLE, ABSPLITEXPERIMENT.TABLE, hs, c1, ExperimentConstants.API_RESOURCE);
		
		ABSplitExperiment experiment = new ABSplitExperiment();
		experiment.setExperimentLinkname(linkName);
		experiment.setSuccess(Boolean.TRUE);
		ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
		wrapper.setModel(experiment);
		wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
		wrapper.setType(OperationType.UPDATE);
		ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);

		//Event Activity Log
		HashMap<String, String> updatedValues = new HashMap<String, String>();
		updatedValues.putAll(hs);
		updatedValues.put(EventActivityConstants.EXPERIMENT_ID, oldABSplitExperiment.getExperimentId().toString());
		updatedValues.put(EventActivityConstants.USER_ID, ZABUtil.getCurrentUser().getUserId().toString());
		updatedValues.put(EventActivityConstants.TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
		EventActivityWrapper activityWrapper = new EventActivityWrapper();
		activityWrapper.setModule(Module.EXPERIMENT);
		activityWrapper.setOperationType(com.zoho.abtest.eventactivity.EventActivityConstants.OperationType.UPDATE);
		activityWrapper.setDbSpace(ZABUtil.getCurrentUserDbSpace());
		activityWrapper.setUpdatedValues(updatedValues);
		activityWrapper.setOldValues(oldValues);
		ZABNotifier.notifyListeners(EventActivityConstants.EVENT_MODULE_NAME, activityWrapper);
	}
	
	public static ABSplitExperiment updateABSplitExperiment(HashMap<String, String> hs) {
		ABSplitExperiment absplitExperiment = null;
		TransactionManager mgr = null;
		Boolean alreadyInTransaction = false;
		Long experimentId = null;
		try {
			String linkName = hs.get(ExperimentConstants.EXPERIMENT_LINKNAME);
			//Logging event activity purpose
			ABSplitExperiment oldAbSplitExp = ABSplitExperiment.getABSplitExperiment(linkName);
			HashMap<String,String> oldValues = generateHashMapFromAbSplitExperimentObj(oldAbSplitExp,hs);
			experimentId = oldAbSplitExp.getExperimentId();
			
			/*ABSplitExperiment Validations START*/
			//Do not allow the experiment to start/schedule without configuring Goal
			if(hs.containsKey(ExperimentConstants.EXPERIMENT_STATUS) && 
					(ExperimentConstants.ExperimentStatus.RUNNING.getStatusCode().equals(Integer.parseInt(hs.get(ExperimentConstants.EXPERIMENT_STATUS))) ||
							ExperimentConstants.ExperimentStatus.SCHEDULED.getStatusCode().equals(Integer.parseInt(hs.get(ExperimentConstants.EXPERIMENT_STATUS)))))
			{
				
				int variationCount = Variation.getExperimentVariationCount(experimentId);
				boolean isGoalExists = ExperimentGoal.isGoalExistsForExperiment(experimentId);
				
				if(variationCount <= 1 && !isGoalExists)
				{
					absplitExperiment = new ABSplitExperiment();
					absplitExperiment.setSuccess(Boolean.FALSE);
					absplitExperiment.setResponseString(ZABAction.getMessage(ExperimentConstants.EXPERIMENT_MINIMUM_VARIATION_GOAL_COUNT_ERROR));
					return absplitExperiment;
				}
				
				if(variationCount <= 1)
				{
					absplitExperiment = new ABSplitExperiment();
					absplitExperiment.setSuccess(Boolean.FALSE);
					absplitExperiment.setResponseString(ZABAction.getMessage(ExperimentConstants.EXPERIMENT_MINIMUM_VARIATION_COUNT_ERROR));
					return absplitExperiment;
				}

				if(!isGoalExists)
				{
					absplitExperiment = new ABSplitExperiment();
					absplitExperiment.setSuccess(Boolean.FALSE);
					absplitExperiment.setResponseString(ZABAction.getMessage(ExperimentConstants.EXPERIMENT_MINIMUM_GOAL_VALIDATION_ERROR));
					return absplitExperiment;
				}
				//				Commented for now 
				// 				Please check with this bug https://projects.zoho.com/portal/zohosheet#buginfo/143922000006470013/143922000007153003
				//				boolean isCheckScriptAdded  = false;
				//				isCheckScriptAdded =  CheckScript.checkScript(linkName).getIsScriptAvailable();
				//				if(!isCheckScriptAdded){
				//					experiment = new Experiment();
				//					experiment.setSuccess(Boolean.FALSE);
				//					experiment.setResponseString(ZABAction.getMessage(ExperimentConstants.CHECKSCRIPT_NOT_ADDED_ERROR));
				//					return experiment;
				//				}
			}

			/*ABSplitExperiment Validations END*/

			Experiment experiment = Experiment.updateExperiment(hs);
			if(!experiment.getSuccess())
			{
				absplitExperiment = new ABSplitExperiment();
				absplitExperiment.setSuccess(Boolean.FALSE);
				absplitExperiment.setResponseString(experiment.getResponseString());
				return absplitExperiment;
			}
			
			mgr = DataAccess.getTransactionManager();
			Transaction trans = mgr.getTransaction();
			alreadyInTransaction = (trans!=null);
			if(!alreadyInTransaction) {				
				mgr.begin();
			}

			if(hs.containsKey(ExperimentConstants.INCLUDE_URLS)){
				hs.put(ExperimentConstants.INCLUDE_URLS, StringEscapeUtils.unescapeJava(hs.get(ExperimentConstants.INCLUDE_URLS)));
			}
			
			if(hs.containsKey(ExperimentConstants.EXCLUDE_URLS)){
				hs.put(ExperimentConstants.EXCLUDE_URLS, StringEscapeUtils.unescapeJava(hs.get(ExperimentConstants.EXCLUDE_URLS)));
			}

			Criteria c = new Criteria(new Column(ABSPLITEXPERIMENT.TABLE, ABSPLITEXPERIMENT.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
			updateRow(ExperimentConstants.ABSPLITEXPERIMENT_TABLE, ABSPLITEXPERIMENT.TABLE, hs, c, ExperimentConstants.API_RESOURCE);
			
			// if is_heatmap_enabled = true //check if is_heatmap_enabled in oldValues is true or false 
			     // - fasle - create new heatmap enabled exp and link it with this abexp - update max_visits_count if exists
				// - true - update actual_endtime of the heatmap exp and update max_visits_count if exists
			
			HashMap<String,String> heatmap = null;
			if(hs.containsKey(ExperimentConstants.IS_HEATMAP_ENABLED) || hs.containsKey(ExperimentConstants.HEATMAP_MAX_VISITORS)){
				
				HeatmapExperiment hmExp = null;
				ExperimentEnabledHeatmap exp = ExperimentEnabledHeatmap.getExperimentHeatmapByExperimentId(experiment.getExperimentId());
				if(hs.containsKey(ExperimentConstants.IS_HEATMAP_ENABLED) && hs.get(ExperimentConstants.IS_HEATMAP_ENABLED).equals(Boolean.TRUE.toString()) && exp == null){
				
					Experiment abexp = getExperimentByLinkname(experiment.getExperimentLinkname());
					heatmap = generateHashMapFromAbSplitExperimentObjForHeatmapExp(abexp,hs);
					heatmap.put(HeatmapConstants.HEATMAP_ENABLED_EXPERIMENT_ID.toLowerCase(),experiment.getExperimentId().toString());
					hmExp = ExperimentEnabledHeatmap.createEnabledHeatmapExperiment(heatmap);		
					
				}else{
					
					heatmap = ExperimentEnabledHeatmap.generateHeatmapHSFromExperiment(hs,experimentId);
					//This flag will be set from job HeatMapVisitorLimitVerification
					if(hs.containsKey(ExperimentConstants.IS_EXP_STATUS_CHANGED))
					{
						heatmap.put(ExperimentConstants.EXPERIMENT_STATUS, ExperimentStatus.PAUSED.getStatusCode().toString());
					}
					hmExp = ExperimentEnabledHeatmap.updateHeatmapEnabledExperiment(heatmap);
				}
				
				if(!hmExp.getSuccess())
				{
					absplitExperiment = new ABSplitExperiment();
					absplitExperiment.setSuccess(Boolean.FALSE);
					absplitExperiment.setResponseString(experiment.getResponseString());
					return absplitExperiment;
				}
			}
			
//			if(hs.containsKey(ExperimentConstants.HEATMAP_MAX_VISITORS)){
//				heatmap = ExperimentEnabledHeatmap.generateHeatmapHSFromExperiment(hs,experimentId);
//				if(heatmap!=null && hmExp == null){
//					hmExp = ExperimentEnabledHeatmap.updateHeatmapEnabledExperiment(heatmap);
//				}
//			}

			if(hs.containsKey(ExperimentConstants.EXPERIMENT_STATUS) && oldAbSplitExp.getIsHeatmapEnabled().equals(Boolean.TRUE)){	
				//If heatmap is enabled for an ab exp, it has the same status as the ab exp
				heatmap = ExperimentEnabledHeatmap.generateHeatmapHSFromExperiment(hs,experimentId);
				if(heatmap!=null){
					ExperimentEnabledHeatmap.updateHeatmapEnabledExperiment(heatmap);
				}
			}
			
			if(hs.containsKey(ExperimentConstants.GOAL)) {

				JSONArray array = new JSONArray(hs.get(ExperimentConstants.GOAL));
				for(int k=0; k<array.length(); k++) {					
					ExperimentGoal.createExperimentGoal(experimentId, array.getString(k), null);
				}
			}
			if(hs.containsKey(ExperimentConstants.PRIMARY_GOAL)) {

				ExperimentGoal.makeExperimentGoalPrimary(experimentId, hs.get(ExperimentConstants.PRIMARY_GOAL));
			}

			if(hs.containsKey(ExperimentConstants.EXPERIMENT_URL)) {
				//Update original variation url

				Variation.updateOriginalVariaitonURL(experimentId, hs.get(ExperimentConstants.EXPERIMENT_URL));
			}

			if(hs.containsKey(ExperimentConstants.VARIATION)) {
				try {
					JSONArray variations = new JSONArray(hs.get(ExperimentConstants.VARIATION));
					ArrayList<HashMap<String, String>> hsArray = ZABAction.parseJSON(variations);
					int size = hsArray.size();
					for(int i=0; i<size; i++) {
						HashMap<String, String> hs1 = hsArray.get(i);
						Boolean isUpdateReq = hs1.containsKey(ZABConstants.LINKNAME);
						hs1.put(VariationConstants.EXPERIMENT_LINKNAME, linkName);
						VariationRequest.validate(hs1, isUpdateReq?"PUT":"POST"); //No I18N
						if(hs1.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs1.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
							throw new ZABException(hs1.get(ZABConstants.RESPONSE_STRING));
						} else {
							//Validate variation traffic allocation
							if(isUpdateReq) {
								Variation v = Variation.updateVariation(hs1, Boolean.FALSE);
								if(!v.getSuccess()) {
									throw new ZABException(v.getResponseString());
								}

							} 
							//							else {
							//								Variation.createVariation(hs1, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
							//							}
						}
					}
					//					Moving it below the transaction commit which makes more sense
					//					Float totalTraffic  = Variation.getTotalTrafficAllocationOfExperiment(experimentId);
					//					if(!totalTraffic.equals(100f)){
					//						if(mgr!=null) {
					//							try {
					//								mgr.rollback();
					//							} catch (Exception e1) {
					//								LOGGER.log(Level.SEVERE,"Exception Occurred",e1);
					//							}
					//						}
					//
					//						experiment = new Experiment();
					//						experiment.setSuccess(Boolean.FALSE);
					//						experiment.setResponseString(ZABAction.getMessage(ZABConstants.TRAFFIC_ALLOCATION_ERROR));
					//						return experiment;
					//
					//					}	


				} catch (JSONException e) {
					throw new ZABException(ZABAction.getMessage(ZABConstants.INVALID_JSON));
				}
			}

			if(!alreadyInTransaction) {				
				mgr.commit();
			}

			//Get the latest ABSPLit values
			setABSplitHeatmapExperimentDetails(experiment);
			absplitExperiment = new ABSplitExperiment(experiment);
			Row latestABSplitRow = getABSplitExperimentRow(experimentId);
			getABSplitExperimentFromRow(latestABSplitRow, absplitExperiment);
			
			//If experiment is started or scheduled validate if required fields are valid.
			if(absplitExperiment.getExperimentStatus().equals(ExperimentStatus.RUNNING.getStatusCode()) || absplitExperiment.getExperimentStatus().equals(ExperimentStatus.SCHEDULED.getStatusCode())) {
				Float totalTraffic  = Variation.getTotalTrafficAllocationOfExperiment(experimentId);
				if(!totalTraffic.equals(100f)){
					//					if(mgr!=null) {
					//						try {
					//							mgr.rollback();
					//						} catch (Exception e1) {
					//							LOGGER.log(Level.SEVERE,"Exception Occurred",e1);
					//						}
					//					}
					throw new ZABException(ZABAction.getMessage(ZABConstants.TRAFFIC_ALLOCATION_ERROR));
					//					experiment = new Experiment();
					//					experiment.setSuccess(Boolean.FALSE);
					//					experiment.setResponseString(ZABAction.getMessage(ZABConstants.TRAFFIC_ALLOCATION_ERROR));
					//					return experiment;

				}	
			}
			
			//Notify event
			ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
			wrapper.setModel(absplitExperiment);
			
//			if (hs.containsKey(ExperimentConstants.IS_ACTIVE)
//					|| (hs.containsKey(ExperimentConstants.EXPERIMENT_STATUS) && (ExperimentStatus.PAUSED
//							.getStatusCode()
//							.equals(Integer.parseInt(hs
//									.get(ExperimentConstants.EXPERIMENT_STATUS))) || ExperimentStatus.RUNNING
//							.getStatusCode()
//							.equals(Integer.parseInt(hs
//									.get(ExperimentConstants.EXPERIMENT_STATUS)))))) {
//			   //Flag to update CDN only is the status is changed to paused or running
//			   wrapper.setCustomObject(true);
//			}
			wrapper.setChangeSets(hs);
			wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
			wrapper.setType(OperationType.UPDATE);
			ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);

			
			//Event Activity Log
			HashMap<String, String> updatedValues = new HashMap<String, String>();
			updatedValues.putAll(hs);
			updatedValues.put(EventActivityConstants.EXPERIMENT_ID, experimentId.toString());
			if(ZABUtil.getCurrentUser() != null)
			{
				updatedValues.put(EventActivityConstants.USER_ID, ZABUtil.getCurrentUser().getUserId().toString());
			}
			updatedValues.put(EventActivityConstants.TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
			EventActivityWrapper activityWrapper = new EventActivityWrapper();
			activityWrapper.setModule(Module.EXPERIMENT);
			activityWrapper.setOperationType(com.zoho.abtest.eventactivity.EventActivityConstants.OperationType.UPDATE);
			activityWrapper.setDbSpace(ZABUtil.getCurrentUserDbSpace());
			activityWrapper.setUpdatedValues(updatedValues);
			activityWrapper.setOldValues(oldValues);
			ZABNotifier.notifyListeners(EventActivityConstants.EVENT_MODULE_NAME, activityWrapper);

		} catch (ResourceNotFoundException | ZABException e) {
			absplitExperiment = new ABSplitExperiment();
			absplitExperiment.setSuccess(Boolean.FALSE);
			absplitExperiment.setResponseString(e.getMessage());
			if(e instanceof ResourceNotFoundException) {
				absplitExperiment.setResponseCode(((ResourceNotFoundException) e).getErrorCode());
			}
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
			if(mgr!=null && !alreadyInTransaction) {
				try {
					mgr.rollback();
				} catch (Exception e1) {
					LOGGER.log(Level.SEVERE,"Exception Occurred",e1);
				}
			}
		} catch (Exception e) {
			absplitExperiment = new ABSplitExperiment();
			absplitExperiment.setSuccess(Boolean.FALSE);
			absplitExperiment.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			if(mgr!=null && !alreadyInTransaction) {
				try {
					mgr.rollback();
				} catch (Exception e1) {
					LOGGER.log(Level.SEVERE,"Exception Occurred",e1);
				}
			}
		}
		return absplitExperiment;
	}

	public static ABSplitExperiment getABSplitExperimentDetailsByLinkname(String linkName) {
		ABSplitExperiment experiment = null;
		try {
			Criteria c = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_LINK_NAME), linkName, QueryConstants.EQUAL);
			Join join0=new Join(EXPERIMENT.TABLE,ABSPLITEXPERIMENT.TABLE,new String[]{EXPERIMENT.EXPERIMENT_ID},new String[]{ABSPLITEXPERIMENT.EXPERIMENT_ID},Join.INNER_JOIN);
			Join join1=new Join(EXPERIMENT.TABLE,VARIATION.TABLE,new String[]{EXPERIMENT.EXPERIMENT_ID},new String[]{VARIATION.EXPERIMENT_ID},Join.INNER_JOIN);
			Join join2=new Join(EXPERIMENT.TABLE,PROJECT.TABLE,new String[]{EXPERIMENT.PROJECT_ID},new String[]{PROJECT.PROJECT_ID},Join.INNER_JOIN);

			//Join join3 = new Join(VARIATION.TABLE,VARIATION_VISITS.TABLE,new String[]{VARIATION.VARIATION_ID},new String[]{VARIATION_VISITS.VARIATION_ID},Join.LEFT_JOIN);

			SortColumn sort = new SortColumn(new Column(VARIATION.TABLE, VARIATION.VARIATION_ID), Boolean.TRUE);
			DataObject dobj = getRow(EXPERIMENT.TABLE, c, sort, new Join[] {join0,join1, join2});
			Row expRow = dobj.getFirstRow(EXPERIMENT.TABLE);
			if(expRow != null)
			{
				Row abExpRow = dobj.getFirstRow(ABSPLITEXPERIMENT.TABLE);
				experiment = getABSplitExperimentFromRow(expRow, abExpRow);
				experiment.setProjectLinkname(Project.getProjectLinkname(dobj, experiment.getProjectId()));
				if(dobj.containsTable(VARIATION.TABLE)) {
					Criteria c2 = new Criteria(new Column(VARIATION.TABLE, VARIATION.EXPERIMENT_ID), experiment.getExperimentId(), QueryConstants.EQUAL);
					Iterator it2 = dobj.getRows(VARIATION.TABLE, c2);
					while(it2.hasNext()) {
						Row row2 = (Row)it2.next();
						Variation variation = Variation.getVariationFromRow(row2);
						/*if(dobj.containsTable(VARIATION_VISITS.TABLE))
						{
							Criteria c3 = new Criteria(new Column(VARIATION_VISITS.TABLE, VARIATION_VISITS.VARIATION_ID), variation.getVariationId(), QueryConstants.EQUAL);
							Iterator it3 = dobj.getRows(VARIATION_VISITS.TABLE, c3);
							if(it3.hasNext())
							{
								Row row3 = (Row)it3.next();
								variation.setUniqueVisitors((Long)row3.get(VARIATION_VISITS.UNIQUE_VISITOR_COUNT));
							}
						}*/
						variation.setExperimentLinkname(experiment.getExperimentLinkname());
						experiment.getVariations().add(variation);
					}
				}
				
				setABSplitHeatmapExperimentDetails(experiment);
				experiment.setPrimaryGoal(ExperimentGoal.getPrimaryGoalLNameofExperiment(experiment.getExperimentId()));
				//Experiment.setVisitorCountForExperiment(experiment.getExperimentId(), experiment);
				//ABSplitExperiment.setExpVisitorCountFromVariation(experiment);
				ABSplitExperiment.setVisitorCountForExperiment(experiment);
				//Get active duration
				Long timeGapinMillis = Experiment.getActiveDurationOfExp(experiment.getExperimentId());
				String activeDuration = Experiment.getActiveDurationOfExpString(timeGapinMillis);
				experiment.setActiveDuration(activeDuration);
			}
		} catch (Exception e) {
			experiment = new ABSplitExperiment();
			experiment.setSuccess(Boolean.FALSE);
			experiment.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return experiment;
	}
	
	public static ABSplitExperiment getABSplitExperimentMeta(String linkName) {
		ABSplitExperiment experiment = null;
		final List<ABSplitExperiment> experiments = new ArrayList<ABSplitExperiment>();
		try {
			Criteria c = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_LINK_NAME), linkName, QueryConstants.EQUAL);
			Join join0=new Join(EXPERIMENT.TABLE,ABSPLITEXPERIMENT.TABLE,new String[]{EXPERIMENT.EXPERIMENT_ID},new String[]{ABSPLITEXPERIMENT.EXPERIMENT_ID},Join.INNER_JOIN);
			Join join2=new Join(EXPERIMENT.TABLE,VARIATION.TABLE,new String[]{EXPERIMENT.EXPERIMENT_ID},new String[]{VARIATION.EXPERIMENT_ID},Join.LEFT_JOIN);
			Join join3=new Join(EXPERIMENT.TABLE,EXPERIMENT_GOAL.TABLE,new String[]{EXPERIMENT.EXPERIMENT_ID},new String[]{EXPERIMENT_GOAL.EXPERIMENT_ID},Join.LEFT_JOIN);
			
			Column variationCount = new Column(VARIATION.TABLE, VARIATION.VARIATION_ID).distinct().count();
			variationCount.setColumnAlias(ExperimentConstants.VARIATION_COUNT);
			Column goalCount = new Column(EXPERIMENT_GOAL.TABLE, EXPERIMENT_GOAL.EXPERIMENT_GOAL_ID).distinct().count();
			goalCount.setColumnAlias(ExperimentConstants.GOAL_COUNT);
			SelectQuery query = new SelectQueryImpl(new Table(EXPERIMENT.TABLE));
			
			//Add experiment table constants
			query.addSelectColumns(getColumnsWithAliasPrefix(ExperimentConstants.EXPERIMENT_TABLE, EXPERIMENT.TABLE+".", EXPERIMENT.TABLE));
			
			//Add AB Split experiment table constants
			query.addSelectColumns(getColumnsWithAliasPrefix(ExperimentConstants.ABSPLITEXPERIMENT_TABLE, ABSPLITEXPERIMENT.TABLE+".", ABSPLITEXPERIMENT.TABLE));
			
			query.addSelectColumn(variationCount);
			query.addSelectColumn(goalCount);
			query.addJoin(join0);
			query.addJoin(join2);
			query.addJoin(join3);
			query.setCriteria(c);
			
			GroupByClause gc = new GroupByClause(Arrays.asList(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_ID),new Column(ABSPLITEXPERIMENT.TABLE, ABSPLITEXPERIMENT.EXPERIMENT_ID)));
			query.setGroupByClause(gc);

			ZABUserBean bean= (ZABUserBean)BeanUtil.lookup(ZABUserBean.BEAN_NAME, ZABUtil.getCurrentUserDbSpace());
			bean.executeQuery(query, new DataSetWrapper() {
				@Override
				public void execute(DataSet ds) throws Exception {
					if(ds.next()) {		
						ABSplitExperiment exp = getABSplitExperimentFromDataSet(ds, EXPERIMENT.TABLE+".");
						experiments.add(exp);
					}
				}
			});

			if(experiments.get(0) != null)
			{
				experiment = experiments.get(0);
			}
			
			ABSplitExperiment.setVisitorCountForExperiment(experiment);
			ABSplitExperiment.getExperimentWinners(experiment);

		}
		catch (ZABException e) {
			experiment = new ABSplitExperiment();
			experiment.setSuccess(Boolean.FALSE);
			experiment.setResponseString(e.getMessage());
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		catch (Exception e) {
		    experiment = new ABSplitExperiment();
			experiment.setSuccess(Boolean.FALSE);
			experiment.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return experiment;
	}
	
	public static void getExperimentWinners(final ABSplitExperiment experiment) throws Exception{
		
		Boolean isWinner = Boolean.FALSE;
		String winnerVariationLinkName = null;
		if(experiment.variationCount <=1){
			return;
		}
		
		String priGoalLinkName = ExperimentGoal.getPrimaryGoalLNameofExperiment(experiment.getExperimentId());
		Goal priGoal = Goal.getGoalByLinkname(priGoalLinkName);
		if(priGoal==null){
			return;
		}
		Integer goalType= priGoal.getGoalTypeTag();
		
		ArrayList<ReportStatistics> result = ElasticSearchStatistics.getOverviewReport(experiment.getExperimentLinkname());
		
		for(int i=0;i<result.size();i++){
			ReportStatistics  repo = result.get(i);
			if(repo.getGoalId().equals(priGoal.getGoalId())){
				if(goalType.equals(GoalType.REVENUE_GOAL.getGoalTypeId())){
					/*Integer decision = repo.getRevenue().getRevPerVisitorDecision();
					if(decision == DecisionType.WINNER.getDecisionTypeId() ){
						isWinner = Boolean.TRUE;
					}*/
					Boolean winnerpresent = repo.getRevenue().getRevPerVisitorIsWinner();
					if(winnerpresent!=null && winnerpresent){
						isWinner = Boolean.TRUE;
						winnerVariationLinkName = repo.getVariationLinkName();
						experiment.setWinningVariation(winnerVariationLinkName);
						break;
					}
				}else{
					/*Integer decision = repo.getDecision();
					if(decision == DecisionType.WINNER.getDecisionTypeId() ){
						isWinner = Boolean.TRUE;
					}*/
					Boolean winnerpresent = repo.getIsWinner();
					if(winnerpresent!=null && winnerpresent){
						isWinner = Boolean.TRUE;
						winnerVariationLinkName = repo.getVariationLinkName();
						experiment.setWinningVariation(winnerVariationLinkName);
						break;
					}
				}
				//break;
			}
		}
		
		experiment.setIsWinnerDeclared(isWinner);
		
	}
	
	public static ABSplitExperiment addDuplicateABSplitExperimentRow(Row row, ABSplitExperiment experiment) throws Exception {
		DataObject wdobj = new WritableDataObject();
		Row newERow = new Row(ABSPLITEXPERIMENT.TABLE);
		newERow.set(ABSPLITEXPERIMENT.EXPERIMENT_ID, experiment.getExperimentId());
		newERow.set(ABSPLITEXPERIMENT.EXPERIMENT_URL, (String)row.get(ABSPLITEXPERIMENT.EXPERIMENT_URL));
		newERow.set(ABSPLITEXPERIMENT.EXCLUDE_URLS, (String)row.get(ABSPLITEXPERIMENT.EXCLUDE_URLS));
		newERow.set(ABSPLITEXPERIMENT.INCLUDE_URLS, (String)row.get(ABSPLITEXPERIMENT.INCLUDE_URLS));
		newERow.set(ABSPLITEXPERIMENT.CONVERSION_RATE, (Integer)row.get(ABSPLITEXPERIMENT.CONVERSION_RATE));
		newERow.set(ABSPLITEXPERIMENT.DAILY_VISITORS, (Long)row.get(ABSPLITEXPERIMENT.DAILY_VISITORS));
		newERow.set(ABSPLITEXPERIMENT.EXPECTED_IMPROVEMENT, (Integer)row.get(ABSPLITEXPERIMENT.EXPECTED_IMPROVEMENT));
		newERow.set(ABSPLITEXPERIMENT.SIGNIFICANCE_LEVEL, (Integer)row.get(ABSPLITEXPERIMENT.SIGNIFICANCE_LEVEL));
		newERow.set(ABSPLITEXPERIMENT.PERMITTED_TRAFFIC, (Integer)row.get(ABSPLITEXPERIMENT.PERMITTED_TRAFFIC));
		newERow.set(ABSPLITEXPERIMENT.IS_HEATMAP_ENABLED, (Boolean)row.get(ABSPLITEXPERIMENT.IS_HEATMAP_ENABLED));
		newERow.set(ABSPLITEXPERIMENT.REDIRECT_PARAMS, (Boolean)row.get(ABSPLITEXPERIMENT.REDIRECT_PARAMS));
		newERow.set(ABSPLITEXPERIMENT.GLOBAL_JS, (String)row.get(ABSPLITEXPERIMENT.GLOBAL_JS));
		newERow.set(ABSPLITEXPERIMENT.GLOBAL_CSS, (String)row.get(ABSPLITEXPERIMENT.GLOBAL_CSS));
		wdobj.addRow(newERow);
		updateDataObject(wdobj);
		return getABSplitExperimentFromRow(newERow, experiment);
	}
	
	public static ABSplitExperiment duplicateABSplitExperiment(String linkname) {
		ABSplitExperiment absplitExperiment = null;
		TransactionManager mgr = DataAccess.getTransactionManager();
		try {		
			Criteria c = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_LINK_NAME), linkname, QueryConstants.EQUAL);
			DataObject dobj = getPersonality(ExperimentConstants.EXPERIMENT_DETAIL_PERSONALITY, c);
			if(dobj.containsTable(EXPERIMENT.TABLE)) {
				
				mgr.begin();
				
				Experiment experiment = Experiment.duplicateExperiment(dobj);
				
				if(experiment != null && experiment.getExperimentId() != null)
				{
					Row absplitRow = dobj.getRow(ABSPLITEXPERIMENT.TABLE);
					absplitExperiment = new ABSplitExperiment(experiment);
					
					//Add abtestSPlit experiment row
					addDuplicateABSplitExperimentRow(absplitRow, absplitExperiment);
					
					//Add variation row
					Iterator variationIterator = dobj.getRows(VARIATION.TABLE);
					ArrayList<Row> variationRows = new ArrayList<Row>();
					while(variationIterator.hasNext()) {
						Row vrow = (Row)variationIterator.next();
						variationRows.add(vrow);
					}
					//Sorting the row for preserving order
					Collections.sort(variationRows, new Comparator<Row>() {
						@Override
						public int compare(Row o1, Row o2) {

							return (Long)o1.get(VARIATION.VARIATION_ID) > (Long)o2.get(VARIATION.VARIATION_ID)?1:-1;
						}
					});

					int vrsize = variationRows.size();
					for(int k=0; k<vrsize; k++) {
						Row vrow = variationRows.get(k);
						Variation.addDuplicateVariationRow(vrow, absplitExperiment);
					}
					absplitExperiment.setVariationCount(absplitExperiment.getVariations().size());
					//Add goal row
					Iterator goalIterator = dobj.getRows(EXPERIMENT_GOAL.TABLE);
					int gcount = 0;
					while(goalIterator.hasNext()) {
						Row egrow = (Row)goalIterator.next();
						Boolean isPrimaryGoal = (Boolean)egrow.get(EXPERIMENT_GOAL.IS_PRIMARY_GOAL);
						Long goalId = (Long)egrow.get(EXPERIMENT_GOAL.GOAL_ID);
						Goal goal = Goal.addDuplicateGoalRow(goalId);
						if(goal!=null) {						
							ExperimentGoal.createExperimentGoalWithoutEventTrigger(absplitExperiment.getExperimentId(), goal.getGoalId(), isPrimaryGoal);
						}
						gcount++;
					}
					absplitExperiment.setGoalsCount(gcount);
					

					//Duplicating heatmap experiment
					HashMap<String, String> heatmap = ABSplitExperiment.generateHashMapFromAbSplitExperimentObjForHeatmapExp(experiment,new HashMap<String, String>());
					heatmap.put(HeatmapConstants.HEATMAP_ENABLED_EXPERIMENT_ID.toLowerCase(),experiment.getExperimentId().toString());
					HeatmapExperiment hmExp = ExperimentEnabledHeatmap.createEnabledHeatmapExperiment(heatmap);
					if(!hmExp.getSuccess()) {
						throw new ZABException("Exception occured while creating heatmap enabled for A/B"); //NO I18N
					}
				}
				//Done have to trigger event to update javascript here as the status of this experiment will be in draft

				mgr.commit();
				
			} else {
				absplitExperiment = new ABSplitExperiment();
				absplitExperiment.setSuccess(Boolean.FALSE);
				absplitExperiment.setResponseString(ZABAction.getMessage(ZABConstants.ErrorMessages.RESOURCE_NOT_FOUND.getErrorString(),new String[]{ExperimentConstants.API_MODULE}));
				return absplitExperiment;
			}
			
			ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
			ServiceOrg currentServiceOrg = IAMUtil.getCurrentServiceOrg();
			if(currentServiceOrg != null)
			{
				wrapper.setZsoid(currentServiceOrg.getZSOID()+"");
			}
			wrapper.setModel(absplitExperiment);
			wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
			wrapper.setType(OperationType.CREATE);
			ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);
		} catch (Exception e) {
			try
			{
				mgr.rollback();
			}
			catch(Exception e1)
			{
				LOGGER.log(Level.SEVERE,"Exception Occurred",e1);
			}
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
			absplitExperiment = new ABSplitExperiment();
			absplitExperiment.setSuccess(Boolean.FALSE);
			absplitExperiment.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
		}

		return absplitExperiment;
	}
	
	public static HashMap<String,String> generateHashMapFromAbSplitExperimentObj(ABSplitExperiment exp, HashMap<String,String> hs) {
		HashMap<String,String> oldValues = new HashMap<String,String>();
		try
		{

			for(String attributeName:EventActivityConstants.ABSPLIT_EXPERIMENT_ATTR_TO_TRACE)
			{
				if(hs.containsKey(attributeName))
				{
					switch(attributeName)
					{
					case ExperimentConstants.EXPERIMENT_URL:
						oldValues.put(ExperimentConstants.EXPERIMENT_URL, exp.getExperimentUrl());
						break;
					case ExperimentConstants.PERMITTED_TRAFFIC:
						oldValues.put(ExperimentConstants.PERMITTED_TRAFFIC, exp.getPermittedTraffic().toString());
						break;
					case ExperimentConstants.STATISTICAL_SIGNIFICANCE:
						oldValues.put(ExperimentConstants.STATISTICAL_SIGNIFICANCE, exp.getStatisticalSignificance().toString());
						break;
					case ExperimentConstants.IS_HEATMAP_ENABLED:
						oldValues.put(ExperimentConstants.IS_HEATMAP_ENABLED, exp.getIsHeatmapEnabled().toString());
						break;
					}
				}
			}
			oldValues.put(ExperimentConstants.EVENT_EXPERIMENT_TYPE, ExperimentType.ABTEST.getTypeNumber().toString());
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		return oldValues;
	}
	
	public static HashMap<String,String> generateHashMapFromAbSplitExperimentObjForHeatmapExp(Experiment exp,HashMap<String,String> expHs) {
		HashMap<String,String> hs = new HashMap<String,String>();
		try
		{
			hs.put(ExperimentConstants.EXPERIMENT_NAME, exp.getExperimentName());
			hs.put(ExperimentConstants.EXPERIMENT_STATUS, ExperimentStatus.DRAFT.getStatusCode().toString());
			hs.put(ExperimentConstants.EXPERIMENT_TYPE, ExperimentType.ENABLED_HEATMAP.getTypeNumber().toString());
			hs.put(ExperimentConstants.PROJECT_LINKNAME, exp.getProjectLinkname());
			if(exp.getProjectId()!=null) {				
				hs.put(ExperimentConstants.PROJECT_ID, exp.getProjectId().toString());
			}
			if(expHs.containsKey(ExperimentConstants.HEATMAP_MAX_VISITORS)){
				hs.put(HeatmapExperimentConstants.MAX_VISITORS, expHs.get(ExperimentConstants.HEATMAP_MAX_VISITORS));
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		return hs;
	}

	
}
