//$Id$
package com.zoho.abtest.experiment;

import java.util.Iterator;
import java.util.logging.Level;

import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.OperationInfo;
import com.adventnet.persistence.Row;
import com.zoho.abtest.AUDIENCE;
import com.zoho.abtest.ELEMENT_CLICK_GOAL;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.EXPERIMENT_AUDIENCE;
import com.zoho.abtest.EXPERIMENT_GOAL;
import com.zoho.abtest.FORM_SUBMIT_GOAL;
import com.zoho.abtest.GOAL;
import com.zoho.abtest.LINK_CLICK_GOAL;
import com.zoho.abtest.PAGE_VISIT_GOAL;
import com.zoho.abtest.VARIATION;
import com.zoho.abtest.audience.Audience;
import com.zoho.abtest.goal.Goal;
import com.zoho.abtest.goal.GoalConstants;
import com.zoho.abtest.project.ProjectJSONService;
import com.zoho.abtest.variation.Variation;

import java.util.logging.Level;
import java.util.logging.Logger;

public class ExperimentEventHandler {
	
	private static final Logger LOGGER = Logger.getLogger(ExperimentEventHandler.class.getName());
	
	public static void handleUpdateGoalEvent(String tableName, DataObject dobj) throws DataAccessException {
		Iterator it = dobj.getRows(tableName);
		while(it.hasNext()) {
			Row row = (Row)it.next();
			Long goalId = (Long)row.get(GoalConstants.GOAL_ID_INITIAL);
			if(Goal.isExperimentGoal(goalId)) {								
				Goal goal = Goal.getGoalByGoalId(goalId);
				if (goal!=null) {
					Long projectId = goal.getProjectId();
//					ProjectJSONService.updateEntity(goal, projectId);
				}
			}
			
		}
	}
	
	public static synchronized void doHandle(DataObject dobj, int operationType) {
	
		
		try {
			switch (operationType) {
				case OperationInfo.ADD:
//					if(dobj.containsTable(EXPERIMENT.TABLE)) {
//						//Add exp json
//						//get experiment id
//					}
					
					if(dobj.containsTable(EXPERIMENT_AUDIENCE.TABLE)) {
						//find audience row by audience id
						//get project id from audience row
						//update experiment json
						Iterator it = dobj.getRows(EXPERIMENT_AUDIENCE.TABLE);
						while(it.hasNext()) {
							Row row = (Row)it.next();
							Long audienceId = (Long)row.get(EXPERIMENT_AUDIENCE.AUDIENCE_ID);
							Long experimentId = (Long)row.get(EXPERIMENT_AUDIENCE.EXPERIMENT_ID);
							Audience audience = Audience.getAudienceById(audienceId,null);
							if(audience!=null) {								
								Long projectId = audience.getProjectId();
//								ProjectJSONService.addEntity(audience, projectId, experimentId);
							}
						}
					}
					
					if(dobj.containsTable(EXPERIMENT_GOAL.TABLE)) {
						//find goal row by goal id
						//get project id from goal row
						//update experiment json
						Iterator it = dobj.getRows(EXPERIMENT_GOAL.TABLE);
						while(it.hasNext()) {
							Row row = (Row)it.next();
							Long goalId = (Long)row.get(EXPERIMENT_GOAL.GOAL_ID);
							Long experimentId = (Long)row.get(EXPERIMENT_AUDIENCE.EXPERIMENT_ID);
							Goal goal = Goal.getGoalByGoalId(goalId);
							if(goal!=null) {
								Long projectId = goal.getProjectId();
//								ProjectJSONService.addEntity(goal, projectId, experimentId);
							}
						}
					}
					
					if(dobj.containsTable(VARIATION.TABLE)) {
						//get experiment row to get project id
						//update experiment json
						Iterator it = dobj.getRows(VARIATION.TABLE);
						while(it.hasNext()) {
							Row row = (Row)it.next();
							Long experimentId = (Long)row.get(VARIATION.EXPERIMENT_ID);
							Variation variation = Variation.getVariationFromRow(row);
							if(variation!=null) {								
								Long projectId = variation.getProjectIdForVariation();
								if(projectId!=null) {
//									ProjectJSONService.addEntity(variation, projectId, experimentId);
								}
							}
						}
					}
					
					break;
				case OperationInfo.UPDATE:
					//Experiment changes
//					if(dobj.containsTable(EXPERIMENT.TABLE)) {
//						//update exp json
//					}
					
					//Goal changes
					if(dobj.containsTable(GOAL.TABLE)) {
						//check whether the goal is associated with any 
						//find all experiments using this goal and update the experiment json
						Iterator it = dobj.getRows(GOAL.TABLE);
						while(it.hasNext()) {							
							Row row = (Row)it.next();
							Long goalId = (Long)row.get(GOAL.GOAL_ID);
							if(Goal.isExperimentGoal(goalId)) {
								Goal goal = Goal.getGoalFromRow(row);
//								ProjectJSONService.updateEntity(goal, goal.getProjectId());
							}
						}
					}
					
					if(dobj.containsTable(PAGE_VISIT_GOAL.TABLE)) {
						//find all experiments using this goal and update the experiment json
						handleUpdateGoalEvent(PAGE_VISIT_GOAL.TABLE, dobj);
					}
					
					if(dobj.containsTable(LINK_CLICK_GOAL.TABLE)) {
						//find all experiments using this goal and update the experiment json
						handleUpdateGoalEvent(LINK_CLICK_GOAL.TABLE, dobj);
					}
					
					if(dobj.containsTable(FORM_SUBMIT_GOAL.TABLE)) {
						//find all experiments using this goal and update the experiment json
						handleUpdateGoalEvent(FORM_SUBMIT_GOAL.TABLE, dobj);
					}
					
					if(dobj.containsTable(ELEMENT_CLICK_GOAL.TABLE)) {
						//find all experiments using this goal and update the experiment json
						handleUpdateGoalEvent(ELEMENT_CLICK_GOAL.TABLE, dobj);
					}
					
					//Variation changes
					if(dobj.containsTable(VARIATION.TABLE)) {
						//find the experiment with variation and update it
						Iterator it = dobj.getRows(VARIATION.TABLE);
						while (it.hasNext()) {
							Row row = (Row)it.next();
							Long experimentId = (Long)row.get(VARIATION.EXPERIMENT_ID);
							Experiment experiment = Experiment.getExperimentById(experimentId);
							if(experiment!=null) {
								Variation variation = Variation.getVariationFromRow(row);
//								ProjectJSONService.updateEntity(variation, experiment);
								
							}
						}
					}
					
					if(dobj.containsTable(AUDIENCE.TABLE)) {
						//find the experiment with audience and update it
						Iterator it = dobj.getRows(AUDIENCE.TABLE);
						while(it.hasNext()) {
							Row row = (Row)it.next();
						}
					}
					
					break;
				case OperationInfo.DELETE:
					
					
					break;
				default:
					break;
			}
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		
		
	}
}
