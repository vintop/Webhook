//$Id$
package com.zoho.abtest.experiment;

import java.net.URI;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transaction;
import javax.transaction.TransactionManager;

import org.json.JSONArray;
import org.json.JSONObject;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.DataSet;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.ds.query.SelectQueryImpl;
import com.adventnet.ds.query.SortColumn;
import com.adventnet.ds.query.Table;
import com.adventnet.iam.IAMUtil;
import com.adventnet.iam.User;
import com.adventnet.mfw.bean.BeanUtil;
import com.adventnet.persistence.DataAccess;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.persistence.WritableDataObject;
import com.zoho.abtest.ABSPLITEXPERIMENT;
import com.zoho.abtest.EVENT_ACTIVITY_LOG;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.EXPERIMENT_AUDIENCE;
import com.zoho.abtest.EXPERIMENT_DYNAMIC_ATTR;
import com.zoho.abtest.EXPERIMENT_PROJECT_INTEGRATION;
import com.zoho.abtest.GOOGLE_ANALYTICS_DETAILS;
import com.zoho.abtest.HEATMAP_EXPERIMENT;
import com.zoho.abtest.PROJECT;
import com.zoho.abtest.PROJECT_USER_ROLE;
import com.zoho.abtest.SHARED_REPORT_DETAILS;
import com.zoho.abtest.adminconsole.AdminConsoleConstants;
import com.zoho.abtest.adminconsole.AdminConsoleConstants.AcOperationType;
import com.zoho.abtest.adminconsole.AdminConsoleWrapper;
import com.zoho.abtest.audience.ExperimentAudience;
import com.zoho.abtest.common.MatchType;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.dimension.DynamicAttributes;
import com.zoho.abtest.dimension.ExperimentDynamicAttribute;
import com.zoho.abtest.eventactivity.EventActivityConstants;
import com.zoho.abtest.eventactivity.EventActivityConstants.EventType;
import com.zoho.abtest.eventactivity.EventActivityConstants.Module;
import com.zoho.abtest.eventactivity.EventActivityWrapper;
import com.zoho.abtest.eventactivity.EventModuleDetail;
import com.zoho.abtest.exception.ResourceNotFoundException;
import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentStatus;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentType;
import com.zoho.abtest.experimentschedule.ExperimentSchedule;
import com.zoho.abtest.experimentschedule.ExperimentScheduleConstants;
import com.zoho.abtest.experimentschedule.ExperimentScheduleConstants.ExperimentScheduleType;
import com.zoho.abtest.heatmaps.ExperimentEnabledHeatmap;
import com.zoho.abtest.heatmaps.HeatmapConstants;
import com.zoho.abtest.heatmaps.HeatmapExperiment;
import com.zoho.abtest.integration.Integration;
import com.zoho.abtest.license.PortalLicenseMapping;
import com.zoho.abtest.listener.ZABNotifier;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.project.ProjectConstants;
import com.zoho.abtest.project.ProjectConstants.ProjectStatus;
import com.zoho.abtest.project.ProjectTreeEventConstants;
import com.zoho.abtest.project.ProjectTreeEventConstants.OperationType;
import com.zoho.abtest.project.ProjectTreeEventWrapper;
import com.zoho.abtest.search.SearchConstants;
import com.zoho.abtest.user.Feature;
import com.zoho.abtest.user.FeatureConstants.AppFeatures;
import com.zoho.abtest.user.ZABUser;
import com.zoho.abtest.user.ZABUserDetailWrapper;
import com.zoho.abtest.utility.ApplicationProperty;
import com.zoho.abtest.utility.DataSetWrapper;
import com.zoho.abtest.utility.ZABUserBean;
import com.zoho.abtest.utility.ZABUtil;

public class Experiment extends ZABModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final Logger LOGGER = Logger.getLogger(Experiment.class.getName());

	private Long experimentId;

	private Long projectId;

	private String experimentName;

	private Long createBy;

	private String createdByName;

	private String experimentKey;

	private String experimentLinkname;

	private Integer experimentType;

	private Integer experimentStatus;

	private Integer duration;

	private Long startDate;

	private Long endDate;

	private Long actualStartTime;

	private Long actualEndTime;

	private Long createdTime;

	private Long modifiedTime;

	private Boolean isActive;

	private String projectLinkname;

	private String smallThumbnailUrl;

	private String largeThumbnailUrl;
	
	private Boolean isHeatmapActive;
	
	private Integer maxHeatmapVisitorsCount;
	
	private String activeDuration;
	
	private Integer activationMode;
	
	private String activationCondition;

    private Boolean makePublic;
	
	private String shareUrl;



	public Boolean getIsHeatmapActive() {
		return isHeatmapActive;
	}

	public void setIsHeatmapActive(Boolean isHeatmapActive) {
		this.isHeatmapActive = isHeatmapActive;
	}
	
	public Integer getMaxHeatmapVisitorsCount() {
		return maxHeatmapVisitorsCount;
	}

	public void setMaxHeatmapVisitorsCount(Integer maxHeatmapVisitorsCount) {
		this.maxHeatmapVisitorsCount = maxHeatmapVisitorsCount;
	}
	
	public String getActiveDuration() {
		return activeDuration;
	}
	public void setActiveDuration(String activeDuration) {
		this.activeDuration = activeDuration;
	}
	public Long getActualStartTime() {
		return actualStartTime;
	}
	public void setActualStartTime(Long actualStartTime) {
		this.actualStartTime = actualStartTime;
	}
	public Long getActualEndTime() {
		return actualEndTime;
	}
	public void setActualEndTime(Long actualEndTime) {
		this.actualEndTime = actualEndTime;
	}
	public Boolean getIsActive() {
		return isActive;
	}
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	public Long getCreateBy() {
		return createBy;
	}
	public void setCreateBy(Long createBy) {
		this.createBy = createBy;
	}
	public String getCreatedByName() {
		return createdByName;
	}
	public void setCreatedByName(String createdByUser) {
		this.createdByName = createdByUser;
	}
	public String getProjectLinkname() {
		return projectLinkname;
	}
	public void setProjectLinkname(String projectLinkname) {
		this.projectLinkname = projectLinkname;
	}
	public String getExperimentKey() {
		return experimentKey;
	}
	public void setExperimentKey(String experimentKey) {
		this.experimentKey = experimentKey;
	}
	public Long getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(Long createdTime) {
		this.createdTime = createdTime;
	}
	public Long getModifiedTime() {
		return modifiedTime;
	}
	public void setModifiedTime(Long modifiedTime) {
		this.modifiedTime = modifiedTime;
	}
	public Long getProjectId() {
		return projectId;
	}
	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}
	public String getExperimentLinkname() {
		return experimentLinkname;
	}
	public void setExperimentLinkname(String experimentLinkname) {
		this.experimentLinkname = experimentLinkname;
	}
	public Long getExperimentId() {
		return experimentId;
	}
	public void setExperimentId(Long experimentId) {
		this.experimentId = experimentId;
	}
	public String getExperimentName() {
		return experimentName;
	}
	public void setExperimentName(String experimentName) {
		this.experimentName = experimentName;
	}
	public Integer getExperimentType() {
		return experimentType;
	}
	
	public ExperimentType getExperimentTypeEnum() {
		if(this.experimentType!=null) {
			return ExperimentType.getExperimentTypeByNumber(this.experimentType);
		}
		return null;
	}
	
	public void setExperimentType(Integer experimentType) {
		this.experimentType = experimentType;
	}
	public Integer getExperimentStatus() {
		return experimentStatus;
	}
	public void setExperimentStatus(Integer experimentStatus) {
		this.experimentStatus = experimentStatus;
	}
	public Integer getDuration() {
		return duration;
	}
	public void setDuration(Integer duration) {
		this.duration = duration;
	}
	public Long getStartDate() {
		return startDate;
	}
	public void setStartDate(Long startDate) {
		this.startDate = startDate;
	}
	public Long getEndDate() {
		return endDate;
	}
	public void setEndDate(Long endDate) {
		this.endDate = endDate;
	}
	public String getSmallThumbnailUrl() {
		return smallThumbnailUrl;
	}
	public void setSmallThumbnailUrl(String smallThumbnailUrl) {
		this.smallThumbnailUrl = smallThumbnailUrl;
	}
	public String getLargeThumbnailUrl() {
		return largeThumbnailUrl;
	}
	public void setLargeThumbnailUrl(String largeThumbnailUrl) {
		this.largeThumbnailUrl = largeThumbnailUrl;
	}
	public Boolean getMakePublic() {
		return makePublic;
	}

	public void setMakePublic(Boolean makePublic) {
		this.makePublic = makePublic;
	}
	public String getShareUrl() {
		return shareUrl;
	}
	public void setShareUrl(String shareUrl) {
		this.shareUrl = shareUrl;
	}
	
	public Integer getActivationMode() {
		return activationMode;
	}

	public void setActivationMode(Integer activationMode) {
		this.activationMode = activationMode;
	}

	public String getActivationCondition() {
		return activationCondition;
	}

	public void setActivationCondition(String activationCondition) {
		this.activationCondition = activationCondition;
	}
	
	/**
	 * Util function to copy values from a parent object to child object 
	 * @param experiment
	 */
	protected void copyValues(Experiment experiment) {
		setExperimentId(experiment.getExperimentId());
		setProjectId(experiment.getProjectId());
		setExperimentName(experiment.getExperimentName());
		setCreateBy(experiment.getCreateBy());
		setCreatedByName(experiment.getCreatedByName());
		setExperimentKey(experiment.getExperimentKey());
		setExperimentLinkname(experiment.getExperimentLinkname());
		setExperimentType(experiment.getExperimentType());
		setExperimentStatus(experiment.getExperimentStatus());
		setDuration(experiment.getDuration());
		setStartDate(experiment.getStartDate());
		setEndDate(experiment.getEndDate());
		setActualStartTime(experiment.getActualStartTime());
		setActualEndTime(experiment.getActualEndTime());
		setCreatedTime(experiment.getCreatedTime());
		setModifiedTime(experiment.getModifiedTime());
		setIsActive(experiment.getIsActive());
		setMakePublic(experiment.getMakePublic());
		setShareUrl(experiment.getShareUrl());
		setProjectLinkname(experiment.getProjectLinkname());
		setSmallThumbnailUrl(experiment.getSmallThumbnailUrl());
		setLargeThumbnailUrl(experiment.getLargeThumbnailUrl());
		setActivationMode(experiment.getActivationMode());
		setActivationCondition(experiment.getActivationCondition());
	}
	
	public static Experiment getExperimentFromRow(Row row, Experiment experiment) {
		experiment.setExperimentId((Long)row.get(EXPERIMENT.EXPERIMENT_ID));
		experiment.setExperimentName((String)row.get(EXPERIMENT.EXPERIMENT_NAME));
		experiment.setExperimentStatus((Integer)row.get(EXPERIMENT.EXPERIMENT_STATUS));
		experiment.setExperimentType((Integer)row.get(EXPERIMENT.EXPERIMENT_TYPE));
		experiment.setEndDate((Long)row.get(EXPERIMENT.END_TIME));
		experiment.setProjectId((Long)row.get(EXPERIMENT.PROJECT_ID));
		experiment.setStartDate((Long)row.get(EXPERIMENT.START_TIME));
		experiment.setActualStartTime((Long)row.get(EXPERIMENT.ACTUAL_START_TIME));
		experiment.setActualEndTime((Long)row.get(EXPERIMENT.ACTUAL_END_TIME));
		experiment.setCreatedTime((Long)row.get(EXPERIMENT.CREATED_TIME));
		experiment.setModifiedTime((Long)row.get(EXPERIMENT.MODIFIED_TIME));
		experiment.setExperimentLinkname((String)row.get(EXPERIMENT.EXPERIMENT_LINK_NAME));
		experiment.setExperimentKey((String)row.get(EXPERIMENT.EXPERIMENT_KEY));
		experiment.setIsActive((Boolean)row.get(EXPERIMENT.IS_ACTIVE));
		experiment.setCreateBy((Long)row.get(EXPERIMENT.CREATED_BY));
		experiment.setSmallThumbnailUrl(ApplicationProperty.getString("zap.zohoabtest.thumbnail.url")+experiment.getExperimentKey()+"-1"); //NO I18N
		experiment.setLargeThumbnailUrl(ApplicationProperty.getString("zap.zohoabtest.thumbnail.url")+experiment.getExperimentKey()+"-2"); //NO I18N
		experiment.setExperimentKey((String)row.get(EXPERIMENT.EXPERIMENT_KEY));
		experiment.setActivationMode((Integer)row.get(EXPERIMENT.ACTIVATION_MODE));
		experiment.setActivationCondition((String)row.get(EXPERIMENT.ACTIVATION_CONDITION));
		experiment.setMakePublic((Boolean)row.get(EXPERIMENT.MAKE_PUBLIC));
		experiment.setSuccess(Boolean.TRUE);
		return experiment;
	}

	public static Experiment getExperimentFromRow(Row row) {
		 Experiment experiment = new Experiment();
		experiment.setExperimentId((Long)row.get(EXPERIMENT.EXPERIMENT_ID));
		experiment.setExperimentName((String)row.get(EXPERIMENT.EXPERIMENT_NAME));
		experiment.setExperimentStatus((Integer)row.get(EXPERIMENT.EXPERIMENT_STATUS));
		experiment.setExperimentType((Integer)row.get(EXPERIMENT.EXPERIMENT_TYPE));
		experiment.setEndDate((Long)row.get(EXPERIMENT.END_TIME));
		experiment.setProjectId((Long)row.get(EXPERIMENT.PROJECT_ID));
		experiment.setStartDate((Long)row.get(EXPERIMENT.START_TIME));
		experiment.setActualStartTime((Long)row.get(EXPERIMENT.ACTUAL_START_TIME));
		experiment.setActualEndTime((Long)row.get(EXPERIMENT.ACTUAL_END_TIME));
		experiment.setCreatedTime((Long)row.get(EXPERIMENT.CREATED_TIME));
		experiment.setModifiedTime((Long)row.get(EXPERIMENT.MODIFIED_TIME));
		experiment.setExperimentLinkname((String)row.get(EXPERIMENT.EXPERIMENT_LINK_NAME));
		experiment.setExperimentKey((String)row.get(EXPERIMENT.EXPERIMENT_KEY));
		experiment.setIsActive((Boolean)row.get(EXPERIMENT.IS_ACTIVE));
		experiment.setCreateBy((Long)row.get(EXPERIMENT.CREATED_BY));
		experiment.setMakePublic((Boolean)row.get(EXPERIMENT.MAKE_PUBLIC));
		experiment.setSmallThumbnailUrl(ApplicationProperty.getString("zap.zohoabtest.thumbnail.url")+experiment.getExperimentKey()+"-1"); //NO I18N
		experiment.setLargeThumbnailUrl(ApplicationProperty.getString("zap.zohoabtest.thumbnail.url")+experiment.getExperimentKey()+"-2"); //NO I18N
		experiment.setActivationMode((Integer)row.get(EXPERIMENT.ACTIVATION_MODE));
		experiment.setActivationCondition((String)row.get(EXPERIMENT.ACTIVATION_CONDITION));
		experiment.setSuccess(Boolean.TRUE);
		return experiment;
	}
	
	public static Experiment getExperimentFromDataSet(DataSet ds, String prefix) throws SQLException {
		Experiment experiment = new Experiment();
		experiment.setExperimentId((Long)ds.getValue(prefix+EXPERIMENT.EXPERIMENT_ID));
		experiment.setExperimentName((String)ds.getValue(prefix+EXPERIMENT.EXPERIMENT_NAME));
		experiment.setExperimentStatus((Integer)ds.getValue(prefix+EXPERIMENT.EXPERIMENT_STATUS));
		experiment.setExperimentType((Integer)ds.getValue(prefix+EXPERIMENT.EXPERIMENT_TYPE));
		experiment.setEndDate((Long)ds.getValue(prefix+EXPERIMENT.END_TIME));
		experiment.setProjectId((Long)ds.getValue(prefix+EXPERIMENT.PROJECT_ID));
		experiment.setStartDate((Long)ds.getValue(prefix+EXPERIMENT.START_TIME));
		experiment.setActualStartTime((Long)ds.getValue(prefix+EXPERIMENT.ACTUAL_START_TIME));
		experiment.setActualEndTime((Long)ds.getValue(prefix+EXPERIMENT.ACTUAL_END_TIME));
		experiment.setCreateBy((Long)ds.getValue(prefix+EXPERIMENT.CREATED_BY));
		experiment.setCreatedTime((Long)ds.getValue(prefix+EXPERIMENT.CREATED_TIME));
		experiment.setModifiedTime((Long)ds.getValue(prefix+EXPERIMENT.MODIFIED_TIME));
		experiment.setExperimentLinkname((String)ds.getValue(prefix+EXPERIMENT.EXPERIMENT_LINK_NAME));
		experiment.setExperimentKey((String)ds.getValue(prefix+EXPERIMENT.EXPERIMENT_KEY));
		experiment.setIsActive((Boolean)ds.getValue(prefix+EXPERIMENT.IS_ACTIVE));
		experiment.setMakePublic((Boolean)ds.getValue(prefix+EXPERIMENT.MAKE_PUBLIC));
		experiment.setSmallThumbnailUrl(ApplicationProperty.getString("zap.zohoabtest.thumbnail.url")+experiment.getExperimentKey()+"-1"); //NO I18N
		experiment.setLargeThumbnailUrl(ApplicationProperty.getString("zap.zohoabtest.thumbnail.url")+experiment.getExperimentKey()+"-2"); //NO I18N
		experiment.setActivationMode((Integer)ds.getValue(prefix+EXPERIMENT.ACTIVATION_MODE));
		experiment.setActivationCondition((String)ds.getValue(prefix+EXPERIMENT.ACTIVATION_CONDITION));
		experiment.setSuccess(Boolean.TRUE);
		return experiment;
	}
	
	public static Experiment getExperimentFromDataSet(DataSet ds, String prefix, Experiment experiment) throws SQLException {
		experiment.setExperimentId((Long)ds.getValue(prefix+EXPERIMENT.EXPERIMENT_ID));
		experiment.setExperimentName((String)ds.getValue(prefix+EXPERIMENT.EXPERIMENT_NAME));
		experiment.setExperimentStatus((Integer)ds.getValue(prefix+EXPERIMENT.EXPERIMENT_STATUS));
		experiment.setExperimentType((Integer)ds.getValue(prefix+EXPERIMENT.EXPERIMENT_TYPE));
		experiment.setEndDate((Long)ds.getValue(prefix+EXPERIMENT.END_TIME));
		experiment.setProjectId((Long)ds.getValue(prefix+EXPERIMENT.PROJECT_ID));
		experiment.setStartDate((Long)ds.getValue(prefix+EXPERIMENT.START_TIME));
		experiment.setActualStartTime((Long)ds.getValue(prefix+EXPERIMENT.ACTUAL_START_TIME));
		experiment.setActualEndTime((Long)ds.getValue(prefix+EXPERIMENT.ACTUAL_END_TIME));
		experiment.setCreateBy((Long)ds.getValue(prefix+EXPERIMENT.CREATED_BY));
		experiment.setCreatedTime((Long)ds.getValue(prefix+EXPERIMENT.CREATED_TIME));
		experiment.setModifiedTime((Long)ds.getValue(prefix+EXPERIMENT.MODIFIED_TIME));
		experiment.setExperimentLinkname((String)ds.getValue(prefix+EXPERIMENT.EXPERIMENT_LINK_NAME));
		experiment.setExperimentKey((String)ds.getValue(prefix+EXPERIMENT.EXPERIMENT_KEY));
		experiment.setIsActive((Boolean)ds.getValue(prefix+EXPERIMENT.IS_ACTIVE));
		experiment.setMakePublic((Boolean)ds.getValue(prefix+EXPERIMENT.MAKE_PUBLIC));
		experiment.setSmallThumbnailUrl(ApplicationProperty.getString("zap.zohoabtest.thumbnail.url")+experiment.getExperimentKey()+"-1"); //NO I18N
		experiment.setLargeThumbnailUrl(ApplicationProperty.getString("zap.zohoabtest.thumbnail.url")+experiment.getExperimentKey()+"-2"); //NO I18N
		experiment.setActivationMode((Integer)ds.getValue(prefix+EXPERIMENT.ACTIVATION_MODE));
		experiment.setActivationCondition((String)ds.getValue(prefix+EXPERIMENT.ACTIVATION_CONDITION));
		experiment.setSuccess(Boolean.TRUE);
		return experiment;
	}
	
	public static ArrayList<Experiment> getExperimentFromDobj(DataObject dobj) throws DataAccessException {
		ArrayList<Experiment> experiments = new ArrayList<Experiment>();
		if(dobj.containsTable(EXPERIMENT.TABLE)) {
			Iterator it = dobj.getRows(EXPERIMENT.TABLE);
			while(it.hasNext()) {
				Row row = (Row)it.next();
				Experiment experiment = new Experiment();
				getExperimentFromRow(row,experiment);
				experiment.setProjectLinkname(Project.getProjectLinkname(dobj, experiment.getProjectId()));
				experiments.add(experiment);
			}
		}
		return experiments;
	}
	
	public static ArrayList<Experiment> getExperimentsForExtensions()
	{
		ArrayList<Experiment> experiments = new ArrayList<Experiment>();
		try
		{
			Long currentUserId = ZABUtil.getCurrentUser().getUserId();
			Criteria userCriteria = new Criteria (new Column(PROJECT_USER_ROLE.TABLE,PROJECT_USER_ROLE.USER_ID),currentUserId,QueryConstants.EQUAL);
			Criteria activeProjCriteria = new Criteria (new Column(PROJECT.TABLE,PROJECT.STATUS),ProjectStatus.ACTIVE.getStatusNumber(),QueryConstants.EQUAL);
			Criteria activeExpCriteria = new Criteria (new Column(EXPERIMENT.TABLE,EXPERIMENT.IS_ACTIVE),Boolean.TRUE,QueryConstants.EQUAL);
			Criteria criteria = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_TYPE), new Integer[]{ExperimentType.ABTEST.getTypeNumber(),ExperimentType.HEATMAP.getTypeNumber()}, QueryConstants.IN);
			DataObject dataObj = getPersonality(ExperimentConstants.ALL_EXPERIMENTS_PERSONALITY, userCriteria.and(activeProjCriteria).and(activeExpCriteria.and(criteria)));
			Iterator<?> iterator = dataObj.getRows(EXPERIMENT.TABLE);
			while(iterator.hasNext())
			{
				Experiment experiment = null;
				Row expRow =  (Row)iterator.next();
				Integer expTypeNo =  (Integer)expRow.get(EXPERIMENT.EXPERIMENT_TYPE);
				Long experimentId = (Long)expRow.get(EXPERIMENT.EXPERIMENT_ID);
				ExperimentType expType = ExperimentType.getExperimentTypeByNumber(expTypeNo);
				switch(expType)
				{
				case ABTEST:
					Criteria criteria2 = new Criteria(new Column(ABSPLITEXPERIMENT.TABLE, ABSPLITEXPERIMENT.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
					Row abtestRow = dataObj.getRow(ABSPLITEXPERIMENT.TABLE, criteria2);
					experiment = ABSplitExperiment.getABSplitExperimentFromRow(expRow, abtestRow);
					break;
				case HEATMAP:
					Criteria criteria3 = new Criteria(new Column(HEATMAP_EXPERIMENT.TABLE, HEATMAP_EXPERIMENT.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
					Row hmRow = dataObj.getRow(HEATMAP_EXPERIMENT.TABLE, criteria3);
					experiment = HeatmapExperiment.getHeatmapExperimentFromRow(expRow, hmRow);
					break;
				default:
					break;
				}
				if(experiment != null)
				{
					experiments.add(experiment);
				}				
			}
			ZABUser.setUserDetails(experiments, new ZABUserDetailWrapper() {
				
				@Override
				public void setUserDetails(User user, ZABModel model) {
					Experiment exe = (Experiment)model;
					exe.setCreatedByName(user.getFirstName()+ " " + user.getLastName());
				}
				@Override
				public Long getUserId(ZABModel model) {
					Experiment exe = (Experiment)model;
					return exe.getCreateBy();
				}
			});
		}
		catch(Exception ex)
		{
			experiments = new ArrayList<Experiment>();
			LOGGER.log(Level.SEVERE,"Exception Occurred while fetching experiments for Extension",ex);
		}
		
		String currentUrl = ZABUtil.getCurrentRequest().getParameter(ExperimentConstants.CURRENT_URL);
		if(currentUrl!=null && !currentUrl.isEmpty()){
			experiments = getExperimentsMatchingUrl(experiments, currentUrl);
		}
		return experiments;
	}
	
	private static ArrayList<Experiment> getExperimentsMatchingUrl(ArrayList<Experiment> experiments, String currentUrl) {
		ArrayList<Experiment> matchingExps =  new ArrayList<Experiment>();
		for(int i=0;i<experiments.size();i++){
			Boolean includeExp = false;
			Experiment exp = experiments.get(i);

			ExperimentType expType = ExperimentType.getExperimentTypeByNumber(exp.getExperimentType());
			switch(expType){
			case HEATMAP:
				HeatmapExperiment hmexp = (HeatmapExperiment) exp;
				includeExp = checkMatching(hmexp.getExperimentUrl(),hmexp.getIncludedUrls(),hmexp.getExcludedUrls(),currentUrl);
				break;
			case ABTEST:
			case SPLITURL:
				ABSplitExperiment abexp = (ABSplitExperiment)exp;
				includeExp = checkMatching(abexp.getExperimentUrl(),abexp.getIncludeUrls(),abexp.getExcludeUrls(),currentUrl);
				break;

			}

			if(includeExp){
				matchingExps.add(exp);
			}

		}
		
		return matchingExps;
	}

	public static Boolean checkMatching(String expUrl, String includeUrls,String excludeUrls,String currentUrl){
		Boolean includeExp = false;
		try{
			
			if(urlMatches(expUrl,currentUrl,MatchType.EXACT_MATCH.getMatchTypeId())){
				includeExp =true;	
			}
			if(!includeExp){
				//check for include urls
				
				if(includeUrls!=null && !includeUrls.isEmpty()){
					JSONArray includearray =  new JSONArray(includeUrls);
					for(int j=0;j<includearray.length();j++){
						JSONObject singlejson  = (JSONObject)includearray.get(j);
						int matchType = (int) singlejson.get(ExperimentConstants.MATCH_TYPE);
						String expincludeurl = (String) singlejson.get(ExperimentConstants.VALUE);
						if(urlMatches(expincludeurl,currentUrl,matchType)){
							includeExp =true;	
							break;
						}
					}
				}
			}
			if(includeExp){
				// check if url matches in exclude list
				
				if(excludeUrls!=null && !excludeUrls.isEmpty()){
					JSONArray excludeArray =  new JSONArray(excludeUrls);
					for(int j=0;j<excludeArray.length();j++){
						JSONObject singlejson  = (JSONObject)excludeArray.get(j);
						int matchType = (int) singlejson.get(ExperimentConstants.MATCH_TYPE);
						String expExcludeurl = (String) singlejson.get(ExperimentConstants.VALUE);
						if(urlMatches(expExcludeurl,currentUrl,matchType)){
							includeExp =false;	
							break;
						}
					}
					
				}
			}
			
		}catch(Exception e){
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return includeExp;
	}
	public static Boolean urlMatches(String expUrl, String currentUrl, Integer matchTypeId) {
		Boolean flag = false;
		
		
		try{
			currentUrl = currentUrl.toLowerCase();
			expUrl = expUrl.toLowerCase();
			MatchType matchtype= MatchType.getMatchTypeById(matchTypeId);
			switch(matchtype){
			case SIMPLE_MATCH:
				URI CurrURI = new URI(currentUrl);
				URI expURI = new URI(expUrl);
				if(CurrURI.getHost().equals(expURI.getHost())){
					String currPath = CurrURI.getPath();
					String expPath = expURI.getPath();
					if(!(currPath.isEmpty() || expPath.isEmpty())){
						if((currPath.charAt(currPath.length()-1)) == '/'){
							currPath = currPath.substring(0,currPath.length()-1);
						}
						if((expPath.charAt(expPath.length()-1)) == '/'){
							expPath = expPath.substring(0,expPath.length()-1);
						}
						if(currPath.equals(expPath)){
							flag = true;
						}
					}
					
				}
				break;
			case EXACT_MATCH:
				if((currentUrl.charAt(currentUrl.length()-1)) == '/'){
					currentUrl = currentUrl.substring(0,currentUrl.length()-1);
				}
				if((expUrl.charAt(expUrl.length()-1)) == '/'){
					expUrl = expUrl.substring(0,expUrl.length()-1);
				}
				if(currentUrl.equals(expUrl)){
					flag = true;
				}
				break;
			case PATTERN_MATCH:
				expUrl = expUrl.replace("*", ".*");
				if(Pattern.matches(expUrl, currentUrl)){
					flag = true;
				}
				break;
			case REGEX_MATCH:
				if(currentUrl.matches(expUrl)){
					flag = true;
				}
				break;
			case CONTAINS_MATCH:
				if(currentUrl.indexOf(expUrl) > -1){
					flag = true;
				}
				break;
			case STARTS_WITH:
				if(currentUrl.startsWith(expUrl)){
					flag = true;
				}
				break;
			case ENDS_WITH:
				if(currentUrl.endsWith(expUrl)){
					flag = true;
				}
				break;
			
			}
		}catch(Exception e){
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		
		return flag;
	}

	public static String getExperimentLinkname(DataObject dobj, Long experimentId) throws DataAccessException {
		String experimentLinkname = null;
		if(dobj.containsTable(EXPERIMENT.TABLE)) {
			Criteria c2 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
			Row prow = dobj.getRow(EXPERIMENT.TABLE, c2);
			if(prow!=null) {
				experimentLinkname = (String)prow.get(EXPERIMENT.EXPERIMENT_LINK_NAME);
			}					
		}
		return experimentLinkname;
	}

	public static void addDefaultValueIfNotAvailable(HashMap<String, String> hs, String key, String defaultValue) {
		if(!hs.containsKey(key) || hs.get(key).isEmpty()){
			hs.put(key, defaultValue);
		}
	}

	public static Experiment createExperiment(HashMap<String, String> hs) {
		Experiment experiment = null;
		try {
			String projectLinkname = hs.get(ExperimentConstants.PROJECT_LINKNAME);
			Long projectId = null;
			if(hs.containsKey(ExperimentConstants.PROJECT_ID)) {
				projectId = Long.parseLong(hs.get(ExperimentConstants.PROJECT_ID));
			} else {
				projectId = Project.getProjectId(projectLinkname);
			}
			
			if(projectId!=null) {

				String displayname = hs.get(ExperimentConstants.EXPERIMENT_NAME);
				displayname = displayname.trim();
				if(displayname.length() == 0){
					experiment = new Experiment();
					experiment.setSuccess(Boolean.FALSE);
					experiment.setResponseString(ZABAction.getMessage(ExperimentConstants.EXPERIMENT_EMPTY_NAME)); 
					return experiment;
				}
				
				Integer experimentTypeNumber = Integer.parseInt(hs.get(ExperimentConstants.EXPERIMENT_TYPE));
				ExperimentType experimentType = ExperimentType.getExperimentTypeByNumber(experimentTypeNumber);
				
				Boolean duplicate = checkDuplicateExperimentNameInProject(displayname,projectId, null, experimentTypeNumber);

				if(duplicate != true){

					hs.put(ExperimentConstants.PROJECT_ID, projectId+"");
					String linkName = generateLinkName(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_LINK_NAME, null, null, hs.get(ExperimentConstants.EXPERIMENT_NAME));
					hs.put(ExperimentConstants.EXPERIMENT_LINKNAME, linkName);
					String experimentKey = generateUniqueId(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_KEY);
					hs.put(ExperimentConstants.EXPERIMENT_KEY, experimentKey);
					hs.put(ExperimentConstants.CREATED_TIME, ZABUtil.getCurrentTimeInMilliSeconds()+"");
					hs.put(ExperimentConstants.CREATED_BY, ZABUtil.getCurrentUser().getUserId()+"");
					
					if(hs.containsKey(ExperimentConstants.AUTO_LAUNCH)) {
						Long userId = ZABUtil.getCurrentUser().getUserId();
						List<String> featuresList = Feature.getFeatureNameList(projectId, userId);
						if(featuresList.contains(AppFeatures.PUBLISHEXPERIMENT.getFeature())) {							
							hs.put(ExperimentConstants.EXPERIMENT_STATUS, ExperimentStatus.RUNNING.getStatusCode().toString());
						} else {
							throw new ZABException("User don't have permission to launch the experiment"); //NO I18N
						}
					}

					/*
					addDefaultValueIfNotAvailable(hs, ExperimentConstants.STATISTICAL_SIGNIFICANCE, ExperimentConstants.DEFAULT_STATISTICAL_SIGNIFICANCE);
					addDefaultValueIfNotAvailable(hs, ExperimentConstants.DAILY_VISITORS, ExperimentConstants.DEFAULT_DAILY_VISITORS);
					addDefaultValueIfNotAvailable(hs, ExperimentConstants.CONVERSION_RATE, ExperimentConstants.DEFAULT_CONVERSION_RATE);
					addDefaultValueIfNotAvailable(hs, ExperimentConstants.EXPECTED_IMPROVEMENT, ExperimentConstants.DEFAULT_EXPECTED_IMPROVEMENT);
					*/
					
					DataObject dobj = createRow(ExperimentConstants.EXPERIMENT_TABLE, EXPERIMENT.TABLE, hs);
					experiment = getExperimentFromDobj(dobj).get(0);
					
					/*if(experiments.size() > 0) {

						Experiment experiment = experiments.get(0);
						//					experiment.setGoalsCount(1);
						experiment.setVariationCount(2);
						Integer exptype = experiment.getExperimentType();

						//Creating variation
						experiment.setProjectLinkname(projectLinkname);
						String linkname = experiment.getExperimentLinkname();
						experiment_id = experiment.getExperimentId();
						
						
						
						HashMap<String, String> original =  new HashMap<String, String>();
						original.put(VariationConstants.TARGET_URL, experiment.getExperimentUrl());
						original.put(VariationConstants.VARIATION_NAME, VariationConstants.ORIGINAL_VARIATION);
						if(ExperimentType.HEATMAP.getTypeNumber().equals(exptype) || ExperimentType.SPLITURL.getTypeNumber().equals(exptype)){
							original.put(VariationConstants.TRAFFIC_ALLOCATION, 100+"");
						}else{
							original.put(VariationConstants.TRAFFIC_ALLOCATION, 50+"");
						}
						original.put(VariationConstants.EXPERIMENT_LINKNAME, linkname);
						Variation origVar = Variation.createVariation(original, Boolean.TRUE, Boolean.FALSE, Boolean.FALSE);
						if(origVar.getSuccess()) {						
							experiment.getVariations().add(origVar);
						} else {
							throw new ZABException(ZABAction.getMessage(ExperimentConstants.VARIATION_CREATION_ERROR)); 
						}
						

						//Add another variation only if it is abtest
						if(ExperimentType.ABTEST.getTypeNumber().equals(exptype)){
							HashMap<String, String> variation1 =  new HashMap<String, String>();
							variation1.put(VariationConstants.VARIATION_NAME, VariationConstants.VARIATION_1);
							variation1.put(VariationConstants.EXPERIMENT_LINKNAME, linkname);
							variation1.put(VariationConstants.TRAFFIC_ALLOCATION, 50+"");
							Variation var1 = Variation.createVariation(variation1, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
							if(var1.getSuccess()) {						
								experiment.getVariations().add(var1);
							} else {
								throw new ZABException(ZABAction.getMessage(ExperimentConstants.VARIATION_CREATION_ERROR)); 
							}
						}
						
						
						if(ExperimentType.FUNNEL.getTypeNumber().equals(exptype)) {
							//Creating first step for the funnel
							HashMap<String, String> step1 =  new HashMap<String, String>();
							step1.put(FunnelAnalysisConstants.STEP_NAME, FunnelAnalysisConstants.STEP_1);
							step1.put(FunnelAnalysisConstants.STEP_ORDER, "1");
							step1.put(FunnelAnalysisConstants.EXPERIMENT_ID, experiment_id.toString());
							
							JSONArray stepUrlJSON = new JSONArray();
							JSONObject stepUrl = new JSONObject();
							stepUrl.put(FunnelAnalysisConstants.URL, experiment.getExperimentUrl());
							stepUrl.put(FunnelAnalysisConstants.MATCH_TYPE, MatchType.SIMPLE_MATCH.getMatchTypeId());
							stepUrlJSON.put(stepUrl);
							step1.put(FunnelAnalysisConstants.STEP_URLS,  stepUrlJSON.toString());
							
							FunnelStep.createFunnelStep(step1);
						}

						if(!ExperimentType.HEATMAP.getTypeNumber().equals(exptype)){ // Heatmap exp has only one variation and no goals and audiences

							Audience audience = Audience.getAudienceByLinkName("all", 0L);//No I18N
							HashMap<String, String> hs_audience =  new HashMap<String, String>();
							hs_audience.put(ExperimentAudienceConstants.EXPERIMENT_ID, experiment_id.toString());
							hs_audience.put(ExperimentAudienceConstants.AUDIENCE_ID, audience.getAudienceId().toString());

							ArrayList<ExperimentAudience> expaudience = ExperimentAudience.createExperimentAudience(hs_audience,false);
						}
					}*/

					//Saving the Experiment display name for the use of event activity
					if(experiment != null && experiment.getExperimentId() != null && !experiment.getExperimentType().equals(ExperimentType.ENABLED_HEATMAP.getTypeNumber())){
						HashMap<String, String> eventModuleHs = new HashMap<String, String>();
						eventModuleHs.put(EventActivityConstants.MODULE_TYPE, Module.EXPERIMENT.getValue().toString());
						eventModuleHs.put(EventActivityConstants.MODULE_ELEMENT_ID, experiment.getExperimentId().toString());
						eventModuleHs.put(EventActivityConstants.MODULE_ELEMENT_NAME, experiment.getExperimentName());
						EventModuleDetail.createEventModuleDetail(eventModuleHs);
						
						//Admin console record
						Long zuid = IAMUtil.getCurrentUser().getZUID();
						HashMap<String, String> acHs = new HashMap<String, String>();
						acHs.put(AdminConsoleConstants.EXPERIMENT_ID, experiment.getExperimentId().toString());
						acHs.put(AdminConsoleConstants.EXPERIMENT_TYPE, experiment.getExperimentType().toString());
						acHs.put(AdminConsoleConstants.EXPERIMENT_STATUS, experiment.getExperimentStatus().toString());
						acHs.put(AdminConsoleConstants.IS_ACTIVE, experiment.getIsActive().toString());
						acHs.put(AdminConsoleConstants.ZSOID, ZABUtil.getDBSpace());
						acHs.put(AdminConsoleConstants.PROJECT_ID, projectId.toString());
						acHs.put(AdminConsoleConstants.CREATED_ZUID, zuid.toString());
						acHs.put(AdminConsoleConstants.CREATED_TIME, experiment.getCreatedTime().toString());
						acHs.put(AdminConsoleConstants.MODIFIED_TIME, experiment.getCreatedTime().toString());
						acHs.put(AdminConsoleConstants.LAST_EVENT_ACTIVITY, EventType.EXPERIMENT_CREATE.getEventValue().toString());
						AdminConsoleWrapper acWrapper = new AdminConsoleWrapper();
						acWrapper.setValueHs(acHs);
						acWrapper.setOperationType(AcOperationType.EXPERIMENT_CREATE);
						ZABNotifier.notifyListeners(AdminConsoleConstants.ADMIN_CONSOLE_MODULE_NAME,acWrapper);
					}

				}else{
					experiment = new Experiment();
					experiment.setSuccess(Boolean.FALSE);
//					experiment.setResponseString(ZABAction.getMessage(ExperimentConstants.DUPLICATE_EXPERIMENT_PROJECT));
					experiment.setResponseString(ZABAction.getMessage(ExperimentConstants.DUPLICATE_EXPERIMENT_PROJECT, new String[]{experimentType.getResourceName()}));
				}

			} else {
				experiment = new Experiment();
				experiment.setSuccess(Boolean.FALSE);
				experiment.setResponseString(ZABAction.getMessage(ProjectConstants.PROJECT_NOT_EXISTS)); 
			}

		} catch (Exception e) {
			experiment = new Experiment();
			experiment.setSuccess(Boolean.FALSE);
			experiment.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return experiment;
	}
	
	private static Boolean checkDuplicateExperimentNameInProject(String displayname, Long projectId, Long experimentId, Integer experimentType) {

		Boolean duplicate = false;
		if(displayname == null || projectId == null){
			return false;
		}
		Criteria c = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_TYPE), experimentType, QueryConstants.EQUAL);

		if(experimentId!=null) {
			//To check if it is duplicate on updation
			Criteria c1 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_ID), experimentId, QueryConstants.NOT_EQUAL);
			c = c.and(c1);
		}
		Experiment exp = getExperimentByNameInProject(displayname,projectId, c);
		if(exp != null){
			duplicate = true;
		}
		return duplicate;
	}

	public static Experiment updateExperiment(HashMap<String, String> hs) {
		Experiment experiment = null;
		TransactionManager mgr = null;
		Boolean alreadyInTransaction = false;
		try {
			String linkName = hs.get(ExperimentConstants.EXPERIMENT_LINKNAME);
			//Logging event activity purpose
			Experiment oldExp = Experiment.getExperimentByLinkname(linkName);
			HashMap<String,String> oldValues = generateHashMapFromExperimentObj(oldExp,hs);
			Project projectObj = Project.getProjectByProjectId(oldExp.getProjectId());

			/*Validations START*/
			ExperimentType experimentType = ExperimentType.getExperimentTypeByNumber(oldExp.getExperimentType());
			
			String displayName = hs.get(ExperimentConstants.EXPERIMENT_NAME);
			if(displayName!=null && checkDuplicateExperimentNameInProject(displayName, oldExp.getProjectId(), oldExp.getExperimentId(), oldExp.getExperimentType())) {
				throw new ZABException(ZABAction.getMessage(ExperimentConstants.DUPLICATE_EXPERIMENT_PROJECT, new String[]{experimentType.getResourceName()}));
			}
			//Cannot start/schedule an experiment when license is expired
			if(hs.containsKey(ExperimentConstants.EXPERIMENT_STATUS)){
				Integer status = Integer.parseInt(hs.get(ExperimentConstants.EXPERIMENT_STATUS));
				if(ExperimentStatus.RUNNING.getStatusCode().equals(status) ||
						ExperimentStatus.SCHEDULED.getStatusCode().equals(status)){
					Boolean licenseStatus = PortalLicenseMapping.getLicenseStatus();
					if(!licenseStatus){
						throw new ZABException(ZABAction.getMessage(ExperimentConstants.LICENSE_EXPIRE_EXPERIMENT_PUBLISH_ERROR));
					}
				}
			}

			//Experiments under Archived Project cannot be updated
			if(ProjectStatus.ARCHIVE.getStatusNumber().equals(projectObj.getProjectStatus()))
			{
				experiment = new Experiment();
				experiment.setSuccess(Boolean.FALSE);
				experiment.setResponseString(ZABAction.getMessage(ExperimentConstants.EXPERIMENT_UPDATE_PROJECT_VALIDATION_ERROR));
				return experiment;
			}

			if(!oldExp.getIsActive() && (!hs.containsKey(ExperimentConstants.IS_ACTIVE) ||
					!hs.get(ExperimentConstants.IS_ACTIVE).equals(Boolean.TRUE.toString())))
			{
				experiment = new Experiment();
				experiment.setSuccess(Boolean.FALSE);
				experiment.setResponseString(ZABAction.getMessage(ExperimentConstants.EXPERIMENT_ARCHIVED_UPDATE_VALIDATION_ERROR));
				return experiment;
			}

			//Running/Scheduled experiment cannot be archived
			if(hs.containsKey(ExperimentConstants.IS_ACTIVE) && hs.get(ExperimentConstants.IS_ACTIVE).equals(Boolean.FALSE.toString()) &&
					(oldExp.getExperimentStatus().equals(ExperimentConstants.ExperimentStatus.RUNNING.getStatusCode()) || 
							oldExp.getExperimentStatus().equals(ExperimentConstants.ExperimentStatus.SCHEDULED.getStatusCode())))
			{
				experiment = new Experiment();
				experiment.setSuccess(Boolean.FALSE);
				experiment.setResponseString(ZABAction.getMessage(ExperimentConstants.EXPERIMENT_ARCHIVE_VALIDATION_ERROR));
				return experiment;
			}

			//Archived experiment status cannot be changed
			if(hs.containsKey(ExperimentConstants.EXPERIMENT_STATUS) && !oldExp.getIsActive())
			{
				experiment = new Experiment();
				experiment.setSuccess(Boolean.FALSE);
				experiment.setResponseString(ZABAction.getMessage(ExperimentConstants.EXPERIMENT_STATUS_ARCHIVE_ERROR));
				return experiment;
			}

			//Running, Paused and Scheduled experiment cannot be drafted
			if(hs.containsKey(ExperimentConstants.EXPERIMENT_STATUS) && 
					ExperimentStatus.DRAFT.getStatusCode().equals(Integer.parseInt(hs.get(ExperimentConstants.EXPERIMENT_STATUS))) && 
					(oldExp.getExperimentStatus().equals(ExperimentConstants.ExperimentStatus.RUNNING.getStatusCode()) ||
							oldExp.getExperimentStatus().equals(ExperimentConstants.ExperimentStatus.PAUSED.getStatusCode()) ||
							oldExp.getExperimentStatus().equals(ExperimentConstants.ExperimentStatus.SCHEDULED.getStatusCode())))
			{
				experiment = new Experiment();
				experiment.setSuccess(Boolean.FALSE);
				experiment.setResponseString(ZABAction.getMessage(ExperimentConstants.EXPERIMENT_STATUS_DRAFT_UPDATE_ERROR));
				return experiment;
			}

			//If experiment status is schedule, then check whether the start date and end date is greater than current date
			if(hs.containsKey(ExperimentConstants.EXPERIMENT_STATUS) && 
					ExperimentStatus.SCHEDULED.getStatusCode().equals(Integer.parseInt(hs.get(ExperimentConstants.EXPERIMENT_STATUS))))
			{
				Long startTime = oldExp.getStartDate();
				Long endTime = oldExp.getEndDate();
				if(startTime!=null)
				{
					//start time less than current time
					if(startTime < ZABUtil.getCurrentTimeInMilliSeconds())
					{
						experiment = new Experiment();
						experiment.setSuccess(Boolean.FALSE);
						String fiedLabel = ZABAction.getMessage(ExperimentConstants.START_DATE);
						experiment.setResponseString(ZABAction.getMessage(ExperimentConstants.EXPERIMENT_SCHEDULE_VALIDATION_ERROR, new String[]{fiedLabel}));
						return experiment;
					}
				}
				if(endTime!=null)
				{
					//end time less than current time
					if(endTime < ZABUtil.getCurrentTimeInMilliSeconds())
					{
						experiment = new Experiment();
						experiment.setSuccess(Boolean.FALSE);
						String fiedLabel = ZABAction.getMessage(ExperimentConstants.END_DATE);
						experiment.setResponseString(ZABAction.getMessage(ExperimentConstants.EXPERIMENT_SCHEDULE_VALIDATION_ERROR, new String[]{fiedLabel}));
						return experiment;
					}
				}
			}

			String projectLinkname = hs.get(ExperimentConstants.PROJECT_LINKNAME);
			Long projectId = null;
			if(hs.containsKey(ExperimentConstants.PROJECT_LINKNAME)) {
				projectId = Project.getProjectId(projectLinkname);
				if(projectId!=null) {
					hs.put(ExperimentConstants.PROJECT_ID, projectId+"");
				} else {
					experiment = new Experiment();
					experiment.setSuccess(Boolean.FALSE);
					experiment.setResponseString(ZABAction.getMessage(ProjectConstants.PROJECT_NOT_EXISTS));
					return experiment;
				}
			} 
			/*Validations END*/

			mgr = DataAccess.getTransactionManager();
			Transaction trans = mgr.getTransaction();
			//Checking if there is already a transaction started.
			//if true, then this function should not take care of commiting and rollbacking transaction
			//Parent function who is calling with a transation must take care of these stuffs
			alreadyInTransaction = (trans!=null);
			if(!alreadyInTransaction) {				
				mgr.begin();
			}
			
			if(hs.containsKey(ExperimentConstants.EXPERIMENT_STATUS))
			{
				if(ExperimentStatus.PAUSED.getStatusCode().equals(Integer.parseInt(hs.get(ExperimentConstants.EXPERIMENT_STATUS))))
				{
					hs.put(ExperimentConstants.ACTUAL_END_TIME,ZABUtil.getCurrentTimeInMilliSeconds()+"");
					if(ExperimentStatus.RUNNING.getStatusCode().equals(Integer.parseInt(oldValues.get(ExperimentConstants.EXPERIMENT_STATUS))))
					{
						hs.put(ExperimentConstants.START_DATE,null);
						hs.put(ExperimentConstants.END_DATE,null);
					}
				}
				if(ExperimentStatus.RUNNING.getStatusCode().equals(Integer.parseInt(hs.get(ExperimentConstants.EXPERIMENT_STATUS))) && oldExp.getActualStartTime() == null)
				{
					hs.put(ExperimentConstants.ACTUAL_START_TIME,ZABUtil.getCurrentTimeInMilliSeconds()+"");
				}
			}
			Long currentTime = ZABUtil.getCurrentTimeInMilliSeconds();
			hs.put(ExperimentConstants.MODIFIED_TIME, currentTime.toString());
			Criteria c = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_LINK_NAME), linkName, QueryConstants.EQUAL);
			updateRow(ExperimentConstants.EXPERIMENT_TABLE, EXPERIMENT.TABLE, hs, c, ExperimentConstants.API_RESOURCE);
			Long experimentId = Experiment.getExperimentId(linkName);

			if(!alreadyInTransaction) {				
				mgr.commit();
			}
			
			try{
				if(hs.containsKey(ExperimentConstants.MAKE_PUBLIC)){
					Boolean makePublic = Boolean.parseBoolean( hs.get(ExperimentConstants.MAKE_PUBLIC));
					
					if(makePublic){
						
						Criteria shareCri =  new Criteria(new Column(SHARED_REPORT_DETAILS.TABLE,SHARED_REPORT_DETAILS.EXPERIMENT_ID),experimentId,QueryConstants.EQUAL);
						DataObject sharedDobj = ZABModel.getRow(SHARED_REPORT_DETAILS.TABLE, shareCri);
						if(!sharedDobj.containsTable(SHARED_REPORT_DETAILS.TABLE)){
							String shareKey = generateUniqueId(SHARED_REPORT_DETAILS.TABLE, SHARED_REPORT_DETAILS.SHARE_KEY);
							Row row = new Row(SHARED_REPORT_DETAILS.TABLE);
							row.set(SHARED_REPORT_DETAILS.EXPERIMENT_ID, experimentId);
							row.set(SHARED_REPORT_DETAILS.SHARE_KEY, shareKey);
							ZABModel.createResource(row);
						}
					}
					
				}
			}catch(Exception publicShareExc){
				
				LOGGER.log(Level.SEVERE,"Exception Occurred while updating public access",publicShareExc);
			}
			


			//If experiment is started or scheduled validate if required fields are valid.
			experiment = Experiment.getExperimentById(experimentId);
			
			//Saving the Experiment display name for the use of event activity
			if(hs.containsKey(ExperimentConstants.EXPERIMENT_NAME))
			{
				HashMap<String, String> eventModuleHs = new HashMap<String, String>();
				eventModuleHs.put(EventActivityConstants.MODULE_ELEMENT_NAME, hs.get(ExperimentConstants.EXPERIMENT_NAME));
				EventModuleDetail.updateEventModuleDetail(eventModuleHs, Module.EXPERIMENT.getValue(), experimentId);
			}

			//If experiment scheduling
			if(hs.containsKey(ExperimentConstants.EXPERIMENT_STATUS) && 
					ExperimentStatus.SCHEDULED.getStatusCode().equals(Integer.parseInt(hs.get(ExperimentConstants.EXPERIMENT_STATUS))))
			{
				Long startTime = oldExp.getStartDate();
				Long endTime = oldExp.getEndDate();
				if(startTime!=null)
				{
					HashMap<String, String> scheduleHs = new HashMap<String, String>();
					scheduleHs.put(ExperimentScheduleConstants.EXPERIMENT_ID, experimentId.toString());
					scheduleHs.put(ExperimentScheduleConstants.SCHEDULE_TYPE, ExperimentScheduleType.EXPERIMENT_START.getScheduleType().toString());
					scheduleHs.put(ExperimentScheduleConstants.SCHEDULE_TIME, startTime.toString());
					ExperimentSchedule.processExperimentSchedule(scheduleHs);
				}
				if(endTime!=null)
				{
					HashMap<String, String> scheduleHs = new HashMap<String, String>();
					scheduleHs.put(ExperimentScheduleConstants.EXPERIMENT_ID, experimentId.toString());
					scheduleHs.put(ExperimentScheduleConstants.SCHEDULE_TYPE, ExperimentScheduleType.EXPERIMENT_STOP.getScheduleType().toString());
					scheduleHs.put(ExperimentScheduleConstants.SCHEDULE_TIME, endTime.toString());
					ExperimentSchedule.processExperimentSchedule(scheduleHs);
				}
			}

			//If experiment status updated to Paused, then remove the scheduler jobs
			if(hs.containsKey(ExperimentConstants.EXPERIMENT_STATUS) && 
					ExperimentStatus.PAUSED.getStatusCode().equals(Integer.parseInt(hs.get(ExperimentConstants.EXPERIMENT_STATUS))))
			{
				HashMap<String, String> scheduleHs = new HashMap<String, String>();
				scheduleHs.put(ExperimentScheduleConstants.EXPERIMENT_ID, experimentId.toString());
				scheduleHs.put(ExperimentScheduleConstants.SCHEDULE_TYPE, ExperimentScheduleType.EXPERIMENT_START.getScheduleType().toString());
				ExperimentSchedule.deleteExperimentSchedule(scheduleHs);

				scheduleHs.put(ExperimentScheduleConstants.SCHEDULE_TYPE, ExperimentScheduleType.EXPERIMENT_STOP.getScheduleType().toString());
				ExperimentSchedule.deleteExperimentSchedule(scheduleHs);
				
				if(ExperimentStatus.RUNNING.getStatusCode().equals(Integer.parseInt(oldValues.get(ExperimentConstants.EXPERIMENT_STATUS))))
				{
					hs.remove(ExperimentConstants.START_DATE);
					hs.remove(ExperimentConstants.END_DATE);
				}
			}

			//Event Activity Log
			HashMap<String, String> updatedValues = new HashMap<String, String>();
			updatedValues.putAll(hs);
			updatedValues.put(EventActivityConstants.EXPERIMENT_ID, experimentId.toString());
			if(ZABUtil.getCurrentUser() != null)
			{
				updatedValues.put(EventActivityConstants.USER_ID, ZABUtil.getCurrentUser().getUserId().toString());
			}
			updatedValues.put(EventActivityConstants.TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
			EventActivityWrapper activityWrapper = new EventActivityWrapper();
			activityWrapper.setModule(Module.EXPERIMENT);
			activityWrapper.setOperationType(com.zoho.abtest.eventactivity.EventActivityConstants.OperationType.UPDATE);
			activityWrapper.setDbSpace(ZABUtil.getCurrentUserDbSpace());
			activityWrapper.setUpdatedValues(updatedValues);
			activityWrapper.setOldValues(oldValues);
			ZABNotifier.notifyListeners(EventActivityConstants.EVENT_MODULE_NAME, activityWrapper);
			
			//Admin console record
			HashMap<String, String> acHs = new HashMap<String, String>();
			acHs.put(AdminConsoleConstants.EXPERIMENT_ID, experimentId.toString());
			acHs.put(AdminConsoleConstants.ZSOID, ZABUtil.getDBSpace());
			acHs.put(AdminConsoleConstants.MODIFIED_TIME, currentTime.toString());
			if(hs.containsKey(ExperimentConstants.EXPERIMENT_STATUS))
			{
				acHs.put(AdminConsoleConstants.EXPERIMENT_STATUS, hs.get(ExperimentConstants.EXPERIMENT_STATUS));
			}
			if(hs.containsKey(ExperimentConstants.IS_ACTIVE))
			{
				acHs.put(AdminConsoleConstants.IS_ACTIVE, hs.get(ExperimentConstants.IS_ACTIVE));
			}
			AdminConsoleWrapper acWrapper = new AdminConsoleWrapper();
			acWrapper.setValueHs(acHs);
			acWrapper.setOperationType(AcOperationType.EXPERIMENT_UPDATE);
			ZABNotifier.notifyListeners(AdminConsoleConstants.ADMIN_CONSOLE_MODULE_NAME,acWrapper);

		} catch (ResourceNotFoundException | ZABException e) {
			experiment = new Experiment();
			experiment.setSuccess(Boolean.FALSE);
			experiment.setResponseString(e.getMessage());
			if(e instanceof ResourceNotFoundException) {
				experiment.setResponseCode(((ResourceNotFoundException) e).getErrorCode());
			}
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
			if(mgr!=null && !alreadyInTransaction) {
				try {
					mgr.rollback();
				} catch (Exception e1) {
					LOGGER.log(Level.SEVERE,"Exception Occurred",e1);
				}
			}
		} catch (Exception e) {
			experiment = new Experiment();
			experiment.setSuccess(Boolean.FALSE);
			experiment.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			if(mgr!=null && !alreadyInTransaction) {
				try {
					mgr.rollback();
				} catch (Exception e1) {
					LOGGER.log(Level.SEVERE,"Exception Occurred",e1);
				}
			}
		}
		return experiment;
	}

	public static ArrayList<Experiment> getExperimentsByCriteria(Criteria c) {
		ArrayList<Experiment> experiments = new ArrayList<Experiment>();
		try {
			Join join1=new Join(EXPERIMENT.TABLE,PROJECT.TABLE,new String[]{EXPERIMENT.PROJECT_ID},new String[]{PROJECT.PROJECT_ID},Join.INNER_JOIN);
			DataObject dobj = getRow(EXPERIMENT.TABLE, c, join1);
			experiments.addAll(getExperimentFromDobj(dobj));
		} catch (Exception e) {
			Experiment experiment = new Experiment();
			experiment.setSuccess(Boolean.FALSE);
			experiment.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			experiments.add(experiment);
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return experiments;
	}

	public static Experiment getExperimentByLinkname(String linkname) {
		Experiment experiment = null;
		Criteria c = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_LINK_NAME), linkname, QueryConstants.EQUAL);
		ArrayList<Experiment> experiments = getExperimentsByCriteria(c);
		if(experiments!=null && !experiments.isEmpty()) {
			Experiment eObj = experiments.get(0);
			if(eObj.getSuccess()) {
				experiment = eObj;
			}
		}
		return experiment;
	}
	
	public static Integer getExperimentTypeByLinkname(String linkname)throws Exception {
		Integer expType = null; 
		Criteria c = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_LINK_NAME), linkname, QueryConstants.EQUAL);
		DataObject dataObj = ZABModel.getRow(EXPERIMENT.TABLE, c);
		if(dataObj.containsTable(EXPERIMENT.TABLE))
		{
			expType = (Integer)dataObj.getFirstValue(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_TYPE);
		}
		return expType;
	}
	
	public static Experiment getExperimentByNameInProject(String displayname,Long projectId, Criteria cext) {
		Experiment experiment = null;
		Criteria c1 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_NAME), displayname, QueryConstants.EQUAL, Boolean.FALSE);
		Criteria c2 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.PROJECT_ID), projectId, QueryConstants.EQUAL);
		Criteria c = c1.and(c2).and(cext);
		ArrayList<Experiment> experiments = getExperimentsByCriteria(c);
		if(experiments!=null && !experiments.isEmpty()) {
			Experiment eObj = experiments.get(0);
			if(eObj.getSuccess()) {
				experiment = eObj;
			}
		}
		return experiment;
	}

	public static Experiment getExperimentByKey(String experimentKey) {

		Experiment experiment = null;
		Criteria c = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_KEY), experimentKey, QueryConstants.EQUAL);
		ArrayList<Experiment> experiments = getExperimentsByCriteria(c);
		if(experiments!=null && !experiments.isEmpty()) {
			Experiment eObj = experiments.get(0);
			if(eObj.getSuccess()) {
				experiment = eObj;
			}
		}
		return experiment;
	}

	public static Experiment addDuplicateExperimentRow(Row row) throws Exception {
		String displayName = (String)row.get(EXPERIMENT.EXPERIMENT_NAME);
		Long projectId = (Long)row.get(EXPERIMENT.PROJECT_ID);
		Integer experimentType = (Integer)row.get(EXPERIMENT.EXPERIMENT_TYPE);
		Criteria c1 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.PROJECT_ID), projectId, QueryConstants.EQUAL);
		Criteria c2 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_TYPE), experimentType, QueryConstants.EQUAL);
		displayName = generateName(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_NAME, displayName, c1.and(c2));
		String newLinkname = generateLinkName(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_LINK_NAME, null, null, displayName);
		String key = generateUniqueId(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_KEY);
		DataObject wdobj = new WritableDataObject();
		Long currentTime = ZABUtil.getCurrentTimeInMilliSeconds();
		Row newERow = new Row(EXPERIMENT.TABLE);
		newERow.set(EXPERIMENT.EXPERIMENT_NAME, displayName);
		newERow.set(EXPERIMENT.EXPERIMENT_LINK_NAME, newLinkname);
		newERow.set(EXPERIMENT.EXPERIMENT_STATUS, ExperimentStatus.DRAFT.getStatusCode());
		newERow.set(EXPERIMENT.EXPERIMENT_KEY, key);
		newERow.set(EXPERIMENT.CREATED_TIME, currentTime);
		newERow.set(EXPERIMENT.CREATED_BY, ZABUtil.getCurrentUser().getUserId());
		newERow.set(EXPERIMENT.EXPERIMENT_TYPE, (Integer)row.get(EXPERIMENT.EXPERIMENT_TYPE));
		newERow.set(EXPERIMENT.PROJECT_ID, projectId);
	
		wdobj.addRow(newERow);
		updateDataObject(wdobj);
		return getExperimentFromRow(newERow);
	}

	public static Experiment duplicateExperiment(DataObject dobj) {
		Experiment experiment = null;
		try {		
			if(dobj.containsTable(EXPERIMENT.TABLE)) {
				Row row = dobj.getRow(EXPERIMENT.TABLE);

				//Add experiment row
				experiment = addDuplicateExperimentRow(row);	
				experiment.setCreatedByName(ZABUser.getCurrentUser().getName());

				//Add audience row
				Iterator audienceIterator = dobj.getRows(EXPERIMENT_AUDIENCE.TABLE);
				while(audienceIterator.hasNext()) {
					Row earow = (Row)audienceIterator.next();
					Long audienceId = (Long)earow.get(EXPERIMENT_AUDIENCE.AUDIENCE_ID);
					//If audience is decided to be used globally just link the audience instead of creating a new one
					//Audience audience = Audience.addDuplicateAudienceRow(audienceId,null);
					//					if(audience!=null) {
					ExperimentAudience.createExperimentAudienceWithoutEvent(audienceId, experiment.getExperimentId());
					//					}
				}

				//Add dyn attr row
				Iterator dynattrIterator = dobj.getRows(EXPERIMENT_DYNAMIC_ATTR.TABLE);
				while(dynattrIterator.hasNext()) {
					Row edarow = (Row)dynattrIterator.next();
					Long daid = (Long)edarow.get(EXPERIMENT_DYNAMIC_ATTR.DYNAMIC_ATTRIBUTE_ID);
					DynamicAttributes datr = DynamicAttributes.addDuplicateDynamicAttribute(daid);
					if(datr!=null) {						
						ExperimentDynamicAttribute.createDynamicAttributeMappingWithoutEvent(datr.getDynamicAttributeId(), experiment.getExperimentId());
					}
				}

				//Add integration row
				Long exp_pro_integrationid = 0L;
				Iterator integrationIterator = dobj.getRows(EXPERIMENT_PROJECT_INTEGRATION.TABLE);
				while(integrationIterator.hasNext()) {
					Row eiarow = (Row)integrationIterator.next();
					exp_pro_integrationid = Integration.duplicateExperimentIntegrationMapping(eiarow, experiment.getExperimentId());
					
				}
				
				//Add Google Analytics row
				Iterator gaIterator = dobj.getRows(GOOGLE_ANALYTICS_DETAILS.TABLE);
				while(gaIterator.hasNext()) {
					Row garow = (Row)gaIterator.next();
					Integration.duplicateGoogleAnalyticsMapping(garow,exp_pro_integrationid);
				}

				//Done have to trigger event to update javascript here as the status of this experiment will be in draft

			} else {
				experiment = new Experiment();
				experiment.setSuccess(Boolean.FALSE);
				experiment.setResponseString(ZABAction.getMessage(ZABConstants.ErrorMessages.RESOURCE_NOT_FOUND.getErrorString(),new String[]{ExperimentConstants.API_MODULE}));
				return experiment;
			}
			
			//Saving the Experiment display name for the use of event activity
			if(experiment != null && experiment.getExperimentId() != null) {
				HashMap<String, String> eventModuleHs = new HashMap<String, String>();
				eventModuleHs.put(EventActivityConstants.MODULE_TYPE, Module.EXPERIMENT.getValue().toString());
				eventModuleHs.put(EventActivityConstants.MODULE_ELEMENT_ID, experiment.getExperimentId().toString());
				eventModuleHs.put(EventActivityConstants.MODULE_ELEMENT_NAME, experiment.getExperimentName());
				EventModuleDetail.createEventModuleDetail(eventModuleHs);
			}
			
			//Event Activity Log
			HashMap<String, String> updatedValues = new HashMap<String, String>();
			updatedValues.put(EventActivityConstants.EXPERIMENT_ID, experiment.getExperimentId().toString());
			updatedValues.put(EventActivityConstants.USER_ID, ZABUtil.getCurrentUser().getUserId().toString());
			updatedValues.put(EventActivityConstants.TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
			EventActivityWrapper activityWrapper = new EventActivityWrapper();
			activityWrapper.setModule(Module.EXPERIMENT);
			activityWrapper.setOperationType(com.zoho.abtest.eventactivity.EventActivityConstants.OperationType.CREATE);
			activityWrapper.setDbSpace(ZABUtil.getCurrentUserDbSpace());
			activityWrapper.setUpdatedValues(updatedValues);
			ZABNotifier.notifyListeners(EventActivityConstants.EVENT_MODULE_NAME, activityWrapper);
			
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
			experiment = new Experiment();
			experiment.setSuccess(Boolean.FALSE);
			experiment.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			return experiment;
		}

		return experiment;
	}

	public static ArrayList<Experiment> getExperiments() {
		return getExperimentsByCriteria(null);
	}

	private static void setCriteriaFromQParam(SelectQuery query) throws ZABException {
		HttpServletRequest request = ZABUtil.getCurrentRequest();
		String projectLinkname = request.getParameter(ExperimentConstants.PROJECT_LINKNAME);
		String experimentStatus = request.getParameter(ExperimentConstants.EXPERIMENT_STATUS);
		String isActive = request.getParameter(ExperimentConstants.IS_ACTIVE);
		String experimentType = request.getParameter(ExperimentConstants.EXPERIMENT_TYPE);
		Boolean isActiveBool = (isActive==null)?null:Boolean.parseBoolean(isActive);
		Integer experimentStatusCode = null;
		Integer experimentTypeNum = null;
		
		Criteria c = null;
		if(projectLinkname!=null) {
			Long projectId = Project.getProjectId(projectLinkname); 
			if(projectId==null) {
				throw new ZABException(ZABAction.getMessage(ZABConstants.RESOURCE_WITHLNAME_NOTEXISTS, new String[]{ProjectConstants.PROJECT_LABEL, projectLinkname})); 
			}
			c = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.PROJECT_ID), projectId, QueryConstants.EQUAL);
		}

		try {
			if(experimentStatus!=null) {				
				experimentStatusCode = Integer.parseInt(experimentStatus);
				Criteria c1 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_STATUS), experimentStatusCode, QueryConstants.EQUAL);
				c = (c==null)?c1:c.and(c1);
			}
		} catch (NumberFormatException e) {
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		
		try {
			if(experimentType!=null) {				
				experimentTypeNum = Integer.parseInt(experimentType);
				Criteria c1 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_TYPE), experimentTypeNum, QueryConstants.EQUAL);
				c = (c==null)?c1:c.and(c1);
			}
		} catch (NumberFormatException e) {
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}

		//		if(experimentStatusCode == null || !experimentStatusCode.equals(ExperimentStatus.ARCHIVED.getStatusCode())) {
		//			//By default fetch only
		//			Criteria c3 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_STATUS), ExperimentStatus.ARCHIVED.getStatusCode(), QueryConstants.NOT_EQUAL);
		//			c = (c==null)?c3:c.and(c3);
		//		}

		if(isActiveBool!=null) {
			Criteria c3 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.IS_ACTIVE), isActiveBool, QueryConstants.EQUAL);
			c = (c==null)?c3:c.and(c3);
		}


		/*TO FACILITATE SEARCH OF EXPERIMENT*/
		String searchTerm = request.getParameter(SearchConstants.SEARCH_NAME);
		if(searchTerm!=null) {
			Criteria c4 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_NAME), searchTerm, QueryConstants.CONTAINS,Boolean.FALSE);
			c = (c==null)?c4:c.and(c4);
		}
		
		/*Trying out this*/
		Integer[] types = new Integer[]{ExperimentType.ENABLED_HEATMAP.getTypeNumber()};
		Criteria c5 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_TYPE), types, QueryConstants.NOT_IN);
		c = (c==null)?c5:c.and(c5);

		query.setCriteria(c);
	}

	public static ArrayList<Experiment> getAllExperimentsByCurrentUser(String url, String name) {
		ArrayList<Experiment> experiments = new ArrayList<Experiment>();

		try {
			Long currentUserId = ZABUtil.getCurrentUser().getUserId();
			Criteria c = new Criteria (new Column(PROJECT_USER_ROLE.TABLE,PROJECT_USER_ROLE.USER_ID),currentUserId,QueryConstants.EQUAL);
			//TODO Temporarily Commenting
			/*if(url!=null) {
				Criteria c2 = new Criteria (new Column(EXPERIMENT.TABLE,EXPERIMENT.EXPERIMENT_URL),url,QueryConstants.EQUAL);
				c = c.and(c2);
			}*/
			if(name!=null) {
				Criteria c2 = new Criteria (new Column(EXPERIMENT.TABLE,EXPERIMENT.EXPERIMENT_NAME),name, QueryConstants.CONTAINS,Boolean.FALSE);
				c = c.and(c2);
			}
			Join join1 = new Join(PROJECT_USER_ROLE.TABLE,PROJECT.TABLE,new String[]{PROJECT_USER_ROLE.PROJECT_ID},new String[]{PROJECT.PROJECT_ID},Join.INNER_JOIN);
			Join join2 = new Join(PROJECT.TABLE,EXPERIMENT.TABLE,new String[]{PROJECT.PROJECT_ID},new String[]{EXPERIMENT.PROJECT_ID},Join.INNER_JOIN);
			DataObject dobj = getRow(PROJECT_USER_ROLE.TABLE, c, new Join[]{join1, join2});
			if(dobj.containsTable(EXPERIMENT.TABLE)) {
				Iterator<Row> it = dobj.getRows(EXPERIMENT.TABLE);
				while(it.hasNext()) {
					Row row = it.next();
					Experiment exp = getExperimentFromRow(row);
					Criteria c2 = new Criteria(new Column(PROJECT.TABLE, PROJECT.PROJECT_ID), exp.getProjectId(), QueryConstants.EQUAL);
					Row row2 = dobj.getRow(PROJECT.TABLE, c2);
					if(row2 !=null) {
						String projectLinkname = (String) row2.get(PROJECT.PROJECT_LINK_NAME);
						exp.setProjectLinkname(projectLinkname);
					}
					experiments.add(exp);
				}
			}
			
			ZABUser.setUserDetails(experiments, new ZABUserDetailWrapper() {
				
				@Override
				public void setUserDetails(User user, ZABModel model) {
					Experiment exe = (Experiment)model;
					exe.setCreatedByName(user.getFirstName());
				}
				@Override
				public Long getUserId(ZABModel model) {
					Experiment exe = (Experiment)model;
					return exe.getCreateBy();
				}
			});

		} catch(Exception e) {
			experiments.clear();
			Experiment experiment = new Experiment();
			experiment.setSuccess(Boolean.FALSE);
			experiment.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			experiments.add(experiment);
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return experiments;
	}

	public static ArrayList<Experiment> getExperimentsWithDetails() {
		ArrayList<Experiment> experiments = new ArrayList<Experiment>();
		try {
			SelectQuery query = new SelectQueryImpl(new Table(EXPERIMENT.TABLE));
			query.addSelectColumns(getColumnsWithAliasPrefix(ExperimentConstants.EXPERIMENT_TABLE, EXPERIMENT.TABLE+".", EXPERIMENT.TABLE));
			SortColumn sort = new SortColumn(new Column(EXPERIMENT.TABLE, EXPERIMENT.CREATED_TIME), Boolean.FALSE);
			query.addSortColumn(sort, 0);

			setCriteriaFromQParam(query);
			
			final String projectLinkname = ZABUtil.getCurrentRequest().getParameter(ExperimentConstants.PROJECT_LINKNAME);

			//GroupByClause gc = new GroupByClause(Arrays.asList(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_ID)));
			//query.setGroupByClause(gc);

			final HashMap<Long, Experiment> experimentIdMap = new HashMap<Long, Experiment>();

			ZABUserBean bean= (ZABUserBean)BeanUtil.lookup(ZABUserBean.BEAN_NAME, ZABUtil.getCurrentUserDbSpace());
			bean.executeQuery(query, new DataSetWrapper() {
				/* (non-Javadoc)
				 * @see com.zoho.abtest.utility.DataSetWrapper#execute(com.adventnet.ds.query.DataSet)
				 */
				@Override
				public void execute(DataSet ds) throws Exception {
					while(ds.next()) {		
						Experiment exp = Experiment.getExperimentFromDataSet(ds, EXPERIMENT.TABLE+".");
						exp.setProjectLinkname(projectLinkname);
						experimentIdMap.put(exp.getExperimentId(), exp);
					}

				}
			});

			experiments = new ArrayList<Experiment>(experimentIdMap.values());
			ZABUser.setUserDetails(experiments, new ZABUserDetailWrapper() {
				@Override
				public void setUserDetails(User user, ZABModel model) {
					Experiment exe = (Experiment)model;
					exe.setCreatedByName(user.getFirstName() + " "  + user.getLastName());
				}
				@Override
				public Long getUserId(ZABModel model) {
					Experiment exe = (Experiment)model;
					return exe.getCreateBy();
				}
			});

		}
		catch (ZABException e) {
			experiments.clear();
			Experiment experiment = new Experiment();
			experiment.setSuccess(Boolean.FALSE);
			experiment.setResponseString(e.getMessage());
			experiments.add(experiment);
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		catch (Exception e) {
			experiments.clear();
			Experiment experiment = new Experiment();
			experiment.setSuccess(Boolean.FALSE);
			experiment.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			experiments.add(experiment);
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return experiments;
	}
	
	/*
	public static ArrayList<Experiment> getExperimentsWithDetails() {
		ArrayList<Experiment> experiments = new ArrayList<Experiment>();
		try {
			Join join2=new Join(EXPERIMENT.TABLE,VARIATION.TABLE,new String[]{EXPERIMENT.EXPERIMENT_ID},new String[]{VARIATION.EXPERIMENT_ID},Join.LEFT_JOIN);
			Join join3=new Join(EXPERIMENT.TABLE,EXPERIMENT_GOAL.TABLE,new String[]{EXPERIMENT.EXPERIMENT_ID},new String[]{EXPERIMENT_GOAL.EXPERIMENT_ID},Join.LEFT_JOIN);
			Column variationCount = new Column(VARIATION.TABLE, VARIATION.VARIATION_ID).distinct().count();
			variationCount.setColumnAlias(ExperimentConstants.VARIATION_COUNT);
			Column goalCount = new Column(EXPERIMENT_GOAL.TABLE, EXPERIMENT_GOAL.EXPERIMENT_GOAL_ID).distinct().count();
			goalCount.setColumnAlias(ExperimentConstants.GOAL_COUNT);
			SelectQuery query = new SelectQueryImpl(new Table(EXPERIMENT.TABLE));
			query.addSelectColumns(getColumnsWithAliasPrefix(ExperimentConstants.EXPERIMENT_TABLE, EXPERIMENT.TABLE+".", EXPERIMENT.TABLE));
			query.addSelectColumn(variationCount);
			query.addSelectColumn(goalCount);
			query.addJoin(join2);
			query.addJoin(join3);
			SortColumn sort = new SortColumn(new Column(EXPERIMENT.TABLE, EXPERIMENT.CREATED_TIME), Boolean.FALSE);
			query.addSortColumn(sort, 0);

			setCriteriaFromQParam(query);
			final String projectLinkname = ZABUtil.getCurrentRequest().getParameter(ExperimentConstants.PROJECT_LINKNAME);

			GroupByClause gc = new GroupByClause(Arrays.asList(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_ID)));
			query.setGroupByClause(gc);

			final HashMap<Long, Experiment> experimentIdMap = new HashMap<Long, Experiment>();

			ZABUserBean bean= (ZABUserBean)BeanUtil.lookup(ZABUserBean.BEAN_NAME, ZABUtil.getCurrentUserDbSpace());
			bean.executeQuery(query, new DataSetWrapper() {
				@Override
				public void execute(DataSet ds) throws Exception {
					while(ds.next()) {		
						Experiment exp = Experiment.getExperimentFromDataSet(ds, EXPERIMENT.TABLE+".");
						exp.setProjectLinkname(projectLinkname);
						experimentIdMap.put(exp.getExperimentId(), exp);
					}

				}
			});

			Experiment.setVisitorCountForExperiment(experimentIdMap);
			Experiment.getExperimentWinners(experimentIdMap);

			experiments = new ArrayList<Experiment>(experimentIdMap.values());
			ZABUser.setUserDetails(experiments, new ZABUserDetailWrapper() {
				@Override
				public void setUserDetails(User user, ZABModel model) {
					Experiment exe = (Experiment)model;
					exe.setCreatedByName(user.getFirstName());
				}
				@Override
				public Long getUserId(ZABModel model) {
					Experiment exe = (Experiment)model;
					return exe.getCreateBy();
				}
			});

		}
		catch (ZABException e) {
			experiments.clear();
			Experiment experiment = new Experiment();
			experiment.setSuccess(Boolean.FALSE);
			experiment.setResponseString(e.getMessage());
			experiments.add(experiment);
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		catch (Exception e) {
			experiments.clear();
			Experiment experiment = new Experiment();
			experiment.setSuccess(Boolean.FALSE);
			experiment.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			experiments.add(experiment);
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return experiments;
	}
	 */
	
	public static Experiment deleteExperiment(String linkname){
		Experiment experiment = null;
		try {			
			Criteria c = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_LINK_NAME), linkname, QueryConstants.EQUAL);
			Experiment exp = Experiment.getExperimentByLinkname(linkname);
			if(exp==null) {
				throw new ResourceNotFoundException(ExperimentConstants.API_MODULE);
			}
			Long experimentId = exp.getExperimentId();
			Long projectId = exp.getProjectId();
			//Running/Scheduled experiment cannot be archived
			if(exp.getExperimentStatus().equals(ExperimentConstants.ExperimentStatus.RUNNING.getStatusCode()) || 
			   exp.getExperimentStatus().equals(ExperimentConstants.ExperimentStatus.SCHEDULED.getStatusCode()))
			{
				experiment = new Experiment();
				experiment.setSuccess(Boolean.FALSE);
				experiment.setResponseString(ZABAction.getMessage(ExperimentConstants.EXPERIMENT_STATUS_DELETE_ERROR));
				return experiment;
			}
			
			
			ArrayList<Row> rows = deleteRow(EXPERIMENT.TABLE, c, ExperimentConstants.API_MODULE);
			if(rows.size() > 0) {
				Row row = rows.get(0);
				experiment = new Experiment();
				getExperimentFromRow(row,experiment);
				//Notify event
				ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
				wrapper.setModel(experiment);
				wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
				wrapper.setType(OperationType.DELETE);
				ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);

				//Event Activity Log
				HashMap<String, String> updatedValues = new HashMap<String, String>();
				updatedValues.put(EventActivityConstants.EXPERIMENT_ID, experimentId.toString());
				updatedValues.put(EventActivityConstants.PROJECT_ID, projectId.toString());
				updatedValues.put(EventActivityConstants.USER_ID, ZABUtil.getCurrentUser().getUserId().toString());
				updatedValues.put(EventActivityConstants.TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
				EventActivityWrapper activityWrapper = new EventActivityWrapper();
				activityWrapper.setModule(Module.EXPERIMENT);
				activityWrapper.setOperationType(com.zoho.abtest.eventactivity.EventActivityConstants.OperationType.DELETE);
				activityWrapper.setDbSpace(ZABUtil.getCurrentUserDbSpace());
				activityWrapper.setUpdatedValues(updatedValues);
				ZABNotifier.notifyListeners(EventActivityConstants.EVENT_MODULE_NAME, activityWrapper);
				
				//Admin console record
				HashMap<String, String> acHs = new HashMap<String, String>();
				acHs.put(AdminConsoleConstants.EXPERIMENT_ID, experimentId.toString());
				acHs.put(AdminConsoleConstants.ZSOID, ZABUtil.getDBSpace());
				AdminConsoleWrapper acWrapper = new AdminConsoleWrapper();
				acWrapper.setValueHs(acHs);
				acWrapper.setOperationType(AcOperationType.EXPERIMENT_DELETE);
				ZABNotifier.notifyListeners(AdminConsoleConstants.ADMIN_CONSOLE_MODULE_NAME,acWrapper);
			}
		} catch(ResourceNotFoundException re) {
			experiment = new Experiment();
			setModelWithRNFData(experiment, re);
		} catch (Exception e) {
			experiment = new Experiment();
			experiment.setSuccess(Boolean.FALSE);
			experiment.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return experiment;
	}

	public static Long getExperimentId(String linkname) {
		Long experimentId = null;
		try {
			Criteria c = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_LINK_NAME), linkname, QueryConstants.EQUAL);
			DataObject dobj = getRow(EXPERIMENT.TABLE, c);
			if(dobj.containsTable(EXPERIMENT.TABLE)) {
				Row row = dobj.getFirstRow(EXPERIMENT.TABLE);
				experimentId = (Long)row.get(EXPERIMENT.EXPERIMENT_ID);
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return experimentId;
	}
	
	public static Long getExperimentIdByExperimentKey(String experimentKey) {
		Long experimentId = null;
		try {
			Criteria c = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_KEY), experimentKey, QueryConstants.EQUAL);
			DataObject dobj = getRow(EXPERIMENT.TABLE, c);
			if(dobj.containsTable(EXPERIMENT.TABLE)) {
				Row row = dobj.getFirstRow(EXPERIMENT.TABLE);
				experimentId = (Long)row.get(EXPERIMENT.EXPERIMENT_ID);
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return experimentId;
	}
	
	public static String getExperimentKeyByLinkname(String linkname) {
		String experimentKey = null;
		try {
			Criteria c = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_LINK_NAME), linkname, QueryConstants.EQUAL);
			DataObject dobj = getRow(EXPERIMENT.TABLE, c);
			if(dobj.containsTable(EXPERIMENT.TABLE)) {
				Row row = dobj.getFirstRow(EXPERIMENT.TABLE);
				experimentKey = (String)row.get(EXPERIMENT.EXPERIMENT_KEY);
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return experimentKey;
	}
	
	public static String getExperimentKeyById(Long id) {
		String experimentKey = null;
		try {
			Criteria c = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_ID), id, QueryConstants.EQUAL);
			DataObject dobj = getRow(EXPERIMENT.TABLE, c);
			if(dobj.containsTable(EXPERIMENT.TABLE)) {
				Row row = dobj.getFirstRow(EXPERIMENT.TABLE);
				experimentKey = (String)row.get(EXPERIMENT.EXPERIMENT_KEY);
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return experimentKey;
	}
	
	public static String getExperimentLinkname(Long experimentId) {
		String linkname = null;
		try {
			Criteria c = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
			DataObject dobj = getRow(EXPERIMENT.TABLE, c);
			if(dobj.containsTable(EXPERIMENT.TABLE)) {
				Row row = dobj.getFirstRow(EXPERIMENT.TABLE);
				linkname = (String)row.get(EXPERIMENT.EXPERIMENT_LINK_NAME);
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return linkname;
	}

	public static Experiment getExperimentById(Long id) {
		Experiment experiment = null;
		try {
			Criteria c = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_ID), id, QueryConstants.EQUAL);
			DataObject dobj = getRow(EXPERIMENT.TABLE, c);
			if(dobj.containsTable(EXPERIMENT.TABLE)) {
				Row row = dobj.getFirstRow(EXPERIMENT.TABLE);
				experiment = new Experiment();
				getExperimentFromRow(row,experiment);
				getShareUrlOfExperiment(experiment);
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return experiment;
	}

	public static HashMap<String,String> generateHashMapFromExperimentObj(Experiment exp, HashMap<String,String> hs) {
		HashMap<String,String> oldValues = new HashMap<String,String>();
		try
		{

			for(String attributeName:EventActivityConstants.EXPERIMENT_ATTR_TO_TRACE)
			{
				if(hs.containsKey(attributeName))
				{
					switch(attributeName)
					{
					case ExperimentConstants.EXPERIMENT_NAME:
						oldValues.put(ExperimentConstants.EXPERIMENT_NAME, exp.getExperimentName());
						break;
					/*case ExperimentConstants.EXPERIMENT_URL:
						oldValues.put(ExperimentConstants.EXPERIMENT_URL, exp.getExperimentUrl());
						break;*/
					case ExperimentConstants.EXPERIMENT_STATUS:
						//TODO
						oldValues.put(ExperimentConstants.EXPERIMENT_STATUS, exp.getExperimentStatus().toString());
						break;
					/*case ExperimentConstants.PERMITTED_TRAFFIC:
						oldValues.put(ExperimentConstants.PERMITTED_TRAFFIC, exp.getPermittedTraffic().toString());
						break;
					case ExperimentConstants.STATISTICAL_SIGNIFICANCE:
						oldValues.put(ExperimentConstants.STATISTICAL_SIGNIFICANCE, exp.getStatisticalSignificance().toString());
						break;*/
					case ExperimentConstants.START_DATE:
						//TODO
						oldValues.put(ExperimentConstants.START_DATE, exp.getStartDate()!=null?exp.getStartDate().toString():null);
						break;
					case ExperimentConstants.END_DATE:
						//TODO
						oldValues.put(ExperimentConstants.END_DATE, exp.getEndDate()!=null?exp.getEndDate().toString():null);
						break;
					}
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		return oldValues;
	}

	public static HashMap<String,String> generateHashMapFromExperimentObj(String expLinkName, HashMap<String,String> hs)
	{
		Experiment exp = Experiment.getExperimentByLinkname(expLinkName);
		return generateHashMapFromExperimentObj(exp, hs);
	}

	public static Long getProjectIdByExperimentId(Long experimentId)
	{
		Long projectId = null;
		try
		{
			Criteria criteria = new Criteria(new Column(EXPERIMENT.TABLE,EXPERIMENT.EXPERIMENT_ID),experimentId,QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(EXPERIMENT.TABLE, criteria);
			projectId = (Long)dataObj.getFirstValue(EXPERIMENT.TABLE, EXPERIMENT.PROJECT_ID);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		return projectId;
	}

	public static Long getProjectIdByExperimentLinkName(String experimentLinkName)
	{
		Long projectId = null;
		try
		{
			Criteria criteria = new Criteria(new Column(EXPERIMENT.TABLE,EXPERIMENT.EXPERIMENT_LINK_NAME),experimentLinkName,QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(EXPERIMENT.TABLE, criteria);
			projectId = (Long)dataObj.getFirstValue(EXPERIMENT.TABLE, EXPERIMENT.PROJECT_ID);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		return projectId;
	}
	
	public static Long getProjectIdByExperimentKey(String experimentKey)
	{
		Long projectId = null;
		try
		{
			Criteria criteria = new Criteria(new Column(EXPERIMENT.TABLE,EXPERIMENT.EXPERIMENT_KEY),experimentKey,QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(EXPERIMENT.TABLE, criteria);
			projectId = (Long)dataObj.getFirstValue(EXPERIMENT.TABLE, EXPERIMENT.PROJECT_ID);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		return projectId;
	}

	public static Long getActiveDurationOfExp(Long experimentId)
	{
		Long timeGapInMillis = 0l;
		try
		{
			Criteria criteria1 = new Criteria(new Column(EVENT_ACTIVITY_LOG.TABLE, EVENT_ACTIVITY_LOG.EXPERIMENT_ID),experimentId,QueryConstants.EQUAL);
			Criteria criteria2 = new Criteria(new Column(EVENT_ACTIVITY_LOG.TABLE, EVENT_ACTIVITY_LOG.EVENT_TYPE),EventType.EXPERIMENT_STATUS_UPDATE.getEventValue(),QueryConstants.EQUAL);
			Criteria criteria3 = new Criteria(new Column(EVENT_ACTIVITY_LOG.TABLE, EVENT_ACTIVITY_LOG.VALUE),new String[]{ExperimentStatus.RUNNING.name(),ExperimentStatus.PAUSED.name()},QueryConstants.IN);
			SortColumn sortColumn = new SortColumn(EVENT_ACTIVITY_LOG.TABLE, EVENT_ACTIVITY_LOG.TIME, Boolean.TRUE);
			List<Long> startTimeList = new ArrayList<Long>();
			List<Long> endTimeList = new ArrayList<Long>();
			DataObject dataObj = ZABModel.getRow(EVENT_ACTIVITY_LOG.TABLE, criteria1.and(criteria2).and(criteria3),sortColumn,null);
			if(!dataObj.isEmpty())
			{
				Criteria criteria4 = new Criteria(new Column(EVENT_ACTIVITY_LOG.TABLE, EVENT_ACTIVITY_LOG.VALUE),ExperimentStatus.RUNNING.name(),QueryConstants.EQUAL);
				Iterator<?> runObjIter= dataObj.getRows(EVENT_ACTIVITY_LOG.TABLE, criteria4);
				while(runObjIter.hasNext())
				{
					Row row = (Row)runObjIter.next();
					Long time = (Long)row.get(EVENT_ACTIVITY_LOG.TIME);
					startTimeList.add(time);
				}
				Criteria criteria5 = new Criteria(new Column(EVENT_ACTIVITY_LOG.TABLE, EVENT_ACTIVITY_LOG.VALUE),ExperimentStatus.PAUSED.name(),QueryConstants.EQUAL);
				Criteria criteria6 = new Criteria(new Column(EVENT_ACTIVITY_LOG.TABLE, EVENT_ACTIVITY_LOG.OLD_VALUE),ExperimentStatus.RUNNING.name(),QueryConstants.EQUAL);
				Iterator<?> pauseObjIter= dataObj.getRows(EVENT_ACTIVITY_LOG.TABLE, criteria5.and(criteria6));
				while(pauseObjIter.hasNext())
				{
					Row row = (Row)pauseObjIter.next();
					Long time = (Long)row.get(EVENT_ACTIVITY_LOG.TIME);
					endTimeList.add(time);
				}
			}
			
			//Calculate the count of timeinmillis 
			
			int startListSize = startTimeList.size();
			int endListSize = endTimeList.size();
			for(int i=0;i<startListSize;i++)
			{
				Long startTime = startTimeList.get(i);
				if(endListSize > i)
				{
					Long endTime = endTimeList.get(i);
					timeGapInMillis += (endTime - startTime);
				}
				else
				{
					Long endTime = ZABUtil.getCurrentTimeInMilliSeconds();
					timeGapInMillis += (endTime - startTime);
					break;
				}
			}
			
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			
		}
		return timeGapInMillis;
	}
	public static String getActiveDurationOfExpString(Long timeGapInMillis)
	{
		String activeDurationStr = "";
		try
		{
			//Convert TimeinMillis to readable
			Long days = null;
			Long hours = TimeUnit.MILLISECONDS.toHours(timeGapInMillis);
			if(hours > 23)
			{
				days = hours/24;
				hours = hours % 24;
			}
			if(days != null)
			{
				String dayLabel = (days>1)?ZABAction.getMessage(ZABConstants.DAYS_LABEL):ZABAction.getMessage(ZABConstants.DAY_LABEL);
				activeDurationStr = days + " "+dayLabel+" ";
			}
			if(hours > 0)
			{
				String hourLabel = (hours>1)?ZABAction.getMessage(ZABConstants.HOURS_LABEL):ZABAction.getMessage(ZABConstants.HOUR_LABEL);
				activeDurationStr = activeDurationStr + hours + " "+hourLabel+" ";
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			activeDurationStr = "";
		}
		return activeDurationStr;
	}
	
	public static Long getExperimentActualStartTime(Long experimentId)
	{
		Long actualStartTime = null;
		try
		{
			Criteria criteria = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(EXPERIMENT.TABLE, criteria);
			actualStartTime = (Long)dataObj.getFirstValue(EXPERIMENT.TABLE, EXPERIMENT.ACTUAL_START_TIME);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			actualStartTime = null;
		}
		return actualStartTime;
	}
	
	public static ExperimentStatus getExperimentStatus(String linkname) throws Exception {
		ExperimentStatus status = null;
		Criteria c = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_LINK_NAME), linkname, QueryConstants.EQUAL);
		DataObject dobj = getRow(EXPERIMENT.TABLE, c);
		if(dobj.containsTable(EXPERIMENT.TABLE)) {
			Row row = dobj.getFirstRow(EXPERIMENT.TABLE);
			Integer statusCode = (Integer)row.get(EXPERIMENT.EXPERIMENT_STATUS);
			status = ExperimentStatus.getStatusByNumber(statusCode);
		}
		return status;
	}
	public static Experiment getShareUrlOfExperiment(Experiment experiment){
		try{
			if(experiment.getMakePublic().equals(Boolean.TRUE)){
				Long expid = experiment.getExperimentId();
				Criteria shareCri = new Criteria(new Column(SHARED_REPORT_DETAILS.TABLE,SHARED_REPORT_DETAILS.EXPERIMENT_ID),expid,QueryConstants.EQUAL);
				DataObject dobj  = ZABModel.getRow(SHARED_REPORT_DETAILS.TABLE, shareCri);
				String sharekey = (String)dobj.getFirstValue(SHARED_REPORT_DETAILS.TABLE, SHARED_REPORT_DETAILS.SHARE_KEY);
				String url = "pagesense/public/#/space/"+ZABUtil.getPortaldomain()+"/shared-reports/"+sharekey; // NO I18N
				String serverUrl ="http://"+ ApplicationProperty.getString("com.zoho.server")+"/";// NO I18N
				experiment.setShareUrl(serverUrl+url);
			}		
		}catch(Exception e ){
			e.printStackTrace();
		}
        return experiment;
	}

}
