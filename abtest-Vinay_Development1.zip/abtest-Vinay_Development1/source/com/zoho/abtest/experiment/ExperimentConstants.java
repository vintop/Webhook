//$Id$
package com.zoho.abtest.experiment;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.zoho.abtest.ABSPLITEXPERIMENT;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.conf.Configuration;

public class ExperimentConstants {
	
	public static final String API_MODULE = "experiment"; //No I18N
	
	public static final String API_MODULE_PLURAL = "experiments"; //No I18N
	
	public static final String API_RESOURCE = "resource.experiment"; //NO I18N
	
	public static final String API_RESOURCE_INITIAL = "resource.experiment.initial"; //NO I18N
	
	public static final String EXPERIMENT_ID = "experiment_id"; //No I18N
	
	public static final String PROJECT_LINKNAME = "project_linkname"; //NO I18N
	
	public static final String GOAL_LINKNAME = "goal_linkname"; //NO I18N
	
	public static final String PROJECT_ID = "project_id"; //NO I18N
	
	public static final String EXPERIMENT_NAME = "display_name"; //No I18N
	
	public static final String EXPERIMENT_LINKNAME = "linkname"; //No I18N
	
	public static final String EXPERIMENT_KEY = "experiment_key"; //No I18N
	
	public static final String EXPERIMENT_URL = "experiment_url"; //No I18N
	
	public static final String FORM_DETAILS= "form_details"; //No I18N
	
	public static final String EXPERIMENT_TYPE = "experiment_type"; //No I18N
	
	public static final String EXPERIMENT_STATUS = "experiment_status"; //No I18N
	
	public static final String EXPERIMENT_DETAIL_PERSONALITY = "experimentDetails"; //No I18N
	
	public static final String ACTIVATION_MODE = "activation_mode"; //No I18N
	
	public static final String ACTIVATON_CONDITION = "activation_condition"; //No I18N
	
	public static final String ALL_EXPERIMENTS_PERSONALITY = "allexperiments"; //No I18N
	
	public static final String CREATED_TIME = "created_time"; //No I18N
	
	public static final String CREATED_DATE = "created_date"; //No I18N
	
	public static final String CREATED_DATETIME = "created_datetime"; //No I18N
	
	public static final String MODIFIED_TIME = "modified_time"; //No I18N
	
	public static final String MODIFIED_DATE = "modified_date"; //No I18N
	
	public static final String MODIFIED_DATETIME = "modified_datetime"; //No I18N
	
	public static final String VARIATION = "variations"; //No I18N
	
	public static final String DURTATION = "duration"; //No I18N
	
	public static final String START_DATE = "start_date"; //No I18N
	
	public static final String ACTUAL_START_TIME = "actual_start_time"; //No I18N
	
	public static final String ACTUAL_END_TIME = "actual_end_time"; //No I18N
	
	public static final String PERMITTED_TRAFFIC = "permitted_traffic"; //No I18N
	
	public static final String END_DATE = "end_date"; // No I18N
	
	public static final String EXPERIMENT_SMALL_THUMBNAIL_URL = "small_thumbnail_url"; //No I18N
	
	public static final String EXPERIMENT_LARGE_THUMBNAIL_URL = "large_thumbnail_url"; //No I18N
	
	public static final String ACTIVE_DURATION = "active_duration"; //No I18N
	
	public static final String EXPERIMENT_TYPE_MODIFICATION_ERROR = "expeirment.type.modification.error"; //NO I18N
	
	public static final String EXPERIMENT_ARCHIVE_VALIDATION_ERROR = "experiment.archive.validation.error"; //NO I18N
	
	public static final String EXPERIMENT_SCHEDULE_VALIDATION_ERROR = "experiment.schedule.expirieddate.validation.error"; //NO I18N
	
	public static final String EXPERIMENT_STATUS_ARCHIVE_ERROR = "experiment.status.archive.error"; //NO I18N
	
	public static final String EXPERIMENT_STATUS_DELETE_ERROR = "experiment.delete.validation.error"; //NO I18N
	
	public static final String EXPERIMENT_STATUS_DRAFT_UPDATE_ERROR = "experiment.status.draft.update.error"; //NO I18N
	
	public static final String EXPERIMENT_UPDATE_PROJECT_VALIDATION_ERROR = "experiment.update.project.validation.error"; //NO I18N
	
	public static final String EXPERIMENT_ARCHIVED_UPDATE_VALIDATION_ERROR = "experiment.archived.update.validation.error"; //NO I18N
	
	public static final String EXPERIMENT_MINIMUM_GOAL_VALIDATION_ERROR = "experiment.minimum.goal.validation.error"; //NO I18N
	
	public static final String EXPERIMENT_MINIMUM_VARIATION_COUNT_ERROR = "experiment.minimum.variation.count.error"; //NO I18N
	
	public static final String EXPERIMENT_MINIMUM_VARIATION_GOAL_COUNT_ERROR = "experiment.minimum.variation.goal.count.error"; //NO I18N
	
	public static final String LICENSE_EXPIRE_EXPERIMENT_PUBLISH_ERROR = "license.experiment.publish.error"; //NO I18N
	
	public static final String LICENSE_EXPIRE_GOAL_PUBLISH_ERROR = "license.goal.publish.error"; //NO I18N
	
	public static final String CHECKSCRIPT_NOT_ADDED_ERROR = "snippet.not.added"; //NO I18N

	public static final String DUPLICATE_EXPERIMENT_PROJECT = "duplicate.experiment.project"; //NO I18N
	
	public static final String EXPERIMENT_EMPTY_NAME = "experiment.empty.name"; //NO I18N
	
	public static final String EXPERIMENT_NOT_EXISTS = "experiment.not.exists"; //NO I18N
	
	public static final String GOAL_NOT_EXISTS_IN_EXPERIMENT = "goal.not.exists.experiment"; //NO I18N
	
	public static final String VARIATION_CREATION_ERROR = "variation.creation.error"; //NO I18N
	
	public static final String STARTDATE_LESS_ENDDATE_ERROR = "startdate.less.enddate"; //NO I18N
	
	public static final String DATE_FORMAT = "dd/MM/yyyy HH:mm"; //No I18N
	
	public static final String PRIMARY_GOAL = "primary_goal";	// NO I18N
	
	public static final String IS_ACTIVE = "is_active";	// NO I18N
	
	public static final String AUTO_LAUNCH = "auto_launch"; //NO I18N
	
	public static final String GOAL= "goals";	// NO I18N
	
	public static final String STATISTICAL_SIGNIFICANCE= "statistical_significance";	// NO I18N
	
	public static final String EXPECTED_IMPROVEMENT = "expected_improvement"; //No I18N
	
	public static final String CONVERSION_RATE = "conversion_rate"; //No I18N
	
	public static final String DAILY_VISITORS = "daily_visitors"; //No I18N
	
	public static final String VARIATION_COUNT = "variation_count"; //No I18N
	
	public static final String GOAL_COUNT = "goal_count"; //No I18N
	
	public static final String VISITOR_COUNT = "visitor_count"; //No I18N
	
	public static final String CREATED_BY = "created_by"; //No I18N
	
	public final static List<Constants> EXPERIMENT_TABLE;
	
	public final static String DEFAULT_DAILY_VISITORS = "2500"; //NO I18N
	
	public final static String DEFAULT_STATISTICAL_SIGNIFICANCE = "95"; //NO I18N
	
	public final static String DEFAULT_CONVERSION_RATE = "6"; //NO I18N
	
	public final static String DEFAULT_EXPECTED_IMPROVEMENT = "7"; //NO I18N

	public final static String EXCLUDE_URLS = "exclude_urls"; //NO I18N
	
	public final static String INCLUDE_URLS = "include_urls"; //NO I18N
	
	public final static String IS_WINNER_DECLARED = "is_winner_declared"; //NO I18N
	
	public static final String EVENT_EXPERIMENT_TYPE = "event_experiment_type"; //No I18N

	public static final String IS_HEATMAP_ENABLED = "is_heatmap_enabled"; //No I18N
	
	public static final String IS_EXP_STATUS_CHANGED = "is_exp_status_changed"; //No I18N
    
	public static final String IS_HEATMAP_ACTIVATED = "is_heatmap_activated"; //No I18N
	
	public static final String HEATMAP_MAX_VISITORS = "heatmap_max_visitors"; //No I18N

	public static final String HEATMAP_STATUS = "heatmap_status"; //No I18N


	public static final String REDIRECT_PARAMS = "redirect_params"; //No I18N
	public static final String GLOBAL_JS = "global_js"; //No I18N
	public static final String GLOBAL_CSS = "global_css"; //No I18N
	
	public static final String WINNING_VARIATION = "winning_variation"; //No I18N
	
	public static final String MAKE_PUBLIC = "make_public"; //No I18N
	
	public static final String SHARE_URL = "share_url"; //No I18N
	
	public static final String MATCH_TYPE = "match_type"; //No I18N
	public static final String VALUE = "value"; //No I18N
	
	public static final String CURRENT_URL = "current_url"; //No I18N
	
	public static final String TOTAL_RECORDINGS = "total_recordings"; //No I18N
	
	
	
	public static enum ExperimentStatus {
		DRAFT(1),
		RUNNING(2),
		PAUSED(3),
		COMPLETED(4),
//		ARCHIVED(5),
		SCHEDULED(6);
		private Integer statusCode;
		
		public Integer getStatusCode() {
			return this.statusCode;
		}
		
		public static ExperimentStatus getStatusByNumber(Integer number) {
			for(ExperimentStatus status: ExperimentStatus.values()) {
				if(number!=null && status.getStatusCode().equals(number)) {
					return status;
				}
			}
			return null;
		}
		
		private ExperimentStatus(Integer statusCode) {
			this.statusCode = statusCode;
		}
		
	}
	

	
	
	public static enum ExperimentMode {
		QUICKTRENDS	(1,90,"QUICK TRENDS"),
		OPTIMAL(2,95,"OPTIMAL"),
		HIGHACCURACY(3,99,"HIGH ACCURACY");
		
		private Integer modeNo;
		private Integer modeValue;
		private String modeStr;
		
		public Integer getModeNo() {
			return modeNo;
		}

		public Integer getModeValue() {
			return modeValue;
		}

		public String getModeStr() {
			return modeStr;
		}

		public static ExperimentMode getModeByModeNo(Integer modeNo) {
			for(ExperimentMode mode: ExperimentMode.values()) {
				if(mode.getModeNo().equals(modeNo)) {
					return mode;
				}
			}
			return null;
		}
		
		public static ExperimentMode getModeByModeValue(Integer modeValue) {
			for(ExperimentMode mode: ExperimentMode.values()) {
				if(mode.getModeValue().equals(modeValue)) {
					return mode;
				}
			}
			return null;
		}
		
		private ExperimentMode(Integer modeNo,Integer modeValue,String modeStr) {
			this.modeNo = modeNo;
			this.modeValue = modeValue;
			this.modeStr = modeStr;
		}
		
	}
	
	public static enum ExperimentActivationMode {
		ONLOAD	(1,"ON LOAD ACTIVATION"),	// NO I18N
		MANUAL(2,"MANUAL ACTIVATION"),// NO I18N
		CONDITIONAL(3,"CONDITIONAL ACTIVATION");// NO I18N
		
		private Integer modeNo;
		private String modeStr;
		
		public Integer getModeNo() {
			return modeNo;
		}

		
		public String getModeStr() {
			return modeStr;
		}

		public static ExperimentMode getModeByModeNo(Integer modeNo) {
			for(ExperimentMode mode: ExperimentMode.values()) {
				if(mode.getModeNo().equals(modeNo)) {
					return mode;
				}
			}
			return null;
		}
		
		private ExperimentActivationMode(Integer modeNo,String modeStr) {
			this.modeNo = modeNo;
			this.modeStr = modeStr;
		}
	}
	
	public static enum ExperimentType {


		ABTEST(1, ZABAction.getMessage("experiment.abtest.resource.name")), //NO I18N
		SPLITURL(2, ZABAction.getMessage("experiment.split.resource.name")), //NO I18N
		MULTIVARIANT(3, ZABAction.getMessage("experiment.multivariant.resource.name")), //NO I18N
		HEATMAP(5, ZABAction.getMessage("experiment.heatmap.resource.name")), //NO I18N
		FUNNEL(6, ZABAction.getMessage("experiment.funnel.resource.name")), //NO I18N
		FORMANALYTICS(7,ZABAction.getMessage("experiment.form.resource.name")),//NO I18N
		SESSION_RECORDING(8,ZABAction.getMessage("experiment.session.resource.name")), //NO I18N
        ENABLED_HEATMAP(100,ZABAction.getMessage("experiment.heatmap.resource.name")); //NO I18N
		
		private Integer typeNumber;
		private String resourceName;
		
		public Integer getTypeNumber() {
			return typeNumber;
		}
		
		
		public String getResourceName() {
			return resourceName;
		}

		public void setResourceName(String duplicateError) {
			this.resourceName = duplicateError;
		}

		public static ExperimentType getExperimentTypeByNumber(Integer number) {
			for(ExperimentType status: ExperimentType.values()) {
				if(number!=null && status.getTypeNumber().equals(number)) {
					return status;
				}
			}
			return null;
		}

		private ExperimentType(Integer typeNumber  , String duplicateError) {
			this.typeNumber = typeNumber;
			this.setResourceName(duplicateError);
		}
		
	}
	
	static{
		ArrayList<Constants> list = new ArrayList<Constants>();
		list.add(new Constants(EXPERIMENT_ID,EXPERIMENT.EXPERIMENT_ID,ZABConstants.LONG,Boolean.FALSE));
		list.add(new Constants(EXPERIMENT_NAME,EXPERIMENT.EXPERIMENT_NAME,ZABConstants.STRING,Boolean.TRUE));
		list.add(new Constants(EXPERIMENT_LINKNAME,EXPERIMENT.EXPERIMENT_LINK_NAME,ZABConstants.STRING,Boolean.FALSE));
		list.add(new Constants(EXPERIMENT_KEY,EXPERIMENT.EXPERIMENT_KEY,ZABConstants.STRING,Boolean.FALSE));
		list.add(new Constants(EXPERIMENT_TYPE,EXPERIMENT.EXPERIMENT_TYPE,ZABConstants.INTEGER,Boolean.FALSE));
		list.add(new Constants(EXPERIMENT_STATUS,EXPERIMENT.EXPERIMENT_STATUS,ZABConstants.INTEGER,Boolean.TRUE));
		list.add(new Constants(ACTIVATION_MODE,EXPERIMENT.ACTIVATION_MODE,ZABConstants.INTEGER,Boolean.FALSE));		
		list.add(new Constants(ACTIVATON_CONDITION,EXPERIMENT.ACTIVATION_CONDITION,ZABConstants.STRING,Boolean.TRUE));
		list.add(new Constants(PROJECT_ID,EXPERIMENT.PROJECT_ID,ZABConstants.LONG,Boolean.FALSE));
		list.add(new Constants(IS_ACTIVE,EXPERIMENT.IS_ACTIVE,ZABConstants.BOOLEAN,Boolean.TRUE));
		list.add(new Constants(MAKE_PUBLIC,EXPERIMENT.MAKE_PUBLIC,ZABConstants.BOOLEAN,Boolean.TRUE));
		list.add(new Constants(START_DATE,EXPERIMENT.START_TIME,ZABConstants.LONG,Boolean.TRUE, Boolean.TRUE));
		list.add(new Constants(END_DATE,EXPERIMENT.END_TIME,ZABConstants.LONG,Boolean.TRUE, Boolean.TRUE));
		list.add(new Constants(CREATED_BY,EXPERIMENT.CREATED_BY,ZABConstants.LONG,Boolean.FALSE));
		list.add(new Constants(CREATED_TIME,EXPERIMENT.CREATED_TIME,ZABConstants.LONG,Boolean.FALSE));
		list.add(new Constants(MODIFIED_TIME,EXPERIMENT.MODIFIED_TIME,ZABConstants.LONG,Boolean.TRUE));
		list.add(new Constants(ACTUAL_START_TIME,EXPERIMENT.ACTUAL_START_TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.TRUE));
		list.add(new Constants(ACTUAL_END_TIME,EXPERIMENT.ACTUAL_END_TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.TRUE));
		EXPERIMENT_TABLE = (List<Constants>) Collections.unmodifiableList(list);
	}
	
	public final static List<Constants> ABSPLITEXPERIMENT_TABLE;
	
	static{
		ArrayList<Constants> absplitlist = new ArrayList<Constants>();
		absplitlist.add(new Constants(EXPERIMENT_ID,ABSPLITEXPERIMENT.EXPERIMENT_ID,ZABConstants.LONG,Boolean.FALSE));
		absplitlist.add(new Constants(EXPERIMENT_URL,ABSPLITEXPERIMENT.EXPERIMENT_URL,ZABConstants.STRING,Boolean.TRUE));
		absplitlist.add(new Constants(EXCLUDE_URLS,ABSPLITEXPERIMENT.EXCLUDE_URLS,ZABConstants.STRING,Boolean.TRUE,Boolean.TRUE));
		absplitlist.add(new Constants(INCLUDE_URLS,ABSPLITEXPERIMENT.INCLUDE_URLS,ZABConstants.STRING,Boolean.TRUE,Boolean.TRUE));
		absplitlist.add(new Constants(PERMITTED_TRAFFIC,ABSPLITEXPERIMENT.PERMITTED_TRAFFIC,ZABConstants.INTEGER,Boolean.TRUE));
		absplitlist.add(new Constants(STATISTICAL_SIGNIFICANCE,ABSPLITEXPERIMENT.SIGNIFICANCE_LEVEL,ZABConstants.INTEGER,Boolean.TRUE));
		absplitlist.add(new Constants(EXPECTED_IMPROVEMENT,ABSPLITEXPERIMENT.EXPECTED_IMPROVEMENT,ZABConstants.INTEGER,Boolean.TRUE));
		absplitlist.add(new Constants(CONVERSION_RATE,ABSPLITEXPERIMENT.CONVERSION_RATE,ZABConstants.INTEGER,Boolean.TRUE));
		absplitlist.add(new Constants(DAILY_VISITORS,ABSPLITEXPERIMENT.DAILY_VISITORS,ZABConstants.LONG,Boolean.TRUE));
		absplitlist.add(new Constants(IS_HEATMAP_ENABLED,ABSPLITEXPERIMENT.IS_HEATMAP_ENABLED,ZABConstants.BOOLEAN,Boolean.TRUE));
		absplitlist.add(new Constants(REDIRECT_PARAMS,ABSPLITEXPERIMENT.REDIRECT_PARAMS,ZABConstants.BOOLEAN,Boolean.TRUE));
		absplitlist.add(new Constants(GLOBAL_JS,ABSPLITEXPERIMENT.GLOBAL_JS,ZABConstants.STRING,Boolean.TRUE));
		absplitlist.add(new Constants(GLOBAL_CSS,ABSPLITEXPERIMENT.GLOBAL_CSS,ZABConstants.STRING,Boolean.TRUE));
		
		ABSPLITEXPERIMENT_TABLE = (List<Constants>) Collections.unmodifiableList(absplitlist);
	}
	
}
