//$Id$
package com.zoho.abtest.jedis;

import java.util.logging.Level;
import java.util.logging.Logger;

import redis.clients.jedis.Jedis;

import com.zoho.cache.cg.RedisConnectionPoolHandler;

public class Jedisfactory 
{
	private static final Logger LOGGER = Logger.getLogger(Jedisfactory.class.getName());
	
	static
	{
		try
		{
			RedisConnectionPoolHandler.initialize();
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Cannot initialize the Redis server", ex);
		}
	}
	
	public static Jedis getJedisConnection() throws Exception
	{
		Jedis jedis = null;
		try
		{
			jedis = RedisConnectionPoolHandler.getRedisConnection();
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occured: ",ex);
			throw ex;
		}
		return jedis;
	}
	
	public static void returnJedis(Jedis jedis)
	{
		if(jedis != null)
		{
			RedisConnectionPoolHandler.returnRedis(jedis);
		}
	}
}
