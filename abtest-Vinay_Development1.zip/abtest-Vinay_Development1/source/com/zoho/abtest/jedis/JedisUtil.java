//$Id$
package com.zoho.abtest.jedis;

import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import redis.clients.jedis.Jedis;

public class JedisUtil
{
	private static final Logger LOGGER = Logger.getLogger(JedisUtil.class.getName());
	
	public static void pushIntoHash(String key, String field, String value)
	{
		Jedis jedis = null;
		try
		{
			jedis = Jedisfactory.getJedisConnection();
			jedis.hsetnx(key, field, value);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occured: ",ex);
		}
		finally
		{
			Jedisfactory.returnJedis(jedis);
		}
	}
	
	public static void pushIntoHash(String key, HashMap<String, String> hs)
	{
		Jedis jedis = null;
		try
		{
			jedis = Jedisfactory.getJedisConnection();
			jedis.hmset(key, hs);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occured: ",ex);
		}
		finally
		{
			Jedisfactory.returnJedis(jedis);
		}
	}
	
	public static String getFromHash(String key, String field)
	{
		String code = null;
		Jedis jedis = null;
		try
		{
			jedis = Jedisfactory.getJedisConnection();
			code = jedis.hget(key, field);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occured: ",ex);
			code = null;
		}
		finally
		{
			Jedisfactory.returnJedis(jedis);
		}
		return code;
	}
	
}
