//$Id$
package com.zoho.abtest.report;

import java.io.Serializable;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.SerializationUtils;
import org.apache.commons.math3.distribution.NormalDistribution;
import org.json.JSONArray;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.iam.IAMUtil;
import com.adventnet.iam.User;
import com.adventnet.mfw.bean.BeanUtil;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.BROWSER_GOAL_REPORT_DAY;
import com.zoho.abtest.BROWSER_GOAL_REPORT_HOUR;
import com.zoho.abtest.BROWSER_VISIT_REPORT_DAY;
import com.zoho.abtest.BROWSER_VISIT_REPORT_HOUR;
import com.zoho.abtest.COOKIE_GOAL_REPORT_DAY;
import com.zoho.abtest.COOKIE_GOAL_REPORT_HOUR;
import com.zoho.abtest.COOKIE_VISIT_REPORT_DAY;
import com.zoho.abtest.COOKIE_VISIT_REPORT_HOUR;
import com.zoho.abtest.COUNTRY_GOAL_REPORT_DAY;
import com.zoho.abtest.COUNTRY_GOAL_REPORT_HOUR;
import com.zoho.abtest.COUNTRY_VISIT_REPORT_DAY;
import com.zoho.abtest.COUNTRY_VISIT_REPORT_HOUR;
import com.zoho.abtest.CUSTDIM_GOAL_REPORT_DAY;
import com.zoho.abtest.CUSTDIM_GOAL_REPORT_HOUR;
import com.zoho.abtest.CUSTDIM_VISIT_REPORT_DAY;
import com.zoho.abtest.CUSTDIM_VISIT_REPORT_HOUR;
import com.zoho.abtest.DAYOFWK_GOAL_REPORT_DAY;
import com.zoho.abtest.DAYOFWK_GOAL_REPORT_HOUR;
import com.zoho.abtest.DAYOFWK_VISIT_REPORT_DAY;
import com.zoho.abtest.DAYOFWK_VISIT_REPORT_HOUR;
import com.zoho.abtest.DEVICE_GOAL_REPORT_DAY;
import com.zoho.abtest.DEVICE_GOAL_REPORT_HOUR;
import com.zoho.abtest.DEVICE_VISIT_REPORT_DAY;
import com.zoho.abtest.DEVICE_VISIT_REPORT_HOUR;
import com.zoho.abtest.GOAL;
import com.zoho.abtest.GOAL_REPORT_DAY;
import com.zoho.abtest.GOAL_REPORT_HOUR;
import com.zoho.abtest.GOAL_VISITS;
import com.zoho.abtest.HOURODY_GOAL_REPORT_DAY;
import com.zoho.abtest.HOURODY_GOAL_REPORT_HOUR;
import com.zoho.abtest.HOURODY_VISIT_REPORT_DAY;
import com.zoho.abtest.HOURODY_VISIT_REPORT_HOUR;
import com.zoho.abtest.JSVAR_GOAL_REPORT_DAY;
import com.zoho.abtest.JSVAR_GOAL_REPORT_HOUR;
import com.zoho.abtest.JSVAR_VISIT_REPORT_DAY;
import com.zoho.abtest.JSVAR_VISIT_REPORT_HOUR;
import com.zoho.abtest.LANG_GOAL_REPORT_DAY;
import com.zoho.abtest.LANG_GOAL_REPORT_HOUR;
import com.zoho.abtest.LANG_VISIT_REPORT_DAY;
import com.zoho.abtest.LANG_VISIT_REPORT_HOUR;
import com.zoho.abtest.OS_GOAL_REPORT_DAY;
import com.zoho.abtest.OS_GOAL_REPORT_HOUR;
import com.zoho.abtest.OS_VISIT_REPORT_DAY;
import com.zoho.abtest.OS_VISIT_REPORT_HOUR;
import com.zoho.abtest.REFURL_GOAL_REPORT_DAY;
import com.zoho.abtest.REFURL_GOAL_REPORT_HOUR;
import com.zoho.abtest.REFURL_VISIT_REPORT_DAY;
import com.zoho.abtest.REFURL_VISIT_REPORT_HOUR;
import com.zoho.abtest.REVENUE_VISITS;
import com.zoho.abtest.TRAFSOUR_GOAL_REPORT_DAY;
import com.zoho.abtest.TRAFSOUR_GOAL_REPORT_HOUR;
import com.zoho.abtest.TRAFSOUR_VISIT_REPORT_DAY;
import com.zoho.abtest.TRAFSOUR_VISIT_REPORT_HOUR;
import com.zoho.abtest.URLPARM_GOAL_REPORT_DAY;
import com.zoho.abtest.URLPARM_GOAL_REPORT_HOUR;
import com.zoho.abtest.URLPARM_VISIT_REPORT_DAY;
import com.zoho.abtest.URLPARM_VISIT_REPORT_HOUR;
import com.zoho.abtest.VARIATION;
import com.zoho.abtest.VARIATION_VISITS;
import com.zoho.abtest.VISITOR_REPORT_DAY;
import com.zoho.abtest.VISITOR_REPORT_HOUR;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.dimension.DynamicAttributes;
import com.zoho.abtest.experiment.ABSplitExperiment;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.goal.Goal;
import com.zoho.abtest.goal.GoalConstants;
import com.zoho.abtest.goal.GoalConstants.GoalType;
import com.zoho.abtest.goal.TimeSpentGoal;
import com.zoho.abtest.misc.SampleSizeCalculator;
import com.zoho.abtest.report.CumulativeReportConstants.DecisionType;
import com.zoho.abtest.revenue.RevenueReport;
import com.zoho.abtest.utility.ZABRevenueBean;
import com.zoho.abtest.utility.ZABUserBean;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.abtest.variation.Variation;
import com.zoho.abtest.variation.VariationConstants;

public class ReportStatistics extends ZABModel implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(ReportStatistics.class.getName());

	private Long uniqueVisitorCount;
	private Long uniqueGaolCount;
	private Long variationId ; 
	private Long goalId;
	private String goalLinkNmae;
	private String variationLinkName;
	private Long time;

	private Double uniqueImprovement;
	private Double uniqueSignificance;
	private Double uniqueConfidence;
	private Double uniqueConversionRate;
	private Boolean uniqueIsSignificant;
	private String uniqueConclusion;
	private Boolean isWinner;
	private Boolean isLoser;
	private Boolean isInconclusive;
	private Integer decision;
	
	
	private Long averageTimeSpent; // This value is present inly for TimeSpent goal
	
	private RevenueReport revenue;

	private Long totalVisitorCount;
	
	/*
	
	private Long totalGaolCount;
	private Double totalImprovement;
	private Double totalSignificance;
	private Double totalConfidence;
	private Double totalConversionRate;
	private Boolean totalIsSignificant;
	private String totalConclusion;
	 */
	/*public ReportStatistics(){

	}
	public ReportStatistics(ReportStatistics report ){
		this.uniqueVisitorCount = new Long(report.getUniqueVisitorCount());
		this.uniqueGaolCount =new Long( report.getUniqueGaolCount());
		this.totalVisitorCount= new Long(report.getTotalVisitorCount());
		this.totalGaolCount = new Long(report.getTotalGaolCount());
		this.goalId = new Long(report.getGoalId());
		this.variationId = new Long(report.getVariationId());	
		this.isSignificant = new Boolean(report.getIsSignificant());

	}*/


	public Long getTime() {
		return time;
	}

	public String getGoalLinkNmae() {
		return goalLinkNmae;
	}

	public void setGoalLinkNmae(String goalLinkNmae) {
		this.goalLinkNmae = goalLinkNmae;
	}



	public void setTime(Long time) {
		this.time = time;
	}
	public Boolean getIsInconclusive() {
		return isInconclusive;
	}

	public void setIsInconclusive(Boolean isInconclusive) {
		this.isInconclusive = isInconclusive;
	}

	public Integer getDecision() {
		return decision;
	}

	public void setDecision(Integer decision) {
		this.decision = decision;
	}

	public Double getUniqueImprovement() {
		return uniqueImprovement;
	}

	public void setUniqueImprovement(Double uniqueImprovement) {
		this.uniqueImprovement = uniqueImprovement;
	}
	public Double getUniqueSignificance() {
		return uniqueSignificance;
	}
	public void setUniqueSignificance(Double uniqueSignificance) {
		this.uniqueSignificance = uniqueSignificance;
	}
	public Double getUniqueConfidence() {
		return uniqueConfidence;
	}
	public void setUniqueConfidence(Double uniqueConfidence) {
		this.uniqueConfidence = uniqueConfidence;
	}
	public Double getUniqueConversionRate() {
		return uniqueConversionRate;
	}
	public void setUniqueConversionRate(Double uniqueConversionRate) {
		this.uniqueConversionRate = uniqueConversionRate;
	}
	public Long getUniqueVisitorCount() {
		return uniqueVisitorCount;
	}
	public void setUniqueVisitorCount(Long uniqueVisitorCount) {
		this.uniqueVisitorCount = uniqueVisitorCount;
	}
	public Long getUniqueGaolCount() {
		return uniqueGaolCount;
	}
	public void setUniqueGaolCount(Long uniqueGaolCount) {
		this.uniqueGaolCount = uniqueGaolCount;
	}

	public Long getVariationId() {
		return variationId;
	}
	public void setVariationId(Long variationId) {
		this.variationId = variationId;
	}
	public Long getGoalId() {
		return goalId;
	}
	public void setGoalId(Long goalId) {
		this.goalId = goalId;
	}
	public Boolean getUniqueIsSignificant() {
		return uniqueIsSignificant;
	}
	public void setUniqueIsSignificant(Boolean uniqueIsSignificant) {
		this.uniqueIsSignificant = uniqueIsSignificant;
	}

	public String getUniqueConclusion() {
		return uniqueConclusion;
	}

	public void setUniqueConclusion(String uniqueConclusion) {
		this.uniqueConclusion = uniqueConclusion;
	}

	public String getVariationLinkName() {
		return variationLinkName;
	}

	public void setVariationLinkName(String variationLinkName) {
		this.variationLinkName = variationLinkName;
	}
	public Boolean getIsWinner() {
		return isWinner;
	}

	public void setIsWinner(Boolean isWinner) {
		this.isWinner = isWinner;
	}
	public RevenueReport getRevenue() {
		return revenue;
	}

	public void setRevenue(RevenueReport revenue) {
		this.revenue = revenue;
	}
	public Boolean getIsLoser() {
		return isLoser;
	}

	public void setIsLoser(Boolean isLoser) {
		this.isLoser = isLoser;
	}
	public Long getAverageTimeSpent() {
		return averageTimeSpent;
	}

	public void setAverageTimeSpent(Long averageTimeSpent) {
		this.averageTimeSpent = averageTimeSpent;
	}
	public Long getTotalVisitorCount() {
		return totalVisitorCount;
	}

	public void setTotalVisitorCount(Long totalVisitorCount) {
		this.totalVisitorCount = totalVisitorCount;
	}

	public static Double getStatisticalSignificance(double controlConversionRate, double variotionConversionRate,Long controlVisit,Long variationVisit)
	{

		double controlSE = getStandardError(controlVisit,controlConversionRate);
		double variationSE = getStandardError(variationVisit,variotionConversionRate);

		double zScore  = (controlConversionRate-variotionConversionRate)/(Math.sqrt(Math.pow(controlSE, 2)+Math.pow(variationSE, 2)));
		NormalDistribution nd = new NormalDistribution(0d, 1d);
		Double pValue  = nd.cumulativeProbability(zScore);
		if(controlConversionRate<variotionConversionRate){
			pValue= 1-pValue;
		}
		if(pValue.isNaN()){
			return 0d;
		}	
		return pValue;
	}



	public static Double getStatisticalSignificance(Long controlVisit,Double  controlConversion, Long variationVisit, Double variationConversion){

		double controlConversionRate = getConversionRate(controlVisit,controlConversion);
		double variotionConversionRate = getConversionRate(variationVisit,variationConversion);

		return getStatisticalSignificance(controlConversionRate, variotionConversionRate,controlVisit,variationVisit);
	}
	public static Boolean isSignificant(int statisticalSignificance,double pvalue){
		double confindenceDecimal = (double)statisticalSignificance/100;
		if(pvalue>=confindenceDecimal){
			return true;
		}
		else{
			return false;
		}
	}

	public static double calculateZScoreForConfidence(int significance){
		double conf = (double)significance/100;
		conf=1-conf;
		conf/=2;
		conf=1-conf;
		NormalDistribution nd= new NormalDistribution(0,1);

		return nd.inverseCumulativeProbability(conf);
	}
	public static double getConfidenceLevel(Long visit, Double  conversion, int statisticalSignificance){
		return getConfidenceLevelFromConversionRate(visit , getConversionRate(visit, conversion) ,statisticalSignificance);
	
	}
	public static double getConfidenceLevelFromConversionRate(Long visit, Double  conversionRate, int statisticalSignificance){
		double standardError =getStandardError(visit,conversionRate);
		return standardError*calculateZScoreForConfidence(statisticalSignificance);

	}
	public static Double getImprovement(Double controlConversionRate, Double variationConversionRate){
		if(controlConversionRate == 0.0d){
			return  null;
		}
		if(controlConversionRate.equals(variationConversionRate)){
			return 0.0d;
		}
		return (variationConversionRate-controlConversionRate)/controlConversionRate;

	}
	public static double getConversionRate(Long visits, Double conversions){

		if(conversions == 0l){
			return 0d;
		}
		if(visits == 0l){
			return 0d;
		}

		return (double)conversions/visits;
	}
	public static double getStandardError(Long visit, double conversionRate){
		/* TODO Check if conversion rate is greater than 1 , if so change code appropriately  (for revenue testing)*/
		if(visit==0){
			return 0d;
		}
		if(conversionRate  >1 ){
			double standardError  =  (conversionRate*(conversionRate-1))/visit;
			standardError= Math.sqrt(standardError);
			return standardError;
		}
		double standardError  =  (conversionRate*(1-conversionRate))/visit;
		standardError= Math.sqrt(standardError);
		return standardError;
	}




	public static String isWinner(Boolean isSignificant, Double improvement, long visitors ,long originalVisitors, Double originalConversions, Integer significance ){

		return isWinner(isSignificant,improvement,visitors,originalVisitors,originalConversions,significance,getConversionRate(originalVisitors, originalConversions));
		
	}
	public static String isWinner(Boolean isSignificant, Double improvement, long visitors ,long originalVisitors, Double originalConversions, Integer significance, Double conversionRate ){

		if(improvement == null){
			if(isSignificant && visitors>=1000 && originalVisitors >=1000){
				return CumulativeReportConstants.WINNER;
			}else{
				return formatNumber(1000l);
			}
			
			
		}
		if(improvement.equals(0.0d)){
			
			if(visitors>=10000 && originalVisitors >=10000){
				return CumulativeReportConstants.INCOCLUSIVE;
			}else{
				return formatNumber(1000l);
			}
			
		}


		if(originalVisitors==0||originalConversions==0){
			return formatNumber(1000l);
		}


		Long visitorsRequired = SampleSizeCalculator.calculateSampleSize(improvement,conversionRate,null,null,significance).getVisitorsRequired();
		
		if(isSignificant){
			if(visitors >= visitorsRequired){
				if(visitors >100 && originalVisitors >100){
					if(improvement  > 0 ){

						return CumulativeReportConstants.WINNER;	
					}else{

						return CumulativeReportConstants.LOSER;	
					}
				}else{
					return formatNumber(1000l);
				}
				
			}else{
				visitorsRequired = visitorsRequired - visitors;
				return formatNumber(visitorsRequired);
				
			}

		}else{


			if(visitors>=10000 && originalVisitors>=10000){
				return CumulativeReportConstants.INCOCLUSIVE;	
			}else{
				visitorsRequired = 10000 - visitors;
				return formatNumber(visitorsRequired);
			}

		}

	}
	public static Long approximateVisitorsRequired(Long visitorsRequired){
		Long result = 100l ;
		if(visitorsRequired <= 100){
			result = 100l;
		}else if(visitorsRequired >100 && visitorsRequired <=1000){
			result = ((visitorsRequired + 99) / 100 ) * 100;
		}else if(visitorsRequired >1000 && visitorsRequired <=100000){
			result = ((visitorsRequired + 999) / 1000 ) * 1000;
		}else{
			result = 100000l;
		}
		return result;
	}

	public static String formatNumber(Long visitorsRequired){
		visitorsRequired = approximateVisitorsRequired(visitorsRequired);
		String result = "";
		
		User IamUser=IAMUtil.getCurrentUser();
		if(IamUser!=null){
			Locale locale = ZABUtil.getLocaleFromIamUser();
			result  = NumberFormat.getNumberInstance(locale).format(visitorsRequired);

		}else{
			result  = NumberFormat.getNumberInstance().format(visitorsRequired);
		}
	
		
		String visitorsString  = "~"+result+" "+CumulativeReportConstants.UNIQUE_VISITORS_REQUIRED;
		return visitorsString;
		
	}

	
	public static ArrayList<ReportStatistics> getReportInformation(HashMap<String,String> hs) throws Exception 
	{
		ArrayList<ReportStatistics> reports = new ArrayList<ReportStatistics>();
		try{
			String experimentLinkNmae = hs.get(ExperimentConstants.EXPERIMENT_LINKNAME);
			Experiment exp  = Experiment.getExperimentByLinkname(experimentLinkNmae);
			if(exp == null){

				LOGGER.log(Level.SEVERE,"Experiment with link name "+experimentLinkNmae+" not present" );
				ReportStatistics report = new ReportStatistics();
				report.setSuccess(Boolean.FALSE);
				reports.add(report);
				return reports;

			}
			String baseLine =  hs.get(ReportConstants.BASELINE);
			Long experimentId = exp.getExperimentId();
			List<Long> variationIds = new ArrayList<Long>();
			String variations =  hs.get(ReportConstants.VARIATIONS);
			if(variations==null){
				variationIds = ABSplitExperiment.getVariationsOfExperiment(experimentId);
			}else{
				
				JSONArray varLinkNames = new JSONArray(variations);
				varLinkNames.put(baseLine);
				String[] varLinkNamesArray = new String[varLinkNames.length()];
				for(int i=0;i<varLinkNames.length();i++){
					varLinkNamesArray[i] = (String) varLinkNames.get(i);
				}
				variationIds = Variation.getVariationIdsFromLinkNames(varLinkNamesArray);
			}
			
			List<Long> goalIds = ABSplitExperiment.getGoalsOfExperiment(experimentId);
			String segmentType= hs.get(ReportConstants.SEGMENT_TYPE);
			String reportType = hs.get(ReportConstants.REPORT_TYPE);
			String dynamicAttrLinkName = hs.get(ReportConstants.DYNAMIC_ATTRIBUTE_LINK_NAME);
			String startTime = hs.get(ReportConstants.START_DATE);
			String  endTime = hs.get(ReportConstants.END_DATE);
			String multisegmentCriteria = hs.get(ReportConstants.MULTISEGMENT_CRITERIA);
			Long startTimeInMillis = null;
			if(startTime!=null&&!startTime.isEmpty()){
				startTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(startTime, "yyyy-MM-dd");		// NO I18N
			}

			Long endTimeInMillis = null;
			if(endTime!=null&&!endTime.isEmpty()){
				endTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(endTime, "yyyy-MM-dd");		// NO I18N
			}

			Integer[] valueArray = null;
			
			String values = hs.get(ReportConstants.VALUES);

			if(values != null)
			{
				JSONArray array  =new JSONArray(values);
				valueArray = new Integer[array.length()];

				for(int i=0;i<array.length();i++){
					valueArray[i] = Integer.parseInt(array.getString(i));
				}
			}

			reports = goalWiseReport(reportType,segmentType,experimentId,valueArray,startTimeInMillis,endTimeInMillis,dynamicAttrLinkName,multisegmentCriteria,variationIds,goalIds,baseLine);


		}catch(Exception ex ){
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);

		}
		return reports;

	}




	public static ArrayList<ReportStatistics> goalWiseReport(String reportType, String segmentType, Long expId, Integer[] segmentValueCodes, Long startTime, Long endTime,String dynamicAttrLinkName,String multisegmentCriteria,List<Long> variationIds,List<Long> goalIds, String baseLine) throws Exception{

		ArrayList<ReportStatistics> resultReport = new ArrayList<ReportStatistics>();
		ArrayList<HashMap<String, String>> visitorMeta = null;
		ArrayList<HashMap<String, String>> goalMeta = null;
		Long dynamicAttrId = null;
		try
		{
			/*
			boolean isLatestInforequired = false;
			boolean isCombinedTableInforequired = false;

			long currentTime = ZABUtil.getCurrentTimeInMilliSeconds();
			long currentDateInLong = ZABUtil.getDateInLongFromTime(currentTime);


			if(endTime.equals(currentDateInLong))
			{
				isLatestInforequired =true;
				isCombinedTableInforequired = true;
				if(startTime.equals(endTime))
				{
					isCombinedTableInforequired = false;
				}
			}
			 */
			HashMap<Long , RevenueReport> revenueMeta  = null; 
			Long revenueGoalId = ABSplitExperiment.getRevenueGoalOfExperiment(expId);
			Long timeSpentGoalId = ABSplitExperiment.getTimeSpentGoalOfExperiment(expId);
			
			
			if(reportType.equals(ReportConstants.MULTISEGMENT))
			{
				
				ZABUserBean userBean = (ZABUserBean)BeanUtil.lookup("ZABUserBean", ZABUtil.getCurrentUserDbSpace());
				HashMap<String, Object> multisegmentCriteriaHs = userBean.generateMultisegmentCriteria(multisegmentCriteria);
				//visitorMeta = userBean.getMultiSegmentVisitorReportDetails(expId, startTime, endTime, isLatestInforequired, isCombinedTableInforequired, multisegmentCriteriaHs,variationIds);
				//goalMeta = userBean.getMultiSegmentGoalReportDetails(expId, startTime, endTime, isLatestInforequired, isCombinedTableInforequired, multisegmentCriteriaHs,variationIds,goalIds);

				visitorMeta = userBean.getMultiSegmentVisitorReportDetails(expId, startTime, endTime, multisegmentCriteriaHs,variationIds);
				LOGGER.log(Level.INFO,"Multisegement Visitor Meta Obtained");
				goalMeta = userBean.getMultiSegmentGoalReportDetails(expId, startTime, endTime, multisegmentCriteriaHs,variationIds,goalIds);
				LOGGER.log(Level.INFO,"Multisegement Goal Meta Obtained");
				
				if(revenueGoalId!=null){
					revenueMeta = RevenueReport.multiSegmentCriteriaReport( expId,  multisegmentCriteria , startTime,  endTime,  variationIds ) ;
					
				}
				if(timeSpentGoalId!=null){
					
					ZABRevenueBean revBean = (ZABRevenueBean)BeanUtil.lookup("ZABRevenueBean", ZABUtil.getCurrentUserDbSpace());
					HashMap<Long, Long>  totalVisitorsHs = revBean.getMultiSegmentTotalVisitor(expId, startTime, endTime,multisegmentCriteriaHs, variationIds);
					HashMap<Long, Long> timeSpentDetails = revBean.getMultiSegmentTimeSpentGoalReportDetails(expId, startTime, endTime, multisegmentCriteriaHs, variationIds);
					
					visitorMeta  = TimeSpentGoal.combineTotalVisitorsWithVisitormeta(visitorMeta,totalVisitorsHs);
					visitorMeta = TimeSpentGoal.combineTimeSpentMetaWithVisitormeta(visitorMeta,timeSpentDetails);
				
					
				}
				
			}
			else
			{
				HashMap<String, String> hs = getTableNames(reportType,segmentType);

				if(reportType.equals(ReportConstants.SEGMENT))
				{
					if(segmentType.equals(ReportConstants.URLPARAMETER) || segmentType.equals(ReportConstants.COOKIE) || segmentType.equals(ReportConstants.JSVARIABLE) || segmentType.equals(ReportConstants.CUSTOMDIMENSION))
					{
						dynamicAttrId = DynamicAttributes.getDynamicAttributesIdByLinkName(dynamicAttrLinkName);
					}
				}
				ZABUserBean userBean = (ZABUserBean)BeanUtil.lookup("ZABUserBean", ZABUtil.getCurrentUserDbSpace());
				//visitorMeta = userBean.getVisitorReportDetails(isLatestInforequired,isCombinedTableInforequired, reportType, expId, segmentValueCodes, startTime, endTime, hs, dynamicAttrId,variationIds);
				//goalMeta = userBean.getGoalReportDetails(isLatestInforequired,isCombinedTableInforequired, reportType, expId, segmentValueCodes, startTime, endTime, hs, dynamicAttrId,variationIds,goalIds);
				visitorMeta = userBean.getVisitorReportDetails( reportType, expId, segmentValueCodes, startTime, endTime, hs, dynamicAttrId,variationIds);
				LOGGER.log(Level.INFO,"Segement Visitor Meta Obtained");
				goalMeta = userBean.getGoalReportDetails( reportType, expId, segmentValueCodes, startTime, endTime, hs, dynamicAttrId,variationIds,goalIds);
				LOGGER.log(Level.INFO,"Segement Goal Meta Obtained");


				if(revenueGoalId != null){
					ZABRevenueBean revenueBean = (ZABRevenueBean)BeanUtil.lookup("ZABRevenueBean", ZABUtil.getCurrentUserDbSpace());

					if(reportType.equals(ReportConstants.SUMMARY)){
						revenueMeta = revenueBean.getRevenueSummaryDetails(expId, startTime, endTime,variationIds);

					}else if (reportType.equals(ReportConstants.SEGMENT)){

						JSONArray segmentjsonArray = new JSONArray(Arrays.asList(segmentValueCodes));
						String segmentCriteria = RevenueReport.converSegmentToMultiSegmentCriteira(segmentType, segmentjsonArray, dynamicAttrLinkName);
						revenueMeta = RevenueReport.multiSegmentCriteriaReport( expId,  segmentCriteria , startTime,  endTime,  variationIds) ;

					}

				}
				if(timeSpentGoalId!=null){
					
					ZABRevenueBean revBean = (ZABRevenueBean)BeanUtil.lookup("ZABRevenueBean", ZABUtil.getCurrentUserDbSpace());
					HashMap<Long, Long>  totalVisitorsHs = null;
					HashMap<Long, Long> timeSpentDetails = null;
					
					if(reportType.equals(ReportConstants.SUMMARY)){
						totalVisitorsHs = revBean.getSummaryTotalVisitor(expId, startTime, endTime, variationIds);
						timeSpentDetails = revBean.getTimeSpentSummaryDetails(expId, startTime, endTime, variationIds);
						
					}else if (reportType.equals(ReportConstants.SEGMENT)){

						JSONArray segmentjsonArray = new JSONArray(Arrays.asList(segmentValueCodes));
						String segmentCriteria = RevenueReport.converSegmentToMultiSegmentCriteira(segmentType, segmentjsonArray, dynamicAttrLinkName);
						
						HashMap<String, Object> multisegmentCriteriaHs = userBean.generateMultisegmentCriteria(segmentCriteria);
						totalVisitorsHs = revBean.getMultiSegmentTotalVisitor(expId, startTime, endTime,multisegmentCriteriaHs, variationIds);
						timeSpentDetails = revBean.getMultiSegmentTimeSpentGoalReportDetails(expId, startTime, endTime, multisegmentCriteriaHs, variationIds);
						
					}
					
					visitorMeta  = TimeSpentGoal.combineTotalVisitorsWithVisitormeta(visitorMeta,totalVisitorsHs);
					visitorMeta = TimeSpentGoal.combineTimeSpentMetaWithVisitormeta(visitorMeta,timeSpentDetails);
					
				}
			}
			resultReport = goalWiseReport(visitorMeta,goalMeta,expId,baseLine,revenueMeta,revenueGoalId,variationIds);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);

		}

		return resultReport;

	}


	public static ArrayList<ReportStatistics> goalWiseReport(ArrayList<HashMap<String, String>> visitorMeta ,ArrayList<HashMap<String, String>> goalMeta , Long expId ,String baseLine, HashMap<Long , RevenueReport> revenueMeta, Long revenueGoalId,List<Long> variationIds) throws Exception   {
		ArrayList<ReportStatistics> resultReport = new ArrayList<ReportStatistics>();
		try{

			HashMap<Long,ReportStatistics> variationStatsHs = new HashMap<Long, ReportStatistics>();
			
			Criteria varCri = new Criteria(new Column(VARIATION.TABLE,VARIATION.VARIATION_ID), variationIds.toArray(new Long[variationIds.size()]), QueryConstants.IN);
			ArrayList<Variation> variations  = Variation.getVariationsWithCriteria(varCri);
			
			ArrayList<Goal> goals = new ArrayList<Goal>();
			goals = Goal.getGoalByExperimentByExperimentId(expId);
		
			

			// VISITOR ID -> REPORT STATISTICS OBJECT MAPPING
			for(int i=0;i<visitorMeta.size();i++){
				HashMap<String, String> hsRow  = visitorMeta.get(i);
				ReportStatistics report = new ReportStatistics();
				report.setVariationId(Long.parseLong(hsRow.get(VariationConstants.VARIATION_ID)));
				report.setUniqueVisitorCount(Long.parseLong(hsRow.get(ReportArchieveDimensionConstants.UNIQUE_COUNT)));
				if(hsRow.containsKey(ReportArchieveDimensionConstants.TOTAL_COUNT) && hsRow.containsKey(ReportRawDataConstants.TIME_SPENT)){
					Long totaltime =Long.parseLong(hsRow.get(ReportRawDataConstants.TIME_SPENT));
					Long totalVisitors =  Long.parseLong(hsRow.get(ReportArchieveDimensionConstants.TOTAL_COUNT));
					if(totalVisitors >0){
						Long avgTime =  totaltime/totalVisitors;
						report.setAverageTimeSpent(avgTime);
					}
					
				}
				
				variationStatsHs.put(report.getVariationId(), report);
			}
			LOGGER.log(Level.INFO,"Visitor Meta Parsed Succesfully");

			String revenueGoalLinkName =  null;
			
			HashMap<Long, ArrayList<ReportStatistics>> goalStatsHs = new HashMap<Long, ArrayList<ReportStatistics>> ();
			LOGGER.log(Level.INFO,"Visitor*Goal Object Creation Start");
			for(int i=0;i<goals.size();i++){
				
				Goal g= goals.get(i);
				if(g.getGoalTypeTag().equals(GoalType.REVENUE_GOAL.getGoalTypeId())){		// PREVENTING REVENUE GOAL OBJECT CREATION
					revenueGoalLinkName=g.getGoalLinkname();
					
					continue;
				}
				
				Long goalId =g.getGoalId();
				String goalLinkName  =g.getGoalLinkname();
				ArrayList<ReportStatistics> tempList= new ArrayList<ReportStatistics>();
				for(int j=0;j<variations.size();j++){
					Long variationId = variations.get(j).getVariationId();
					String variationLinkname  = variations.get(j).getVariationLinkname();
					ReportStatistics report =null;
					if(!variationStatsHs.containsKey(variationId)){
						report = new ReportStatistics();
						report.setVariationId(variationId);
						report.setUniqueVisitorCount(0l);

					}else{
						report = SerializationUtils.clone(variationStatsHs.get(variationId));

					}
					report.setVariationLinkName(variationLinkname);
					report.setGoalId(goalId);
					report.setGoalLinkNmae(goalLinkName);
					report.setIsWinner(Boolean.FALSE);
					report.setIsLoser(Boolean.FALSE);
					report.setIsInconclusive(Boolean.FALSE);
					// setting defaults to 0
					report.setUniqueGaolCount(0l);
					tempList.add(report);
				}

				goalStatsHs.put(goalId, tempList);

			}

			LOGGER.log(Level.INFO,"Visitor*Goal Object Creation End");
			for(int i=0;i<goalMeta.size();i++){
				HashMap<String, String> hsRow  = goalMeta.get(i);
				Long variationId  = Long.parseLong(hsRow.get(VariationConstants.VARIATION_ID));
				Long goalId = Long.parseLong(hsRow.get(GoalConstants.GOAL_ID));
				
				Long uniqueGoalCount  =  Long.parseLong(hsRow.get(ReportArchieveDimensionConstants.UNIQUE_COUNT));
				if(revenueGoalId!=null && revenueGoalId.equals(goalId)){
					
					try{
						revenueMeta.get(variationId).setUniquePayingVisitors(uniqueGoalCount);
					}catch(Exception e){
						LOGGER.log(Level.SEVERE,"Extra Revenue goal Info From ES");	// NO I18N
					}
					continue;
					
				}
				try{
					ArrayList<ReportStatistics> statsList = goalStatsHs.get(goalId);
					for(int j=0;j<statsList.size();j++){
						ReportStatistics  report  =statsList.get(j);
						if(report.getVariationId().equals(variationId)){

							report.setUniqueGaolCount(uniqueGoalCount);
							break;
						}
					}

				}catch(Exception e){
					LOGGER.log(Level.SEVERE,"Extra goal Info From ES");	// NO I18N
				}
				
			}

			LOGGER.log(Level.INFO,"Goal Meta Parse End");
			
			
			Long originalVariationId  =getBaselineVariationId(baseLine,expId);
			Integer expSignifcance  =ABSplitExperiment.getABSplitExperiment(expId).getStatisticalSignificance();			
			resultReport.addAll(reportCalc( goalStatsHs, originalVariationId, expSignifcance));
			if(revenueGoalId!=null){

				revenueMeta = RevenueReport.combineVisitorMetaAndRevenueMeta(visitorMeta,revenueMeta,variations);
				revenueMeta = RevenueReport.revenueCalculation(revenueMeta,expId,originalVariationId);

				for(int a=0;a<variations.size();a++){
					Long varId = variations.get(a).getVariationId();
					String varLinkName = variations.get(a).getVariationLinkname();

					RevenueReport revenue = revenueMeta.get(varId);
					ReportStatistics report  = new ReportStatistics();
					report.setVariationId(varId);
					report.setVariationLinkName(varLinkName);
					report.setGoalId(revenueGoalId);
					report.setGoalLinkNmae(revenueGoalLinkName);
					report.setRevenue(revenue);
					report.setSuccess(Boolean.TRUE);
					resultReport.add(report);
				}
			}

		}catch(Exception e){
			LOGGER.log(Level.SEVERE, e.getMessage(),e);

		}
		return resultReport;
	}


	public static ArrayList<ReportStatistics> reportCalc (HashMap<Long, ArrayList<ReportStatistics>> goalStatsHs , Long originalVariationId,Integer expSignifcance){

		ArrayList<ReportStatistics>  resultReport = new ArrayList<ReportStatistics> ();
		
		HashMap<String, ReportStatistics> unwindedReports = new HashMap<String,  ReportStatistics>();
		HashMap<Long , Integer> goalDecisionHs = new HashMap<Long , Integer>();
		
		Set<Long> goalskeySet = goalStatsHs.keySet();
		Iterator<Long> keyItr = goalskeySet.iterator();
		while(keyItr.hasNext()){


			// COMPUTE STATISTICS FOR EACH GOAL 


			Long goalId   =  keyItr.next();
			Long originalVisitoryUniqueCount = 0l;
			Long originalGoalUniqueCount = 0l;
			Boolean isWinnerPresentForGoal = Boolean.FALSE;
			Boolean isInsignificantPresentForGoal = Boolean.FALSE;
			
			ArrayList<ReportStatistics> reports = goalStatsHs.get(goalId);
			Integer variationCount =  reports.size();
	
			for(int i=0;i<reports.size();i++){
				ReportStatistics rep = reports.get(i);
				Long varId  = rep.getVariationId();
				String key = goalId+":"+varId;
				if(varId.equals(originalVariationId)){
					originalGoalUniqueCount = rep.getUniqueGaolCount();
					originalVisitoryUniqueCount = rep.getUniqueVisitorCount();
					reports.remove(i);
					ReportStatistics originalReport = new ReportStatistics();
					originalReport = rep;
					if(originalVisitoryUniqueCount > 0){
						originalReport.setUniqueConversionRate(getConversionRate(originalVisitoryUniqueCount, (double)originalGoalUniqueCount));
						originalReport.setUniqueConfidence(getConfidenceLevel(originalVisitoryUniqueCount, (double)originalGoalUniqueCount, expSignifcance));
				
					}
					originalReport.setSuccess(Boolean.TRUE);
					unwindedReports.put(key, originalReport);				
					break;
				}
			}


			ArrayList<String> goalUniqueWinners= new ArrayList<String>();
			ArrayList<String> goalUniqueLosers= new ArrayList<String>();
			ArrayList<String> goalInsignificant= new ArrayList<String>();
			Double uniqueWinningImprovement =  null;
			Double uniqueLosingImprovement = null;
			for(int i=0;i<reports.size();i++){
				ReportStatistics variationReport=  reports.get(i);
				Long variationId = variationReport.getVariationId();
				String key = goalId+":"+variationId;
				Long variationUniqueGoal  = variationReport.getUniqueGaolCount();
				Long variationUniqueVisitor = variationReport.getUniqueVisitorCount();
			
				if(variationUniqueVisitor > 0){
					variationReport.setUniqueConfidence(getConfidenceLevel(variationUniqueVisitor, (double)variationUniqueGoal, expSignifcance));
					variationReport.setUniqueConversionRate(getConversionRate(variationUniqueVisitor, (double)variationUniqueGoal));

					if(originalVisitoryUniqueCount > 0){
						Double varImprovement = getImprovement(getConversionRate(originalVisitoryUniqueCount,(double) originalGoalUniqueCount), variationReport.getUniqueConversionRate());
						variationReport.setUniqueImprovement(varImprovement);
						variationReport.setUniqueSignificance(getStatisticalSignificance(originalVisitoryUniqueCount,(double) originalGoalUniqueCount, variationUniqueVisitor,(double) variationUniqueGoal));
						variationReport.setUniqueIsSignificant(isSignificant(expSignifcance, variationReport.getUniqueSignificance()));
						String uniqueconclusion =isWinner(variationReport.getUniqueIsSignificant(), variationReport.getUniqueImprovement(), variationReport.getUniqueVisitorCount(),originalVisitoryUniqueCount,(double)originalGoalUniqueCount,expSignifcance);
						variationReport.setUniqueConclusion(uniqueconclusion);
						variationReport.setSuccess(Boolean.TRUE);

						if(uniqueconclusion.equals(CumulativeReportConstants.WINNER)){
							if(uniqueWinningImprovement == null){
								uniqueWinningImprovement = varImprovement;
							}else if (uniqueWinningImprovement<varImprovement){
								uniqueWinningImprovement=varImprovement;
							}
							goalUniqueWinners.add(key);
						
						}else if (uniqueconclusion.equals(CumulativeReportConstants.LOSER)){

							if(uniqueLosingImprovement == null){
								uniqueLosingImprovement = varImprovement;
							}else if (uniqueLosingImprovement>varImprovement){
								uniqueLosingImprovement= varImprovement;
							}
							goalUniqueLosers.add(key);

						}else if (uniqueconclusion.equals(CumulativeReportConstants.INCOCLUSIVE)){
							variationReport.setIsInconclusive(Boolean.TRUE);
							goalInsignificant.add(key);
						}
					}
				}
				variationReport.setSuccess(Boolean.TRUE);
				unwindedReports.put(key,variationReport);
				

			}
			
			for(int i=0;i<goalUniqueWinners.size();i++){
				isWinnerPresentForGoal = Boolean.TRUE;
				ReportStatistics repo =  unwindedReports.get(goalUniqueWinners.get(i));
				
				if(repo.getUniqueImprovement() == null  || repo.getUniqueImprovement().equals(uniqueWinningImprovement)){
					repo.setIsWinner(Boolean.TRUE);
				}else{
					repo.setUniqueConclusion(" ");
				}
			}
			if(goalUniqueLosers.size() ==  (variationCount-1)){
				Double minSignificance  = null;
				
				for(int i=0;i<goalUniqueLosers.size();i++){
					ReportStatistics repo = unwindedReports.get(goalUniqueLosers.get(i));
					Double signi =  repo.getUniqueSignificance();
					repo.setUniqueConclusion(" ");	
					if(minSignificance == null){
						minSignificance = signi;
					}else if(signi < minSignificance){
						minSignificance = signi;
					}
				}
				isWinnerPresentForGoal = Boolean.TRUE;
				String originalKey = goalId+":"+originalVariationId;
				unwindedReports.get(originalKey).setIsWinner(Boolean.TRUE);
				unwindedReports.get(originalKey).setUniqueConclusion(CumulativeReportConstants.WINNER);
				unwindedReports.get(originalKey).setUniqueSignificance(minSignificance);
			
			}
			else{
				for(int i=0;i<goalUniqueLosers.size();i++){
					ReportStatistics repo = unwindedReports.get(goalUniqueLosers.get(i));
					if(goalUniqueWinners.size()>0){
						repo.setUniqueConclusion(" ");
					}else{
						if(repo.getUniqueImprovement().equals(uniqueLosingImprovement)){
							repo.setIsLoser(Boolean.TRUE);

						}else{
							repo.setUniqueConclusion(" ");
						}
					}
				}
			}
			
			if(goalInsignificant.size() == variationCount-1){
				isInsignificantPresentForGoal = Boolean.TRUE;
			}
			
			Integer decision  = DecisionType.LEADING_VARIANT.getDecisionTypeId();
			
			if(isWinnerPresentForGoal){
				decision  = DecisionType.WINNER.getDecisionTypeId();
			
			}else if(isInsignificantPresentForGoal){
				decision  = DecisionType.INCONCLUSIVE.getDecisionTypeId();
				
			}
			goalDecisionHs.put(goalId, decision);

		}
		
		Set<String> reportKeyset = unwindedReports.keySet();
		Iterator<String> itr = reportKeyset.iterator();
		while(itr.hasNext()){
			String key = itr.next();
			ReportStatistics rep =unwindedReports.get(key);
			Long goalid = rep.getGoalId();
			Integer decision = goalDecisionHs.get(goalid);
			rep.setDecision(decision);
			resultReport.add(rep);
		}
		
		return resultReport;

	}






	public static HashMap<String, String> getTableNames(String reportType, String segmentType)
	{
		HashMap<String, String> hs = null;
		String visitortableName = null;
		String visitorIdColumnName = null;
		String visitorsArrTableName = null;
		String visitorHourTableName = null;
		String visitorHourIdColumnName = null;
		String visitorsHourArrTableName = null;

		String goaltableName = null; 
		String goalIdColumnName = null;
		String goalArrTableName = null;
		String goalHourTableName = null;
		String goalHourIdColumnName = null;
		String goalHourArrTableName = null;

		String rawTableSegmentColumnName = null;

		String dbspaceId = ZABUtil.getCurrentUserDbSpace();
		try
		{
			hs = new HashMap<String, String>();
			if(reportType.equals(ReportConstants.SUMMARY))
			{
				visitortableName = VISITOR_REPORT_DAY.TABLE;
				visitorIdColumnName = VISITOR_REPORT_DAY.VISITOR_REPORT_DAY_ID;
				visitorsArrTableName = "VISITOR_REPORT_DAY_VISITORS_"+dbspaceId; //No I18N
				visitorHourTableName = VISITOR_REPORT_HOUR.TABLE;
				visitorHourIdColumnName = VISITOR_REPORT_HOUR.VISITOR_REPORT_HOUR_ID;
				visitorsHourArrTableName = "VISITOR_REPORT_HOUR_VISITORS_"+dbspaceId; //No I18N
				goaltableName = GOAL_REPORT_DAY.TABLE;
				goalIdColumnName = GOAL_REPORT_DAY.GOAL_REPORT_DAY_ID;
				goalArrTableName = "GOAL_REPORT_DAY_VISITORS_"+dbspaceId; //No I18N
				goalHourTableName = GOAL_REPORT_HOUR.TABLE;
				goalHourIdColumnName = GOAL_REPORT_HOUR.GOAL_REPORT_HOUR_ID;
				goalHourArrTableName = "GOAL_REPORT_HOUR_VISITORS_"+dbspaceId; //No I18N
			}
			else if(reportType.equals(ReportConstants.SEGMENT))
			{
				switch(segmentType)
				{
				case ReportConstants.BROWSER:
					visitortableName = BROWSER_VISIT_REPORT_DAY.TABLE;
					visitorIdColumnName = BROWSER_VISIT_REPORT_DAY.BROWSER_VISIT_REPORT_DAY_ID;
					visitorsArrTableName = "BROWSER_VISIT_DAY_VISITORS_"+dbspaceId; //No I18N
					visitorHourTableName = BROWSER_VISIT_REPORT_HOUR.TABLE;
					visitorHourIdColumnName = BROWSER_VISIT_REPORT_HOUR.BROWSER_VISIT_REPORT_HOUR_ID;
					visitorsHourArrTableName = "BROWSER_VISIT_HOUR_VISITORS_"+dbspaceId; //No I18N
					rawTableSegmentColumnName = "BROWSER_CODE"; //No I18N
					goaltableName = BROWSER_GOAL_REPORT_DAY.TABLE;
					goalIdColumnName = BROWSER_GOAL_REPORT_DAY.BROWSER_GOAL_REPORT_DAY_ID;
					goalArrTableName = "BROWSER_GOAL_DAY_VISITORS_"+dbspaceId; //No I18N
					goalHourTableName = BROWSER_GOAL_REPORT_HOUR.TABLE;
					goalHourIdColumnName = BROWSER_GOAL_REPORT_HOUR.BROWSER_GOAL_REPORT_HOUR_ID;
					goalHourArrTableName = "BROWSER_GOAL_HOUR_VISITORS_"+dbspaceId; //No I18N
					break;
				case ReportConstants.DEVICE:
					visitortableName = DEVICE_VISIT_REPORT_DAY.TABLE;
					visitorIdColumnName = DEVICE_VISIT_REPORT_DAY.DEVICE_VISIT_REPORT_DAY_ID;
					visitorsArrTableName = "DEVICE_VISIT_DAY_VISITORS_"+dbspaceId; //No I18N
					visitorHourTableName = DEVICE_VISIT_REPORT_HOUR.TABLE;
					visitorHourIdColumnName = DEVICE_VISIT_REPORT_HOUR.DEVICE_VISIT_REPORT_HOUR_ID;
					visitorsHourArrTableName = "DEVICE_VISIT_HOUR_VISITORS_"+dbspaceId; //No I18N
					rawTableSegmentColumnName = "DEVICE_CODE"; //No I18N
					goaltableName = DEVICE_GOAL_REPORT_DAY.TABLE;
					goalIdColumnName = DEVICE_GOAL_REPORT_DAY.DEVICE_GOAL_REPORT_DAY_ID;
					goalArrTableName = "DEVICE_GOAL_DAY_VISITORS_"+dbspaceId; //No I18N
					goalHourTableName = DEVICE_GOAL_REPORT_HOUR.TABLE;
					goalHourIdColumnName = DEVICE_GOAL_REPORT_HOUR.DEVICE_GOAL_REPORT_HOUR_ID;
					goalHourArrTableName = "DEVICE_GOAL_HOUR_VISITORS_"+dbspaceId; //No I18N
					break;
				case ReportConstants.COUNTRY:
					visitortableName = COUNTRY_VISIT_REPORT_DAY.TABLE;
					visitorIdColumnName = COUNTRY_VISIT_REPORT_DAY.COUNTRY_VISIT_REPORT_DAY_ID;
					visitorsArrTableName = "COUNTRY_VISIT_DAY_VISITORS_"+dbspaceId; //No I18N
					visitorHourTableName = COUNTRY_VISIT_REPORT_HOUR.TABLE;
					visitorHourIdColumnName = COUNTRY_VISIT_REPORT_HOUR.COUNTRY_VISIT_REPORT_HOUR_ID;
					visitorsHourArrTableName = "COUNTRY_VISIT_HOUR_VISITORS_"+dbspaceId; //No I18N
					rawTableSegmentColumnName = "COUNTRY_CODE"; //No I18N
					goaltableName = COUNTRY_GOAL_REPORT_DAY.TABLE;
					goalIdColumnName = COUNTRY_GOAL_REPORT_DAY.COUNTRY_GOAL_REPORT_DAY_ID;
					goalArrTableName = "COUNTRY_GOAL_DAY_VISITORS_"+dbspaceId; //No I18N
					goalHourTableName = COUNTRY_GOAL_REPORT_HOUR.TABLE;
					goalHourIdColumnName = COUNTRY_GOAL_REPORT_HOUR.COUNTRY_GOAL_REPORT_HOUR_ID;
					goalHourArrTableName = "COUNTRY_GOAL_HOUR_VISITORS_"+dbspaceId; //No I18N
					break;
				case ReportConstants.LANGUAGE:
					visitortableName = LANG_VISIT_REPORT_DAY.TABLE;
					visitorIdColumnName = LANG_VISIT_REPORT_DAY.LANG_VISIT_REPORT_DAY_ID;
					visitorsArrTableName = "LANG_VISIT_DAY_VISITORS_"+dbspaceId; //No I18N
					visitorHourTableName = LANG_VISIT_REPORT_HOUR.TABLE;
					visitorHourIdColumnName = LANG_VISIT_REPORT_HOUR.LANG_VISIT_REPORT_HOUR_ID;
					visitorsHourArrTableName = "LANG_VISIT_HOUR_VISITORS_"+dbspaceId; //No I18N
					rawTableSegmentColumnName = "LANGUAGE_CODE"; //No I18N
					goaltableName = LANG_GOAL_REPORT_DAY.TABLE;
					goalIdColumnName = LANG_GOAL_REPORT_DAY.LANG_GOAL_REPORT_DAY_ID;
					goalArrTableName = "LANG_GOAL_DAY_VISITORS_"+dbspaceId; //No I18N
					goalHourTableName = LANG_GOAL_REPORT_HOUR.TABLE;
					goalHourIdColumnName = LANG_GOAL_REPORT_HOUR.LANG_GOAL_REPORT_HOUR_ID;
					goalHourArrTableName = "LANG_GOAL_HOUR_VISITORS_"+dbspaceId; //No I18N
					break;
				case ReportConstants.OS:
					visitortableName = OS_VISIT_REPORT_DAY.TABLE;
					visitorIdColumnName = OS_VISIT_REPORT_DAY.OS_VISIT_REPORT_DAY_ID;
					visitorsArrTableName = "OS_VISIT_DAY_VISITORS_"+dbspaceId; //No I18N
					visitorHourTableName = OS_VISIT_REPORT_HOUR.TABLE;
					visitorHourIdColumnName = OS_VISIT_REPORT_HOUR.OS_VISIT_REPORT_HOUR_ID;
					visitorsHourArrTableName = "OS_VISIT_HOUR_VISITORS_"+dbspaceId; //No I18N
					rawTableSegmentColumnName = "OS_CODE"; //No I18N
					goaltableName = OS_GOAL_REPORT_DAY.TABLE;
					goalIdColumnName = OS_GOAL_REPORT_DAY.OS_GOAL_REPORT_DAY_ID;
					goalArrTableName = "OS_GOAL_DAY_VISITORS_"+dbspaceId; //No I18N
					goalHourTableName = OS_GOAL_REPORT_HOUR.TABLE;
					goalHourIdColumnName = OS_GOAL_REPORT_HOUR.OS_GOAL_REPORT_HOUR_ID;
					goalHourArrTableName = "OS_GOAL_HOUR_VISITORS_"+dbspaceId; //No I18N
					break;
				case ReportConstants.TRAFFICSOURCE:
					visitortableName = TRAFSOUR_VISIT_REPORT_DAY.TABLE;
					visitorIdColumnName = TRAFSOUR_VISIT_REPORT_DAY.TRAFSOUR_VISIT_REPORT_DAY_ID;
					visitorsArrTableName = "TRAFSOUR_VISIT_DAY_VISITORS_"+dbspaceId; //No I18N
					visitorHourTableName = TRAFSOUR_VISIT_REPORT_HOUR.TABLE;
					visitorHourIdColumnName = TRAFSOUR_VISIT_REPORT_HOUR.TRAFSOUR_VISIT_REPORT_HOUR_ID;
					visitorsHourArrTableName = "TRAFSOUR_VISIT_HOUR_VISITORS_"+dbspaceId; //No I18N
					rawTableSegmentColumnName = "TRAFFICSOURCE_CODE"; //No I18N
					goaltableName = TRAFSOUR_GOAL_REPORT_DAY.TABLE;
					goalIdColumnName = TRAFSOUR_GOAL_REPORT_DAY.TRAFSOUR_GOAL_REPORT_DAY_ID;
					goalArrTableName = "TRAFSOUR_GOAL_DAY_VISITORS_"+dbspaceId; //No I18N
					goalHourTableName = TRAFSOUR_GOAL_REPORT_HOUR.TABLE;
					goalHourIdColumnName = TRAFSOUR_GOAL_REPORT_HOUR.TRAFSOUR_GOAL_REPORT_HOUR_ID;
					goalHourArrTableName = "TRAFSOUR_GOAL_HOUR_VISITORS_"+dbspaceId; //No I18N
					break;
				case ReportConstants.REFFERERURL:
					visitortableName = REFURL_VISIT_REPORT_DAY.TABLE;
					visitorIdColumnName = REFURL_VISIT_REPORT_DAY.REFURL_VISIT_REPORT_DAY_ID;
					visitorsArrTableName = "REFUR_VISIT_DAY_VISITORS_"+dbspaceId; //No I18N
					visitorHourTableName = REFURL_VISIT_REPORT_HOUR.TABLE;
					visitorHourIdColumnName = REFURL_VISIT_REPORT_HOUR.REFURL_VISIT_REPORT_HOUR_ID;
					visitorsHourArrTableName = "REFURL_VISIT_HOUR_VISITORS_"+dbspaceId; //No I18N
					rawTableSegmentColumnName = "REFFERERURL_CODE"; //No I18N
					goaltableName = REFURL_GOAL_REPORT_DAY.TABLE;
					goalIdColumnName = REFURL_GOAL_REPORT_DAY.REFURL_GOAL_REPORT_DAY_ID;
					goalArrTableName = "REFURL_GOAL_DAY_VISITORS_"+dbspaceId; //No I18N
					goalHourTableName = REFURL_GOAL_REPORT_HOUR.TABLE;
					goalHourIdColumnName = REFURL_GOAL_REPORT_HOUR.REFURL_GOAL_REPORT_HOUR_ID;
					goalHourArrTableName = "REFURL_GOAL_HOUR_VISITORS_"+dbspaceId; //No I18N
					break;
				case ReportConstants.DAYOFWEEK:
					visitortableName = DAYOFWK_VISIT_REPORT_DAY.TABLE;
					visitorIdColumnName = DAYOFWK_VISIT_REPORT_DAY.DAYOFWK_VISIT_REPORT_DAY_ID;
					visitorsArrTableName = "DAYOFWK_VISIT_DAY_VISITORS_"+dbspaceId; //No I18N
					visitorHourTableName = DAYOFWK_VISIT_REPORT_HOUR.TABLE;
					visitorHourIdColumnName = DAYOFWK_VISIT_REPORT_HOUR.DAYOFWK_VISIT_REPORT_HOUR_ID;
					visitorsHourArrTableName = "DAYOFWK_VISIT_HOUR_VISITORS_"+dbspaceId; //No I18N
					rawTableSegmentColumnName = "DAYOFWEEK_CODE"; //No I18N
					goaltableName = DAYOFWK_GOAL_REPORT_DAY.TABLE;
					goalIdColumnName = DAYOFWK_GOAL_REPORT_DAY.DAYOFWK_GOAL_REPORT_DAY_ID;
					goalArrTableName = "DAYOFWK_GOAL_DAY_VISITORS_"+dbspaceId; //No I18N
					goalHourTableName = DAYOFWK_GOAL_REPORT_HOUR.TABLE;
					goalHourIdColumnName = DAYOFWK_GOAL_REPORT_HOUR.DAYOFWK_GOAL_REPORT_HOUR_ID;
					goalHourArrTableName = "DAYOFWK_GOAL_HOUR_VISITORS_"+dbspaceId; //No I18N
					break;
				case ReportConstants.HOUROFDAY:
					visitortableName = HOURODY_VISIT_REPORT_DAY.TABLE;
					visitorIdColumnName = HOURODY_VISIT_REPORT_DAY.HOURODY_VISIT_REPORT_DAY_ID;
					visitorsArrTableName = "HOURODY_VISIT_DAY_VISITORS_"+dbspaceId; //No I18N
					visitorHourTableName = HOURODY_VISIT_REPORT_HOUR.TABLE;
					visitorHourIdColumnName = HOURODY_VISIT_REPORT_HOUR.HOURODY_VISIT_REPORT_HOUR_ID;
					visitorsHourArrTableName = "HOURODY_VISIT_HOUR_VISITORS_"+dbspaceId; //No I18N
					rawTableSegmentColumnName = "HOUROFDAY_CODE"; //No I18N
					goaltableName = HOURODY_GOAL_REPORT_DAY.TABLE;
					goalIdColumnName = HOURODY_GOAL_REPORT_DAY.HOURODY_GOAL_REPORT_DAY_ID;
					goalArrTableName = "HOURODY_GOAL_DAY_VISITORS_"+dbspaceId; //No I18N
					goalHourTableName = HOURODY_GOAL_REPORT_HOUR.TABLE;
					goalHourIdColumnName = HOURODY_GOAL_REPORT_HOUR.HOURODY_GOAL_REPORT_HOUR_ID;
					goalHourArrTableName = "HOURODY_GOAL_HOUR_VISITORS_"+dbspaceId; //No I18N
					break;
				case ReportConstants.COOKIE:
					visitortableName = COOKIE_VISIT_REPORT_DAY.TABLE;
					visitorIdColumnName = COOKIE_VISIT_REPORT_DAY.COOKIE_VISIT_REPORT_DAY_ID;
					visitorsArrTableName = "COOKIE_VISIT_DAY_VISITORS_"+dbspaceId; //No I18N
					visitorHourTableName = COOKIE_VISIT_REPORT_HOUR.TABLE;
					visitorHourIdColumnName = COOKIE_VISIT_REPORT_HOUR.COOKIE_VISIT_REPORT_HOUR_ID;
					visitorsHourArrTableName = "COOKIE_VISIT_HOUR_VISITORS_"+dbspaceId; //No I18N
					rawTableSegmentColumnName = "COOKIE_JSON"; //No I18N
					goaltableName = COOKIE_GOAL_REPORT_DAY.TABLE;
					goalIdColumnName = COOKIE_GOAL_REPORT_DAY.COOKIE_GOAL_REPORT_DAY_ID;
					goalArrTableName = "COOKIE_GOAL_DAY_VISITORS_"+dbspaceId; //No I18N
					goalHourTableName = COOKIE_GOAL_REPORT_HOUR.TABLE;
					goalHourIdColumnName = COOKIE_GOAL_REPORT_HOUR.COOKIE_GOAL_REPORT_HOUR_ID;
					goalHourArrTableName = "COOKIE_GOAL_HOUR_VISITORS_"+dbspaceId; //No I18N
					break;
				case ReportConstants.URLPARAMETER:
					visitortableName = URLPARM_VISIT_REPORT_DAY.TABLE;
					visitorIdColumnName = URLPARM_VISIT_REPORT_DAY.URLPARM_VISIT_REPORT_DAY_ID;
					visitorsArrTableName = "URLPARM_VISIT_DAY_VISITORS_"+dbspaceId; //No I18N
					visitorHourTableName = URLPARM_VISIT_REPORT_HOUR.TABLE;
					visitorHourIdColumnName = URLPARM_VISIT_REPORT_HOUR.URLPARM_VISIT_REPORT_HOUR_ID;
					visitorsHourArrTableName = "URLPARM_VISIT_HOUR_VISITORS_"+dbspaceId; //No I18N
					rawTableSegmentColumnName = "URLPARAM_JSON"; //No I18N
					goaltableName = URLPARM_GOAL_REPORT_DAY.TABLE;
					goalIdColumnName = URLPARM_GOAL_REPORT_DAY.URLPARM_GOAL_REPORT_DAY_ID;
					goalArrTableName = "URLPARM_GOAL_DAY_VISITORS_"+dbspaceId; //No I18N
					goalHourTableName = URLPARM_GOAL_REPORT_HOUR.TABLE;
					goalHourIdColumnName = URLPARM_GOAL_REPORT_HOUR.URLPARM_GOAL_REPORT_HOUR_ID;
					goalHourArrTableName = "URLPARM_GOAL_HOUR_VISITORS_"+dbspaceId; //No I18N
					break;
				case ReportConstants.JSVARIABLE:
					visitortableName = JSVAR_VISIT_REPORT_DAY.TABLE;
					visitorIdColumnName = JSVAR_VISIT_REPORT_DAY.JSVAR_VISIT_REPORT_DAY_ID;
					visitorsArrTableName = "JSVAR_VISIT_DAY_VISITORS_"+dbspaceId; //No I18N
					visitorHourTableName = JSVAR_VISIT_REPORT_HOUR.TABLE;
					visitorHourIdColumnName = JSVAR_VISIT_REPORT_HOUR.JSVAR_VISIT_REPORT_HOUR_ID;
					visitorsHourArrTableName = "JSVAR_VISIT_HOUR_VISITORS_"+dbspaceId; //No I18N
					rawTableSegmentColumnName = "JS_VARIABLE_JSON"; //No I18N
					goaltableName = JSVAR_GOAL_REPORT_DAY.TABLE;
					goalIdColumnName = JSVAR_GOAL_REPORT_DAY.JSVAR_GOAL_REPORT_DAY_ID;
					goalArrTableName = "JSVAR_GOAL_DAY_VISITORS_"+dbspaceId; //No I18N
					goalHourTableName = JSVAR_GOAL_REPORT_HOUR.TABLE;
					goalHourIdColumnName = JSVAR_GOAL_REPORT_HOUR.JSVAR_GOAL_REPORT_HOUR_ID;
					goalHourArrTableName = "JSVAR_GOAL_HOUR_VISITORS_"+dbspaceId; //No I18N
					break;
				case ReportConstants.CUSTOMDIMENSION:
					visitortableName = CUSTDIM_VISIT_REPORT_DAY.TABLE;
					visitorIdColumnName = CUSTDIM_VISIT_REPORT_DAY.CUSTDIM_VISIT_REPORT_DAY_ID;
					visitorsArrTableName = "CUSTDIM_VISIT_DAY_VISITORS_"+dbspaceId; //No I18N
					visitorHourTableName = CUSTDIM_VISIT_REPORT_HOUR.TABLE;
					visitorHourIdColumnName = CUSTDIM_VISIT_REPORT_HOUR.CUSTDIM_VISIT_REPORT_HOUR_ID;
					visitorsHourArrTableName = "CUSTDIM_VISIT_HOUR_VISITORS_"+dbspaceId; //No I18N
					rawTableSegmentColumnName = "CUSTOM_DIMENSION_JSON"; //No I18N
					goaltableName = CUSTDIM_GOAL_REPORT_DAY.TABLE;
					goalIdColumnName = CUSTDIM_GOAL_REPORT_DAY.CUSTDIM_GOAL_REPORT_DAY_ID;
					goalArrTableName = "CUSTDIM_GOAL_DAY_VISITORS_"+dbspaceId; //No I18N
					goalHourTableName = CUSTDIM_GOAL_REPORT_HOUR.TABLE;
					goalHourIdColumnName = CUSTDIM_GOAL_REPORT_HOUR.CUSTDIM_GOAL_REPORT_HOUR_ID;
					goalHourArrTableName = "CUSTDIM_GOAL_HOUR_VISITORS_"+dbspaceId; //No I18N
					break;
				}
			}

			hs.put(ReportConstants.VISITORTABLENAME, visitortableName);
			hs.put(ReportConstants.VISITORIDCOLUMNNAME, visitorIdColumnName);
			hs.put(ReportConstants.VISITORARRTABLENAME, visitorsArrTableName);
			hs.put(ReportConstants.VISITORHOURTABLENAME, visitorHourTableName);
			hs.put(ReportConstants.VISITORHOURIDCOLUMNNAME, visitorHourIdColumnName);
			hs.put(ReportConstants.VISITORHOURARRTABLENAME, visitorsHourArrTableName);
			hs.put(ReportConstants.GOALTABLENAME, goaltableName);
			hs.put(ReportConstants.GOALIDCOLUMNNAME, goalIdColumnName);
			hs.put(ReportConstants.GOALARRTABLENAME, goalArrTableName);
			hs.put(ReportConstants.GOALHOURTABLENAME, goalHourTableName);
			hs.put(ReportConstants.GOALHOURIDCOLUMNNAME, goalHourIdColumnName);
			hs.put(ReportConstants.GOALHOURARRTABLENAME, goalHourArrTableName);
			hs.put(ReportConstants.RAWTABLESEGMENTCOLUMNNAME, rawTableSegmentColumnName);

		}
		catch(Exception ex)
		{
			hs = new HashMap<String, String>();
		}
		return hs;
	}

	public static Long getBaselineVariationId(String baseLine, Long expId){
		Long originalVariationId  =Variation.getOriginalVariationId(expId); 
		try{

			if(baseLine  != null){
				Variation  baseVar  = Variation.getVariationByLinkname(baseLine).get(0);
				if(baseVar.getSuccess().equals(Boolean.FALSE)){
					throw new Exception();
				}
				originalVariationId =  baseVar.getVariationId();
			}


		}catch(Exception e ){

			LOGGER.log(Level.SEVERE, "Requested baseline variation was not available. Defaulting to original variation",e);// NO I18N

		}
		return originalVariationId;

	}

	public static ArrayList<ReportStatistics> overviewReport(String expLinkName){

		ArrayList<ReportStatistics> resultReport = new ArrayList<ReportStatistics>();
		try{

			Long experimentId = Experiment.getExperimentId(expLinkName);
			if(experimentId==null){
				return resultReport ;
			}
			Criteria c1= new Criteria(new Column(VARIATION_VISITS.TABLE,VARIATION_VISITS.EXPERIMENT_ID),experimentId, QueryConstants.EQUAL);
			
			Criteria c2= new Criteria(new Column(GOAL_VISITS.TABLE,GOAL_VISITS.EXPERIMENT_ID),experimentId, QueryConstants.EQUAL);
			Criteria c3 = new Criteria(new Column(GOAL.TABLE,GOAL.GOAL_TYPE_FLAG), GoalType.REVENUE_GOAL.getGoalTypeId(), QueryConstants.NOT_EQUAL);
			Join revExcludeJoin  = new Join(GOAL_VISITS.TABLE,GOAL.TABLE, new String[]{GOAL_VISITS.GOAL_ID}, new String[]{GOAL.GOAL_ID},Join.INNER_JOIN);

			DataObject varVisitsdobj = ZABModel.getRow(VARIATION_VISITS.TABLE, c1);

			String revenueGoalLinkName = null;
			Long revenueGaolId = ABSplitExperiment.getRevenueGoalOfExperiment(experimentId);
			
			HashMap<Long,ReportStatistics> variationStatsHs = new HashMap<Long, ReportStatistics>();
			ArrayList<Variation> variations  = new ArrayList<Variation>();
			ArrayList<Goal> goals = new ArrayList<Goal>();
			variations =  Variation.getVariationsOfExperiment(experimentId);
			goals = Goal.getGoalByExperimentByExperimentId(experimentId);


			Iterator<?> varVisitsItr = varVisitsdobj.getRows(VARIATION_VISITS.TABLE);
			while(varVisitsItr.hasNext()){
				Row r  = (Row)varVisitsItr.next();
				ReportStatistics report = new ReportStatistics();
				report.setVariationId((Long)r.get(VARIATION_VISITS.VARIATION_ID));
				report.setUniqueVisitorCount((Long)r.get(VARIATION_VISITS.UNIQUE_VISITOR_COUNT));
				variationStatsHs.put(report.getVariationId(), report);

			}


			HashMap<Long, ArrayList<ReportStatistics>> goalStatsHs = new HashMap<Long, ArrayList<ReportStatistics>> ();
			for(int i=0;i<goals.size();i++){

				Goal g= goals.get(i);
				if(g.getGoalTypeTag().equals(GoalType.REVENUE_GOAL.getGoalTypeId())){		// PREVENTING REVENUE GOAL OBJECT CREATION
					revenueGoalLinkName=g.getGoalLinkname();
					revenueGaolId = g.getGoalId();
					continue;
				}

				Long goalId = goals.get(i).getGoalId();
				String goalLinkName  = goals.get(i).getGoalLinkname();

				ArrayList<ReportStatistics> tempList= new ArrayList<ReportStatistics>();
				for(int j=0;j<variations.size();j++){
					Long variationId = variations.get(j).getVariationId();
					String variationLinkname  = variations.get(j).getVariationLinkname();
					ReportStatistics report =null;
					if(!variationStatsHs.containsKey(variationId)){
						report = new ReportStatistics();
						report.setVariationId(variationId);
						report.setUniqueVisitorCount(0l);

					}else{
						report = SerializationUtils.clone(variationStatsHs.get(variationId));

					}
					report.setVariationLinkName(variationLinkname);
					report.setGoalId(goalId);
					report.setGoalLinkNmae(goalLinkName);
					report.setIsWinner(Boolean.FALSE);
					report.setIsLoser(Boolean.FALSE);
					report.setIsInconclusive(Boolean.FALSE);
					report.setUniqueGaolCount(0l);
					tempList.add(report);
				}

				goalStatsHs.put(goalId, tempList);
			}

			DataObject goalVisitsdobj = ZABModel.getRow(GOAL_VISITS.TABLE, c2.and(c3),revExcludeJoin);

	
			Iterator<?> goalVisitsItr = goalVisitsdobj.getRows(GOAL_VISITS.TABLE);
			while(goalVisitsItr.hasNext()){
				Row r  = (Row)goalVisitsItr.next();
				Long variationId  = (Long)r.get(GOAL_VISITS.VARIATION_ID);
				Long goalId = (Long)r.get(GOAL_VISITS.GOAL_ID);
				Long uniqueGoalCount  =  (Long)r.get(GOAL_VISITS.UNIQUE_GOAL_ACHIEVED_COUNT);
				
				ArrayList<ReportStatistics> statsList = goalStatsHs.get(goalId);
				for(int j=0;j<statsList.size();j++){
					ReportStatistics  report  =statsList.get(j);
					if(report.getVariationId().equals(variationId)){
						report.setUniqueGaolCount(uniqueGoalCount);
						break;
					}
				}
			}

			Long originalVariationId  =Variation.getOriginalVariationId(experimentId); 
			Integer expSignifcance  =ABSplitExperiment.getABSplitExperiment(experimentId).getStatisticalSignificance();			
			resultReport.addAll(reportCalc(goalStatsHs, originalVariationId, expSignifcance));



			if(revenueGaolId!=null){
				HashMap<Long, RevenueReport> revenueMeta = new HashMap<Long, RevenueReport>();
				for(int i=0;i<variations.size();i++){
					RevenueReport report  = new RevenueReport();
					Long varid = variations.get(i).getVariationId();
					Long visitors  = 0l;   
					if(variationStatsHs.containsKey(varid)){
						visitors = variationStatsHs.get(varid).getUniqueVisitorCount();
					}
					report.setVisitors(visitors);
					report.setRevenue(0d);
					report.setUniquePayingVisitors(0l);
					report.setTotalPurchases(0l);
					revenueMeta.put(varid, report);
				}
				
				Criteria revCriteria  = new Criteria(new Column(GOAL_VISITS.TABLE, GOAL_VISITS.GOAL_ID), revenueGaolId,QueryConstants.EQUAL);
				Join revJoin = new Join(GOAL_VISITS.TABLE, REVENUE_VISITS.TABLE, new String []{GOAL_VISITS.GOAL_VISITS_ID}, new String []{REVENUE_VISITS.REVENUE_VISITS_ID}, Join.INNER_JOIN);
				
				DataObject revenueDobj = ZABModel.getRow(GOAL_VISITS.TABLE, revCriteria, revJoin);
				Iterator<?> revenueItr = revenueDobj.getRows(GOAL_VISITS.TABLE);
				while(revenueItr.hasNext()){
					Row r  = (Row)revenueItr.next();
					Long variationId =  (Long)r.get(GOAL_VISITS.VARIATION_ID);
					Long purchasingisitors = (Long)r.get(GOAL_VISITS.UNIQUE_GOAL_ACHIEVED_COUNT);
					Long purchases = (Long)r.get(GOAL_VISITS.TOTAL_GOAL_ACHIEVED_COUNT);
					Long mappingId =  (Long)r.get(GOAL_VISITS.GOAL_VISITS_ID);

					Criteria mappingCri = new Criteria(new Column(REVENUE_VISITS.TABLE, REVENUE_VISITS.REVENUE_VISITS_ID), mappingId, QueryConstants.EQUAL);
					Row revenueRow = revenueDobj.getRow(REVENUE_VISITS.TABLE, mappingCri);
					
					Double revenue= ((Long) revenueRow.get(REVENUE_VISITS.REVENUE)).doubleValue();
					revenue/=100;
					RevenueReport report = revenueMeta.get(variationId);
					report.setUniquePayingVisitors(purchasingisitors);
					report.setTotalPurchases(purchases);
					report.setRevenue(revenue);

				}

				revenueMeta = RevenueReport.revenueCalculation(revenueMeta,experimentId,originalVariationId);
				for(int a=0;a<variations.size();a++){
					Long varId = variations.get(a).getVariationId();
					String varLinkName = variations.get(a).getVariationLinkname();

					RevenueReport revenue = revenueMeta.get(varId);
					ReportStatistics report  = new ReportStatistics();
					report.setVariationId(varId);
					report.setVariationLinkName(varLinkName);
					report.setGoalId(revenueGaolId);
					report.setGoalLinkNmae(revenueGoalLinkName);
					report.setRevenue(revenue);
					report.setSuccess(Boolean.TRUE);
					resultReport.add(report);
				}

			}

		}catch(Exception e){
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}

		return resultReport;
	}

	


}
