//$Id$
package com.zoho.abtest.report;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.histogram.DateHistogramAggregationBuilder;
import org.elasticsearch.search.aggregations.bucket.histogram.DateHistogramInterval;
import org.elasticsearch.search.aggregations.bucket.histogram.InternalDateHistogram;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.min.InternalMin;
import org.elasticsearch.search.aggregations.metrics.min.MinAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.sum.InternalSum;
import org.elasticsearch.search.aggregations.metrics.sum.SumAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.valuecount.InternalValueCount;
import org.elasticsearch.search.aggregations.metrics.valuecount.ValueCountAggregationBuilder;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.json.JSONArray;

import com.adventnet.iam.IAMUtil;
import com.zoho.abtest.elastic.ElasticSearchStatistics;
import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.experiment.ABSplitExperiment;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentStatus;
import com.zoho.abtest.goal.Goal;
import com.zoho.abtest.revenue.RevenueChartReport;
import com.zoho.abtest.revenue.RevenueConstants;
import com.zoho.abtest.user.ZABUser;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.abtest.variation.VariationConstants;

public class ElasticsearchChartReport
{

	private static final Logger LOGGER = Logger.getLogger(ElasticsearchChartReport.class.getName());
	
	/* Data Point chart statistics method */
	public static ArrayList<ChartReport> getDatapointReportInformation(HashMap<String,String> hs) throws Exception
	{
		ArrayList<ChartReport> reports = new ArrayList<ChartReport>();
		try{
			String experimentLinkNmae = hs.get(ExperimentConstants.EXPERIMENT_LINKNAME);
			Experiment exp  = Experiment.getExperimentByLinkname(experimentLinkNmae);
			if(exp == null){
				ChartReport report = new ChartReport();
				report.setSuccess(Boolean.FALSE);
				reports.add(report);
				return reports;
			}
			Long experimentId = exp.getExperimentId();
			Long goalId = null;
			String goalLinkName = hs.get(ReportConstants.GOAL_LINK_NAME);
			if(StringUtils.isNotEmpty(goalLinkName))
			{
				goalId = Goal.getGoalIdForGoal(goalLinkName);
			}
			//TODO - check if segment type matches with column name 
			String segmentType= hs.get(ReportConstants.SEGMENT_TYPE);
			
			String reportType = hs.get(ReportConstants.REPORT_TYPE);
			String dynamicAttrLinkName = hs.get(ReportConstants.DYNAMIC_ATTRIBUTE_LINK_NAME);
			String startTime = hs.get(ReportConstants.START_DATE);
			String  endTime = hs.get(ReportConstants.END_DATE);
			String multisegmentCriteria = hs.get(ReportConstants.MULTISEGMENT_CRITERIA);
			Long startTimeInMillis = null;
			if(startTime!=null&&!startTime.isEmpty()){
				 startTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(startTime, "yyyy-MM-dd");		// NO I18N
			}
			
			//TODO end time needs to be changed due to query range
			Long endTimeInMillis = null;
			if(endTime!=null&&!endTime.isEmpty()){
				endTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(endTime, "yyyy-MM-dd");		// NO I18N
			}
			
			String[] valueArray = null;
			String baseLine = hs.get(ReportConstants.BASELINE);
			String values = hs.get(ReportConstants.VALUES);
			
			if(values != null)
			{
				JSONArray array  = new JSONArray(values);
				valueArray = new String[array.length()];
				
				for(int i=0;i<array.length();i++){
					valueArray[i] = array.getString(i);
				}
			}
			
			reports = dataPointGoalWiseReport(reportType,segmentType,experimentId,valueArray,startTimeInMillis,endTimeInMillis,dynamicAttrLinkName,multisegmentCriteria,baseLine,goalId);
			
			
		}catch(Exception ex ){
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		return reports;
	
	}
	
	public static ArrayList<ChartReport> dataPointGoalWiseReport(String reportType, String segmentType, Long expId, String[] segmentValueCodes, Long startTime, Long endTime,String dynamicAttrLinkName,String multisegmentCriteria, String baseLine, Long goalId) throws Exception
	{
		
		ArrayList<ChartReport> resultReport = new ArrayList<ChartReport>();
		
		HashMap<Long, HashMap<Long, HashMap<String, Long>>> visitorMeta = null;
		HashMap<Long, HashMap<Long, HashMap<Long, HashMap<String, Long>>>> goalMeta = null;
		HashMap<String, HashMap<String, String>> revenueMeta = new HashMap<String, HashMap<String, String>>();
		HashMap<String, HashMap<String, String>> timeSpentMeta = new HashMap<String, HashMap<String, String>>();
		Long revenueGoalId = ABSplitExperiment.getRevenueGoalOfExperiment(expId);
		Long timeSpentGoalId = ABSplitExperiment.getTimeSpentGoalOfExperiment(expId);
		
		//TODO timepoints timezone
		ArrayList<Long> timePoints = new ArrayList<Long>();
		boolean isHourbased = false;
		try
		{
			long currentTime = ZABUtil.getCurrentTimeInMilliSeconds();
			//long currentDateInLong = ZABUtil.getDateInLongFromTime(currentTime);
			
			Experiment experiment = Experiment.getExperimentById(expId);
			
			Long expActualStartTime = experiment.getActualStartTime();
			if(expActualStartTime != null && startTime < expActualStartTime)
			{
				startTime = expActualStartTime;
			}
			
			long hourEndTime = ZABUtil.getNthDayDateInLong(endTime, 1);
			
			Integer expStatus = experiment.getExperimentStatus();
			Long expActualEndTime = experiment.getActualEndTime();
			if(ExperimentStatus.PAUSED.getStatusCode().equals(expStatus) && hourEndTime > expActualEndTime)
			{
				endTime = expActualEndTime;
				hourEndTime = ZABUtil.getNthUserHourInLong(endTime, 1);
			}
			
			//long currentDateInterval = ZABUtil.getInterval(startTime, currentDateInLong, TimeUnit.DAYS);
			long reportDateInterval = ZABUtil.getInterval(startTime, endTime, TimeUnit.DAYS);
			//int hourTableDuration = Configuration.getInteger("max.hourreporttable.duration"); //No I18N

			//check the data should be fetched as per hour or day
			//If 2 or less days fetch based on hours
			if(reportDateInterval < 23)
			{
				isHourbased = true;
			}
			
			LOGGER.log(Level.INFO, "CHART DATA POINT - Generate possible data points - START");
			//generate complete possible time points
			if(isHourbased)
			{
				int hourIndex = 1;
				long hourStartTime = startTime;
				hourStartTime = ZABUtil.getNthUserHourInLong(startTime, 0);
				long time = hourStartTime;
				timePoints.add(time);
				while(time != hourEndTime)
				{
					time = ZABUtil.getNthUserHourInLong(hourStartTime, hourIndex);
					if(time>currentTime || time >= hourEndTime)
					{
						break;
					}
					timePoints.add(time);
					hourIndex++;
				}
			}
			else
			{
				int dayIndex = 1;
				long time = startTime;
				time = ZABUtil.getNthDayDateInLong(startTime, 0);
				timePoints.add(time);
				while(time < endTime)
				{
					time = ZABUtil.getNthDayDateInLong(startTime, dayIndex);
					timePoints.add(time);
					dayIndex++;
				}
			}
			
			HashMap<Long, Long> destTimePointHs = new HashMap<Long, Long>();
			ArrayList<Long> desttimePoints = timePoints;
			
			if(isHourbased && reportDateInterval > 1)
			{
				desttimePoints = new ArrayList<Long>();
				int size = timePoints.size();
				int i = 0;
				long timePointConversionLength = reportDateInterval+1;
				while(i<size)
				{
					int j=i;
					long destTimePoint = timePoints.get(i);
					desttimePoints.add(destTimePoint);
					while(j < (i+timePointConversionLength) && j<size)
					{
						long sourceTimePoint = timePoints.get(j);
						destTimePointHs.put(sourceTimePoint, destTimePoint);
						j++;
					}
					i=j;
				}
			}
			
			LOGGER.log(Level.INFO, "CHART DATA POINT - Generate possible data points - END");
			//Cover the time range of the end date in milliseconds
			endTime = hourEndTime-1;
			
			String portalName =null;
			try{
				 portalName = IAMUtil.getCurrentServiceOrg().getDomains().get(0).getDomain();
			}catch(Exception e){
				portalName = ZABUtil.getPortaldomain();
				if(portalName == null){
					return null;
				}
			}
			String indexName = ElasticSearchUtil.getIndexByPortal(portalName);
			
			LOGGER.log(Level.INFO, "CHART DATA POINT - Get visitor report - START");
			visitorMeta = getDatapointVisitorReportInformation(indexName,portalName,reportType, segmentType, expId, startTime, endTime, dynamicAttrLinkName, segmentValueCodes,multisegmentCriteria,isHourbased,timePoints);
            LOGGER.log(Level.INFO, "CHART DATA POINT - Get visitor report - END");
            LOGGER.log(Level.INFO, "CHART DATA POINT - Get Goal report - START");
			goalMeta = getDatapointGoalReportInformation(indexName,portalName,reportType, segmentType, expId, startTime, endTime, dynamicAttrLinkName, segmentValueCodes,multisegmentCriteria,isHourbased,timePoints,goalId);
            LOGGER.log(Level.INFO, "CHART DATA POINT - Get Goal report - END");
            
            LOGGER.log(Level.INFO, "CHART DATA POINT - Convert Visitor and Goal to Destination time points - START");
			if(isHourbased && reportDateInterval > 1)
			{
				visitorMeta = ChartReport.convertVisitorHourEntriesToDestTimePoints(visitorMeta, destTimePointHs);
				goalMeta = ChartReport.convertGoalHourEntriesToDestTimePoints(goalMeta, destTimePointHs);
			}
			LOGGER.log(Level.INFO, "CHART DATA POINT - Convert  Visitor and Goal  to Destination time points - END");
			
            LOGGER.log(Level.INFO, "CHART DATA POINT - Calculate visitor cumulative values - START");
			visitorMeta = ChartReport.calculateCumulativeCountForVisitors(visitorMeta, desttimePoints);
            LOGGER.log(Level.INFO, "CHART DATA POINT - Calculate visitor cumulative values - END");
            
            LOGGER.log(Level.INFO, "CHART DATA POINT - Calculate goal cumulative values - START");
			goalMeta = ChartReport.calculateCumulativeCountForGoal(goalMeta, desttimePoints);
			LOGGER.log(Level.INFO, "CHART DATA POINT - Calculate goal cumulative values - END");
            
			boolean fetchRevenue = true;
			boolean fetchTimeSpent = true;
			if(goalId != null && !goalId.equals(revenueGoalId))
			{
				fetchRevenue = false;
			}
			if(goalId != null && !goalId.equals(timeSpentGoalId))
			{
				fetchTimeSpent = false;
			}
			
            if(fetchRevenue && revenueGoalId!=null){
            	
				revenueMeta = getDatapointRevenueGoalReportInformation(indexName, portalName, reportType, segmentType, expId, startTime, endTime, dynamicAttrLinkName, segmentValueCodes, multisegmentCriteria, isHourbased, desttimePoints, revenueGoalId);
				//TODO Have to calculate cumulative values if needed in future 
			}
            if(fetchTimeSpent && timeSpentGoalId!=null){
				timeSpentMeta = getDatapointTimeSpentGoalReportInformation(indexName, portalName, reportType, segmentType, expId, startTime, endTime, dynamicAttrLinkName, segmentValueCodes, multisegmentCriteria, isHourbased, desttimePoints, timeSpentGoalId);
			}


            LOGGER.log(Level.INFO, "CHART DATA POINT - Chart calculations - START");
			resultReport = ChartReport.chartCalculations(visitorMeta, goalMeta, expId, desttimePoints, baseLine,revenueMeta,revenueGoalId,goalId,timeSpentMeta,timeSpentGoalId,endTime);
            LOGGER.log(Level.INFO, "CHART DATA POINT - Chart calculations - END");
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		
		return resultReport;
	
	}
	
	public static HashMap<Long, HashMap<Long, HashMap<String, Long>>> getDatapointVisitorReportInformation(String index,String portal,String reportType, String segmentType, Long expId, Long startTime, Long endTime, String dynamicAttrLinkName, String[] values, String multisegmentCriteria, boolean isHourbased, ArrayList<Long> timePoints)
	{
		//ArrayList<HashMap<String, String>> visitorReportDetails = new ArrayList<HashMap<String, String>>();
		HashMap<Long, HashMap<Long, HashMap<String, Long>>> visitCountDetails = null;
		QueryBuilder query =  null;
		AggregationBuilder aggregation = null;
		int size = 0 ;
		try
		{
			LOGGER.log(Level.INFO, "CHART DATA POINT - visitor report query formation - START");
			if(reportType.equals(ReportConstants.SUMMARY))
			{
				query = ElasticSearchStatistics.generateSourceQueryJson(portal,expId,startTime,endTime,false,null,false,null,null);
			}
			else if(reportType.equals(ReportConstants.SEGMENT))
			{
				query = ElasticSearchStatistics.generateSourceSegmentQueryJson(portal,expId, startTime, endTime, segmentType, dynamicAttrLinkName, values,false,null,null);
			}
			else if(reportType.equals(ReportConstants.MULTISEGMENT))
			{
				query = ElasticSearchStatistics.generateSourceMultiSegmentQueryJson(portal,expId, startTime, endTime, multisegmentCriteria,false,null,null,null);
			}
			
			aggregation  =   generateDatapointVistorAggregateJson(isHourbased);
			LOGGER.log(Level.INFO, "CHART DATA POINT - visitor report query formation - END");
			
			LOGGER.log(Level.INFO, "CHART DATA POINT - visitor report fetch from ES - START");
			SearchResponse response = ElasticSearchUtil.getData(index, ElasticSearchConstants.VISITOR_RAW_TYPE, size, query, aggregation);
			LOGGER.log(Level.INFO, "CHART DATA POINT - visitor report fetch from ES - END");
			
			//LOGGER.log(Level.INFO, "Search response" + response.toString());
			
			LOGGER.log(Level.INFO, "CHART DATA POINT - visitor report process into reponse - START");
			visitCountDetails = readDatapointVisitResponseData(response,isHourbased);
			LOGGER.log(Level.INFO, "CHART DATA POINT - visitor report process into reponse - END");
			
			/*
			//Populate the cumulative count data for chart
			for(Map.Entry<Long, HashMap<Long, Integer>> variationEntry:visitCountDetails.entrySet())
			{
				Long variationId = variationEntry.getKey();
				HashMap<Long, Integer> timeCountDetails = variationEntry.getValue();
				int cumulativeCount = 0;
				for(Long time:timePoints)
				{
					Integer countValue = timeCountDetails.get(time);
					if(countValue == null)
					{
						countValue = 0;
					}
					cumulativeCount = cumulativeCount+countValue;
					
					HashMap<String , String> rsHs = new HashMap<String,String>();
					rsHs.put(VariationConstants.VARIATION_ID, variationId.toString());
					rsHs.put(ReportArchieveDimensionConstants.DATE,time.toString());
					rsHs.put(ReportArchieveDimensionConstants.UNIQUE_COUNT, countValue.toString());
					rsHs.put(ReportArchieveDimensionConstants.CUMULATIVE_COUNT, ((Integer)cumulativeCount).toString());
					visitorReportDetails.add(rsHs);
				}
			}
			*/
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		return visitCountDetails;
	}
	
	public static HashMap<Long, HashMap<Long, HashMap<Long, HashMap<String, Long>>>> getDatapointGoalReportInformation(String index,String portal,String reportType, String segmentType, Long expId, Long startTime, Long endTime, String dynamicAttrLinkName, String[] values, String multisegmentCriteria, boolean isHourbased, ArrayList<Long> timePoints, Long goalId)
	{
		//ArrayList<HashMap<String, String>> goalReportDetails = new ArrayList<HashMap<String, String>>();
		HashMap<Long, HashMap<Long, HashMap<Long, HashMap<String, Long>>>> goalCountDetails = null;
		QueryBuilder query =  null;
		AggregationBuilder aggregation = null;
		int size = 0 ;
		try
		{
			LOGGER.log(Level.INFO, "CHART DATA POINT - goal report query formation - START");
			if(reportType.equals(ReportConstants.SUMMARY))
			{
				query = ElasticSearchStatistics.generateSourceQueryJson(portal,expId,startTime,endTime,false,null,false,goalId,null);
			}
			else if(reportType.equals(ReportConstants.SEGMENT))
			{
				query = ElasticSearchStatistics.generateSourceSegmentQueryJson(portal,expId, startTime, endTime, segmentType, dynamicAttrLinkName, values,false,null,goalId);
			}
			else if(reportType.equals(ReportConstants.MULTISEGMENT))
			{
				query = ElasticSearchStatistics.generateSourceMultiSegmentQueryJson(portal,expId, startTime, endTime, multisegmentCriteria,false,null,goalId,null);
			}
			
			aggregation  =   generateDatapointGoalAggregateJson(isHourbased);
			LOGGER.log(Level.INFO, "CHART DATA POINT - goal report query formation - END");
			
			LOGGER.log(Level.INFO, "CHART DATA POINT - goal report fetch from ES - START");
			SearchResponse response = ElasticSearchUtil.getData(index, ElasticSearchConstants.GOAL_RAW_TYPE, size, query, aggregation);
			LOGGER.log(Level.INFO, "CHART DATA POINT - goal report fetch from ES - END");
			
			//LOGGER.log(Level.INFO, "Search response" + response.toString());
			
			LOGGER.log(Level.INFO, "CHART DATA POINT - goal report process into reponse - START");
			goalCountDetails = readDatapointGoalResponseData(response,isHourbased);
			LOGGER.log(Level.INFO, "CHART DATA POINT - goal report process into reponse - END");
			
			/*
			//Populate the cumulative count data for chart
			for(Map.Entry<Long, HashMap<Long, HashMap<Long, Integer>>> variationHs:goalCountDetails.entrySet())
			{
				Long variationId = variationHs.getKey();
				HashMap<Long, HashMap<Long, Integer>> goalDetail = variationHs.getValue();
				for(Map.Entry<Long, HashMap<Long, Integer>> goalHs:goalDetail.entrySet())
				{
					Long goalId = goalHs.getKey();
					HashMap<Long, Integer> timeCountDetails = goalHs.getValue();
					int cumulativeCount = 0;
					for(Long time:timePoints)
					{
						Integer countValue = timeCountDetails.get(time);
						if(countValue == null)
						{
							countValue = 0;
						}
						cumulativeCount = cumulativeCount+countValue;
						
						HashMap<String , String> rsHs = new HashMap<String,String>();
						rsHs.put(VariationConstants.VARIATION_ID, variationId.toString());
						rsHs.put(GoalConstants.GOAL_ID, goalId.toString());
						rsHs.put(ReportArchieveDimensionConstants.DATE,time.toString());
						rsHs.put(ReportArchieveDimensionConstants.UNIQUE_COUNT, countValue.toString());
						rsHs.put(ReportArchieveDimensionConstants.CUMULATIVE_COUNT, ((Integer)cumulativeCount).toString());
						goalReportDetails.add(rsHs);
					}
				}
			}
			*/
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		return goalCountDetails;
	}
	
	public static HashMap<String , HashMap<String, String>> getDatapointRevenueGoalReportInformation(String index,String portal,String reportType, String segmentType, Long expId, Long startTime, Long endTime, String dynamicAttrLinkName, String[] values, String multisegmentCriteria, boolean isHourbased, ArrayList<Long> timePoints, Long revenueGoalId)
	{
		HashMap<String , HashMap<String, String>> metaHs = null;
		QueryBuilder query =  null;
		AggregationBuilder aggregation = null;
		int size = 0 ;
		try
		{
			if(reportType.equals(ReportConstants.SUMMARY))
			{
				query = ElasticSearchStatistics.generateSourceQueryJson(portal,expId,startTime,endTime,true,revenueGoalId,false,null,null);
			}
			else if(reportType.equals(ReportConstants.SEGMENT))
			{
				query = ElasticSearchStatistics.generateSourceSegmentQueryJson(portal,expId, startTime, endTime, segmentType, dynamicAttrLinkName, values,true,revenueGoalId,null);
			}
			else if(reportType.equals(ReportConstants.MULTISEGMENT))
			{
				query = ElasticSearchStatistics.generateSourceMultiSegmentQueryJson(portal,expId, startTime, endTime, multisegmentCriteria,true,revenueGoalId,null,null);
			}
			if(isHourbased){
				Integer timeInterval = (int) ((endTime -startTime)/1000);
				timeInterval = timeInterval/timePoints.size();
				aggregation  =   generateDatapointRevenueGoalAggregateJson(timeInterval);
			}else{
				aggregation  =   generateDatapointRevenueGoalAggregateJson(null);
			}
			
			SearchResponse response = ElasticSearchUtil.getData(index, ElasticSearchConstants.GOAL_RAW_TYPE, size, query, aggregation);
			//LOGGER.log(Level.INFO, "Search response" + response.toString());
			metaHs = readDatapointRevenueGoalResponseData(response);
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			metaHs = new HashMap<String , HashMap<String , String>>();
		}
		return metaHs;
	}
	public static HashMap<String , HashMap<String, String>> getDatapointTimeSpentGoalReportInformation(String index,String portal,String reportType, String segmentType, Long expId, Long startTime, Long endTime, String dynamicAttrLinkName, String[] values, String multisegmentCriteria, boolean isHourbased, ArrayList<Long> timePoints, Long timeSpentGoalId)
	{
		HashMap<String , HashMap<String, String>> metaHs = null;
		QueryBuilder query =  null;
		AggregationBuilder aggregation = null;
		int size = 0 ;
		try
		{
			if(reportType.equals(ReportConstants.SUMMARY))
			{
				query = ElasticSearchStatistics.generateSourceQueryJson(portal,expId,startTime,endTime,true,null,false,null,null);
			}
			else if(reportType.equals(ReportConstants.SEGMENT))
			{
				query = ElasticSearchStatistics.generateSourceSegmentQueryJson(portal,expId, startTime, endTime, segmentType, dynamicAttrLinkName, values,true,null,null);
			}
			else if(reportType.equals(ReportConstants.MULTISEGMENT))
			{
				query = ElasticSearchStatistics.generateSourceMultiSegmentQueryJson(portal,expId, startTime, endTime, multisegmentCriteria,true,null,null,null);
			}
			if(isHourbased){
				Integer timeInterval = (int) ((endTime -startTime)/1000);
				timeInterval = timeInterval/timePoints.size();
				aggregation  =   generateDatapointTimeSpentGoalAggregateJson(timeInterval);
			}else{
				aggregation  =   generateDatapointTimeSpentGoalAggregateJson(null);
			}

			
			SearchResponse response = ElasticSearchUtil.getData(index, ElasticSearchConstants.VISITOR_RAW_TYPE, size, query, aggregation);
			metaHs = readDatapointTimeSpentGoalResponseData(response,timePoints);
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			metaHs = new HashMap<String , HashMap<String , String>>();
		}
		return metaHs;
	}
	
	public static TermsAggregationBuilder generateDatapointVistorAggregateJson(boolean isHourbased)
	{
		TermsAggregationBuilder finalAggr = null;
		try
		{
			//TODO Timezone issue needs to be considered here
			String format = isHourbased?"yyyy-MM-dd HH":"yyyy-MM-dd"; // No I18N
			
			TermsAggregationBuilder uuidVisitorAggr	= AggregationBuilders.terms("uuid_visitors").field(ElasticSearchConstants.UUID).size(ElasticSearchConstants.VISITOR_MAX_COUNT);  // No I18N
			TermsAggregationBuilder visitorAggr	= AggregationBuilders.terms("visitors").field(ElasticSearchConstants.VISITORID).size(ElasticSearchConstants.VISITOR_MAX_COUNT);  // No I18N
			MinAggregationBuilder firstDateAggr	= AggregationBuilders.min("first_date").field(ElasticSearchConstants.TIME).format(format); // No I18N	

			finalAggr = AggregationBuilders.terms("variations").   // No I18N
							field(ElasticSearchConstants.VARIATIONID).
							size(ElasticSearchConstants.VARIATION_MAX_COUNT).
								subAggregation(visitorAggr.subAggregation(firstDateAggr)).subAggregation(uuidVisitorAggr.subAggregation(firstDateAggr));
			/*
			JSONObject variationJson = new JSONObject();
			JSONObject termsJson = new JSONObject();
			termsJson.put("field", ElasticSearchConstants.VARIATIONID);
			termsJson.put("size", ElasticSearchConstants.VARIATION_MAX_COUNT);
			variationJson.put("terms", termsJson);
			JSONObject innerAggrJson = new JSONObject();
			JSONObject visitorJson = new JSONObject();
			JSONObject visitorTermsJson = new JSONObject();
			visitorTermsJson.put("field", ElasticSearchConstants.VISITORID);
			visitorTermsJson.put("size", ElasticSearchConstants.VISITOR_MAX_COUNT);
			visitorJson.put("terms", visitorTermsJson);
			JSONObject mindateAggrJson = new JSONObject();
			JSONObject firstdateJson = new JSONObject();
			JSONObject minJson = new JSONObject();
			minJson.put("field", ElasticSearchConstants.TIME);
			minJson.put("format", format);
			firstdateJson.put("min", minJson);
			mindateAggrJson.put("first_date", firstdateJson);
			visitorJson.put("aggs", mindateAggrJson);
			innerAggrJson.put("visitors", visitorJson);
			variationJson.put("aggs", innerAggrJson);
			aggrJson.put("variations", variationJson);*/
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		return finalAggr;
	}
	
	public static TermsAggregationBuilder generateDatapointGoalAggregateJson(boolean isHourbased)
	{
		TermsAggregationBuilder finalAggr = null;
		try
		{
			String format = isHourbased?"yyyy-MM-dd HH":"yyyy-MM-dd"; //No I18N
			
			TermsAggregationBuilder goalAggr = AggregationBuilders.terms("goals").field(ElasticSearchConstants.GOALID).size(ElasticSearchConstants.GOAL_MAX_COUNT); // No I18N
			TermsAggregationBuilder visitorAggr	= AggregationBuilders.terms("visitors").field(ElasticSearchConstants.VISITORID).size(ElasticSearchConstants.VISITOR_MAX_COUNT); // No I18N
			TermsAggregationBuilder uuidVisitorAggr	= AggregationBuilders.terms("uuid_visitors").field(ElasticSearchConstants.UUID).size(ElasticSearchConstants.VISITOR_MAX_COUNT); // No I18N

			MinAggregationBuilder firstDateAggr	= AggregationBuilders.min("first_date").field(ElasticSearchConstants.TIME).format(format); // No I18N

			finalAggr = AggregationBuilders.terms("variations").  // No I18N
							field(ElasticSearchConstants.VARIATIONID).
							size(ElasticSearchConstants.VARIATION_MAX_COUNT).
								subAggregation(goalAggr.subAggregation(visitorAggr.subAggregation(firstDateAggr)).subAggregation(uuidVisitorAggr.subAggregation(firstDateAggr)));
			
			/*
			JSONObject variationJson = new JSONObject();
			JSONObject termsJson = new JSONObject();
			termsJson.put("field", ElasticSearchConstants.VARIATIONID);
			termsJson.put("size", ElasticSearchConstants.VARIATION_MAX_COUNT);
			variationJson.put("terms", termsJson);
			
			JSONObject innerAggrJson1 = new JSONObject();
			JSONObject goalsJson = new JSONObject();
			JSONObject gtermsJson = new JSONObject();
			gtermsJson.put("field", ElasticSearchConstants.GOALID);
			gtermsJson.put("size", ElasticSearchConstants.GOAL_MAX_COUNT);
			goalsJson.put("terms", gtermsJson);
			
			JSONObject innerAggrJson2 = new JSONObject();
			JSONObject visitorJson = new JSONObject();
			JSONObject visitorTermsJson = new JSONObject();
			visitorTermsJson.put("field", ElasticSearchConstants.VISITORID);
			visitorTermsJson.put("size", ElasticSearchConstants.VISITOR_MAX_COUNT);
			visitorJson.put("terms", visitorTermsJson);
			
			JSONObject mindateAggrJson = new JSONObject();
			JSONObject firstdateJson = new JSONObject();
			JSONObject minJson = new JSONObject();
			minJson.put("field", ElasticSearchConstants.TIME);
			minJson.put("format", format);
			firstdateJson.put("min", minJson);
			mindateAggrJson.put("first_date", firstdateJson);
			visitorJson.put("aggs", mindateAggrJson);
			
			innerAggrJson2.put("visitors", visitorJson);
			
			goalsJson.put("aggs", innerAggrJson2);
			innerAggrJson1.put("goals", goalsJson);
			variationJson.put("aggs", innerAggrJson1);
			aggrJson.put("variations", variationJson); */
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		return finalAggr;
	}
	
	public static TermsAggregationBuilder generateDatapointRevenueGoalAggregateJson(Integer intervalInSeconds)
	{
		TermsAggregationBuilder finalAggr = null;
		try
		
		{
			
			DateHistogramInterval interval = DateHistogramInterval.DAY;
			if(intervalInSeconds!=null){
				interval = DateHistogramInterval.seconds(intervalInSeconds); 
			}
			String userTimeZone = ElasticSearchUtil.getCurrentUserTimezone();
			
			DateHistogramAggregationBuilder dateAggr = AggregationBuilders.dateHistogram("revenue_details").field(ElasticSearchConstants.TIME).dateHistogramInterval(interval); // No I18N
			if(StringUtils.isNotEmpty(userTimeZone))
			{
				DateTimeZone dtz = DateTimeZone.forID(userTimeZone);
				dateAggr.timeZone(dtz);
			}
			SumAggregationBuilder sumAggr = AggregationBuilders.sum("total_revenue").field(ElasticSearchConstants.REVENUE); // No I18N
			ValueCountAggregationBuilder valuecountAggr = AggregationBuilders.count("total_purchases").field(ElasticSearchConstants.VISITORID); // No I18N
			ValueCountAggregationBuilder uuidValueCountAggr = AggregationBuilders.count("uuid_total_purchases").field(ElasticSearchConstants.UUID); // No I18N

			
			finalAggr = AggregationBuilders.terms("variations").  // No I18N
							field(ElasticSearchConstants.VARIATIONID).
							size(ElasticSearchConstants.VARIATION_MAX_COUNT).
								subAggregation(dateAggr.subAggregation(sumAggr).subAggregation(valuecountAggr).subAggregation(uuidValueCountAggr));
			
			/*
			JSONObject variationJson = new JSONObject();
			JSONObject termsJson = new JSONObject();
			termsJson.put("field", ElasticSearchConstants.VARIATIONID);
			termsJson.put("size", ElasticSearchConstants.VARIATION_MAX_COUNT);
			variationJson.put("terms", termsJson);
			
			JSONObject innerAggrJson1 = new JSONObject();
			
			//Revenue Per day and Purchases per day json forming
			JSONObject revenuePerDayJson = new JSONObject();
			JSONObject revenueDateHistJson = new JSONObject();
			revenueDateHistJson.put("field", ElasticSearchConstants.TIME);
			revenueDateHistJson.put("interval", interval);
			if(StringUtils.isNotEmpty(userTimeZone))
			{
				revenueDateHistJson.put("time_zone", userTimeZone);
			}
			revenuePerDayJson.put("date_histogram", revenueDateHistJson);
			
			JSONObject revenueInnrAggJson = new JSONObject();
			JSONObject revenueTotalJson = new JSONObject();
			JSONObject revenueSumJson = new JSONObject();
			revenueSumJson.put("field", ElasticSearchConstants.REVENUE);
			revenueTotalJson.put("sum", revenueSumJson);
			revenueInnrAggJson.put("total_revenue", revenueTotalJson);
			
			JSONObject totalPurchasesJson = new JSONObject();
			JSONObject valueCountJson = new JSONObject();
			valueCountJson.put("field", ElasticSearchConstants.VISITORID);
			totalPurchasesJson.put("value_count", valueCountJson);
			revenueInnrAggJson.put("total_purchases", totalPurchasesJson);
			
			revenuePerDayJson.put("aggs", revenueInnrAggJson);
			
			innerAggrJson1.put("revenue_details", revenuePerDayJson);
			
			variationJson.put("aggs", innerAggrJson1);
			aggrJson.put("variations", variationJson);*/
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		return finalAggr;
	}
	public static TermsAggregationBuilder generateDatapointTimeSpentGoalAggregateJson(Integer intervalInSeconds)
	{
		TermsAggregationBuilder finalAggr = null;
		try
		{
			DateHistogramInterval interval = DateHistogramInterval.DAY;
			if(intervalInSeconds!=null){
				interval = DateHistogramInterval.seconds(intervalInSeconds); 
			}

			String userTimeZone = ElasticSearchUtil.getCurrentUserTimezone();
			
			DateHistogramAggregationBuilder dateAggr = AggregationBuilders.dateHistogram("time_spent_details").field(ElasticSearchConstants.TIME).dateHistogramInterval(interval); // No I18N
			if(StringUtils.isNotEmpty(userTimeZone))
			{
				DateTimeZone dtz = DateTimeZone.forID(userTimeZone);
				dateAggr.timeZone(dtz);
			}
			SumAggregationBuilder sumAggr = AggregationBuilders.sum("total_time_spent").field(ElasticSearchConstants.TIME_SPENT); // No I18N
			ValueCountAggregationBuilder valuecountAggr = AggregationBuilders.count("total_visits").field(ElasticSearchConstants.VISITORID); // No I18N
			ValueCountAggregationBuilder uuidValueCountAggr = AggregationBuilders.count("uuid_total_visits").field(ElasticSearchConstants.UUID); // No I18N

			
			finalAggr = AggregationBuilders.terms("variations").  // No I18N
							field(ElasticSearchConstants.VARIATIONID).
							size(ElasticSearchConstants.VARIATION_MAX_COUNT).
								subAggregation(dateAggr.subAggregation(sumAggr).subAggregation(valuecountAggr).subAggregation(uuidValueCountAggr));
			
		
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		return finalAggr;
	}
	
	public static HashMap<Long, HashMap<Long, HashMap<String, Long>>> readDatapointVisitResponseData(SearchResponse response, boolean isHourbased)
	{
		HashMap<Long, HashMap<Long, HashMap<String, Long>>> visitCountDetails = new HashMap<Long, HashMap<Long, HashMap<String, Long>>>();
		
		try
		{
			String format = isHourbased?"yyyy-MM-dd HH":"yyyy-MM-dd"; //No I18N
			
			Aggregations aggrResponse = response.getAggregations();
			Terms variationTerms = aggrResponse.get("variations");
			List<? extends Bucket> variationBuckets = variationTerms.getBuckets();
			for(Bucket variationBucket:variationBuckets)
			{
				HashMap<Long, Long> dateHs = new HashMap<Long,Long>();
				Long variationId = (Long)variationBucket.getKey();
				
				LOGGER.log(Level.INFO, "CHART DATA POINT - visitor report process variation calc - START - "+variationId);
				
				Aggregations buckaggrResponse = variationBucket.getAggregations();
				Terms visitorTerms = buckaggrResponse.get("visitors");
				List<? extends Bucket> visitorBuckets = visitorTerms.getBuckets();
				for(Bucket visitorBucket:visitorBuckets)
				{
					Aggregations visitorbuckaggrResponse = visitorBucket.getAggregations();
					InternalMin minDate = visitorbuckaggrResponse.get("first_date");
					String date = minDate.getValueAsString();
					Long dateLong = (long) minDate.getValue();
					if(isHourbased)
					{
						dateLong = ZABUtil.getUserHourInLong(dateLong);
					}
					else
					{
						dateLong = ZABUtil.getUserDateInLong(dateLong);
					}
					long count = 0;
					if(dateHs.containsKey(dateLong))
					{
						count = dateHs.get(dateLong);
					}
					dateHs.put(dateLong, count+1);
				}
				
				Terms uuidVisitorTerms = buckaggrResponse.get("uuid_visitors");
				List<? extends Bucket> uuidVisitorBuckets = uuidVisitorTerms.getBuckets();
				for(Bucket visitorBucket:uuidVisitorBuckets)
				{
					Aggregations visitorbuckaggrResponse = visitorBucket.getAggregations();
					InternalMin minDate = visitorbuckaggrResponse.get("first_date");
					String date = minDate.getValueAsString();
					Long dateLong = (long) minDate.getValue();
					if(isHourbased)
					{
						dateLong = ZABUtil.getUserHourInLong(dateLong);
					}
					else
					{
						dateLong = ZABUtil.getUserDateInLong(dateLong);
					}
					long count = 0;
					if(dateHs.containsKey(dateLong))
					{
						count = dateHs.get(dateLong);
					}
					dateHs.put(dateLong, count+1);
				}
				
				HashMap<Long, HashMap<String, Long>> timeCount = new HashMap<Long, HashMap<String, Long>>();
				
				for(Map.Entry<Long, Long> entry:dateHs.entrySet())
				{
					Long time = entry.getKey();
					Long count = entry.getValue();
					HashMap<String, Long> valueHs = new HashMap<String, Long>();
					valueHs.put(ReportArchieveDimensionConstants.UNIQUE_COUNT, count);
					timeCount.put(time, valueHs);
				}
				
				visitCountDetails.put(variationId, timeCount);
				
				LOGGER.log(Level.INFO, "CHART DATA POINT - visitor report process variation calc - END - "+variationId);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			visitCountDetails = new HashMap<Long, HashMap<Long, HashMap<String, Long>>>();
		}
		return visitCountDetails;
	}
	
	public static HashMap<Long, HashMap<Long, HashMap<Long, HashMap<String, Long>>>> readDatapointGoalResponseData(SearchResponse response, boolean isHourbased)
	{
		HashMap<Long, HashMap<Long, HashMap<Long, HashMap<String, Long>>>> goalCountDetails = new HashMap<Long, HashMap<Long, HashMap<Long, HashMap<String, Long>>>>();
		
		try
		{
			String format = isHourbased?"yyyy-MM-dd HH":"yyyy-MM-dd"; //No I18N
			
			Aggregations aggrResponse = response.getAggregations();
			Terms variationTerms = aggrResponse.get("variations");
			List<? extends Bucket> variationBuckets = variationTerms.getBuckets();
			for(Bucket variationBucket:variationBuckets)
			{
				Long variationId = (Long)variationBucket.getKey();
				LOGGER.log(Level.INFO, "CHART DATA POINT - goal report process variation calc - START - "+variationId);
				Aggregations variationbuckaggrResponse = variationBucket.getAggregations();
				Terms goalTerms = variationbuckaggrResponse.get("goals");
				List<? extends Bucket> goalBuckets = goalTerms.getBuckets();
				
				HashMap<Long, HashMap<Long, HashMap<String, Long>>> goalCount = new HashMap<Long, HashMap<Long, HashMap<String, Long>>>();
				
				for(Bucket goalBucket:goalBuckets)
				{
					Long goalId = (Long)goalBucket.getKey();
					LOGGER.log(Level.INFO, "CHART DATA POINT - goal report process goal calc - START - "+goalId);
					HashMap<Long, Long> dateHs = new HashMap<Long,Long>();
					Aggregations buckaggrResponse = goalBucket.getAggregations();
					Terms visitorTerms = buckaggrResponse.get("visitors");
					
					List<? extends Bucket> visitorBuckets = visitorTerms.getBuckets();
					for(Bucket visitorBucket:visitorBuckets)
					{
						Aggregations visitorbuckaggrResponse = visitorBucket.getAggregations();
						InternalMin minDate = visitorbuckaggrResponse.get("first_date");
						String date = minDate.getValueAsString();
						Long dateLong = (long) minDate.getValue();
						if(isHourbased)
						{
							dateLong = ZABUtil.getUserHourInLong(dateLong);
						}
						else
						{
							dateLong = ZABUtil.getUserDateInLong(dateLong);
						}
						long count = 0;
						if(dateHs.containsKey(dateLong))
						{
							count = dateHs.get(dateLong);
						}
						dateHs.put(dateLong, count+1);
					}
					
					Terms UuidVisitorTerms = buckaggrResponse.get("uuid_visitors");
					
					List<? extends Bucket> uuidVisitorBuckets = UuidVisitorTerms.getBuckets();
					for(Bucket visitorBucket:uuidVisitorBuckets)
					{
						Aggregations visitorbuckaggrResponse = visitorBucket.getAggregations();
						InternalMin minDate = visitorbuckaggrResponse.get("first_date");
						String date = minDate.getValueAsString();
						Long dateLong = (long) minDate.getValue();
						if(isHourbased)
						{
							dateLong = ZABUtil.getUserHourInLong(dateLong);
						}
						else
						{
							dateLong = ZABUtil.getUserDateInLong(dateLong);
						}
						long count = 0;
						if(dateHs.containsKey(dateLong))
						{
							count = dateHs.get(dateLong);
						}
						dateHs.put(dateLong, count+1);
					}
					
					HashMap<Long, HashMap<String, Long>> timeCount = new HashMap<Long, HashMap<String, Long>>();
					
					for(Map.Entry<Long, Long> entry:dateHs.entrySet())
					{
						
						Long time = entry.getKey();
						Long count = entry.getValue();
						HashMap<String, Long> valueHs = new HashMap<String, Long>();
						valueHs.put(ReportArchieveDimensionConstants.UNIQUE_COUNT, count);
						timeCount.put(time, valueHs);
					}
					
					goalCount.put(goalId, timeCount);
					LOGGER.log(Level.INFO, "CHART DATA POINT - goal report process goal calc - END - "+goalId);
				}
				
				goalCountDetails.put(variationId, goalCount);
				LOGGER.log(Level.INFO, "CHART DATA POINT - goal report process variation calc - END - "+variationId);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			goalCountDetails = new HashMap<Long, HashMap<Long, HashMap<Long, HashMap<String, Long>>>>();
		}
		return goalCountDetails;
	}
	
	public static HashMap<String , HashMap<String, String>> readDatapointRevenueGoalResponseData(SearchResponse response)
	{
		HashMap<String , HashMap<String, String>> metaHs = new HashMap<String , HashMap<String , String>>();
		
		try
		{
			Aggregations aggrResponse = response.getAggregations();
			Terms variationTerms = aggrResponse.get("variations");
			List<? extends Bucket> variationBuckets = variationTerms.getBuckets();
			for(Bucket variationBucket:variationBuckets)
			{
				Long variationId = (Long)variationBucket.getKey();
				
				Aggregations variationbuckaggrResponse = variationBucket.getAggregations();
				InternalDateHistogram revenueDetailsTerms = variationbuckaggrResponse.get("revenue_details");
				List<org.elasticsearch.search.aggregations.bucket.histogram.InternalDateHistogram.Bucket> revenueDetailBuckets = revenueDetailsTerms.getBuckets();
				for(org.elasticsearch.search.aggregations.bucket.histogram.InternalDateHistogram.Bucket revenueDetail:revenueDetailBuckets)
				{
					Long time = ((DateTime)revenueDetail.getKey()).getMillis();
					Aggregations revenueDetailaggrResponse = revenueDetail.getAggregations();
					InternalSum sum= revenueDetailaggrResponse.get("total_revenue");
					Double totalrevenue = sum.getValue();
					InternalValueCount valueCount = revenueDetailaggrResponse.get("total_purchases");
					Long totalPurchases = valueCount.getValue();
					
					InternalValueCount uuidValueCount = revenueDetailaggrResponse.get("uuid_total_purchases");
					Long uuidTotalPurchases = uuidValueCount.getValue();
					
					Long totalPurchasesCount = totalPurchases + uuidTotalPurchases;
					
					String key  = variationId+":"+time;
					HashMap<String, String> meta = new HashMap<String, String>();
					totalrevenue/=100;
					meta.put( ReportArchieveDimensionConstants.DATE, time.toString());
					meta.put(VariationConstants.VARIATION_ID, variationId.toString());
					meta.put(RevenueConstants.PAYING_VISITORS_COUNT,"0");
					meta.put(RevenueConstants.REVENUE, totalrevenue.toString());
					meta.put(RevenueConstants.PURCAHSES, totalPurchasesCount.toString());
				
					metaHs.put(key, meta);
				}
				
				
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			metaHs = new HashMap<String , HashMap<String , String>>();
		}
		return metaHs;
	}
	
	public static HashMap<String , HashMap<String, String>> readDatapointTimeSpentGoalResponseData(SearchResponse response,ArrayList<Long> timepoints)
	{
		HashMap<String , HashMap<String, String>> metaHs = new HashMap<String , HashMap<String , String>>();
		
		try
		{
			Aggregations aggrResponse = response.getAggregations();
			Terms variationTerms = aggrResponse.get("variations");
			List<? extends Bucket> variationBuckets = variationTerms.getBuckets();
			for(Bucket variationBucket:variationBuckets)
			{
				Long variationId = (Long)variationBucket.getKey();
				
				Aggregations variationbuckaggrResponse = variationBucket.getAggregations();
				InternalDateHistogram timeSpentDetailsTerms = variationbuckaggrResponse.get("time_spent_details");
				List<org.elasticsearch.search.aggregations.bucket.histogram.InternalDateHistogram.Bucket> timeSpetnDetailBuckets = timeSpentDetailsTerms.getBuckets();
				for(org.elasticsearch.search.aggregations.bucket.histogram.InternalDateHistogram.Bucket timeSpentDetail:timeSpetnDetailBuckets)
				{
					Long time = ((DateTime)timeSpentDetail.getKey()).getMillis();
					time = RevenueChartReport.findNearestTimeValue(timepoints, time);
					Aggregations timeSpentDetailaggrResponse = timeSpentDetail.getAggregations();
					InternalSum sum= timeSpentDetailaggrResponse.get("total_time_spent");
					Double totalTimeSpent = sum.getValue();
					InternalValueCount valueCount = timeSpentDetailaggrResponse.get("total_visits");
					Long totalvisits = valueCount.getValue();
					
					InternalValueCount uuidValueCount = timeSpentDetailaggrResponse.get("uuid_total_visits");
					Long uuidTotalVisits = uuidValueCount.getValue();
					
					Long totalVisitors = totalvisits + uuidTotalVisits;
					
					String key  = variationId+":"+time;
					HashMap<String, String> meta = new HashMap<String, String>();
					meta.put( ReportArchieveDimensionConstants.DATE, time.toString());
					meta.put(VariationConstants.VARIATION_ID, variationId.toString());
					meta.put(ReportArchieveDimensionConstants.TOTAL_COUNT,totalVisitors.toString());
					meta.put(ReportArchieveDimensionConstants.TIME_SPENT,totalTimeSpent.toString());
				
					metaHs.put(key, meta);
				}
				
				
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			metaHs = new HashMap<String , HashMap<String , String>>();
		}
		return metaHs;
	}
	
	
}
