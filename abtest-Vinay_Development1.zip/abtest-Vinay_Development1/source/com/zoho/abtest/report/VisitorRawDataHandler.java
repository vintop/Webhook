//$Id$
package com.zoho.abtest.report;

import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.zoho.abtest.BROWSER_DETAIL;
import com.zoho.abtest.CURRENTURL_DETAIL;
import com.zoho.abtest.DEVICE_DETAIL;
import com.zoho.abtest.GOAL;
import com.zoho.abtest.OS_DETAIL;
import com.zoho.abtest.REFFERERURL_DETAIL;
import com.zoho.abtest.TRAFFICSOURCE_DETAIL;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.customevent.CustomEvent;
import com.zoho.abtest.customevent.CustomEventConstants;
import com.zoho.abtest.dimension.Dimension;
import com.zoho.abtest.dimension.DimensionConstants;
import com.zoho.abtest.dimension.DimensionConstants.DynamicAttributeType;
import com.zoho.abtest.dimension.DimensionConstants.VisitorType;
import com.zoho.abtest.dimension.DynamicAttributes;
import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.forms.FormRawData;
import com.zoho.abtest.forms.FormRawDataConstants;
import com.zoho.abtest.goal.Goal;
import com.zoho.abtest.goal.GoalConstants;
import com.zoho.abtest.goal.GoalConstants.GoalType;
import com.zoho.abtest.goal.GoalVisits;
import com.zoho.abtest.heatmaps.HeatmapConstants;
import com.zoho.abtest.heatmaps.HeatmapExperiment;
import com.zoho.abtest.portal.PortalConstants;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.project.ProjectConstants;
import com.zoho.abtest.report.ElasticSearchConstants.HeatmapRawDataType;
import com.zoho.abtest.report.ElasticSearchConstants.ScrollmapRawDataType;
import com.zoho.abtest.revenue.RevenueConstants;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.abtest.variation.Variation;
import com.zoho.abtest.variation.VariationConstants;
import com.zoho.abtest.variation.VariationVisits;
import com.zoho.abtest.visitor.VisitorDetail;
import com.zoho.logs.apache.commons.lang3.StringEscapeUtils;

public class VisitorRawDataHandler {
	
	private static final Logger LOGGER = Logger.getLogger(ReportRawDataAction.class.getName());
	
	private static final long serialVersionUID = 1L;
	
	/*
	 * INPUT DATA FORMAT
	 * 
	 *
	  //If you dont know any of the values - just send the value for that field as 'UNKNOWN'
	  //If language value is not know send then as 'UNK' and its display value as 'UNKNOWN'
	  // is_new_visitor - should be 'true' or 'false' only. Do not send as UNKNOWN for it
	 * 
	 */
	public static String addHeatmapData(VisitorRawDataWrapper wrapper) throws Exception
	{	
		List<ReportRawData> reportRawDataList = new ArrayList<ReportRawData>();
		
		try
		{
			/*
			ArrayList<HashMap<String,String>> mapArray = wrapper.getExperimentsData();
			ArrayList<HashMap<String, String>> heatmappoints = wrapper.getHeatmapPoints();
			HashMap<String, String> userAgenths = wrapper.getUserAgenths();
			
			for(HashMap<String,String> inpuths:mapArray)
			{
				if(inpuths.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(inpuths.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					ReportRawData reportRawData = new ReportRawData();
					reportRawData.setSuccess(Boolean.FALSE);
					reportRawData.setResponseString(inpuths.get(ZABConstants.RESPONSE_STRING));
					reportRawDataList.add(reportRawData);
					
				}else{
					
					String dbSpaceId = null;
					Long zsoid = ZABServiceOrgUtil.getZSOIDFromDomain(inpuths.get(ReportRawDataConstants.PORTAL));
					if(zsoid != null)
					{
						dbSpaceId = zsoid.toString();
					}
					else
					{
						LOGGER.log(Level.SEVERE,"Invalid portal provided :"+inpuths.get(ReportRawDataConstants.PORTAL));
						LOGGER.log(Level.SEVERE,inpuths.toString());
						continue;
					}
					ZABUtil.setDBSpace(dbSpaceId);
	
					String variationKey = inpuths.get(ReportRawDataConstants.VARIATION_KEY);
					
					if(!variationKey.equals("original")){
						Variation variationObj = Variation.getVariationByKey(variationKey);
						inpuths.put(ReportRawDataConstants.EXPERIMENT_ID, variationObj.getExperimentId().toString());
						inpuths.put(ReportRawDataConstants.VARIATION_ID, variationObj.getVariationId().toString());
					}else{
						
						Experiment exp = Experiment.getExperimentByKey(inpuths.get(ReportRawDataConstants.EXPERIMENT_KEY));
						inpuths.put(ReportRawDataConstants.EXPERIMENT_ID, exp.getExperimentId().toString());
					}

					HashMap<String,String> hs = buildCodeDetailsFromRawDataValues(inpuths,userAgenths,wrapper.getIpAddress(), wrapper.getTime());
					hs.put("VISIT_ID", userAgenths.get(ReportRawDataConstants.UVID));
					int clicks = 0;
				
					for (HashMap<String,String> hp : heatmappoints) 
					{ 
						JSONArray jarr = new JSONArray(hp.get(ReportRawDataConstants.POINTS));
						hs.put(HeatmapConstants.SELECTOR,StringEscapeUtils.unescapeHtml4(hp.get(ReportRawDataConstants.SELECTOR)));
						
						for(int i=0; i<jarr.length() ;i++){
							
							JSONObject point = jarr.getJSONObject(i);
							   
						    hs.put(HeatmapConstants.POINT_X,Integer.toString((int) Math.round((double) point.get(ReportRawDataConstants.POINT_X) * 1000)));
						    hs.put(HeatmapConstants.POINT_Y,Integer.toString((int) Math.round((double) point.get(ReportRawDataConstants.POINT_Y) * 1000)));
						    hs.put(HeatmapConstants.CLICKS,point.get(ReportRawDataConstants.CLICKS).toString());
						    clicks += Integer.parseInt(point.get(ReportRawDataConstants.CLICKS).toString());
						    //HeatmapRawData.addHeatmapRawData(hs);
						    	
						}
						
					}
					HeatmapExperiment.updateHeatmapVisitsClicks(inpuths.get(ReportRawDataConstants.EXPERIMENT_ID),Integer.toString(clicks));				
				}	
			}
			*/
			addHeatmapDataToElasticSearch(wrapper);
		}  
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred during heat map raw data processing");
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
		}
		return null;
	
	}
	
	public static String addScrollmapData(VisitorRawDataWrapper wrapper) throws Exception
	{	
		List<ReportRawData> reportRawDataList = new ArrayList<ReportRawData>();
		
		try
		{
			/*
			ArrayList<HashMap<String,String>> mapArray = wrapper.getExperimentsData();
			ArrayList<HashMap<String,String>> scrolldata = wrapper.getScrollmapData();
			HashMap<String, String> userAgenths = wrapper.getUserAgenths();
			
			for(HashMap<String,String> inpuths:mapArray)
			{
				if(inpuths.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(inpuths.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					ReportRawData reportRawData = new ReportRawData();
					reportRawData.setSuccess(Boolean.FALSE);
					reportRawData.setResponseString(inpuths.get(ZABConstants.RESPONSE_STRING));
					reportRawDataList.add(reportRawData);
					
				}else{
					
					String dbSpaceId = null;
					Long zsoid = ZABServiceOrgUtil.getZSOIDFromDomain(inpuths.get(ReportRawDataConstants.PORTAL));
					if(zsoid != null)
					{
						dbSpaceId = zsoid.toString();
					}
					else
					{
						LOGGER.log(Level.SEVERE,"Invalid portal provided :"+inpuths.get(ReportRawDataConstants.PORTAL));
						LOGGER.log(Level.SEVERE,inpuths.toString());
						continue;
					}
					ZABUtil.setDBSpace(dbSpaceId);
	
					String variationKey = inpuths.get(ReportRawDataConstants.VARIATION_KEY);
					
					if(!variationKey.equals("original")){
						Variation variationObj = Variation.getVariationByKey(variationKey);
						inpuths.put(ReportRawDataConstants.EXPERIMENT_ID, variationObj.getExperimentId().toString());
						inpuths.put(ReportRawDataConstants.VARIATION_ID, variationObj.getVariationId().toString());
					}else{
						
						Experiment exp = Experiment.getExperimentByKey(inpuths.get(ReportRawDataConstants.EXPERIMENT_KEY));
						inpuths.put(ReportRawDataConstants.EXPERIMENT_ID, exp.getExperimentId().toString());
					}

					HashMap<String,String> hs = buildCodeDetailsFromRawDataValues(inpuths,userAgenths,wrapper.getIpAddress(), wrapper.getTime());
					hs.put("VISIT_ID", userAgenths.get(ReportRawDataConstants.UVID));
				
//					int y1 = Integer.parseInt(scrolldata.get("y1"));
//					int y2 = Integer.parseInt(scrolldata.get("y1"));
//					y1 = y1 - y1%50;
//					y2 = y2 + (50 - ( y2%50 != 0 ? y2%50 : 50));
					
//					hs.put("POINT_Y1",scrolldata.get("y1"));
//					hs.put("POINT_Y2",scrolldata.get("y2"));
//					hs.put("HEIGHT",scrolldata.get("height"));
//					ScrollmapRawData.addScrollmapRawData(hs);
				}	
			}
			*/
			
			addScrollmapDataToElasticSearch(wrapper);
		}catch(Exception ex){
			
			LOGGER.log(Level.SEVERE,"Exception occurred during heat map raw data processing");
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
		}
		return null;
	
	}
	
	public static String addScrollmapDataToElasticSearch(VisitorRawDataWrapper wrapper){
		
		try{
			ArrayList<HashMap<String,String>> mapArray = wrapper.getExperimentsData();
			ArrayList<HashMap<String,String>> scrolldata = wrapper.getScrollmapData();
			HashMap<String, String> userAgenths = wrapper.getUserAgenths();
			
			for (HashMap<String, String> hs : mapArray) {
				
				String portal = hs.get(ReportRawDataConstants.PORTAL);
				String dbSpaceId = null;
				Long zsoid = ZABServiceOrgUtil.getZSOIDFromDomain(hs.get(ReportRawDataConstants.PORTAL));
				if(zsoid != null)
				{
					dbSpaceId = zsoid.toString();
				}
				else
				{
					LOGGER.log(Level.SEVERE,"Invalid portal provided :"+hs.get(ReportRawDataConstants.PORTAL));
					LOGGER.log(Level.SEVERE,hs.toString());
					continue;
				}
				ZABUtil.setDBSpace(dbSpaceId);
				
				String index = ElasticSearchUtil.getIndexByPortal(portal);
				String type = ElasticSearchConstants.SCROLLMAP_RAW_TYPE;
				
				String variationKey = hs.get(ReportRawDataConstants.VARIATION_KEY);
				if(!variationKey.equals("original")){
					Variation variationObj = Variation.getVariationByKey(variationKey);
					hs.put(ReportRawDataConstants.EXPERIMENT_ID, variationObj.getExperimentId().toString());
					hs.put(ReportRawDataConstants.VARIATION_ID, variationObj.getVariationId().toString());
				}else{
					
					Experiment exp = Experiment.getExperimentByKey(hs.get(ReportRawDataConstants.EXPERIMENT_KEY));
					hs.put(ReportRawDataConstants.EXPERIMENT_ID, exp.getExperimentId().toString());
				}
				
				JSONObject jsonObject = buildDataDetailsForElasticSearch(hs, userAgenths, wrapper.getIpAddress(), wrapper.getTime());
				jsonObject.put(ElasticSearchConstants.PORTAL, portal);
				jsonObject.put(ElasticSearchConstants.ZSOID, zsoid);
				
				for( HashMap<String,String> smdata : scrolldata ){
					
					int y1 = Integer.parseInt(smdata.get("y1"));
					int y2 = Integer.parseInt(smdata.get("y2"));
					y1 = y1 - y1%50;
					y2 = y2 + (50 - ( y2%50 != 0 ? y2%50 : 50));
					ArrayList<Integer> array = new ArrayList<Integer>();
					
					for(int i = y1;i<y2;i+=50){
						array.add(i);
					}
					
					jsonObject.put(ElasticSearchConstants.SCROLL_Y1,y1);
					jsonObject.put(ElasticSearchConstants.SCROLL_Y2,y2);
					jsonObject.put(ElasticSearchConstants.HEIGHT,smdata.get("h"));
					jsonObject.put(ElasticSearchConstants.TIME_SPENT,smdata.get("t"));
					
					JSONObject rawdata = buildScrollmapDetailsForElasticSearch(jsonObject);
					rawdata.put(ElasticSearchConstants.SCROLL_LIST,array);
		
					try {
						ElasticSearchUtil.createIndex(index, type,rawdata.toString());							
					} catch (Exception e) {
						LOGGER.log(Level.SEVERE, e.getMessage(),e);
					}
				}
			}
		}  
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
		}
		return null;
	}
	
	public static String addHeatmapDataToElasticSearch(VisitorRawDataWrapper wrapper){
	
		try{
			ArrayList<HashMap<String, String>> mapArray = wrapper.getExperimentsData();
			ArrayList<HashMap<String, String>> heatmappoints = wrapper.getHeatmapPoints();
			HashMap<String, String> userAgenths = wrapper.getUserAgenths();
			
			for (HashMap<String, String> hs : mapArray) {
				String portal = hs.get(ReportRawDataConstants.PORTAL);
				
				String dbSpaceId = null;
				Long zsoid = ZABServiceOrgUtil.getZSOIDFromDomain(hs.get(ReportRawDataConstants.PORTAL));
				if(zsoid != null)
				{
					dbSpaceId = zsoid.toString();
				}
				else
				{
					LOGGER.log(Level.SEVERE,"Invalid portal provided :"+hs.get(ReportRawDataConstants.PORTAL));
					LOGGER.log(Level.SEVERE,hs.toString());
					continue;
				}
				ZABUtil.setDBSpace(dbSpaceId);
				
				String index = ElasticSearchUtil.getIndexByPortal(portal);
				String type = ElasticSearchConstants.HEATMAP_RAW_TYPE;
				
				String variationKey = hs.get(ReportRawDataConstants.VARIATION_KEY);
				if(!variationKey.equals("original")){
					
					Variation variationObj = Variation.getVariationByKey(variationKey);
					hs.put(ReportRawDataConstants.EXPERIMENT_ID, variationObj.getExperimentId().toString());
					hs.put(ReportRawDataConstants.VARIATION_ID, variationObj.getVariationId().toString());
					
				}else{
					
					Experiment exp = Experiment.getExperimentByKey(hs.get(ReportRawDataConstants.EXPERIMENT_KEY));
					hs.put(ReportRawDataConstants.EXPERIMENT_ID, exp.getExperimentId().toString());
				}
				
				JSONObject jsonObject = buildDataDetailsForElasticSearch(hs, userAgenths, wrapper.getIpAddress(), wrapper.getTime());
				jsonObject.put(ElasticSearchConstants.PORTAL, portal);
				jsonObject.put(ElasticSearchConstants.ZSOID, zsoid);
				
				for (HashMap<String, String> hp : heatmappoints) 
				{ 
					JSONArray jarr = new JSONArray(hp.get(ReportRawDataConstants.POINTS));
					jsonObject.put(ElasticSearchConstants.SELECTOR,StringEscapeUtils.unescapeHtml4(hp.get(ReportRawDataConstants.SELECTOR)));
					jsonObject.put(ElasticSearchConstants.DISPLAY_TEXT,hp.get(ReportRawDataConstants.DISPLAY_TEXT));
					
					for(int i=0; i<jarr.length() ;i++){
						
						JSONObject point = jarr.getJSONObject(i);
						double x = (double)point.get("x")*1000;
						double y = (double) point.get("y")*1000;
						
						jsonObject.put(ElasticSearchConstants.POINT_X,x);
						jsonObject.put(ElasticSearchConstants.POINT_Y,y);
						jsonObject.put(ElasticSearchConstants.CLICKS,point.get("c"));
						JSONObject rawdata = buildHeatmapDetailsForElasticSearch(jsonObject);
							
						try {
							ElasticSearchUtil.createIndex(index, type,rawdata.toString());							
						} catch (Exception e) {
							LOGGER.log(Level.SEVERE, e.getMessage(),e);
						}	
					}
				}
			}
		}  
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
		}
		return null;
	}
	
	public static JSONObject buildHeatmapDetailsForElasticSearch(JSONObject json) throws JSONException{
		
		HeatmapRawDataType[] heatmapRawDataTypes = HeatmapRawDataType.values();
		JSONObject resultJson = new JSONObject();
		
		for(HeatmapRawDataType heatmapRawDataType:heatmapRawDataTypes)
		{
			String fieldName = heatmapRawDataType.getFieldName();
			if(json.has(fieldName)){
				resultJson.put(fieldName, json.get(fieldName));
			}
		}
		return resultJson;
	}
	
	public static JSONObject buildScrollmapDetailsForElasticSearch(JSONObject json) throws JSONException{
		
		ScrollmapRawDataType[] scrollmapRawDataTypes = ScrollmapRawDataType.values();
		JSONObject resultJson = new JSONObject();
		
		for(ScrollmapRawDataType scrollmapRawDataType:scrollmapRawDataTypes)
		{
			String fieldName = scrollmapRawDataType.getFieldName();
			if(json.has(fieldName)){
				resultJson.put(fieldName, json.get(fieldName));
			}
		}
		return resultJson;
	}
	
	public static String addGoalRawdata(VisitorRawDataWrapper wrapper) throws Exception
	{
		List<ReportRawData> reportRawDataList = new ArrayList<ReportRawData>();
		try
		{
			
			ReportTester.incrementGoalCountConsumer();
			ArrayList<HashMap<String,String>> mapArray = wrapper.getExperimentsData();
			HashMap<String,String> userAgenths = wrapper.getUserAgenths();
			
			/*
			for(HashMap<String,String> inpuths:mapArray)
			{
				if(inpuths.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(inpuths.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					ReportRawData reportRawData = new ReportRawData();
					reportRawData.setSuccess(Boolean.FALSE);
					reportRawData.setResponseString(inpuths.get(ZABConstants.RESPONSE_STRING));
					reportRawDataList.add(reportRawData);
				}else{
					String dbSpaceId = null;
					Long zsoid = ZABServiceOrgUtil.getZSOIDFromDomain(inpuths.get(ReportRawDataConstants.PORTAL));
					if(zsoid != null)
					{
						dbSpaceId = zsoid.toString();
					}
					else
					{
						LOGGER.log(Level.SEVERE,"Invalid portal provided :"+inpuths.get(ReportRawDataConstants.PORTAL));
						LOGGER.log(Level.SEVERE,inpuths.toString());
						continue;
					}
					ZABUtil.setDBSpace(dbSpaceId);
					String variationKey = inpuths.get(ReportRawDataConstants.VARIATION_KEY);
					Variation variationObj = Variation.getVariationByKey(variationKey);
					inpuths.put(ReportRawDataConstants.EXPERIMENT_ID, variationObj.getExperimentId().toString());
					inpuths.put(ReportRawDataConstants.VARIATION_ID, variationObj.getVariationId().toString());
					
					
					
					Criteria goalExixtsCheck = new Criteria(new Column(GOAL.TABLE,GOAL.GOAL_LINK_NAME),inpuths.get(ReportRawDataConstants.GOAL_LINK_NAME),QueryConstants.EQUAL);
					
					DataObject dobj  = ZABModel.getRow(GOAL.TABLE, goalExixtsCheck);
					if(!dobj.containsTable(GOAL.TABLE)){
						ReportRawData reportRawData = new ReportRawData();
						reportRawData.setSuccess(Boolean.FALSE);
						reportRawData.setResponseString(inpuths.get(ZABConstants.RESPONSE_STRING));
						reportRawDataList.add(reportRawData);
 
					}else{
						Long goalId = (Long)dobj.getFirstValue(GOAL.TABLE, GOAL.GOAL_ID);
						Integer goalType = (Integer)dobj.getFirstValue(GOAL.TABLE, GOAL.GOAL_TYPE_FLAG);
						
						inpuths.put(GoalConstants.GOAL_ID, goalId.toString());
						HashMap<String,String> hs = buildCodeDetailsFromRawDataValues(inpuths,userAgenths,wrapper.getIpAddress(), wrapper.getTime());
						Long visitorId = VisitorDetail.getVisitorId(userAgenths.get(ReportRawDataConstants.UUID));
						hs.put("VISITOR_ID", visitorId.toString());
						hs.put("ACTIVITY_ID", userAgenths.get(ReportRawDataConstants.UAID));
						hs.put(PortalConstants.DBSPACEID, dbSpaceId);
						
						if(goalType.equals( GoalType.REVENUE_GOAL.getGoalTypeId())){
							String revenue  = inpuths.get(ReportRawDataConstants.REVENUE_VALUE);
							if(Long.parseLong(revenue) >0) {
								hs.put(RevenueConstants.REVENUE, revenue);
							}else{
								return null;
							}
							
						}else{
						
							inpuths.remove(ReportRawDataConstants.REVENUE_VALUE);
						}
						
						ReportRawData resultReportRawData = ReportRawData.addGoalRawData(hs);
						if(resultReportRawData.getSuccess())
						{
							updateGoalVisits(inpuths);
						}
						reportRawDataList.add(resultReportRawData);
					}
					
				}
			} 
			*/
			//TODO ES
			addGoalRawDataToElasticSearch(wrapper);
		}  
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred during goal raw data processing");
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
		}
		
	    
		return null;
	}
	
	public static void updateGoalVisits(HashMap<String,String> inpuths)
	{
		try
		{
			boolean isGoalAcheivedFirstTime = Boolean.parseBoolean(inpuths.get(ReportRawDataConstants.IS_GOAL_ACHIEVED_FIRST_TIME));
			Long uniqueGoalCount = isGoalAcheivedFirstTime?1l:0l;
			Long totalGoalCount = 1l;
			String revenue = null;
			if(inpuths.containsKey(ReportRawDataConstants.REVENUE_VALUE)){
				revenue =  inpuths.get(ReportRawDataConstants.REVENUE_VALUE);
			}
			HashMap<String, String> goalHs = new HashMap<String,String>(); 
			goalHs.put(ExperimentConstants.EXPERIMENT_ID,  inpuths.get(ReportRawDataConstants.EXPERIMENT_ID));
			goalHs.put(VariationConstants.VARIATION_ID, inpuths.get(ReportRawDataConstants.VARIATION_ID));
			goalHs.put(GoalConstants.GOAL_ID, inpuths.get(GoalConstants.GOAL_ID));
			goalHs.put(ReportArchieveDimensionConstants.UNIQUE_GOAL_ACHIEVED_COUNT, uniqueGoalCount.toString());
			goalHs.put(ReportArchieveDimensionConstants.TOTAL_GOAL_ACHIEVED_COUNT, totalGoalCount.toString());
			GoalVisits.updateGoalVisits(goalHs,isGoalAcheivedFirstTime,revenue); 
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
			LOGGER.log(Level.SEVERE,"Exception occured while updating variation visits count");
		}
	}
	
	private static void addVisitorRawDataToElasticSearch(VisitorRawDataWrapper wrapper) throws NumberFormatException, Exception {
		
		LOGGER.log(Level.INFO,"Elastic search rawdata push started");
		ArrayList<HashMap<String, String>> mapArray = wrapper.getExperimentsData();
		HashMap<String, String> userAgenths = wrapper.getUserAgenths();
		
		for (HashMap<String, String> hs : mapArray) {
			String portal = hs.get(ReportRawDataConstants.PORTAL);
			Long zsoid = ZABServiceOrgUtil.getZSOIDFromDomain(portal);
			String dbSpaceId = null;
			if(zsoid != null)
			{
				dbSpaceId = zsoid.toString();
			}
			else
			{
				LOGGER.log(Level.SEVERE,"Invalid portal provided :"+hs.get(ReportRawDataConstants.PORTAL));
				LOGGER.log(Level.SEVERE,hs.toString());
				continue;
			}
			ZABUtil.setDBSpace(dbSpaceId);
			String index = ElasticSearchUtil.getIndexByPortal(portal);
			String type = ElasticSearchConstants.VISITOR_RAW_TYPE;
			String variationKey = hs.get(ReportRawDataConstants.VARIATION_KEY);
			if(hs.get(ReportRawDataConstants.EXPERIMENT_KEY) == null){ // FOR CUSTOM EVENTS , NO ASSOCIATED EXPERIMENT IS PRESENT
				String projkey = hs.get(ReportRawDataConstants.PROJECT_KEY);
				Long projid = Project.getProjectIdFromKey(projkey);
				hs.put(ProjectConstants.PROJECT_ID, projid.toString());
				String goalLnName = hs.get(ReportRawDataConstants.GOAL_LINK_NAME);
				String existingDocId = null;
				if(goalLnName!=null){
					Long goalid = Goal.getGoalIdForGoal(goalLnName);
					hs.put(GoalConstants.GOAL_ID, goalid.toString());
					hs.put(ElasticSearchConstants.IS_PROJECT_GOAL, Boolean.TRUE.toString());
					existingDocId = ElasticSearchUtil.getExistingDocumentIdForProjectGoal(index, portal, userAgenths.get(ReportRawDataConstants.UVID),goalid.toString());
					
				}else{ // Landing page
					 existingDocId = ElasticSearchUtil.getExistingDocumentIdForPageVisit(index, portal, userAgenths.get(ReportRawDataConstants.UVID));
					
				}
				
				if(existingDocId == null){
					JSONObject jsonObject = buildDataDetailsForElasticSearch(hs, userAgenths, wrapper.getIpAddress(), wrapper.getTime());
					jsonObject.put(ElasticSearchConstants.PORTAL, portal);
					try {
						ElasticSearchUtil.createIndex(index, type, jsonObject.toString());
					} catch (Exception e) {
						LOGGER.log(Level.SEVERE, e.getMessage(),e);
					}
					return;
				}else{
					JSONObject jsonObject = buildUpdateDataDetailsForElasticSearch(hs);
					try {
						ElasticSearchUtil.updateIndex(index, type , existingDocId , jsonObject.toString());
					} catch (Exception e) {
						LOGGER.log(Level.SEVERE, e.getMessage(),e);
					}
					return;
				}
			}
			Long experimentId = null;
			
			if(!variationKey.equals("original")){
				
				Variation variationObj = Variation.getVariationByKey(variationKey);
				experimentId = variationObj.getExperimentId();
				hs.put(ReportRawDataConstants.EXPERIMENT_ID, variationObj.getExperimentId().toString());
				hs.put(ReportRawDataConstants.VARIATION_ID, variationObj.getVariationId().toString());
				
				
			}else{
				
				Experiment exp = Experiment.getExperimentByKey(hs.get(ReportRawDataConstants.EXPERIMENT_KEY));
				experimentId = exp.getExperimentId();
				hs.put(ReportRawDataConstants.EXPERIMENT_ID, exp.getExperimentId().toString());
			}
			
			
			String existingDocId = ElasticSearchUtil.getExistingDocumentIdByVisitId(index, portal, experimentId, userAgenths.get(ReportRawDataConstants.UVID));
			
			if(existingDocId == null)
			{
				JSONObject jsonObject = buildDataDetailsForElasticSearch(hs, userAgenths, wrapper.getIpAddress(), wrapper.getTime());
				jsonObject.put(ElasticSearchConstants.PORTAL, portal);
				jsonObject.put(ElasticSearchConstants.ZSOID, zsoid);
				try {
					ElasticSearchUtil.createIndex(index, type, jsonObject.toString());
				} catch (Exception e) {
					LOGGER.log(Level.SEVERE, e.getMessage(),e);
				}
			}
			else
			{
				JSONObject custDimJson = buildUpdateDataDetailsForElasticSearch(hs);
				try {
					ElasticSearchUtil.updateIndex(index, type, existingDocId, custDimJson.toString());
				} catch (Exception e) {
					LOGGER.log(Level.SEVERE, e.getMessage(),e);
				}
			}
		}
		LOGGER.log(Level.INFO,"Elastic search rawdata push completed");
	}
	
	
	private static void addGoalRawDataToElasticSearch(VisitorRawDataWrapper wrapper) throws NumberFormatException, Exception {
		
		ArrayList<HashMap<String, String>> mapArray = wrapper.getExperimentsData();
		HashMap<String, String> userAgenths = wrapper.getUserAgenths();
		
		for (HashMap<String, String> hs : mapArray) {
			
			String portal = hs.get(ReportRawDataConstants.PORTAL);
			Long zsoid = ZABServiceOrgUtil.getZSOIDFromDomain(portal);
			String dbSpaceId = null;
			if(zsoid != null)
			{
				dbSpaceId = zsoid.toString();
			}
			else
			{
				LOGGER.log(Level.SEVERE,"Invalid portal provided :"+hs.get(ReportRawDataConstants.PORTAL));
				LOGGER.log(Level.SEVERE,hs.toString());
				continue;
			}
			ZABUtil.setDBSpace(dbSpaceId);
			String index = ElasticSearchUtil.getIndexByPortal(portal);
			String type = ElasticSearchConstants.GOAL_RAW_TYPE;
			
			if(hs.get(ReportRawDataConstants.EXPERIMENT_KEY) == null){ // FOR CUSTOM EVENTS , NO ASSOCIATED EXPERIMENT IS PRESENT)
				String projkey = hs.get(ReportRawDataConstants.PROJECT_KEY);
				Long projid = Project.getProjectIdFromKey(projkey);
				hs.put(ProjectConstants.PROJECT_ID, projid.toString());
				String goalLnName = hs.get(ReportRawDataConstants.GOAL_LINK_NAME);
				Long goalid = Goal.getGoalIdForGoal(goalLnName);
				hs.put(GoalConstants.GOAL_ID, goalid.toString());
				hs.put(ElasticSearchConstants.IS_PROJECT_GOAL, Boolean.TRUE.toString());
				JSONObject jsonObject = buildDataDetailsForElasticSearch(hs, userAgenths, wrapper.getIpAddress(), wrapper.getTime());
				jsonObject.put(ElasticSearchConstants.PORTAL, portal);
				try {
					ElasticSearchUtil.createIndex(index, type, jsonObject.toString());
				} catch (Exception e) {
					LOGGER.log(Level.SEVERE, e.getMessage(),e);
				}
				return ;
			
			}
			String variationKey = hs.get(ReportRawDataConstants.VARIATION_KEY);
			Criteria goalExixtsCheck = new Criteria(new Column(GOAL.TABLE,GOAL.GOAL_LINK_NAME),hs.get(ReportRawDataConstants.GOAL_LINK_NAME),QueryConstants.EQUAL);
			DataObject dobj  = ZABModel.getRow(GOAL.TABLE, goalExixtsCheck);
			if(!dobj.containsTable(GOAL.TABLE)){
				LOGGER.log(Level.SEVERE,"Invalid goal link name provided :"+hs.get(ReportRawDataConstants.GOAL_LINK_NAME));
				continue;
			}
			Long goalId = (Long)dobj.getFirstValue(GOAL.TABLE, GOAL.GOAL_ID);
		
			//CHECKING FOR REVENUE GOAL 
			Integer goalType = (Integer)dobj.getFirstValue(GOAL.TABLE, GOAL.GOAL_TYPE_FLAG);
			if(goalType.equals( GoalType.REVENUE_GOAL.getGoalTypeId())){
				String revenue  = hs.get(ReportRawDataConstants.REVENUE_VALUE);
				if(Long.parseLong(revenue) <= 0) {
					return ;
				}
			}else{
				hs.remove(ReportRawDataConstants.REVENUE_VALUE);
			}
			
			
			Variation variationObj = Variation.getVariationByKey(variationKey);
			hs.put(ReportRawDataConstants.EXPERIMENT_ID, variationObj.getExperimentId().toString());
			hs.put(ReportRawDataConstants.VARIATION_ID, variationObj.getVariationId().toString());
			hs.put(GoalConstants.GOAL_ID, goalId.toString());
			
			String existingDocId = ElasticSearchUtil.getExistingDocumentIdByGoalActivityId(index, portal, variationObj.getVariationId(), goalId, userAgenths.get(ReportRawDataConstants.UAID));
			
			if(existingDocId == null)
			{
				JSONObject jsonObject = buildDataDetailsForElasticSearch(hs, userAgenths, wrapper.getIpAddress(), wrapper.getTime());
				jsonObject.put(ElasticSearchConstants.PORTAL, portal);
				jsonObject.put(ElasticSearchConstants.ZSOID, zsoid);
				try {
					ElasticSearchUtil.createIndex(index, type, jsonObject.toString());
				} catch (Exception e) {
					LOGGER.log(Level.SEVERE, e.getMessage(),e);
				}
			}
		}		
	}
	
	public static String addVisitorRawdata(VisitorRawDataWrapper wrapper) throws Exception
	{
		List<ReportRawData> reportRawDataList = new ArrayList<ReportRawData>();
		try
		{
			ReportTester.incrementVisitorCountCousumer();
			ArrayList<HashMap<String,String>> mapArray = wrapper.getExperimentsData();
			HashMap<String,String> userAgenths = wrapper.getUserAgenths();
			/*
			for(HashMap<String,String> inpuths:mapArray)
			{
				if(inpuths.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(inpuths.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					ReportRawData reportRawData = new ReportRawData();
					reportRawData.setSuccess(Boolean.FALSE);
					reportRawData.setResponseString(inpuths.get(ZABConstants.RESPONSE_STRING));
					reportRawDataList.add(reportRawData);
				}else{
					String dbSpaceId = null;
					Long zsoid = ZABServiceOrgUtil.getZSOIDFromDomain(inpuths.get(ReportRawDataConstants.PORTAL));
					if(zsoid != null)
					{
						dbSpaceId = zsoid.toString();
					}
					else
					{
						LOGGER.log(Level.SEVERE,"Invalid portal provided :"+inpuths.get(ReportRawDataConstants.PORTAL));
						LOGGER.log(Level.SEVERE,inpuths.toString());
						continue;
					}
					ZABUtil.setDBSpace(dbSpaceId);
					
					
					String variationKey = inpuths.get(ReportRawDataConstants.VARIATION_KEY);
					
					if(!variationKey.equals("original")){
						
						Variation variationObj = Variation.getVariationByKey(variationKey);
						inpuths.put(ReportRawDataConstants.EXPERIMENT_ID, variationObj.getExperimentId().toString());
						inpuths.put(ReportRawDataConstants.VARIATION_ID, variationObj.getVariationId().toString());
						
						HashMap<String, String> vrawdata = ReportRawData.getVisitorRawData(userAgenths.get(ReportRawDataConstants.UVID), variationObj.getExperimentId());
						
						if(vrawdata.isEmpty()) {
							HashMap<String,String> hs = buildCodeDetailsFromRawDataValues(inpuths,userAgenths,wrapper.getIpAddress(), wrapper.getTime());
							hs.put("VISIT_ID", userAgenths.get(ReportRawDataConstants.UVID));
							Long visitorId = VisitorDetail.getVisitorId(userAgenths.get(ReportRawDataConstants.UUID));
							hs.put("VISITOR_ID", visitorId.toString());
							hs.put(PortalConstants.DBSPACEID, dbSpaceId);
							ReportRawData resultReportRawData = ReportRawData.addVisitorRawData(hs);
							if(resultReportRawData.getSuccess())
							{
								updateVariationVisits(inpuths);
							}
							reportRawDataList.add(resultReportRawData);						
						} else {				
							
							if(inpuths.containsKey(ReportRawDataConstants.TIME_SPENT)){
								// do  time spent related code
								
								Long visitorRawId = Long.parseLong(vrawdata.get(ReportRawDataConstants.VISITOR_DATA_RAW_ID));
								Long timeSpent  = Long.parseLong(inpuths.get(ReportRawDataConstants.TIME_SPENT));
								ReportRawData.addTimeSpentRawData(visitorRawId,timeSpent);

								break;
							}
							HashMap<String,String> hs = buildUpdateCodeDetailsFromRawDataValues(inpuths, vrawdata);
							hs.put("VISIT_ID", userAgenths.get(ReportRawDataConstants.UVID));
							ReportRawData resultReportRawData = ReportRawData.updateVisitorRawData(hs);
							reportRawDataList.add(resultReportRawData);
						}
						
					}else{
						
						Experiment exp = Experiment.getExperimentByKey(inpuths.get(ReportRawDataConstants.EXPERIMENT_KEY));
						inpuths.put(ReportRawDataConstants.EXPERIMENT_ID, exp.getExperimentId().toString());
						HeatmapExperiment.updateHeatmapVisits(inpuths);
					}
				}
			}
			*/
			//TODO ES
			addVisitorRawDataToElasticSearch(wrapper);
		}  
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred during visitor raw data processing");
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
		}
	    
		return null;
	}
	
	public static void updateVariationVisits(HashMap<String,String> inpuths)
	{
		try
		{
			boolean isNewVisitor = Boolean.parseBoolean(inpuths.get(ReportRawDataConstants.IS_NEW_VISITOR));
			Long uniqueVisitorCount = isNewVisitor?1l:0l;
			Long totalVisitorCount = 1l;
			HashMap<String, String> visitsHs = new HashMap<String,String>(); 
			visitsHs.put(VariationConstants.EXPERIMENT_ID,  inpuths.get(ReportRawDataConstants.EXPERIMENT_ID));
			visitsHs.put(VariationConstants.VARIATION_ID, inpuths.get(ReportRawDataConstants.VARIATION_ID));
			visitsHs.put(VariationConstants.UNIQUE_VISITOR_COUNT, uniqueVisitorCount.toString());
			visitsHs.put(VariationConstants.TOTAL_VISITOR_COUNT, totalVisitorCount.toString());
			VariationVisits.updateVariationVisits(visitsHs,isNewVisitor); 
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
			LOGGER.log(Level.SEVERE,"Exception occured while updating variation visits count");
		}
	}
	
	public static HashMap<String,String> buildUpdateCodeDetailsFromRawDataValues(HashMap<String,String> inpuths, HashMap<String,String> vrawdata) throws Exception
	{
		HashMap<String,String> hs = new HashMap<String,String>(); 
		JSONObject customDimensionJson = new JSONObject(vrawdata.get("custom_dimension_json"));
		if(inpuths.containsKey(ReportRawDataConstants.DYNAMICATTRIBUTES)){
		      JSONArray dynamicAttributeAray = new JSONArray(inpuths.get(ReportRawDataConstants.DYNAMICATTRIBUTES));
		      Integer customDimensionCode =DynamicAttributeType.CUSTOMDIMENSION.getAttributeTypeCode();
		       
		       HashMap<String,DynamicAttributes> dynamicAttriHs =  DynamicAttributes.getCustomDimensionOfExperiment(inpuths.get(ReportRawDataConstants.EXPERIMENT_ID));
		       
		       for(int i=0;i<dynamicAttributeAray.length();i++){
		    	   JSONObject dynamicAttribute = (JSONObject)dynamicAttributeAray.get(i);
		    	   String attributeLinkName =(String) dynamicAttribute.get(ReportRawDataConstants.ATTRIBUTE_LINK_NAME);
		    	   if(dynamicAttriHs.containsKey(attributeLinkName)){
		    		   Integer attributeType =(Integer) dynamicAttribute.get(ReportRawDataConstants.ATTRIBUTE_TYPE);
			    	   String attributeValue =(String) dynamicAttribute.get(ReportRawDataConstants.ATTRIBUTE_VALUE);
			    	   String attributeId =  dynamicAttriHs.get(attributeLinkName).getDynamicAttributeId().toString();
			    	   Integer code  = Dimension.getDynamicAttributeCodeByValue(Long.parseLong(attributeId),attributeValue);
			    	   if(attributeType.equals(customDimensionCode)){
			    		   customDimensionJson.put(attributeId, code);
			    	   }
		    	   }
		    	   
		       }
		    }
		hs.put("CUSTOM_DIMENSION_JSON", customDimensionJson.toString());
		hs.put(ReportRawDataConstants.EXPERIMENT_ID, inpuths.get(ReportRawDataConstants.EXPERIMENT_ID));
		return hs;
		
	}
	
	public static HashMap<String,String> buildCodeDetailsFromRawDataValues(HashMap<String,String> inpuths,HashMap<String,String> userAgenths, String ipaddress, Long currentTime) throws Exception
	{
		HashMap<String,String> hs = new HashMap<String,String>(); 
		
		HashMap<String,String> browserHs = new HashMap<String,String>(); 

		browserHs.put(DimensionConstants.BROWSER_VALUE, userAgenths.get(ReportRawDataConstants.BROWSER_VALUE).toUpperCase()); 
		Integer browserCode = Dimension.getCommonDimensionCodeByValue(BROWSER_DETAIL.TABLE, BROWSER_DETAIL.BROWSER_CODE, DimensionConstants.BROWSER_CODE, BROWSER_DETAIL.BROWSER_VALUE, DimensionConstants.BROWSER_VALUE,browserHs, DimensionConstants.BROWSER_DETAIL_CONSTANTS);
		
		HashMap<String,String> deviceHs = new HashMap<String,String>(); 
		deviceHs.put(DimensionConstants.DEVICE_VALUE, userAgenths.get(ReportRawDataConstants.DEVICE_VALUE).toUpperCase()); 
		Integer deviceCode = Dimension.getCommonDimensionCodeByValue(DEVICE_DETAIL.TABLE, DEVICE_DETAIL.DEVICE_CODE, DimensionConstants.DEVICE_CODE, DEVICE_DETAIL.DEVICE_VALUE, DimensionConstants.DEVICE_VALUE,deviceHs, DimensionConstants.DEVICE_DETAIL_CONSTANTS);

		
		//Fetching ipaddress and country details from it
//		String ipaddress = request.getHeader("X-FORWARDED-FOR");
//		if(ipaddress == null)
//		{
//			ipaddress = request.getRemoteAddr();
//		}
		JSONObject ipDetailsJson = ZABUtil.getIpAddressDetails(ipaddress);
		String countryValue = ipDetailsJson.has("COUNTRY_CODE") ? ipDetailsJson.get("COUNTRY_CODE").toString() : "-"; //NO I18N
		String countryName = ipDetailsJson.has("COUNTRY_NAME") ? ipDetailsJson.get("COUNTRY_NAME").toString() : "-"; //NO I18N
		if(countryValue.equals("-"))
		{
			countryValue = ReportRawDataConstants.UNKNOWN_COUNTRY_CODE;
			countryName = ReportRawDataConstants.UNKNOWN_VALUE;
		}
		
		HashMap<String,String> countryHs = new HashMap<String,String>();
		countryHs.put(DimensionConstants.COUNTRY_VALUE, countryValue.toUpperCase()); 
		countryHs.put(DimensionConstants.COUNTRY_DISPLAY_NAME, countryName.toUpperCase()); 
		Integer countryCode = 5;//Dimension.getCommonDimensionCodeByValue(COUNTRY_DETAIL.TABLE, COUNTRY_DETAIL.COUNTRY_CODE, DimensionConstants.COUNTRY_CODE, COUNTRY_DETAIL.COUNTRY_VALUE, DimensionConstants.COUNTRY_VALUE,countryHs, DimensionConstants.COUNTRY_DETAIL_CONSTANTS);
		
		HashMap<String,String> languageHs = new HashMap<String,String>(); 
		languageHs.put(DimensionConstants.LANGUAGE_VALUE, userAgenths.get(ReportRawDataConstants.LANGUAGE_VALUE).toUpperCase()); 
		String languageDisplayName = ZABUtil.getLanguageFromCode(userAgenths.get(ReportRawDataConstants.LANGUAGE_VALUE).toUpperCase());
		languageHs.put(DimensionConstants.LANGUAGE_DISPLAY_NAME, languageDisplayName); 
		Integer languageCode = 5;//Dimension.getCommonDimensionCodeByValue(LANGUAGE_DETAIL.TABLE, LANGUAGE_DETAIL.LANGUAGE_CODE, DimensionConstants.LANGUAGE_CODE, LANGUAGE_DETAIL.LANGUAGE_VALUE, DimensionConstants.LANGUAGE_VALUE,languageHs, DimensionConstants.LANGUAGE_DETAIL_CONSTANTS);
		
		/*
		HashMap<String,String> usertypeHs = new HashMap<String,String>(); 
		usertypeHs.put(DimensionConstants.USERTYPE_VALUE, inpuths.get(DimensionConstants.USERTYPE_VALUE).toUpperCase()); //TODO
		Integer usertypeCode = Dimension.getDimensionCodeByValue(USERTYPE_DETAIL.TABLE, USERTYPE_DETAIL.USERTYPE_CODE, DimensionConstants.USERTYPE_CODE, USERTYPE_DETAIL.USERTYPE_VALUE, DimensionConstants.USERTYPE_VALUE,usertypeHs, DimensionConstants.USERTYPE_DETAIL_CONSTANTS);
		*/
		Boolean isNewVisitor =true;
		Integer uniqueCountFlag =1;
		Integer usertypeCode =null;
		
		try{
			
			if(inpuths.containsKey(ReportRawDataConstants.IS_NEW_VISITOR)){
				isNewVisitor = Boolean.parseBoolean(inpuths.get(ReportRawDataConstants.IS_NEW_VISITOR));
				uniqueCountFlag = isNewVisitor?1:0;
				
			}
			if(inpuths.containsKey(ReportRawDataConstants.IS_GOAL_ACHIEVED_FIRST_TIME)){
				Boolean isGoalAchievedFirstTime = Boolean.parseBoolean(inpuths.get(ReportRawDataConstants.IS_GOAL_ACHIEVED_FIRST_TIME));
				 uniqueCountFlag = isGoalAchievedFirstTime?1:0;
				
			}
		}catch(Exception e){
			LOGGER.log(Level.SEVERE,"Goal Achieved first time / is new visitor key not set to boolean",e);
		}
		
		usertypeCode = isNewVisitor? VisitorType.NEW_VISITOR.getVisitorTypeCode():VisitorType.RETURNING_VISITOR.getVisitorTypeCode();
		Integer totalCountFlag = 1; //This will always be 1 for one visit request
		
		HashMap<String,String> osHs = new HashMap<String,String>(); 

		osHs.put(DimensionConstants.OS_VALUE, userAgenths.get(ReportRawDataConstants.OS_VALUE).toUpperCase()); 
		Integer osCode = Dimension.getCommonDimensionCodeByValue(OS_DETAIL.TABLE, OS_DETAIL.OS_CODE, DimensionConstants.OS_CODE, OS_DETAIL.OS_VALUE, DimensionConstants.OS_VALUE,osHs, DimensionConstants.OS_DETAIL_CONSTANTS);
		
		HashMap<String,String> trafficsourceHs = new HashMap<String,String>(); 
		trafficsourceHs.put(DimensionConstants.TRAFFICSOURCE_VALUE, userAgenths.get(ReportRawDataConstants.TRAFFICSOURCE_VALUE).toUpperCase());
		Integer trafficsourceCode = Dimension.getCommonDimensionCodeByValue(TRAFFICSOURCE_DETAIL.TABLE, TRAFFICSOURCE_DETAIL.TRAFFICSOURCE_CODE, DimensionConstants.TRAFFICSOURCE_CODE, TRAFFICSOURCE_DETAIL.TRAFFICSOURCE_VALUE, DimensionConstants.TRAFFICSOURCE_VALUE,trafficsourceHs, DimensionConstants.TRAFFICSOURCE_DETAIL_CONSTANTS);
		
		HashMap<String,String> reffererurlHs = new HashMap<String,String>(); 
		reffererurlHs.put(DimensionConstants.REFFERERURL_VALUE, userAgenths.get(ReportRawDataConstants.REFFERERURL_VALUE)); 
		Integer reffererurlCode = Dimension.getDimensionCodeByValue(REFFERERURL_DETAIL.TABLE, REFFERERURL_DETAIL.REFFERERURL_CODE, DimensionConstants.REFFERERURL_CODE, REFFERERURL_DETAIL.REFFERERURL_VALUE, DimensionConstants.REFFERERURL_VALUE,reffererurlHs, DimensionConstants.REFFERERURL_DETAIL_CONSTANTS);
		
		HashMap<String,String> currenturlHs = new HashMap<String,String>(); 
		currenturlHs.put(DimensionConstants.CURRENTURL_VALUE, userAgenths.get(ReportRawDataConstants.CURRENTURL_VALUE)); 
		Integer currenturlCode = Dimension.getDimensionCodeByValue(CURRENTURL_DETAIL.TABLE, CURRENTURL_DETAIL.CURRENTURL_CODE, DimensionConstants.CURRENTURL_CODE, CURRENTURL_DETAIL.CURRENTURL_VALUE, DimensionConstants.CURRENTURL_VALUE,currenturlHs, DimensionConstants.CURRENTURL_DETAIL_CONSTANTS);

		
		hs.put("EXPERIMENT_ID", inpuths.get(ReportRawDataConstants.EXPERIMENT_ID));
		hs.put("VARIATION_ID", inpuths.get(ReportRawDataConstants.VARIATION_ID));
		if(inpuths.containsKey(GoalConstants.GOAL_ID)){
			hs.put("GOAL_ID", inpuths.get(GoalConstants.GOAL_ID));
			
		}
		
		hs.put("BROWSER_CODE", browserCode.toString());
		hs.put("DEVICE_CODE", deviceCode.toString());
		hs.put("COUNTRY_CODE", countryCode.toString()); 
		hs.put("LANGUAGE_CODE", languageCode.toString());
		hs.put("USERTYPE_CODE", usertypeCode.toString());
		hs.put("OS_CODE", osCode.toString());
		hs.put("TRAFFICSOURCE_CODE", trafficsourceCode.toString());
		hs.put("REFFERERURL_CODE", reffererurlCode.toString());
		hs.put("CURRENTURL_CODE", currenturlCode.toString());
		
//		Long currentTime = ZABUtil.getCurrentTimeInMilliSeconds();
		
		hs.put("DAYOFWEEK_CODE", ZABUtil.getDayOfWeek(currentTime).toString());  
		hs.put("HOUROFDAY_CODE", ZABUtil.getHourOfDay(currentTime).toString());  
		
		//TODO
		JSONObject cookieJson = new JSONObject();
		JSONObject urlParamJson = new JSONObject();
		JSONObject jsVariableJson = new JSONObject();
		JSONObject customDimensionJson = new JSONObject();
		
	
		if(inpuths.containsKey(ReportRawDataConstants.DYNAMICATTRIBUTES)){
		      JSONArray dynamicAttributeAray = new JSONArray(inpuths.get(ReportRawDataConstants.DYNAMICATTRIBUTES));
		      Integer urlParamCode =DynamicAttributeType.URLPARAMETER.getAttributeTypeCode();
		       Integer cookieCode =DynamicAttributeType.COOKIE.getAttributeTypeCode();
		       Integer jsVariableCode =DynamicAttributeType.JSVARIABLE.getAttributeTypeCode();
		       Integer customDimensionCode =DynamicAttributeType.CUSTOMDIMENSION.getAttributeTypeCode();
		       
		       HashMap<String,DynamicAttributes> dynamicAttriHs =  DynamicAttributes.getDynamicAttributesOfExperiment(hs.get("EXPERIMENT_ID"));		// NO I18N
		       
		       for(int i=0;i<dynamicAttributeAray.length();i++){
		    	   JSONObject dynamicAttribute = (JSONObject)dynamicAttributeAray.get(i);
		    	   String attributeLinkName =(String) dynamicAttribute.get(ReportRawDataConstants.ATTRIBUTE_LINK_NAME);
		    	   if(dynamicAttriHs.containsKey(attributeLinkName)){
		    		   Integer attributeType =(Integer) dynamicAttribute.get(ReportRawDataConstants.ATTRIBUTE_TYPE);
			    	   String attributeValue =(String) dynamicAttribute.get(ReportRawDataConstants.ATTRIBUTE_VALUE);
			    	   String attributeId =  dynamicAttriHs.get(attributeLinkName).getDynamicAttributeId().toString();
			    	   Integer code  = 5;//Dimension.getDynamicAttributeCodeByValue(Long.parseLong(attributeId),attributeValue);
			    	   if(attributeType.equals(urlParamCode)){
			    		   urlParamJson.put(attributeId, code);
			    	   }else if(attributeType.equals(cookieCode)){
			    		   cookieJson.put(attributeId, code);
			    		   
			    	   }else if(attributeType.equals(jsVariableCode)){
			    		   jsVariableJson.put(attributeId, code);
			    	   }else if(attributeType.equals(customDimensionCode)){
			    		   customDimensionJson.put(attributeId, code);
			    	   }
			    	   
			    	   dynamicAttriHs.remove(attributeLinkName);
		    	   }
		    	   
		       }
		       // DYNAMIC ATTRIBUTES WHICK ARE NOT SENT IN REQUEST ARE FILLED WITH 'UNKNOWN'
		       
		       Set<String> keySet = dynamicAttriHs.keySet();
		       Iterator<String> keysItr = keySet.iterator();
		       while(keysItr.hasNext()){
		    	  String attributeLinkName  =  keysItr.next();
		    	  DynamicAttributes da = dynamicAttriHs.get(attributeLinkName);
		    	  Integer attributeType = da.getAttributeType();	
		    	  String attributeId = da.getDynamicAttributeId().toString();	
		    	  Integer code  = Dimension.getDynamicAttributeCodeByValue(da.getDynamicAttributeId(),ReportRawDataConstants.UNKNOWN_VALUE);		
		    	  if(attributeType.equals(urlParamCode)){
		    		   urlParamJson.put(attributeId, code);
		    	   }else if(attributeType.equals(cookieCode)){
		    		   cookieJson.put(attributeId, code);
		    		   
		    	   }else if(attributeType.equals(jsVariableCode)){
		    		   jsVariableJson.put(attributeId, code);
		    	   }else if(attributeType.equals(customDimensionCode)){
		    		   customDimensionJson.put(attributeId, code);
		    	   }
			    	 
		       }
		    }
		hs.put("COOKIE_CODE", cookieJson.toString() );
		hs.put("URLPARAM_CODE",urlParamJson.toString() );
		hs.put("JS_VARIABLE_CODE", jsVariableJson.toString());
		hs.put("CUSTOM_DIMENSION_JSON", customDimensionJson.toString());
		
		hs.put("UNIQUECOUNT_FLAG", uniqueCountFlag.toString());  
		hs.put("TOTALCOUNT_FLAG", totalCountFlag.toString());
		hs.put("TIME", currentTime.toString());
		
		return hs;
		
	}
	
	public static JSONArray parseUrlparamValues(String urlParamStr)
	{
		JSONArray resultUrlparamArr = new JSONArray();
		if(StringUtils.isNotEmpty(urlParamStr))
		{
			try
			{
				JSONArray urlParamArr = new JSONArray(urlParamStr);
				for(int arrIndex = 0; arrIndex < urlParamArr.length(); arrIndex++)
				{
					JSONObject jsonObj = urlParamArr.getJSONObject(arrIndex);
					String paramName = jsonObj.getString(ReportRawDataConstants.PARAMETER_NAME);
					String paramValue = jsonObj.getString(ReportRawDataConstants.PARAMETER_VALUE);
					JSONObject urlParamJson = new JSONObject();
					urlParamJson.put(ElasticSearchConstants.NAME, paramName);
					urlParamJson.put(ElasticSearchConstants.VALUE, paramValue);
					resultUrlparamArr.put(urlParamJson);
				}
			}
			catch(Exception ex)
			{
				LOGGER.log(Level.SEVERE, "Suppressed - Exception while urlparam json parsing, " + ex.getMessage(), ex);
			}
		}
		return resultUrlparamArr;
	}
	
	public static JSONObject buildDataDetailsForElasticSearch(HashMap<String,String> inpuths,HashMap<String,String> userAgenths, String ipaddress, Long currentTime) throws Exception
	{
		JSONObject resultJson = new JSONObject();
		
		String browser = userAgenths.get(ReportRawDataConstants.BROWSER_VALUE).toUpperCase();
		String device = userAgenths.get(ReportRawDataConstants.DEVICE_VALUE).toUpperCase();
		String country = null;
		String city = null;
		String region = null;
		String language = ZABUtil.getLanguageFromCode(userAgenths.get(ReportRawDataConstants.LANGUAGE_VALUE).toUpperCase());
		String os = userAgenths.get(ReportRawDataConstants.OS_VALUE).toUpperCase();
		String trafficsource = userAgenths.get(ReportRawDataConstants.TRAFFICSOURCE_VALUE).toUpperCase();
		String refurl = userAgenths.get(ReportRawDataConstants.REFFERERURL_VALUE);
		String currenturl = userAgenths.get(ReportRawDataConstants.CURRENTURL_VALUE);
		String urlParamStr = userAgenths.get(ReportRawDataConstants.URLPARAMETER_VALUE);
		JSONArray urlParamArr = parseUrlparamValues(urlParamStr);
		
		String userType = null;
		Boolean isNewVisitor = Boolean.parseBoolean(inpuths.get(ReportRawDataConstants.IS_NEW_VISITOR));
		JSONArray cookieArr = new JSONArray();
		JSONArray jsVariableArr = new JSONArray();
		JSONArray customDimensionArr = new JSONArray();
		
		userType = isNewVisitor?"NEW":"RETURNING"; //No I18N
		
		//Get country details from IP Address
		JSONObject ipDetailsJson = ZABUtil.getIpAddressDetails(ipaddress);
		//Used hyphen since the api returns hyphen if ip is invalid kinda scenarios
		country = ipDetailsJson.has("COUNTRY_NAME") ? ipDetailsJson.get("COUNTRY_NAME").toString() : "-"; //NO I18N
		if(StringUtils.isEmpty(country) || country.equals("-"))
		{
			country = ReportRawDataConstants.UNKNOWN_VALUE;
		}
		country = country.toUpperCase();
		//Get city details
		city = ipDetailsJson.has("CITY") ? ipDetailsJson.get("CITY").toString() : "-"; //NO I18N
		if(StringUtils.isEmpty(city) || city.equals("-"))
		{
			city = ReportRawDataConstants.UNKNOWN_VALUE;
		}
		city = city.toUpperCase();
		//Get region details
		region = ipDetailsJson.has("REGION") ? ipDetailsJson.get("REGION").toString() : "-"; //NO I18N
		if(StringUtils.isEmpty(region) || region.equals("-"))
		{
			region = ReportRawDataConstants.UNKNOWN_VALUE;
		}
		region = region.toUpperCase();
		
		if(inpuths.containsKey(ReportRawDataConstants.DYNAMICATTRIBUTES)){
		      JSONArray dynamicAttributeAray = new JSONArray(inpuths.get(ReportRawDataConstants.DYNAMICATTRIBUTES));
		       Integer cookieCode =DynamicAttributeType.COOKIE.getAttributeTypeCode();
		       Integer jsVariableCode =DynamicAttributeType.JSVARIABLE.getAttributeTypeCode();
		       Integer customDimensionCode =DynamicAttributeType.CUSTOMDIMENSION.getAttributeTypeCode();
		       
		       HashMap<String,DynamicAttributes> dynamicAttriHs =  DynamicAttributes.getDynamicAttributesOfExperiment(inpuths.get(ReportRawDataConstants.EXPERIMENT_ID));
		       
		       for(int i=0;i<dynamicAttributeAray.length();i++){
		    	   JSONObject dynamicAttribute = (JSONObject)dynamicAttributeAray.get(i);
		    	   String attributeLinkName =(String) dynamicAttribute.get(ReportRawDataConstants.ATTRIBUTE_LINK_NAME);
		    	   if(dynamicAttriHs.containsKey(attributeLinkName)){
		    		   Integer attributeType =(Integer) dynamicAttribute.get(ReportRawDataConstants.ATTRIBUTE_TYPE);
			    	   String attributeValue =(String) dynamicAttribute.get(ReportRawDataConstants.ATTRIBUTE_VALUE);
			    	   JSONObject daObject = new JSONObject();
			    	   daObject.put(ElasticSearchConstants.NAME, attributeLinkName);
			    	   daObject.put(ElasticSearchConstants.VALUE, attributeValue);
			    	   if(attributeType.equals(cookieCode)){
			    		   cookieArr.put(daObject);
			    	   }else if(attributeType.equals(jsVariableCode)){
			    		   jsVariableArr.put(daObject);
			    	   }else if(attributeType.equals(customDimensionCode)){
			    		   customDimensionArr.put(daObject);
			    	   }
			    	   
			    	   dynamicAttriHs.remove(attributeLinkName);
		    	   }
		    	   
		       }
		       // DYNAMIC ATTRIBUTES WHICK ARE NOT SENT IN REQUEST ARE FILLED WITH 'UNKNOWN'
		       
		       Set<String> keySet = dynamicAttriHs.keySet();
		       Iterator<String> keysItr = keySet.iterator();
		       while(keysItr.hasNext()){
		    	  String attributeLinkName  =  keysItr.next();
		    	  DynamicAttributes da = dynamicAttriHs.get(attributeLinkName);
		    	  Integer attributeType = da.getAttributeType();	
		    	  String attributeValue = ReportRawDataConstants.UNKNOWN_VALUE;
		    	  JSONObject daObject = new JSONObject();
		    	  daObject.put(ElasticSearchConstants.NAME, attributeLinkName);
		    	  daObject.put(ElasticSearchConstants.VALUE, attributeValue);
		    	  if(attributeType.equals(cookieCode)){
		    		   cookieArr.put(daObject);
		    	   }else if(attributeType.equals(jsVariableCode)){
		    		   jsVariableArr.put(daObject);
		    	   }else if(attributeType.equals(customDimensionCode)){
		    		   customDimensionArr.put(daObject);
		    	   }
			    	 
		       }
		    }
		if(inpuths.containsKey(ReportRawDataConstants.EXPERIMENT_ID)){
			resultJson.put(ElasticSearchConstants.EXPERIMENTID, Long.parseLong(inpuths.get(ReportRawDataConstants.EXPERIMENT_ID)));
		}
		if(inpuths.containsKey(ReportRawDataConstants.HEATMAP_ENABLED)){
			resultJson.put(ElasticSearchConstants.IS_HEATMAP_ENABLED, inpuths.get(ReportRawDataConstants.HEATMAP_ENABLED));
		}
		if(inpuths.containsKey(ReportRawDataConstants.VARIATION_ID)){
			resultJson.put(ElasticSearchConstants.VARIATIONID, Long.parseLong(inpuths.get(ReportRawDataConstants.VARIATION_ID)));
		}
		if(inpuths.containsKey(GoalConstants.GOAL_ID)){
			resultJson.put(ElasticSearchConstants.GOALID, Long.parseLong(inpuths.get(GoalConstants.GOAL_ID)));
			if(inpuths.containsKey(ReportRawDataConstants.REVENUE_VALUE)){
				resultJson.put(ElasticSearchConstants.REVENUE, Long.parseLong(inpuths.get(ReportRawDataConstants.REVENUE_VALUE)));
			}
		}
		if(inpuths.containsKey(ProjectConstants.PROJECT_ID)){
			resultJson.put(ElasticSearchConstants.PROJECTID, Long.parseLong(inpuths.get(ProjectConstants.PROJECT_ID)));
		}
		if(inpuths.containsKey(ReportRawDataConstants.TIME_SPENT)){
			resultJson.put(ElasticSearchConstants.TIME_SPENT, Long.parseLong(inpuths.get(ReportRawDataConstants.TIME_SPENT)));
		}
		if(inpuths.containsKey(CustomEventConstants.EVENT_ID)){
			resultJson.put(ElasticSearchConstants.EVENTID, Long.parseLong(inpuths.get(CustomEventConstants.EVENT_ID)));
		}
		if(inpuths.containsKey(ElasticSearchConstants.IS_PROJECT_GOAL)){
			resultJson.put(ElasticSearchConstants.IS_PROJECT_GOAL, Boolean.parseBoolean(inpuths.get(ElasticSearchConstants.IS_PROJECT_GOAL)));
		}
		
		resultJson.put(ElasticSearchConstants.UVID, userAgenths.get(ReportRawDataConstants.UVID));
		resultJson.put(ElasticSearchConstants.UAID, userAgenths.get(ReportRawDataConstants.UAID));
		resultJson.put(ElasticSearchConstants.UUID, userAgenths.get(ReportRawDataConstants.UUID));
//		Long visitorId = VisitorDetail.getVisitorId(userAgenths.get(ReportRawDataConstants.UUID));
//		resultJson.put(ElasticSearchConstants.VISITORID, visitorId);
		resultJson.put(ElasticSearchConstants.BROWSER, browser);
		resultJson.put(ElasticSearchConstants.DEVICE, device);
		resultJson.put(ElasticSearchConstants.COUNTRY, country);
		resultJson.put(ElasticSearchConstants.CITY, city);
		resultJson.put(ElasticSearchConstants.REGION, region);
		resultJson.put(ElasticSearchConstants.LANGUAGE, language);
		resultJson.put(ElasticSearchConstants.USERTYPE, userType);
		resultJson.put(ElasticSearchConstants.OS, os);
		resultJson.put(ElasticSearchConstants.TRAFFICSOURCE, trafficsource);
		resultJson.put(ElasticSearchConstants.REFFERERURL, refurl);
		resultJson.put(ElasticSearchConstants.CURRENTURL,currenturl);
		resultJson.put(ElasticSearchConstants.DAYOFWEEK, ZABUtil.getDayOfWeek(currentTime));  
		resultJson.put(ElasticSearchConstants.HOUROFDAY, ZABUtil.getHourOfDay(currentTime));  
		resultJson.put(ElasticSearchConstants.NCOOKIE, cookieArr );
		resultJson.put(ElasticSearchConstants.NURLPARAMETER,urlParamArr );
		resultJson.put(ElasticSearchConstants.NJSVARIABLE, jsVariableArr);
		resultJson.put(ElasticSearchConstants.NCUSTOMDIMENSION, customDimensionArr);
		resultJson.put(ElasticSearchConstants.TIME, currentTime);
		
		return resultJson;
		
	}
	
	public static JSONObject buildUpdateDataDetailsForElasticSearch(HashMap<String,String> inpuths) throws Exception
	{
		JSONObject docJson = new JSONObject();
		JSONArray customDimensionArr = new JSONArray();
		try
		{
			if(inpuths.containsKey(ReportRawDataConstants.DYNAMICATTRIBUTES)){
				JSONArray dynamicAttributeAray = new JSONArray(inpuths.get(ReportRawDataConstants.DYNAMICATTRIBUTES));
				HashMap<String,DynamicAttributes> dynamicAttriHs =  DynamicAttributes.getCustomDimensionOfExperiment(inpuths.get(ReportRawDataConstants.EXPERIMENT_ID));
				for(int i=0;i<dynamicAttributeAray.length();i++){
		    	   JSONObject dynamicAttribute = (JSONObject)dynamicAttributeAray.get(i);
		    	   String attributeLinkName =(String) dynamicAttribute.get(ReportRawDataConstants.ATTRIBUTE_LINK_NAME);
		    	   if(dynamicAttriHs.containsKey(attributeLinkName)){
			    	   String attributeValue =(String) dynamicAttribute.get(ReportRawDataConstants.ATTRIBUTE_VALUE);
			    	   Long attributeId = dynamicAttriHs.get(attributeLinkName).getDynamicAttributeId();
		    		   Dimension.getDynamicAttributeCodeByValue(attributeId,attributeValue);

			    	   JSONObject jsonObj = new JSONObject();
			    	   jsonObj.put(ElasticSearchConstants.NAME, attributeLinkName);
			    	   jsonObj.put(ElasticSearchConstants.VALUE, attributeValue);
			    	   customDimensionArr.put(jsonObj);
		    	   }
		       }
			}
			
		}
		catch(Exception ex)
		{
			customDimensionArr = new JSONArray();
		}
		try{
			if(inpuths.containsKey(ReportRawDataConstants.TIME_SPENT)){
				Long time_spent = Long.parseLong(inpuths.get(ReportRawDataConstants.TIME_SPENT));
				docJson.put(ElasticSearchConstants.TIME_SPENT, time_spent);
				
			}
			
		}catch(Exception e){
			LOGGER.log(Level.SEVERE,"Exception occurred during ES Time Spent processing");
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		docJson.put(ElasticSearchConstants.NCUSTOMDIMENSION, customDimensionArr);
		return docJson;
	}

}
