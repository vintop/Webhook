//$Id$
package com.zoho.abtest.report;

import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.goal.Goal;
import com.zoho.abtest.listener.IPRestrictionData;
import com.zoho.abtest.listener.ZABListener;
import com.zoho.mqueue.consumer.MessageListener;

public class VisitorRawDataListener extends ZABListener implements MessageListener<String, String>{

	private static final Logger LOGGER = Logger.getLogger(VisitorRawDataListener.class.getName());

	@Override
	public void consumeMessage(Object obj) throws Exception {
		try {			
			if(obj!=null) {
				VisitorRawDataWrapper wrapper = (VisitorRawDataWrapper)obj;
				VisitorRawDataHandler.addVisitorRawdata(wrapper);
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			throw new Exception(e);
		}
	}

	@Override
	public IPRestrictionData getIPRestrictionData(Object message) throws ZABException {
		VisitorRawDataWrapper wrapper = (VisitorRawDataWrapper)message;
		
		//TODO: Confirm with Nekshan and Ram that only one experiment data will be sent in visitor raw data
		//Assuming that only one will be there the below implementation continues.
		if(wrapper.getExperimentsData().size() > 0) {
			HashMap<String, String> hs = wrapper.getExperimentsData().get(0);
			String portal = hs.get(ReportRawDataConstants.PORTAL);
			setDBSpace(portal);
			Long projectId = null;
			String experimentKey = hs.get(ReportRawDataConstants.EXPERIMENT_KEY);
			if(experimentKey == null){
				String goalLinkName = hs.get(ReportRawDataConstants.GOAL_LINK_NAME);
				projectId = Goal.getProjectIdFromGoalLinkname(goalLinkName);
				LOGGER.log(Level.INFO, "Getting IP Address from visitor raw data for project goal:"+goalLinkName+", "+projectId+", ****");
				
			}else{
				 projectId = Experiment.getProjectIdByExperimentKey(experimentKey);
				LOGGER.log(Level.INFO, "Getting IP Address from visitor raw data:"+experimentKey+", "+projectId+", "+ wrapper.getIpAddress());
					
			}
			return new IPRestrictionData(portal, projectId, wrapper.getIpAddress());
		}
		return null;
	}

}
