//$Id$
package com.zoho.abtest.report;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.opensymphony.xwork2.ActionSupport;
import com.zoho.abtest.audience.Audience;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.elastic.ElasticSearchStatistics;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.listener.ZABNotifier;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.abtest.variation.Variation;

public class ReportAction extends ActionSupport implements ServletResponseAware, ServletRequestAware{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private HttpServletRequest request;
	private HttpServletResponse response;
	private String experimentLinkName ;
	private static final Logger LOGGER = Logger.getLogger(ReportAction.class.getName());
	
	public void setServletRequest(HttpServletRequest arg0) {
		request = arg0;
	}


	public void setServletResponse(HttpServletResponse arg0) {
		response = arg0;
	}
	
	public String getExperimentLinkName() {
		return experimentLinkName;
	}

	public void setExperimentLinkName(String experimentLinkName) {
		this.experimentLinkName = experimentLinkName;
		request.setAttribute(ExperimentConstants.EXPERIMENT_LINKNAME, experimentLinkName);
	}


	public String execute() throws IOException, JSONException 
	{
		
		ArrayList<ReportStatistics> visitorReports = new ArrayList<ReportStatistics>();
		HashMap<String,String> hs;
		try {			
		
			switch(ZABAction.getHTTPMethod(request)) {
			case POST:	

				
				hs = ZABAction.getRequestParser(request).parseReport(request);

				if(hs.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					ReportStatistics report = new ReportStatistics();
					report.setSuccess(Boolean.FALSE);
					report.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
					visitorReports.add(report);
					LOGGER.log(Level.SEVERE,hs.get(ZABConstants.RESPONSE_STRING));
				}else{
					visitorReports.addAll(ReportStatistics.getReportInformation(hs));
				}

				break;

			}
		} catch(Exception ex){
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), CumulativeReportConstants.API_MODULE));
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
			return null; 	
		}		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getReportResponse(request, visitorReports));		
	    
		return null;
	}
	
	public String getOverviewReport() throws IOException, JSONException 
	{
		
		ArrayList<ReportStatistics> visitorReports = new ArrayList<ReportStatistics>();
		try {			
			visitorReports.addAll(ReportStatistics.overviewReport(experimentLinkName));
				
		} catch(Exception ex){
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), CumulativeReportConstants.API_MODULE));
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
			return null; 	
		}		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getReportResponse(request, visitorReports));		
		return null;
	}
	
	public String getElasticOverviewReport() throws IOException, JSONException 
	{
		
		ArrayList<ReportStatistics> visitorReports = new ArrayList<ReportStatistics>();
		try {			
			visitorReports.addAll(ElasticSearchStatistics.getOverviewReport(experimentLinkName));
				
		} catch(Exception ex){
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), CumulativeReportConstants.API_MODULE));
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
			return null; 	
		}		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getReportResponse(request, visitorReports));		
		return null;
	}
	
	public String getElasticReport() throws IOException, JSONException 
	{
		
		ArrayList<ReportStatistics> visitorReports = new ArrayList<ReportStatistics>();
		HashMap<String,String> hs;
		try {			
		
			switch(ZABAction.getHTTPMethod(request)) {
			case POST:	

				hs = ZABAction.getRequestParser(request).parseReport(request);

				if(hs.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					ReportStatistics report = new ReportStatistics();
					report.setSuccess(Boolean.FALSE);
					report.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
					visitorReports.add(report);
					LOGGER.log(Level.SEVERE,hs.get(ZABConstants.RESPONSE_STRING));
				}else{
					//TODO ES
					visitorReports.addAll(ElasticSearchStatistics.getReportInformation(hs));
				}
				break;
			}
		} catch(Exception ex){
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), CumulativeReportConstants.API_MODULE));
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
			return null; 	
		}		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getReportResponse(request, visitorReports));		
	    
		return null;
	}
	
	public String getDataPointReportDetails() throws IOException, JSONException 
	{
		ArrayList<ChartReport> charts = new ArrayList<ChartReport>();
		
		try {			
			switch(ZABAction.getHTTPMethod(request)) {
			case POST:	
				HashMap<String,String> hs;
				hs = ZABAction.getRequestParser(request).parseReport(request);

				if(hs.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					ChartReport report = new ChartReport();
					report.setSuccess(Boolean.FALSE);
					report.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
					charts.add(report);
					LOGGER.log(Level.SEVERE,hs.get(ZABConstants.RESPONSE_STRING));
				}else{
					charts.addAll(ChartReport.getDataPointReportInformation(hs));
				}

				break;

			}
		} catch(Exception ex){
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), CumulativeReportConstants.API_MODULE));
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
			return null; 	
		}		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getChartRpeortResponse(request, charts));		
	   
		return null;
	}
	
	public String getDataPointElasticReportDetails() throws IOException, JSONException 
	{
		ArrayList<ChartReport> charts = new ArrayList<ChartReport>();
		
		try {			
			switch(ZABAction.getHTTPMethod(request)) {
			case POST:	
				HashMap<String,String> hs;
				hs = ZABAction.getRequestParser(request).parseReport(request);

				if(hs.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					ChartReport report = new ChartReport();
					report.setSuccess(Boolean.FALSE);
					report.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
					charts.add(report);
					LOGGER.log(Level.SEVERE,hs.get(ZABConstants.RESPONSE_STRING));
				}else{
					//TODO ES
					charts.addAll(ElasticsearchChartReport.getDatapointReportInformation(hs));
				}

				break;

			}
		} catch(Exception ex){
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), CumulativeReportConstants.API_MODULE));
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
			return null; 	
		}		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getChartRpeortResponse(request, charts));		
	   
		return null;
	}
	 
	
	public static void testRawTableWorking(){
		ArrayList<HashMap<String,String>> mapArray = new ArrayList<HashMap<String,String>>();
		
		
		String value = "{dv=Desktop, tv=DIRECT, cv=http://scripty11.blogspot.in, bv=Chrome, rv=UNKNOWN, d=1502185083442zabv0.6490781295853254, f=1502185083442zabu0.4937646559547264, srv=1440x900, ov=MacOS, lv=en-US, mdv=UNKNOWN}";// NO I18N
		value = value.substring(1, value.length()-1);           //remove curly brackets
		String[] keyValuePairs = value.split(",");              //split the string to creat key-value pairs
		HashMap<String,String> userAgenths = new HashMap<>();               

		for(String pair : keyValuePairs)                        //iterate over the pairs
		{
		    String[] entry = pair.split("=");                   //split the pairs to get key and value 
		    userAgenths.put(entry[0].trim(), entry[1]);          //add them to the hashmap and trim whitespaces
		}
		
		String expstring = "{a=abi2, b=713976ed9b344c02a7f36f461143f5a7, c=b5d5f4fc85a24accb546c495d5c86c9f, da=[], n=true,ts=100}";	// NO I18N
		expstring = expstring.substring(1, expstring.length()-1);           //remove curly brackets
		keyValuePairs = expstring.split(",");              //split the string to creat key-value pairs
		HashMap<String,String> mapArrayhs = new HashMap<>();               

		for(String pair : keyValuePairs)                        //iterate over the pairs
		{
		    String[] entry = pair.split("=");                   //split the pairs to get key and value 
		    mapArrayhs.put(entry[0].trim(), entry[1]);          //add them to the hashmap and trim whitespaces
		}
		mapArray.add(mapArrayhs);
		
		VisitorRawDataWrapper wrapper = new VisitorRawDataWrapper();
		wrapper.setUserAgenths(userAgenths);
		wrapper.setExperimentsData(mapArray);
		LOGGER.log(Level.INFO,"!!! Raw Data Received: {}",wrapper);
		ZABNotifier.notifyListeners(ReportRawDataConstants.VRAW_DATA_NOTIFIER_NAME, wrapper);
	}
	

}