//$Id$
package com.zoho.abtest.report;

import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.abtest.RAW_DATA_TABLE_DETAILS;

public class RawDataTableDetails extends ZABModel{

	private static final Logger LOGGER = Logger.getLogger(RawDataTableDetails.class.getName());
	private static final long serialVersionUID = 1L;
	
	private Long rawDataTableDetailsId;
	private String rawTableName;
	private Integer moduleType;
	private Boolean isActive;
	
	public String getRawTableName() {
		return rawTableName;
	}
	public void setRawTableName(String rawTableName) {
		this.rawTableName = rawTableName;
	}
	public Integer getModuleType() {
		return moduleType;
	}
	public void setModuleType(Integer moduleType) {
		this.moduleType = moduleType;
	}
	public Long getRawDataTableDetailsId() {
		return rawDataTableDetailsId;
	}
	public void setRawDataTableDetailsId(Long rawDataTableDetailsId) {
		this.rawDataTableDetailsId = rawDataTableDetailsId;
	}
	public Boolean getIsActive() {
		return isActive;
	}
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	
	public static void addActiveRawDataTableEntry(HashMap<String, String> hs) throws Exception
	{
		try
		{
			Integer moduleType = Integer.parseInt(hs.get(ReportRawDataConstants.MODULE_TYPE));
			updateOldRawDataTableStatus(moduleType);
			hs.put(ReportRawDataConstants.IS_ACTIVE,Boolean.TRUE.toString());
			ZABModel.createRow(ReportRawDataConstants.RAW_DATA_TABLE_DETAILS_CONSTANTS, RAW_DATA_TABLE_DETAILS.TABLE, hs);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			throw ex;
		}
	}
	
	public static void updateOldRawDataTableStatus(Integer moduleType) throws Exception
	{
		try
		{
			Criteria criteria1 = new Criteria(new Column(RAW_DATA_TABLE_DETAILS.TABLE,RAW_DATA_TABLE_DETAILS.MODULE_TYPE), moduleType, QueryConstants.EQUAL);
			Criteria criteria2 = new Criteria(new Column(RAW_DATA_TABLE_DETAILS.TABLE,RAW_DATA_TABLE_DETAILS.IS_ACTIVE), Boolean.TRUE, QueryConstants.EQUAL);
			
			Boolean isResourceExists = ZABModel.resourceExists(RAW_DATA_TABLE_DETAILS.TABLE, criteria1.and(criteria2));
			
			if(isResourceExists)
			{
				HashMap<String, String> hs = new HashMap<String, String>();
				hs.put(ReportRawDataConstants.IS_ACTIVE,Boolean.FALSE.toString());
				ZABModel.updateRow(ReportRawDataConstants.RAW_DATA_TABLE_DETAILS_CONSTANTS, RAW_DATA_TABLE_DETAILS.TABLE, hs, criteria1.and(criteria2), null);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			throw ex;
		}
	}
	
	public static void deleteUnusedRawtableDetails(String rawTableName) throws Exception
	{
		try
		{
			Criteria criteria = new Criteria(new Column(RAW_DATA_TABLE_DETAILS.TABLE,RAW_DATA_TABLE_DETAILS.RAW_TABLE_NAME),rawTableName,QueryConstants.EQUAL,Boolean.FALSE);
			ZABModel.deleteRow(RAW_DATA_TABLE_DETAILS.TABLE, criteria, ReportRawDataConstants.RAW_TABLE_MODULE);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
	}
	
	public static RawDataTableDetails getActiveRawDataTable(Integer moduleType)
	{
		RawDataTableDetails activeRawDataTableDetail = null;
		try
		{
			Criteria criteria1 = new Criteria(new Column(RAW_DATA_TABLE_DETAILS.TABLE,RAW_DATA_TABLE_DETAILS.MODULE_TYPE), moduleType, QueryConstants.EQUAL);
			Criteria criteria2 = new Criteria(new Column(RAW_DATA_TABLE_DETAILS.TABLE,RAW_DATA_TABLE_DETAILS.IS_ACTIVE), Boolean.TRUE, QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(RAW_DATA_TABLE_DETAILS.TABLE, criteria1.and(criteria2));
			Iterator<?> iterator = dataObj.getRows(RAW_DATA_TABLE_DETAILS.TABLE);
			if(iterator.hasNext())
			{
				Row row = (Row) iterator.next();
				activeRawDataTableDetail = getRawDataTableDetailFromRow(row);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			activeRawDataTableDetail = new RawDataTableDetails();
		}
		return activeRawDataTableDetail;
	}
	
	public static HashMap<Integer, String> getAllActiveRawTables()
	{
		HashMap<Integer, String> hs = new HashMap<Integer, String>();
		try
		{
			
			Criteria criteria1 = new Criteria(new Column(RAW_DATA_TABLE_DETAILS.TABLE,RAW_DATA_TABLE_DETAILS.IS_ACTIVE), Boolean.TRUE, QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(RAW_DATA_TABLE_DETAILS.TABLE, criteria1);
			Iterator<?> iterator = dataObj.getRows(RAW_DATA_TABLE_DETAILS.TABLE);
			while(iterator.hasNext())
			{
				Row row = (Row) iterator.next();
				Integer moduleType = (Integer)row.get(RAW_DATA_TABLE_DETAILS.MODULE_TYPE);
				String rawTableName = (String)row.get(RAW_DATA_TABLE_DETAILS.RAW_TABLE_NAME);
				hs.put(moduleType, rawTableName);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			hs = new HashMap<Integer, String>();
		}
		return hs;
	}
	
	public static RawDataTableDetails getRawDataTableDetailFromRow(Row row)
	{
		RawDataTableDetails rawDataTableDetail = new RawDataTableDetails();
		rawDataTableDetail.setRawDataTableDetailsId((Long)row.get(RAW_DATA_TABLE_DETAILS.RAW_DATA_TABLE_DETAILS_ID));
		rawDataTableDetail.setRawTableName((String)row.get(RAW_DATA_TABLE_DETAILS.RAW_TABLE_NAME));
		rawDataTableDetail.setModuleType((Integer)row.get(RAW_DATA_TABLE_DETAILS.MODULE_TYPE));
		rawDataTableDetail.setIsActive((Boolean)row.get(RAW_DATA_TABLE_DETAILS.IS_ACTIVE));
		return rawDataTableDetail;
	}
	
}
