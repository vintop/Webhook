//$Id$
package com.zoho.abtest.report;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;

import com.adventnet.mfw.bean.BeanUtil;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.dimension.DynamicAttributes;
import com.zoho.abtest.experiment.ABSplitExperiment;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentStatus;
import com.zoho.abtest.goal.Goal;
import com.zoho.abtest.goal.GoalConstants.GoalType;
import com.zoho.abtest.ml.MLConstants;
import com.zoho.abtest.ml.MachineLearningUtil;
import com.zoho.abtest.revenue.RevenueChartReport;
import com.zoho.abtest.revenue.RevenueConstants;
import com.zoho.abtest.revenue.RevenueReport;
import com.zoho.abtest.revenue.ZABRevenueChartBean;
import com.zoho.abtest.utility.ZABChartBean;
import com.zoho.abtest.utility.ZABUserBean;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.abtest.variation.Variation;

public class ChartReport extends ZABModel {

	private Long goalId;
	private Long variationId;
	private String goalLinkName ;
	private String variationLinkName;

	private HashMap<Long, Double> conversionRate =  new HashMap<Long,Double>();
	private HashMap<Long, Double> statisticalSignificance =  new HashMap<Long,Double>();
	private HashMap<Long, Double> improvement =  new HashMap<Long,Double>();
	private HashMap<Long, Long> visitors  =  new HashMap<Long,Long>();
	private HashMap<Long, Long> conversions =  new HashMap<Long,Long>();


	private HashMap<Long, Double> cumulativeconversionRate =  new HashMap<Long,Double>();
	private HashMap<Long, Double> cumulativeimprovement =  new HashMap<Long,Double>();
	private HashMap<Long, Long> cumulativevisitors  =  new HashMap<Long,Long>();
	private HashMap<Long, Long> cumulativeconversions =  new HashMap<Long,Long>();
	
	
	private HashMap<Long, Double> forecastconversionRate =  new HashMap<Long,Double>();
	private HashMap<Long, Double> forecastimprovement =  new HashMap<Long,Double>();
	private HashMap<Long, Long> forecastvisitors  =  new HashMap<Long,Long>();
	private HashMap<Long, Long> forecastconversions =  new HashMap<Long,Long>();
	private HashMap<Long, Double> forecastsignificance =  new HashMap<Long,Double>();
	
	
	private RevenueChartReport revenueChart ;

	private HashMap<Long, Long> avgTime =  new HashMap<Long,Long>();
	
	private Boolean isPredicted;
	
	private static final Logger LOGGER = Logger.getLogger(ChartReport.class.getName());

	private static final long serialVersionUID = 1L;
	
	public Boolean getIsPredicted() {
		return isPredicted;
	}

	public void setIsPredicted(Boolean isPredicted) {
		this.isPredicted = isPredicted;
	}

	
	public HashMap<Long, Double> getForecastconversionRate() {
		return forecastconversionRate;
	}

	public void setForecastconversionRate(
			HashMap<Long, Double> forecastconversionRate) {
		this.forecastconversionRate = forecastconversionRate;
	}

	public HashMap<Long, Double> getForecastimprovement() {
		return forecastimprovement;
	}

	public void setForecastimprovement(HashMap<Long, Double> forecastimprovement) {
		this.forecastimprovement = forecastimprovement;
	}

	public HashMap<Long, Long> getForecastvisitors() {
		return forecastvisitors;
	}

	public void setForecastvisitors(HashMap<Long, Long> forecastvisitors) {
		this.forecastvisitors = forecastvisitors;
	}

	public HashMap<Long, Long> getForecastconversions() {
		return forecastconversions;
	}

	public void setForecastconversions(HashMap<Long, Long> forecastconversions) {
		this.forecastconversions = forecastconversions;
	}

	public HashMap<Long, Double> getForecastsignificance() {
		return forecastsignificance;
	}

	public void setForecastsignificance(HashMap<Long, Double> forecastsignificance) {
		this.forecastsignificance = forecastsignificance;
	}

	
	public HashMap<Long, Double> getCumulativeconversionRate() {
		return cumulativeconversionRate;
	}

	public void setCumulativeconversionRate(
			HashMap<Long, Double> cumulativeconversionRate) {
		this.cumulativeconversionRate = cumulativeconversionRate;
	}


	public HashMap<Long, Double> getCumulativeimprovement() {
		return cumulativeimprovement;
	}

	public void setCumulativeimprovement(HashMap<Long, Double> cumulativeimprovement) {
		this.cumulativeimprovement = cumulativeimprovement;
	}

	public HashMap<Long, Long> getCumulativevisitors() {
		return cumulativevisitors;
	}

	public void setCumulativevisitors(HashMap<Long, Long> cumulativevisitors) {
		this.cumulativevisitors = cumulativevisitors;
	}

	public HashMap<Long, Long> getCumulativeconversions() {
		return cumulativeconversions;
	}

	public void setCumulativeconversions(HashMap<Long, Long> cumulativeconversions) {
		this.cumulativeconversions = cumulativeconversions;
	}

	public HashMap<Long, Long> getVisitors() {
		return visitors;
	}

	public void setVisitors(HashMap<Long, Long> visitors) {
		this.visitors = visitors;
	}

	public HashMap<Long, Long> getConversions() {
		return conversions;
	}

	public void setConversions(HashMap<Long, Long> conversions) {
		this.conversions = conversions;
	}

	public Long getGoalId() {
		return goalId;
	}

	public void setGoalId(Long goalId) {
		this.goalId = goalId;
	}

	public Long getVariationId() {
		return variationId;
	}

	public void setVariationId(Long variationId) {
		this.variationId = variationId;
	}

	public HashMap<Long, Double> getConversionRate() {
		return conversionRate;
	}

	public void setConversionRate(HashMap<Long, Double> conversionRate) {
		this.conversionRate = conversionRate;
	}

	public HashMap<Long, Double> getStatisticalSignificance() {
		return statisticalSignificance;
	}

	public void setStatisticalSignificance(
			HashMap<Long, Double> statisticalSignificance) {
		this.statisticalSignificance = statisticalSignificance;
	}


	public HashMap<Long, Double> getImprovement() {
		return improvement;
	}

	public void setImprovement(HashMap<Long, Double> improvement) {
		this.improvement = improvement;
	}

	public String getGoalLinkName() {
		return goalLinkName;
	}

	public void setGoalLinkName(String goalLinkName) {
		this.goalLinkName = goalLinkName;
	}

	public String getVariationLinkName() {
		return variationLinkName;
	}

	public void setVariationLinkName(String variationLinkName) {
		this.variationLinkName = variationLinkName;
	}

	public RevenueChartReport getRevenueChart() {
		return revenueChart;
	}

	public void setRevenueChart(RevenueChartReport revenueChart) {
		this.revenueChart = revenueChart;
	}
	
	public HashMap<Long, Long> getAvgTime() {
		return avgTime;
	}

	public void setAvgTime(HashMap<Long, Long> avgTime) {
		this.avgTime = avgTime;
	}

	

	public static ArrayList<ChartReport> getDataPointReportInformation(HashMap<String,String> hs) throws Exception
	{
		ArrayList<ChartReport> reports = new ArrayList<ChartReport>();
		try{

			String experimentLinkNmae = hs.get(ExperimentConstants.EXPERIMENT_LINKNAME);
			Experiment exp  = Experiment.getExperimentByLinkname(experimentLinkNmae);
			if(exp == null){
				LOGGER.log(Level.SEVERE, "Experiment with linkname " +experimentLinkNmae+" does not exist");
				ChartReport report = new ChartReport();
				report.setSuccess(Boolean.FALSE);
				reports.add(report);
				return reports;

			}
			Long experimentId = exp.getExperimentId();
			Long goalId = null;
			String goalLinkName = hs.get(ReportConstants.GOAL_LINK_NAME);
			if(StringUtils.isNotEmpty(goalLinkName))
			{
				goalId = Goal.getGoalIdForGoal(goalLinkName);
			}
			String segmentType= hs.get(ReportConstants.SEGMENT_TYPE);
			String reportType = hs.get(ReportConstants.REPORT_TYPE);
			String dynamicAttrLinkName = hs.get(ReportConstants.DYNAMIC_ATTRIBUTE_LINK_NAME);
			String startTime = hs.get(ReportConstants.START_DATE);
			String  endTime = hs.get(ReportConstants.END_DATE);
			String multisegmentCriteria = hs.get(ReportConstants.MULTISEGMENT_CRITERIA);
			Long startTimeInMillis = null;
			if(startTime!=null&&!startTime.isEmpty()){
				startTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(startTime, "yyyy-MM-dd");		// NO I18N
			}

			Long endTimeInMillis = null;
			if(endTime!=null&&!endTime.isEmpty()){
				endTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(endTime, "yyyy-MM-dd");		// NO I18N
			}

			Integer[] valueArray = null;
			String baseLine = hs.get(ReportConstants.BASELINE);
			String values = hs.get(ReportConstants.VALUES);


			if(values != null)
			{
				JSONArray array  =new JSONArray(values);
				valueArray = new Integer[array.length()];

				for(int i=0;i<array.length();i++){
					valueArray[i] = Integer.parseInt(array.getString(i));
				}
			}

			reports = getDataPointReportDetails(reportType,segmentType,experimentId,valueArray,startTimeInMillis,endTimeInMillis,dynamicAttrLinkName,multisegmentCriteria, baseLine,goalId);


		}catch(Exception ex ){
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);

		}
		return reports;

	}

	public static ArrayList<ChartReport> getDataPointReportDetails(String reportType, String segmentType, Long expId, Integer[] segmentValueCodes, Long startTime, Long endTime,String dynamicAttrLinkName,String multisegmentCriteria, String baseLine,Long goalid) throws Exception{


		ArrayList<ChartReport> resultReport = new ArrayList<ChartReport>();
		HashMap<Long, HashMap<Long, HashMap<String, Long>>> visitorMeta = null;
		HashMap<Long, HashMap<Long, HashMap<Long, HashMap<String, Long>>>> goalMeta = null;
		HashMap<String, HashMap<String, String>> revenueMeta  = null; 
		Long revenueGoalId = ABSplitExperiment.getRevenueGoalOfExperiment(expId);
		
		ArrayList<Long> timePoints = new ArrayList<Long>();

		Long dynamicAttrId = null;
		try
		{
			boolean isHourBasedData = false;

			long currentTime = ZABUtil.getCurrentTimeInMilliSeconds();
			/*boolean isLatestInforequired = false;
			boolean isCombinedTableInforequired = false;

			long currentTime = ZABUtil.getCurrentTimeInMilliSeconds();
			long currentDateInLong = ZABUtil.getDateInLongFromTime(currentTime);


			if(endTime.equals(currentDateInLong))
			{
				isLatestInforequired =true;
				isCombinedTableInforequired = true;
				if(startTime.equals(endTime))
				{
					isCombinedTableInforequired = false;
				}
			}
			long currentDateInterval = ZABUtil.getInterval(startTime, currentDateInLong, TimeUnit.DAYS);
			int hourTableDuration = Configuration.getInteger("max.hourreporttable.duration"); //No I18N
			 */
			Experiment experiment = Experiment.getExperimentById(expId);
			Long expActualStartTime = experiment.getActualStartTime();
			long hourStartTime = startTime + 1;
			long hourPointStartTime = hourStartTime;
			if(expActualStartTime != null && hourPointStartTime < expActualStartTime)
			{
				startTime = expActualStartTime;
				hourPointStartTime = ZABUtil.getNthHourInLong(expActualStartTime, 0);
			}
			
			long hourEndTime = ZABUtil.getNthDayDateInLong(endTime, 1);
			Integer expStatus = experiment.getExperimentStatus();
			Long expActualEndTime = experiment.getActualEndTime();
			if(ExperimentStatus.PAUSED.getStatusCode().equals(expStatus) && hourEndTime > expActualEndTime)
			{
				endTime = expActualEndTime;
				hourEndTime = ZABUtil.getNthHourInLong(endTime, 1);
			}
			
			long reportDateInterval = ZABUtil.getInterval(startTime, endTime, TimeUnit.DAYS);

			//check the data should be fetched as per hour or day
			//If 2 or less days fetch based on hours
			/*if(currentDateInterval < hourTableDuration && reportDateInterval <= 1)
			{
				isHourBasedData = true;
			}*/
			if(reportDateInterval < 23)
			{
				isHourBasedData = true;
			}
			

			//generate complete possible time points
			if(isHourBasedData)
			{
				int hourIndex = 1;
				long time = hourPointStartTime;
				while(time <= hourEndTime)
				{
					time = ZABUtil.getNthHourInLong(hourPointStartTime, hourIndex);
					if(time>currentTime)
					{
						break;
					}
					timePoints.add(time);
					hourIndex++;
				}
			}
			else
			{
				int dayIndex = 1;
				long time = startTime;
				time = ZABUtil.getNthDayDateInLong(startTime, 0);
				timePoints.add(time);
				while(endTime > time)
				{
					time = ZABUtil.getNthDayDateInLong(startTime, dayIndex);
					timePoints.add(time);
					dayIndex++;
				}
			}

			HashMap<Long, Long> destTimePointHs = new HashMap<Long, Long>();
			ArrayList<Long> desttimePoints = timePoints;
			
			if(isHourBasedData && reportDateInterval > 1)
			{
				desttimePoints = new ArrayList<Long>();
				int size = timePoints.size();
				int i = 0;
				long timePointConversionLength = reportDateInterval+1;
				while(i<size)
				{
					int j=i;
					long destTimePoint = timePoints.get(i);
					desttimePoints.add(destTimePoint);
					while(j < (i+timePointConversionLength) && j<size)
					{
						long sourceTimePoint = timePoints.get(j);
						destTimePointHs.put(sourceTimePoint, destTimePoint);
						j++;
					}
					i=j;
				}
			}
			
			if(reportType.equals(ReportConstants.MULTISEGMENT))
			{
				ZABChartBean chartBean = (ZABChartBean)BeanUtil.lookup("ZABChartBean", ZABUtil.getCurrentUserDbSpace());
				ZABUserBean userBean = (ZABUserBean)BeanUtil.lookup("ZABUserBean", ZABUtil.getCurrentUserDbSpace());
				HashMap<String, Object> multisegmentCriteriaHs = userBean.generateMultisegmentCriteria(multisegmentCriteria);
				/*if(isHourBasedData)
				{*/
				visitorMeta = chartBean.getDataPointMultiSegmentHourVisitorReportDetails(expId, hourStartTime, hourEndTime, multisegmentCriteriaHs);
				LOGGER.log(Level.INFO, "Chart Multisegment Visitor Meta Obtained");
				goalMeta = chartBean.getDataPointMultiSegmentHourGoalReportDetails(expId, hourStartTime, hourEndTime, multisegmentCriteriaHs,goalid);
				LOGGER.log(Level.INFO, "Chart Multisegment Goal Meta Obtained");			
				/*}*/
				/*else
				{
					visitorMeta = chartBean.getDataPointMultiSegmentVisitorReportDetails(expId, startTime, endTime, isLatestInforequired, isCombinedTableInforequired, multisegmentCriteriaHs);
					goalMeta = chartBean.getDataPointMultiSegmentGoalReportDetails(expId, startTime, endTime, isLatestInforequired, isCombinedTableInforequired, multisegmentCriteriaHs);
				}*/
			}
			else
			{
				HashMap<String, String> hs = ReportStatistics.getTableNames(reportType,segmentType);

				if(reportType.equals(ReportConstants.SEGMENT))
				{
					if(segmentType.equals(ReportConstants.URLPARAMETER) || segmentType.equals(ReportConstants.COOKIE) || segmentType.equals(ReportConstants.JSVARIABLE) || segmentType.equals(ReportConstants.CUSTOMDIMENSION))
					{
						dynamicAttrId = DynamicAttributes.getDynamicAttributesIdByLinkName(dynamicAttrLinkName);
					}
				}
				ZABChartBean userBean = (ZABChartBean)BeanUtil.lookup("ZABChartBean", ZABUtil.getCurrentUserDbSpace());
				/*if(isHourBasedData)
				{*/
				visitorMeta = userBean.getDataPointHourVisitorReportDetails(reportType, expId, segmentValueCodes, hourStartTime, hourEndTime, hs, dynamicAttrId);
				LOGGER.log(Level.INFO, "Chart Segment Visitor Meta Obtained");
				goalMeta = userBean.getDataPointHourGoalReportDetails(reportType, expId, segmentValueCodes, hourStartTime, hourEndTime, hs, dynamicAttrId,goalid);
				LOGGER.log(Level.INFO, "Chart Segment Goal Meta Obtained");			
				/*}*/
				/*else
				{
					visitorMeta = userBean.getDataPointVisitorReportDetails(isLatestInforequired,isCombinedTableInforequired, reportType, expId, segmentValueCodes, startTime, endTime, hs, dynamicAttrId);
					goalMeta = userBean.getDataPointGoalReportDetails(isLatestInforequired,isCombinedTableInforequired, reportType, expId, segmentValueCodes, startTime, endTime, hs, dynamicAttrId);
				}*/
			}
			boolean fetchRevenue = true;
			if(goalid != null && !goalid.equals(revenueGoalId))
			{
				fetchRevenue = false;
			}
			if(fetchRevenue && revenueGoalId!=null){
				ZABRevenueChartBean revenueBean = (ZABRevenueChartBean)BeanUtil.lookup("ZABRevenueChartBean", ZABUtil.getCurrentUserDbSpace());
				ZABUserBean userBean = (ZABUserBean)BeanUtil.lookup("ZABUserBean", ZABUtil.getCurrentUserDbSpace());
				
				if(reportType.equals(ReportConstants.SUMMARY))
				{
					revenueMeta = revenueBean.getDataPointHourGoalReportDetails( expId, hourStartTime, hourEndTime);

				}else if(reportType.equals(ReportConstants.SEGMENT)){
					JSONArray segmentjsonArray = new JSONArray(Arrays.asList(segmentValueCodes));
					String segmentCriteria = RevenueReport.converSegmentToMultiSegmentCriteira(segmentType, segmentjsonArray, dynamicAttrLinkName);
					HashMap<String, Object> multisegmentCriteriaHs = userBean.generateMultisegmentCriteria(segmentCriteria);
					revenueMeta = revenueBean.getDataPointMultiSegmentHourGoalReportDetails(expId, hourStartTime, hourEndTime, multisegmentCriteriaHs, revenueGoalId);

				}
				else if(reportType.equals(ReportConstants.MULTISEGMENT)){
					HashMap<String, Object> multisegmentCriteriaHs = userBean.generateMultisegmentCriteria(multisegmentCriteria);
					revenueMeta = revenueBean.getDataPointMultiSegmentHourGoalReportDetails(expId, hourStartTime, hourEndTime, multisegmentCriteriaHs, revenueGoalId);

				}
			}

			if(isHourBasedData && reportDateInterval > 1)
			{
				LOGGER.log(Level.INFO, "Timepoint Based Consolidation of Results");
				visitorMeta = ChartReport.convertVisitorHourEntriesToDestTimePoints(visitorMeta, destTimePointHs);
				goalMeta = ChartReport.convertGoalHourEntriesToDestTimePoints(goalMeta, destTimePointHs);
				visitorMeta = calculateCumulativeCountForVisitors(visitorMeta, desttimePoints);
				goalMeta = calculateCumulativeCountForGoal(goalMeta, desttimePoints);
			}
			else if(!isHourBasedData)
			{
				LOGGER.log(Level.INFO, "Day Based Consolidation of Results");
				visitorMeta = convertVisitorHourEntriesToDay(visitorMeta);
				goalMeta = convertGoalHourEntriesToDay(goalMeta);
                visitorMeta = calculateCumulativeCountForVisitors(visitorMeta, desttimePoints);
                goalMeta = calculateCumulativeCountForGoal(goalMeta, desttimePoints);
                revenueMeta = RevenueChartReport.convertRevenueGoalHourEntriesToDay(revenueMeta);
			}
        resultReport = chartCalculations(visitorMeta,goalMeta,expId,desttimePoints, baseLine,revenueMeta,revenueGoalId,goalid,null,null,endTime);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}

		return resultReport;

	}

	public static HashMap<Long, HashMap<Long, HashMap<String, Long>>> convertVisitorHourEntriesToDay(HashMap<Long, HashMap<Long, HashMap<String, Long>>> visitorMeta)
	{
		HashMap<Long, HashMap<Long, HashMap<String, Long>>> visitorDayMeta = new HashMap<Long, HashMap<Long, HashMap<String, Long>>>();

		//Convert to day START
		for(Map.Entry<Long, HashMap<Long, HashMap<String, Long>>> variationEntry:visitorMeta.entrySet())
		{
			Long variationId = variationEntry.getKey();
			HashMap<Long, HashMap<String, Long>> timeMap = variationEntry.getValue();
			HashMap<Long, HashMap<String, Long>> dayMap =  new HashMap<Long, HashMap<String, Long>>();
			for(Map.Entry<Long,HashMap<String, Long>> timeEntry:timeMap.entrySet())
			{
				Long time = timeEntry.getKey();
				HashMap<String, Long> valueHs = timeEntry.getValue();
				Long count = valueHs.get(ReportArchieveDimensionConstants.UNIQUE_COUNT);
				Long date = ZABUtil.getDateInLongFromTime(time);
				if(dayMap.containsKey(date))
				{
					HashMap<String, Long> dayValueHs = dayMap.get(date);
					dayValueHs.put(ReportArchieveDimensionConstants.UNIQUE_COUNT, dayValueHs.get(ReportArchieveDimensionConstants.UNIQUE_COUNT)+count);
				}
				else
				{
					HashMap<String, Long> dayValueHs = new HashMap<String, Long>();
					dayValueHs.put(ReportArchieveDimensionConstants.UNIQUE_COUNT, count);
					dayMap.put(date, dayValueHs);
				}
			}
			visitorDayMeta.put(variationId, dayMap);
		}
		//Convert to day END
		return visitorDayMeta;
	}
	
	public static HashMap<Long, HashMap<Long, HashMap<String, Long>>> convertVisitorHourEntriesToDestTimePoints(HashMap<Long, HashMap<Long, HashMap<String, Long>>> visitorMeta, HashMap<Long, Long> destTimePointHs)
	{
		HashMap<Long, HashMap<Long, HashMap<String, Long>>> visitorDayMeta = new HashMap<Long, HashMap<Long, HashMap<String, Long>>>();

		//Convert to destinated entries START
		for(Map.Entry<Long, HashMap<Long, HashMap<String, Long>>> variationEntry:visitorMeta.entrySet())
		{
			Long variationId = variationEntry.getKey();
			HashMap<Long, HashMap<String, Long>> timeMap = variationEntry.getValue();
			HashMap<Long, HashMap<String, Long>> destTimeMap =  new HashMap<Long, HashMap<String, Long>>();
			for(Map.Entry<Long,HashMap<String, Long>> timeEntry:timeMap.entrySet())
			{
				Long time = timeEntry.getKey();
				HashMap<String, Long> valueHs = timeEntry.getValue();
				Long count = valueHs.get(ReportArchieveDimensionConstants.UNIQUE_COUNT);
				Long destTime = destTimePointHs.get(time);
				if(destTimeMap.containsKey(destTime))
				{
					HashMap<String, Long> destValueHs = destTimeMap.get(destTime);
					destValueHs.put(ReportArchieveDimensionConstants.UNIQUE_COUNT, destValueHs.get(ReportArchieveDimensionConstants.UNIQUE_COUNT)+count);
				}
				else
				{
					HashMap<String, Long> destValueHs = new HashMap<String, Long>();
					destValueHs.put(ReportArchieveDimensionConstants.UNIQUE_COUNT, count);
					destTimeMap.put(destTime, destValueHs);
				}
			}
			visitorDayMeta.put(variationId, destTimeMap);
		}
		//Convert to destinated entries END
		return visitorDayMeta;
	}

	public static HashMap<Long, HashMap<Long, HashMap<String, Long>>> calculateCumulativeCountForVisitors(HashMap<Long, HashMap<Long, HashMap<String, Long>>> visitorDayMeta, ArrayList<Long> timePoints)
	{
		//calculate cumulative count entries START
		for(Map.Entry<Long, HashMap<Long, HashMap<String, Long>>> variationEntry:visitorDayMeta.entrySet())
		{
			HashMap<Long, HashMap<String, Long>> timeMap = variationEntry.getValue();
			long cumulativeCount = 0;
			for(Long time:timePoints)
			{
				if(timeMap.containsKey(time))
				{
					HashMap<String, Long> valueHs = timeMap.get(time);
					Long countValue = valueHs.get(ReportArchieveDimensionConstants.UNIQUE_COUNT);
					cumulativeCount = cumulativeCount+countValue;
					valueHs.put(ReportArchieveDimensionConstants.CUMULATIVE_COUNT, cumulativeCount);
				}
			}
		}
		//calculate cumulative count entries END
		return visitorDayMeta;
	}

	public static HashMap<Long, HashMap<Long, HashMap<Long, HashMap<String, Long>>>> convertGoalHourEntriesToDay(HashMap<Long, HashMap<Long, HashMap<Long, HashMap<String, Long>>>> goalMeta)
	{
		HashMap<Long, HashMap<Long, HashMap<Long, HashMap<String, Long>>>> goalDayMeta = new HashMap<Long, HashMap<Long, HashMap<Long, HashMap<String, Long>>>>();
		//Convert to day START
		for(Map.Entry<Long, HashMap<Long, HashMap<Long, HashMap<String, Long>>>> variationEntry:goalMeta.entrySet())
		{
			Long variationId = variationEntry.getKey();
			HashMap<Long, HashMap<Long, HashMap<String, Long>>> newGoalData =  new HashMap<Long, HashMap<Long,HashMap<String, Long>>>();
			HashMap<Long, HashMap<Long, HashMap<String, Long>>> goalData = variationEntry.getValue();
			for(Map.Entry<Long, HashMap<Long, HashMap<String, Long>>> goalEntry:goalData.entrySet())
			{
				Long goalId = goalEntry.getKey();
				HashMap<Long, HashMap<String, Long>> timeMap = goalEntry.getValue();
				HashMap<Long, HashMap<String, Long>> dayMap =  new HashMap<Long, HashMap<String, Long>>();
				for(Map.Entry<Long,HashMap<String, Long>> timeEntry:timeMap.entrySet())
				{
					Long time = timeEntry.getKey();
					HashMap<String, Long> valueHs = timeEntry.getValue();
					Long count = valueHs.get(ReportArchieveDimensionConstants.UNIQUE_COUNT);
					Long date = ZABUtil.getDateInLongFromTime(time);
					if(dayMap.containsKey(date))
					{
						HashMap<String, Long> dayValueHs = dayMap.get(date);
						dayValueHs.put(ReportArchieveDimensionConstants.UNIQUE_COUNT, dayValueHs.get(ReportArchieveDimensionConstants.UNIQUE_COUNT)+count);
					}
					else
					{
						HashMap<String, Long> dayValueHs = new HashMap<String, Long>();
						dayValueHs.put(ReportArchieveDimensionConstants.UNIQUE_COUNT, count);
						dayMap.put(date, dayValueHs);
					}
				}
				newGoalData.put(goalId, dayMap);
			}
			goalDayMeta.put(variationId, newGoalData);
		}
		//Convert to day END
		return goalDayMeta;
	}

	public static HashMap<Long, HashMap<Long, HashMap<Long, HashMap<String, Long>>>> convertGoalHourEntriesToDestTimePoints(HashMap<Long, HashMap<Long, HashMap<Long, HashMap<String, Long>>>> goalMeta, HashMap<Long, Long> destTimePointHs)
	{
		HashMap<Long, HashMap<Long, HashMap<Long, HashMap<String, Long>>>> goalDayMeta = new HashMap<Long, HashMap<Long, HashMap<Long, HashMap<String, Long>>>>();
		//Convert to day START
		for(Map.Entry<Long, HashMap<Long, HashMap<Long, HashMap<String, Long>>>> variationEntry:goalMeta.entrySet())
		{
			Long variationId = variationEntry.getKey();
			HashMap<Long, HashMap<Long, HashMap<String, Long>>> newGoalData =  new HashMap<Long, HashMap<Long,HashMap<String, Long>>>();
			HashMap<Long, HashMap<Long, HashMap<String, Long>>> goalData = variationEntry.getValue();
			for(Map.Entry<Long, HashMap<Long, HashMap<String, Long>>> goalEntry:goalData.entrySet())
			{
				Long goalId = goalEntry.getKey();
				HashMap<Long, HashMap<String, Long>> timeMap = goalEntry.getValue();
				HashMap<Long, HashMap<String, Long>> destTimeMap =  new HashMap<Long, HashMap<String, Long>>();
				for(Map.Entry<Long,HashMap<String, Long>> timeEntry:timeMap.entrySet())
				{
					Long time = timeEntry.getKey();
					HashMap<String, Long> valueHs = timeEntry.getValue();
					Long count = valueHs.get(ReportArchieveDimensionConstants.UNIQUE_COUNT);
					Long destTime = destTimePointHs.get(time);
					if(destTimeMap.containsKey(destTime))
					{
						HashMap<String, Long> destValueHs = destTimeMap.get(destTime);
						destValueHs.put(ReportArchieveDimensionConstants.UNIQUE_COUNT, destValueHs.get(ReportArchieveDimensionConstants.UNIQUE_COUNT)+count);
					}
					else
					{
						HashMap<String, Long> destValueHs = new HashMap<String, Long>();
						destValueHs.put(ReportArchieveDimensionConstants.UNIQUE_COUNT, count);
						destTimeMap.put(destTime, destValueHs);
					}
				}
				newGoalData.put(goalId, destTimeMap);
			}
			goalDayMeta.put(variationId, newGoalData);
		}
		//Convert to day END
		return goalDayMeta;
	}
	
	public static HashMap<Long, HashMap<Long, HashMap<Long, HashMap<String, Long>>>> calculateCumulativeCountForGoal(HashMap<Long, HashMap<Long, HashMap<Long, HashMap<String, Long>>>> goalDayMeta, ArrayList<Long> timePoints)
	{
		//calculate cumulative count entries START
		for(Map.Entry<Long, HashMap<Long, HashMap<Long, HashMap<String, Long>>>> variationEntry:goalDayMeta.entrySet())
		{
			HashMap<Long, HashMap<Long, HashMap<String, Long>>> goalData = variationEntry.getValue();
			for(Map.Entry<Long, HashMap<Long, HashMap<String, Long>>> goalEntry:goalData.entrySet())
			{
				HashMap<Long, HashMap<String, Long>> timeMap = goalEntry.getValue();
				long cumulativeCount = 0;
				for(Long time:timePoints)
				{
					if(timeMap.containsKey(time))
					{
						HashMap<String, Long> valueHs = timeMap.get(time);
						Long countValue = valueHs.get(ReportArchieveDimensionConstants.UNIQUE_COUNT);
						cumulativeCount = cumulativeCount+countValue;
						valueHs.put(ReportArchieveDimensionConstants.CUMULATIVE_COUNT, cumulativeCount);
					}
				}
			}
		}
		//calculate cumulative count entries END
		return goalDayMeta;
	}

	public static ArrayList<ChartReport> chartCalculations(HashMap<Long, HashMap<Long, HashMap<String, Long>>> visitorMeta ,HashMap<Long, HashMap<Long, HashMap<Long, HashMap<String, Long>>>> goalMeta , Long expId ,ArrayList<Long> timeValues, String baseLine,HashMap<String, HashMap<String, String>> revenueMeta,Long revenueGoalId , Long requiredGaolId ,HashMap<String, HashMap<String, String>> timeSpentMeta ,Long timeSpentGoalId,Long endTime ){

		ArrayList<ChartReport> chartReports = new ArrayList<ChartReport>();
		HashMap<String, ChartReport> chartHs = new HashMap<String , ChartReport>();

		ArrayList<Variation> variations  = new ArrayList<Variation>();
		ArrayList<Goal> goals = new ArrayList<Goal>();
		variations =  Variation.getVariationsOfExperiment(expId);
		
		if(requiredGaolId == null){
			goals = Goal.getGoalByExperimentByExperimentId(expId);
			
		}else{
			goals.add(Goal.getGoalByGoalId(requiredGaolId));
		}


		Collections.sort(timeValues);
		Goal revenueGoal= null;
	
		
		for(int i=0;i<variations.size();i++){
			for(int j=0;j<goals.size();j++){
			
				Goal g= goals.get(j);
				if(g.getGoalTypeTag().equals(GoalType.REVENUE_GOAL.getGoalTypeId())){		// PREVENTING REVENUE GOAL OBJECT CREATION
					revenueGoal=g;
					continue;
				}
				
				Long variationId = variations.get(i).getVariationId();
				String variationLinkName  =  variations.get(i).getVariationLinkname();
				Long goalId  = g.getGoalId();
				String goalLinkName =g.getGoalLinkname();
				String key = variationId+":"+goalId;

				ChartReport chart = new ChartReport();
				chart.setGoalId(goalId);
				chart.setVariationId(variationId);
				chart.setVariationLinkName(variationLinkName);
				chart.setGoalLinkName(goalLinkName);
				chart.setIsPredicted(Boolean.FALSE);
				chartHs.put(key, chart);
			}
		}

		Long originalVariationId  =ReportStatistics.getBaselineVariationId(baseLine, expId);
	
		for(int i=0;i<variations.size();i++){
			Long variationId = variations.get(i).getVariationId();
			for(int j=0;j<goals.size();j++){
				Long  goalId  = goals.get(j).getGoalId();
				
				for(int k=0;k<timeValues.size();k++){

					Long time  = timeValues.get(k);
					
					if(revenueGoalId!=null&& goalId.equals(revenueGoalId)){
						String revKey =  variationId+":"+time;
						try{
							Long PayingVisitors  = goalMeta.get(variationId).get(goalId).get(time).get(ReportArchieveDimensionConstants.UNIQUE_COUNT);
							revenueMeta.get(revKey).put(RevenueConstants.PAYING_VISITORS_COUNT, PayingVisitors.toString());
							
						}catch(Exception e){
							if(revenueMeta.containsKey(revKey)){
								revenueMeta.get(revKey).put(RevenueConstants.PAYING_VISITORS_COUNT, "0");
							}
						
						}
						continue;
					}	
					
					String key = variationId+":"+goalId;
					ChartReport chart = chartHs.get(key);
					
					if(timeSpentGoalId!=null&& goalId.equals(timeSpentGoalId)){
						String tsKey =  variationId+":"+time;
						try{
							HashMap<String, String> timespentdetail = timeSpentMeta.get(tsKey);
							Long totVisitors = Long.parseLong(timespentdetail.get(ReportArchieveDimensionConstants.TOTAL_COUNT));
							Double totTimeSpent = Double.parseDouble(timespentdetail.get(ReportArchieveDimensionConstants.TIME_SPENT));
							if(totTimeSpent>0 && totVisitors >0){
								Long avgTime =(long) (totTimeSpent/totVisitors);
								chart.getAvgTime().put(time, avgTime);
							}else{
								chart.getAvgTime().put(time, 0l);
							}
						}catch(Exception e){
							chart.getAvgTime().put(time, 0l);
						}
						
					}	
					


					Long  originalVisitCount  = 0l;
					Long originalGoalCount  = 0l;
					try{
						originalVisitCount = visitorMeta.get(originalVariationId).get(time).get(ReportArchieveDimensionConstants.UNIQUE_COUNT);
					}catch(Exception e){
						originalVisitCount= 0l;
					}
					try{
						originalGoalCount = goalMeta.get(originalVariationId).get(goalId).get(time).get(ReportArchieveDimensionConstants.UNIQUE_COUNT);
					}catch(Exception e){
						originalGoalCount = 0l;
					}


					Long  cumulativeoriginalVisitCount  = 0l;
					Long cumulativeoriginalGoalCount  = 0l;
					try{

						cumulativeoriginalVisitCount = visitorMeta.get(originalVariationId).get(time).get(ReportArchieveDimensionConstants.CUMULATIVE_COUNT);

					}catch(Exception e){

						cumulativeoriginalVisitCount= 0l;
						int a=k;
						while(true){
							try{
								if(a>0){

									Long oldTime  = timeValues.get(a-1);
									cumulativeoriginalVisitCount =  visitorMeta.get(originalVariationId).get(oldTime).get(ReportArchieveDimensionConstants.CUMULATIVE_COUNT);

									break;
								}else{
									cumulativeoriginalVisitCount= 0l;
									break;
								}

							}catch(Exception excep){
								a--;
							}
						}

					}
					try{

						cumulativeoriginalGoalCount = goalMeta.get(originalVariationId).get(goalId).get(time).get(ReportArchieveDimensionConstants.CUMULATIVE_COUNT);
					}catch(Exception e){
						cumulativeoriginalGoalCount = 0l;
						int a=k;
						while(true){
							try{
								if(a>0){

									Long oldTime  = timeValues.get(a-1);
									cumulativeoriginalGoalCount=  goalMeta.get(originalVariationId).get(goalId).get(oldTime).get(ReportArchieveDimensionConstants.CUMULATIVE_COUNT);
									break;
								}else{
									cumulativeoriginalGoalCount= 0l;
									break;
								}

							}catch(Exception excep){
								a--;
							}
						}
					}
					

					if(variationId.toString().equals(originalVariationId.toString())){
						// CALCULAATE ONLY CONVERSION RATES , CONFIDENCE INTERVAL   ALONE 

						double conversionRate  =  ReportStatistics.getConversionRate(originalVisitCount,(double) originalGoalCount);
						chart.getConversionRate().put(time, conversionRate);
						chart.getVisitors().put(time, originalVisitCount);
						chart.getConversions().put(time, originalGoalCount);

						double cumulativeconversionRate  =  ReportStatistics.getConversionRate(cumulativeoriginalVisitCount, (double)cumulativeoriginalGoalCount);
						chart.getCumulativeconversionRate().put(time, cumulativeconversionRate);
						chart.getCumulativevisitors().put(time, cumulativeoriginalVisitCount);
						chart.getCumulativeconversions().put(time, cumulativeoriginalGoalCount);

					}else{
						// CALCULATE CONVERSION RATE , CONFIDENCE INTERVAL , SIGNIFICANCE	

						Long  variationVisitCount  = 0l;
						Long variationGoalCount  = 0l;
						try{
							variationVisitCount =  visitorMeta.get(variationId).get(time).get(ReportArchieveDimensionConstants.UNIQUE_COUNT);

						}catch(Exception e){
							variationVisitCount= 0l;
						}
						try{
							variationGoalCount = goalMeta.get(variationId).get(goalId).get(time).get(ReportArchieveDimensionConstants.UNIQUE_COUNT);

						}catch(Exception e){
							variationGoalCount = 0l;
						}
						// TO DEAL WITH MISSING INTERMEDIATE DATA IN CHART REPORTS
						Long  cumulativevariationVisitCount  = 0l;
						Long cumulativevariationGoalCount  = 0l;
						try{
							cumulativevariationVisitCount = visitorMeta.get(variationId).get(time).get(ReportArchieveDimensionConstants.CUMULATIVE_COUNT);

						}catch(Exception e){
							cumulativevariationVisitCount= 0l;
							int a=k;
							while(true){
								try{
									if(a>0){

										Long oldTime  = timeValues.get(a-1);
										cumulativevariationVisitCount = visitorMeta.get(variationId).get(oldTime).get(ReportArchieveDimensionConstants.CUMULATIVE_COUNT);
										break;
									}else{
										cumulativevariationVisitCount= 0l;
										break;
									}

								}catch(Exception excep){
									a--;
								}
							}

						}
						try{
							cumulativevariationGoalCount = goalMeta.get(variationId).get(goalId).get(time).get(ReportArchieveDimensionConstants.CUMULATIVE_COUNT);

						}catch(Exception e){
							cumulativevariationGoalCount = 0l;
							int a=k;
							while(true){
								try{
									if(a>0){

										Long oldTime  = timeValues.get(a-1);
										cumulativevariationGoalCount = goalMeta.get(variationId).get(goalId).get(oldTime).get(ReportArchieveDimensionConstants.CUMULATIVE_COUNT);

										break;
									}else{
										cumulativevariationGoalCount= 0l;
										break;
									}

								}catch(Exception excep){
									a--;
								}
							}
						}
						
						Double conversionRate  =  ReportStatistics.getConversionRate(variationVisitCount, (double)variationGoalCount);
						Double significance  = ReportStatistics.getStatisticalSignificance(cumulativeoriginalVisitCount,(double) cumulativeoriginalGoalCount, cumulativevariationVisitCount, (double)cumulativevariationGoalCount);
					//	Double improvement  = ReportStatistics.getImprovement( ReportStatistics.getConversionRate(originalVisitCount, (double)originalGoalCount), conversionRate);
						chart.getConversionRate().put(time, conversionRate);
					 	chart.getStatisticalSignificance().put(time, significance);
					//	chart.getImprovement().put(time, improvement);
						chart.getVisitors().put(time, variationVisitCount);
						chart.getConversions().put(time, variationGoalCount);


						Double cumulativeconversionRate  =  ReportStatistics.getConversionRate(cumulativevariationVisitCount, (double)cumulativevariationGoalCount);
						Double cumulativeimprovement  = ReportStatistics.getImprovement( ReportStatistics.getConversionRate(cumulativeoriginalVisitCount,(double) cumulativeoriginalGoalCount), cumulativeconversionRate);
						
						chart.getCumulativeconversionRate().put(time, cumulativeconversionRate);
						if(cumulativeimprovement!=null){
							chart.getCumulativeimprovement().put(time, cumulativeimprovement);
						}
						
						chart.getCumulativevisitors().put(time, cumulativevariationVisitCount);
						chart.getCumulativeconversions().put(time, cumulativevariationGoalCount);

					}

				}

			}
		}
		Boolean setPredictionError = false;
		String predictionError = null;
		String to_forecast =  ZABUtil.getCurrentRequest().getParameter(ReportConstants.FORECAST);
		try{
			if(to_forecast!=null && to_forecast.equals("true")){

				Long totalVisitorCount = MachineLearningUtil.findTotalVisitorCount(visitorMeta);
				Boolean shouldPredict = MachineLearningUtil.shouldPredict(expId,totalVisitorCount,endTime);
				if(shouldPredict && requiredGaolId!=null && !requiredGaolId.equals(revenueGoalId)){ // This method works on assumption of presense of  requiredgoalId
					Long goalId  = requiredGaolId;
					Long lastTime = timeValues.get(timeValues.size()-1);
					HashMap<Long,HashMap<Long,Long>> visitorPredictions = new HashMap<Long,HashMap<Long,Long>>();
					HashMap<Long,HashMap<Long,Long>> conversionPredictions = new HashMap<Long,HashMap<Long,Long>>();
					for(int i =0;i<variations.size();i++){
						Long variationId =  variations.get(i).getVariationId();
						String key  = variationId+":"+goalId;
						ChartReport chart  = chartHs.get(key);
						
						JSONArray visitorArray = ZABUtil.convertHashMapToJSONArray(chart.getVisitors());
						JSONArray forecastvisitorarray = MachineLearningUtil.forecastPoints(visitorArray);
						visitorPredictions.put(variationId, MachineLearningUtil.convertJSONResponseToHMLL(forecastvisitorarray));
					
						JSONArray conversionArray = ZABUtil.convertHashMapToJSONArray(chart.getConversions());
						JSONArray forecastconversionarray = MachineLearningUtil.forecastPoints(conversionArray);
						conversionPredictions.put(variationId, MachineLearningUtil.convertJSONResponseToHMLL(forecastconversionarray));	
					}
					
					//calculate meta for original alone 
					
					ChartReport originalTemp = chartHs.get(originalVariationId+":"+requiredGaolId);
					Long oriLastCumulativeVisitors = originalTemp.getCumulativevisitors().get(lastTime);
					Long oriLastCumulativeGoals = originalTemp.getCumulativeconversions().get(lastTime);
					
					HashMap<Long,Long> originalVisitorCumulative = new 	HashMap<Long,Long>();
					
					for(Map.Entry<Long,Long> entry:visitorPredictions.get(originalVariationId).entrySet())
					{
						Long time  = entry.getKey();
						Long vis = entry.getValue();
						oriLastCumulativeVisitors = oriLastCumulativeVisitors +vis;
						originalVisitorCumulative.put(time, oriLastCumulativeVisitors);
					}
					
					HashMap<Long,Long> originalGoalCumulative = new HashMap<Long,Long>();
					for(Map.Entry<Long,Long> entry:conversionPredictions.get(originalVariationId).entrySet())
					{
						Long time  = entry.getKey();
						Long goalcount = entry.getValue();
						oriLastCumulativeGoals = oriLastCumulativeGoals +goalcount;
						originalGoalCumulative.put(time, oriLastCumulativeGoals);
					}
					
					Set<String>  keys  = chartHs.keySet();
					Iterator <?> itr = keys.iterator();
					while(itr.hasNext()){
						String key = (String)itr.next();
						ChartReport chart  = chartHs.get(key);
						Long variationId  = chart.getVariationId();
						
						HashMap<Long,Long> visitorForecastTemp = visitorPredictions.get(variationId);
						HashMap<Long,Long> converisonForecastTemp = conversionPredictions.get(variationId);
						chart.setForecastvisitors(visitorForecastTemp);
						chart.setForecastconversions(converisonForecastTemp);
						
						
						Long lastCumulativeVisitor = chart.getCumulativevisitors().get(lastTime);
						Long lastCumulativeConversion = chart.getCumulativeconversions().get(lastTime);
						
						for(Map.Entry<Long,Long> entry:visitorForecastTemp.entrySet())
						{
							
							Long time = entry.getKey();
							Long viscount =  entry.getValue();
							Long concount = converisonForecastTemp.get(time);
							if(concount>viscount){
								concount = viscount;
							}
							lastCumulativeVisitor = lastCumulativeVisitor +viscount;
							lastCumulativeConversion = lastCumulativeConversion + concount;
							Double predictedconvRate = ReportStatistics.getConversionRate(lastCumulativeVisitor, lastCumulativeConversion.doubleValue());
							chart.getForecastconversionRate().put(time, predictedconvRate);
							
							if(!variationId.equals(originalVariationId)){
								Long orivisitor = originalVisitorCumulative.get(time) ;
								Long origoal = originalGoalCumulative.get(time) ;
								Double oriConvRate  = ReportStatistics.getConversionRate(orivisitor, origoal.doubleValue());
								
								Double forecastImprove = ReportStatistics.getImprovement(oriConvRate, predictedconvRate);
								if(forecastImprove!=null){
									chart.getForecastimprovement().put(time, forecastImprove);
									
								}
								Double significance  = ReportStatistics.getStatisticalSignificance(orivisitor,origoal.doubleValue(),lastCumulativeVisitor,lastCumulativeConversion.doubleValue());
								chart.getForecastsignificance().put(time, significance);
								
								
							}
						}	
						
						chart.getForecastvisitors().put(lastTime, chart.getVisitors().get(lastTime));
						chart.getForecastconversions().put(lastTime, chart.getConversions().get(lastTime));
						
						if(chart.getCumulativeimprovement().get(lastTime) !=null){
							chart.getForecastimprovement().put(lastTime, chart.getCumulativeimprovement().get(lastTime));
						}
						if(chart.getCumulativeimprovement().get(lastTime) !=null){
							chart.getForecastsignificance().put(lastTime, chart.getStatisticalSignificance().get(lastTime));	
						}
						if(chart.getCumulativeconversionRate().get(lastTime) !=null){
							chart.getForecastconversionRate().put(lastTime, chart.getCumulativeconversionRate().get(lastTime));
						}
						chart.setIsPredicted(Boolean.TRUE);
						
					}
					
				}else{
					String failureresponse  = MachineLearningUtil.predictFailureReason(expId,totalVisitorCount,endTime);
					predictionError = ZABAction.getMessage(failureresponse);
					setPredictionError = Boolean.TRUE;
					
				}
				
			
			}
			
			
		}catch(Exception predictionException){
			LOGGER.log(Level.SEVERE, predictionException.getMessage(),predictionException);
			predictionError = ZABAction.getMessage(MLConstants.ML_ERROR);
			setPredictionError = Boolean.TRUE;
			
		}
		
		
		Set<String>  keys  = chartHs.keySet();
		Iterator <?> itr = keys.iterator();
		while(itr.hasNext()){
			String key = (String)itr.next();
			ChartReport chart  = chartHs.get(key);
			chart.setSuccess(Boolean.TRUE);
			
			if(setPredictionError){
				chart.setSuccess(Boolean.FALSE);
				chart.setResponseString(predictionError);
			}
			
			chartReports.add(chart);
		}
		
		if((revenueGoalId!=null) && ( (requiredGaolId == null) || (requiredGaolId.equals(revenueGoalId)))){
			HashMap<Long, RevenueChartReport> revenyecharts = RevenueChartReport.chartCalculations(visitorMeta, revenueMeta, expId, timeValues);
			for(int i=0;i<variations.size();i++){
				Variation var = variations.get(i);
				Long variationId = var.getVariationId();
				String variationLinkName = var.getVariationLinkname();
				RevenueChartReport rev = revenyecharts.get(variationId);
				ChartReport chart  = new ChartReport();
				chart.setVariationId(variationId);
				chart.setVariationLinkName(variationLinkName);
				chart.setGoalId(revenueGoalId);
				chart.setGoalLinkName(revenueGoal.getGoalLinkname());
				chart.setRevenueChart(rev);
				chart.setSuccess(Boolean.TRUE);
				chartReports.add(chart);
				
			}
		
		}
		
		
		return chartReports;


	}

	

}
