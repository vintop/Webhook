//$Id$
package com.zoho.abtest.report;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.json.JSONException;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.opensymphony.xwork2.ActionSupport;
import com.zoho.abtest.EVENTS;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.SHARED_REPORT_DETAILS;
import com.zoho.abtest.audience.Audience;
import com.zoho.abtest.audience.AudienceConstants;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.customevent.CustomEvent;
import com.zoho.abtest.customevent.CustomEventConstants;
import com.zoho.abtest.elastic.ElasticSearchStatistics;
import com.zoho.abtest.eventactivity.EventActivityAction;
import com.zoho.abtest.eventactivity.EventActivityConstants;
import com.zoho.abtest.eventactivity.EventActivityLog;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.experiment.ExperimentHandler;
import com.zoho.abtest.goal.Goal;
import com.zoho.abtest.goal.GoalConstants;
import com.zoho.abtest.heatmaps.Heatmap;
import com.zoho.abtest.heatmaps.HeatmapConstants;
import com.zoho.abtest.heatmaps.HeatmapElasticSearch;
import com.zoho.abtest.heatmaps.Scrollmap;
import com.zoho.abtest.heatmaps.ScrollmapConstants;
import com.zoho.abtest.heatmaps.ScrollmapElasticSearch;
import com.zoho.abtest.integration.GoogleAdwords;
import com.zoho.abtest.integration.Integration;
import com.zoho.abtest.integration.IntegrationConstants;
import com.zoho.abtest.project.ProjectConstants;
import com.zoho.abtest.utility.ZABUtil;

public class SharedReportAction extends ActionSupport implements ServletResponseAware, ServletRequestAware{
	private static final long serialVersionUID = 1L;

	private HttpServletRequest request;
	private HttpServletResponse response;
	private String shareKey ;
	private String variationLinkName ;
	private static final Logger LOGGER = Logger.getLogger(ReportAction.class.getName());
	
	public void setServletRequest(HttpServletRequest arg0) {
		request = arg0;
	}


	public void setServletResponse(HttpServletResponse arg0) {
		response = arg0;
	}
	
	public String getShareKey() {
		return shareKey;
	}

	public void setShareKey(String shareKey) {
		this.shareKey = shareKey;
		
	}
	public void setVariationLinkName(String variationLinkName) {
		this.variationLinkName = variationLinkName;
		request.setAttribute(HeatmapConstants.VARIATION_LINKNAME, variationLinkName);
	}
	
	public String getOverviewReport() throws IOException, JSONException 
	{
		String shareKey = getShareKey();
		ArrayList<ReportStatistics> visitorReports = new ArrayList<ReportStatistics>();
		try {			
			visitorReports.addAll(ElasticSearchStatistics.getOverviewReport(getExperimentLinkNameFromShareKey(shareKey)));
				
		} catch(Exception ex){
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), CumulativeReportConstants.API_MODULE));
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
			return null; 	
		}		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getReportResponse(request, visitorReports));		
		return null;
	}
	
	public static String getExperimentLinkNameFromShareKey(String shareKey){
	
		/*Criteria c= new Criteria(new Column(SHARED_REPORT_DETAILS.TABLE,SHARED_REPORT_DETAILS.SHARE_KEY),shareKey,QueryConstants.EQUAL);
		Long expId = null;
		String expLinkName = null;
		try{
			DataObject dobj = ZABModel.getRow(SHARED_REPORT_DETAILS.TABLE, c);
			if(dobj.containsTable(SHARED_REPORT_DETAILS.TABLE)){
				Row row = dobj.getFirstRow(SHARED_REPORT_DETAILS.TABLE);
				expId = (Long)row.get(SHARED_REPORT_DETAILS.EXPERIMENT_ID);	
				expLinkName = Experiment.getExperimentById(expId).getExperimentLinkname();
			}
		}catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}*/
		
		String expLinkName = (String)ZABUtil.getCurrentRequest().getAttribute(ExperimentConstants.EXPERIMENT_LINKNAME);
		return expLinkName;
		
	}

	public static Long getExperimentIdFromShareKey(String shareKey){
		
		Criteria c= new Criteria(new Column(SHARED_REPORT_DETAILS.TABLE,SHARED_REPORT_DETAILS.SHARE_KEY),shareKey,QueryConstants.EQUAL);
		Long expId = null;
		
		try{
			DataObject dobj = ZABModel.getRow(SHARED_REPORT_DETAILS.TABLE, c);
			if(dobj.containsTable(SHARED_REPORT_DETAILS.TABLE)){
				Row row = dobj.getFirstRow(SHARED_REPORT_DETAILS.TABLE);
				expId = (Long)row.get(SHARED_REPORT_DETAILS.EXPERIMENT_ID);	
				
			}
		}catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		
		return expId;
		
	}
	public String getGoals() throws IOException, JSONException{

		ArrayList<Goal> goals = new ArrayList<Goal>();
		try {		
			Long id = getExperimentIdFromShareKey(getShareKey());
			goals.addAll(Goal.getGoalByExperimentByExperimentId(id));
			
		}	
		catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), GoalConstants.API_MODULE_PLURAL));
			return null; 	
		}		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getGoalResponse(request, goals));		
	    return null;	
	
	}
	public String getAudiences() throws IOException, JSONException{

		ArrayList<Audience> audiences = new ArrayList<Audience>();
		try {		
			Long id = getExperimentIdFromShareKey(getShareKey());
			audiences.addAll(Audience.getAudienceByExperimentId(id));
			
		}	
		catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), AudienceConstants.API_MODULE));
			return null; 	
		}		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getAudienceResponse(request, audiences));		
	    return null;	
	
	}
	
	public String getExperiments() throws IOException, JSONException{

		ArrayList<Experiment> experiments = new ArrayList<Experiment>();
		try {		
			String linkname = getExperimentLinkNameFromShareKey(getShareKey());
			experiments.addAll(ExperimentHandler.handleExperimentFetch(linkname));
			
		}	
		catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ExperimentConstants.API_MODULE));
			return null; 	
		}		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExperimentResponse(request, experiments));		
	    return null;	
	
	}
	
	
	public String getHeatmapElasticReport() throws Exception 
	{
		
		ArrayList<Heatmap> heatmapreport = new ArrayList<Heatmap>();
		HashMap<String,String> hs;
		try {			
			
			String shareKey = getShareKey();
			String expLinkName =  getExperimentLinkNameFromShareKey(shareKey);
			request.setAttribute(HeatmapConstants.EXPERIMENT_LINKNAME, expLinkName);
			switch(ZABAction.getHTTPMethod(request)) {
			case POST:	
 
				hs = ZABAction.getRequestParser(request).parseHeatmapReport(request);
				if(hs.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					Heatmap report = new Heatmap();
					report.setSuccess(Boolean.FALSE);
					report.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
					heatmapreport.add(report);
					LOGGER.log(Level.SEVERE,hs.get(ZABConstants.RESPONSE_STRING));
				}else{
					heatmapreport.addAll(HeatmapElasticSearch.getHeatmapInformation(hs));
				}
				break;
			default:
				break;
			}
		} catch(Exception ex){
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), HeatmapConstants.API_MODULE));
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
			return null; 	
		}	
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getHeatmapDataResponse(request, heatmapreport));		  
		return null;
	}
	
	public String getScrollmapElasticReport() throws IOException, JSONException 
	{
		
		ArrayList<Scrollmap> scrollmapdata = new ArrayList<Scrollmap>();
		HashMap<String,String> hs;
		try {			
			String shareKey = getShareKey();
			String expLinkName =  getExperimentLinkNameFromShareKey(shareKey);
			request.setAttribute(HeatmapConstants.EXPERIMENT_LINKNAME, expLinkName);
			switch(ZABAction.getHTTPMethod(request)) {
			case POST:	
				hs = ZABAction.getRequestParser(request).parseScrollmapReport(request);

				if(hs.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					Scrollmap report = new Scrollmap();
					report.setSuccess(Boolean.FALSE);
					report.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
					scrollmapdata.add(report);
					LOGGER.log(Level.SEVERE,hs.get(ZABConstants.RESPONSE_STRING));
				}else{
					
					scrollmapdata.addAll(ScrollmapElasticSearch.getScrollmapInformation(hs));
				}
				break;
			default:
				break;
			}
		} catch(Exception ex){
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ScrollmapConstants.API_MODULE));
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
			return null; 	
		}	
		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getScrollmapDataResponse(request, scrollmapdata));		  
		return null;
	}
	public String getCustomEvents() throws Exception {
		ArrayList<CustomEvent> cusEvents = new ArrayList<CustomEvent>();
		try {			
			String sharekey =  getShareKey();
			
			Long projectId = getProjectIdFromShareKey(sharekey) ;
			Criteria c =  new Criteria(new Column(EVENTS.TABLE,EVENTS.PROJECT_ID),projectId ,QueryConstants.EQUAL);
			cusEvents.addAll(CustomEvent.getCustomEventByCriteria(c));

		} catch(Exception ex){
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ProjectConstants.API_MODULE_PLURAL));
			return null; 	
		}		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getCustomEventResponse(request, cusEvents));	
	    return null;
	}
	public static Long getProjectIdFromShareKey(String shareKey){
		
		Long projectId = null;
		try{
			String expLinkName = (String)ZABUtil.getCurrentRequest().getAttribute(ExperimentConstants.EXPERIMENT_LINKNAME);
			Criteria c = new Criteria(new Column(EXPERIMENT.TABLE,EXPERIMENT.EXPERIMENT_LINK_NAME),expLinkName,QueryConstants.EQUAL);
			DataObject dobj = ZABModel.getRow(EXPERIMENT.TABLE, c);
			projectId = (Long)dobj.getFirstValue(EXPERIMENT.TABLE, EXPERIMENT.PROJECT_ID);
			
		}catch(Exception ex ){
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
		}
		
		return projectId;
	
		
	}
	public  String getGoogleAdwords() throws JSONException, IOException{

		
		HashMap<String,String> hs = ZABAction.getRequestParser(request).parseGoogleAdwords(request);

		ArrayList<GoogleAdwords> googleadwords = new ArrayList<GoogleAdwords>();
		try {			
			String sharekey =  getShareKey();
			Long projectid = getProjectIdFromShareKey(shareKey);
			Long id = getExperimentIdFromShareKey(getShareKey());
			hs.put(IntegrationConstants.EXPERIMENT_ID,id.toString());
			switch(ZABAction.getHTTPMethod(request)) {
			case POST:	
				googleadwords.addAll(GoogleAdwords.getGoogleAdwordsReport(hs,request,projectid.toString()));
				break;
			
			}
		}  catch(Exception ex){
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), IntegrationConstants.API_MODULE));
			return null; 	
		}		
		LOGGER.log(Level.INFO, "Google Adwords  Action Ends"); //No I18N
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getGoogleAdwordsResponse(request, googleadwords));	
	    return null;
	
	}
	
	public String integrations() throws IOException,JSONException {
		ArrayList<Integration> integrations = new ArrayList<Integration>();
		

		String key = getShareKey();
		Long projectid = getProjectIdFromShareKey(key);
		String integration_id = request.getParameter(IntegrationConstants.INTEGRATION_ID);
		
		try {		
			switch(ZABAction.getHTTPMethod(request)) {			
			
			case GET:
				
				integrations.addAll(Integration.getIntegration(projectid.toString(),null,null,integration_id,request));
				break;
				
			
			}
		}	
		catch(Exception ex){
			LOGGER.log(Level.SEVERE, "Exception occured: ",ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), IntegrationConstants.API_MODULE));
			return null; 	
		}		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getIntegrationResponse(request, integrations));		
	    return null;
	}

	
}
