//$Id$
package com.zoho.abtest.report;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import com.zoho.abtest.sessionrecording.SessionRawDataEventBuffer;
import com.zoho.abtest.sessionrecording.SessionRawDataPageBuffer;
import com.zoho.abtest.utility.ZABUtil;

public class VisitorRawDataWrapper implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public VisitorRawDataWrapper() {
		HttpServletRequest request = ZABUtil.getCurrentRequest();
		String ipaddress = request.getHeader("X-FORWARDED-FOR");
		if(ipaddress == null)
		{
			ipaddress = request.getRemoteAddr();
		}
		setIpAddress(ipaddress);
		setTime(ZABUtil.getCurrentTimeInMilliSeconds());
	}
	
	private Long time;
	
	private HashMap<String,String> userAgenths;
	
	private ArrayList<HashMap<String,String>> experimentsData;
	
	private HashMap<String,String> formData;

	
	private ArrayList<HashMap<String,String>> heatmappoints;
	
	private ArrayList<HashMap<String,String>> formanalyticspoints;
	
	private ArrayList<HashMap<String,String>> scrollmapData;
	
	private HashMap<String,String> funnelData;
	
	private ArrayList<HashMap<String,String>> sessionRawData;
	
	private String sessionEventData;

	private String ipAddress;
	
	private Boolean isOptOut = false;
	
	private Object optOutData;
	
	private HashMap<String,String> identityData;
	
	
	
	public HashMap<String, String> getIdentityData() {
		return identityData;
	}

	public void setIdentityData(HashMap<String, String> identityData) {
		this.identityData = identityData;
	}

	public Object getOptOutData() {
		return optOutData;
	}

	public void setOptOutData(Object optOutData) {
		this.optOutData = optOutData;
	}

	public Boolean getIsOptOut() {
		return isOptOut;
	}

	public void setIsOptOut(Boolean isOptOut) {
		this.isOptOut = isOptOut;
	}

	public HashMap<String, String> getFormData() {
		return formData;
	}

	public void setFormData(HashMap<String, String> formData) {
		this.formData = formData;
	}

	public ArrayList<HashMap<String, String>> getFormanalyticspoints() {
		return formanalyticspoints;
	}

	public void setFormanalyticspoints(
			ArrayList<HashMap<String, String>> formanalyticspoints) {
		this.formanalyticspoints = formanalyticspoints;
	}
	
	private Long pageBufferId;
	
	private Long eventBufferId;

	public Long getPageBufferId() {
		return pageBufferId;
	}

	public void setPageBufferId(Long pageBufferId) {
		this.pageBufferId = pageBufferId;
	}

	public Long getEventBufferId() {
		return eventBufferId;
	}

	public void setEventBufferId(Long eventBufferId) {
		this.eventBufferId = eventBufferId;
	}

	public HashMap<String, String> getFunnelData() {
		return funnelData;
	}

	public void setFunnelData(HashMap<String, String> funnelData) {
		this.funnelData = funnelData;
	}

	public Long getTime() {
		return time;
	}

	public void setTime(Long time) {
		this.time = time;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public HashMap<String, String> getUserAgenths() {
		return userAgenths;
	}

	public void setUserAgenths(HashMap<String, String> userAgenths) {
		this.userAgenths = userAgenths;
	}

	public ArrayList<HashMap<String, String>> getExperimentsData() {
		return experimentsData;
	}

	public void setExperimentsData(
			ArrayList<HashMap<String, String>> experimentsData) {
		this.experimentsData = experimentsData;
	}

	public ArrayList<HashMap<String,String>> getHeatmapPoints() {
		return heatmappoints;
	}

	public void setHeatmapPoints(ArrayList<HashMap<String,String>> heatmappoints) {
		this.heatmappoints = heatmappoints;
	}

	public ArrayList<HashMap<String, String>> getSessionRawData() {
		return sessionRawData;
	}

	public void setSessionRawData(ArrayList<HashMap<String, String>> sessionRawData) {
		this.sessionRawData = sessionRawData;
	}

	public String getSessionEventData() {
		return sessionEventData;
	}

	public void setSessionEventData(String sessionEventData) {
		this.sessionEventData = sessionEventData;
	}

	@Override
	public String toString() {
		return "VisitorRawDataWrapper [userAgenths=" + userAgenths + ", experimentsData=" + experimentsData +", heatmappoints= " + heatmappoints +", ipAddress=****" + ", formanalyticspoints="+formanalyticspoints+", identityData="+identityData+"]"; //No I18N
	}

	public ArrayList<HashMap<String,String>> getScrollmapData() {
		return scrollmapData;
	}

	public void setScrollmapData(ArrayList<HashMap<String,String>> scrollmapData) {
		this.scrollmapData = scrollmapData;
	}
	
	public void bufferSessionPage() throws Exception {
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		String pageData = this.getUserAgenths().get(ReportRawDataConstants.HTML_CONTENT_VALUE);
		SessionRawDataPageBuffer buffer = new SessionRawDataPageBuffer();
		buffer.setData(pageData);
		buffer.saveRecord();
		Long pageBufferId = buffer.getBufferId();
		this.getUserAgenths().remove(ReportRawDataConstants.HTML_CONTENT_VALUE);
		this.setPageBufferId(pageBufferId);
	}
	
	public void bufferSessionEvent() throws Exception {
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		String eventData = this.getSessionEventData();
		SessionRawDataEventBuffer buffer = new SessionRawDataEventBuffer();
		buffer.setData(eventData);
		buffer.saveRecord();
		Long eventBufferId = buffer.getBufferId();
		this.setEventBufferId(eventBufferId);
	}

}
