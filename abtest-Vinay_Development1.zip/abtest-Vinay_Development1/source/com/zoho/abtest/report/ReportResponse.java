//$Id$
package com.zoho.abtest.report;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;
import com.zoho.abtest.goal.GoalConstants;
import com.zoho.abtest.revenue.RevenueResponse;
import com.zoho.abtest.variation.VariationConstants;

public class ReportResponse {
	public static String jsonResponse(HttpServletRequest request,ArrayList<ReportStatistics> lst) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(lst);			
			JSONObject json = ZABResponse.updateMetaInfo(request, CumulativeReportConstants.API_MODULE, array);
//			json.put(VariationConstants.API_MODULE , getVariationDetails(lst));
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){}
		return returnBuffer.toString();
	}

	public static JSONArray getJSONArray(ArrayList<ReportStatistics> lst) throws JSONException {
		JSONArray array = new JSONArray();
		int size =lst.size();
		for (int i=0;i<size;i++) {
			ReportStatistics ld=lst.get(i);
			JSONObject jsonObj = new JSONObject();

			//jsonObj.put(ExperimentConstants.EXPERIMENT_ID, ld.getExperimentId());
			jsonObj.put(VariationConstants.VARIATION_ID, ld.getVariationId());
			jsonObj.put(CumulativeReportConstants.VARIATION_LINK_NAME, ld.getVariationLinkName());
			jsonObj.put(ReportArchieveDimensionConstants.UNIQUE_VISITOR_COUNT, ld.getUniqueVisitorCount());
			
			if(ld.getGoalId() != null){
				jsonObj.put(GoalConstants.GOAL_ID, ld.getGoalId());
				jsonObj.put(CumulativeReportConstants.GOAL_LINK_NAME, ld.getGoalLinkNmae());
				jsonObj.put(ReportArchieveDimensionConstants.UNIQUE_GOAL_ACHIEVED_COUNT, ld.getUniqueGaolCount());

				
				if(ld.getUniqueConversionRate()!=null){
					jsonObj.put(CumulativeReportConstants.UNIQUE_CNVERSION_RATE, Math.round(ld.getUniqueConversionRate()*10000.0)/100.0);
					
				}
				if(ld.getUniqueConfidence()!=null){
					jsonObj.put(CumulativeReportConstants.UNIQUE_CONFIDENCE,Math.round(ld.getUniqueConfidence()*10000.0)/100.0 );
					
				}
				if(ld.getUniqueImprovement() !=null){

					jsonObj.put(CumulativeReportConstants.UNIQUE_IMPROVEMENT, Math.round(ld.getUniqueImprovement()*10000.0)/100.0);
				}
				if(ld.getUniqueSignificance()!=null){

					jsonObj.put(CumulativeReportConstants.UNIQUE_STATISTICAL_SIGNIFICANCE,Math.round(ld.getUniqueSignificance()*10000.0)/100.0 );

				}
				if(ld.getAverageTimeSpent()!=null){
					
					jsonObj.put(CumulativeReportConstants.AVERAGE_TIME_SPENT,ld.getAverageTimeSpent());
				}
				
				jsonObj.put(CumulativeReportConstants.UNIQUE_IS_SIGNIFICANT, ld.getUniqueIsSignificant());
				jsonObj.put(CumulativeReportConstants.UNIQUE_CONCLUSION, ld.getUniqueConclusion());
				jsonObj.put(CumulativeReportConstants.IS_WINNER, ld.getIsWinner());
				jsonObj.put(CumulativeReportConstants.IS_LOSER, ld.getIsLoser());
				jsonObj.put(CumulativeReportConstants.IS_INSIGNIFICANT, ld.getIsInconclusive());
				jsonObj.put(CumulativeReportConstants.DECISION, ld.getDecision());
				

			}
			if(ld.getRevenue()!=null){
				JSONObject revenuejson = RevenueResponse.singleRevenueResponse(ld.getRevenue());
				Iterator<String> revenuekeys = revenuejson.keys();
				while(revenuekeys.hasNext()){
					String key = revenuekeys.next();
					Object value  = revenuejson.get(key);
					jsonObj.put(key, value);
				}
			}

			jsonObj.put(ZABConstants.SUCCESS, ld.getSuccess());
			jsonObj.put(ZABConstants.RESPONSE_STRING, ld.getResponseString());
			array.put(jsonObj);
		}
		return array;
	}

	
	public static JSONArray getVariationDetails(ArrayList<ReportStatistics> lst) throws JSONException {
		JSONArray array = new JSONArray();
		HashMap<Long, ReportStatistics> hs = new 	HashMap<Long, ReportStatistics>();
		for(int i = 0;i<lst.size();i++){
			ReportStatistics report = lst.get(i);
			Long variationID = report.getVariationId();
			if(!hs.containsKey(variationID)){
				hs.put(variationID, report);
			}
		}
		Set<Long> keys  = hs.keySet();
		Iterator <Long> itr  = keys.iterator();
		while(itr.hasNext()){
			Long varId = itr.next();
			ReportStatistics  reprot  =  hs.get(varId);
			JSONObject json = new JSONObject();
			json.put(VariationConstants.VARIATION_ID, reprot.getVariationId());

			json.put(CumulativeReportConstants.VARIATION_LINK_NAME, reprot.getVariationLinkName());
			json.put(ReportArchieveDimensionConstants.UNIQUE_VISITOR_COUNT, reprot.getUniqueVisitorCount());
			//json.put(ReportArchieveDimensionConstants.TOTAL_VISITOR_COUNT, reprot.getTotalVisitorCount());
			array.put(json);
			
		}
		return array;
	}
	public static String convertTimeSpentToReadableFormat(Long seconds){
		String time  = "";
		
		Long hours  = seconds/3600;
		if(hours>0){
			Long remainder = seconds%3600;
			Long mins  = remainder/60;
			time = hours+"h";	// NO I18N
			if(mins>0){
				time = time+" "+mins+"m";// NO I18N
			}
			
		}else{
			Long minutes = seconds/60;
			if(minutes>0){
				time =  minutes+"m ";// NO I18N
			}
			Long secs = seconds%60;
			time = time+secs+"s";// NO I18N
		}
		
		return time ;
	}
}
