//$Id$
package com.zoho.abtest.report;

import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.trigger.TriggerConstants.TriggerType;
import com.zoho.abtest.listener.IPRestrictionData;
import com.zoho.abtest.listener.ZABListener;
import com.zoho.abtest.listener.ZABNotifier;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.mqueue.consumer.ConsumerRecord;
import com.zoho.mqueue.consumer.MessageListener;

public class VisitorGoalRawDataListener extends ZABListener implements MessageListener<String, String>{

	private static final Logger LOGGER = Logger.getLogger(VisitorGoalRawDataListener.class.getName());
	
	@Override
	public void consumeMessage(Object obj) throws Exception {
		try {			
			if(obj!=null) {
				VisitorRawDataWrapper wrapper = (VisitorRawDataWrapper)obj;
				VisitorRawDataHandler.addGoalRawdata(wrapper);
				

			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			throw new Exception(e);
		}
	}

	@Override
	public IPRestrictionData getIPRestrictionData(Object message)
			throws ZABException {
		VisitorRawDataWrapper wrapper = (VisitorRawDataWrapper)message;
		
		if(wrapper.getExperimentsData().size() > 0) {
			HashMap<String, String> hs = wrapper.getExperimentsData().get(0);
			String portal = hs.get(ReportRawDataConstants.PORTAL);
			
			String experimentKey = hs.get(ReportRawDataConstants.EXPERIMENT_KEY);
			setDBSpace(portal);
			Long projectId = Experiment.getProjectIdByExperimentKey(experimentKey);
			LOGGER.log(Level.INFO, "Getting IP Address from visitor raw data:"+experimentKey+", "+projectId+", ****");
			return new IPRestrictionData(portal, projectId, wrapper.getIpAddress());
		}
		return null;
	}
	
	
}
