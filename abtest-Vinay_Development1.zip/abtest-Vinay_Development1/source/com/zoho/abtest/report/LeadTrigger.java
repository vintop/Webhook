//$Id$
package com.zoho.abtest.report;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Logger;

import com.zoho.abtest.webhook.Webhook;

public class LeadTrigger extends CustomTrigger{


	private static final Logger LOGGER = Logger.getLogger(LeadTrigger.class.getName());

	private static final long serialVersionUID = 1L;




	@Override
	public ArrayList<Webhook> getWebhooks(WebhookWrapper object) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public HashMap<String, String> getVariables(WebhookWrapper object) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	

}
