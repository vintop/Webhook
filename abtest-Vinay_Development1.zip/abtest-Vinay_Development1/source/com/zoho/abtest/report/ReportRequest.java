//$Id$
package com.zoho.abtest.report;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;

import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABRequest;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.utility.ZABUtil;

public class ReportRequest extends ZABRequest{

	public void updateFromRequest(HashMap<String, String> map,
			HttpServletRequest request) {
		String experimentLinkName  = (String)request.getAttribute(ExperimentConstants.EXPERIMENT_LINKNAME);

		if(experimentLinkName!=null) 
		{
			map.put(ExperimentConstants.EXPERIMENT_LINKNAME,experimentLinkName);
		}

	}

	public void specificValidation(HashMap<String, String> map, HttpServletRequest request) throws IOException, JSONException { 
		String httpMethod = ZABAction.getHTTPMethod(request).toString();
		if(httpMethod.equalsIgnoreCase("POST")){
			ArrayList<String> fields = new ArrayList<String>();
			
			if(!map.containsKey(ExperimentConstants.EXPERIMENT_LINKNAME)) {
				fields.add(ExperimentConstants.EXPERIMENT_LINKNAME);
			}
			if (!map.containsKey(ReportConstants.START_DATE)) {
				fields.add(ReportConstants.START_DATE);
			}
			if (!map.containsKey(ReportConstants.END_DATE)) {
				fields.add(ReportConstants.END_DATE);
			}/*else{
				String endTime  = map.get(ReportConstants.END_DATE);
				try{
					if(endTime!=null&&!endTime.isEmpty()){
						Long endTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(endTime, "yyyy-MM-dd");		// NO I18N
						Long currentTime = ZABUtil.getCurrentTimeInMilliSeconds();
						if(currentTime <endTimeInMillis) {	// END DATE IS A DATE GREATER THAN TODAY 
							fields.add(ReportConstants.END_DATE);
						}
					}
					
				}catch(Exception e){
					fields.add(ReportConstants.END_DATE);
				}
				
			}*/
			
			if(!map.containsKey(ReportConstants.REPORT_TYPE)){
				fields.add(ReportConstants.REPORT_TYPE);
			}
			else{
				String reportType = map.get(ReportConstants.REPORT_TYPE);
				if(reportType.equals(ReportConstants.SEGMENT)){
					if (!map.containsKey(ReportConstants.SEGMENT_TYPE)) {
						fields.add(ReportConstants.SEGMENT_TYPE);
					}
					if (!map.containsKey(ReportConstants.VALUES)) {
						fields.add(ReportConstants.VALUES);
					}
				}
				else if(reportType.equals(ReportConstants.MULTISEGMENT)){
					if (!map.containsKey(ReportConstants.MULTISEGMENT_CRITERIA)) {
						fields.add(ReportConstants.MULTISEGMENT_CRITERIA);
					}
				}
				else if(reportType.equals(ReportConstants.QUICKFILTER)){
					if (!map.containsKey(ReportConstants.SEGMENT_TYPE)) {
						fields.add(ReportConstants.SEGMENT_TYPE);
					}
				}
			}
			
		    if(fields.size() > 0)
		    {
		    	ZABRequest.updateError(map, ZABAction.getAppropriateMessage(ZABConstants.ErrorMessages.MANDATORY_FIELD_MISSING.getErrorString(),fields));
		    }

		}
	}
}
