//$Id$
package com.zoho.abtest.report;

import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.mfw.bean.BeanUtil;
import com.adventnet.persistence.DataObject;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.utility.ZABUserBean;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.abtest.GOAL_DATA_RAW_IDGEN;
import com.zoho.abtest.VISITOR_DATA_RAW_IDGEN;
import com.zoho.abtest.JSON_VISITOR_RAW_IDGEN;

public class ReportRawData extends ZABModel{
	
	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = Logger.getLogger(ReportRawData.class.getName());
	
	public static ReportRawData updateVisitorRawData(HashMap<String, String> hs) {
		ReportRawData reportRawData = new ReportRawData();
		try
		{
			ZABUserBean userAction = (ZABUserBean)BeanUtil.lookup("ZABUserBean",ZABUtil.getCurrentUserDbSpace());
			userAction.updateVisitorRawData(hs);
			reportRawData.setSuccess(Boolean.TRUE);
			reportRawData.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_ADD_SUCCESS));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			reportRawData.setSuccess(Boolean.FALSE);
			reportRawData.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
		}
		return reportRawData;
	}
	
	public static HashMap<String, String> getVisitorRawData(String uvid, Long experimentId) {
		HashMap<String, String> hs = new HashMap<String, String>();
		try {
			ZABUserBean userAction = (ZABUserBean)BeanUtil.lookup("ZABUserBean",ZABUtil.getCurrentUserDbSpace());
			hs = userAction.getVisitorRawData(uvid, experimentId);
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		return hs;
	}
	
	public static ReportRawData addVisitorRawData(HashMap<String,String> hs)
	{
		ReportRawData reportRawData = new ReportRawData();
		try
		{
			Long visitorDataRawId = generateVisitorRawDataId();
			hs.put("VISITOR_DATA_RAW_ID", visitorDataRawId.toString());
			ZABUserBean userAction = (ZABUserBean)BeanUtil.lookup("ZABUserBean",ZABUtil.getCurrentUserDbSpace());
			userAction.addVisitorRawData(hs);
			reportRawData.setSuccess(Boolean.TRUE);
			reportRawData.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_ADD_SUCCESS));
			
			//TODO 
			/*
			 * Verify Performance based on JSON table START
			 */
			//Long jsonVisitorDataRawId = generateJsonVisitorRawDataId();
			//hs.put("JSON_VISITOR_DATA_RAW_ID", jsonVisitorDataRawId.toString());
			//userAction.addJsonVisitorRawData(hs);
			/*
			 * Verify Performance based on JSON table END
			 */
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			reportRawData.setSuccess(Boolean.FALSE);
			reportRawData.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
		}
		return reportRawData;
	}
	
	public static Long generateVisitorRawDataId() throws Exception
	{
		Long visitorDataRawId = 0l;
		HashMap<String, String> hs = new HashMap<String,String>();
		try
		{
			DataObject dataObj = ZABModel.createRow(ReportRawDataConstants.VISITOR_DATA_RAW_IDGEN_CONSTANTS, VISITOR_DATA_RAW_IDGEN.TABLE, hs);
			visitorDataRawId = (Long)dataObj.getFirstValue(VISITOR_DATA_RAW_IDGEN.TABLE, VISITOR_DATA_RAW_IDGEN.VISITOR_DATA_RAW_ID);
		}catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			throw ex;
		}
		return visitorDataRawId;
	}
	
	public static Long generateJsonVisitorRawDataId() throws Exception
	{
		Long jsonVisitorDataRawId = 0l;
		HashMap<String, String> hs = new HashMap<String,String>();
		try
		{
			DataObject dataObj = ZABModel.createRow(ReportRawDataConstants.JSON_VISITOR_DATA_RAW_IDGEN_CONSTANTS, JSON_VISITOR_RAW_IDGEN.TABLE, hs);
			jsonVisitorDataRawId = (Long)dataObj.getFirstValue(JSON_VISITOR_RAW_IDGEN.TABLE, JSON_VISITOR_RAW_IDGEN.JSON_VISITOR_DATA_RAW_ID);
		}catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			throw ex;
		}
		return jsonVisitorDataRawId;
	}
	
	public static ReportRawData addGoalRawData(HashMap<String,String> hs)
	{
		ReportRawData reportRawData = new ReportRawData();
		try
		{
			Long goalDataRawId = generateGoalRawDataId();
			hs.put("GOAL_DATA_RAW_ID", goalDataRawId.toString());
			ZABUserBean userAction = (ZABUserBean)BeanUtil.lookup("ZABUserBean",ZABUtil.getCurrentUserDbSpace());
			userAction.addGoalRawData(hs);
			reportRawData.setSuccess(Boolean.TRUE);
			reportRawData.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_ADD_SUCCESS));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			reportRawData.setSuccess(Boolean.FALSE);
			reportRawData.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
		}
		return reportRawData;
	}
	public static Long generateGoalRawDataId() throws Exception
	{
		Long goalDataRawId = 0l;
		HashMap<String, String> hs = new HashMap<String,String>();
		try
		{
			DataObject dataObj = ZABModel.createRow(ReportRawDataConstants.GOAL_DATA_RAW_IDGEN_CONSTANTS, GOAL_DATA_RAW_IDGEN.TABLE, hs);
			goalDataRawId = (Long)dataObj.getFirstValue(GOAL_DATA_RAW_IDGEN.TABLE, GOAL_DATA_RAW_IDGEN.GOAL_DATA_RAW_ID);
		}catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			throw ex;
		}
		return goalDataRawId;
	}
	public static ReportRawData addTimeSpentRawData(Long visitorRawId, Long timeSpent)
	{
		ReportRawData reportRawData = new ReportRawData();
		try
		{
			ZABUserBean userAction = (ZABUserBean)BeanUtil.lookup("ZABUserBean",ZABUtil.getCurrentUserDbSpace());
			userAction.addTimeSpentRawData(visitorRawId,timeSpent);
			reportRawData.setSuccess(Boolean.TRUE);
			reportRawData.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_ADD_SUCCESS));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			reportRawData.setSuccess(Boolean.FALSE);
			reportRawData.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
		}
		return reportRawData;
	}
}
