//$Id$
package com.zoho.abtest.report;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.zoho.abtest.BROWSER_GOAL_REPORT_DAY;
import com.zoho.abtest.BROWSER_GOAL_REPORT_HOUR;
import com.zoho.abtest.BROWSER_VISIT_REPORT_HOUR;
import com.zoho.abtest.BROWSER_VISIT_REPORT_DAY;
import com.zoho.abtest.COOKIE_GOAL_REPORT_DAY;
import com.zoho.abtest.COOKIE_GOAL_REPORT_HOUR;
import com.zoho.abtest.COUNTRY_GOAL_REPORT_DAY;
import com.zoho.abtest.COUNTRY_GOAL_REPORT_HOUR;
import com.zoho.abtest.DAYOFWK_GOAL_REPORT_DAY;
import com.zoho.abtest.DAYOFWK_GOAL_REPORT_HOUR;
import com.zoho.abtest.DEVICE_GOAL_REPORT_DAY;
import com.zoho.abtest.DEVICE_GOAL_REPORT_HOUR;
import com.zoho.abtest.DEVICE_VISIT_REPORT_HOUR;
import com.zoho.abtest.DEVICE_VISIT_REPORT_DAY;
import com.zoho.abtest.COUNTRY_VISIT_REPORT_HOUR;
import com.zoho.abtest.COUNTRY_VISIT_REPORT_DAY;
import com.zoho.abtest.HOURODY_GOAL_REPORT_DAY;
import com.zoho.abtest.HOURODY_GOAL_REPORT_HOUR;
import com.zoho.abtest.JSVAR_GOAL_REPORT_DAY;
import com.zoho.abtest.JSVAR_GOAL_REPORT_HOUR;
import com.zoho.abtest.LANG_GOAL_REPORT_DAY;
import com.zoho.abtest.LANG_GOAL_REPORT_HOUR;
import com.zoho.abtest.LANG_VISIT_REPORT_HOUR;
import com.zoho.abtest.LANG_VISIT_REPORT_DAY;
import com.zoho.abtest.OS_GOAL_REPORT_DAY;
import com.zoho.abtest.OS_GOAL_REPORT_HOUR;
import com.zoho.abtest.OS_VISIT_REPORT_HOUR;
import com.zoho.abtest.OS_VISIT_REPORT_DAY;
import com.zoho.abtest.REFURL_GOAL_REPORT_DAY;
import com.zoho.abtest.REFURL_GOAL_REPORT_HOUR;
import com.zoho.abtest.TRAFSOUR_GOAL_REPORT_DAY;
import com.zoho.abtest.TRAFSOUR_GOAL_REPORT_HOUR;
import com.zoho.abtest.TRAFSOUR_VISIT_REPORT_HOUR;
import com.zoho.abtest.TRAFSOUR_VISIT_REPORT_DAY;
import com.zoho.abtest.REFURL_VISIT_REPORT_HOUR;
import com.zoho.abtest.REFURL_VISIT_REPORT_DAY;
import com.zoho.abtest.DAYOFWK_VISIT_REPORT_HOUR;
import com.zoho.abtest.DAYOFWK_VISIT_REPORT_DAY;
import com.zoho.abtest.HOURODY_VISIT_REPORT_HOUR;
import com.zoho.abtest.HOURODY_VISIT_REPORT_DAY;
import com.zoho.abtest.COOKIE_VISIT_REPORT_HOUR;
import com.zoho.abtest.COOKIE_VISIT_REPORT_DAY;
import com.zoho.abtest.URLPARM_GOAL_REPORT_DAY;
import com.zoho.abtest.URLPARM_GOAL_REPORT_HOUR;
import com.zoho.abtest.URLPARM_VISIT_REPORT_HOUR;
import com.zoho.abtest.URLPARM_VISIT_REPORT_DAY;
import com.zoho.abtest.JSVAR_VISIT_REPORT_HOUR;
import com.zoho.abtest.JSVAR_VISIT_REPORT_DAY;
import com.zoho.abtest.CUSTDIM_GOAL_REPORT_HOUR;
import com.zoho.abtest.CUSTDIM_GOAL_REPORT_DAY;
import com.zoho.abtest.CUSTDIM_VISIT_REPORT_HOUR;
import com.zoho.abtest.CUSTDIM_VISIT_REPORT_DAY;
import com.zoho.abtest.ARCHIEVE_TABLE_META;
import com.zoho.abtest.ARCHIEVE_CUM_TABLE_META;
import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.ZABConstants;

public class ReportArchieveDimensionConstants {
	
	public static final String EXPERIMENT_ID = "experiment_id"; //No I18N
	public static final String VARIATION_ID = "variation_id"; //NO I18N
	public static final String GOAL_ID = "goal_id"; //NO I18N
	public static final String CODE = "code"; //NO I18N
	public static final String UNIQUE_COUNT = "unique_count"; //NO I18N
	public static final String CUMULATIVE_COUNT = "cumulative_count"; //NO I18N
	public static final String TOTAL_COUNT = "total_count"; //NO I18N
	public static final String TIME = "time"; //NO I18N
	public static final String DATE = "date"; //NO I18N
	
	public static final String UNIQUE_VISITOR_COUNT = "unique_visitor_count"; //NO I18N
	public static final String TOTAL_VISITOR_COUNT = "total_visitor_count"; //NO I18N
	public static final String FORECAST_VISITOR_COUNT = "forecast_visitor_count"; //NO I18N
	
	public static final String TOTAL_GOAL_ACHIEVED_COUNT = "total_goal_achieved_count"; //NO I18N
	public static final String UNIQUE_GOAL_ACHIEVED_COUNT = "unique_goal_achieved_count"; //NO I18N
	public static final String FORECAST_GOAL_ACHIEVED_COUNT = "forecast_goal_achieved_count"; //NO I18N
	
	public static final String VISITOR_COUNT = "visitor_count"; //NO I18N
	public static final String GOAL_COUNT = "goal_count"; //NO I18N

	public static final String CUMULATIVE_VISITOR_COUNT = "cumulative_visitor_count"; //NO I18N
	public static final String CUMULATIVE_GOAL_COUNT = "cumulative_goal_count"; //NO I18N
	public static final String CONVERSION_RATE = "conversion_rate"; //NO I18N
	
	public static final String UNIQUECOUNT_FLAG = "uniquecount_flag"; //NO I18N
	public static final String TOTALCOUNT_FLAG = "totalcount_flag"; //NO I18N
	
	public static final String VISITOR_ID = "visitor_id"; //NO I18N
	
	public static final String ARCHIEVE_TABLE_ID = "archieve_table_id"; //No I18N
	public static final String ARCHIEVE_CUM_TABLE_ID = "archieve_cum_table_id"; //No I18N
	public static final String COLUMN_NAME = "column_name"; //No I18N
	public static final String GROUP_BY_COLUMNS = "group_by_columns"; //No I18N
	public static final String RESULT_ARCHIEVE_TABLE = "result_archieve_table"; //No I18N
	public static final String VISITOR_IDS_TABLE = "visitor_ids_table"; //No I18N
	public static final String DURATION_TYPE = "duration_type"; //No I18N
	public static final String MODULE_TYPE = "module_type"; //No I18N
	public static final String LAST_ARCHIEVED_TIME = "last_archieved_time"; //No I18N
	public static final String TIME_SPENT = "time_spent"; //No I18N
	public static final String TIME_SPENT_ON_PAGE = "time_spent_page"; //No I18N
	public static final String TIME_SPENT_SECONDS = "time_spent_seconds"; //No I18N
	public static final String TIME_SPENT_ON_PAGE_SECONDS = "time_spent_page_seconds"; //No I18N
	
	public static final String BROWSER_VISIT_REPORT_HOUR_ID = "browser_visit_report_hour_id"; //NO I18N
	public static final String BROWSER_VISIT_REPORT_DAY_ID = "browser_visit_report_day_id"; //NO I18N
	
	public static final String DEVICE_VISIT_REPORT_HOUR_ID = "device_visit_report_hour_id"; //NO I18N
	public static final String DEVICE_VISIT_REPORT_DAY_ID = "device_visit_report_day_id"; //NO I18N
	
	public static final String COUNTRY_VISIT_REPORT_HOUR_ID = "country_visit_report_hour_id"; //NO I18N
	public static final String COUNTRY_VISIT_REPORT_DAY_ID = "country_visit_report_day_id"; //NO I18N
	
	public static final String LANG_VISIT_REPORT_HOUR_ID = "lang_visit_report_hour_id"; //NO I18N
	public static final String LANG_VISIT_REPORT_DAY_ID = "lang_visit_report_day_id"; //NO I18N
	
	public static final String OS_VISIT_REPORT_HOUR_ID = "os_visit_report_hour_id"; //NO I18N
	public static final String OS_VISIT_REPORT_DAY_ID = "os_visit_report_day_id"; //NO I18N
	
	public static final String TRAFSOUR_VISIT_REPORT_HOUR_ID = "trafsour_visit_report_hour_id"; //NO I18N
	public static final String TRAFSOUR_VISIT_REPORT_DAY_ID = "trafsour_visit_report_day_id"; //NO I18N
	
	public static final String REFURL_VISIT_REPORT_HOUR_ID = "refurl_visit_report_hour_id"; //NO I18N
	public static final String REFURL_VISIT_REPORT_DAY_ID = "refurl_visit_report_day_id"; //NO I18N
	
	public static final String DAYOFWK_VISIT_REPORT_HOUR_ID = "dayofwk_visit_report_hour_id"; //NO I18N
	public static final String DAYOFWK_VISIT_REPORT_DAY_ID = "dayofwk_visit_report_day_id"; //NO I18N
	
	public static final String HOURODY_VISIT_REPORT_HOUR_ID = "hourody_visit_report_hour_id"; //NO I18N
	public static final String HOURODY_VISIT_REPORT_DAY_ID = "hourody_visit_report_day_id"; //NO I18N
	
	public static final String COOKIE_VISIT_REPORT_HOUR_ID = "cookie_visit_report_hour_id"; //NO I18N
	public static final String COOKIE_VISIT_REPORT_DAY_ID = "cookie_visit_report_day_id"; //NO I18N
	
	public static final String URLPARM_VISIT_REPORT_HOUR_ID = "urlparm_visit_report_hour_id"; //NO I18N
	public static final String URLPARM_VISIT_REPORT_DAY_ID = "urlparm_visit_report_day_id"; //NO I18N
	
	public static final String JSVAR_VISIT_REPORT_HOUR_ID = " jsvar_visit_report_hour_id"; //NO I18N
	public static final String JSVAR_VISIT_REPORT_DAY_ID = "jsvar_visit_report_day_id"; //NO I18N
	
	public static final String CUSTDIM_VISIT_REPORT_HOUR_ID = " custdim_visit_report_hour_id"; //NO I18N
	public static final String CUSTDIM_VISIT_REPORT_DAY_ID = " custdim_visit_report_day_id"; //NO I18N

	public static final String BROWSER_GOAL_REPORT_HOUR_ID = " browser_goal_report_hour_id"; //NO I18N
	public static final String BROWSER_GOAL_REPORT_DAY_ID = " browser_goal_report_day_id"; //NO I18N

	public static final String DEVICE_GOAL_REPORT_HOUR_ID = " device_goal_report_hour_id"; //NO I18N
	public static final String DEVICE_GOAL_REPORT_DAY_ID = " device_goal_report_day_id"; //NO I18N

	public static final String COUNTRY_GOAL_REPORT_HOUR_ID = " country_goal_report_hour_id"; //NO I18N
	public static final String COUNTRY_GOAL_REPORT_DAY_ID = " country_goal_report_day_id"; //NO I18N

	public static final String LANG_GOAL_REPORT_HOUR_ID = " lang_goal_report_hour_id"; //NO I18N
	public static final String LANG_GOAL_REPORT_DAY_ID = " lang_goal_report_day_id"; //NO I18N

	public static final String OS_GOAL_REPORT_HOUR_ID = " os_goal_report_hour_id"; //NO I18N
	public static final String OS_GOAL_REPORT_DAY_ID = " os_goal_report_day_id"; //NO I18N

	public static final String TRAFSOUR_GOAL_REPORT_HOUR_ID = " trafsour_goal_report_hour_id"; //NO I18N
	public static final String TRAFSOUR_GOAL_REPORT_DAY_ID = " trafsour_goal_report_day_id"; //NO I18N

	public static final String REFURL_GOAL_REPORT_HOUR_ID = " refurl_goal_report_hour_id"; //NO I18N
	public static final String REFURL_GOAL_REPORT_DAY_ID = " refurl_goal_report_day_id"; //NO I18N

	public static final String DAYOFWK_GOAL_REPORT_HOUR_ID = " dayofwk_goal_report_hour_id"; //NO I18N
	public static final String DAYOFWK_GOAL_REPORT_DAY_ID = " dayofwk_goal_report_day_id"; //NO I18N

	public static final String HOURODY_GOAL_REPORT_HOUR_ID = " hourody_goal_report_hour_id"; //NO I18N
	public static final String HOURODY_GOAL_REPORT_DAY_ID = " hourody_goal_report_day_id"; //NO I18N

	public static final String COOKIE_GOAL_REPORT_HOUR_ID = " cookie_goal_report_hour_id"; //NO I18N
	public static final String COOKIE_GOAL_REPORT_DAY_ID = " cookie_goal_report_day_id"; //NO I18N

	public static final String URLPARM_GOAL_REPORT_HOUR_ID = " urlparm_goal_report_hour_id"; //NO I18N
	public static final String URLPARM_GOAL_REPORT_DAY_ID = " urlparm_goal_report_day_id"; //NO I18N
	
	public static final String JSVAR_GOAL_REPORT_HOUR_ID = " jsvar_goal_report_hour_id"; //NO I18N
	public static final String JSVAR_GOAL_REPORT_DAY_ID = " jsvar_goal_report_day_id"; //NO I18N
	
	public static final String CUSTDIM_GOAL_REPORT_HOUR_ID = " custdim_goal_report_hour_id"; //NO I18N
	public static final String CUSTDIM_GOAL_REPORT_DAY_ID = " custdim_goal_report_day_id"; //NO I18N

	public static final String DYNAMIC_ATTRIBUTE_ID = "dynamic_attribute_id"; //NO I18N
	public static final String IS_STANDARD_DIMENSION = "is_standard_dimension"; //NO I18N
	
	public static final String HOUR_ENUM_STRING = "HOUR";  //NO I18N
	public static final String DAY_ENUM_STRING = "DAY";  //NO I18N
	
	public static final String VISIT_MODULE = "VISIT";  //NO I18N
	public static final String GOAL_ACHIEVED_MODULE = "GOALACHIEVED";  //NO I18N
	public static final String HEATMAP_DATA_MODULE = "HEATMAPDATA";  //NO I18N
	public static final String SCROLLMAP_DATA_MODULE = "SCROLLMAPDATA";  //NO I18N
	public static final String FUNNEL_DATA_MODULE = "FUNNELDATA";  //NO I18N
	
	public static final String COOKIE_JSON = "COOKIE_JSON";  //NO I18N
	public static final String URLPARAM_JSON = "URLPARAM_JSON";  //NO I18N
	public static final String JS_VARIABLE_JSON = "JS_VARIABLE_JSON";  //NO I18N
	public static final String CUSTOM_DIMENSION_JSON = "CUSTOM_DIMENSION_JSON";  //NO I18N
	
	public static final String START_HOUR_IN_MILLIS = "startHourInMs";  //NO I18N
	public static final String END_HOUR_IN_MILLIS = "endHourInMs";  //NO I18N
	
	public enum ReportDurationType
	{
		HOUR(HOUR_ENUM_STRING,1),
		DAY(DAY_ENUM_STRING,2);
		
		private String durationValue;
		private Integer durationCode;
		
		public Integer getDurationCode() {
			return durationCode;
		}
		public void setDurationCode(Integer durationCode) {
			this.durationCode = durationCode;
		}
		public String getDurationValue() {
			return durationValue;
		}
		public void setDurationValue(String durationValue) {
			this.durationValue = durationValue;
		}
		
		private ReportDurationType(String durationValue,Integer durationCode)
		{
			this.durationValue = durationValue;
			this.durationCode = durationCode;
		}
	}
	
	public enum ReportModuleType
	{
		VISIT(VISIT_MODULE,1),
		GOALACHIEVED(GOAL_ACHIEVED_MODULE,2),
		HEATMAPDATA(HEATMAP_DATA_MODULE,3),
		SCROLLMAPDATA(SCROLLMAP_DATA_MODULE,4),
		FUNNELDATA(FUNNEL_DATA_MODULE,5);
		
		private String moduleValue;
		private Integer moduleCode;
		
		public String getModuleValue() {
			return moduleValue;
		}
		public void setModuleValue(String moduleValue) {
			this.moduleValue = moduleValue;
		}
		public Integer getModuleCode() {
			return moduleCode;
		}
		public void setModuleCode(Integer moduleCode) {
			this.moduleCode = moduleCode;
		}
		
		private ReportModuleType(String moduleValue, Integer moduleCode)
		{
			this.moduleValue = moduleValue;
			this.moduleCode = moduleCode;
		}
	}
	
	public enum ArchieveTableMetaValues
	{
		BROWSER_VISIT_REPORT_HOUR("BROWSER_CODE","EXPERIMENT_ID,VARIATION_ID","BROWSER_VISIT_REPORT_HOUR","BROWSER_VISIT_HOUR_VISITORS",ReportDurationType.HOUR.durationCode,ReportModuleType.VISIT.moduleCode,Boolean.TRUE), //No I18N
		BROWSER_VISIT_REPORT_DAY("BROWSER_CODE","EXPERIMENT_ID,VARIATION_ID","BROWSER_VISIT_REPORT_DAY","BROWSER_VISIT_DAY_VISITORS",ReportDurationType.DAY.durationCode,ReportModuleType.VISIT.moduleCode,Boolean.TRUE), //No I18N
		DEVICE_VISIT_REPORT_HOUR("DEVICE_CODE","EXPERIMENT_ID,VARIATION_ID","DEVICE_VISIT_REPORT_HOUR","DEVICE_VISIT_HOUR_VISITORS",ReportDurationType.HOUR.durationCode,ReportModuleType.VISIT.moduleCode,Boolean.TRUE), //No I18N
		DEVICE_VISIT_REPORT_DAY("DEVICE_CODE","EXPERIMENT_ID,VARIATION_ID","DEVICE_VISIT_REPORT_DAY","DEVICE_VISIT_DAY_VISITORS",ReportDurationType.DAY.durationCode,ReportModuleType.VISIT.moduleCode,Boolean.TRUE), //No I18N
		COUNTRY_VISIT_REPORT_HOUR("COUNTRY_CODE","EXPERIMENT_ID,VARIATION_ID","COUNTRY_VISIT_REPORT_HOUR","COUNTRY_VISIT_HOUR_VISITORS",ReportDurationType.HOUR.durationCode,ReportModuleType.VISIT.moduleCode,Boolean.TRUE), //No I18N
		COUNTRY_VISIT_REPORT_DAY("COUNTRY_CODE","EXPERIMENT_ID,VARIATION_ID","COUNTRY_VISIT_REPORT_DAY","COUNTRY_VISIT_DAY_VISITORS",ReportDurationType.DAY.durationCode,ReportModuleType.VISIT.moduleCode,Boolean.TRUE), //No I18N
		LANG_VISIT_REPORT_HOUR("LANGUAGE_CODE","EXPERIMENT_ID,VARIATION_ID","LANG_VISIT_REPORT_HOUR","LANG_VISIT_HOUR_VISITORS",ReportDurationType.HOUR.durationCode,ReportModuleType.VISIT.moduleCode,Boolean.TRUE), //No I18N
		LANG_VISIT_REPORT_DAY("LANGUAGE_CODE","EXPERIMENT_ID,VARIATION_ID","LANG_VISIT_REPORT_DAY","LANG_VISIT_DAY_VISITORS",ReportDurationType.DAY.durationCode,ReportModuleType.VISIT.moduleCode,Boolean.TRUE), //No I18N
		OS_VISIT_REPORT_HOUR("OS_CODE","EXPERIMENT_ID,VARIATION_ID","OS_VISIT_REPORT_HOUR","OS_VISIT_HOUR_VISITORS",ReportDurationType.HOUR.durationCode,ReportModuleType.VISIT.moduleCode,Boolean.TRUE), //No I18N
		OS_VISIT_REPORT_DAY("OS_CODE","EXPERIMENT_ID,VARIATION_ID","OS_VISIT_REPORT_DAY","OS_VISIT_DAY_VISITORS",ReportDurationType.DAY.durationCode,ReportModuleType.VISIT.moduleCode,Boolean.TRUE), //No I18N
		TRAFSOUR_VISIT_REPORT_HOUR("TRAFFICSOURCE_CODE","EXPERIMENT_ID,VARIATION_ID","TRAFSOUR_VISIT_REPORT_HOUR","TRAFSOUR_VISIT_HOUR_VISITORS",ReportDurationType.HOUR.durationCode,ReportModuleType.VISIT.moduleCode,Boolean.TRUE), //No I18N
		TRAFSOUR_VISIT_REPORT_DAY("TRAFFICSOURCE_CODE","EXPERIMENT_ID,VARIATION_ID","TRAFSOUR_VISIT_REPORT_DAY","TRAFSOUR_VISIT_DAY_VISITORS",ReportDurationType.DAY.durationCode,ReportModuleType.VISIT.moduleCode,Boolean.TRUE), //No I18N
		REFURL_VISIT_REPORT_HOUR("REFFERERURL_CODE","EXPERIMENT_ID,VARIATION_ID","REFURL_VISIT_REPORT_HOUR","REFURL_VISIT_HOUR_VISITORS",ReportDurationType.HOUR.durationCode,ReportModuleType.VISIT.moduleCode,Boolean.TRUE), //No I18N
		REFURL_VISIT_REPORT_DAY("REFFERERURL_CODE","EXPERIMENT_ID,VARIATION_ID","REFURL_VISIT_REPORT_DAY","REFUR_VISIT_DAY_VISITORS",ReportDurationType.DAY.durationCode,ReportModuleType.VISIT.moduleCode,Boolean.TRUE), //No I18N
		DAYOFWK_VISIT_REPORT_HOUR("DAYOFWEEK_CODE","EXPERIMENT_ID,VARIATION_ID","DAYOFWK_VISIT_REPORT_HOUR","DAYOFWK_VISIT_HOUR_VISITORS",ReportDurationType.HOUR.durationCode,ReportModuleType.VISIT.moduleCode,Boolean.TRUE), //No I18N
		DAYOFWK_VISIT_REPORT_DAY("DAYOFWEEK_CODE","EXPERIMENT_ID,VARIATION_ID","DAYOFWK_VISIT_REPORT_DAY","DAYOFWK_VISIT_DAY_VISITORS",ReportDurationType.DAY.durationCode,ReportModuleType.VISIT.moduleCode,Boolean.TRUE), //No I18N
		HOURODY_VISIT_REPORT_HOUR("HOUROFDAY_CODE","EXPERIMENT_ID,VARIATION_ID","HOURODY_VISIT_REPORT_HOUR","HOURODY_VISIT_HOUR_VISITORS",ReportDurationType.HOUR.durationCode,ReportModuleType.VISIT.moduleCode,Boolean.TRUE), //No I18N
		HOURODY_VISIT_REPORT_DAY("HOUROFDAY_CODE","EXPERIMENT_ID,VARIATION_ID","HOURODY_VISIT_REPORT_DAY","HOURODY_VISIT_DAY_VISITORS",ReportDurationType.DAY.durationCode,ReportModuleType.VISIT.moduleCode,Boolean.TRUE), //No I18N
		COOKIE_VISIT_REPORT_HOUR(COOKIE_JSON,"EXPERIMENT_ID,VARIATION_ID","COOKIE_VISIT_REPORT_HOUR","COOKIE_VISIT_HOUR_VISITORS",ReportDurationType.HOUR.durationCode,ReportModuleType.VISIT.moduleCode,Boolean.FALSE), //No I18N
		COOKIE_VISIT_REPORT_DAY(COOKIE_JSON,"EXPERIMENT_ID,VARIATION_ID","COOKIE_VISIT_REPORT_DAY","COOKIE_VISIT_DAY_VISITORS",ReportDurationType.DAY.durationCode,ReportModuleType.VISIT.moduleCode,Boolean.FALSE), //No I18N
		URLPARM_VISIT_REPORT_HOUR(URLPARAM_JSON,"EXPERIMENT_ID,VARIATION_ID","URLPARM_VISIT_REPORT_HOUR","URLPARM_VISIT_HOUR_VISITORS",ReportDurationType.HOUR.durationCode,ReportModuleType.VISIT.moduleCode,Boolean.FALSE), //No I18N
		URLPARM_VISIT_REPORT_DAY(URLPARAM_JSON,"EXPERIMENT_ID,VARIATION_ID","URLPARM_VISIT_REPORT_DAY","URLPARM_VISIT_DAY_VISITORS",ReportDurationType.DAY.durationCode,ReportModuleType.VISIT.moduleCode,Boolean.FALSE), //No I18N
		JSVAR_VISIT_REPORT_HOUR(JS_VARIABLE_JSON,"EXPERIMENT_ID,VARIATION_ID","JSVAR_VISIT_REPORT_HOUR","JSVAR_VISIT_HOUR_VISITORS",ReportDurationType.HOUR.durationCode,ReportModuleType.VISIT.moduleCode,Boolean.FALSE), //No I18N
		JSVAR_VISIT_REPORT_DAY(JS_VARIABLE_JSON,"EXPERIMENT_ID,VARIATION_ID","JSVAR_VISIT_REPORT_DAY","JSVAR_VISIT_DAY_VISITORS",ReportDurationType.DAY.durationCode,ReportModuleType.VISIT.moduleCode,Boolean.FALSE), //No I18N
		CUSTDIM_VISIT_REPORT_HOUR(CUSTOM_DIMENSION_JSON,"EXPERIMENT_ID,VARIATION_ID","CUSTDIM_VISIT_REPORT_HOUR","CUSTDIM_VISIT_HOUR_VISITORS",ReportDurationType.HOUR.durationCode,ReportModuleType.VISIT.moduleCode,Boolean.FALSE), //No I18N
		CUSTDIM_VISIT_REPORT_DAY(CUSTOM_DIMENSION_JSON,"EXPERIMENT_ID,VARIATION_ID","CUSTDIM_VISIT_REPORT_DAY","CUSTDIM_VISIT_DAY_VISITORS",ReportDurationType.DAY.durationCode,ReportModuleType.VISIT.moduleCode,Boolean.FALSE), //No I18N

		BROWSER_GOAL_REPORT_HOUR("BROWSER_CODE","EXPERIMENT_ID,VARIATION_ID,GOAL_ID","BROWSER_GOAL_REPORT_HOUR","BROWSER_GOAL_HOUR_VISITORS",ReportDurationType.HOUR.durationCode,ReportModuleType.GOALACHIEVED.moduleCode,Boolean.TRUE), //No I18N
		BROWSER_GOAL_REPORT_DAY("BROWSER_CODE","EXPERIMENT_ID,VARIATION_ID,GOAL_ID","BROWSER_GOAL_REPORT_DAY","BROWSER_GOAL_DAY_VISITORS",ReportDurationType.DAY.durationCode,ReportModuleType.GOALACHIEVED.moduleCode,Boolean.TRUE), //No I18N
		DEVICE_GOAL_REPORT_HOUR("DEVICE_CODE","EXPERIMENT_ID,VARIATION_ID,GOAL_ID","DEVICE_GOAL_REPORT_HOUR","DEVICE_GOAL_HOUR_VISITORS",ReportDurationType.HOUR.durationCode,ReportModuleType.GOALACHIEVED.moduleCode,Boolean.TRUE), //No I18N
		DEVICE_GOAL_REPORT_DAY("DEVICE_CODE","EXPERIMENT_ID,VARIATION_ID,GOAL_ID","DEVICE_GOAL_REPORT_DAY","DEVICE_GOAL_DAY_VISITORS",ReportDurationType.DAY.durationCode,ReportModuleType.GOALACHIEVED.moduleCode,Boolean.TRUE), //No I18N
		COUNTRY_GOAL_REPORT_HOUR("COUNTRY_CODE","EXPERIMENT_ID,VARIATION_ID,GOAL_ID","COUNTRY_GOAL_REPORT_HOUR","COUNTRY_GOAL_HOUR_VISITORS",ReportDurationType.HOUR.durationCode,ReportModuleType.GOALACHIEVED.moduleCode,Boolean.TRUE), //No I18N
		COUNTRY_GOAL_REPORT_DAY("COUNTRY_CODE","EXPERIMENT_ID,VARIATION_ID,GOAL_ID","COUNTRY_GOAL_REPORT_DAY","COUNTRY_GOAL_DAY_VISITORS",ReportDurationType.DAY.durationCode,ReportModuleType.GOALACHIEVED.moduleCode,Boolean.TRUE), //No I18N
		LANG_GOAL_REPORT_HOUR("LANGUAGE_CODE","EXPERIMENT_ID,VARIATION_ID,GOAL_ID","LANG_GOAL_REPORT_HOUR","LANG_GOAL_HOUR_VISITORS",ReportDurationType.HOUR.durationCode,ReportModuleType.GOALACHIEVED.moduleCode,Boolean.TRUE), //No I18N
		LANG_GOAL_REPORT_DAY("LANGUAGE_CODE","EXPERIMENT_ID,VARIATION_ID,GOAL_ID","LANG_GOAL_REPORT_DAY","LANG_GOAL_DAY_VISITORS",ReportDurationType.DAY.durationCode,ReportModuleType.GOALACHIEVED.moduleCode,Boolean.TRUE), //No I18N
		OS_GOAL_REPORT_HOUR("OS_CODE","EXPERIMENT_ID,VARIATION_ID,GOAL_ID","OS_GOAL_REPORT_HOUR","OS_GOAL_HOUR_VISITORS",ReportDurationType.HOUR.durationCode,ReportModuleType.GOALACHIEVED.moduleCode,Boolean.TRUE), //No I18N
		OS_GOAL_REPORT_DAY("OS_CODE","EXPERIMENT_ID,VARIATION_ID,GOAL_ID","OS_GOAL_REPORT_DAY","OS_GOAL_DAY_VISITORS",ReportDurationType.DAY.durationCode,ReportModuleType.GOALACHIEVED.moduleCode,Boolean.TRUE), //No I18N
		TRAFSOUR_GOAL_REPORT_HOUR("TRAFFICSOURCE_CODE","EXPERIMENT_ID,VARIATION_ID,GOAL_ID","TRAFSOUR_GOAL_REPORT_HOUR","TRAFSOUR_GOAL_HOUR_VISITORS",ReportDurationType.HOUR.durationCode,ReportModuleType.GOALACHIEVED.moduleCode,Boolean.TRUE), //No I18N
		TRAFSOUR_GOAL_REPORT_DAY("TRAFFICSOURCE_CODE","EXPERIMENT_ID,VARIATION_ID,GOAL_ID","TRAFSOUR_GOAL_REPORT_DAY","TRAFSOUR_GOAL_DAY_VISITORS",ReportDurationType.DAY.durationCode,ReportModuleType.GOALACHIEVED.moduleCode,Boolean.TRUE), //No I18N
		REFURL_GOAL_REPORT_HOUR("REFFERERURL_CODE","EXPERIMENT_ID,VARIATION_ID,GOAL_ID","REFURL_GOAL_REPORT_HOUR","REFURL_GOAL_HOUR_VISITORS",ReportDurationType.HOUR.durationCode,ReportModuleType.GOALACHIEVED.moduleCode,Boolean.TRUE), //No I18N
		REFURL_GOAL_REPORT_DAY("REFFERERURL_CODE","EXPERIMENT_ID,VARIATION_ID,GOAL_ID","REFURL_GOAL_REPORT_DAY","REFURL_GOAL_DAY_VISITORS",ReportDurationType.DAY.durationCode,ReportModuleType.GOALACHIEVED.moduleCode,Boolean.TRUE), //No I18N
		DAYOFWK_GOAL_REPORT_HOUR("DAYOFWEEK_CODE","EXPERIMENT_ID,VARIATION_ID,GOAL_ID","DAYOFWK_GOAL_REPORT_HOUR","DAYOFWK_GOAL_HOUR_VISITORS",ReportDurationType.HOUR.durationCode,ReportModuleType.GOALACHIEVED.moduleCode,Boolean.TRUE), //No I18N
		DAYOFWK_GOAL_REPORT_DAY("DAYOFWEEK_CODE","EXPERIMENT_ID,VARIATION_ID,GOAL_ID","DAYOFWK_GOAL_REPORT_DAY","DAYOFWK_GOAL_DAY_VISITORS",ReportDurationType.DAY.durationCode,ReportModuleType.GOALACHIEVED.moduleCode,Boolean.TRUE), //No I18N
		HOURODY_GOAL_REPORT_HOUR("HOUROFDAY_CODE","EXPERIMENT_ID,VARIATION_ID,GOAL_ID","HOURODY_GOAL_REPORT_HOUR","HOURODY_GOAL_HOUR_VISITORS",ReportDurationType.HOUR.durationCode,ReportModuleType.GOALACHIEVED.moduleCode,Boolean.TRUE), //No I18N
		HOURODY_GOAL_REPORT_DAY("HOUROFDAY_CODE","EXPERIMENT_ID,VARIATION_ID,GOAL_ID","HOURODY_GOAL_REPORT_DAY","HOURODY_GOAL_DAY_VISITORS",ReportDurationType.DAY.durationCode,ReportModuleType.GOALACHIEVED.moduleCode,Boolean.TRUE), //No I18N
		COOKIE_GOAL_REPORT_HOUR(COOKIE_JSON,"EXPERIMENT_ID,VARIATION_ID,GOAL_ID","COOKIE_GOAL_REPORT_HOUR","COOKIE_GOAL_HOUR_VISITORS",ReportDurationType.HOUR.durationCode,ReportModuleType.GOALACHIEVED.moduleCode,Boolean.FALSE), //No I18N
		COOKIE_GOAL_REPORT_DAY(COOKIE_JSON,"EXPERIMENT_ID,VARIATION_ID,GOAL_ID","COOKIE_GOAL_REPORT_DAY","COOKIE_GOAL_DAY_VISITORS",ReportDurationType.DAY.durationCode,ReportModuleType.GOALACHIEVED.moduleCode,Boolean.FALSE), //No I18N
		URLPARM_GOAL_REPORT_HOUR(URLPARAM_JSON,"EXPERIMENT_ID,VARIATION_ID,GOAL_ID","URLPARM_GOAL_REPORT_HOUR","URLPARM_GOAL_HOUR_VISITORS",ReportDurationType.HOUR.durationCode,ReportModuleType.GOALACHIEVED.moduleCode,Boolean.FALSE), //No I18N
		URLPARM_GOAL_REPORT_DAY(URLPARAM_JSON,"EXPERIMENT_ID,VARIATION_ID,GOAL_ID","URLPARM_GOAL_REPORT_DAY","URLPARM_GOAL_DAY_VISITORS",ReportDurationType.DAY.durationCode,ReportModuleType.GOALACHIEVED.moduleCode,Boolean.FALSE), //No I18N
		JSVAR_GOAL_REPORT_HOUR(JS_VARIABLE_JSON,"EXPERIMENT_ID,VARIATION_ID,GOAL_ID","JSVAR_GOAL_REPORT_HOUR","JSVAR_GOAL_HOUR_VISITORS",ReportDurationType.HOUR.durationCode,ReportModuleType.GOALACHIEVED.moduleCode,Boolean.FALSE), //No I18N
		JSVAR_GOAL_REPORT_DAY(JS_VARIABLE_JSON,"EXPERIMENT_ID,VARIATION_ID,GOAL_ID","JSVAR_GOAL_REPORT_DAY","JSVAR_GOAL_DAY_VISITORS",ReportDurationType.DAY.durationCode,ReportModuleType.GOALACHIEVED.moduleCode,Boolean.FALSE), //No I18N
		CUSTDIM_GOAL_REPORT_HOUR(CUSTOM_DIMENSION_JSON,"EXPERIMENT_ID,VARIATION_ID,GOAL_ID","CUSTDIM_GOAL_REPORT_HOUR","CUSTDIM_GOAL_HOUR_VISITORS",ReportDurationType.HOUR.durationCode,ReportModuleType.GOALACHIEVED.moduleCode,Boolean.FALSE), //No I18N
		CUSTDIM_GOAL_REPORT_DAY(CUSTOM_DIMENSION_JSON,"EXPERIMENT_ID,VARIATION_ID,GOAL_ID","CUSTDIM_GOAL_REPORT_DAY","CUSTDIM_GOAL_DAY_VISITORS",ReportDurationType.DAY.durationCode,ReportModuleType.GOALACHIEVED.moduleCode,Boolean.FALSE); //No I18N
		
		String columnName;
		String groupByColumns;
		String resultArchieveTable;
		String visitorIdsTable;
		Integer durationType;
		Integer moduleType;
		Boolean isStandardDimension;
		
		public Boolean getIsStandardDimension() {
			return isStandardDimension;
		}
		public void setIsStandardDimension(Boolean isStandardDimension) {
			this.isStandardDimension = isStandardDimension;
		}
		public String getColumnName() {
			return columnName;
		}
		public void setColumnName(String columnName) {
			this.columnName = columnName;
		}
		public String getGroupByColumns() {
			return groupByColumns;
		}
		public void setGroupByColumns(String groupByColumns) {
			this.groupByColumns = groupByColumns;
		}
		public String getResultArchieveTable() {
			return resultArchieveTable;
		}
		public void setResultArchieveTable(String resultArchieveTable) {
			this.resultArchieveTable = resultArchieveTable;
		}
		public String getVisitorIdsTable() {
			return visitorIdsTable;
		}
		public void setVisitorIdsTable(String visitorIdsTable) {
			this.visitorIdsTable = visitorIdsTable;
		}
		public Integer getDurationType() {
			return durationType;
		}
		public void setDurationType(Integer durationType) {
			this.durationType = durationType;
		}
		public Integer getModuleType() {
			return moduleType;
		}
		public void setModuleType(Integer moduleType) {
			this.moduleType = moduleType;
		}
		
		private ArchieveTableMetaValues(String columnName,String groupByColumns,String resultArchieveTable,String visitorIdsTable,Integer durationType,Integer moduleType,Boolean isStandardDimension)
		{
			this.columnName = columnName;
			this.groupByColumns = groupByColumns;
			this.resultArchieveTable = resultArchieveTable;
			this.visitorIdsTable = visitorIdsTable;
			this.durationType = durationType;
			this.moduleType = moduleType;
			this.isStandardDimension = isStandardDimension;
		}
	}
	
	
	public static final List<Constants> ARCHIEVE_TABLE_META_CONSTANTS;
	
	static{
		List<Constants> archieveTableMetaConstants = new ArrayList<Constants>();
		archieveTableMetaConstants.add(new Constants(ARCHIEVE_TABLE_ID,ARCHIEVE_TABLE_META.ARCHIEVE_TABLE_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(COLUMN_NAME,ARCHIEVE_TABLE_META.COLUMN_NAME,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(GROUP_BY_COLUMNS,ARCHIEVE_TABLE_META.GROUP_BY_COLUMNS,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(RESULT_ARCHIEVE_TABLE,ARCHIEVE_TABLE_META.RESULT_ARCHIEVE_TABLE,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(VISITOR_IDS_TABLE,ARCHIEVE_TABLE_META.VISITOR_IDS_TABLE,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(DURATION_TYPE,ARCHIEVE_TABLE_META.DURATION_TYPE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(MODULE_TYPE,ARCHIEVE_TABLE_META.MODULE_TYPE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(LAST_ARCHIEVED_TIME,ARCHIEVE_TABLE_META.LAST_ARCHIEVED_TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.TRUE));
		archieveTableMetaConstants.add(new Constants(IS_STANDARD_DIMENSION,ARCHIEVE_TABLE_META.IS_STANDARD_DIMENSION,ZABConstants.BOOLEAN,Boolean.TRUE,Boolean.FALSE));
		ARCHIEVE_TABLE_META_CONSTANTS = Collections.unmodifiableList(archieveTableMetaConstants);
	}
	
	public static final List<Constants> ARCHIEVE_CUM_TABLE_META_CONSTANTS;
	
	static{
		List<Constants> archieveCumTableMetaConstants = new ArrayList<Constants>();
		archieveCumTableMetaConstants.add(new Constants(ARCHIEVE_CUM_TABLE_ID,ARCHIEVE_CUM_TABLE_META.ARCHIEVE_CUM_TABLE_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		archieveCumTableMetaConstants.add(new Constants(RESULT_ARCHIEVE_TABLE,ARCHIEVE_CUM_TABLE_META.RESULT_ARCHIEVE_TABLE,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
		archieveCumTableMetaConstants.add(new Constants(LAST_ARCHIEVED_TIME,ARCHIEVE_CUM_TABLE_META.LAST_ARCHIEVED_TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.TRUE));
		ARCHIEVE_CUM_TABLE_META_CONSTANTS = Collections.unmodifiableList(archieveCumTableMetaConstants);
	}
	
	public static final List<Constants> BROWSER_GOAL_REPORT_HOUR_CONSTANTS;
	
	static{
		List<Constants> browserGoalReportHourConstants = new ArrayList<Constants>();
		browserGoalReportHourConstants.add(new Constants(BROWSER_GOAL_REPORT_HOUR_ID,BROWSER_GOAL_REPORT_HOUR.BROWSER_GOAL_REPORT_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		browserGoalReportHourConstants.add(new Constants(EXPERIMENT_ID,BROWSER_GOAL_REPORT_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		browserGoalReportHourConstants.add(new Constants(VARIATION_ID,BROWSER_GOAL_REPORT_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		browserGoalReportHourConstants.add(new Constants(GOAL_ID,BROWSER_GOAL_REPORT_HOUR.GOAL_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		browserGoalReportHourConstants.add(new Constants(CODE,BROWSER_GOAL_REPORT_HOUR.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		browserGoalReportHourConstants.add(new Constants(TOTAL_COUNT,BROWSER_GOAL_REPORT_HOUR.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		browserGoalReportHourConstants.add(new Constants(TIME,BROWSER_GOAL_REPORT_HOUR.TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		BROWSER_GOAL_REPORT_HOUR_CONSTANTS = Collections.unmodifiableList(browserGoalReportHourConstants);
	}
	
	public static final List<Constants> BROWSER_GOAL_REPORT_DAY_CONSTANTS;
	
	static{
		List<Constants> browserGoalReportDayConstants = new ArrayList<Constants>();
		browserGoalReportDayConstants.add(new Constants(BROWSER_GOAL_REPORT_DAY_ID,BROWSER_GOAL_REPORT_DAY.BROWSER_GOAL_REPORT_DAY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		browserGoalReportDayConstants.add(new Constants(EXPERIMENT_ID,BROWSER_GOAL_REPORT_DAY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		browserGoalReportDayConstants.add(new Constants(VARIATION_ID,BROWSER_GOAL_REPORT_DAY.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		browserGoalReportDayConstants.add(new Constants(GOAL_ID,BROWSER_GOAL_REPORT_DAY.GOAL_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		browserGoalReportDayConstants.add(new Constants(CODE,BROWSER_GOAL_REPORT_DAY.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		browserGoalReportDayConstants.add(new Constants(TOTAL_COUNT,BROWSER_GOAL_REPORT_DAY.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		browserGoalReportDayConstants.add(new Constants(DATE,BROWSER_GOAL_REPORT_DAY.DATE,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		BROWSER_GOAL_REPORT_DAY_CONSTANTS = Collections.unmodifiableList(browserGoalReportDayConstants);
	}
	
	public static final List<Constants> DEVICE_GOAL_REPORT_HOUR_CONSTANTS;
	
	static{
		List<Constants> deviceGoalReportHourConstants = new ArrayList<Constants>();
		deviceGoalReportHourConstants.add(new Constants(DEVICE_GOAL_REPORT_HOUR_ID,DEVICE_GOAL_REPORT_HOUR.DEVICE_GOAL_REPORT_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		deviceGoalReportHourConstants.add(new Constants(EXPERIMENT_ID,DEVICE_GOAL_REPORT_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		deviceGoalReportHourConstants.add(new Constants(VARIATION_ID,DEVICE_GOAL_REPORT_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		deviceGoalReportHourConstants.add(new Constants(GOAL_ID,DEVICE_GOAL_REPORT_HOUR.GOAL_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		deviceGoalReportHourConstants.add(new Constants(CODE,DEVICE_GOAL_REPORT_HOUR.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		deviceGoalReportHourConstants.add(new Constants(TOTAL_COUNT,DEVICE_GOAL_REPORT_HOUR.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		deviceGoalReportHourConstants.add(new Constants(TIME,DEVICE_GOAL_REPORT_HOUR.TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		DEVICE_GOAL_REPORT_HOUR_CONSTANTS = Collections.unmodifiableList(deviceGoalReportHourConstants);
	}
	
	public static final List<Constants> DEVICE_GOAL_REPORT_DAY_CONSTANTS;
	
	static{
		List<Constants> deviceGoalReportDayConstants = new ArrayList<Constants>();
		deviceGoalReportDayConstants.add(new Constants(DEVICE_GOAL_REPORT_DAY_ID,DEVICE_GOAL_REPORT_DAY.DEVICE_GOAL_REPORT_DAY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		deviceGoalReportDayConstants.add(new Constants(EXPERIMENT_ID,DEVICE_GOAL_REPORT_DAY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		deviceGoalReportDayConstants.add(new Constants(VARIATION_ID,DEVICE_GOAL_REPORT_DAY.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		deviceGoalReportDayConstants.add(new Constants(GOAL_ID,DEVICE_GOAL_REPORT_DAY.GOAL_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		deviceGoalReportDayConstants.add(new Constants(CODE,DEVICE_GOAL_REPORT_DAY.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		deviceGoalReportDayConstants.add(new Constants(TOTAL_COUNT,DEVICE_GOAL_REPORT_DAY.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		deviceGoalReportDayConstants.add(new Constants(DATE,DEVICE_GOAL_REPORT_DAY.DATE,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		DEVICE_GOAL_REPORT_DAY_CONSTANTS = Collections.unmodifiableList(deviceGoalReportDayConstants);
	}
	

	public static final List<Constants> COUNTRY_GOAL_REPORT_HOUR_CONSTANTS;
	
	static{
		List<Constants> countryGoalReportHourConstants = new ArrayList<Constants>();
		countryGoalReportHourConstants.add(new Constants(COUNTRY_GOAL_REPORT_HOUR_ID,COUNTRY_GOAL_REPORT_HOUR.COUNTRY_GOAL_REPORT_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		countryGoalReportHourConstants.add(new Constants(EXPERIMENT_ID,COUNTRY_GOAL_REPORT_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		countryGoalReportHourConstants.add(new Constants(VARIATION_ID,COUNTRY_GOAL_REPORT_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		countryGoalReportHourConstants.add(new Constants(GOAL_ID,COUNTRY_GOAL_REPORT_HOUR.GOAL_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		countryGoalReportHourConstants.add(new Constants(CODE,COUNTRY_GOAL_REPORT_HOUR.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		countryGoalReportHourConstants.add(new Constants(TOTAL_COUNT,COUNTRY_GOAL_REPORT_HOUR.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		countryGoalReportHourConstants.add(new Constants(TIME,COUNTRY_GOAL_REPORT_HOUR.TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		COUNTRY_GOAL_REPORT_HOUR_CONSTANTS = Collections.unmodifiableList(countryGoalReportHourConstants);
	}
	
	public static final List<Constants> COUNTRY_GOAL_REPORT_DAY_CONSTANTS;
	
	static{
		List<Constants> countryGoalReportDayConstants = new ArrayList<Constants>();
		countryGoalReportDayConstants.add(new Constants(COUNTRY_GOAL_REPORT_DAY_ID,COUNTRY_GOAL_REPORT_DAY.COUNTRY_GOAL_REPORT_DAY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		countryGoalReportDayConstants.add(new Constants(EXPERIMENT_ID,COUNTRY_GOAL_REPORT_DAY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		countryGoalReportDayConstants.add(new Constants(VARIATION_ID,COUNTRY_GOAL_REPORT_DAY.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		countryGoalReportDayConstants.add(new Constants(GOAL_ID,COUNTRY_GOAL_REPORT_DAY.GOAL_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		countryGoalReportDayConstants.add(new Constants(CODE,COUNTRY_GOAL_REPORT_DAY.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		countryGoalReportDayConstants.add(new Constants(TOTAL_COUNT,COUNTRY_GOAL_REPORT_DAY.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		countryGoalReportDayConstants.add(new Constants(DATE,COUNTRY_GOAL_REPORT_DAY.DATE,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		COUNTRY_GOAL_REPORT_DAY_CONSTANTS = Collections.unmodifiableList(countryGoalReportDayConstants);
	}
	
////
	public static final List<Constants> LANG_GOAL_REPORT_HOUR_CONSTANTS;
	
	static{
		List<Constants> langGoalReportHourConstants = new ArrayList<Constants>();
		langGoalReportHourConstants.add(new Constants(LANG_GOAL_REPORT_HOUR_ID,LANG_GOAL_REPORT_HOUR.LANG_GOAL_REPORT_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		langGoalReportHourConstants.add(new Constants(EXPERIMENT_ID,LANG_GOAL_REPORT_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		langGoalReportHourConstants.add(new Constants(VARIATION_ID,LANG_GOAL_REPORT_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		langGoalReportHourConstants.add(new Constants(GOAL_ID,LANG_GOAL_REPORT_HOUR.GOAL_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		langGoalReportHourConstants.add(new Constants(CODE,LANG_GOAL_REPORT_HOUR.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		langGoalReportHourConstants.add(new Constants(TOTAL_COUNT,LANG_GOAL_REPORT_HOUR.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		langGoalReportHourConstants.add(new Constants(TIME,LANG_GOAL_REPORT_HOUR.TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		LANG_GOAL_REPORT_HOUR_CONSTANTS = Collections.unmodifiableList(langGoalReportHourConstants);
	}
	
	public static final List<Constants> LANG_GOAL_REPORT_DAY_CONSTANTS;
	
	static{
		List<Constants> langGoalReportDayConstants = new ArrayList<Constants>();
		langGoalReportDayConstants.add(new Constants(LANG_GOAL_REPORT_DAY_ID,LANG_GOAL_REPORT_DAY.LANG_GOAL_REPORT_DAY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		langGoalReportDayConstants.add(new Constants(EXPERIMENT_ID,LANG_GOAL_REPORT_DAY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		langGoalReportDayConstants.add(new Constants(VARIATION_ID,LANG_GOAL_REPORT_DAY.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		langGoalReportDayConstants.add(new Constants(GOAL_ID,LANG_GOAL_REPORT_DAY.GOAL_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		langGoalReportDayConstants.add(new Constants(CODE,LANG_GOAL_REPORT_DAY.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		langGoalReportDayConstants.add(new Constants(TOTAL_COUNT,LANG_GOAL_REPORT_DAY.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		langGoalReportDayConstants.add(new Constants(DATE,LANG_GOAL_REPORT_DAY.DATE,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		LANG_GOAL_REPORT_DAY_CONSTANTS = Collections.unmodifiableList(langGoalReportDayConstants);
	}
	

	public static final List<Constants> OS_GOAL_REPORT_HOUR_CONSTANTS;
	
	static{
		List<Constants> osGoalReportHourConstants = new ArrayList<Constants>();
		osGoalReportHourConstants.add(new Constants(OS_GOAL_REPORT_HOUR_ID,OS_GOAL_REPORT_HOUR.OS_GOAL_REPORT_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		osGoalReportHourConstants.add(new Constants(EXPERIMENT_ID,OS_GOAL_REPORT_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		osGoalReportHourConstants.add(new Constants(VARIATION_ID,OS_GOAL_REPORT_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		osGoalReportHourConstants.add(new Constants(GOAL_ID,OS_GOAL_REPORT_HOUR.GOAL_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		osGoalReportHourConstants.add(new Constants(CODE,OS_GOAL_REPORT_HOUR.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		osGoalReportHourConstants.add(new Constants(TOTAL_COUNT,OS_GOAL_REPORT_HOUR.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		osGoalReportHourConstants.add(new Constants(TIME,OS_GOAL_REPORT_HOUR.TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		OS_GOAL_REPORT_HOUR_CONSTANTS = Collections.unmodifiableList(osGoalReportHourConstants);
	}
	
	public static final List<Constants> OS_GOAL_REPORT_DAY_CONSTANTS;
	
	static{
		List<Constants> osGoalReportDayConstants = new ArrayList<Constants>();
		osGoalReportDayConstants.add(new Constants(OS_GOAL_REPORT_DAY_ID,OS_GOAL_REPORT_DAY.OS_GOAL_REPORT_DAY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		osGoalReportDayConstants.add(new Constants(EXPERIMENT_ID,OS_GOAL_REPORT_DAY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		osGoalReportDayConstants.add(new Constants(VARIATION_ID,OS_GOAL_REPORT_DAY.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		osGoalReportDayConstants.add(new Constants(GOAL_ID,OS_GOAL_REPORT_DAY.GOAL_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		osGoalReportDayConstants.add(new Constants(CODE,OS_GOAL_REPORT_DAY.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		osGoalReportDayConstants.add(new Constants(TOTAL_COUNT,OS_GOAL_REPORT_DAY.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		osGoalReportDayConstants.add(new Constants(DATE,OS_GOAL_REPORT_DAY.DATE,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		OS_GOAL_REPORT_DAY_CONSTANTS = Collections.unmodifiableList(osGoalReportDayConstants);
	}
	

	public static final List<Constants> TRAFSOUR_GOAL_REPORT_HOUR_CONSTANTS;
	
	static{
		List<Constants> trafsourceReportHourConstants = new ArrayList<Constants>();
		trafsourceReportHourConstants.add(new Constants(TRAFSOUR_GOAL_REPORT_HOUR_ID,TRAFSOUR_GOAL_REPORT_HOUR.TRAFSOUR_GOAL_REPORT_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		trafsourceReportHourConstants.add(new Constants(EXPERIMENT_ID,TRAFSOUR_GOAL_REPORT_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		trafsourceReportHourConstants.add(new Constants(VARIATION_ID,TRAFSOUR_GOAL_REPORT_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		trafsourceReportHourConstants.add(new Constants(GOAL_ID,TRAFSOUR_GOAL_REPORT_HOUR.GOAL_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		trafsourceReportHourConstants.add(new Constants(CODE,TRAFSOUR_GOAL_REPORT_HOUR.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		trafsourceReportHourConstants.add(new Constants(TOTAL_COUNT,TRAFSOUR_GOAL_REPORT_HOUR.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		trafsourceReportHourConstants.add(new Constants(TIME,TRAFSOUR_GOAL_REPORT_HOUR.TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		TRAFSOUR_GOAL_REPORT_HOUR_CONSTANTS = Collections.unmodifiableList(trafsourceReportHourConstants);
	}
	
	public static final List<Constants> TRAFSOUR_GOAL_REPORT_DAY_CONSTANTS;
	
	static{
		List<Constants> trafsourceReportDayConstants = new ArrayList<Constants>();
		trafsourceReportDayConstants.add(new Constants(TRAFSOUR_GOAL_REPORT_DAY_ID,TRAFSOUR_GOAL_REPORT_DAY.TRAFSOUR_GOAL_REPORT_DAY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		trafsourceReportDayConstants.add(new Constants(EXPERIMENT_ID,TRAFSOUR_GOAL_REPORT_DAY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		trafsourceReportDayConstants.add(new Constants(VARIATION_ID,TRAFSOUR_GOAL_REPORT_DAY.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		trafsourceReportDayConstants.add(new Constants(GOAL_ID,TRAFSOUR_GOAL_REPORT_DAY.GOAL_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		trafsourceReportDayConstants.add(new Constants(CODE,TRAFSOUR_GOAL_REPORT_DAY.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		trafsourceReportDayConstants.add(new Constants(TOTAL_COUNT,TRAFSOUR_GOAL_REPORT_DAY.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		trafsourceReportDayConstants.add(new Constants(DATE,TRAFSOUR_GOAL_REPORT_DAY.DATE,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		TRAFSOUR_GOAL_REPORT_DAY_CONSTANTS = Collections.unmodifiableList(trafsourceReportDayConstants);
	}
	

	public static final List<Constants> REFURL_GOAL_REPORT_HOUR_CONSTANTS;
	
	static{
		List<Constants> refurlGoalReportHourConstants = new ArrayList<Constants>();
		refurlGoalReportHourConstants.add(new Constants(REFURL_GOAL_REPORT_HOUR_ID,REFURL_GOAL_REPORT_HOUR.REFURL_GOAL_REPORT_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		refurlGoalReportHourConstants.add(new Constants(EXPERIMENT_ID,REFURL_GOAL_REPORT_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		refurlGoalReportHourConstants.add(new Constants(VARIATION_ID,REFURL_GOAL_REPORT_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		refurlGoalReportHourConstants.add(new Constants(GOAL_ID,REFURL_GOAL_REPORT_HOUR.GOAL_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		refurlGoalReportHourConstants.add(new Constants(CODE,REFURL_GOAL_REPORT_HOUR.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		refurlGoalReportHourConstants.add(new Constants(TOTAL_COUNT,REFURL_GOAL_REPORT_HOUR.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		refurlGoalReportHourConstants.add(new Constants(TIME,REFURL_GOAL_REPORT_HOUR.TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		REFURL_GOAL_REPORT_HOUR_CONSTANTS = Collections.unmodifiableList(refurlGoalReportHourConstants);
	}
	
	public static final List<Constants> REFURL_GOAL_REPORT_DAY_CONSTANTS;
	
	static{
		List<Constants> refurlGoalReportDayConstants = new ArrayList<Constants>();
		refurlGoalReportDayConstants.add(new Constants(REFURL_GOAL_REPORT_DAY_ID,REFURL_GOAL_REPORT_DAY.REFURL_GOAL_REPORT_DAY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		refurlGoalReportDayConstants.add(new Constants(EXPERIMENT_ID,REFURL_GOAL_REPORT_DAY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		refurlGoalReportDayConstants.add(new Constants(VARIATION_ID,REFURL_GOAL_REPORT_DAY.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		refurlGoalReportDayConstants.add(new Constants(GOAL_ID,REFURL_GOAL_REPORT_DAY.GOAL_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		refurlGoalReportDayConstants.add(new Constants(CODE,REFURL_GOAL_REPORT_DAY.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		refurlGoalReportDayConstants.add(new Constants(TOTAL_COUNT,REFURL_GOAL_REPORT_DAY.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		refurlGoalReportDayConstants.add(new Constants(DATE,REFURL_GOAL_REPORT_DAY.DATE,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		REFURL_GOAL_REPORT_DAY_CONSTANTS = Collections.unmodifiableList(refurlGoalReportDayConstants);
	}
	

	public static final List<Constants> DAYOFWK_GOAL_REPORT_HOUR_CONSTANTS;
	
	static{
		List<Constants> dayOfWeekGoalReportHourConstants = new ArrayList<Constants>();
		dayOfWeekGoalReportHourConstants.add(new Constants(DAYOFWK_GOAL_REPORT_HOUR_ID,DAYOFWK_GOAL_REPORT_HOUR.DAYOFWK_GOAL_REPORT_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		dayOfWeekGoalReportHourConstants.add(new Constants(EXPERIMENT_ID,DAYOFWK_GOAL_REPORT_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		dayOfWeekGoalReportHourConstants.add(new Constants(VARIATION_ID,DAYOFWK_GOAL_REPORT_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		dayOfWeekGoalReportHourConstants.add(new Constants(GOAL_ID,DAYOFWK_GOAL_REPORT_HOUR.GOAL_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		dayOfWeekGoalReportHourConstants.add(new Constants(CODE,DAYOFWK_GOAL_REPORT_HOUR.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		dayOfWeekGoalReportHourConstants.add(new Constants(TOTAL_COUNT,DAYOFWK_GOAL_REPORT_HOUR.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		dayOfWeekGoalReportHourConstants.add(new Constants(TIME,DAYOFWK_GOAL_REPORT_HOUR.TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		DAYOFWK_GOAL_REPORT_HOUR_CONSTANTS = Collections.unmodifiableList(dayOfWeekGoalReportHourConstants);
	}
	
	public static final List<Constants> DAYOFWK_GOAL_REPORT_DAY_CONSTANTS;
	
	static{
		List<Constants> dayOfWeekGoalReportDayConstants = new ArrayList<Constants>();
		dayOfWeekGoalReportDayConstants.add(new Constants(DAYOFWK_GOAL_REPORT_DAY_ID,DAYOFWK_GOAL_REPORT_DAY.DAYOFWK_GOAL_REPORT_DAY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		dayOfWeekGoalReportDayConstants.add(new Constants(EXPERIMENT_ID,DAYOFWK_GOAL_REPORT_DAY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		dayOfWeekGoalReportDayConstants.add(new Constants(VARIATION_ID,DAYOFWK_GOAL_REPORT_DAY.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		dayOfWeekGoalReportDayConstants.add(new Constants(GOAL_ID,DAYOFWK_GOAL_REPORT_DAY.GOAL_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		dayOfWeekGoalReportDayConstants.add(new Constants(CODE,DAYOFWK_GOAL_REPORT_DAY.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		dayOfWeekGoalReportDayConstants.add(new Constants(TOTAL_COUNT,DAYOFWK_GOAL_REPORT_DAY.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		dayOfWeekGoalReportDayConstants.add(new Constants(DATE,DAYOFWK_GOAL_REPORT_DAY.DATE,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		DAYOFWK_GOAL_REPORT_DAY_CONSTANTS = Collections.unmodifiableList(dayOfWeekGoalReportDayConstants);
	}
	

	public static final List<Constants> HOURODY_GOAL_REPORT_HOUR_CONSTANTS;
	
	static{
		List<Constants> hourOfDayGoalReportHourConstants = new ArrayList<Constants>();
		hourOfDayGoalReportHourConstants.add(new Constants(HOURODY_GOAL_REPORT_HOUR_ID,HOURODY_GOAL_REPORT_HOUR.HOURODY_GOAL_REPORT_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		hourOfDayGoalReportHourConstants.add(new Constants(EXPERIMENT_ID,HOURODY_GOAL_REPORT_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		hourOfDayGoalReportHourConstants.add(new Constants(VARIATION_ID,HOURODY_GOAL_REPORT_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		hourOfDayGoalReportHourConstants.add(new Constants(GOAL_ID,HOURODY_GOAL_REPORT_HOUR.GOAL_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		hourOfDayGoalReportHourConstants.add(new Constants(CODE,HOURODY_GOAL_REPORT_HOUR.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		hourOfDayGoalReportHourConstants.add(new Constants(TOTAL_COUNT,HOURODY_GOAL_REPORT_HOUR.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		hourOfDayGoalReportHourConstants.add(new Constants(TIME,HOURODY_GOAL_REPORT_HOUR.TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		HOURODY_GOAL_REPORT_HOUR_CONSTANTS = Collections.unmodifiableList(hourOfDayGoalReportHourConstants);
	}
	
	public static final List<Constants> HOURODY_GOAL_REPORT_DAY_CONSTANTS;
	
	static{
		List<Constants> hourOfDayGoalReportDayConstants = new ArrayList<Constants>();
		hourOfDayGoalReportDayConstants.add(new Constants(HOURODY_GOAL_REPORT_DAY_ID,HOURODY_GOAL_REPORT_DAY.HOURODY_GOAL_REPORT_DAY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		hourOfDayGoalReportDayConstants.add(new Constants(EXPERIMENT_ID,HOURODY_GOAL_REPORT_DAY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		hourOfDayGoalReportDayConstants.add(new Constants(VARIATION_ID,HOURODY_GOAL_REPORT_DAY.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		hourOfDayGoalReportDayConstants.add(new Constants(GOAL_ID,HOURODY_GOAL_REPORT_DAY.GOAL_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		hourOfDayGoalReportDayConstants.add(new Constants(CODE,HOURODY_GOAL_REPORT_DAY.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		hourOfDayGoalReportDayConstants.add(new Constants(TOTAL_COUNT,HOURODY_GOAL_REPORT_DAY.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		hourOfDayGoalReportDayConstants.add(new Constants(DATE,HOURODY_GOAL_REPORT_DAY.DATE,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		HOURODY_GOAL_REPORT_DAY_CONSTANTS = Collections.unmodifiableList(hourOfDayGoalReportDayConstants);
	}
	

	public static final List<Constants> COOKIE_GOAL_REPORT_HOUR_CONSTANTS;
	
	static{
		List<Constants> cookieGoalReportHourConstants = new ArrayList<Constants>();
		cookieGoalReportHourConstants.add(new Constants(COOKIE_GOAL_REPORT_HOUR_ID,COOKIE_GOAL_REPORT_HOUR.COOKIE_GOAL_REPORT_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		cookieGoalReportHourConstants.add(new Constants(EXPERIMENT_ID,COOKIE_GOAL_REPORT_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		cookieGoalReportHourConstants.add(new Constants(VARIATION_ID,COOKIE_GOAL_REPORT_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		cookieGoalReportHourConstants.add(new Constants(GOAL_ID,COOKIE_GOAL_REPORT_HOUR.GOAL_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		cookieGoalReportHourConstants.add(new Constants(DYNAMIC_ATTRIBUTE_ID,COOKIE_GOAL_REPORT_HOUR.DYNAMIC_ATTRIBUTE_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		cookieGoalReportHourConstants.add(new Constants(CODE,COOKIE_GOAL_REPORT_HOUR.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		cookieGoalReportHourConstants.add(new Constants(TOTAL_COUNT,COOKIE_GOAL_REPORT_HOUR.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		cookieGoalReportHourConstants.add(new Constants(TIME,COOKIE_GOAL_REPORT_HOUR.TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		COOKIE_GOAL_REPORT_HOUR_CONSTANTS = Collections.unmodifiableList(cookieGoalReportHourConstants);
	}
	
	public static final List<Constants> COOKIE_GOAL_REPORT_DAY_CONSTANTS;
	
	static{
		List<Constants> cookieGoalReportDayConstants = new ArrayList<Constants>();
		cookieGoalReportDayConstants.add(new Constants(COOKIE_GOAL_REPORT_DAY_ID,COOKIE_GOAL_REPORT_DAY.COOKIE_GOAL_REPORT_DAY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		cookieGoalReportDayConstants.add(new Constants(EXPERIMENT_ID,COOKIE_GOAL_REPORT_DAY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		cookieGoalReportDayConstants.add(new Constants(VARIATION_ID,COOKIE_GOAL_REPORT_DAY.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		cookieGoalReportDayConstants.add(new Constants(GOAL_ID,COOKIE_GOAL_REPORT_DAY.GOAL_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		cookieGoalReportDayConstants.add(new Constants(DYNAMIC_ATTRIBUTE_ID,COOKIE_GOAL_REPORT_DAY.DYNAMIC_ATTRIBUTE_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		cookieGoalReportDayConstants.add(new Constants(CODE,COOKIE_GOAL_REPORT_DAY.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		cookieGoalReportDayConstants.add(new Constants(TOTAL_COUNT,COOKIE_GOAL_REPORT_DAY.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		cookieGoalReportDayConstants.add(new Constants(DATE,COOKIE_GOAL_REPORT_DAY.DATE,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		COOKIE_GOAL_REPORT_DAY_CONSTANTS = Collections.unmodifiableList(cookieGoalReportDayConstants);
	}
	

	public static final List<Constants> URLPARM_GOAL_REPORT_HOUR_CONSTANTS;
	
	static{
		List<Constants> urlParamGoalReportHourConstants = new ArrayList<Constants>();
		urlParamGoalReportHourConstants.add(new Constants(URLPARM_GOAL_REPORT_HOUR_ID,URLPARM_GOAL_REPORT_HOUR.URLPARM_GOAL_REPORT_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		urlParamGoalReportHourConstants.add(new Constants(EXPERIMENT_ID,URLPARM_GOAL_REPORT_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		urlParamGoalReportHourConstants.add(new Constants(VARIATION_ID,URLPARM_GOAL_REPORT_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		urlParamGoalReportHourConstants.add(new Constants(GOAL_ID,URLPARM_GOAL_REPORT_HOUR.GOAL_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		urlParamGoalReportHourConstants.add(new Constants(DYNAMIC_ATTRIBUTE_ID,URLPARM_GOAL_REPORT_HOUR.DYNAMIC_ATTRIBUTE_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		urlParamGoalReportHourConstants.add(new Constants(CODE,URLPARM_GOAL_REPORT_HOUR.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		urlParamGoalReportHourConstants.add(new Constants(TOTAL_COUNT,URLPARM_GOAL_REPORT_HOUR.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		urlParamGoalReportHourConstants.add(new Constants(TIME,URLPARM_GOAL_REPORT_HOUR.TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		URLPARM_GOAL_REPORT_HOUR_CONSTANTS = Collections.unmodifiableList(urlParamGoalReportHourConstants);
	}
	
	public static final List<Constants> URLPARM_GOAL_REPORT_DAY_CONSTANTS;
	
	static{
		List<Constants> urlParamGoalReportDayConstants = new ArrayList<Constants>();
		urlParamGoalReportDayConstants.add(new Constants(URLPARM_GOAL_REPORT_DAY_ID,URLPARM_GOAL_REPORT_DAY.URLPARM_GOAL_REPORT_DAY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		urlParamGoalReportDayConstants.add(new Constants(EXPERIMENT_ID,URLPARM_GOAL_REPORT_DAY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		urlParamGoalReportDayConstants.add(new Constants(VARIATION_ID,URLPARM_GOAL_REPORT_DAY.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		urlParamGoalReportDayConstants.add(new Constants(GOAL_ID,URLPARM_GOAL_REPORT_DAY.GOAL_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		urlParamGoalReportDayConstants.add(new Constants(DYNAMIC_ATTRIBUTE_ID,URLPARM_GOAL_REPORT_DAY.DYNAMIC_ATTRIBUTE_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		urlParamGoalReportDayConstants.add(new Constants(CODE,URLPARM_GOAL_REPORT_DAY.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		urlParamGoalReportDayConstants.add(new Constants(TOTAL_COUNT,URLPARM_GOAL_REPORT_DAY.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		urlParamGoalReportDayConstants.add(new Constants(DATE,URLPARM_GOAL_REPORT_DAY.DATE,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		URLPARM_GOAL_REPORT_DAY_CONSTANTS = Collections.unmodifiableList(urlParamGoalReportDayConstants);
	}
	

	public static final List<Constants> JSVAR_GOAL_REPORT_HOUR_CONSTANTS;
	
	static{
		List<Constants> jsvarGoalReportHourConstants = new ArrayList<Constants>();
		jsvarGoalReportHourConstants.add(new Constants(JSVAR_GOAL_REPORT_HOUR_ID,JSVAR_GOAL_REPORT_HOUR.JSVAR_GOAL_REPORT_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		jsvarGoalReportHourConstants.add(new Constants(EXPERIMENT_ID,JSVAR_GOAL_REPORT_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		jsvarGoalReportHourConstants.add(new Constants(VARIATION_ID,JSVAR_GOAL_REPORT_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		jsvarGoalReportHourConstants.add(new Constants(GOAL_ID,JSVAR_GOAL_REPORT_HOUR.GOAL_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		jsvarGoalReportHourConstants.add(new Constants(DYNAMIC_ATTRIBUTE_ID,JSVAR_GOAL_REPORT_HOUR.DYNAMIC_ATTRIBUTE_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		jsvarGoalReportHourConstants.add(new Constants(CODE,JSVAR_GOAL_REPORT_HOUR.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		jsvarGoalReportHourConstants.add(new Constants(TOTAL_COUNT,JSVAR_GOAL_REPORT_HOUR.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		jsvarGoalReportHourConstants.add(new Constants(TIME,JSVAR_GOAL_REPORT_HOUR.TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		JSVAR_GOAL_REPORT_HOUR_CONSTANTS = Collections.unmodifiableList(jsvarGoalReportHourConstants);
	}
	
	public static final List<Constants> JSVAR_GOAL_REPORT_DAY_CONSTANTS;
	
	static{
		List<Constants> jsvarGoalReportDayConstants = new ArrayList<Constants>();
		jsvarGoalReportDayConstants.add(new Constants(JSVAR_GOAL_REPORT_DAY_ID,JSVAR_GOAL_REPORT_DAY.JSVAR_GOAL_REPORT_DAY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		jsvarGoalReportDayConstants.add(new Constants(EXPERIMENT_ID,JSVAR_GOAL_REPORT_DAY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		jsvarGoalReportDayConstants.add(new Constants(VARIATION_ID,JSVAR_GOAL_REPORT_DAY.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		jsvarGoalReportDayConstants.add(new Constants(GOAL_ID,JSVAR_GOAL_REPORT_DAY.GOAL_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		jsvarGoalReportDayConstants.add(new Constants(DYNAMIC_ATTRIBUTE_ID,JSVAR_GOAL_REPORT_DAY.DYNAMIC_ATTRIBUTE_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		jsvarGoalReportDayConstants.add(new Constants(CODE,JSVAR_GOAL_REPORT_DAY.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		jsvarGoalReportDayConstants.add(new Constants(TOTAL_COUNT,JSVAR_GOAL_REPORT_DAY.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		jsvarGoalReportDayConstants.add(new Constants(DATE,JSVAR_GOAL_REPORT_DAY.DATE,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		JSVAR_GOAL_REPORT_DAY_CONSTANTS = Collections.unmodifiableList(jsvarGoalReportDayConstants);
	}
	
	public static final List<Constants> CUSTDIM_GOAL_REPORT_HOUR_CONSTANTS;
	
	static{
		List<Constants> custdimGoalReportHourConstants = new ArrayList<Constants>();
		custdimGoalReportHourConstants.add(new Constants(CUSTDIM_GOAL_REPORT_HOUR_ID,CUSTDIM_GOAL_REPORT_HOUR.CUSTDIM_GOAL_REPORT_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		custdimGoalReportHourConstants.add(new Constants(EXPERIMENT_ID,CUSTDIM_GOAL_REPORT_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		custdimGoalReportHourConstants.add(new Constants(VARIATION_ID,CUSTDIM_GOAL_REPORT_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		custdimGoalReportHourConstants.add(new Constants(GOAL_ID,CUSTDIM_GOAL_REPORT_HOUR.GOAL_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		custdimGoalReportHourConstants.add(new Constants(DYNAMIC_ATTRIBUTE_ID,CUSTDIM_GOAL_REPORT_HOUR.DYNAMIC_ATTRIBUTE_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		custdimGoalReportHourConstants.add(new Constants(CODE,CUSTDIM_GOAL_REPORT_HOUR.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		custdimGoalReportHourConstants.add(new Constants(TOTAL_COUNT,CUSTDIM_GOAL_REPORT_HOUR.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		custdimGoalReportHourConstants.add(new Constants(TIME,CUSTDIM_GOAL_REPORT_HOUR.TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		CUSTDIM_GOAL_REPORT_HOUR_CONSTANTS = Collections.unmodifiableList(custdimGoalReportHourConstants);
	}
	
	public static final List<Constants> CUSTDIM_GOAL_REPORT_DAY_CONSTANTS;
	
	static{
		List<Constants> custdimGoalReportDayConstants = new ArrayList<Constants>();
		custdimGoalReportDayConstants.add(new Constants(CUSTDIM_GOAL_REPORT_DAY_ID,CUSTDIM_GOAL_REPORT_DAY.CUSTDIM_GOAL_REPORT_DAY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		custdimGoalReportDayConstants.add(new Constants(EXPERIMENT_ID,CUSTDIM_GOAL_REPORT_DAY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		custdimGoalReportDayConstants.add(new Constants(VARIATION_ID,CUSTDIM_GOAL_REPORT_DAY.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		custdimGoalReportDayConstants.add(new Constants(GOAL_ID,CUSTDIM_GOAL_REPORT_DAY.GOAL_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		custdimGoalReportDayConstants.add(new Constants(DYNAMIC_ATTRIBUTE_ID,CUSTDIM_GOAL_REPORT_DAY.DYNAMIC_ATTRIBUTE_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		custdimGoalReportDayConstants.add(new Constants(CODE,CUSTDIM_GOAL_REPORT_DAY.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		custdimGoalReportDayConstants.add(new Constants(TOTAL_COUNT,CUSTDIM_GOAL_REPORT_DAY.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		custdimGoalReportDayConstants.add(new Constants(DATE,CUSTDIM_GOAL_REPORT_DAY.DATE,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		CUSTDIM_GOAL_REPORT_DAY_CONSTANTS = Collections.unmodifiableList(custdimGoalReportDayConstants);
	}
	
	public static final List<Constants> BROWSER_VISIT_REPORT_HOUR_CONSTANTS;
	
	static{
		List<Constants> browserVisitReportHourConstants = new ArrayList<Constants>();
		browserVisitReportHourConstants.add(new Constants(BROWSER_VISIT_REPORT_HOUR_ID,BROWSER_VISIT_REPORT_HOUR.BROWSER_VISIT_REPORT_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		browserVisitReportHourConstants.add(new Constants(EXPERIMENT_ID,BROWSER_VISIT_REPORT_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		browserVisitReportHourConstants.add(new Constants(VARIATION_ID,BROWSER_VISIT_REPORT_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		browserVisitReportHourConstants.add(new Constants(CODE,BROWSER_VISIT_REPORT_HOUR.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		browserVisitReportHourConstants.add(new Constants(TOTAL_COUNT,BROWSER_VISIT_REPORT_HOUR.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		browserVisitReportHourConstants.add(new Constants(TIME,BROWSER_VISIT_REPORT_HOUR.TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		BROWSER_VISIT_REPORT_HOUR_CONSTANTS = Collections.unmodifiableList(browserVisitReportHourConstants);
	}
	
	public static final List<Constants> BROWSER_VISIT_REPORT_DAY_CONSTANTS;
	
	static{
		List<Constants> browserVisitReportDayConstants = new ArrayList<Constants>();
		browserVisitReportDayConstants.add(new Constants(BROWSER_VISIT_REPORT_DAY_ID,BROWSER_VISIT_REPORT_DAY.BROWSER_VISIT_REPORT_DAY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		browserVisitReportDayConstants.add(new Constants(EXPERIMENT_ID,BROWSER_VISIT_REPORT_DAY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		browserVisitReportDayConstants.add(new Constants(VARIATION_ID,BROWSER_VISIT_REPORT_DAY.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		browserVisitReportDayConstants.add(new Constants(CODE,BROWSER_VISIT_REPORT_DAY.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		browserVisitReportDayConstants.add(new Constants(TOTAL_COUNT,BROWSER_VISIT_REPORT_DAY.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		browserVisitReportDayConstants.add(new Constants(DATE,BROWSER_VISIT_REPORT_DAY.DATE,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		BROWSER_VISIT_REPORT_DAY_CONSTANTS = Collections.unmodifiableList(browserVisitReportDayConstants);
	}
	
	public static final List<Constants> DEVICE_VISIT_REPORT_HOUR_CONSTANTS;
	
	static{
		List<Constants> deviceVisitReportHourConstants = new ArrayList<Constants>();
		deviceVisitReportHourConstants.add(new Constants(DEVICE_VISIT_REPORT_HOUR_ID,DEVICE_VISIT_REPORT_HOUR.DEVICE_VISIT_REPORT_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		deviceVisitReportHourConstants.add(new Constants(EXPERIMENT_ID,DEVICE_VISIT_REPORT_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		deviceVisitReportHourConstants.add(new Constants(VARIATION_ID,DEVICE_VISIT_REPORT_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		deviceVisitReportHourConstants.add(new Constants(CODE,DEVICE_VISIT_REPORT_HOUR.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		deviceVisitReportHourConstants.add(new Constants(TOTAL_COUNT,DEVICE_VISIT_REPORT_HOUR.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		deviceVisitReportHourConstants.add(new Constants(TIME,DEVICE_VISIT_REPORT_HOUR.TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		DEVICE_VISIT_REPORT_HOUR_CONSTANTS = Collections.unmodifiableList(deviceVisitReportHourConstants);
	}
	
	public static final List<Constants> DEVICE_VISIT_REPORT_DAY_CONSTANTS;
	
	static{
		List<Constants> deviceVisitReportDayConstants = new ArrayList<Constants>();
		deviceVisitReportDayConstants.add(new Constants(DEVICE_VISIT_REPORT_DAY_ID,DEVICE_VISIT_REPORT_DAY.DEVICE_VISIT_REPORT_DAY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		deviceVisitReportDayConstants.add(new Constants(EXPERIMENT_ID,DEVICE_VISIT_REPORT_DAY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		deviceVisitReportDayConstants.add(new Constants(VARIATION_ID,DEVICE_VISIT_REPORT_DAY.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		deviceVisitReportDayConstants.add(new Constants(CODE,DEVICE_VISIT_REPORT_DAY.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		deviceVisitReportDayConstants.add(new Constants(TOTAL_COUNT,DEVICE_VISIT_REPORT_DAY.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		deviceVisitReportDayConstants.add(new Constants(DATE,DEVICE_VISIT_REPORT_DAY.DATE,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		DEVICE_VISIT_REPORT_DAY_CONSTANTS = Collections.unmodifiableList(deviceVisitReportDayConstants);
	}
	

	public static final List<Constants> COUNTRY_VISIT_REPORT_HOUR_CONSTANTS;
	
	static{
		List<Constants> countryVisitReportHourConstants = new ArrayList<Constants>();
		countryVisitReportHourConstants.add(new Constants(COUNTRY_VISIT_REPORT_HOUR_ID,COUNTRY_VISIT_REPORT_HOUR.COUNTRY_VISIT_REPORT_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		countryVisitReportHourConstants.add(new Constants(EXPERIMENT_ID,COUNTRY_VISIT_REPORT_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		countryVisitReportHourConstants.add(new Constants(VARIATION_ID,COUNTRY_VISIT_REPORT_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		countryVisitReportHourConstants.add(new Constants(CODE,COUNTRY_VISIT_REPORT_HOUR.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		countryVisitReportHourConstants.add(new Constants(TOTAL_COUNT,COUNTRY_VISIT_REPORT_HOUR.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		countryVisitReportHourConstants.add(new Constants(TIME,COUNTRY_VISIT_REPORT_HOUR.TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		COUNTRY_VISIT_REPORT_HOUR_CONSTANTS = Collections.unmodifiableList(countryVisitReportHourConstants);
	}
	
	public static final List<Constants> COUNTRY_VISIT_REPORT_DAY_CONSTANTS;
	
	static{
		List<Constants> countryVisitReportDayConstants = new ArrayList<Constants>();
		countryVisitReportDayConstants.add(new Constants(COUNTRY_VISIT_REPORT_DAY_ID,COUNTRY_VISIT_REPORT_DAY.COUNTRY_VISIT_REPORT_DAY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		countryVisitReportDayConstants.add(new Constants(EXPERIMENT_ID,COUNTRY_VISIT_REPORT_DAY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		countryVisitReportDayConstants.add(new Constants(VARIATION_ID,COUNTRY_VISIT_REPORT_DAY.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		countryVisitReportDayConstants.add(new Constants(CODE,COUNTRY_VISIT_REPORT_DAY.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		countryVisitReportDayConstants.add(new Constants(TOTAL_COUNT,COUNTRY_VISIT_REPORT_DAY.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		countryVisitReportDayConstants.add(new Constants(DATE,COUNTRY_VISIT_REPORT_DAY.DATE,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		COUNTRY_VISIT_REPORT_DAY_CONSTANTS = Collections.unmodifiableList(countryVisitReportDayConstants);
	}
	
////
	public static final List<Constants> LANG_VISIT_REPORT_HOUR_CONSTANTS;
	
	static{
		List<Constants> langVisitReportHourConstants = new ArrayList<Constants>();
		langVisitReportHourConstants.add(new Constants(LANG_VISIT_REPORT_HOUR_ID,LANG_VISIT_REPORT_HOUR.LANG_VISIT_REPORT_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		langVisitReportHourConstants.add(new Constants(EXPERIMENT_ID,LANG_VISIT_REPORT_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		langVisitReportHourConstants.add(new Constants(VARIATION_ID,LANG_VISIT_REPORT_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		langVisitReportHourConstants.add(new Constants(CODE,LANG_VISIT_REPORT_HOUR.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		langVisitReportHourConstants.add(new Constants(TOTAL_COUNT,LANG_VISIT_REPORT_HOUR.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		langVisitReportHourConstants.add(new Constants(TIME,LANG_VISIT_REPORT_HOUR.TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		LANG_VISIT_REPORT_HOUR_CONSTANTS = Collections.unmodifiableList(langVisitReportHourConstants);
	}
	
	public static final List<Constants> LANG_VISIT_REPORT_DAY_CONSTANTS;
	
	static{
		List<Constants> langVisitReportDayConstants = new ArrayList<Constants>();
		langVisitReportDayConstants.add(new Constants(LANG_VISIT_REPORT_DAY_ID,LANG_VISIT_REPORT_DAY.LANG_VISIT_REPORT_DAY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		langVisitReportDayConstants.add(new Constants(EXPERIMENT_ID,LANG_VISIT_REPORT_DAY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		langVisitReportDayConstants.add(new Constants(VARIATION_ID,LANG_VISIT_REPORT_DAY.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		langVisitReportDayConstants.add(new Constants(CODE,LANG_VISIT_REPORT_DAY.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		langVisitReportDayConstants.add(new Constants(TOTAL_COUNT,LANG_VISIT_REPORT_DAY.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		langVisitReportDayConstants.add(new Constants(DATE,LANG_VISIT_REPORT_DAY.DATE,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		LANG_VISIT_REPORT_DAY_CONSTANTS = Collections.unmodifiableList(langVisitReportDayConstants);
	}
	

	public static final List<Constants> OS_VISIT_REPORT_HOUR_CONSTANTS;
	
	static{
		List<Constants> osVisitReportHourConstants = new ArrayList<Constants>();
		osVisitReportHourConstants.add(new Constants(OS_VISIT_REPORT_HOUR_ID,OS_VISIT_REPORT_HOUR.OS_VISIT_REPORT_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		osVisitReportHourConstants.add(new Constants(EXPERIMENT_ID,OS_VISIT_REPORT_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		osVisitReportHourConstants.add(new Constants(VARIATION_ID,OS_VISIT_REPORT_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		osVisitReportHourConstants.add(new Constants(CODE,OS_VISIT_REPORT_HOUR.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		osVisitReportHourConstants.add(new Constants(TOTAL_COUNT,OS_VISIT_REPORT_HOUR.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		osVisitReportHourConstants.add(new Constants(TIME,OS_VISIT_REPORT_HOUR.TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		OS_VISIT_REPORT_HOUR_CONSTANTS = Collections.unmodifiableList(osVisitReportHourConstants);
	}
	
	public static final List<Constants> OS_VISIT_REPORT_DAY_CONSTANTS;
	
	static{
		List<Constants> osVisitReportDayConstants = new ArrayList<Constants>();
		osVisitReportDayConstants.add(new Constants(OS_VISIT_REPORT_DAY_ID,OS_VISIT_REPORT_DAY.OS_VISIT_REPORT_DAY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		osVisitReportDayConstants.add(new Constants(EXPERIMENT_ID,OS_VISIT_REPORT_DAY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		osVisitReportDayConstants.add(new Constants(VARIATION_ID,OS_VISIT_REPORT_DAY.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		osVisitReportDayConstants.add(new Constants(CODE,OS_VISIT_REPORT_DAY.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		osVisitReportDayConstants.add(new Constants(TOTAL_COUNT,OS_VISIT_REPORT_DAY.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		osVisitReportDayConstants.add(new Constants(DATE,OS_VISIT_REPORT_DAY.DATE,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		OS_VISIT_REPORT_DAY_CONSTANTS = Collections.unmodifiableList(osVisitReportDayConstants);
	}
	

	public static final List<Constants> TRAFSOUR_VISIT_REPORT_HOUR_CONSTANTS;
	
	static{
		List<Constants> trafsourceReportHourConstants = new ArrayList<Constants>();
		trafsourceReportHourConstants.add(new Constants(TRAFSOUR_VISIT_REPORT_HOUR_ID,TRAFSOUR_VISIT_REPORT_HOUR.TRAFSOUR_VISIT_REPORT_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		trafsourceReportHourConstants.add(new Constants(EXPERIMENT_ID,TRAFSOUR_VISIT_REPORT_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		trafsourceReportHourConstants.add(new Constants(VARIATION_ID,TRAFSOUR_VISIT_REPORT_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		trafsourceReportHourConstants.add(new Constants(CODE,TRAFSOUR_VISIT_REPORT_HOUR.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		trafsourceReportHourConstants.add(new Constants(TOTAL_COUNT,TRAFSOUR_VISIT_REPORT_HOUR.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		trafsourceReportHourConstants.add(new Constants(TIME,TRAFSOUR_VISIT_REPORT_HOUR.TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		TRAFSOUR_VISIT_REPORT_HOUR_CONSTANTS = Collections.unmodifiableList(trafsourceReportHourConstants);
	}
	
	public static final List<Constants> TRAFSOUR_VISIT_REPORT_DAY_CONSTANTS;
	
	static{
		List<Constants> trafsourceReportDayConstants = new ArrayList<Constants>();
		trafsourceReportDayConstants.add(new Constants(TRAFSOUR_VISIT_REPORT_DAY_ID,TRAFSOUR_VISIT_REPORT_DAY.TRAFSOUR_VISIT_REPORT_DAY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		trafsourceReportDayConstants.add(new Constants(EXPERIMENT_ID,TRAFSOUR_VISIT_REPORT_DAY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		trafsourceReportDayConstants.add(new Constants(VARIATION_ID,TRAFSOUR_VISIT_REPORT_DAY.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		trafsourceReportDayConstants.add(new Constants(CODE,TRAFSOUR_VISIT_REPORT_DAY.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		trafsourceReportDayConstants.add(new Constants(TOTAL_COUNT,TRAFSOUR_VISIT_REPORT_DAY.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		trafsourceReportDayConstants.add(new Constants(DATE,TRAFSOUR_VISIT_REPORT_DAY.DATE,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		TRAFSOUR_VISIT_REPORT_DAY_CONSTANTS = Collections.unmodifiableList(trafsourceReportDayConstants);
	}
	

	public static final List<Constants> REFURL_VISIT_REPORT_HOUR_CONSTANTS;
	
	static{
		List<Constants> refurlVisitReportHourConstants = new ArrayList<Constants>();
		refurlVisitReportHourConstants.add(new Constants(REFURL_VISIT_REPORT_HOUR_ID,REFURL_VISIT_REPORT_HOUR.REFURL_VISIT_REPORT_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		refurlVisitReportHourConstants.add(new Constants(EXPERIMENT_ID,REFURL_VISIT_REPORT_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		refurlVisitReportHourConstants.add(new Constants(VARIATION_ID,REFURL_VISIT_REPORT_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		refurlVisitReportHourConstants.add(new Constants(CODE,REFURL_VISIT_REPORT_HOUR.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		refurlVisitReportHourConstants.add(new Constants(TOTAL_COUNT,REFURL_VISIT_REPORT_HOUR.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		refurlVisitReportHourConstants.add(new Constants(TIME,REFURL_VISIT_REPORT_HOUR.TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		REFURL_VISIT_REPORT_HOUR_CONSTANTS = Collections.unmodifiableList(refurlVisitReportHourConstants);
	}
	
	public static final List<Constants> REFURL_VISIT_REPORT_DAY_CONSTANTS;
	
	static{
		List<Constants> refurlVisitReportDayConstants = new ArrayList<Constants>();
		refurlVisitReportDayConstants.add(new Constants(REFURL_VISIT_REPORT_DAY_ID,REFURL_VISIT_REPORT_DAY.REFURL_VISIT_REPORT_DAY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		refurlVisitReportDayConstants.add(new Constants(EXPERIMENT_ID,REFURL_VISIT_REPORT_DAY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		refurlVisitReportDayConstants.add(new Constants(VARIATION_ID,REFURL_VISIT_REPORT_DAY.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		refurlVisitReportDayConstants.add(new Constants(CODE,REFURL_VISIT_REPORT_DAY.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		refurlVisitReportDayConstants.add(new Constants(TOTAL_COUNT,REFURL_VISIT_REPORT_DAY.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		refurlVisitReportDayConstants.add(new Constants(DATE,REFURL_VISIT_REPORT_DAY.DATE,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		REFURL_VISIT_REPORT_DAY_CONSTANTS = Collections.unmodifiableList(refurlVisitReportDayConstants);
	}
	

	public static final List<Constants> DAYOFWK_VISIT_REPORT_HOUR_CONSTANTS;
	
	static{
		List<Constants> dayOfWeekVisitReportHourConstants = new ArrayList<Constants>();
		dayOfWeekVisitReportHourConstants.add(new Constants(DAYOFWK_VISIT_REPORT_HOUR_ID,DAYOFWK_VISIT_REPORT_HOUR.DAYOFWK_VISIT_REPORT_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		dayOfWeekVisitReportHourConstants.add(new Constants(EXPERIMENT_ID,DAYOFWK_VISIT_REPORT_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		dayOfWeekVisitReportHourConstants.add(new Constants(VARIATION_ID,DAYOFWK_VISIT_REPORT_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		dayOfWeekVisitReportHourConstants.add(new Constants(CODE,DAYOFWK_VISIT_REPORT_HOUR.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		dayOfWeekVisitReportHourConstants.add(new Constants(TOTAL_COUNT,DAYOFWK_VISIT_REPORT_HOUR.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		dayOfWeekVisitReportHourConstants.add(new Constants(TIME,DAYOFWK_VISIT_REPORT_HOUR.TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		DAYOFWK_VISIT_REPORT_HOUR_CONSTANTS = Collections.unmodifiableList(dayOfWeekVisitReportHourConstants);
	}
	
	public static final List<Constants> DAYOFWK_VISIT_REPORT_DAY_CONSTANTS;
	
	static{
		List<Constants> dayOfWeekVisitReportDayConstants = new ArrayList<Constants>();
		dayOfWeekVisitReportDayConstants.add(new Constants(DAYOFWK_VISIT_REPORT_DAY_ID,DAYOFWK_VISIT_REPORT_DAY.DAYOFWK_VISIT_REPORT_DAY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		dayOfWeekVisitReportDayConstants.add(new Constants(EXPERIMENT_ID,DAYOFWK_VISIT_REPORT_DAY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		dayOfWeekVisitReportDayConstants.add(new Constants(VARIATION_ID,DAYOFWK_VISIT_REPORT_DAY.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		dayOfWeekVisitReportDayConstants.add(new Constants(CODE,DAYOFWK_VISIT_REPORT_DAY.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		dayOfWeekVisitReportDayConstants.add(new Constants(TOTAL_COUNT,DAYOFWK_VISIT_REPORT_DAY.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		dayOfWeekVisitReportDayConstants.add(new Constants(DATE,DAYOFWK_VISIT_REPORT_DAY.DATE,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		DAYOFWK_VISIT_REPORT_DAY_CONSTANTS = Collections.unmodifiableList(dayOfWeekVisitReportDayConstants);
	}
	

	public static final List<Constants> HOURODY_VISIT_REPORT_HOUR_CONSTANTS;
	
	static{
		List<Constants> hourOfDayVisitReportHourConstants = new ArrayList<Constants>();
		hourOfDayVisitReportHourConstants.add(new Constants(HOURODY_VISIT_REPORT_HOUR_ID,HOURODY_VISIT_REPORT_HOUR.HOURODY_VISIT_REPORT_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		hourOfDayVisitReportHourConstants.add(new Constants(EXPERIMENT_ID,HOURODY_VISIT_REPORT_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		hourOfDayVisitReportHourConstants.add(new Constants(VARIATION_ID,HOURODY_VISIT_REPORT_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		hourOfDayVisitReportHourConstants.add(new Constants(CODE,HOURODY_VISIT_REPORT_HOUR.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		hourOfDayVisitReportHourConstants.add(new Constants(TOTAL_COUNT,HOURODY_VISIT_REPORT_HOUR.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		hourOfDayVisitReportHourConstants.add(new Constants(TIME,HOURODY_VISIT_REPORT_HOUR.TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		HOURODY_VISIT_REPORT_HOUR_CONSTANTS = Collections.unmodifiableList(hourOfDayVisitReportHourConstants);
	}
	
	public static final List<Constants> HOURODY_VISIT_REPORT_DAY_CONSTANTS;
	
	static{
		List<Constants> hourOfDayVisitReportDayConstants = new ArrayList<Constants>();
		hourOfDayVisitReportDayConstants.add(new Constants(HOURODY_VISIT_REPORT_DAY_ID,HOURODY_VISIT_REPORT_DAY.HOURODY_VISIT_REPORT_DAY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		hourOfDayVisitReportDayConstants.add(new Constants(EXPERIMENT_ID,HOURODY_VISIT_REPORT_DAY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		hourOfDayVisitReportDayConstants.add(new Constants(VARIATION_ID,HOURODY_VISIT_REPORT_DAY.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		hourOfDayVisitReportDayConstants.add(new Constants(CODE,HOURODY_VISIT_REPORT_DAY.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		hourOfDayVisitReportDayConstants.add(new Constants(TOTAL_COUNT,HOURODY_VISIT_REPORT_DAY.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		hourOfDayVisitReportDayConstants.add(new Constants(DATE,HOURODY_VISIT_REPORT_DAY.DATE,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		HOURODY_VISIT_REPORT_DAY_CONSTANTS = Collections.unmodifiableList(hourOfDayVisitReportDayConstants);
	}
	

	public static final List<Constants> COOKIE_VISIT_REPORT_HOUR_CONSTANTS;
	
	static{
		List<Constants> cookieVisitReportHourConstants = new ArrayList<Constants>();
		cookieVisitReportHourConstants.add(new Constants(COOKIE_VISIT_REPORT_HOUR_ID,COOKIE_VISIT_REPORT_HOUR.COOKIE_VISIT_REPORT_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		cookieVisitReportHourConstants.add(new Constants(EXPERIMENT_ID,COOKIE_VISIT_REPORT_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		cookieVisitReportHourConstants.add(new Constants(VARIATION_ID,COOKIE_VISIT_REPORT_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		cookieVisitReportHourConstants.add(new Constants(DYNAMIC_ATTRIBUTE_ID,COOKIE_VISIT_REPORT_HOUR.DYNAMIC_ATTRIBUTE_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		cookieVisitReportHourConstants.add(new Constants(CODE,COOKIE_VISIT_REPORT_HOUR.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		cookieVisitReportHourConstants.add(new Constants(TOTAL_COUNT,COOKIE_VISIT_REPORT_HOUR.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		cookieVisitReportHourConstants.add(new Constants(TIME,COOKIE_VISIT_REPORT_HOUR.TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		COOKIE_VISIT_REPORT_HOUR_CONSTANTS = Collections.unmodifiableList(cookieVisitReportHourConstants);
	}
	
	public static final List<Constants> COOKIE_VISIT_REPORT_DAY_CONSTANTS;
	
	static{
		List<Constants> cookieVisitReportDayConstants = new ArrayList<Constants>();
		cookieVisitReportDayConstants.add(new Constants(COOKIE_VISIT_REPORT_DAY_ID,COOKIE_VISIT_REPORT_DAY.COOKIE_VISIT_REPORT_DAY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		cookieVisitReportDayConstants.add(new Constants(EXPERIMENT_ID,COOKIE_VISIT_REPORT_DAY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		cookieVisitReportDayConstants.add(new Constants(VARIATION_ID,COOKIE_VISIT_REPORT_DAY.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		cookieVisitReportDayConstants.add(new Constants(DYNAMIC_ATTRIBUTE_ID,COOKIE_VISIT_REPORT_DAY.DYNAMIC_ATTRIBUTE_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		cookieVisitReportDayConstants.add(new Constants(CODE,COOKIE_VISIT_REPORT_DAY.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		cookieVisitReportDayConstants.add(new Constants(TOTAL_COUNT,COOKIE_VISIT_REPORT_DAY.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		cookieVisitReportDayConstants.add(new Constants(DATE,COOKIE_VISIT_REPORT_DAY.DATE,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		COOKIE_VISIT_REPORT_DAY_CONSTANTS = Collections.unmodifiableList(cookieVisitReportDayConstants);
	}
	

	public static final List<Constants> URLPARM_VISIT_REPORT_HOUR_CONSTANTS;
	
	static{
		List<Constants> urlParamVisitReportHourConstants = new ArrayList<Constants>();
		urlParamVisitReportHourConstants.add(new Constants(URLPARM_VISIT_REPORT_HOUR_ID,URLPARM_VISIT_REPORT_HOUR.URLPARM_VISIT_REPORT_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		urlParamVisitReportHourConstants.add(new Constants(EXPERIMENT_ID,URLPARM_VISIT_REPORT_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		urlParamVisitReportHourConstants.add(new Constants(VARIATION_ID,URLPARM_VISIT_REPORT_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		urlParamVisitReportHourConstants.add(new Constants(DYNAMIC_ATTRIBUTE_ID,URLPARM_VISIT_REPORT_HOUR.DYNAMIC_ATTRIBUTE_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		urlParamVisitReportHourConstants.add(new Constants(CODE,URLPARM_VISIT_REPORT_HOUR.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		urlParamVisitReportHourConstants.add(new Constants(TOTAL_COUNT,URLPARM_VISIT_REPORT_HOUR.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		urlParamVisitReportHourConstants.add(new Constants(TIME,URLPARM_VISIT_REPORT_HOUR.TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		URLPARM_VISIT_REPORT_HOUR_CONSTANTS = Collections.unmodifiableList(urlParamVisitReportHourConstants);
	}
	
	public static final List<Constants> URLPARM_VISIT_REPORT_DAY_CONSTANTS;
	
	static{
		List<Constants> urlParamVisitReportDayConstants = new ArrayList<Constants>();
		urlParamVisitReportDayConstants.add(new Constants(URLPARM_VISIT_REPORT_DAY_ID,URLPARM_VISIT_REPORT_DAY.URLPARM_VISIT_REPORT_DAY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		urlParamVisitReportDayConstants.add(new Constants(EXPERIMENT_ID,URLPARM_VISIT_REPORT_DAY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		urlParamVisitReportDayConstants.add(new Constants(VARIATION_ID,URLPARM_VISIT_REPORT_DAY.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		urlParamVisitReportDayConstants.add(new Constants(DYNAMIC_ATTRIBUTE_ID,URLPARM_VISIT_REPORT_DAY.DYNAMIC_ATTRIBUTE_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		urlParamVisitReportDayConstants.add(new Constants(CODE,URLPARM_VISIT_REPORT_DAY.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		urlParamVisitReportDayConstants.add(new Constants(TOTAL_COUNT,URLPARM_VISIT_REPORT_DAY.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		urlParamVisitReportDayConstants.add(new Constants(DATE,URLPARM_VISIT_REPORT_DAY.DATE,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		URLPARM_VISIT_REPORT_DAY_CONSTANTS = Collections.unmodifiableList(urlParamVisitReportDayConstants);
	}
	

	public static final List<Constants> JSVAR_VISIT_REPORT_HOUR_CONSTANTS;
	
	static{
		List<Constants> jsvarVisitReportHourConstants = new ArrayList<Constants>();
		jsvarVisitReportHourConstants.add(new Constants(JSVAR_VISIT_REPORT_HOUR_ID,JSVAR_VISIT_REPORT_HOUR.JSVAR_VISIT_REPORT_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		jsvarVisitReportHourConstants.add(new Constants(EXPERIMENT_ID,JSVAR_VISIT_REPORT_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		jsvarVisitReportHourConstants.add(new Constants(VARIATION_ID,JSVAR_VISIT_REPORT_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		jsvarVisitReportHourConstants.add(new Constants(DYNAMIC_ATTRIBUTE_ID,JSVAR_VISIT_REPORT_HOUR.DYNAMIC_ATTRIBUTE_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		jsvarVisitReportHourConstants.add(new Constants(CODE,JSVAR_VISIT_REPORT_HOUR.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		jsvarVisitReportHourConstants.add(new Constants(TOTAL_COUNT,JSVAR_VISIT_REPORT_HOUR.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		jsvarVisitReportHourConstants.add(new Constants(TIME,JSVAR_VISIT_REPORT_HOUR.TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		JSVAR_VISIT_REPORT_HOUR_CONSTANTS = Collections.unmodifiableList(jsvarVisitReportHourConstants);
	}
	
	public static final List<Constants> JSVAR_VISIT_REPORT_DAY_CONSTANTS;
	
	static{
		List<Constants> jsvarVisitReportDayConstants = new ArrayList<Constants>();
		jsvarVisitReportDayConstants.add(new Constants(JSVAR_VISIT_REPORT_DAY_ID,JSVAR_VISIT_REPORT_DAY.JSVAR_VISIT_REPORT_DAY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		jsvarVisitReportDayConstants.add(new Constants(EXPERIMENT_ID,JSVAR_VISIT_REPORT_DAY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		jsvarVisitReportDayConstants.add(new Constants(VARIATION_ID,JSVAR_VISIT_REPORT_DAY.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		jsvarVisitReportDayConstants.add(new Constants(DYNAMIC_ATTRIBUTE_ID,JSVAR_VISIT_REPORT_DAY.DYNAMIC_ATTRIBUTE_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		jsvarVisitReportDayConstants.add(new Constants(CODE,JSVAR_VISIT_REPORT_DAY.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		jsvarVisitReportDayConstants.add(new Constants(TOTAL_COUNT,JSVAR_VISIT_REPORT_DAY.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		jsvarVisitReportDayConstants.add(new Constants(DATE,JSVAR_VISIT_REPORT_DAY.DATE,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		JSVAR_VISIT_REPORT_DAY_CONSTANTS = Collections.unmodifiableList(jsvarVisitReportDayConstants);
	}
	
	public static final List<Constants> CUSTDIM_VISIT_REPORT_HOUR_CONSTANTS;
	
	static{
		List<Constants> custdimVisitReportHourConstants = new ArrayList<Constants>();
		custdimVisitReportHourConstants.add(new Constants(CUSTDIM_VISIT_REPORT_HOUR_ID,CUSTDIM_VISIT_REPORT_HOUR.CUSTDIM_VISIT_REPORT_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		custdimVisitReportHourConstants.add(new Constants(EXPERIMENT_ID,CUSTDIM_VISIT_REPORT_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		custdimVisitReportHourConstants.add(new Constants(VARIATION_ID,CUSTDIM_VISIT_REPORT_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		custdimVisitReportHourConstants.add(new Constants(DYNAMIC_ATTRIBUTE_ID,CUSTDIM_VISIT_REPORT_HOUR.DYNAMIC_ATTRIBUTE_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		custdimVisitReportHourConstants.add(new Constants(CODE,CUSTDIM_VISIT_REPORT_HOUR.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		custdimVisitReportHourConstants.add(new Constants(TOTAL_COUNT,CUSTDIM_VISIT_REPORT_HOUR.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		custdimVisitReportHourConstants.add(new Constants(TIME,CUSTDIM_VISIT_REPORT_HOUR.TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		CUSTDIM_VISIT_REPORT_HOUR_CONSTANTS = Collections.unmodifiableList(custdimVisitReportHourConstants);
	}
	
	public static final List<Constants> CUSTDIM_VISIT_REPORT_DAY_CONSTANTS;
	
	static{
		List<Constants> custdimVisitReportDayConstants = new ArrayList<Constants>();
		custdimVisitReportDayConstants.add(new Constants(CUSTDIM_VISIT_REPORT_DAY_ID,CUSTDIM_VISIT_REPORT_DAY.CUSTDIM_VISIT_REPORT_DAY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		custdimVisitReportDayConstants.add(new Constants(EXPERIMENT_ID,CUSTDIM_VISIT_REPORT_DAY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		custdimVisitReportDayConstants.add(new Constants(VARIATION_ID,CUSTDIM_VISIT_REPORT_DAY.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		custdimVisitReportDayConstants.add(new Constants(DYNAMIC_ATTRIBUTE_ID,CUSTDIM_VISIT_REPORT_DAY.DYNAMIC_ATTRIBUTE_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		custdimVisitReportDayConstants.add(new Constants(CODE,CUSTDIM_VISIT_REPORT_DAY.CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		custdimVisitReportDayConstants.add(new Constants(TOTAL_COUNT,CUSTDIM_VISIT_REPORT_DAY.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		custdimVisitReportDayConstants.add(new Constants(DATE,CUSTDIM_VISIT_REPORT_DAY.DATE,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		CUSTDIM_VISIT_REPORT_DAY_CONSTANTS = Collections.unmodifiableList(custdimVisitReportDayConstants);
	}
	
}
