//$Id$
package com.zoho.abtest.report;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.report.ReportArchieveDimensionConstants.ReportDurationType;
import com.zoho.abtest.ARCHIEVE_TABLE_META;

public class ArchieveTableMeta extends ZABModel{
	
	private static final Logger LOGGER = Logger.getLogger(ArchieveTableMeta.class.getName());
	private static final long serialVersionUID = 1L;
	private Long archieveTableId;
	private String columnName;
	private String groupByColumns;
	private String resultArchieveTable;
	private String visitorIdsTable;
	private Integer durationType;
	private Integer moduleType;
	private Long lastArchievedTime;
	private Boolean isStandardDimension;
	
	public Boolean getIsStandardDimension() {
		return isStandardDimension;
	}
	public void setIsStandardDimension(Boolean isStandardDimension) {
		this.isStandardDimension = isStandardDimension;
	}
	public Long getArchieveTableId() {
		return archieveTableId;
	}
	public void setArchieveTableId(Long archieveTableId) {
		this.archieveTableId = archieveTableId;
	}
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	public String getGroupByColumns() {
		return groupByColumns;
	}
	public void setGroupByColumns(String groupByColumns) {
		this.groupByColumns = groupByColumns;
	}
	public String getResultArchieveTable() {
		return resultArchieveTable;
	}
	public void setResultArchieveTable(String resultArchieveTable) {
		this.resultArchieveTable = resultArchieveTable;
	}
	public String getVisitorIdsTable() {
		return visitorIdsTable;
	}
	public void setVisitorIdsTable(String visitorIdsTable) {
		this.visitorIdsTable = visitorIdsTable;
	}
	public Integer getDurationType() {
		return durationType;
	}
	public void setDurationType(Integer durationType) {
		this.durationType = durationType;
	}
	public Integer getModuleType() {
		return moduleType;
	}
	public void setModuleType(Integer moduleType) {
		this.moduleType = moduleType;
	}
	public Long getLastArchievedTime() {
		return lastArchievedTime;
	}
	public void setLastArchievedTime(Long lastArchievedTime) {
		this.lastArchievedTime = lastArchievedTime;
	}
	
	public static void createArchieveTableMeta(HashMap<String, String> hs)
	{
		try
		{
			ZABModel.createRow(ReportArchieveDimensionConstants.ARCHIEVE_TABLE_META_CONSTANTS, ARCHIEVE_TABLE_META.TABLE, hs);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
	}
	
	public static void createArchieveTableMeta(ArrayList<HashMap<String, String>> hsList)
	{
		try
		{
			ZABModel.createRow(ReportArchieveDimensionConstants.ARCHIEVE_TABLE_META_CONSTANTS, ARCHIEVE_TABLE_META.TABLE, hsList);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
	}
	
	public static void updateArchieveTableMeta(HashMap<String, String> hs)
	{
		try
		{
			Criteria criteria = new Criteria(new Column(ARCHIEVE_TABLE_META.TABLE,ARCHIEVE_TABLE_META.ARCHIEVE_TABLE_ID),hs.get(ReportArchieveDimensionConstants.ARCHIEVE_TABLE_ID),QueryConstants.EQUAL);
			ZABModel.updateRow(ReportArchieveDimensionConstants.ARCHIEVE_TABLE_META_CONSTANTS, ARCHIEVE_TABLE_META.TABLE, hs, criteria, null);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
	}
	
	public static List<ArchieveTableMeta> getArchieveTableMetaDetails()
	{
		List<ArchieveTableMeta> archieveTableMetaDetails = null;
		ArchieveTableMeta archieveTableMeta = null;
		try
		{
			DataObject dataObj = ZABModel.getRow(ARCHIEVE_TABLE_META.TABLE, null);
			Iterator<?> iterator = dataObj.getRows(ARCHIEVE_TABLE_META.TABLE);
			archieveTableMetaDetails = new ArrayList<ArchieveTableMeta>();
			while(iterator.hasNext())
			{
				Row row = (Row)iterator.next();
				archieveTableMeta = getArchieveTableMetaFromRow(row);
				archieveTableMetaDetails.add(archieveTableMeta);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			archieveTableMetaDetails = new ArrayList<ArchieveTableMeta>();
		}
		return archieveTableMetaDetails;
	}
	
	public static List<ArchieveTableMeta> getHourlyArchieveTableMetaDetails()
	{
		List<ArchieveTableMeta> archieveTableMetaDetails = null;
		ArchieveTableMeta archieveTableMeta = null;
		try
		{
			Criteria criteria = new Criteria(new Column(ARCHIEVE_TABLE_META.TABLE,ARCHIEVE_TABLE_META.DURATION_TYPE), ReportDurationType.HOUR.getDurationCode(), QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(ARCHIEVE_TABLE_META.TABLE, criteria);
			Iterator<?> iterator = dataObj.getRows(ARCHIEVE_TABLE_META.TABLE);
			archieveTableMetaDetails = new ArrayList<ArchieveTableMeta>();
			while(iterator.hasNext())
			{
				Row row = (Row)iterator.next();
				archieveTableMeta = getArchieveTableMetaFromRow(row);
				archieveTableMetaDetails.add(archieveTableMeta);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			archieveTableMetaDetails = new ArrayList<ArchieveTableMeta>();
		}
		return archieveTableMetaDetails;
	} 
	
	public static List<ArchieveTableMeta> getDailyArchieveTableMetaDetails()
	{
		List<ArchieveTableMeta> archieveTableMetaDetails = null;
		ArchieveTableMeta archieveTableMeta = null;
		try
		{
			Criteria criteria = new Criteria(new Column(ARCHIEVE_TABLE_META.TABLE,ARCHIEVE_TABLE_META.DURATION_TYPE), ReportDurationType.DAY.getDurationCode(), QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(ARCHIEVE_TABLE_META.TABLE, criteria);
			Iterator<?> iterator = dataObj.getRows(ARCHIEVE_TABLE_META.TABLE);
			archieveTableMetaDetails = new ArrayList<ArchieveTableMeta>();
			while(iterator.hasNext())
			{
				Row row = (Row)iterator.next();
				archieveTableMeta = getArchieveTableMetaFromRow(row);
				archieveTableMetaDetails.add(archieveTableMeta);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			archieveTableMetaDetails = new ArrayList<ArchieveTableMeta>();
		}
		return archieveTableMetaDetails;
	} 
	
	public static ArchieveTableMeta getArchieveTableMetaFromRow(Row row)
	{
		ArchieveTableMeta archieveTableMeta = new ArchieveTableMeta(); 
		try
		{
			archieveTableMeta.setArchieveTableId((Long)row.get(ARCHIEVE_TABLE_META.ARCHIEVE_TABLE_ID));
			archieveTableMeta.setColumnName((String)row.get(ARCHIEVE_TABLE_META.COLUMN_NAME));
			archieveTableMeta.setGroupByColumns((String)row.get(ARCHIEVE_TABLE_META.GROUP_BY_COLUMNS));
			archieveTableMeta.setResultArchieveTable((String)row.get(ARCHIEVE_TABLE_META.RESULT_ARCHIEVE_TABLE));
			archieveTableMeta.setVisitorIdsTable((String)row.get(ARCHIEVE_TABLE_META.VISITOR_IDS_TABLE));
			archieveTableMeta.setDurationType((Integer)row.get(ARCHIEVE_TABLE_META.DURATION_TYPE));
			archieveTableMeta.setModuleType((Integer)row.get(ARCHIEVE_TABLE_META.MODULE_TYPE));
			archieveTableMeta.setLastArchievedTime((Long)row.get(ARCHIEVE_TABLE_META.LAST_ARCHIEVED_TIME));
			archieveTableMeta.setIsStandardDimension((Boolean)row.get(ARCHIEVE_TABLE_META.IS_STANDARD_DIMENSION));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			archieveTableMeta = new ArchieveTableMeta();
		}
		return archieveTableMeta;
	}
	

}
