//$Id$
package com.zoho.abtest.report;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABRequest;
import com.zoho.abtest.funnel.report.FunnelReportConstants;
import com.zoho.abtest.listener.ZABNotifier;
import com.zoho.abtest.sessionrecording.SessionReportConstants;

import com.zoho.abtest.trigger.TriggerConstants.TriggerType;
import com.zoho.abtest.utility.ApplicationProperty;

import com.zoho.abtest.utility.ZABUtil;

public class RawData extends HttpServlet {
	
	private static final Logger LOGGER = Logger.getLogger(RawData.class.getName());
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public void init(ServletConfig config) throws ServletException {
	    super.init(config);
	}
	
	public void doGet(HttpServletRequest request,HttpServletResponse response)  
			throws ServletException,IOException  
	{  
		processRawData(request,response);
	}
	public void doPost(HttpServletRequest request,HttpServletResponse response)  
			throws ServletException,IOException  
	{  
		processRawData(request,response);
	}
	
	private boolean checkCORS(HttpServletRequest request,HttpServletResponse response) throws MalformedURLException {
//		String origin = request.getHeader("Origin");
//		if(origin == null) {
//			return true;
//		} else if(origin.equals(validOrigin)) {			
//			response.setHeader("Access-Control-Allow-Origin", validOrigin); //NO I18N
//			LOGGER.log(Level.INFO, "CORS success");
//			return true;
//		}
//		LOGGER.log(Level.SEVERE, "CORS failure for origin:"+origin);
//		return false;
		//Allowing for all domains
		response.setHeader("Access-Control-Allow-Origin", "*"); //NO I18N
		return true;
	}
	
	public void processRawData(HttpServletRequest request,HttpServletResponse response) throws IOException{

		String type = request.getParameter("type");
		switch(type){
		case "1":		// VISITOR RAW DATA
			visitorRawData(request,response);
			break;
		case "2":		// GOAL RAW DATA
			addGoalRawdata(request,response);
			break;
		case "3":		// HEAT MAP RAW DATA
			addHeatmapRawdata(request,response);
			break;
		case "4":		// HEAT MAP RAW DATA
			addScrollmapRawdata(request,response);
			break;
		case "5":		// HEAT MAP RAW DATA
			addFunnelRawData(request, response);
			break;
		case "6": // FORM ANALYTICS RAW DATA
			addFormAnalyticsRawData(request, response);
			break;
		case "7":		// SESSION RAW DATA
			addSessionRawData(request, response);
			break;
		case "8":		// SESSION EVENT DATA
			addSessionEventData(request, response);
			break;
		case "9":		//Consent - Opted for "Count me out"
			handleConsent(request, response);
			break;
		case "10" : // update userType in sessionRawData
			identityData(request, response);
		}
		
		FileInputStream inStream =null;
		OutputStream outStream = null;
		try{
			// obtains ServletContext
	        ServletContext context = getServletContext();
	      
	        String imagePath = "/psimg.gif"; // NO I18N
	       
	        // reads input file from an absolute path
	        String filePath = context.getRealPath(imagePath);
	        File downloadFile = new File(filePath);
	        inStream = new FileInputStream(downloadFile);
	         
	        // gets MIME type of the file
	        String mimeType = context.getMimeType(filePath);
	        if (mimeType == null) {        
	            // set to binary type if MIME mapping not found
	            mimeType = "application/octet-stream";  // NO I18N
	        }
	     
	        // modifies response
	        response.setContentType(mimeType);
	        response.setContentLength((int) downloadFile.length());
	         
	        // forces download
	        String headerKey = "Content-Disposition";  // NO I18N
	        String headerValue = String.format("attachment; filename=\"%s\"", downloadFile.getName()); // NO I18N
	        response.setHeader(headerKey, headerValue);
	         
	        // obtains response's output stream
	        outStream = response.getOutputStream();
	         
	        byte[] buffer = new byte[4096];
	        int bytesRead = -1;
	         
	        while ((bytesRead = inStream.read(buffer)) != -1) {
	            outStream.write(buffer, 0, bytesRead);
	        }	    
			
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE,"Error while setting image in response " + ex.getMessage(),ex);
		}finally{
			if(inStream != null){
				inStream.close();
			}
			if(outStream != null){
				outStream.close();     
			}
		}
	}
	
	public void identityData(HttpServletRequest request,HttpServletResponse response) {
		try
		{
			LOGGER.log(Level.INFO, "Identity Module Starts");
			
			String inputJson = request.getParameter("raw"); //No I18N
			
			HashMap<String,String> map = ZABAction.parseJSON(ZABAction.parseModuleInputObject(inputJson, "ird")); //No I18N
			
			VisitorRawDataWrapper wrapper = new VisitorRawDataWrapper();
			wrapper.setIdentityData(map);
			
			LOGGER.log(Level.INFO,"!!! Identity Data Received: {}",wrapper);
			ZABNotifier.notifyListeners(ReportRawDataConstants.IDENTITY_DATA_NOTIFIER_NAME, wrapper);
			
			LOGGER.log(Level.INFO, "Identity Module Ends");
		}catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
		}	   
	}
	
	public void addSessionRawData(HttpServletRequest request,HttpServletResponse response) {
		try
		{
			if(checkCORS(request, response)) {
				Long start = new Date().getTime();
				LOGGER.log(Level.INFO,"ZZZZZZZ Session Raw data started");
				String inputString = ZABAction.getInputString(request);
				ZABUtil.setCurrentInputString(inputString);
				
				Gson gson = new Gson();
				JsonElement element = gson.fromJson(inputString, JsonElement.class);
				JsonObject object = element.getAsJsonObject();
				
				
				VisitorRawDataWrapper wrapper = new VisitorRawDataWrapper();
				ArrayList<HashMap<String, String>> sessionRawData = ZABAction.getRequestParser(request).parseSessionRawData(object, SessionReportConstants.API_MODULE_SESSION_RAW_SH);
				wrapper.setSessionRawData(sessionRawData);
				
				String sessionEventData = ZABAction.getRequestParser(request).parseSessionEventData(object, SessionReportConstants.API_MODULE_SESSION_EVENT_PF_SH);
				wrapper.setSessionEventData(sessionEventData);
				wrapper.bufferSessionEvent();
				
				HashMap<String, String> userAgentHashmap = ZABAction.getRequestParser(request).parseSessionUAData(object, FunnelReportConstants.API_MODULE_USERAGENT_RAW_SH);
				wrapper.setUserAgenths(userAgentHashmap);
				wrapper.bufferSessionPage();
				
				LOGGER.log(Level.INFO,"!!! Session Raw data Received: {0}",wrapper);
				ZABNotifier.notifyListeners(SessionReportConstants.SESSION_RAW_NOTIFIER_NAME, wrapper);
				LOGGER.log(Level.INFO,"ZZZZZZZ Session Raw data end");
				Long end = new Date().getTime();
				LOGGER.log(Level.INFO,"Time taken to process session data:"+(end-start));
			}
		}catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
		}
	}
	
	public void addSessionEventData(HttpServletRequest request,HttpServletResponse response) {
		try
		{
			if(checkCORS(request, response)) {	
				Long start = new Date().getTime();
				String inputString = ZABAction.getInputString(request);
				ZABUtil.setCurrentInputString(inputString);
				
				Gson gson = new Gson();
				JsonElement element = gson.fromJson(inputString, JsonElement.class);
				JsonObject object = element.getAsJsonObject();
				
				
				
				VisitorRawDataWrapper wrapper = new VisitorRawDataWrapper();
				String sessionEventData = ZABAction.getRequestParser(request).parseSessionEventData(object, SessionReportConstants.API_MODULE_SESSION_EVENT_PF_SH);
				wrapper.setSessionEventData(sessionEventData);
				
				ArrayList<HashMap<String, String>> sessionRawData = ZABAction.getRequestParser(request).parseSessionRawData(object, SessionReportConstants.API_MODULE_SESSION_RAW_SH);
				wrapper.setSessionRawData(sessionRawData);
				
				wrapper.bufferSessionEvent();
				LOGGER.log(Level.INFO,"!!! Session event data Received: {0}",wrapper);
				ZABNotifier.notifyListeners(SessionReportConstants.SESSION_EVENT_NOTIFIER_NAME, wrapper);
				Long end = new Date().getTime();
				LOGGER.log(Level.INFO,"Time taken to process session data:"+(end-start));
			}
		}catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
		}
	}
	
	public void handleConsent(HttpServletRequest request,HttpServletResponse response) {
		try
		{
			VisitorRawDataWrapper wrapper = new VisitorRawDataWrapper();
			wrapper.setIsOptOut(true);
			
			//Check for session data
			ArrayList<HashMap<String, String>> hs = ZABRequest.parseRawDataJSONArray(request, SessionReportConstants.API_MODULE_SESSION_RAW_SH);
			if(hs!=null) {
				wrapper.setOptOutData(hs);
				ZABNotifier.notifyListeners(SessionReportConstants.SESSION_RAW_NOTIFIER_NAME, wrapper);
			}
			
			LOGGER.log(Level.INFO, "Consent API");
		}catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
		}
	}
	
	public static void addFunnelRawData(HttpServletRequest request,HttpServletResponse response) {
		try
		{
			VisitorRawDataWrapper wrapper = new VisitorRawDataWrapper();
			HashMap<String, String> funnelData = ZABAction.getRequestParser(request).parseFunnelRawData(request, FunnelReportConstants.API_MODULE_FUNNEL_RAW_SH);
			wrapper.setFunnelData(funnelData);
			HashMap<String, String> userAgentHashmap = ZABAction.getRequestParser(request).parseFunnelRawData(request, FunnelReportConstants.API_MODULE_USERAGENT_RAW_SH);
			wrapper.setUserAgenths(userAgentHashmap);
			LOGGER.log(Level.INFO,"!!! Funnel Raw data Received: {0}",wrapper);
			ZABNotifier.notifyListeners(FunnelReportConstants.FUNNEL_RAW_NOTIFIER_NAME, wrapper);
		}catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
		}
	}
	
	public static void visitorRawData(HttpServletRequest request,HttpServletResponse response) throws IOException{
		try
		{
			ReportTester.incrementVisitorCount();
			ArrayList<HashMap<String,String>> mapArray = null;
			mapArray = ZABAction.getRequestParser(request).parseVisitorRawData(request,false);
			HashMap<String,String> userAgenths = mapArray.get(0);
			mapArray = ZABAction.getRequestParser(request).parseVisitorRawData(request,true);
			
			VisitorRawDataWrapper wrapper = new VisitorRawDataWrapper();
			wrapper.setUserAgenths(userAgenths);
			wrapper.setExperimentsData(mapArray);
			LOGGER.log(Level.INFO,"!!! Raw Data Received: {}",wrapper);
			ZABNotifier.notifyListeners(ReportRawDataConstants.VRAW_DATA_NOTIFIER_NAME, wrapper);
			//ZABAction.sendResponse(request,response,ZABAction.getMessage(ZABConstants.RESOURCE_ADD_SUCCESS));
		}  
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
			//ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ReportRawDataConstants.API_MODULE_VISITOR_RAW));
		}
		
	}
	public void addGoalRawdata(HttpServletRequest request,HttpServletResponse response) throws IOException
	{
		try
		{
			ReportTester.incrementGoalCount();
			ArrayList<HashMap<String,String>> mapArray = null;
			mapArray = ZABAction.getRequestParser(request).parseGoalRawData(request,false);
			HashMap<String,String> userAgenths = mapArray.get(0);
			
			mapArray = ZABAction.getRequestParser(request).parseGoalRawData(request,true);
			
			VisitorRawDataWrapper wrapper = new VisitorRawDataWrapper();
			wrapper.setUserAgenths(userAgenths);
			wrapper.setExperimentsData(mapArray);
			LOGGER.log(Level.INFO,"!!! Goal Data Received: {}",wrapper);
			ZABNotifier.notifyListeners(ReportRawDataConstants.GRAW_DATA_NOTIFIER_NAME, wrapper);	
		     Integrate.integrate(TriggerType.GOAL,wrapper);
			//	ZABAction.sendResponse(request,response,ZABAction.getMessage(ZABConstants.RESOURCE_ADD_SUCCESS));
		}  
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
		}
	}
	
	public String addHeatmapRawdata(HttpServletRequest request,HttpServletResponse response) throws IOException {
		
		try
		{
			
			ArrayList<HashMap<String,String>> mapArray = null;
			mapArray = ZABAction.getRequestParser(request).parseHeatmapRawData(request,ReportRawDataConstants.API_MODULE_HEATMAP_POINTS_SH);
			ArrayList<HashMap<String,String>> heatmappoints = mapArray;
			mapArray = ZABAction.getRequestParser(request).parseHeatmapRawData(request,ReportRawDataConstants.API_MODULE_USERAGENT_RAW_SH);
			HashMap<String,String> userAgenths = mapArray.get(0);
			mapArray = ZABAction.getRequestParser(request).parseHeatmapRawData(request,ReportRawDataConstants.API_MODULE_HEATMAP_RAW_SH);
			
			VisitorRawDataWrapper wrapper = new VisitorRawDataWrapper();
			wrapper.setHeatmapPoints(heatmappoints);
			wrapper.setExperimentsData(mapArray);
			wrapper.setUserAgenths(userAgenths);
			LOGGER.log(Level.INFO,"!!! Heat Data Received: {}",wrapper);
			ZABNotifier.notifyListeners(ReportRawDataConstants.HPRAW_DATA_NOTIFIER_NAME, wrapper);
			
		}catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
			//ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ReportRawDataConstants.API_MODULE_HEATMAP_RAW));
		}
			
		return null;
	}
	
	public String addScrollmapRawdata(HttpServletRequest request,HttpServletResponse response) throws IOException{		
		try
		{
			
			ArrayList<HashMap<String,String>> mapArray = null;
			mapArray = ZABAction.getRequestParser(request).parseScrollmapRawData(request,ReportRawDataConstants.API_MODULE_SCROLL_DATA_SH);
			ArrayList<HashMap<String,String>> scrolldata = mapArray;
			mapArray = ZABAction.getRequestParser(request).parseScrollmapRawData(request,ReportRawDataConstants.API_MODULE_USERAGENT_RAW_SH);
			HashMap<String,String> userAgenths = mapArray.get(0);
			mapArray = ZABAction.getRequestParser(request).parseScrollmapRawData(request,ReportRawDataConstants.API_MODULE_SCROLLMAP_RAW_SH);
			
			VisitorRawDataWrapper wrapper = new VisitorRawDataWrapper();
			wrapper.setScrollmapData(scrolldata);
			wrapper.setExperimentsData(mapArray);
			wrapper.setUserAgenths(userAgenths);
			LOGGER.log(Level.INFO,"!!! Scrollmap Data Received: {}",wrapper);
			ZABNotifier.notifyListeners(ReportRawDataConstants.SMRAW_DATA_NOTIFIER_NAME, wrapper);
			
		}catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
			//	ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ReportRawDataConstants.API_MODULE_SCROLLMAP_RAW));

		}
			
		return null;
	}
	
	public void addFormAnalyticsRawData(HttpServletRequest request, HttpServletResponse response)  {
		try
		{
			
			
			ArrayList<HashMap<String,String>> mapArray = null;
			mapArray = ZABAction.getRequestParser(request).parseFormAnalyticsRawData(request,ReportRawDataConstants.API_MODULE_FORMANALYTICS_RAW_SH);
			ArrayList<HashMap<String,String>> formdata = mapArray;
			mapArray = ZABAction.getRequestParser(request).parseFormAnalyticsRawData(request,ReportRawDataConstants.API_MODULE_USERAGENT_RAW_SH);
			HashMap<String,String> userAgenths = mapArray.get(0);
			mapArray = ZABAction.getRequestParser(request).parseFormAnalyticsRawData(request,ReportRawDataConstants.API_MODULE_FORMANALYTICSEXP_RAW_SH);
			HashMap<String,String> hs=mapArray.get(0);
			

			VisitorRawDataWrapper wrapper = new VisitorRawDataWrapper();
			wrapper.setFormanalyticspoints(formdata);
			wrapper.setUserAgenths(userAgenths);
			wrapper.setFormData(hs);

			LOGGER.log(Level.INFO,"!!! Form Analytics Data Received: {}",wrapper);
			ZABNotifier.notifyListeners(ReportRawDataConstants.FORMRAW_DATA_NOTIFIER_NAME, wrapper);
			
		}catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
		}
			
	}


}
