//$Id$
package com.zoho.abtest.report;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;
import com.zoho.abtest.goal.GoalConstants;
import com.zoho.abtest.revenue.RevenueChartReport;
import com.zoho.abtest.revenue.RevenueChartReportResponse;
import com.zoho.abtest.variation.VariationConstants;

public class ChartReportResponse {

	public static String jsonResponse(HttpServletRequest request,ArrayList<ChartReport> lst) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(lst);			
			JSONObject json = ZABResponse.updateMetaInfo(request, CumulativeReportConstants.API_MODULE, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){
			ex.toString();
		}
		return returnBuffer.toString();
	}

	public static JSONArray getJSONArray(ArrayList<ChartReport> lst) throws JSONException {
		JSONArray array = new JSONArray();
		int size =lst.size();
		for (int i=0;i<size;i++) {
			ChartReport ld=lst.get(i);
			JSONObject jsonObj = new JSONObject();

			jsonObj.put(VariationConstants.VARIATION_ID, ld.getVariationId());
			jsonObj.put(GoalConstants.GOAL_ID, ld.getGoalId());
			
			jsonObj.put(CumulativeReportConstants.VARIATION_LINK_NAME, ld.getVariationLinkName());
			jsonObj.put(CumulativeReportConstants.GOAL_LINK_NAME, ld.getGoalLinkName());
			
			jsonObj.put(CumulativeReportConstants.IS_PREDICTED, ld.getIsPredicted());
			

			HashMap<Long, Double> cumulativeConversionRate=ld.getCumulativeconversionRate();
			JSONArray converionRateArray = new JSONArray();
			HashMap<Long, Double> conversionRate=ld.getConversionRate();
			Set<Long> conversionRateKeys = conversionRate.keySet();
			Iterator<Long> conversionRateItr = conversionRateKeys.iterator();
			while(conversionRateItr.hasNext()){
				Long key = conversionRateItr.next();
				Double value  =  conversionRate.get(key);
				JSONObject json = new JSONObject ();
				json.put(ReportArchieveDimensionConstants.TIME, key);
				
				
				json.put(CumulativeReportConstants.UNIQUE_CNVERSION_RATE,  Math.round(value*10000.0)/100.0);
				try{
					json.put(CumulativeReportConstants.TOTAL_CNVERSION_RATE, Math.round(cumulativeConversionRate.get(key)*10000.0)/100.0 );
				}catch(Exception e){
					
				}
				converionRateArray.put(json);
				
			}
			jsonObj.put(CumulativeReportConstants.CONVERSION_RATE, converionRateArray);
			
			HashMap<Long, Double> predictedconversionRate=ld.getForecastconversionRate();
			JSONArray predictedConversionRateArray = new JSONArray();
			
			Set<Long> predictedconversionrateKeys = predictedconversionRate.keySet();
			Iterator<Long> predicteConversionrateItr = predictedconversionrateKeys.iterator();
			while(predicteConversionrateItr.hasNext()){
				Long key = predicteConversionrateItr.next();
				Double value  =  predictedconversionRate.get(key);
				JSONObject json = new JSONObject ();
				json.put(ReportArchieveDimensionConstants.TIME, key);
				json.put(CumulativeReportConstants.FORECAST_CONVERSION_RATE,  Math.round(value*10000.0)/100.0);
				
				predictedConversionRateArray.put(json);
			}
			jsonObj.put(CumulativeReportConstants.FORECAST_CONVERSION_RATE, predictedConversionRateArray);

			HashMap<Long, Double> cumulativeImprovements=ld.getCumulativeimprovement();
			JSONArray improvementArray = new JSONArray();
		//	HashMap<Long, Double> imrpovement=ld.getImprovement();
			Set<Long> imrpovementKeys = cumulativeImprovements.keySet();
			Iterator<Long> improvementItr = imrpovementKeys.iterator();
			while(improvementItr.hasNext()){
				Long key = improvementItr.next();
				Double value  =  cumulativeImprovements.get(key);
				JSONObject json = new JSONObject ();
				json.put(ReportArchieveDimensionConstants.TIME, key);
				/*if(value!=null){
					json.put(CumulativeReportConstants.UNIQUE_IMPROVEMENT,  Math.round(value*10000.0)/100.0);
				}else{
					json.put(CumulativeReportConstants.UNIQUE_IMPROVEMENT, 0.0);
				}
			*/
				try{
					json.put(CumulativeReportConstants.TOTAL_IMPROVEMENT,  Math.round(value*10000.0)/100.0 );
				}catch(Exception e){
					
				}
				improvementArray.put(json);
			}
			jsonObj.put(CumulativeReportConstants.IMPROVEMENT, improvementArray);
			
			HashMap<Long, Double> predictedimprovement=ld.getForecastimprovement();
			JSONArray predictedImprovementArray = new JSONArray();
			
			Set<Long> predictedimprovementKeys = predictedimprovement.keySet();
			Iterator<Long> predictImprovementItr = predictedimprovementKeys.iterator();
			while(predictImprovementItr.hasNext()){
				Long key = predictImprovementItr.next();
				Double value  =  predictedimprovement.get(key);
				JSONObject json = new JSONObject ();
				json.put(ReportArchieveDimensionConstants.TIME, key);
				json.put(CumulativeReportConstants.FORECAST_IMPROVEMENT, Math.round(value*10000.0)/100.0 );
				
				predictedImprovementArray.put(json);
			}
			jsonObj.put(CumulativeReportConstants.FORECAST_IMPROVEMENT, predictedImprovementArray);
			
			
			HashMap<Long, Long> cumulativevisitors=ld.getCumulativevisitors();
			JSONArray visitorsArray = new JSONArray();
			HashMap<Long, Long> visitors=ld.getVisitors();
			Set<Long> visitorsKeys = visitors.keySet();
			Iterator<Long> visitorsItr = visitorsKeys.iterator();
			while(visitorsItr.hasNext()){
				Long key = visitorsItr.next();
				Long value  =  visitors.get(key);
				JSONObject json = new JSONObject ();
				json.put(ReportArchieveDimensionConstants.TIME, key);
				json.put(ReportArchieveDimensionConstants.UNIQUE_VISITOR_COUNT, value);
				try{
					json.put(ReportArchieveDimensionConstants.TOTAL_VISITOR_COUNT, cumulativevisitors.get(key));
				}catch(Exception e){
					
				}
				visitorsArray.put(json);
			}
			jsonObj.put(CumulativeReportConstants.VISITORS, visitorsArray);
			
			HashMap<Long, Long> predictedvisitors=ld.getForecastvisitors();
			JSONArray predictedvisitorsArray = new JSONArray();
			
			Set<Long> predictedvisitorsKeys = predictedvisitors.keySet();
			Iterator<Long> predictedvisitorsItr = predictedvisitorsKeys.iterator();
			while(predictedvisitorsItr.hasNext()){
				Long key = predictedvisitorsItr.next();
				Long value  =  predictedvisitors.get(key);
				JSONObject json = new JSONObject ();
				json.put(ReportArchieveDimensionConstants.TIME, key);
				json.put(ReportArchieveDimensionConstants.FORECAST_VISITOR_COUNT, value);
				
				predictedvisitorsArray.put(json);
			}
			jsonObj.put(CumulativeReportConstants.FORECAST_VISITORS, predictedvisitorsArray);

			HashMap<Long, Long> cumulativeconversions=ld.getCumulativeconversions();
			JSONArray conversionArray = new JSONArray();
			HashMap<Long, Long> conversions=ld.getConversions();
			Set<Long> conversionKeys = conversions.keySet();
			Iterator<Long> conversionItr = conversionKeys.iterator();
			while(conversionItr.hasNext()){
				Long key = conversionItr.next();
				Long value  =  conversions.get(key);
				JSONObject json = new JSONObject ();
				json.put(ReportArchieveDimensionConstants.TIME, key);
				json.put(ReportArchieveDimensionConstants.UNIQUE_GOAL_ACHIEVED_COUNT, value);
				try{
					json.put(ReportArchieveDimensionConstants.TOTAL_GOAL_ACHIEVED_COUNT, cumulativeconversions.get(key));
				}catch(Exception e){
					
				}
				conversionArray.put(json);
				
			}
			jsonObj.put(CumulativeReportConstants.CONVERSIONS, conversionArray);
			
			HashMap<Long, Long> predictedconversions=ld.getForecastconversions();
			JSONArray predictedConversionsArray = new JSONArray();
			
			Set<Long> predictedconversionsKeys = predictedconversions.keySet();
			Iterator<Long> predicteConversionsItr = predictedconversionsKeys.iterator();
			while(predicteConversionsItr.hasNext()){
				Long key = predicteConversionsItr.next();
				Long value  =  predictedconversions.get(key);
				JSONObject json = new JSONObject ();
				json.put(ReportArchieveDimensionConstants.TIME, key);
				json.put(ReportArchieveDimensionConstants.FORECAST_GOAL_ACHIEVED_COUNT, value);
				
				predictedConversionsArray.put(json);
			}
			jsonObj.put(CumulativeReportConstants.FORECAST_CONVERSIONS, predictedConversionsArray);

			JSONArray significanceArray = new JSONArray();
			HashMap<Long, Double> significance=ld.getStatisticalSignificance();
			Set<Long> significanceKeys = significance.keySet();
			Iterator<Long> significanceItr = significanceKeys.iterator();
			while(significanceItr.hasNext()){
				Long key = significanceItr.next();
				Double value  =  significance.get(key);
				JSONObject json = new JSONObject ();
				json.put(ReportArchieveDimensionConstants.TIME, key);
				json.put(CumulativeReportConstants.UNIQUE_STATISTICAL_SIGNIFICANCE,  Math.round(value*10000.0)/100.0);
				significanceArray.put(json);
				
			}
			jsonObj.put(CumulativeReportConstants.SIGNIFICANCE, significanceArray);
			
			if(ld.getRevenueChart()!=null){
				RevenueChartReport revenue = ld.getRevenueChart();
				JSONObject revenueJson = RevenueChartReportResponse.getJSONArray(revenue);
				Iterator<String> revenuekeys = revenueJson.keys();
				while(revenuekeys.hasNext()){
					String key = revenuekeys.next();
					Object value  = revenueJson.get(key);
					jsonObj.put(key, value);
				}
			}
			
			HashMap<Long, Double> predictedsignigicance = ld.getForecastsignificance();
			JSONArray predictedsignigicanceArray = new JSONArray();
			
			Set<Long> predictedsignificanceKeys = predictedsignigicance.keySet();
			Iterator<Long> predictsignificanceItr = predictedsignificanceKeys.iterator();
			while(predictsignificanceItr.hasNext()){
				Long key = predictsignificanceItr.next();
				Double value  =  predictedsignigicance.get(key);
				JSONObject json = new JSONObject ();
				json.put(ReportArchieveDimensionConstants.TIME, key);
				json.put(CumulativeReportConstants.FORECAST_SIGNIFICANCE,  Math.round(value*10000.0)/100.0);
				
				predictedsignigicanceArray.put(json);
			}
			jsonObj.put(CumulativeReportConstants.FORECAST_SIGNIFICANCE, predictedsignigicanceArray);

			JSONArray timeSpentArray = new JSONArray();
			HashMap<Long, Long> timespent=ld.getAvgTime();
			Set<Long> timespentKeys = timespent.keySet();
			Iterator<Long> timespentItr = timespentKeys.iterator();
			while(timespentItr.hasNext()){
				Long key = timespentItr.next();
				Long value  =  timespent.get(key);
				JSONObject json = new JSONObject ();
				json.put(ReportArchieveDimensionConstants.TIME, key);
				json.put(ReportArchieveDimensionConstants.TIME_SPENT, value);
				timeSpentArray.put(json);
				
			}
			jsonObj.put(ReportArchieveDimensionConstants.TIME_SPENT, timeSpentArray);
			
			jsonObj.put(ZABConstants.SUCCESS, ld.getSuccess());
			jsonObj.put(ZABConstants.RESPONSE_STRING, ld.getResponseString());
			array.put(jsonObj);
		}
		return array;
	}
	

}
