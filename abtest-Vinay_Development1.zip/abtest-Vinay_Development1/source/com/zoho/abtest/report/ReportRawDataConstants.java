//$Id$
package com.zoho.abtest.report;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.variation.VariationConstants;
import com.zoho.abtest.GOAL_DATA_RAW_IDGEN;
import com.zoho.abtest.VISITOR_DATA_RAW_IDGEN;
import com.zoho.abtest.JSON_VISITOR_RAW_IDGEN;
import com.zoho.abtest.RAW_DATA_TABLE_DETAILS;


public class ReportRawDataConstants{
	
	public static final String RAW_TABLE_MODULE = "raw_table";	//NO I18N
	public static final String API_MODULE_VISITOR_RAW = "visitorrawdata"; //No I18N
	public static final String API_MODULE_GOAL_RAW = "goalrawdata"; //No I18N
	public static final String API_MODULE_USERAGENT_RAW = "useragentrawdata"; //No I18N
	
	public static final String API_MODULE_HEATMAP_RAW = "heatmaprawdata"; //No I18N
	public static final String API_MODULE_HEATMAP_POINTS = "heatmappoints"; //No I18N
	public static final String API_MODULE_SCROLL_DATA = "scrollmapdata"; //No I18N
	public static final String API_MODULE_SCROLLMAP_RAW = "scrollmaprawdata"; //No I18N
	public static final String API_MODULE_WEBHOOK = "WebhookListener"; //No I18N

	
	//SHORTHAND NOTATIONS
	public static final String API_MODULE_VISITOR_RAW_SH = "vrd"; //No I18N
	public static final String API_MODULE_GOAL_RAW_SH = "grd"; //No I18N
	public static final String API_MODULE_USERAGENT_RAW_SH = "urd"; //No I18N
	
	public static final String API_MODULE_FORMANALYTICS_RAW_SH = "forms"; //No I18N
	public static final String API_MODULE_FORMANALYTICSEXP_RAW_SH = "formrd"; //No I18N


	
	public static final String API_MODULE_HEATMAP_RAW_SH = "hrd"; //No I18N
	public static final String API_MODULE_HEATMAP_POINTS_SH = "hp"; //No I18N
	public static final String API_MODULE_SCROLL_DATA_SH = "sd"; //No I18N
	public static final String API_MODULE_SCROLLMAP_RAW_SH = "srd"; //No I18N


	public static final String VRAW_DATA_NOTIFIER_NAME = "VisitorRawDataListener"; //No I18N
	public static final String GRAW_DATA_NOTIFIER_NAME = "VisitorGoalRawDataListener"; //No I18N
	public static final String HPRAW_DATA_NOTIFIER_NAME = "VisitorHeatmapRawDataListener"; //No I18N
	public static final String SMRAW_DATA_NOTIFIER_NAME = "VisitorScrollmapRawDataListener"; //No I18N
	
	
	public static final String IDENTITY_DATA_NOTIFIER_NAME = "IdentityRawDataListener"; //No I18N

	public static final String FORMRAW_DATA_NOTIFIER_NAME = "VisitorFormRawDataListener"; //No I18N

	
	public static final String VISITOR_DATA_RAW = "VISITOR_DATA_RAW"; //No I18N
	public static final String GOAL_DATA_RAW = "GOAL_DATA_RAW"; //No I18N
	public static final String TIME_SPENT_DATA_RAW = "TIME_SPENT_DATA_RAW"; //No I18N
	public static final String HEATMAP_DATA_RAW = "HEATMAP_DATA_RAW"; //No I18N
	public static final String SCROLLMAP_DATA_RAW = "SCROLLMAP_DATA_RAW"; //No I18N
	
	public static final String EXPERIMENT_ID = ExperimentConstants.EXPERIMENT_ID; 
	public static final String VARIATION_ID = "variation_id"; //NO I18N
	public static final String SPACE_ID = "spaceId"; //NO I18N
	
	public static final String VISITOR_DATA_RAW_ID = "visitor_data_raw_id";			// No I18N
	public static final String GOAL_DATA_RAW_ID = "goal_data_raw_id";			// No I18N
	public static final String HEATMAP_DATA_RAW_ID = "heatmap_data_raw_id";			// No I18N
	public static final String TIME_SPENT_DATA_RAW_ID = "time_spent_data_raw_id";			// No I18N
	
	public static final String JSON_VISITOR_DATA_RAW_ID = "json_visitor_data_raw_id";			// No I18N
	
	public static final String UNKNOWN_VALUE = "UNKNOWN"; //NO I18N
	public static final String UNKNOWN_COUNTRY_CODE = "UNK"; //NO I18N
	public static final String UNKNOWN_LANGUAGE_CODE = "UNK"; //NO I18N
	public static final Long DEFAULT_VARIATION_ID_VALUE = 0l;
	
	public static final String RAW_DATA_TABLE_DETAILS_ID = "raw_data_table_details_id"; //NO I18N
	public static final String RAW_TABLE_NAME = "raw_table_name"; //NO I18N
	public static final String MODULE_TYPE = "module_type"; //NO I18N
	public static final String IS_ACTIVE = "is_active"; //NO I18N
	
	//SHORTHAND EXPERIMENT CONSTANTS
	public static final String PORTAL = "a";				      // NO I18N
	public static final String EXPERIMENT_KEY = "b";		      // NO I18N
	public static final String VARIATION_KEY = "c";				  // NO I18N
	public static final String IS_NEW_VISITOR = "n"; 		  	  // NO I18N
	public static final String GOAL_LINK_NAME = "gln"; 			  // NO I18N
	public static final String IS_GOAL_ACHIEVED_FIRST_TIME = "gft"; // NO I18N
	public static final String HEATMAP_ENABLED = "h";  //NO I18N
	public static final String PROJECT_KEY = "p";				  // NO I18N

	
	//SHORTHAND DYNAMICATTRIBUTES CONSTANT
	public static final String DYNAMICATTRIBUTES = "da"; 		  // NO I18N
	public static final String ATTRIBUTE_LINK_NAME = "ln"; // No I18N
	public static final String ATTRIBUTE_TYPE = "t"; // No I18N
	public static final String ATTRIBUTE_VALUE = "v"; // No I18N
	
	//SHORTHAND Unique visit Id
	public static final String UVID = "d"; //No I18N
	//Unique user goal activity Id
	public static final String UAID = "e"; //No I18N
	//Unique user Id
	public static final String UUID = "f"; //No I18N
	
	public static final String IDENTITY_DETAILS = "id"; //No I18N

		
		
	//SHORTHAND USERAGENT SHORTHAND CONSTANTS
	public static final String BROWSER_VALUE = "bv"; 		      //NO I18N
	public static final String LANGUAGE_DISPLAY_NAME = "ldn";     //NO I18N
	public static final String LANGUAGE_VALUE = "lv"; 			  //NO I18N
	public static final String OS_VALUE = "ov"; 				  //NO I18N
	public static final String DEVICE_VALUE = "dv"; 			  //NO I18N
	public static final String REFFERERURL_VALUE = "rv"; 	      //NO I18N
	public static final String CURRENTURL_VALUE = "cv"; 		  //NO I18N
	public static final String URLPARAMETER_VALUE = "up"; 		  //NO I18N
	public static final String PARAMETER_NAME = "pn"; 		  //NO I18N
	public static final String PARAMETER_VALUE = "pv"; 		  //NO I18N
	public static final String TRAFFICSOURCE_VALUE = "tv";        //NO I18N
	public static final String SCREEN_RESOLUTION_VALUE = "srv";   //NO I18N
	public static final String MOBILE_DEVICE_VALUE = "mdv";		  //NO I18N
	
	public static final String HTML_CONTENT_VALUE = "pv";		  //NO I18N
	
	public static final String REVENUE_VALUE = "r";		  //NO I18N
	public static final String EVENT_NAME = "ev";		  //NO I18N
	
	
	public static final String VISITOR_RAW_TYPE = "vrd";		  // NO I18N
	public static final String GOAL_RAW_TYPE = "grd";			  // NO I18N
	public static final String HEATMAP_RAW_TYPE = "hrd";		  // NO I18N
	
	//SHORTHAND HEATMAP CONSTANTS
	public static final String SELECTOR = "s"; //NO I18N
	public static final String POINTS = "p"; //NO I18N
	public static final String DISPLAY_TEXT = "dt"; //NO I18N
	public static final String POINT_X = "x";  //NO I18N
	public static final String POINT_Y = "y"; //NO I18N
	public static final String CLICKS = "c";  //NO I18N
	
	public static final String PAGE_ID = "p";   //NO I18N
	
	public static final String PAGE_PID = "pid";   //NO I18N
	
	public static final String FUNNEL_RETURNING_STEPVISIT = "fr";  //NO I18N

	public static final String TIME_SPENT = "ts";  //NO I18N
	
	public static final String ZSID = "zs"; //No I18N
	
	public static final String SESSION_TIME_FRAME = "tf";		// NO I18N
	
	public static final String SESSION_GOAL = "g";		// NO I18N
	
	public static final String SESSION_LAST_TIMER = "ets";		// NO I18N
	
	public static final String SESSION_TIMELINE_MAP = "tlm";		// NO I18N
	
	public static final String SESSION_PROGRESS_BAR = "pb";		// NO I18N
	
	public static final String SESSION_EVENT_PLAYLIST = "epl";		// NO I18N
	
	public static final String SESSION_PAGE_NAVIGATION = "pn";		// NO I18N
	
	public static final String SESSION_USER_EVENTS = "ue";		// NO I18N

	public static final String SESSION_EVENTS_ARRAY = "e";		// NO I18N
	
	public static final String USER_NAME = "un";		// NO I18N

	
	public static final List<Constants> VISITOR_DATA_RAW_IDGEN_CONSTANTS;
	
	static{
		List<Constants> visitorDataRawIdGenConstants = new ArrayList<Constants>();
		visitorDataRawIdGenConstants.add(new Constants(VISITOR_DATA_RAW_ID,VISITOR_DATA_RAW_IDGEN.VISITOR_DATA_RAW_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		VISITOR_DATA_RAW_IDGEN_CONSTANTS = Collections.unmodifiableList(visitorDataRawIdGenConstants);
	}
	
	public static final List<Constants> JSON_VISITOR_DATA_RAW_IDGEN_CONSTANTS;
	
	static{
		List<Constants> jsonVisitorDataRawIdGenConstants = new ArrayList<Constants>();
		jsonVisitorDataRawIdGenConstants.add(new Constants(JSON_VISITOR_DATA_RAW_ID,JSON_VISITOR_RAW_IDGEN.JSON_VISITOR_DATA_RAW_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		JSON_VISITOR_DATA_RAW_IDGEN_CONSTANTS = Collections.unmodifiableList(jsonVisitorDataRawIdGenConstants);
	}
	
	public static final List<Constants> GOAL_DATA_RAW_IDGEN_CONSTANTS;
	
	static{
		List<Constants> visitorDataRawIdGenConstants = new ArrayList<Constants>();
		visitorDataRawIdGenConstants.add(new Constants(GOAL_DATA_RAW_ID,GOAL_DATA_RAW_IDGEN.GOAL_DATA_RAW_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		GOAL_DATA_RAW_IDGEN_CONSTANTS = Collections.unmodifiableList(visitorDataRawIdGenConstants);
	}
	
	public static final List<Constants> RAW_DATA_TABLE_DETAILS_CONSTANTS;
	
	static{
		List<Constants> rawDataTableDetailsConstants = new ArrayList<Constants>();
		rawDataTableDetailsConstants.add(new Constants(RAW_DATA_TABLE_DETAILS_ID,RAW_DATA_TABLE_DETAILS.RAW_DATA_TABLE_DETAILS_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		rawDataTableDetailsConstants.add(new Constants(RAW_TABLE_NAME,RAW_DATA_TABLE_DETAILS.RAW_TABLE_NAME,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
		rawDataTableDetailsConstants.add(new Constants(MODULE_TYPE,RAW_DATA_TABLE_DETAILS.MODULE_TYPE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		rawDataTableDetailsConstants.add(new Constants(IS_ACTIVE,RAW_DATA_TABLE_DETAILS.IS_ACTIVE,ZABConstants.BOOLEAN,Boolean.TRUE,Boolean.FALSE));
		RAW_DATA_TABLE_DETAILS_CONSTANTS = Collections.unmodifiableList(rawDataTableDetailsConstants);
	}
}
