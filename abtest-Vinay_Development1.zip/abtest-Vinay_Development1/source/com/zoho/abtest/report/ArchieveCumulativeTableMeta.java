//$Id$
package com.zoho.abtest.report;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.ARCHIEVE_CUM_TABLE_META;
import com.zoho.abtest.ARCHIEVE_TABLE_META;
import com.zoho.abtest.common.ZABModel;

public class ArchieveCumulativeTableMeta extends ZABModel
{
	private static final Logger LOGGER = Logger.getLogger(ArchieveCumulativeTableMeta.class.getName());
	private static final long serialVersionUID = 1L;
	
	private Long archieveCumTableId;
	private String resultArchieveTable;
	private Long lastArchievedTime;
	
	public Long getArchieveCumTableId() {
		return archieveCumTableId;
	}
	public void setArchieveCumTableId(Long archieveCumTableId) {
		this.archieveCumTableId = archieveCumTableId;
	}
	public String getResultArchieveTable() {
		return resultArchieveTable;
	}
	public void setResultArchieveTable(String resultArchieveTable) {
		this.resultArchieveTable = resultArchieveTable;
	}
	public Long getLastArchievedTime() {
		return lastArchievedTime;
	}
	public void setLastArchievedTime(Long lastArchievedTime) {
		this.lastArchievedTime = lastArchievedTime;
	}
	
	public static void createArchieveCumulativeTableMetaDetails(ArrayList<HashMap<String, String>> hsList)
	{
		try
		{
			ZABModel.createRow(ReportArchieveDimensionConstants.ARCHIEVE_CUM_TABLE_META_CONSTANTS, ARCHIEVE_CUM_TABLE_META.TABLE, hsList);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
	}
	
	public static void updateArchieveCumulativeTableMetaDetails(String archivedTableName, Long lastArchiveTime)
	{
		try
		{
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(ReportArchieveDimensionConstants.LAST_ARCHIEVED_TIME, lastArchiveTime.toString());
			Criteria criteria = new Criteria(new Column(ARCHIEVE_CUM_TABLE_META.TABLE,ARCHIEVE_CUM_TABLE_META.RESULT_ARCHIEVE_TABLE),archivedTableName,QueryConstants.EQUAL);
			boolean isEntryExists = ZABModel.resourceExists(ARCHIEVE_CUM_TABLE_META.TABLE, criteria);
			if(isEntryExists)
			{
				ZABModel.updateRow(ReportArchieveDimensionConstants.ARCHIEVE_CUM_TABLE_META_CONSTANTS, ARCHIEVE_CUM_TABLE_META.TABLE, hs, criteria, null);
			}
			else
			{
				hs.put(ReportArchieveDimensionConstants.RESULT_ARCHIEVE_TABLE, archivedTableName);
				ZABModel.createRow(ReportArchieveDimensionConstants.ARCHIEVE_CUM_TABLE_META_CONSTANTS, ARCHIEVE_CUM_TABLE_META.TABLE, hs);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
	}
	
	public static HashMap<String, Long> getArchieveCumulativeTableMetaDetails()
	{
		HashMap<String, Long> hs = new HashMap<String, Long>();
		try
		{
			DataObject dataObj = ZABModel.getRow(ARCHIEVE_CUM_TABLE_META.TABLE, null);
			Iterator<?> iterator = dataObj.getRows(ARCHIEVE_CUM_TABLE_META.TABLE);
			while(iterator.hasNext())
			{
				Row row = (Row)iterator.next();
				String tableTable = (String)row.get(ARCHIEVE_CUM_TABLE_META.RESULT_ARCHIEVE_TABLE);
				Long lastArchiveTime = (Long)row.get(ARCHIEVE_CUM_TABLE_META.LAST_ARCHIEVED_TIME);
				hs.put(tableTable, lastArchiveTime);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			hs = new HashMap<String, Long>();
		}
		return hs;
	}
	
	
	
	public static ArchieveCumulativeTableMeta getArchieveCumulativeTableMetaFromRow(Row row)
	{
		ArchieveCumulativeTableMeta archieveCumTableMeta = new ArchieveCumulativeTableMeta(); 
		try
		{
			archieveCumTableMeta.setArchieveCumTableId((Long)row.get(ARCHIEVE_CUM_TABLE_META.ARCHIEVE_CUM_TABLE_ID));
			archieveCumTableMeta.setResultArchieveTable((String)row.get(ARCHIEVE_CUM_TABLE_META.RESULT_ARCHIEVE_TABLE));
			archieveCumTableMeta.setLastArchievedTime((Long)row.get(ARCHIEVE_CUM_TABLE_META.LAST_ARCHIEVED_TIME));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			archieveCumTableMeta = new ArchieveCumulativeTableMeta();
		}
		return archieveCumTableMeta;
	}
}
