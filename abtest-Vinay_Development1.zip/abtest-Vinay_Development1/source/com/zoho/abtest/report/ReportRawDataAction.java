//$Id$
package com.zoho.abtest.report;

import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;

import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.utility.ZABUtil;

public class ReportRawDataAction extends ZABAction implements ServletResponseAware, ServletRequestAware {
	
	private static final Logger LOGGER = Logger.getLogger(ReportRawDataAction.class.getName());
	
	private static final long serialVersionUID = 1L;

	private HttpServletRequest request;
	
	private HttpServletResponse response;
	
	@Override
	public void setServletRequest(HttpServletRequest request) {
		ZABUtil.setCurrentRequest(request);
		this.request = request;
	}

	@Override
	public void setServletResponse(HttpServletResponse response) {
		this.response = response;
	}
	
	/*
	 * INPUT DATA FORMAT
	 * 
	 *
	  //If you dont know any of the values - just send the value for that field as 'UNKNOWN'
	  //If language value is not know send then as 'UNK' and its display value as 'UNKNOWN'
	  // is_new_visitor - should be 'true' or 'false' only. Do not send as UNKNOWN for it
	 * 
	 */

}
