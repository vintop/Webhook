//$Id$
package com.zoho.abtest.report;

public class ReportConstants {
	
	public static final String EXPERIMENT_ID_COLUMN = "EXPERIMENT_ID"; //NO I18N
	public static final String VARIATION_ID_COLUMN = "VARIATION_ID"; //NO I18N
	public static final String GOAL_ID_COLUMN = "GOAL_ID"; //NO I18N
	public static final String CODE_COLUMN = "CODE"; //NO I18N
	public static final String DYNAMIC_ATTRIBUTE_ID_COLUMN = "DYNAMIC_ATTRIBUTE_ID"; //NO I18N
	public static final String UNIQUE_COUNT_COLUMN = "UNIQUE_COUNT"; //NO I18N
	public static final String TOTAL_COUNT_COLUMN = "TOTAL_COUNT"; //NO I18N
	public static final String TIME_COLUMN = "TIME"; //NO I18N 
	public static final String DATE_COLUMN = "DATE"; //NO I18N
	
	public static final String OVERVIEW = "overview"; //NO I18N
	public static final String SUMMARY = "summary"; //NO I18N
	public static final String SEGMENT = "segment"; //NO I18N
	public static final String MULTISEGMENT = "multisegment"; //NO I18N
	public static final String QUICKFILTER = "quickfilter"; //NO I18N
	
	public static final String VISITORTABLENAME = "visitortablename"; //NO I18N
	public static final String VISITORIDCOLUMNNAME = "visitoridcolumnname"; //NO I18N
	public static final String VISITORARRTABLENAME = "visitorarrtablename"; //NO I18N
	public static final String VISITORHOURTABLENAME = "visitorhourtablename"; //NO I18N
	public static final String VISITORHOURIDCOLUMNNAME = "visitorhouridcolumnname"; //NO I18N
	public static final String VISITORHOURARRTABLENAME = "visitorhourarrtablename"; //NO I18N

	public static final String GOALTABLENAME = "goaltablename"; //NO I18N
	public static final String GOALIDCOLUMNNAME = "goalidcolumnname"; //NO I18N
	public static final String GOALARRTABLENAME = "goalarrtablename"; //NO I18N
	public static final String GOALHOURTABLENAME = "goalhourtablename"; //NO I18N
	public static final String GOALHOURIDCOLUMNNAME = "goalhouridcolumnname"; //NO I18N
	public static final String GOALHOURARRTABLENAME = "goalhourarrtablename"; //NO I18N
	
	public static final String RAWTABLESEGMENTCOLUMNNAME = "rawtablesegmentcolumnname"; //NO I18N
	
	public static final String BROWSER = "browser"; //NO I18N
	public static final String DEVICE = "device"; //NO I18N
	public static final String COUNTRY = "country"; //NO I18N
	public static final String LANGUAGE = "language"; //NO I18N
	public static final String OS = "os"; //NO I18N
	public static final String TRAFFICSOURCE = "trafficsource"; //NO I18N
	public static final String REFFERERURL = "reffererurl"; //NO I18N
	public static final String DAYOFWEEK = "dayofweek"; //NO I18N
	public static final String HOUROFDAY = "hourofday"; //NO I18N
	public static final String COOKIE = "cookie"; //NO I18N
	public static final String URLPARAMETER = "urlparameter"; //NO I18N
	public static final String JSVARIABLE = "jsvariable"; //NO I18N
	public static final String CUSTOMDIMENSION = "customdimension"; //NO I18N
	public static final String CURRENTURL = "currenturl"; //NO I18N
	public static final String USERTYPE = "usertype"; //NO I18N
	
	public static final String START_DATE = "start_date";	// NO I18N
	public static final String END_DATE = "end_date";	// NO I18N
	public static final String SEGMENT_TYPE = "segment_type";	// NO I18N
	public static final String REPORT_TYPE = "report_type";	// NO I18N
	public static final String DYNAMIC_ATTRIBUTE_LINK_NAME = "dynamic_attribute_link_name";	// NO I18N
	public static final String VALUES = "values";	// NO I18N
	public static final String MULTISEGMENT_CRITERIA = "multisegment_criteria"; //NO I18N
	public static final String QF_PARENT_NAME = "qf_parent_name"; //NO I18N
	public static final String QF_PARENT_VALUE = "qf_parent_value"; //NO I18N
	
	public static final String HEATMAP_REQUIRED_CRITERIA = "heatmap_required_criteria"; //NO I18N

	
	public static final String VISITOR_ID = "visitor_id";		// NO I18N
	
	public static final String GOAL_DATA_RAW_ID = "GOAL_DATA_RAW_ID";	// NO I18N
	public static final String VISITOR_DATA_RAW_ID = "VISITOR_DATA_RAW_ID";	// NO I18N
	
	public static final String VISITOR_IDS = "VISITOR_IDS";		// NO I18N
	public static final String BASELINE = "baseline";		// NO I18N
	public static final String VARIATIONS = "variations";		// NO I18N
	public static final String GOAL_LINK_NAME = "goal_link_name";		// NO I18N
	
	public static final String ATTRIBUTE_NAME = "attribute_name";		// NO I18N
	

	public static final String SEGMENT_LOCATION = "location"; //NO I18N

	public static final String FORECAST = "forecast";		// NO I18N
	
	
	public static final String SEGMENT_DOW = "day_of_week"; //NO I18N
	public static final String SEGMENT_HOD = "hour_of_the_day"; //NO I18N
	
	
}
