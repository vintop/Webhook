//$Id$
package com.zoho.abtest.report;

import java.sql.Array;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;

import com.adventnet.db.api.RelationalAPI;
import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.zoho.abtest.BROWSER_GOAL_REPORT_DAY;
import com.zoho.abtest.BROWSER_GOAL_REPORT_HOUR;
import com.zoho.abtest.BROWSER_VISIT_REPORT_DAY;
import com.zoho.abtest.BROWSER_VISIT_REPORT_HOUR;
import com.zoho.abtest.COOKIE_GOAL_REPORT_DAY;
import com.zoho.abtest.COOKIE_GOAL_REPORT_HOUR;
import com.zoho.abtest.COOKIE_VISIT_REPORT_DAY;
import com.zoho.abtest.COOKIE_VISIT_REPORT_HOUR;
import com.zoho.abtest.COUNTRY_GOAL_REPORT_DAY;
import com.zoho.abtest.COUNTRY_GOAL_REPORT_HOUR;
import com.zoho.abtest.COUNTRY_VISIT_REPORT_DAY;
import com.zoho.abtest.COUNTRY_VISIT_REPORT_HOUR;
import com.zoho.abtest.CUSTDIM_GOAL_REPORT_DAY;
import com.zoho.abtest.CUSTDIM_GOAL_REPORT_HOUR;
import com.zoho.abtest.CUSTDIM_VISIT_REPORT_DAY;
import com.zoho.abtest.CUSTDIM_VISIT_REPORT_HOUR;
import com.zoho.abtest.DAYOFWK_GOAL_REPORT_DAY;
import com.zoho.abtest.DAYOFWK_GOAL_REPORT_HOUR;
import com.zoho.abtest.DAYOFWK_VISIT_REPORT_DAY;
import com.zoho.abtest.DAYOFWK_VISIT_REPORT_HOUR;
import com.zoho.abtest.DEVICE_GOAL_REPORT_DAY;
import com.zoho.abtest.DEVICE_GOAL_REPORT_HOUR;
import com.zoho.abtest.DEVICE_VISIT_REPORT_DAY;
import com.zoho.abtest.DEVICE_VISIT_REPORT_HOUR;
import com.zoho.abtest.HOURODY_GOAL_REPORT_DAY;
import com.zoho.abtest.HOURODY_GOAL_REPORT_HOUR;
import com.zoho.abtest.HOURODY_VISIT_REPORT_DAY;
import com.zoho.abtest.HOURODY_VISIT_REPORT_HOUR;
import com.zoho.abtest.JSVAR_GOAL_REPORT_DAY;
import com.zoho.abtest.JSVAR_GOAL_REPORT_HOUR;
import com.zoho.abtest.JSVAR_VISIT_REPORT_DAY;
import com.zoho.abtest.JSVAR_VISIT_REPORT_HOUR;
import com.zoho.abtest.LANG_GOAL_REPORT_DAY;
import com.zoho.abtest.LANG_GOAL_REPORT_HOUR;
import com.zoho.abtest.LANG_VISIT_REPORT_DAY;
import com.zoho.abtest.LANG_VISIT_REPORT_HOUR;
import com.zoho.abtest.OS_GOAL_REPORT_DAY;
import com.zoho.abtest.OS_GOAL_REPORT_HOUR;
import com.zoho.abtest.OS_VISIT_REPORT_DAY;
import com.zoho.abtest.OS_VISIT_REPORT_HOUR;
import com.zoho.abtest.REFURL_GOAL_REPORT_DAY;
import com.zoho.abtest.REFURL_GOAL_REPORT_HOUR;
import com.zoho.abtest.REFURL_VISIT_REPORT_DAY;
import com.zoho.abtest.REFURL_VISIT_REPORT_HOUR;
import com.zoho.abtest.TRAFSOUR_GOAL_REPORT_DAY;
import com.zoho.abtest.TRAFSOUR_GOAL_REPORT_HOUR;
import com.zoho.abtest.TRAFSOUR_VISIT_REPORT_DAY;
import com.zoho.abtest.TRAFSOUR_VISIT_REPORT_HOUR;
import com.zoho.abtest.URLPARM_GOAL_REPORT_DAY;
import com.zoho.abtest.URLPARM_GOAL_REPORT_HOUR;
import com.zoho.abtest.URLPARM_VISIT_REPORT_DAY;
import com.zoho.abtest.URLPARM_VISIT_REPORT_HOUR;
import com.zoho.abtest.VISITOR_REPORT_HOUR;
import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.dimension.Dimension;
import com.zoho.abtest.dimension.DynamicAttributes;
import com.zoho.abtest.dimension.DimensionConstants.DynamicAttributeType;
import com.zoho.abtest.dimension.ExperimentDynamicAttribute;
import com.zoho.abtest.report.ReportArchieveDimensionConstants.ReportDurationType;

public class ReportArchieveDimension {
	
	private static final Logger LOGGER = Logger.getLogger(ReportArchieveDimension.class.getName());
	
	public static void archieveIndividualReportOnStandardDimension(String rawTable,final String columnName, final String[] groupByColumns, String resultTable, String visitorIdsTable, int durationType, Long startHourInMs, Long endHourInMs)
	{
		List<Constants> resultTableConstants = null; 
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet resultSet = null;
		List<HashMap<String, String>> resultSetList = new ArrayList<HashMap<String, String>>();
		List<Array> visitorIdArrList = new ArrayList<Array>();
		try
		{
			String timeSpanColumn = null;
			String visitorsTableIdColumn = null;
			
			if(durationType == ReportDurationType.HOUR.getDurationCode())
			{
				timeSpanColumn = ReportArchieveDimensionConstants.TIME;
				visitorsTableIdColumn = "HOUR_ID"; //No I18N
			}
			else if(durationType == ReportDurationType.DAY.getDurationCode())
			{
				timeSpanColumn = ReportArchieveDimensionConstants.DATE;
				visitorsTableIdColumn = "DAY_ID"; //No I18N
			}
			
			String groupByColumnsStr = StringUtils.join(groupByColumns, ZABConstants.COMMA);
			if(!groupByColumnsStr.isEmpty())
			{
				groupByColumnsStr = groupByColumnsStr + ZABConstants.COMMA + columnName;
			}
			else
			{
				groupByColumnsStr = columnName;
			}
			
			String summationColumns = "ARRAY_AGG("+ReportArchieveDimensionConstants.VISITOR_ID+") AS VISITOR_IDS"+ZABConstants.COMMA+"SUM("+ReportArchieveDimensionConstants.TOTALCOUNT_FLAG+") AS "+ReportArchieveDimensionConstants.TOTAL_COUNT; //No I18N
			
			String criteriaClause = "";
			
			if(durationType == ReportDurationType.HOUR.getDurationCode())
			{
				String condition1 =  ReportArchieveDimensionConstants.TIME + ZABConstants.GREATER_THAN + "?";
				String condition2 =  ReportArchieveDimensionConstants.TIME + ZABConstants.LESSER_EQUAL + "?";
				criteriaClause = condition1 + " AND " + condition2;  //No I18N
			}

			String selectClause = groupByColumnsStr +ZABConstants.COMMA+summationColumns;
			String groupByClause = groupByColumnsStr;
			
			String selectQuery = "";
			
			if(durationType == ReportDurationType.HOUR.getDurationCode())
			{
				selectQuery = "SELECT "+ selectClause + " FROM "+ rawTable + " WHERE " + criteriaClause + " GROUP BY " + groupByClause; // No I18N
			}
			else if(durationType == ReportDurationType.DAY.getDurationCode())
			{
				selectQuery = "SELECT "+ selectClause + " FROM "+ rawTable + " GROUP BY " + groupByClause; // No I18N
			}
			
			HashMap<String,Object> tableDetails = getTableConstants(resultTable);
			resultTableConstants = (List<Constants>)tableDetails.get("resultTableConstants");
			String idColumn = (String)tableDetails.get("idColumn");
			
			try
			{
				RelationalAPI relationalApi = RelationalAPI.getInstance();
				connection = relationalApi.getConnection();
				pstmt = connection.prepareStatement(selectQuery);
				if(durationType == ReportDurationType.HOUR.getDurationCode())
				{
					pstmt.setLong(1, startHourInMs);
					pstmt.setLong(2, endHourInMs);
				}
				resultSet = pstmt.executeQuery();
				
				while(resultSet.next())
				{
					HashMap<String, String> hs = new HashMap<String, String>();
					
					//TODO this will cause O(n-square), have to check if it is better to hardcode than looping the array
					if(groupByColumns != null)
					{
						for(String groupByColumn:groupByColumns)
						{
							switch(groupByColumn)
							{
							case "EXPERIMENT_ID": //No I18N
								hs.put(ReportArchieveDimensionConstants.EXPERIMENT_ID,((Long)resultSet.getLong(ReportArchieveDimensionConstants.EXPERIMENT_ID)).toString());
								break;
							case "VARIATION_ID": //No I18N
								hs.put(ReportArchieveDimensionConstants.VARIATION_ID,((Long)resultSet.getLong(ReportArchieveDimensionConstants.VARIATION_ID)).toString());
								break;
							case "GOAL_ID": //No I18N
								hs.put(ReportArchieveDimensionConstants.GOAL_ID,((Long)resultSet.getLong(ReportArchieveDimensionConstants.GOAL_ID)).toString());
								break;
							}
						}
					}
					
					hs.put(ReportArchieveDimensionConstants.CODE,Integer.toString(resultSet.getInt(columnName)));
					hs.put(ReportArchieveDimensionConstants.TOTAL_COUNT,Integer.toString(resultSet.getInt(ReportArchieveDimensionConstants.TOTAL_COUNT)));
					hs.put(timeSpanColumn,endHourInMs.toString());
					resultSetList.add(hs);
					
					Array visitorIdsArr = resultSet.getArray("VISITOR_IDS"); //No I18N
					visitorIdArrList.add(visitorIdsArr);
				}
			}
			catch(Exception ex)
			{
				LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			}
			finally
			{
				try
				{
					if(resultSet != null)
					{
						resultSet.close();
					}
					if(pstmt != null)
					{
						pstmt.close();
					}
					if(connection != null)
					{
						connection.close();
					}
				}
				catch(SQLException ex)
				{
					LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
				}
			}
			
			for(int index=0;index<resultSetList.size();index++)
			{
				HashMap<String, String> hs = resultSetList.get(index);
				Array visitorIdsArr = visitorIdArrList.get(index);
				DataObject dataObj = ZABModel.createRow(resultTableConstants, resultTable, hs);
				Long mappingId = getIdFromDataObject(dataObj, resultTable, idColumn);
				addReportVisitorIdsMapping(visitorIdsTable,visitorsTableIdColumn,mappingId,visitorIdsArr);
			}
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
	}
	
	public static Long getIdFromDataObject(DataObject dataObj, String resultTable, String idColumn)
	{
		Long id = 0l;
		try
		{
			id = (Long)dataObj.getFirstValue(resultTable, idColumn);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			id = 0l;
		}
		return id;
	}
	
	public static void addReportVisitorIdsMapping(String tableName, String idColumnName, Long mappingId, Array visitorIdsArr)
	{
		Connection connection = null;
		PreparedStatement insertstmt = null;
		try
		{
			RelationalAPI relationalApi = RelationalAPI.getInstance();
			connection = relationalApi.getConnection();
			String insertSql = "INSERT INTO "+ tableName + "("+idColumnName+",VISITOR_IDS) VALUES (?,?)"; //No I18N
			insertstmt = connection.prepareStatement(insertSql);
			insertstmt.setLong(1, mappingId);
			insertstmt.setArray(2, visitorIdsArr);
			insertstmt.executeUpdate();
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
		}
		finally
		{
			try
			{
				if(insertstmt != null)
				{
					insertstmt.close();
				}
				if(connection != null)
				{
					connection.close();
				}
			}
			catch(SQLException ex)
			{
				LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			}
			
		}
	}
	
	public static void archieveIndividualReportOnDynamicAttributes(String rawTable,final String columnName, final String[] groupByColumns, String resultTable, String visitorIdsTable, int durationType, Long startHourInMs, Long endHourInMs)
	{
		List<Constants> resultTableConstants = null; 
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet resultSet = null;
		List<DynamicAttributes> dynamicAttributes = null;
		List<Long> experimentIds = null;
		try
		{
			ArrayList<HashMap<String, String>> hsList = new ArrayList<HashMap<String, String>>();
			String timeSpanColumn = null;
			String visitorsTableIdColumn = null;
			
			if(durationType == ReportDurationType.HOUR.getDurationCode())
			{
				timeSpanColumn = ReportArchieveDimensionConstants.TIME;
				visitorsTableIdColumn = "HOUR_ID"; //No I18N
			}
			else if(durationType == ReportDurationType.DAY.getDurationCode())
			{
				timeSpanColumn = ReportArchieveDimensionConstants.DATE;
				visitorsTableIdColumn = "DAY_ID"; //No I18N
			}
			
			Integer attributeTypeCode = null;
			
			switch(columnName)
			{
			case ReportArchieveDimensionConstants.URLPARAM_JSON:
				attributeTypeCode = DynamicAttributeType.URLPARAMETER.getAttributeTypeCode();
				break;
			case ReportArchieveDimensionConstants.COOKIE_JSON:
				attributeTypeCode = DynamicAttributeType.COOKIE.getAttributeTypeCode();
				break;
			case ReportArchieveDimensionConstants.JS_VARIABLE_JSON:
				attributeTypeCode = DynamicAttributeType.JSVARIABLE.getAttributeTypeCode();
				break;
			case ReportArchieveDimensionConstants.CUSTOM_DIMENSION_JSON:
				attributeTypeCode = DynamicAttributeType.CUSTOMDIMENSION.getAttributeTypeCode();
				break;
			}
			
			dynamicAttributes = DynamicAttributes.getDynamicAttributesByType(attributeTypeCode);
			
			String groupByColumnsStr = StringUtils.join(groupByColumns, ZABConstants.COMMA);
			String summationColumns = "ARRAY_AGG("+ReportArchieveDimensionConstants.VISITOR_ID+") AS VISITOR_IDS"+ZABConstants.COMMA+"SUM("+ReportArchieveDimensionConstants.TOTALCOUNT_FLAG+") AS "+ReportArchieveDimensionConstants.TOTAL_COUNT; //No I18N
			
			for(DynamicAttributes dynamicAttribute:dynamicAttributes)
			{
				String selectClause = "";
				String criteriaClause = "";
				experimentIds = ExperimentDynamicAttribute.getExperimentIdsByDynamicAttributeId(dynamicAttribute.getDynamicAttributeId());
				int idsSize = experimentIds.size();
				if(idsSize > 0)
				{
					String jsonAttrGroupby = columnName+"->'"+dynamicAttribute.getDynamicAttributeId()+"'";
					if(!groupByColumnsStr.isEmpty())
					{
						selectClause = groupByColumnsStr;
						groupByColumnsStr = groupByColumnsStr + ZABConstants.COMMA + jsonAttrGroupby;
						selectClause = selectClause + ZABConstants.COMMA + jsonAttrGroupby + " AS CODE";  //No I18N
					}
					
					String expIdsParams = StringUtils.join(Collections.nCopies(idsSize, "?"), ",");
					
					String expIdsCriteria = " EXPERIMENT_ID IN ("+expIdsParams+")";  //No I18N
					criteriaClause = expIdsCriteria;
					
					if(durationType == ReportDurationType.HOUR.getDurationCode())
					{
						String condition1 =  ReportArchieveDimensionConstants.TIME + ZABConstants.GREATER_THAN + "?";
						String condition2 =  ReportArchieveDimensionConstants.TIME + ZABConstants.LESSER_EQUAL + "?";
						criteriaClause = criteriaClause + " AND " + condition1 + " AND " + condition2;  //No I18N
					}

					selectClause = selectClause +ZABConstants.COMMA+summationColumns;
					String groupByClause = groupByColumnsStr;
					
					String selectQuery = "";
					
					selectQuery = "SELECT "+ selectClause + " FROM "+ rawTable + " WHERE " + criteriaClause + " GROUP BY " + groupByClause; // No I18N
					
					HashMap<String,Object> tableDetails = getTableConstants(resultTable);
					resultTableConstants = (List<Constants>)tableDetails.get("resultTableConstants");
					String idColumn = (String)tableDetails.get("idColumn");
					
					List<HashMap<String, String>> resultSetList = new ArrayList<HashMap<String, String>>();
					List<Array> visitorIdArrList = new ArrayList<Array>();
					
					try
					{
						RelationalAPI relationalApi = RelationalAPI.getInstance();
						connection = relationalApi.getConnection();
						pstmt = connection.prepareStatement(selectQuery);
						
						int index = 1;
						
						for(Long experimentId:experimentIds)
						{
							pstmt.setLong(index++, experimentId);
						}
						
						if(durationType == ReportDurationType.HOUR.getDurationCode())
						{
							pstmt.setLong(index++, startHourInMs);
							pstmt.setLong(index++, endHourInMs);
						}
						
						resultSet = pstmt.executeQuery();
						
						while(resultSet.next())
						{
							HashMap<String, String> hs = new HashMap<String, String>();
							
							//TODO this will cause O(n-square), have to check if it is better to hardcode than looping the array
							if(groupByColumns != null)
							{
								for(String groupByColumn:groupByColumns)
								{
									switch(groupByColumn)
									{
									case "EXPERIMENT_ID": //No I18N
										hs.put(ReportArchieveDimensionConstants.EXPERIMENT_ID,((Long)resultSet.getLong(ReportArchieveDimensionConstants.EXPERIMENT_ID)).toString());
										break;
									case "VARIATION_ID": //No I18N
										hs.put(ReportArchieveDimensionConstants.VARIATION_ID,((Long)resultSet.getLong(ReportArchieveDimensionConstants.VARIATION_ID)).toString());
										break;
									case "GOAL_ID": //No I18N
										hs.put(ReportArchieveDimensionConstants.GOAL_ID,((Long)resultSet.getLong(ReportArchieveDimensionConstants.GOAL_ID)).toString());
										break;
									}
								}
							}
							hs.put(ReportArchieveDimensionConstants.DYNAMIC_ATTRIBUTE_ID,dynamicAttribute.getDynamicAttributeId().toString());
							Integer code = resultSet.getInt("CODE"); //No I18N
							if(code == null)
							{
								//TODO will think for some other ways to maintain the unknown code as hardcoded value - if nested connection issue occurs here 
								code  = Dimension.getDynamicAttributeCodeByValue(dynamicAttribute.getDynamicAttributeId(),ReportRawDataConstants.UNKNOWN_VALUE);
							}
							hs.put(ReportArchieveDimensionConstants.CODE,code.toString());
							hs.put(ReportArchieveDimensionConstants.TOTAL_COUNT,Integer.toString(resultSet.getInt(ReportArchieveDimensionConstants.TOTAL_COUNT)));
							hs.put(timeSpanColumn,endHourInMs.toString());
							resultSetList.add(hs);
							
							Array visitorIdsArr = resultSet.getArray("VISITOR_IDS"); //No I18N
							visitorIdArrList.add(visitorIdsArr);
							
						}
					}
					catch(Exception ex)
					{
						LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
					}
					finally
					{
						try
						{
							if(resultSet != null)
							{
								resultSet.close();
							}
							if(pstmt != null)
							{
								pstmt.close();
							}
							if(connection != null)
							{
								connection.close();
							}
						}
						catch(SQLException ex)
						{
							LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
						}
					}
					
					for(int lindex=0;lindex<resultSetList.size();lindex++)
					{
						HashMap<String, String> hs = resultSetList.get(lindex);
						Array visitorIdsArr = visitorIdArrList.get(lindex);
						DataObject dataObj = ZABModel.createRow(resultTableConstants, resultTable, hs);
						Long mappingId = getIdFromDataObject(dataObj, resultTable, idColumn);
						addReportVisitorIdsMapping(visitorIdsTable,visitorsTableIdColumn,mappingId,visitorIdsArr);
					}
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
	}
	
	public static HashMap<String, Object> getTableConstants(String resultTable)
	{
		HashMap<String, Object> hs = new HashMap<String,Object>();
		
		List<Constants> resultTableConstants = null; 
		String idColumn = null;
		
		switch(resultTable)
		{
		case BROWSER_VISIT_REPORT_HOUR.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.BROWSER_VISIT_REPORT_HOUR_CONSTANTS;
			idColumn = BROWSER_VISIT_REPORT_HOUR.BROWSER_VISIT_REPORT_HOUR_ID;
			break;
		
		case BROWSER_VISIT_REPORT_DAY.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.BROWSER_VISIT_REPORT_DAY_CONSTANTS;
			idColumn = BROWSER_VISIT_REPORT_DAY.BROWSER_VISIT_REPORT_DAY_ID;
			break;
			
		case DEVICE_VISIT_REPORT_HOUR.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.DEVICE_VISIT_REPORT_HOUR_CONSTANTS;
			idColumn = DEVICE_VISIT_REPORT_HOUR.DEVICE_VISIT_REPORT_HOUR_ID;
			break;
		
		case DEVICE_VISIT_REPORT_DAY.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.DEVICE_VISIT_REPORT_DAY_CONSTANTS;
			idColumn = DEVICE_VISIT_REPORT_DAY.DEVICE_VISIT_REPORT_DAY_ID;
			break;
			
		case COUNTRY_VISIT_REPORT_HOUR.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.COUNTRY_VISIT_REPORT_HOUR_CONSTANTS;
			idColumn = COUNTRY_VISIT_REPORT_HOUR.COUNTRY_VISIT_REPORT_HOUR_ID;
			break;
		
		case COUNTRY_VISIT_REPORT_DAY.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.COUNTRY_VISIT_REPORT_DAY_CONSTANTS;
			idColumn = COUNTRY_VISIT_REPORT_DAY.COUNTRY_VISIT_REPORT_DAY_ID;
			break;
			
		case LANG_VISIT_REPORT_HOUR.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.LANG_VISIT_REPORT_HOUR_CONSTANTS;
			idColumn = LANG_VISIT_REPORT_HOUR.LANG_VISIT_REPORT_HOUR_ID;
			break;
		
		case LANG_VISIT_REPORT_DAY.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.LANG_VISIT_REPORT_DAY_CONSTANTS;
			idColumn = LANG_VISIT_REPORT_DAY.LANG_VISIT_REPORT_DAY_ID;
			break;
			
		case OS_VISIT_REPORT_HOUR.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.OS_VISIT_REPORT_HOUR_CONSTANTS;
			idColumn = OS_VISIT_REPORT_HOUR.OS_VISIT_REPORT_HOUR_ID;
			break;
		
		case OS_VISIT_REPORT_DAY.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.OS_VISIT_REPORT_DAY_CONSTANTS;
			idColumn = OS_VISIT_REPORT_DAY.OS_VISIT_REPORT_DAY_ID;
			break;
			
		case TRAFSOUR_VISIT_REPORT_HOUR.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.TRAFSOUR_VISIT_REPORT_HOUR_CONSTANTS;
			idColumn = TRAFSOUR_VISIT_REPORT_HOUR.TRAFSOUR_VISIT_REPORT_HOUR_ID;
			break;
		
		case TRAFSOUR_VISIT_REPORT_DAY.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.TRAFSOUR_VISIT_REPORT_DAY_CONSTANTS;
			idColumn = TRAFSOUR_VISIT_REPORT_DAY.TRAFSOUR_VISIT_REPORT_DAY_ID;
			break;
			
		case REFURL_VISIT_REPORT_HOUR.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.REFURL_VISIT_REPORT_HOUR_CONSTANTS;
			idColumn = REFURL_VISIT_REPORT_HOUR.REFURL_VISIT_REPORT_HOUR_ID;
			break;
		
		case REFURL_VISIT_REPORT_DAY.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.REFURL_VISIT_REPORT_DAY_CONSTANTS;
			idColumn = REFURL_VISIT_REPORT_DAY.REFURL_VISIT_REPORT_DAY_ID;
			break;
			
		case DAYOFWK_VISIT_REPORT_HOUR.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.DAYOFWK_VISIT_REPORT_HOUR_CONSTANTS;
			idColumn = DAYOFWK_VISIT_REPORT_HOUR.DAYOFWK_VISIT_REPORT_HOUR_ID;
			break;
		
		case DAYOFWK_VISIT_REPORT_DAY.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.DAYOFWK_VISIT_REPORT_DAY_CONSTANTS;
			idColumn = DAYOFWK_VISIT_REPORT_DAY.DAYOFWK_VISIT_REPORT_DAY_ID;
			break;
			
		case HOURODY_VISIT_REPORT_HOUR.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.HOURODY_VISIT_REPORT_HOUR_CONSTANTS;
			idColumn = HOURODY_VISIT_REPORT_HOUR.HOURODY_VISIT_REPORT_HOUR_ID;
			break;
		
		case HOURODY_VISIT_REPORT_DAY.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.HOURODY_VISIT_REPORT_DAY_CONSTANTS;
			idColumn = HOURODY_VISIT_REPORT_DAY.HOURODY_VISIT_REPORT_DAY_ID;
			break;
			
		case COOKIE_VISIT_REPORT_HOUR.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.COOKIE_VISIT_REPORT_HOUR_CONSTANTS;
			idColumn = COOKIE_VISIT_REPORT_HOUR.COOKIE_VISIT_REPORT_HOUR_ID;
			break;
		
		case COOKIE_VISIT_REPORT_DAY.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.COOKIE_VISIT_REPORT_DAY_CONSTANTS;
			idColumn = COOKIE_VISIT_REPORT_DAY.COOKIE_VISIT_REPORT_DAY_ID;
			break;
			
		case URLPARM_VISIT_REPORT_HOUR.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.URLPARM_VISIT_REPORT_HOUR_CONSTANTS;
			idColumn = URLPARM_VISIT_REPORT_HOUR.URLPARM_VISIT_REPORT_HOUR_ID;
			break;
		
		case URLPARM_VISIT_REPORT_DAY.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.URLPARM_VISIT_REPORT_DAY_CONSTANTS;
			idColumn = URLPARM_VISIT_REPORT_DAY.URLPARM_VISIT_REPORT_DAY_ID;
			break;
			
		case JSVAR_VISIT_REPORT_HOUR.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.JSVAR_VISIT_REPORT_HOUR_CONSTANTS;
			idColumn = JSVAR_VISIT_REPORT_HOUR.JSVAR_VISIT_REPORT_HOUR_ID;
			break;
		
		case JSVAR_VISIT_REPORT_DAY.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.JSVAR_VISIT_REPORT_DAY_CONSTANTS;
			idColumn = JSVAR_VISIT_REPORT_DAY.JSVAR_VISIT_REPORT_DAY_ID;
			break;
			
		case CUSTDIM_VISIT_REPORT_HOUR.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.CUSTDIM_VISIT_REPORT_HOUR_CONSTANTS;
			idColumn = CUSTDIM_VISIT_REPORT_HOUR.CUSTDIM_VISIT_REPORT_HOUR_ID;
			break;
		
		case CUSTDIM_VISIT_REPORT_DAY.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.CUSTDIM_VISIT_REPORT_DAY_CONSTANTS;
			idColumn = CUSTDIM_VISIT_REPORT_DAY.CUSTDIM_VISIT_REPORT_DAY_ID;
			break;
			
		case BROWSER_GOAL_REPORT_HOUR.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.BROWSER_GOAL_REPORT_HOUR_CONSTANTS;
			idColumn = BROWSER_GOAL_REPORT_HOUR.BROWSER_GOAL_REPORT_HOUR_ID;
			break;
		
		case BROWSER_GOAL_REPORT_DAY.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.BROWSER_GOAL_REPORT_DAY_CONSTANTS;
			idColumn = BROWSER_GOAL_REPORT_DAY.BROWSER_GOAL_REPORT_DAY_ID;
			break;
			
		case DEVICE_GOAL_REPORT_HOUR.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.DEVICE_GOAL_REPORT_HOUR_CONSTANTS;
			idColumn = DEVICE_GOAL_REPORT_HOUR.DEVICE_GOAL_REPORT_HOUR_ID;
			break;
		
		case DEVICE_GOAL_REPORT_DAY.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.DEVICE_GOAL_REPORT_DAY_CONSTANTS;
			idColumn = DEVICE_GOAL_REPORT_DAY.DEVICE_GOAL_REPORT_DAY_ID;
			break;
			
		case COUNTRY_GOAL_REPORT_HOUR.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.COUNTRY_GOAL_REPORT_HOUR_CONSTANTS;
			idColumn = COUNTRY_GOAL_REPORT_HOUR.COUNTRY_GOAL_REPORT_HOUR_ID;
			break;
		
		case COUNTRY_GOAL_REPORT_DAY.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.COUNTRY_GOAL_REPORT_DAY_CONSTANTS;
			idColumn = COUNTRY_GOAL_REPORT_DAY.COUNTRY_GOAL_REPORT_DAY_ID;
			break;
			
		case LANG_GOAL_REPORT_HOUR.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.LANG_GOAL_REPORT_HOUR_CONSTANTS;
			idColumn = LANG_GOAL_REPORT_HOUR.LANG_GOAL_REPORT_HOUR_ID;
			break;
		
		case LANG_GOAL_REPORT_DAY.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.LANG_GOAL_REPORT_DAY_CONSTANTS;
			idColumn = LANG_GOAL_REPORT_DAY.LANG_GOAL_REPORT_DAY_ID;
			break;
			
		case OS_GOAL_REPORT_HOUR.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.OS_GOAL_REPORT_HOUR_CONSTANTS;
			idColumn = OS_GOAL_REPORT_HOUR.OS_GOAL_REPORT_HOUR_ID;
			break;
		
		case OS_GOAL_REPORT_DAY.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.OS_GOAL_REPORT_DAY_CONSTANTS;
			idColumn = OS_GOAL_REPORT_DAY.OS_GOAL_REPORT_DAY_ID;
			break;
			
		case TRAFSOUR_GOAL_REPORT_HOUR.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.TRAFSOUR_GOAL_REPORT_HOUR_CONSTANTS;
			idColumn = TRAFSOUR_GOAL_REPORT_HOUR.TRAFSOUR_GOAL_REPORT_HOUR_ID;
			break;
		
		case TRAFSOUR_GOAL_REPORT_DAY.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.TRAFSOUR_GOAL_REPORT_DAY_CONSTANTS;
			idColumn = TRAFSOUR_GOAL_REPORT_DAY.TRAFSOUR_GOAL_REPORT_DAY_ID;
			break;
			
		case REFURL_GOAL_REPORT_HOUR.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.REFURL_GOAL_REPORT_HOUR_CONSTANTS;
			idColumn = REFURL_GOAL_REPORT_HOUR.REFURL_GOAL_REPORT_HOUR_ID;
			break;
		
		case REFURL_GOAL_REPORT_DAY.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.REFURL_GOAL_REPORT_DAY_CONSTANTS;
			idColumn = REFURL_GOAL_REPORT_DAY.REFURL_GOAL_REPORT_DAY_ID;
			break;
			
		case DAYOFWK_GOAL_REPORT_HOUR.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.DAYOFWK_GOAL_REPORT_HOUR_CONSTANTS;
			idColumn = DAYOFWK_GOAL_REPORT_HOUR.DAYOFWK_GOAL_REPORT_HOUR_ID;
			break;
		
		case DAYOFWK_GOAL_REPORT_DAY.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.DAYOFWK_GOAL_REPORT_DAY_CONSTANTS;
			idColumn = DAYOFWK_GOAL_REPORT_DAY.DAYOFWK_GOAL_REPORT_DAY_ID;
			break;
			
		case HOURODY_GOAL_REPORT_HOUR.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.HOURODY_GOAL_REPORT_HOUR_CONSTANTS;
			idColumn = HOURODY_GOAL_REPORT_HOUR.HOURODY_GOAL_REPORT_HOUR_ID;
			break;
		
		case HOURODY_GOAL_REPORT_DAY.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.HOURODY_GOAL_REPORT_DAY_CONSTANTS;
			idColumn = HOURODY_GOAL_REPORT_DAY.HOURODY_GOAL_REPORT_DAY_ID;
			break;
			
		case COOKIE_GOAL_REPORT_HOUR.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.COOKIE_GOAL_REPORT_HOUR_CONSTANTS;
			idColumn = COOKIE_GOAL_REPORT_HOUR.COOKIE_GOAL_REPORT_HOUR_ID;
			break;
		
		case COOKIE_GOAL_REPORT_DAY.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.COOKIE_GOAL_REPORT_DAY_CONSTANTS;
			idColumn = COOKIE_GOAL_REPORT_DAY.COOKIE_GOAL_REPORT_DAY_ID;
			break;
			
		case URLPARM_GOAL_REPORT_HOUR.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.URLPARM_GOAL_REPORT_HOUR_CONSTANTS;
			idColumn = URLPARM_GOAL_REPORT_HOUR.URLPARM_GOAL_REPORT_HOUR_ID;
			break;
		
		case URLPARM_GOAL_REPORT_DAY.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.URLPARM_GOAL_REPORT_DAY_CONSTANTS;
			idColumn = URLPARM_GOAL_REPORT_DAY.URLPARM_GOAL_REPORT_DAY_ID;
			break;
			
		case JSVAR_GOAL_REPORT_HOUR.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.JSVAR_GOAL_REPORT_HOUR_CONSTANTS;
			idColumn = JSVAR_GOAL_REPORT_HOUR.JSVAR_GOAL_REPORT_HOUR_ID;
			break;
		
		case JSVAR_GOAL_REPORT_DAY.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.JSVAR_GOAL_REPORT_DAY_CONSTANTS;
			idColumn = JSVAR_GOAL_REPORT_DAY.JSVAR_GOAL_REPORT_DAY_ID;
			break;
			
		case CUSTDIM_GOAL_REPORT_HOUR.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.CUSTDIM_GOAL_REPORT_HOUR_CONSTANTS;
			idColumn = CUSTDIM_GOAL_REPORT_HOUR.CUSTDIM_GOAL_REPORT_HOUR_ID;
			break;
		
		case CUSTDIM_GOAL_REPORT_DAY.TABLE:
			resultTableConstants = ReportArchieveDimensionConstants.CUSTDIM_GOAL_REPORT_DAY_CONSTANTS;
			idColumn = CUSTDIM_GOAL_REPORT_DAY.CUSTDIM_GOAL_REPORT_DAY_ID;
			break;
		}
		hs.put("resultTableConstants", resultTableConstants);
		hs.put("idColumn",idColumn);
		
		return hs;
	}
	
	public static void cleanUpReportHourTable(List<String> hourTablesToBeCleaned, Long startTime, Long endTime)
	{
		try
		{
			for(String tableName:hourTablesToBeCleaned)
			{
				String timeSpanColumn = ReportConstants.TIME_COLUMN;
				Criteria criteria = new Criteria(new Column(tableName,timeSpanColumn),new Long[]{startTime,endTime},QueryConstants.BETWEEN);
				boolean isResourceExists = ZABModel.resourceExists(tableName, criteria);
				if(isResourceExists)
				{
					ZABModel.deleteRow(tableName, criteria, null);
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
	}
	

	/*
	 * public static void archieveIndividualReportOnStandardDimension(String rawTable,final String columnName, final String[] groupByColumns, String resultTable, int durationType, Long lastArchievedSpan, final Long jobScheduleStartTime)
	{
		List<Constants> resultTableConstants = null; 
		
		try
		{
			final ArrayList<HashMap<String, String>> hsList = new ArrayList<HashMap<String, String>>();
			String timeSpanColumn = null;
			
			//TODO make the check statements through enum
			if(durationType == ReportDurationType.HOUR.getDurationCode())
			{
				timeSpanColumn = ReportArchieveDimensionConstants.TIME;
			}
			else if(durationType == ReportDurationType.DAY.getDurationCode())
			{
				timeSpanColumn = ReportArchieveDimensionConstants.DATE;
			}
			final String archieveTableTimespanColumn = timeSpanColumn;
			
			Table table1 = new Table(rawTable);
			SelectQuery selectQuery = new SelectQueryImpl(table1);
			List<Column> groupList = new ArrayList<Column>();
			Column column = null;
			
			if(groupByColumns != null)
			{
				for(String groupByColumn:groupByColumns)
				{
					switch(groupByColumn)
					{
					case "EXPERIMENT_ID": //No I18N
						column = new Column(rawTable,ReportArchieveDimensionConstants.EXPERIMENT_ID);
						selectQuery.addSelectColumn(column);
						groupList.add(column);
						break;
					case "VARIATION_ID": //No I18N
						column = new Column(rawTable,ReportArchieveDimensionConstants.VARIATION_ID);
						selectQuery.addSelectColumn(column);
						groupList.add(column);
						break;
					case "GOAL_ID": //No I18N
						column = new Column(rawTable,ReportArchieveDimensionConstants.GOAL_ID);
						selectQuery.addSelectColumn(column);
						groupList.add(column);
						break;
					}
				}
			}
			
			column = new Column(rawTable,columnName);
			selectQuery.addSelectColumn(column);
			groupList.add(column);
			
			Column summationColumn1 = new Column(rawTable,ReportArchieveDimensionConstants.UNIQUECOUNT_FLAG).summation();
			summationColumn1.setColumnAlias(ReportArchieveDimensionConstants.UNIQUE_COUNT);
			Column summationColumn2 = new Column(rawTable,ReportArchieveDimensionConstants.TOTALCOUNT_FLAG).summation();
			summationColumn2.setColumnAlias(ReportArchieveDimensionConstants.TOTAL_COUNT);
			
			selectQuery.addSelectColumn(summationColumn1);
			selectQuery.addSelectColumn(summationColumn2);
			
			Criteria criteria1 = new Criteria(new Column(rawTable, ReportArchieveDimensionConstants.TIME),lastArchievedSpan,QueryConstants.GREATER_THAN);
			Criteria criteria2 = new Criteria(new Column(rawTable, ReportArchieveDimensionConstants.TIME),jobScheduleStartTime,QueryConstants.LESS_EQUAL);
			Criteria timespanCriteria = criteria1.and(criteria2);
			
			selectQuery.setCriteria(timespanCriteria);
			
			GroupByClause groupByClause = new GroupByClause(groupList);
			
			selectQuery.setGroupByClause(groupByClause);
			
			ZABUserBean userAction = (ZABUserBean)BeanUtil.lookup("ZABUserBean");
			userAction.executeQuery(selectQuery, 
					new DataSetWrapper() {
						
						@Override
						public void execute(DataSet ds) throws Exception {
							HashMap<String, String> hs = null;
							while(ds.next())
							{
								hs = new HashMap<String, String>();
								//hs.put(ReportArchieveDimensionConstants.EXPERIMENT_ID,ds.getValue(ReportArchieveDimensionConstants.EXPERIMENT_ID).toString());
								//hs.put(ReportArchieveDimensionConstants.VARIATION_ID,ds.getValue(ReportArchieveDimensionConstants.VARIATION_ID).toString());
								
								//TODO this will cause O(n-square), have to check if it is better to hardcode than looping the array
								if(groupByColumns != null)
								{
									for(String groupByColumn:groupByColumns)
									{
										switch(groupByColumn)
										{
										case "EXPERIMENT_ID": //No I18N
											hs.put(ReportArchieveDimensionConstants.EXPERIMENT_ID,ds.getValue(ReportArchieveDimensionConstants.EXPERIMENT_ID).toString());
											break;
										case "VARIATION_ID": //No I18N
											hs.put(ReportArchieveDimensionConstants.VARIATION_ID,ds.getValue(ReportArchieveDimensionConstants.VARIATION_ID).toString());
											break;
										case "GOAL_ID": //No I18N
											hs.put(ReportArchieveDimensionConstants.GOAL_ID,ds.getValue(ReportArchieveDimensionConstants.GOAL_ID).toString());
											break;
										}
									}
								}
								
								
								hs.put(ReportArchieveDimensionConstants.CODE,ds.getValue(columnName).toString());
								hs.put(ReportArchieveDimensionConstants.UNIQUE_COUNT,ds.getValue(ReportArchieveDimensionConstants.UNIQUE_COUNT).toString());
								hs.put(ReportArchieveDimensionConstants.TOTAL_COUNT,ds.getValue(ReportArchieveDimensionConstants.TOTAL_COUNT).toString());
								hs.put(archieveTableTimespanColumn,jobScheduleStartTime.toString());
								hsList.add(hs);
							}
						}
					});
			
			switch(resultTable)
			{
			case ReportArchieveDimensionConstants.BROWSER_VISIT_REPORT_HOUR_TABLE:
				resultTableConstants = ReportArchieveDimensionConstants.BROWSER_VISIT_REPORT_HOUR_CONSTANTS;
				break;
			
			case ReportArchieveDimensionConstants.BROWSER_VISIT_REPORT_DAY_TABLE:
				resultTableConstants = ReportArchieveDimensionConstants.BROWSER_VISIT_REPORT_DAY_CONSTANTS;
				break;
				
			case ReportArchieveDimensionConstants.DEVICE_VISIT_REPORT_HOUR_TABLE:
				resultTableConstants = ReportArchieveDimensionConstants.DEVICE_VISIT_REPORT_HOUR_CONSTANTS;
				break;
			
			case ReportArchieveDimensionConstants.DEVICE_VISIT_REPORT_DAY_TABLE:
				resultTableConstants = ReportArchieveDimensionConstants.DEVICE_VISIT_REPORT_DAY_CONSTANTS;
				break;
				
			case ReportArchieveDimensionConstants.COUNTRY_VISIT_REPORT_HOUR_TABLE:
				resultTableConstants = ReportArchieveDimensionConstants.COUNTRY_VISIT_REPORT_HOUR_CONSTANTS;
				break;
			
			case ReportArchieveDimensionConstants.COUNTRY_VISIT_REPORT_DAY_TABLE:
				resultTableConstants = ReportArchieveDimensionConstants.COUNTRY_VISIT_REPORT_DAY_CONSTANTS;
				break;
				
			case ReportArchieveDimensionConstants.LANG_VISIT_REPORT_HOUR_TABLE:
				resultTableConstants = ReportArchieveDimensionConstants.LANG_VISIT_REPORT_HOUR_CONSTANTS;
				break;
			
			case ReportArchieveDimensionConstants.LANG_VISIT_REPORT_DAY_TABLE:
				resultTableConstants = ReportArchieveDimensionConstants.LANG_VISIT_REPORT_DAY_CONSTANTS;
				break;
				
			case ReportArchieveDimensionConstants.OS_VISIT_REPORT_HOUR_TABLE:
				resultTableConstants = ReportArchieveDimensionConstants.OS_VISIT_REPORT_HOUR_CONSTANTS;
				break;
			
			case ReportArchieveDimensionConstants.OS_VISIT_REPORT_DAY_TABLE:
				resultTableConstants = ReportArchieveDimensionConstants.OS_VISIT_REPORT_DAY_CONSTANTS;
				break;
				
			case ReportArchieveDimensionConstants.TRAFSOUR_VISIT_REPORT_HOUR_TABLE:
				resultTableConstants = ReportArchieveDimensionConstants.TRAFSOUR_VISIT_REPORT_HOUR_CONSTANTS;
				break;
			
			case ReportArchieveDimensionConstants.TRAFSOUR_VISIT_REPORT_DAY_TABLE:
				resultTableConstants = ReportArchieveDimensionConstants.TRAFSOUR_VISIT_REPORT_DAY_CONSTANTS;
				break;
				
			case ReportArchieveDimensionConstants.REFURL_VISIT_REPORT_HOUR_TABLE:
				resultTableConstants = ReportArchieveDimensionConstants.REFURL_VISIT_REPORT_HOUR_CONSTANTS;
				break;
			
			case ReportArchieveDimensionConstants.REFURL_VISIT_REPORT_DAY_TABLE:
				resultTableConstants = ReportArchieveDimensionConstants.REFURL_VISIT_REPORT_DAY_CONSTANTS;
				break;
				
			case ReportArchieveDimensionConstants.DAYOFWK_VISIT_REPORT_HOUR_TABLE:
				resultTableConstants = ReportArchieveDimensionConstants.DAYOFWK_VISIT_REPORT_HOUR_CONSTANTS;
				break;
			
			case ReportArchieveDimensionConstants.DAYOFWK_VISIT_REPORT_DAY_TABLE:
				resultTableConstants = ReportArchieveDimensionConstants.DAYOFWK_VISIT_REPORT_DAY_CONSTANTS;
				break;
				
			case ReportArchieveDimensionConstants.HOURODY_VISIT_REPORT_HOUR_TABLE:
				resultTableConstants = ReportArchieveDimensionConstants.HOURODY_VISIT_REPORT_HOUR_CONSTANTS;
				break;
			
			case ReportArchieveDimensionConstants.HOURODY_VISIT_REPORT_DAY_TABLE:
				resultTableConstants = ReportArchieveDimensionConstants.HOURODY_VISIT_REPORT_DAY_CONSTANTS;
				break;
				
			case ReportArchieveDimensionConstants.COOKIE_VISIT_REPORT_HOUR_TABLE:
				resultTableConstants = ReportArchieveDimensionConstants.COOKIE_VISIT_REPORT_HOUR_CONSTANTS;
				break;
			
			case ReportArchieveDimensionConstants.COOKIE_VISIT_REPORT_DAY_TABLE:
				resultTableConstants = ReportArchieveDimensionConstants.COOKIE_VISIT_REPORT_DAY_CONSTANTS;
				break;
				
			case ReportArchieveDimensionConstants.URLPARM_VISIT_REPORT_HOUR_TABLE:
				resultTableConstants = ReportArchieveDimensionConstants.URLPARM_VISIT_REPORT_HOUR_CONSTANTS;
				break;
			
			case ReportArchieveDimensionConstants.URLPARM_VISIT_REPORT_DAY_TABLE:
				resultTableConstants = ReportArchieveDimensionConstants.URLPARM_VISIT_REPORT_DAY_CONSTANTS;
				break;
				
			case ReportArchieveDimensionConstants.JSVAR_VISIT_REPORT_HOUR_TABLE:
				resultTableConstants = ReportArchieveDimensionConstants.JSVAR_VISIT_REPORT_HOUR_CONSTANTS;
				break;
			
			case ReportArchieveDimensionConstants.JSVAR_VISIT_REPORT_DAY_TABLE:
				resultTableConstants = ReportArchieveDimensionConstants.JSVAR_VISIT_REPORT_DAY_CONSTANTS;
				break;
			}
			
			ZABModel.createRow(resultTableConstants, resultTable, hsList);
		
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage());
		}
		
	}
	 */

}
