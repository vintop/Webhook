//$Id$
package com.zoho.abtest.report;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.zoho.abtest.GOAL_DIMENSION_DAY;
import com.zoho.abtest.GOAL_DIMENSION_HOUR;
import com.zoho.abtest.GOAL_REPORT_DAY;
import com.zoho.abtest.GOAL_REPORT_HOUR;
import com.zoho.abtest.TIME_SPENT_REPORT_HOUR;
import com.zoho.abtest.VISITOR_DIMENSION_DAY;
import com.zoho.abtest.VISITOR_DIMENSION_HOUR;
import com.zoho.abtest.VISITOR_REPORT_DAY;
import com.zoho.abtest.VISITOR_REPORT_HOUR;
import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.goal.GoalConstants;
import com.zoho.abtest.report.ReportArchieveDimensionConstants.ReportDurationType;
import com.zoho.abtest.report.ReportArchieveDimensionConstants.ReportModuleType;

public class CumulativeReportConstants {
	
	public static final String API_MODULE = "reports";  //No I18N
	
	public final static String UNIQUE_VISITOR_HOUR_ID = "unique_visitor_hour_id";	//NO I18N
	public final static String UNIQUE_VISITOR_DAY_ID = "unique_visitor_day_id";	//NO I18N

	public final static String UNIQUE_GOAL_HOUR_ID = "unique_goal_hour_id";	//NO I18N
	public final static String UNIQUE_GOAL_DAY_ID = "unique_goal_day_id";	//NO I18N
	public final static String UNIQUE_HEATMAP_DAY_ID = "unique_heatmap_day_id";	//NO I18N
	public final static String UNIQUE_HEATMAP_HOUR_ID = "unique_heatmap_hour_id";	//NO I18N
	public final static String UNIQUE_SCROLLMAP_DAY_ID = "unique_scrollmap_day_id";	//NO I18N
	public final static String UNIQUE_SCROLLMAP_HOUR_ID = "unique_scrollmap_hour_id";	//NO I18N
	
	//public final static String UNIQUE_HEATMAP_HOUR_VISITS_ID = "unique_heatmap_hour_visits_id";	//NO I18N
	
	public final static String HOUR = "hour";	//NO I18N
	public final static String DATE = "date";	//NO I18N
	
	public static final String SAMPLE_SIZE= "sample_size";		//NO I18N
	public final static String CONVERSION_RATE = "conversion_rate";	//NO I18N
	public final static String EXPECTED_IMPROVEMENT  ="expected_improvement";		// NO I18N
	public static final String VISITORS_REQUIRED = "visitors_required";				// NO I18N
	public static final String DAYS_REQUIRED = "days_required";						// NO I18N
	public static final String DAILY_VISITORS = "daily_visitors";				// NO I18N
	public static final String IMPROVEMENT = "improvement";							// NO I18N
	public static final String VISITORS = "visitors";								// NO I18N
	public static final String FORECAST_VISITORS = "forecast_visitors";								// NO I18N
	public static final String CONVERSIONS = "conversions";								// NO I18N

	public static final String FORECAST_CONVERSIONS = "forecast_conversions";								// NO I18N
	public static final String SIGNIFICANCE = "significance";								// NO I18N
	public final static String IS_WINNER = "is_winner";									//NO I18N
	public final static String IS_LOSER = "is_loser";									//NO I18N
	public final static String IS_INSIGNIFICANT = "is_insignificant";									//NO I18N
	
	public final static String UNIQUE_STATISTICAL_SIGNIFICANCE = "unique_statistical_significance";	//NO I18N
	public final static String UNIQUE_CNVERSION_RATE=  "unique_conversion_rate";	//NO I18N
	public final static String UNIQUE_CONFIDENCE = "unique_confidence";	//NO I18N
	public final static String UNIQUE_IMPROVEMENT = "unique_improvement";			//NO I18N
	public final static String UNIQUE_IS_SIGNIFICANT = "unique_is_significant";			//NO I18N
	public final static String UNIQUE_CONCLUSION = "unique_conclusion";			//NO I18N
	
	public final static String TOTAL_STATISTICAL_SIGNIFICANCE = "total_statistical_significance";	//NO I18N
	public final static String TOTAL_CNVERSION_RATE=  "total_conversion_rate";	//NO I18N
	public final static String TOTAL_CONFIDENCE = "total_confidence";	//NO I18N
	public final static String TOTAL_IMPROVEMENT = "total_improvement";			//NO I18N
	public final static String TOTAL_IS_SIGNIFICANT = "total_is_significant";			//NO I18N
	public final static String TOTAL_CONCLUSION = "total_conclusion";			//NO I18N
	
	public static final String FORECAST_CONVERSION_RATE = "forecast_conversion_rate";								// NO I18N
	public static final String FORECAST_IMPROVEMENT = "forecast_improvement";								// NO I18N
	public static final String FORECAST_SIGNIFICANCE = "forecast_significance";								// NO I18N
	public static final String FORECAST_TIME_SPENT = "forecast_time_spent";								// NO I18N

	public final static String AVERAGE_TIME_SPENT = "average_time_spent";			//NO I18N

	public final static String UNIQUE_VISITORS_REQUIRED = "visitors required";	//NO I18N

	public final static String GOAL_CONVERSION_RATE = "goal_conversion_rate";			//NO I18N

	public final static String WINNER = "Winner";			//NO I18N
	public final static String LOSER = "Loser";			//NO I18N
	public final static String INCOCLUSIVE = "Inconclusive";			//NO I18N

	public final static String DECISION = "decision";			//NO I18N
	
	
	public static final String VISITOR_DIMENSION_DAY_ID = "visitor_dimension_day_id";	// NO I18N
	public static final String VISITOR_DIMENSION_HOUR_ID = "visitor_dimension_hour_id";	// NO I18N
	public static final String GOAL_DIMENSION_DAY_ID = "goal_dimension_day_id";	// NO I18N
	public static final String GOAL_DIMENSION_HOUR_ID = "goal_dimension_hour_id";	// NO I18N
	
	public static final String COUNTRY_CODE = "country_code";				//NO I18N
	public static final String DEVICE_CODE = "device_code";					//NO I18N
	public static final String OS_CODE = "os_code";							//NO I18N
	
	public static final String BROWSER_CODE = "browser_code";				//NO I18N
	public static final String LANGUAGE_CODE = "language_code";				//NO I18N
	public static final String USERTYPE_CODE = "usertype_code";				//NO I18N
	public static final String TRAFFICSOURCE_CODE = "trafficsource_code";		//NO I18N
	public static final String REFFERERURL_CODE = "reffererurl_code";			//NO I18N
	public static final String CURRENTURL_CODE = "currenturl_code";			//NO I18N
	public static final String DAYOFWEEK_CODE = "dayofweek_code";			//NO I18N
	public static final String HOUROFDAY_CODE = "hourofday_code";			//NO I18N
	
	public static final String URLPARAM_JSON = "urlparam_json";			//NO I18N
	public static final String COOKIE_JSON = "cookie_json";			//NO I18N
	public static final String JSVAR_JSON = "jsvar_json";			//NO I18N
	public static final String CUSTOMDIMEN_JSON = "customdimen_json";			//NO I18N
	
	public static final String TIME = "time";								//NO I18N
	
	public static final String GOAL_LINK_NAME  = "goal_link_name";		// NO I18N
	public static final String VARIATION_LINK_NAME  = "variation_link_name";		// NO I18N
	
	public static final String IS_PREDICTED  = "is_predicted";		// NO I18N
		
	
	public enum CumulativeTableMetaValues
	{
		VISITOR_REPORT_HOUR("EXPERIMENT_ID,VARIATION_ID","VISITOR_REPORT_HOUR",ReportDurationType.HOUR.getDurationCode(),ReportModuleType.VISIT.getModuleCode()), //No I18N
		VISITOR_REPORT_DAY("EXPERIMENT_ID,VARIATION_ID","VISITOR_REPORT_DAY",ReportDurationType.DAY.getDurationCode(),ReportModuleType.VISIT.getModuleCode()), //No I18N
		GOAL_REPORT_HOUR("EXPERIMENT_ID,VARIATION_ID,GOAL_ID","GOAL_REPORT_HOUR",ReportDurationType.HOUR.getDurationCode(),ReportModuleType.GOALACHIEVED.getModuleCode()), //No I18N
		HEATMAP_DATA_DAY("EXPERIMENT_ID,VARIATION_ID,SELECTOR,POINT_X,POINT_Y","HEATMAP_DATA_DAY",ReportDurationType.DAY.getDurationCode(),ReportModuleType.HEATMAPDATA.getModuleCode()), //No I18N
		HEATMAP_DATA_HOUR("EXPERIMENT_ID,VARIATION_ID,SELECTOR,POINT_X,POINT_Y","HEATMAP_DATA_HOUR",ReportDurationType.HOUR.getDurationCode(),ReportModuleType.HEATMAPDATA.getModuleCode()), //No I18N
		SCROLLMAP_DATA_DAY("EXPERIMENT_ID,VARIATION_ID","SCROLLMAP_DATA_DAY",ReportDurationType.DAY.getDurationCode(),ReportModuleType.SCROLLMAPDATA.getModuleCode()), //No I18N
		SCROLLMAP_DATA_HOUR("EXPERIMENT_ID,VARIATION_ID","SCROLLMAP_DATA_HOUR",ReportDurationType.HOUR.getDurationCode(),ReportModuleType.SCROLLMAPDATA.getModuleCode()), //No I18N
		GOAL_REPORT_DAY("EXPERIMENT_ID,VARIATION_ID,GOAL_ID","GOAL_REPORT_DAY",ReportDurationType.DAY.getDurationCode(),ReportModuleType.GOALACHIEVED.getModuleCode()), //No I18N
		REVENUE_REPORT_HOUR("EXPERIMENT_ID,VARIATION_ID","REVENUE_REPORT_HOUR",ReportDurationType.HOUR.getDurationCode(),ReportModuleType.GOALACHIEVED.getModuleCode()),//No I18N
		REVENUE_REPORT_DAY("EXPERIMENT_ID,VARIATION_ID","REVENUE_REPORT_DAY",ReportDurationType.DAY.getDurationCode(),ReportModuleType.GOALACHIEVED.getModuleCode()),//No I18N
		TIME_SPENT_REPORT_HOUR("EXPERIMENT_ID,VARIATION_ID","TIME_SPENT_REPORT_HOUR",ReportDurationType.HOUR.getDurationCode(),ReportModuleType.VISIT.getModuleCode());//No I18N
		
		String groupByColumns;
		String resultTable;
		Integer durationType;
		Integer moduleType;
		
	
		public String getGroupByColumns() {
			return groupByColumns;
		}
		public void setGroupByColumns(String groupByColumns) {
			this.groupByColumns = groupByColumns;
		}
		public String getResultTable() {
			return resultTable;
		}
		public void setResultTable(String resultTable) {
			this.resultTable = resultTable;
		}
		public Integer getDurationType() {
			return durationType;
		}
		public void setDurationType(Integer durationType) {
			this.durationType = durationType;
		}
		public Integer getModuleType() {
			return moduleType;
		}
		public void setModuleType(Integer moduleType) {
			this.moduleType = moduleType;
		}
		
		private CumulativeTableMetaValues(String groupByColumns,String resultTable,Integer durationType,Integer moduleType)
		{
			
			this.groupByColumns = groupByColumns;
			this.resultTable = resultTable;
			this.durationType = durationType;
			this.moduleType = moduleType;
		}
	}

	public  enum DecisionType {
		WINNER(1),
		INCONCLUSIVE(2),
		LEADING_VARIANT(3);
		
		
		private Integer decisionTypeId;
		
		private DecisionType(Integer decisionTypeId) {
			this.decisionTypeId = decisionTypeId;
		}

		public Integer getDecisionTypeId() {
			return decisionTypeId;
		}
		
		public static DecisionType getDecisionTypeById(Integer decisionTypeId) {
			if(decisionTypeId!=null) {
				for(DecisionType decision: DecisionType.values()) {
					if(decisionTypeId.equals(decision.getDecisionTypeId())) {
						return decision;
					}
				}
			}
			return null;
		}
	}
	
	
	public static final List<Constants> VISITOR_REPORT_HOUR_CONSTANTS;
	
	static{
		List<Constants> archieveTableMetaConstants = new ArrayList<Constants>();
		archieveTableMetaConstants.add(new Constants(UNIQUE_VISITOR_HOUR_ID,VISITOR_REPORT_HOUR.VISITOR_REPORT_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.EXPERIMENT_ID,VISITOR_REPORT_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.VARIATION_ID,VISITOR_REPORT_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.TOTAL_COUNT,VISITOR_REPORT_HOUR.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(HOUR,VISITOR_REPORT_HOUR.TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		
		VISITOR_REPORT_HOUR_CONSTANTS = Collections.unmodifiableList(archieveTableMetaConstants);
	}
	
	
	public static final List<Constants> VISITOR_REPORT_DAY_CONSTANTS;
	
	static{
		List<Constants> archieveTableMetaConstants = new ArrayList<Constants>();
		archieveTableMetaConstants.add(new Constants(UNIQUE_VISITOR_DAY_ID,VISITOR_REPORT_DAY.VISITOR_REPORT_DAY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.EXPERIMENT_ID,VISITOR_REPORT_DAY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.VARIATION_ID,VISITOR_REPORT_DAY.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.TOTAL_COUNT,VISITOR_REPORT_DAY.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(DATE,VISITOR_REPORT_DAY.DATE,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		
		VISITOR_REPORT_DAY_CONSTANTS = Collections.unmodifiableList(archieveTableMetaConstants);
	}
	
	public static final List<Constants> GOAL_REPORT_HOUR_CONSTANTS;
	
	static{
		List<Constants> archieveTableMetaConstants = new ArrayList<Constants>();
		archieveTableMetaConstants.add(new Constants(UNIQUE_GOAL_HOUR_ID,GOAL_REPORT_HOUR.GOAL_REPORT_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.EXPERIMENT_ID,GOAL_REPORT_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.VARIATION_ID,GOAL_REPORT_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.GOAL_ID,GOAL_REPORT_HOUR.GOAL_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.TOTAL_COUNT,GOAL_REPORT_HOUR.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(HOUR,GOAL_REPORT_HOUR.TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		
		GOAL_REPORT_HOUR_CONSTANTS = Collections.unmodifiableList(archieveTableMetaConstants);
	}
	
	
	public static final List<Constants> GOAL_REPORT_DAY_CONSTANTS;
	
	static{
		List<Constants> archieveTableMetaConstants = new ArrayList<Constants>();
		archieveTableMetaConstants.add(new Constants(UNIQUE_GOAL_DAY_ID,GOAL_REPORT_DAY.GOAL_REPORT_DAY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.EXPERIMENT_ID,GOAL_REPORT_DAY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.VARIATION_ID,GOAL_REPORT_DAY.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.GOAL_ID,GOAL_REPORT_DAY.GOAL_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.TOTAL_COUNT,GOAL_REPORT_DAY.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(DATE,GOAL_REPORT_DAY.DATE,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		
		GOAL_REPORT_DAY_CONSTANTS = Collections.unmodifiableList(archieveTableMetaConstants);
	}
	
//	public static final List<Constants> HEATMAP_DATA_DAY_CONSTANTS;
//	
//	static{
//		List<Constants> archieveTableMetaConstants = new ArrayList<Constants>();
//		archieveTableMetaConstants.add(new Constants(UNIQUE_HEATMAP_DAY_ID,HEATMAP_DATA_DAY.HEATMAP_DATA_DAY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
//		archieveTableMetaConstants.add(new Constants(HeatmapConstants.EXPERIMENT_ID,HEATMAP_DATA_DAY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
//		archieveTableMetaConstants.add(new Constants(HeatmapConstants.VARIATION_ID,HEATMAP_DATA_DAY.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
//		archieveTableMetaConstants.add(new Constants(HeatmapConstants.SELECTOR,HEATMAP_DATA_DAY.SELECTOR,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
//		archieveTableMetaConstants.add(new Constants(HeatmapConstants.POINT_X,HEATMAP_DATA_DAY.POINT_X,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
//		archieveTableMetaConstants.add(new Constants(HeatmapConstants.POINT_Y,HEATMAP_DATA_DAY.POINT_Y,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
//		archieveTableMetaConstants.add(new Constants(HeatmapConstants.CLICKS,HEATMAP_DATA_DAY.CLICKS,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
//		archieveTableMetaConstants.add(new Constants(HeatmapConstants.DATE,HEATMAP_DATA_DAY.DATE,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
//		
//		HEATMAP_DATA_DAY_CONSTANTS = Collections.unmodifiableList(archieveTableMetaConstants);
//	}
//		
//	public static final List<Constants> HEATMAP_DATA_HOUR_CONSTANTS;
//	
//	static{
//		List<Constants> archieveTableMetaConstants = new ArrayList<Constants>();
//		archieveTableMetaConstants.add(new Constants(UNIQUE_HEATMAP_HOUR_ID,HEATMAP_DATA_HOUR.HEATMAP_DATA_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
//		archieveTableMetaConstants.add(new Constants(HeatmapConstants.EXPERIMENT_ID,HEATMAP_DATA_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
//		archieveTableMetaConstants.add(new Constants(HeatmapConstants.VARIATION_ID,HEATMAP_DATA_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
//		archieveTableMetaConstants.add(new Constants(HeatmapConstants.SELECTOR,HEATMAP_DATA_HOUR.SELECTOR,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
//		archieveTableMetaConstants.add(new Constants(HeatmapConstants.POINT_X,HEATMAP_DATA_HOUR.POINT_X,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
//		archieveTableMetaConstants.add(new Constants(HeatmapConstants.POINT_Y,HEATMAP_DATA_HOUR.POINT_Y,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
//		archieveTableMetaConstants.add(new Constants(HeatmapConstants.CLICKS,HEATMAP_DATA_HOUR.CLICKS,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
//		archieveTableMetaConstants.add(new Constants(HeatmapConstants.HOUR,HEATMAP_DATA_HOUR.HOUR,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
//		
//		HEATMAP_DATA_HOUR_CONSTANTS = Collections.unmodifiableList(archieveTableMetaConstants);
//	}
	
//	public static final List<Constants> HEATMAP_DATA_HOUR_TRY_CONSTANTS;
//	
//	static{
//		List<Constants> archieveTableMetaConstants = new ArrayList<Constants>();
//		archieveTableMetaConstants.add(new Constants(UNIQUE_HEATMAP_HOUR_ID,HEATMAP_DATA_HOUR_TRY.HEATMAP_DATA_HOUR_TRY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
//		archieveTableMetaConstants.add(new Constants(HeatmapConstants.EXPERIMENT_ID.toLowerCase(),HEATMAP_DATA_HOUR_TRY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
//		archieveTableMetaConstants.add(new Constants(HeatmapConstants.VARIATION_ID.toLowerCase(),HEATMAP_DATA_HOUR_TRY.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
//		archieveTableMetaConstants.add(new Constants(HeatmapConstants.SELECTOR.toLowerCase(),HEATMAP_DATA_HOUR_TRY.SELECTOR,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
//		archieveTableMetaConstants.add(new Constants("points",HEATMAP_DATA_HOUR_TRY.POINTS,"integer[][]",Boolean.TRUE,Boolean.FALSE));
//		archieveTableMetaConstants.add(new Constants(HeatmapConstants.HOUR.toLowerCase(),HEATMAP_DATA_HOUR_TRY.HOUR,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
//		
//		HEATMAP_DATA_HOUR_TRY_CONSTANTS = Collections.unmodifiableList(archieveTableMetaConstants);
//	}
	
//	public static final List<Constants> SCROLLMAP_DATA_DAY_CONSTANTS;
//	
//	static{
//		List<Constants> archieveTableMetaConstants = new ArrayList<Constants>();
//		archieveTableMetaConstants.add(new Constants(UNIQUE_SCROLLMAP_DAY_ID,SCROLLMAP_DATA_DAY.SCROLLMAP_DATA_DAY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
//		archieveTableMetaConstants.add(new Constants(ScrollmapConstants.EXPERIMENT_ID,SCROLLMAP_DATA_DAY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
//		archieveTableMetaConstants.add(new Constants(ScrollmapConstants.VARIATION_ID,SCROLLMAP_DATA_DAY.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
//		archieveTableMetaConstants.add(new Constants(ScrollmapConstants.POINT_Y1,SCROLLMAP_DATA_DAY.POINT_Y1,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
//		archieveTableMetaConstants.add(new Constants(ScrollmapConstants.POINT_Y2,SCROLLMAP_DATA_DAY.POINT_Y2,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
//		archieveTableMetaConstants.add(new Constants(ScrollmapConstants.VISITS_COUNT,SCROLLMAP_DATA_DAY.VISITS_COUNT,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
//		archieveTableMetaConstants.add(new Constants(ScrollmapConstants.DATE,SCROLLMAP_DATA_DAY.DATE,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
//		
//		SCROLLMAP_DATA_DAY_CONSTANTS = Collections.unmodifiableList(archieveTableMetaConstants);
//	}
//		
//	public static final List<Constants> SCROLLMAP_DATA_HOUR_CONSTANTS;
//	
//	static{
//		List<Constants> archieveTableMetaConstants = new ArrayList<Constants>();
//		archieveTableMetaConstants.add(new Constants(UNIQUE_SCROLLMAP_HOUR_ID,SCROLLMAP_DATA_HOUR.SCROLLMAP_DATA_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
//		archieveTableMetaConstants.add(new Constants(ScrollmapConstants.EXPERIMENT_ID,SCROLLMAP_DATA_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
//		archieveTableMetaConstants.add(new Constants(ScrollmapConstants.VARIATION_ID,SCROLLMAP_DATA_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
//		archieveTableMetaConstants.add(new Constants(ScrollmapConstants.POINT_Y1,SCROLLMAP_DATA_HOUR.POINT_Y1,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
//		archieveTableMetaConstants.add(new Constants(ScrollmapConstants.POINT_Y2,SCROLLMAP_DATA_HOUR.POINT_Y2,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
//		archieveTableMetaConstants.add(new Constants(ScrollmapConstants.VISITS_COUNT,SCROLLMAP_DATA_HOUR.VISITS_COUNT,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
//		archieveTableMetaConstants.add(new Constants(ScrollmapConstants.HOUR,SCROLLMAP_DATA_HOUR.HOUR,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
//		
//		SCROLLMAP_DATA_HOUR_CONSTANTS = Collections.unmodifiableList(archieveTableMetaConstants);
//	}
//
	public static final List<Constants> VISITOR_DIMENSION_DAY_CONSTANTS;
	
	static{
		List<Constants> archieveTableMetaConstants = new ArrayList<Constants>();
		archieveTableMetaConstants.add(new Constants(VISITOR_DIMENSION_DAY_ID,VISITOR_DIMENSION_DAY.VISITOR_DIMENSION_DAY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.EXPERIMENT_ID,VISITOR_DIMENSION_DAY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.VARIATION_ID,VISITOR_DIMENSION_DAY.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(BROWSER_CODE,VISITOR_DIMENSION_DAY.BROWSER_CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(COUNTRY_CODE,VISITOR_DIMENSION_DAY.COUNTRY_CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(DEVICE_CODE,VISITOR_DIMENSION_DAY.DEVICE_CODE,ZABConstants.INTEGER,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(OS_CODE,VISITOR_DIMENSION_DAY.OS_CODE,ZABConstants.INTEGER,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(REFFERERURL_CODE,VISITOR_DIMENSION_DAY.REFFERERURL_CODE,ZABConstants.INTEGER,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(LANGUAGE_CODE,VISITOR_DIMENSION_DAY.LANGUAGE_CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(USERTYPE_CODE,VISITOR_DIMENSION_DAY.USERTYPE_CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(TRAFFICSOURCE_CODE,VISITOR_DIMENSION_DAY.TRAFFICSOURCE_CODE,ZABConstants.INTEGER,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(CURRENTURL_CODE,VISITOR_DIMENSION_DAY.CURRENTURL_CODE,ZABConstants.INTEGER,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(DAYOFWEEK_CODE,VISITOR_DIMENSION_DAY.DAYOFWEEK_CODE,ZABConstants.INTEGER,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(HOUROFDAY_CODE,VISITOR_DIMENSION_DAY.HOUROFDAY_CODE,ZABConstants.INTEGER,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.TOTAL_COUNT,VISITOR_DIMENSION_DAY.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(TIME,VISITOR_DIMENSION_DAY.DATE,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		
		VISITOR_DIMENSION_DAY_CONSTANTS = Collections.unmodifiableList(archieveTableMetaConstants);
	}
	
public static final List<Constants> VISITOR_DIMENSION_HOUR_CONSTANTS;
	
	static{
		List<Constants> archieveTableMetaConstants = new ArrayList<Constants>();
		archieveTableMetaConstants.add(new Constants(VISITOR_DIMENSION_HOUR_ID,VISITOR_DIMENSION_HOUR.VISITOR_DIMENSION_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.EXPERIMENT_ID,VISITOR_DIMENSION_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.VARIATION_ID,VISITOR_DIMENSION_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(BROWSER_CODE,VISITOR_DIMENSION_HOUR.BROWSER_CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(COUNTRY_CODE,VISITOR_DIMENSION_HOUR.COUNTRY_CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(DEVICE_CODE,VISITOR_DIMENSION_HOUR.DEVICE_CODE,ZABConstants.INTEGER,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(OS_CODE,VISITOR_DIMENSION_HOUR.OS_CODE,ZABConstants.INTEGER,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(REFFERERURL_CODE,VISITOR_DIMENSION_HOUR.REFFERERURL_CODE,ZABConstants.INTEGER,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(LANGUAGE_CODE,VISITOR_DIMENSION_HOUR.LANGUAGE_CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(USERTYPE_CODE,VISITOR_DIMENSION_HOUR.USERTYPE_CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(TRAFFICSOURCE_CODE,VISITOR_DIMENSION_HOUR.TRAFFICSOURCE_CODE,ZABConstants.INTEGER,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(CURRENTURL_CODE,VISITOR_DIMENSION_HOUR.CURRENTURL_CODE,ZABConstants.INTEGER,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(DAYOFWEEK_CODE,VISITOR_DIMENSION_HOUR.DAYOFWEEK_CODE,ZABConstants.INTEGER,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(HOUROFDAY_CODE,VISITOR_DIMENSION_HOUR.HOUROFDAY_CODE,ZABConstants.INTEGER,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.TOTAL_COUNT,VISITOR_DIMENSION_HOUR.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(TIME,VISITOR_DIMENSION_HOUR .TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		
		VISITOR_DIMENSION_HOUR_CONSTANTS = Collections.unmodifiableList(archieveTableMetaConstants);
	}
	

	public static final List<Constants> GOAL_DIMENSION_DAY_CONSTANTS;
	
	static{
		List<Constants> archieveTableMetaConstants = new ArrayList<Constants>();
		archieveTableMetaConstants.add(new Constants(GOAL_DIMENSION_DAY_ID,GOAL_DIMENSION_DAY.GOAL_DIMENSION_DAY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.EXPERIMENT_ID,GOAL_DIMENSION_DAY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.VARIATION_ID,GOAL_DIMENSION_DAY.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(GoalConstants.GOAL_ID,GOAL_DIMENSION_DAY.GOAL_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(BROWSER_CODE,GOAL_DIMENSION_DAY.BROWSER_CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(COUNTRY_CODE,GOAL_DIMENSION_DAY.COUNTRY_CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(DEVICE_CODE,GOAL_DIMENSION_DAY.DEVICE_CODE,ZABConstants.INTEGER,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(OS_CODE,GOAL_DIMENSION_DAY.OS_CODE,ZABConstants.INTEGER,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(REFFERERURL_CODE,GOAL_DIMENSION_DAY.REFFERERURL_CODE,ZABConstants.INTEGER,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(LANGUAGE_CODE,GOAL_DIMENSION_DAY.LANGUAGE_CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(USERTYPE_CODE,GOAL_DIMENSION_DAY.USERTYPE_CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(TRAFFICSOURCE_CODE,GOAL_DIMENSION_DAY.TRAFFICSOURCE_CODE,ZABConstants.INTEGER,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(CURRENTURL_CODE,GOAL_DIMENSION_DAY.CURRENTURL_CODE,ZABConstants.INTEGER,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(DAYOFWEEK_CODE,GOAL_DIMENSION_DAY.DAYOFWEEK_CODE,ZABConstants.INTEGER,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(HOUROFDAY_CODE,GOAL_DIMENSION_DAY.HOUROFDAY_CODE,ZABConstants.INTEGER,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.TOTAL_COUNT,GOAL_DIMENSION_DAY.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(TIME,GOAL_DIMENSION_DAY.DATE,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		
		GOAL_DIMENSION_DAY_CONSTANTS = Collections.unmodifiableList(archieveTableMetaConstants);
	}
	
	public static final List<Constants> GOAL_DIMENSION_HOUR_CONSTANTS;
	
	static{
		List<Constants> archieveTableMetaConstants = new ArrayList<Constants>();
		archieveTableMetaConstants.add(new Constants(GOAL_DIMENSION_HOUR_ID,GOAL_DIMENSION_HOUR.GOAL_DIMENSION_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.EXPERIMENT_ID,GOAL_DIMENSION_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.VARIATION_ID,GOAL_DIMENSION_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(GoalConstants.GOAL_ID,GOAL_DIMENSION_HOUR.GOAL_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(BROWSER_CODE,GOAL_DIMENSION_HOUR.BROWSER_CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(COUNTRY_CODE,GOAL_DIMENSION_HOUR.COUNTRY_CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(DEVICE_CODE,GOAL_DIMENSION_HOUR.DEVICE_CODE,ZABConstants.INTEGER,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(OS_CODE,GOAL_DIMENSION_HOUR.OS_CODE,ZABConstants.INTEGER,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(REFFERERURL_CODE,GOAL_DIMENSION_HOUR.REFFERERURL_CODE,ZABConstants.INTEGER,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(LANGUAGE_CODE,GOAL_DIMENSION_HOUR.LANGUAGE_CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(USERTYPE_CODE,GOAL_DIMENSION_HOUR.USERTYPE_CODE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(TRAFFICSOURCE_CODE,GOAL_DIMENSION_HOUR.TRAFFICSOURCE_CODE,ZABConstants.INTEGER,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(CURRENTURL_CODE,GOAL_DIMENSION_HOUR.CURRENTURL_CODE,ZABConstants.INTEGER,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(DAYOFWEEK_CODE,GOAL_DIMENSION_HOUR.DAYOFWEEK_CODE,ZABConstants.INTEGER,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(HOUROFDAY_CODE,GOAL_DIMENSION_HOUR.HOUROFDAY_CODE,ZABConstants.INTEGER,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.TOTAL_COUNT,GOAL_DIMENSION_HOUR.TOTAL_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(TIME,GOAL_DIMENSION_HOUR .TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		
		GOAL_DIMENSION_HOUR_CONSTANTS = Collections.unmodifiableList(archieveTableMetaConstants);
	}
	public static final List<Constants> TIME_SPENT_HOUR_CONSTANTS;
	
	static{
		List<Constants> archieveTableMetaConstants = new ArrayList<Constants>();
		archieveTableMetaConstants.add(new Constants(ReportRawDataConstants.TIME_SPENT_DATA_RAW_ID,TIME_SPENT_REPORT_HOUR.TIME_SPENT_REPORT_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.EXPERIMENT_ID,VISITOR_REPORT_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.VARIATION_ID,VISITOR_REPORT_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(HOUR,VISITOR_REPORT_HOUR.TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));	
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.TIME_SPENT,TIME_SPENT_REPORT_HOUR.TIME_SPENT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		
		TIME_SPENT_HOUR_CONSTANTS = Collections.unmodifiableList(archieveTableMetaConstants);
	}
	

}
