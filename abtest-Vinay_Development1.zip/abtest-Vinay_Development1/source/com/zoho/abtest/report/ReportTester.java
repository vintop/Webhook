//$Id$
package com.zoho.abtest.report;

public class ReportTester {
	
	private static Long visitorCountHits = 0L;
	
	private static Long visitorCountCousumerHits = 0L;
	
	private static Long goalCountHits = 0L;
	
	private static Long goalCountCousumerHits = 0L;

	public static Long getVisitorCount() {
		return visitorCountHits;
	}
	
	public static Long getGoalCount() {
		return goalCountHits;
	}

	public static Long getVisitorCountCousumerHits() {
		return visitorCountCousumerHits;
	}
	
	public static Long getGoalCountCousumerHits() {
		return goalCountCousumerHits;
	}

	public static void incrementVisitorCountCousumer() {
		synchronized (visitorCountCousumerHits) {			
			visitorCountCousumerHits++;
		}
	}
	
	public static void incrementGoalCountConsumer() {
		synchronized (goalCountCousumerHits) {			
			goalCountCousumerHits++;
		}
	}
	
	public static void incrementVisitorCount() {
		synchronized (visitorCountHits) {			
			visitorCountHits++;
		}
	}
	
	public static void incrementGoalCount() {
		synchronized (goalCountHits) {			
			goalCountHits++;
		}
	}
	
	public static void resetVisitorCount() {
		visitorCountHits = 0L;
	}
	
	public static void resetGoalCount() {
		visitorCountHits = 0L;
	}
	
}
