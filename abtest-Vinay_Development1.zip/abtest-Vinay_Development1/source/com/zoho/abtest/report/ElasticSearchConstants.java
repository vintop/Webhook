//$Id$
package com.zoho.abtest.report;

import java.util.ArrayList;

public class ElasticSearchConstants 
{
	public static final String QUICKFILTER_ATTR_API_MODULE = "quickfilterattr";		// NO I18N
	
	public static final String DBSPACEID = "dbspaceid";		// NO I18N
	public static final String PORTAL = "portal";		// NO I18N
	public static final String ZSOID = "zsoid";		// NO I18N
	public static final String EXPERIMENTID = "experimentid";		// NO I18N
	public static final String EXPERIMENTIDS = "experimentids";		// NO I18N
	public static final String EXPERIMENTKEY = "experimentkey";		// NO I18N
	public static final String SESSION_ALIAS_USERNAME = "alias_username";		// NO I18N
	public static final String VARIATIONID = "variationid";		// NO I18N
	public static final String PROJECTID = "projectid";		// NO I18N
	public static final String STEPID = "stepid";		// NO I18N
	public static final String STEPKEY = "stepkey";		// NO I18N
	public static final String GCLID = "gclid";		// NO I18N
	public static final String SESSION_ID = "sessionid";		// NO I18N
	public static final String STEPS = "steps";		// NO I18N
	public static final String GOALID = "goalid";		// NO I18N
	public static final String BROWSER = "browser"; //NO I18N
	public static final String DEVICE = "device"; //NO I18N
	public static final String COUNTRY = "country"; //NO I18N
	public static final String CITY = "city"; //NO I18N
	public static final String REGION = "region"; //NO I18N
	public static final String LANGUAGE = "language"; //NO I18N
	public static final String TEXT = "text"; //NO I18N
	public static final String ELEMENT_ID = "element_id"; //NO I18N
	
	public static final String OS = "os"; //NO I18N
	public static final String IS_PROJECT_GOAL = "is_project_goal"; //NO I18N
	public static final String TRAFFICSOURCE = "trafficsource"; //NO I18N
	public static final String REFFERERURL = "reffererurl"; //NO I18N
	public static final String DAYOFWEEK = "dayofweek"; //NO I18N
	public static final String HOUROFDAY = "hourofday"; //NO I18N
	public static final String CURRENTURL = "currenturl"; //NO I18N
	public static final String USERTYPE = "usertype"; //NO I18N
	public static final String FUSERTYPE = "fusertype"; //NO I18N
	public static final String COOKIE = "cookie"; //NO I18N
	public static final String URLPARAMETER = "urlparameter"; //NO I18N
	public static final String JSVARIABLE = "jsvariable"; //NO I18N
	public static final String CUSTOMDIMENSION = "customdimension"; //NO I18N
	public static final String NCOOKIE = "ncookie"; //NO I18N
	public static final String NURLPARAMETER = "nurlparameter"; //NO I18N
	public static final String NJSVARIABLE = "njsvariable"; //NO I18N
	public static final String NCUSTOMDIMENSION = "ncustomdimension"; //NO I18N
	public static final String VISITORID = "visitorid";		// NO I18N
	public static final String UVID = "uvid";		// NO I18N
	public static final String UAID = "uaid";		// NO I18N
	public static final String TIME = "time";		// NO I18N
	public static final String URL = "url";		// NO I18N
	public static final String PAGE_ID = "page_id";		// NO I18N
	public static final String PAGE_BLOCK_ID = "page_block_id";		// NO I18N
	
	public static final String TIME_SPENT = "time_spent";		// NO I18N
	public static final String EVENTID = "eventid";		// NO I18N
	public static final String NAME = "name"; //NO I18N
	public static final String VALUE = "value"; //NO I18N
	public static final String FIRST_VISIT_TIME = "first_visit_time";		// NO I18N
	public static final String LAST_ACTIVITY_TIME = "last_activity_time";		// NO I18N
	
	public static final String LAST_INTERACTED_TIME = "last_interacted_time";		// NO I18N
	
	public static final String LAST_URL_VISITED = "last_url_visited";		// NO I18N
	
	
	public static final String URLS_VISITED = "urls_visited";		// NO I18N
	public static final String ELEMENTS_CLICKED = "elements_clicked";		// NO I18N
	
	public static final String INPUT_INTERACTED = "input_interacted";		// NO I18N
	public static final String ACHEIVED_GOALS = "acheived_goals";		// NO I18N
	public static final String TAGS = "tags";		// NO I18N
	public static final String IDENTITY_DETAILS = "identity_details";		// NO I18N

	
	
	
	/**
	 * These types are considered to find whether the portal have got any visitors or not.
	 * Will be used by Zoho Campaign schedule and will be updated 3 times a day.
	 */
	public static final String[] VISITOR_DOC_TYPES = {
														ElasticSearchConstants.VISITOR_RAW_TYPE,
														ElasticSearchConstants.FUNNEL_RAW_TYPE,
														ElasticSearchConstants.FORM_ANALYTICS_RAW_TYPE,
														ElasticSearchConstants.SESSION_RAW_DATA_TYPE,
													 };
	
	public static final String VISITOR_RAW_TYPE = "visitorrawdata";		// NO I18N
	public static final String GOAL_RAW_TYPE = "goalrawdata";		// NO I18N
	public static final String HEATMAP_RAW_TYPE = "heatmaprawdata";		// NO I18N
	public static final String FUNNEL_RAW_TYPE = "funnelrawdata";		// NO I18N
	public static final String SCROLLMAP_RAW_TYPE = "scrollmaprawdata";		// NO I18N
	public static final String FORM_ANALYTICS_RAW_TYPE = "formrawdata";		// NO I18N
	public static final String FORM_ANALYTICS_FIELDS_RAW_TYPE = "formfieldrawdata";		// NO I18N
	public static final String ADWORDS_RAW_TYPE = "adwordsrawdata";		// NO I18N
	//public static final String IDENTITY_RAW_DATA_TYPE = "identityrawdata";		// NO I18N


	public static final String UUID="uuid"; //No I18N
	
	public static final String SESSION_RAW_DATA_TYPE = "sessionrawdata";		// NO I18N
	
	public static final String SESSION_EVENT_STREAM_DATA_TYPE = "sessioneventstreamdata";		// NO I18N
	
	public static final String SESSION_USER_EVENT_DATA_TYPE = "sessionusereventdata";		// NO I18N
	
	public static final String SESSION_PAGE_RESOURCE_TYPE = "sessionpageassetsdata";		// NO I18N

	//Quick filters
	public static final String SEGMENT_VALUE = "segment_value";		// NO I18N
	public static final String VISITOR_COUNT = "visitor_count";		// NO I18N
	public static final String DISPLAY_NAME = "display_name";		// NO I18N
	public static final String QF_ATTRIBUTE_DISPLAYNAME = "qf_attribute_displayname";		// NO I18N
	public static final String QF_ATTRIBUTE_LINKNAME = "qf_attribute_linkname";		// NO I18N
	public static final String QF_ATTRIBUTE_TYPE = "qf_attribute_type";		// NO I18N
	
	public static final String QF_ATTRIBUTE_VALUES = "qf_attribute_values";		// NO I18N
	
	public static final String SELECTOR = "selector"; //NO I18N
	public static final String DISPLAY_TEXT = "display_text"; //NO I18N
	public static final String POINTS = "points"; //NO I18N
	public static final String POINT_X = "point_x"; //NO I18N
	public static final String POINT_Y = "point_y"; //NO I18N
	public static final String CLICKS = "clicks"; //NO I18N
	public static final String REVENUE = "revenue";//NO I18N
	
	public static final String SCROLL_Y1 = "scroll_y1"; //NO I18N
	public static final String SCROLL_Y2 = "scroll_y2"; //NO I18N
	public static final String HEIGHT = "height"; //NO I18N
	public static final String SCROLL_LIST = "scroll_list"; //NO I18N
	
	public static final String WIDTH = "width"; //NO I18N
	
	public static final String VISITOR_TYPE = "visitor_type"; //NO I18N
	
	public static final int DEFAULT_INDEX_COUNT = 20;
	
	public static final String DEFAULT_INDEX_PREFIX = "zohooptimize";		// NO I18N
	
	public static final int VARIATION_MAX_COUNT = 100;
	public static final int EVENT_MAX_COUNT = 50;
	public static final int GOAL_MAX_COUNT = 100;
	public static final int VISITOR_MAX_COUNT = Integer.MAX_VALUE;
	public static final int INTEGER_MAX_COUNT = Integer.MAX_VALUE;
	public static final int SEGMENT_MAX_COUNT = 500;
	public static final int URLS_MAX_COUNT = 100;
	
	public static final String IS_HEATMAP_ENABLED = "heatmap_enabled"; // NO I18N
	
	public static final String PAGE_X = "page_x"; //NO I18N
	
	public static final String PAGE_Y = "page_y"; //NO I18N
	
	public static final String CLIENT_X = "client_x"; //NO I18N
	
	public static final String CLIENT_Y = "client_y"; //NO I18N

	public static final String CSS_SELECTOR = "css_selector"; //NO I18N
	
	public static final String ZSID = "zsid"; //NO I18N
	
	public static final String SESSION_INPUT_VALUE = "input_value"; //NO I18N
	
	public static final String SESSION_EVENT_TYPE = "event_type"; //NO I18N
	
	public static final String SESSION_TIMER = "timer"; //NO I18N
	
	public static final String SESSION_SEQUENCE_ID = "sequence_id"; //NO I18N
	
	public static final String SESSION_VISIBILITY_TYPE = "visibility_type"; //NO I18N
	
	public static final String SESSION_SCROLLX = "scroll_x";		// NO I18N
	
	public static final String SESSION_SCROLLY = "scroll_y";		// NO I18N
	
	public static final String SESSION_MUTATION_TYPE = "mutation_type";		// NO I18N
	
	public static final String SESSION_IS_PARTIAL_DATA = "is_partial_data";		// NO I18N
	
	public static final String IS_OPT_OUT = "is_opt_out";		// NO I18N
	
	public static final String SESSION_ATTRIBUTE_NAME = "attribute_name";		// NO I18N
	
	public static final String SESSION_ATTRIBUTE_VALUE = "attribute_value";		// NO I18N
	
	public static final String SESSION_DOM_CHANGE = "dom_change";		// NO I18N
	
	public static final String SESSION_PREVIOUS_SELECTOR = "previous_selector";		// NO I18N
	
	public static final String SESSION_NEXT_SELECTOR = "next_selector";		// NO I18N
	
	public static final String SESSION_TIME_FRAME = "time_frame";		// NO I18N
	
	public static final String SESSION_TIMELINE_MAP = "timeline_map";		// NO I18N
	
	public static final String SESSION_USER_EVENTS = "user_events";		// NO I18N

	public static final String SESSION_PAGE_NAVIGATION = "page_navigation";		// NO I18N
	
	public static final String PAGE_DFS_FILE_PATH = "page_dfs_file_path"; //NO I18N
	
	public static final String PAGE_RESOURCE_DFS_FILE_PATH = "page_resource_dfs_file_path"; //NO I18N
	
	public static final String PAGE_RESOURCE_KEY = "page_resource_key"; //NO I18N
	
	public static final String PAGE_RESOURCE_URL = "zpage_resource_url"; //NO I18N
	
	public static final String PAGE_RESOURCE_BLOCKID = "zpage_resource_blockid"; //NO I18N
	
	public static final String PAGE_RESOURCE_CONTENT_TYPE = "zpage_resource_content_type"; //NO I18N
	
	public static final String PAGE_RESOURCE_STATUS = "zpage_resource_status"; //NO I18N
	
	public static final int MAX_WINDOW_SIZE = 10000;
	
	public static final String CAMPAIGN_NAME = "campaignname"; // NO I18N
	
	public static final String ADGROUP_NAME = "adgroupname"; // NO I18N
	
	
	/**
	 * Params
	 * values - Array of values
	 * field - Name of the field
	 * timezone - timezone of current user
	 */
	public static final String FILTER_DAY_OF_WEEK_SCRIPT = "return params.values.contains(LocalDateTime.ofInstant(Instant.ofEpochMilli(doc[params.field].value), TimeZone.getTimeZone(params.timezone).toZoneId()).getDayOfWeek().toString())"; //NO I18N
	public static final String FILTER_HOUR_OF_DAY_SCRIPT = "return params.values.contains(LocalDateTime.ofInstant(Instant.ofEpochMilli(doc[params.field].value), TimeZone.getTimeZone(params.timezone).toZoneId()).getHour().toString())"; //NO I18N
	
	public enum VisitorRawDataType
	{
		PORTAL("portal","string",false), // NO I18N
		ZSOID("zsoid","long",false), // NO I18N
		EXPERIMENTID("experimentid","long",false), // NO I18N
		VARIATIONID("variationid","long",false), // NO I18N
		HEATMAP_ENABLED("heatmap_enabled","boolean",false), // NO I18N
		BROWSER("browser","string",false), // NO I18N
		DEVICE("device","string",false), // NO I18N
		COUNTRY("country","string",false), // NO I18N
		CITY("city","string",false), // NO I18N
		REGION("region","string",false), // NO I18N
		LANGUAGE("language","string",false), // NO I18N
		OS("os","string",false), // NO I18N
		TRAFFICSOURCE("trafficsource","string",false), // NO I18N
		REFFERERURL("reffererurl","string",false), // NO I18N
		DAYOFWEEK("dayofweek","byte",false), // NO I18N
		HOUROFDAY("hourofday","byte",false), // NO I18N
		CURRENTURL("currenturl","string",false), // NO I18N
		USERTYPE("usertype","string",false), // NO I18N
		//COOKIE("cookie","object",false), // NO I18N
		//URLPARAMETER("urlparameter","object",false), // NO I18N
		//JSVARIABLE("jsvariable","object",false), // NO I18N
		//CUSTOMDIMENSION("customdimension","object",false), // NO I18N
		NCOOKIE("ncookie","nested",false), // NO I18N
		NURLPARAMETER("nurlparameter","nested",false), // NO I18N
		NJSVARIABLE("njsvariable","nested",false), // NO I18N
		NCUSTOMDIMENSION("ncustomdimension","nested",false), // NO I18N
		VISITORID("visitorid","long",false), // NO I18N
		UUID("uuid","string",false), // NO I18N
		UVID("uvid","string",false), // NO I18N
		TIME_SPENT("time_spent","long",false), // NO I18N
		GOALID("goalid","long",false), // NO I18N
		PROJECTID("projectid","long",false),// NO I18N
		IS_PROJECT_GOAL("is_project_goal","boolean",false),// NO I18N
		TIME("time","date",false); // NO I18N
		
		
		private String fieldName;
		private String fieldType;
		private boolean isAnalyzed;
		
		public boolean isAnalyzed() {
			return isAnalyzed;
		}
		public void setAnalyzed(boolean isAnalyzed) {
			this.isAnalyzed = isAnalyzed;
		}
		public String getFieldName() {
			return fieldName;
		}
		public void setFieldName(String fieldName) {
			this.fieldName = fieldName;
		}
		public String getFieldType() {
			return fieldType;
		}
		public void setFieldType(String fieldType) {
			this.fieldType = fieldType;
		}
		
		private VisitorRawDataType(String fieldName,String fieldType,boolean isAnalyzed)
		{
			this.fieldName = fieldName;
			this.fieldType = fieldType;
			this.isAnalyzed = isAnalyzed;
		}
	}
	
	public static class ElasticJSONColumn {
		
		private final String columnName;
		
		private final String type;
		
		private final Boolean isAnaylsed;
		
		private final Boolean isEnabled;
		
		public String getColumnName() {
			return columnName;
		}

		public String getType() {
			return type;
		}

		public Boolean getIsAnaylsed() {
			return isAnaylsed;
		}
		
		public Boolean getIsEnabled() {
			return isEnabled;
		}

		/**
		 * @param columnName
		 * @param type
		 * @param isAnaylsed
		 */
		public ElasticJSONColumn(String columnName, String type, Boolean isAnaylsed) {
			this.columnName = columnName;
			this.type = type;
			this.isAnaylsed = isAnaylsed;
			this.isEnabled = Boolean.TRUE;
		}
		
		/**
		 * @param columnName
		 * @param isEnabled
		 */
		public ElasticJSONColumn(String columnName, Boolean isEnabled) {
			this.columnName = columnName;
			this.type = null;
			this.isAnaylsed = null;
			this.isEnabled = isEnabled;
		}
	}
	
	/**
	 * Doc structure:
	 * 
	 * {
		   "portal":"test",
		   "experimentid": "experimentId",
		   "experimentKey": "experimentKey",
		   "steps_visited":[],
		   "first_visit_time": 122122,
		   "browser":"Chrome",
		   "device": "Laptop",
		   "country": "India",
		   "language": "Tamil",
		   "os": "MacOS",
		   "trafficsource": "Social",
		   "reffererurl": "https://www.google.com",
		   "dayofweek": 1,
		   "hourofday": 2,
		   "cookie": {},
		   "urlparameter": {},
		   "jsvariable": {},
		   "customdimension": {},
		   "session_id": "asasa12addsad",
		   "steps":[
		   		{ 
		   		 "stepid": "stepId",
		   		 "stepkey": "stepKey",
		   		 "time": 12121221
		   		 }
		   ]
		 }
	 *
	 */
	public static class FunnelRawDataType {
		
		private final String columnName;
		
		private final String type;
		
		private final Boolean isAnaylsed;
		
		public String getColumnName() {
			return columnName;
		}

		public String getType() {
			return type;
		}

		public Boolean getIsAnaylsed() {
			return isAnaylsed;
		}

		public static final ArrayList<FunnelRawDataType> FIELDS_META;
		static {
			ArrayList<FunnelRawDataType> funnelRawDataTypes = new ArrayList<FunnelRawDataType>();
			funnelRawDataTypes.add(new FunnelRawDataType(PORTAL, "string", false)); //NO I18N
			funnelRawDataTypes.add(new FunnelRawDataType(ZSOID, "long", false)); //NO I18N
			funnelRawDataTypes.add(new FunnelRawDataType(EXPERIMENTID, "long", false)); //NO I18N
			funnelRawDataTypes.add(new FunnelRawDataType(EXPERIMENTKEY, "string", false)); //NO I18N
			funnelRawDataTypes.add(new FunnelRawDataType(FIRST_VISIT_TIME, "long", false)); //NO I18N
			funnelRawDataTypes.add(new FunnelRawDataType(BROWSER, "string", false)); //NO I18N
			funnelRawDataTypes.add(new FunnelRawDataType(DEVICE, "string", false)); //NO I18N
			funnelRawDataTypes.add(new FunnelRawDataType(COUNTRY, "string", false)); //NO I18N
			funnelRawDataTypes.add(new FunnelRawDataType(CITY, "string", false)); //NO I18N
			funnelRawDataTypes.add(new FunnelRawDataType(REGION, "string", false)); //NO I18N
			funnelRawDataTypes.add(new FunnelRawDataType(LANGUAGE, "string", false)); //NO I18N
			funnelRawDataTypes.add(new FunnelRawDataType(OS, "string", false)); //NO I18N
			funnelRawDataTypes.add(new FunnelRawDataType(DAYOFWEEK, "byte", false)); //NO I18N
			funnelRawDataTypes.add(new FunnelRawDataType(HOUROFDAY, "byte", false)); //NO I18N
			funnelRawDataTypes.add(new FunnelRawDataType(SESSION_ID, "string", false)); //NO I18N
			FIELDS_META = funnelRawDataTypes;
		}
		
		FunnelRawDataType(String columnName, String type, Boolean isAnaylsed) {
			this.columnName = columnName;
			this.type = type;
			this.isAnaylsed = isAnaylsed;
		}
		
		public static class FunnelStep {
			public static final ArrayList<FunnelRawDataType> FIELDS_META;
			static {
				ArrayList<FunnelRawDataType> funnelRawDataTypes = new ArrayList<FunnelRawDataType>();
				funnelRawDataTypes.add(new FunnelRawDataType(TRAFFICSOURCE, "string", false)); //NO I18N
				funnelRawDataTypes.add(new FunnelRawDataType(FUSERTYPE, "string", false)); //NO I18N
				funnelRawDataTypes.add(new FunnelRawDataType(NJSVARIABLE, "nested", false)); //NO I18N
				funnelRawDataTypes.add(new FunnelRawDataType(NCUSTOMDIMENSION, "nested", false)); //NO I18N
				funnelRawDataTypes.add(new FunnelRawDataType(NURLPARAMETER, "nested", false)); //NO I18N
				funnelRawDataTypes.add(new FunnelRawDataType(NCOOKIE, "nested", false)); //NO I18N
				funnelRawDataTypes.add(new FunnelRawDataType(REFFERERURL, "string", false)); //NO I18N
				funnelRawDataTypes.add(new FunnelRawDataType(CURRENTURL, "string", false)); //NO I18N
				funnelRawDataTypes.add(new FunnelRawDataType(STEPID, "long", false)); //NO I18N
				funnelRawDataTypes.add(new FunnelRawDataType(STEPKEY, "string", false)); //NO I18N
				funnelRawDataTypes.add(new FunnelRawDataType(TIME, "date", false)); //NO I18N
				FIELDS_META = funnelRawDataTypes;
			}
		}
		
	}
	
	public enum GaolRawDataType
	{
		PORTAL("portal","string",false), // NO I18N
		ZSOID("zsoid","long",false), // NO I18N
		EXPERIMENTID("experimentid","long",false), // NO I18N
		VARIATIONID("variationid","long",false), // NO I18N
		GOALID("goalid","long",false), // NO I18N
		BROWSER("browser","string",false), // NO I18N
		DEVICE("device","string",false), // NO I18N
		COUNTRY("country","string",false), // NO I18N
		CITY("city","string",false), // NO I18N
		REGION("region","string",false), // NO I18N
		LANGUAGE("language","string",false), // NO I18N
		OS("os","string",false), // NO I18N
		TRAFFICSOURCE("trafficsource","string",false), // NO I18N
		REFFERERURL("reffererurl","string",false), // NO I18N
		DAYOFWEEK("dayofweek","byte",false), // NO I18N
		HOUROFDAY("hourofday","byte",false), // NO I18N
		CURRENTURL("currenturl","string",false), // NO I18N
		USERTYPE("usertype","string",false), // NO I18N
		//COOKIE("cookie","object",false), // NO I18N
		//URLPARAMETER("urlparameter","object",false), // NO I18N
		//JSVARIABLE("jsvariable","object",false), // NO I18N
		//CUSTOMDIMENSION("customdimension","object",false), // NO I18N
		NCOOKIE("ncookie","nested",false), // NO I18N
		NURLPARAMETER("nurlparameter","nested",false), // NO I18N
		NJSVARIABLE("njsvariable","nested",false), // NO I18N
		NCUSTOMDIMENSION("ncustomdimension","nested",false), // NO I18N
		VISITORID("visitorid","long",false), // NO I18N
		UUID("uuid","string",false), // NO I18N
		UVID("uvid","string",false), // NO I18N
		UAID("uaid","string",false), // NO I18N
		TIME("time","date",false), // NO I18N
		TIME_SPENT("time_spent","long",false), // NO I18N
		PROJECTID("projectid","long",false),// NO I18N
		IS_PROJECT_GOAL("is_project_goal","boolean",false),// NO I18N
		REVENUE("revenue","long",false); // NO I18N
		
		
		private String fieldName;
		private String fieldType;
		private boolean isAnalyzed;
		
		public boolean isAnalyzed() {
			return isAnalyzed;
		}
		public void setAnalyzed(boolean isAnalyzed) {
			this.isAnalyzed = isAnalyzed;
		}
		public String getFieldName() {
			return fieldName;
		}
		public void setFieldName(String fieldName) {
			this.fieldName = fieldName;
		}
		public String getFieldType() {
			return fieldType;
		}
		public void setFieldType(String fieldType) {
			this.fieldType = fieldType;
		}
		
		private GaolRawDataType(String fieldName,String fieldType,boolean isAnalyzed)
		{
			this.fieldName = fieldName;
			this.fieldType = fieldType;
			this.isAnalyzed = isAnalyzed;
		}
	}
	
	public enum HeatmapRawDataType
	{
		PORTAL("portal","string",false), // NO I18N
		ZSOID("zsoid","long",false), // NO I18N
		EXPERIMENTID("experimentid","long",false), // NO I18N
		VARIATIONID("variationid","long",false), // NO I18N
		SELECTOR("selector","string",false), // NO I18N
		DISPLAY_TEXT("display_text","string",false), // NO I18N
		POINT_X("point_x","integer",false), // NO I18N
		POINT_Y("point_y","integer",false), // NO I18N
		CLICKS("clicks","integer",false), // NO I18N
		DEVICE("device","string",false), // NO I18N
		BROWSER("browser","string",false), // NO I18N
		COUNTRY("country","string",false), // NO I18N
		CITY("city","string",false), // NO I18N
		REGION("region","string",false), // NO I18N
		LANGUAGE("language","string",false), // NO I18N
		OS("os","string",false), // NO I18N
		TRAFFICSOURCE("trafficsource","string",false), // NO I18N
		REFFERERURL("reffererurl","string",false), // NO I18N
		USERTYPE("usertype","string",false), // NO I18N
		DAYOFWEEK("dayofweek","byte",false), // NO I18N
		HOUROFDAY("hourofday","byte",false), // NO I18N
		CURRENTURL("currenturl","string",false), // NO I18N
		VISITORID("visitorid","long",false), // NO I18N
		UUID("uuid","string",false), // NO I18N
		UVID("uvid","string",false), // NO I18N
		//COOKIE("cookie","object",false), // NO I18N
		//URLPARAMETER("urlparameter","object",false), // NO I18N
		NCOOKIE("ncookie","nested",false), // NO I18N
		NURLPARAMETER("nurlparameter","nested",false), // NO I18N
		NJSVARIABLE("njsvariable","nested",false), // NO I18N
		NCUSTOMDIMENSION("ncustomdimension","nested",false), // NO I18N
		//JSVARIABLE("jsvariable","object",false), // NO I18N
		//CUSTOMDIMENSION("customdimension","object",false), // NO I18N
		TIME("time","date",false); // NO I18N
		
		
		private String fieldName;
		private String fieldType;
		private Boolean isAnalyzed;
		
		public String getFieldName() {
			return fieldName;
		}
		public void setFieldName(String fieldName) {
			this.fieldName = fieldName;
		}
		public String getFieldType() {
			return fieldType;
		}
		public void setFieldType(String fieldType) {
			this.fieldType = fieldType;
		}
		
		public Boolean getIsAnalyzed() {
			return isAnalyzed;
		}
		public void setIsAnalyzed(Boolean isAnalyzed) {
			this.isAnalyzed = isAnalyzed;
		}
		
		private HeatmapRawDataType(String fieldName,String fieldType,Boolean isAnalyzed)
		{
			this.fieldName = fieldName;
			this.fieldType = fieldType;
			this.isAnalyzed = isAnalyzed;
		}
	}
	
	public enum ScrollmapRawDataType
	{
		PORTAL("portal","string",false), // NO I18N
		ZSOID("zsoid","long",false), // NO I18N
		EXPERIMENTID("experimentid","long",false), // NO I18N
		VARIATIONID("variationid","long",false), // NO I18N
		SCROLL_Y1("scroll_y1","integer",false), // NO I18N
		SCROLL_Y2("scroll_y2","integer",false), // NO I18N
		HEIGHT("height","integer",false), // NO I18N
		DEVICE("device","string",false), // NO I18N
		BROWSER("browser","string",false), // NO I18N
		COUNTRY("country","string",false), // NO I18N
		CITY("city","string",false), // NO I18N
		REGION("region","string",false), // NO I18N
		LANGUAGE("language","string",false), // NO I18N
		OS("os","string",false), // NO I18N
		TRAFFICSOURCE("trafficsource","string",false), // NO I18N
		REFFERERURL("reffererurl","string",false), // NO I18N
		USERTYPE("usertype","string",false), // NO I18N
		DAYOFWEEK("dayofweek","byte",false), // NO I18N
		HOUROFDAY("hourofday","byte",false), // NO I18N
		CURRENTURL("currenturl","string",false), // NO I18N
		VISITORID("visitorid","long",false), // NO I18N
		UUID("uuid","string",false), // NO I18N
		UVID("uvid","string",false), // NO I18N
		TIME("time","date",false), // NO I18N
		//COOKIE("cookie","object",false), // NO I18N
		//URLPARAMETER("urlparameter","object",false), // NO I18N
		//JSVARIABLE("jsvariable","object",false), // NO I18N
		//CUSTOMDIMENSION("customdimension","object",false), // NO I18N
		NCOOKIE("ncookie","nested",false), // NO I18N
		NURLPARAMETER("nurlparameter","nested",false), // NO I18N
		NJSVARIABLE("njsvariable","nested",false), // NO I18N
		NCUSTOMDIMENSION("ncustomdimension","nested",false), // NO I18N
		SCROLL_LIST("scroll_list","text",false), // NO I18N
		TIME_SPENT("time_spent","long",false); // NO I18N
		
		
		private String fieldName;
		private String fieldType;
		private Boolean isAnalyzed;
		
		public String getFieldName() {
			return fieldName;
		}
		public void setFieldName(String fieldName) {
			this.fieldName = fieldName;
		}
		public String getFieldType() {
			return fieldType;
		}
		public void setFieldType(String fieldType) {
			this.fieldType = fieldType;
		}
		
		public Boolean getIsAnalyzed() {
			return isAnalyzed;
		}
		public void setIsAnalyzed(Boolean isAnalyzed) {
			this.isAnalyzed = isAnalyzed;
		}
		
		private ScrollmapRawDataType(String fieldName,String fieldType,Boolean isAnalyzed)
		{
			this.fieldName = fieldName;
			this.fieldType = fieldType;
			this.isAnalyzed = isAnalyzed;
		}
	}
	
	

	public enum FormRawDataType
	{
		PORTAL("portal","string",false), // NO I18N
		ZSOID("zsoid","long",false), //No I18N
		EXPERIMENTID("experimentid","long",false), // NO I18N
		FORMSTARTER("form_starter","integer",false), //No I18N
		FORMCONVERSION("form_conversion","integer",false), //No I18N
		FORMSUBMISSION("form_submission","integer",false), //No I18N
		LASTACTIVEFIELD("last_active","string",false), //No I18N
		FORMLIVE("form_live","integer",false), //No I18N
		FORMSPENTTIME("form_spent_time","long",false), //No I18N
		TIME("time","date",false), // NO I18N
		DEVICE("device","string",false), // NO I18N
		BROWSER("browser","string",false), // NO I18N
		COUNTRY("country","string",false), // NO I18N
		CITY("city","string",false), // NO I18N
		REGION("region","string",false), // NO I18N
		LANGUAGE("language","string",false), // NO I18N
		OS("os","string",false), // NO I18N
		TRAFFICSOURCE("trafficsource","string",false), // NO I18N
		REFFERERURL("reffererurl","string",false), // NO I18N
		DAYOFWEEK("dayofweek","byte",false), // NO I18N
		HOUROFDAY("hourofday","byte",false), // NO I18N
		CURRENTURL("currenturl","string",false), // NO I18N
		USERTYPE("usertype","string",false), // NO I18N
		UUID("uuid","string",false), // NO I18N
		UVID("uvid","string",false), // NO I18N
		NCOOKIE("ncookie","nested",false), // NO I18N
		NURLPARAMETER("nurlparameter","nested",false), // NO I18N
		NJSVARIABLE("njsvariable","nested",false), // NO I18N
		NCUSTOMDIMENSION("ncustomdimension","nested",false); // NO I18N
		
		
		private String fieldName;
		private String fieldType;
		private Boolean isAnalyzed;
		
		public String getFieldName() {
			return fieldName;
		}
		public void setFieldName(String fieldName) {
			this.fieldName = fieldName;
		}
		public String getFieldType() {
			return fieldType;
		}
		public void setFieldType(String fieldType) {
			this.fieldType = fieldType;
		}
		
		public Boolean getIsAnalyzed() {
			return isAnalyzed;
		}
		public void setIsAnalyzed(Boolean isAnalyzed) {
			this.isAnalyzed = isAnalyzed;
		}
		
		private FormRawDataType(String fieldName,String fieldType,Boolean isAnalyzed)
		{
			this.fieldName = fieldName;
			this.fieldType = fieldType;
			this.isAnalyzed = isAnalyzed;
		}
	}
	
	public enum FormFieldRawDataType
	{
		PORTAL("portal","string",false), // NO I18N
		ZSOID("zsoid","long",false), //No I18N
		EXPERIMENTID("experimentid","long",false), // NO I18N
		FORMFIELDID("form_field_id","long",false), //No I18N
		FORMFIELDVISIT("form_field_visit","integer",false), //No I18N
		FORMFIELDSTARTER("form_field_starter","integer",false), //No I18N
		FORMFIELDREFOCUS("form_field_refocus","integer",false), //No I18N
		FORMFIELDCORRECTION("form_field_correction","integer",false), //No I18N
		//FORMFIELDDROPOFF("form_field_dropoff","integer",false), //No I18N
		FORMFIELDBLANKRATE("form_field_blankrate","integer",false), //No I18N
		FILLEDRATE("filled_rate","integer",false), // NO I18N
		FORMFIELDCOMPLETIONTIME("form_field_completion_time","long",false),  // NO I18N
		FORMFIELDHESITATIONTIME("form_field_hesitation_time","long",false),  // NO I18N
		TIME("time","date",false),   // NO I18N
		DEVICE("device","string",false), // NO I18N
		BROWSER("browser","string",false), // NO I18N
		COUNTRY("country","string",false), // NO I18N
		CITY("city","string",false), // NO I18N
		REGION("region","string",false), // NO I18N
		LANGUAGE("language","string",false), // NO I18N
		OS("os","string",false), // NO I18N
		TRAFFICSOURCE("trafficsource","string",false), // NO I18N
		REFFERERURL("reffererurl","string",false), // NO I18N
		DAYOFWEEK("dayofweek","byte",false), // NO I18N
		HOUROFDAY("hourofday","byte",false), // NO I18N
		CURRENTURL("currenturl","string",false), // NO I18N
		USERTYPE("usertype","string",false), // NO I18N   
		UUID("uuid","string",false), // NO I18N            
		UVID("uvid","string",false), // NO I18N
		NCOOKIE("ncookie","nested",false), // NO I18N
		NURLPARAMETER("nurlparameter","nested",false), // NO I18N
		NJSVARIABLE("njsvariable","nested",false), // NO I18N
		NCUSTOMDIMENSION("ncustomdimension","nested",false); // NO I18N
		//uuid for unique id
		//uvid for visit id for that session
		private String fieldName;
		private String fieldType;
		private Boolean isAnalyzed;
		
		public String getFieldName() {
			return fieldName;
		}
		public void setFieldName(String fieldName) {
			this.fieldName = fieldName;
		}
		public String getFieldType() {
			return fieldType;
		}
		public void setFieldType(String fieldType) {
			this.fieldType = fieldType;
		}
		
		public Boolean getIsAnalyzed() {
			return isAnalyzed;
		}
		public void setIsAnalyzed(Boolean isAnalyzed) {
			this.isAnalyzed = isAnalyzed;
		}
		
		private FormFieldRawDataType(String fieldName,String fieldType,Boolean isAnalyzed)
		{
			this.fieldName = fieldName;
			this.fieldType = fieldType;
			this.isAnalyzed = isAnalyzed;
		}
	}
	public enum AdwordsRawDataType
	{
		GCLID("gclid","string",false), // NO I18N
		CAMPAIGNNAME("campaignname","string",false), // NO I18N
		ADGROUPNAME("adgroupname","string",false), // NO I18N
		PORTAL("portal","string",false), // NO I18N
		ZSOID("zsoid","long",false), //No I18N
		PROJECTID("projectid","long",false), // NO I18N
		TIME("time","date",false);   // NO I18N

		private String fieldName;
		private String fieldType;
		private Boolean isAnalyzed;
		
		public String getFieldName() {
			return fieldName;
		}
		public void setFieldName(String fieldName) {
			this.fieldName = fieldName;
		}
		public String getFieldType() {
			return fieldType;
		}
		public void setFieldType(String fieldType) {
			this.fieldType = fieldType;
		}
		
		public Boolean getIsAnalyzed() {
			return isAnalyzed;
		}
		public void setIsAnalyzed(Boolean isAnalyzed) {
			this.isAnalyzed = isAnalyzed;
		}
		
		private AdwordsRawDataType(String fieldName,String fieldType,Boolean isAnalyzed)
		{
			this.fieldName = fieldName;
			this.fieldType = fieldType;
			this.isAnalyzed = isAnalyzed;
		}
	}
	
//	public enum IdentityRawDataType
//	{
//		UUID("uuid","string",false), // NO I18N
//		IDENTITYDETAILS("identity_details","string",false), // NO I18N
//		PORTAL("portal","string",false), // NO I18N
//		ZSOID("zsoid","long",false), // NO I18N
//		PROJECTID("projectid","long",false),// NO I18N
//		TIME("time","date",false);   // NO I18N
//
//		private String fieldName;
//		private String fieldType;
//		private Boolean isAnalyzed;
//		
//		public String getFieldName() {
//			return fieldName;
//		}
//		public void setFieldName(String fieldName) {
//			this.fieldName = fieldName;
//		}
//		public String getFieldType() {
//			return fieldType;
//		}
//		public void setFieldType(String fieldType) {
//			this.fieldType = fieldType;
//		}
//		
//		public Boolean getIsAnalyzed() {
//			return isAnalyzed;
//		}
//		public void setIsAnalyzed(Boolean isAnalyzed) {
//			this.isAnalyzed = isAnalyzed;
//		}
//		
//		private IdentityRawDataType(String fieldName,String fieldType,Boolean isAnalyzed)
//		{
//			this.fieldName = fieldName;
//			this.fieldType = fieldType;
//			this.isAnalyzed = isAnalyzed;
//		}
//	}
	
}
