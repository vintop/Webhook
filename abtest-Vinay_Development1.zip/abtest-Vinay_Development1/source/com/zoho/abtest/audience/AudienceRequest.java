//$Id$
package com.zoho.abtest.audience;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;

import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABRequest;
import com.zoho.abtest.audience.AudienceConstants;

public class AudienceRequest extends ZABRequest{

	@Override
	public void updateFromRequest(HashMap<String, String> map,
			HttpServletRequest request) {
		String linkName = (String)request.getAttribute(ZABConstants.LINKNAME);
		if(linkName!=null) {			
			map.put(AudienceConstants.AUDIENCE_LINKNAME, linkName);
		}
	}

	@Override
	public void specificValidation(HashMap<String, String> map,
			HttpServletRequest request) throws IOException, JSONException {

		String httpMethod = ZABAction.getHTTPMethod(request).toString();

		if(httpMethod.equalsIgnoreCase("POST")){
			ArrayList<String> fields = new ArrayList<String>();
			//					if(!map.containsKey(AudienceConstants.AUDIENCE_NAME)) {
			if (!map.containsKey(AudienceConstants.AUDIENCE_NAME)
					|| map.get(AudienceConstants.AUDIENCE_NAME) == null
					|| map.get(AudienceConstants.AUDIENCE_NAME).isEmpty()) {
				fields.add(AudienceConstants.AUDIENCE_NAME);
				ZABRequest.updateError(map, ZABAction.getAppropriateMessage(ZABConstants.ErrorMessages.MANDATORY_FIELD_MISSING.getErrorString(),fields));

			}


			//					}

		}


		if(httpMethod.equalsIgnoreCase("PUT")){
			ArrayList<String> fields = new ArrayList<String>();
			if(!map.containsKey(AudienceConstants.AUDIENCE_LINKNAME)){
				fields.add(AudienceConstants.AUDIENCE_LINKNAME);
			}

			if(map.containsKey(AudienceConstants.AUDIENCE_NAME) && map.get(AudienceConstants.AUDIENCE_NAME).isEmpty()){
				fields.add(AudienceConstants.AUDIENCE_NAME);
			}

			if(!fields.isEmpty()) {
				ZABRequest.updateError(map, ZABAction.getAppropriateMessage(ZABConstants.ErrorMessages.MANDATORY_FIELD_MISSING.getErrorString(),fields));
				return;
			}


		}
	}

}