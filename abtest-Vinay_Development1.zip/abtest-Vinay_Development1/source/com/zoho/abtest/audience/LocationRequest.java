//$Id$
package com.zoho.abtest.audience;

public class LocationRequest {

}
