//$Id$
package com.zoho.abtest.audience;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.json.JSONException;

import com.adventnet.iam.IAMUtil;
import com.opensymphony.xwork2.ActionSupport;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.project.ProjectTreeEventListener;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.mqueue.consumer.MessageConsumer;
import com.zoho.mqueue.producer.MessageProducer;
import com.zoho.mqueue.producer.ProducerRecord;

public class AudienceAttributeAction extends ActionSupport implements ServletResponseAware, ServletRequestAware{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private HttpServletRequest request;
	
	private HttpServletResponse response;
	
	private Integer audienceAttrId;
	
	public Integer getAudienceAttrId() {
		return audienceAttrId;
	}

	public void setAudienceAttrId(Integer audienceAttrId) {
		this.audienceAttrId = audienceAttrId;
	}

	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		request = arg0;
	}

	@Override
	public void setServletResponse(HttpServletResponse arg0) {
		response = arg0;
	}
	
	public String execute() throws IOException,JSONException {
		ArrayList<AudienceAttribute> attributes = new ArrayList<AudienceAttribute>();

		try {		
			switch(ZABAction.getHTTPMethod(request)) {
			case GET:
				if(audienceAttrId!=null) {
					attributes.add(AudienceAttribute.getAudienceAttributeDetails(audienceAttrId));
				}
				else
				{
					attributes.addAll(AudienceAttribute.getAudienceAttributes(request));
				}
				break;
			}
		}	
		catch(Exception ex){
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), AudienceAttributeConstants.API_MODULE));
			return null; 	
		}		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getAudienceAttributeResponse(request, attributes));		
	    return null;
	}
}
