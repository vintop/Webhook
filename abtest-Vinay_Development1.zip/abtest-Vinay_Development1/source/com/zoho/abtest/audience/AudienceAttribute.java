//$Id$
package com.zoho.abtest.audience;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.AUDIENCE_ATTRIBUTE;
import com.zoho.abtest.EXPERIMENT_PROJECT_INTEGRATION;
import com.zoho.abtest.PROJECT_INTEGRATION;
import com.zoho.abtest.audience.AudienceAttributeConstants.AudienceAttributes;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.dimension.DimensionConstants;
import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentType;
import com.zoho.abtest.utility.ZABUtil;

public class AudienceAttribute extends ZABModel{
	
	/**
	 * 
	 */
	
	private static final Logger LOGGER = Logger.getLogger(AudienceAttribute.class.getName());
	
	private static final long serialVersionUID = 1L;

	private Integer attributeId;
	
	private String attributeDisplayName;
	
	private String attributeKeyName;
	
	private String attributedescription;
	
	private AudienceMatchType matchTypeDetails;
	
	private Boolean isDynamicAttribute;
	
	private Integer ordinal;
	
	public Boolean getIsDynamicAttribute() {
		return isDynamicAttribute;
	}

	public void setIsDynamicAttribute(Boolean isDynamicAttribute) {
		this.isDynamicAttribute = isDynamicAttribute;
	}

	public AudienceMatchType getMatchTypeDetails() {
		return matchTypeDetails;
	}

	public void setMatchTypeDetails(AudienceMatchType matchTypeDetails) {
		this.matchTypeDetails = matchTypeDetails;
	}

	public Integer getAttributeId() {
		return attributeId;
	}

	public void setAttributeId(Integer attributeId) {
		this.attributeId = attributeId;
	}

	public String getAttributeDisplayName() {
		return attributeDisplayName;
	}

	public void setAttributeDisplayName(String attributeDisplayName) {
		this.attributeDisplayName = attributeDisplayName;
	}

	public String getAttributeKeyName() {
		return attributeKeyName;
	}

	public void setAttributeKeyName(String attributeKeyName) {
		this.attributeKeyName = attributeKeyName;
	}
	
	public String getAttributeDescription() {
		return attributedescription;
	}

	public void setAttributeDescription(String attributedescription) {
		this.attributedescription = attributedescription;
	}
	public Integer getOrdinal() {
		return ordinal;
	}

	public void setOrdinal(Integer ordinal) {
		this.ordinal = ordinal;
	}
	
	static final Comparator<AudienceAttribute> ORDINAL_ORDER = 
			new Comparator<AudienceAttribute>() {
		public int compare(AudienceAttribute e1, AudienceAttribute e2) {
			return e1.getOrdinal() - e2.getOrdinal();
		}
	};

	
	private static Criteria getFilterCriteriaForExperimentType(String experimentType) {
		Criteria c = null;
		try {
			Integer experimentTypeId = Integer.parseInt(experimentType);
			ExperimentType type = ExperimentType.getExperimentTypeByNumber(experimentTypeId);
			ArrayList<Integer> chuckOutList = new ArrayList<Integer>();
			//chuckOutList.add(AudienceAttributes.AD_CAMPAIGN.getAudienceAttrId());
			chuckOutList.add(AudienceAttributes.ADWORDS_CAMPAIGN.getAudienceAttrId());
			chuckOutList.add(AudienceAttributes.ADWORDS_GROUP.getAudienceAttrId());
			chuckOutList.add(AudienceAttributes.JS_VARIABLE.getAudienceAttrId());

			switch(type) {
				 case ABTEST:
				 case SPLITURL:
				 case FUNNEL:
					 chuckOutList.add(AudienceAttributes.GOALS.getAudienceAttrId());
					 break;
				 case HEATMAP:
				 case ENABLED_HEATMAP:
					 chuckOutList.add(AudienceAttributes.GOALS.getAudienceAttrId());
					 chuckOutList.add(AudienceAttributes.MOBILE_OS.getAudienceAttrId());
					 chuckOutList.add(AudienceAttributes.DEVICE.getAudienceAttrId());
					 chuckOutList.add(AudienceAttributes.CURRENT_URL.getAudienceAttrId());
					 break;
				 case SESSION_RECORDING:
					 break;
			}
			c = new Criteria(new Column(AUDIENCE_ATTRIBUTE.TABLE, AUDIENCE_ATTRIBUTE.ATTRIBUTE_ID), chuckOutList.toArray(new Integer[chuckOutList.size()]), QueryConstants.NOT_IN);
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Exception occured:", e);
		}
		return c;
	}
	

	public static ArrayList<AudienceAttribute> getAudienceAttributes(HttpServletRequest request) {
		Boolean adwordsintegration=false;
		ArrayList<AudienceAttribute> attributes = new ArrayList<AudienceAttribute>();
		ArrayList<AudienceAttribute> attributes1=new ArrayList<AudienceAttribute>();
		String experimentlinkname = request.getParameter("experiment_link_name");
		if(experimentlinkname != null){
			Long experimentId = Experiment.getExperimentId(experimentlinkname);
			Join join1=new Join(EXPERIMENT_PROJECT_INTEGRATION.TABLE,PROJECT_INTEGRATION.TABLE,new String[]{EXPERIMENT_PROJECT_INTEGRATION.PROJECT_INTEGRATION_ID},new String[]{PROJECT_INTEGRATION.PROJECT_INTEGRATION_ID},Join.INNER_JOIN);
			Criteria c=new Criteria(new Column(EXPERIMENT_PROJECT_INTEGRATION.TABLE,EXPERIMENT_PROJECT_INTEGRATION.EXPERIMENT_ID),experimentId,QueryConstants.EQUAL);

			try
			{
				DataObject dobj1 = getRow(EXPERIMENT_PROJECT_INTEGRATION.TABLE, c,new Join[]{join1});
				Iterator<?> it = dobj1.getRows(PROJECT_INTEGRATION.TABLE);
				while(it.hasNext())
				{	
					Row row1 = (Row)it.next();
					int integrationid=(int)row1.get(PROJECT_INTEGRATION.INTEGRATION_ID);
					if(integrationid==4)
					{
						adwordsintegration=true;
					}
				}
			}catch(Exception e)
			{ 			
				LOGGER.log(Level.SEVERE,"Exception Occurred",e);	
			}
		}
		
		try 
		{
			Criteria repFilterCriteria = null;
			String experimentType = request.getParameter(AudienceAttributeConstants.FOR_EXPERIMENT_REPORT);
			if(experimentType!=null){				
				repFilterCriteria = getFilterCriteriaForExperimentType(experimentType);
			} else {
				repFilterCriteria = new Criteria(new Column(AUDIENCE_ATTRIBUTE.TABLE, AUDIENCE_ATTRIBUTE.ATTRIBUTE_ID), AudienceAttributes.GOALS.getAudienceAttrId(), QueryConstants.NOT_EQUAL);
			}
			
			
//			else {
//				//CRUFT: Remove if once location is supported in audience client side.
//				//Files: AudienceAttribute.java, AudienceAttributeConstants.java, PortalAction.java
//				repFilterCriteria = new Criteria(new Column(AUDIENCE_ATTRIBUTE.TABLE, AUDIENCE_ATTRIBUTE.ATTRIBUTE_ID), AudienceAttributes.LOCATION.getAudienceAttrId(), QueryConstants.NOT_EQUAL);
//			}
			
			DataObject dobj = getRow(AUDIENCE_ATTRIBUTE.TABLE, repFilterCriteria);
			if(dobj.containsTable(AUDIENCE_ATTRIBUTE.TABLE))
			{
				Iterator<?> it = dobj.getRows(AUDIENCE_ATTRIBUTE.TABLE);
				while(it.hasNext())
				{
					Row row1 = (Row)it.next();
					Integer adwords=(Integer)row1.get(AUDIENCE_ATTRIBUTE.ATTRIBUTE_ID);
					if (adwords.equals(AudienceAttributes.ADWORDS_CAMPAIGN.getAudienceAttrId())
							|| adwords.equals(AudienceAttributes.ADWORDS_GROUP.getAudienceAttrId()))
					{   
						AudienceAttribute audience=new AudienceAttribute();
						audience=getAudienceAttributeFromRow(row1);
						attributes1.add(audience);
						attributes.add(audience);
					} else if (adwords.equals(AudienceAttributes.COOKIE_VALUE.getAudienceAttrId())
							|| adwords.equals(AudienceAttributes.USERAGENT.getAudienceAttrId())
							|| adwords.equals(AudienceAttributes.CUSTOM_DIMENSION.getAudienceAttrId())
							|| adwords.equals(18)) {
						// dp nothing
						continue;
					}
					else
					{
						attributes.add(getAudienceAttributeFromRow(row1));
					}
				}
				if(adwordsintegration==false){
					attributes.removeAll(attributes1);
				}
			}
			attributes = rearrangeAudienctAttributes(attributes);
				
			
	} catch(Exception e) {
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return attributes;
	}
	
	private static ArrayList<AudienceAttribute> rearrangeAudienctAttributes(ArrayList<AudienceAttribute> attributes) {
	  //This method is added the ensure the order mentioned in Bug #W9-526
	
		for(int i=0;i<attributes.size();i++){
			AudienceAttribute audAttr = attributes.get(i);
			Integer attrId = audAttr.getAttributeId();
			AudienceAttributes attr = AudienceAttributes.getAudienceAttributeById(attrId);
			if(attr!=null){
				audAttr.setOrdinal(attr.ordinal());
			}
		}
		Collections.sort(attributes , ORDINAL_ORDER);
		
		return attributes;
	}

	public static AudienceAttribute getAudienceAttributeDetails(Integer id) {
		AudienceAttribute audienceAttribute = null;
		Criteria c = new Criteria(new Column(AUDIENCE_ATTRIBUTE.TABLE, AUDIENCE_ATTRIBUTE.ATTRIBUTE_ID), id, QueryConstants.EQUAL);
		try {
			DataObject dobj = getRow(AUDIENCE_ATTRIBUTE.TABLE, c);
			String projectLinkname = ZABUtil.getCurrentRequest().getParameter(DimensionConstants.PROJECT_LINK_NAME);
			
			if(dobj.containsTable(AUDIENCE_ATTRIBUTE.TABLE)) {
				Iterator<?> it = dobj.getRows(AUDIENCE_ATTRIBUTE.TABLE);
				while(it.hasNext()) {
					Row row1 = (Row)it.next();
					audienceAttribute = getAudienceAttributeFromRow(row1);
					audienceAttribute.setMatchTypeDetails(AudienceMatchType.getAudienceMatchType(id, projectLinkname));
				}
			}
		}
		catch(ZABException e) {
			LOGGER.log(Level.SEVERE,"ZABException Occurred",e);
			audienceAttribute = new AudienceAttribute();
			audienceAttribute.setSuccess(Boolean.FALSE);
			audienceAttribute.setResponseString(e.getMessage());
		} catch(Exception e) {
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
			audienceAttribute = new AudienceAttribute();
			audienceAttribute.setSuccess(Boolean.FALSE);
			audienceAttribute.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
		}
		
		return audienceAttribute;
	}
	
	public static AudienceAttribute getAudienceAttributeFromRow(Row row) throws JSONException {
		
		AudienceAttribute audienceattribute = new AudienceAttribute();
		audienceattribute.setAttributeId((Integer)row.get(AUDIENCE_ATTRIBUTE.ATTRIBUTE_ID));
		
		AudienceAttributes attr = AudienceAttributes.getAudienceAttributeById(audienceattribute.getAttributeId());
		if(attr!=null) {
			audienceattribute.setAttributeDisplayName(attr.getDisplayName());			
		}
		
		audienceattribute.setAttributeKeyName((String)row.get(AUDIENCE_ATTRIBUTE.ATTRIBUTE_KEY_NAME));
		audienceattribute.setAttributeDescription((String)row.get(AUDIENCE_ATTRIBUTE.ATTRIBUTE_DESCRIPTION));
		audienceattribute.setIsDynamicAttribute((Boolean)row.get(AUDIENCE_ATTRIBUTE.IS_DYNAMIC_ATTRICUTE));
		audienceattribute.setSuccess(Boolean.TRUE);
		return audienceattribute;
		
	}
	
}