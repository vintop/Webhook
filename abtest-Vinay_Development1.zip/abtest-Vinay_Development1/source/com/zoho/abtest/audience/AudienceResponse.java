//$Id$
package com.zoho.abtest.audience;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;

public class AudienceResponse {
	private static final Logger LOGGER = Logger.getLogger(Audience.class.getName());

	public static String jsonResponse(HttpServletRequest request,ArrayList<Audience> lst) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(lst);			
			JSONObject json = ZABResponse.updateMetaInfo(request, AudienceConstants.API_MODULE, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){
			
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			
		}
		return returnBuffer.toString();
	}
	
	public static JSONArray getJSONArray(ArrayList<Audience> lst) throws JSONException {
		JSONArray array = new JSONArray();
		int size =lst.size();
		for (int i=0;i<size;i++) {
			Audience ld=lst.get(i);
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(AudienceConstants.AUDIENCE_ID, ld.getAudienceId());
			jsonObj.put(AudienceConstants.AUDIENCE_NAME, ld.getAudienceName());
			jsonObj.put(AudienceConstants.AUDIENCE_LINKNAME, ld.getAudienceLinkName());
			jsonObj.put(AudienceConstants.AUDIENCE_DESCRIPTION, ld.getAudienceDescription());
			jsonObj.put(AudienceConstants.AUDIENCE_CONDITION_JSON, ld.getAudienceConditionJSON());
			jsonObj.put(AudienceConstants.PROJECT_ID, ld.getProjectId());
			jsonObj.put(AudienceConstants.AUDIENCE_IS_SELECTED, ld.getAudienceIsSelected());
			jsonObj.put(AudienceConstants.AUDIENCE_IS_PRESET, ld.getIsPresetAudience());
			jsonObj.put(AudienceConstants.EXPERIMENT_INVOLVED, ld.getExperimentCount());
			jsonObj.put(ZABConstants.RESPONSE_STRING, ld.getResponseString());
			jsonObj.put(ZABConstants.STATUS_CODE, ld.getResponseCode());
			jsonObj.put(ZABConstants.SUCCESS, ld.getSuccess());
			array.put(jsonObj);
		}
		return array;
	}
}
