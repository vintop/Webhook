//$Id$
package com.zoho.abtest.audience;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.json.JSONException;

import com.adventnet.iam.IAMUtil;
import com.opensymphony.xwork2.ActionSupport;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.integration.IntegrationConstants;
import com.zoho.abtest.project.ProjectTreeEventListener;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.mqueue.consumer.MessageConsumer;
import com.zoho.mqueue.producer.MessageProducer;
import com.zoho.mqueue.producer.ProducerRecord;
import com.zoho.zfs.ZPFSAPI;

public class AudienceAction extends ActionSupport implements ServletResponseAware, ServletRequestAware{
	
	/**
	 * 
	 */
	private static final Logger LOGGER = Logger.getLogger(AudienceAction.class.getName());

	private static final long serialVersionUID = 1L;

	private HttpServletRequest request;
	
	private HttpServletResponse response;
	
	private String linkname;
	
	public String getLinkname() {
		return linkname;
	}

	public void setLinkname(String linkname) {
		this.linkname = linkname;
	}

	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		request = arg0;
	}

	@Override
	public void setServletResponse(HttpServletResponse arg0) {
		response = arg0;
	}
	
	public String execute() throws IOException, JSONException {
		ArrayList<Audience> audiences = new ArrayList<Audience>();
		String project_link_name = request.getParameter(AudienceConstants.PROJECT_LINK_NAME);
		String experiment_link_name = request.getParameter(AudienceConstants.EXPERIMENT_LINK_NAME);
		try {		
			switch(ZABAction.getHTTPMethod(request)) {
			case POST:	
				HashMap<String,String> hs = ZABAction.getRequestParser(request).parseAudience(request);
				if(hs.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					Audience audience = new Audience();
					audience.setSuccess(Boolean.FALSE);
					audience.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
					audiences.add(audience);
				}else{
					String dbspace = ZABUtil.getDBSpace();
					audiences.addAll(Audience.createAudience(hs));
				}
				break;
			case GET:
				if(linkname!=null) {
					audiences.add(Audience.getAudienceByLinkName(linkname,null));
				}else{ 
					audiences.addAll(Audience.getAudiences(project_link_name,experiment_link_name));
				}
				break;
			case DELETE:
				if(linkname!=null) {					
					audiences.add(Audience.deleteAudience(linkname,null));
				}
				break;
			case PUT:
				HashMap<String,String> hsPut = ZABAction.getRequestParser(request).parseAudience(request);
				if(hsPut.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hsPut.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					Audience audience = new Audience();
					audience.setSuccess(Boolean.FALSE);
					audience.setResponseString(hsPut.get(ZABConstants.RESPONSE_STRING));
					audiences.add(audience);
				}else{
					audiences.addAll(Audience.updateAudience(hsPut));
				}
				break;
			}
		}catch(JSONException ex){	

			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getInvalidInputFormatException(AudienceConstants.API_MODULE));
			return null; 	
		}
		catch(Exception ex){
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), AudienceConstants.API_MODULE));
			return null; 	
		}		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getAudienceResponse(request, audiences));		
	    return null;
	}

}
