//$Id$
package com.zoho.abtest.audience;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.json.JSONException;

import com.opensymphony.xwork2.ActionSupport;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.utility.ZABUtil;

public class ProjectAudienceAction extends ActionSupport implements ServletResponseAware, ServletRequestAware{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private HttpServletRequest request;
	
	private HttpServletResponse response;
	
	private String linkname;
	
	public String getLinkname() {
		return linkname;
	}

	public void setLinkname(String linkname) {
		this.linkname = linkname;
	}

	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		request = arg0;
	}

	@Override
	public void setServletResponse(HttpServletResponse arg0) {
		response = arg0;
	}
	
	public String execute() throws IOException, JSONException {
		ArrayList<ProjectAudience> audiences = new ArrayList<ProjectAudience>();
		try {			
			switch(ZABAction.getHTTPMethod(request)) {
			case POST:	
				HashMap<String,String> hs = ZABAction.getRequestParser(request).parseProjectAudience(request);
				if(hs.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					ProjectAudience audience = new ProjectAudience();
					audience.setSuccess(Boolean.FALSE);
					audience.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
					audiences.add(audience);
				}else{
					audiences.addAll(ProjectAudience.createProjectAudience(hs));
				}
				break;
			case GET:
				
				if(linkname!=null) {
					
					Long projectId = Project.getProjectId(linkname); 
					//audiences.add(ProjectAudience.getProjectAudienceByProjectId(projectId));
				}
				break;

				
				/*HashMap<String,String> hs1 = ZABAction.getRequestParser(request).parseExperimentAudience(request);
				String audienceId = hs1.get(ExperimentAudienceConstants.AUDIENCE_ID);
				String experimentId = hs1.get(ExperimentAudienceConstants.EXPERIMENT_ID);
				if(audienceId!=null) {
					audiences.add(ExperimentAudience.getExperimentAudienceByAudienceId(audienceId));
				}else if (experimentId!=null) {
					audiences.add(ExperimentAudience.getExperimentAudienceByExperimentId(audienceId));
				}
				break;*/
				
				
				/*case DELETE:
				if(audienceId!=null) {					
					audiences.add(Audience.deleteExperimentAudience(audienceId));
				}
				break;
			case PUT:
				HashMap<String,String> hsPut = ZABAction.getRequestParser(request).parseExperimentAudience(request);
				if(hsPut.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hsPut.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					Audience audience = new Audience();
					audience.setSuccess(Boolean.FALSE);
					audience.setResponseString(hsPut.get(ZABConstants.RESPONSE_STRING));
					audiences.add(audience);
				}else{
					audiences.add(Audience.updateAudience(hsPut));
				}
				break; */
			}
		}catch(JSONException ex){	
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getInvalidInputFormatException(AudienceConstants.API_MODULE));
			return null; 	
		}
		catch(Exception ex){
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ProjectAudienceConstants.API_MODULE));
			return null; 	
		}		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getProjectAudienceResponse(request, audiences));		
	    return null;
	}

}
