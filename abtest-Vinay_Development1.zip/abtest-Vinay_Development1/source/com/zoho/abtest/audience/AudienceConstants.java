//$Id$
package com.zoho.abtest.audience;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.zoho.abtest.AUDIENCE;
import com.zoho.abtest.audience.AudienceAttributeConstants.AudienceAttributes;
import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;

public class AudienceConstants {
	public static final String API_MODULE = "audiences"; //No I18N
	
	public static final String API_MODULE_SINGLE = "audience"; //No I18N
	
	public static final String API_RESOURCE = "resource.audience"; //NO I18N
	
	public static final String API_RESOURCE_INITIAL = "resource.audience.initial"; //NO I18N
	
	public static final String AUDIENCE_ID = "audience_id"; //No I18N
	
	public static final String AUDIENCE_LINKNAME = "audience_linkname"; //NO I18N
	
	public static final String EXPERIMENT_QUERY_KEY = "experiment_link_name"; //NO I18N
	
	public static final String PROJECT_ID = "project_id"; //No I18N
	
	public static final String PROJECT_LINK_NAME = "project_link_name"; //No I18N
	
	public static final String EXPERIMENT_LINK_NAME = "experiment_link_name"; //No I18N
	
	public static final String AUDIENCE_NAME = "display_name"; //No I18N
	
	public static final String AUDIENCE_DESCRIPTION = "audience_description"; //No I18N
	
	public static final String AUDIENCE_CONDITION_JSON = "audience_condition_json"; //No I18N
	
	public static final String AUDIENCE_IS_COUNTRY = "audience_is_country"; //No I18N
	
	public static final String AUDIENCE_IS_SELECTED = "audience_is_selected"; //No I18N
	
	public static final String AUDIENCE_IS_PRESET = "audience_is_preset"; //No I18N
	
	public static final String EXPERIMENT_INVOLVED = "experiment_involved"; //No I18N
	
	public static final String EXPERIMENT_ID = "experiment_id"; //No I18N
	
	public static final String AUDIENCE_NOT_EXISTS = "audience.not.exists"; //No I18N
	
	public static enum AudienceEnum {

		ALL_VISITORS("All Visitors"), //NO I18N
		DIRECT("Direct Visitors"),//NO I18N
		PAID_SEARCH("Paid Search"),//NO I18N
		ORGANIC_SEARCH("Organic Search"),//NO I18N
		SOCIAL("Social Traffic"),//NO I18N
		REFERRAL("Referral Traffic"),//NO I18N
		MOBILE_TABLET("Mobile and Tablet Traffic"),//NO I18N
		DESKTOP_VISITORS("Desktop Visitors"),//NO I18N
		NEW_VISITORS("New Visitors"),//NO I18N
		RETURNING_VISITORS("Returning Visitors");//NO I18N
	
	
		
		private String audienceName;

		AudienceEnum(String audienceName) {
			this.setAudienceName(audienceName);

		}

		public static AudienceEnum getAudienceByName(String audienceName) {
			for(AudienceEnum attr: AudienceEnum.values()) {
				if(audienceName!=null && attr.getAudienceName().equals(audienceName)) {
					return attr;
				}
			}
			return null;
		}

		public String getAudienceName() {
			return audienceName;
		}

		public void setAudienceName(String audienceName) {
			this.audienceName = audienceName;
		}


	}
	
	
	public final static List<Constants> AUDIENCE_TABLE;
	static{
		ArrayList<Constants> list = new ArrayList<Constants>();
		list.add(new Constants(ZABConstants.LINKNAME,AUDIENCE.AUDIENCE_LINK_NAME,ZABConstants.STRING,Boolean.FALSE));
		list.add(new Constants(AUDIENCE_NAME,AUDIENCE.AUDIENCE_NAME,ZABConstants.STRING,Boolean.TRUE));
		list.add(new Constants(AUDIENCE_LINKNAME,AUDIENCE.AUDIENCE_LINK_NAME,ZABConstants.STRING,Boolean.TRUE));
		list.add(new Constants(AUDIENCE_DESCRIPTION,AUDIENCE.AUDIENCE_DESCRIPTION,ZABConstants.STRING,Boolean.TRUE));
		list.add(new Constants(AUDIENCE_CONDITION_JSON,AUDIENCE.AUDIENCE_CONDITION_JSON,ZABConstants.STRING,Boolean.TRUE));
		list.add(new Constants(AUDIENCE_IS_COUNTRY,AUDIENCE.AUDIENCE_IS_COUNTRY,ZABConstants.BOOLEAN,Boolean.TRUE));
		list.add(new Constants(AUDIENCE_IS_PRESET,AUDIENCE.AUDIENCE_IS_PRESET,ZABConstants.BOOLEAN,Boolean.TRUE));
		AUDIENCE_TABLE = (List<Constants>) Collections.unmodifiableList(list);
	}

	
}
