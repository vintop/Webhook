//$Id$
package com.zoho.abtest.audience;

import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.json.JSONException;

import com.opensymphony.xwork2.ActionSupport;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;

public class LocationAction extends ActionSupport implements ServletResponseAware, ServletRequestAware {
	
		
		
		private static final Logger LOGGER = Logger.getLogger(LocationAction.class.getName());

		private static final long serialVersionUID = 1L;

		private HttpServletRequest request;
		
		private HttpServletResponse response;
		
		private String linkname;
		
		public String getLinkname() {
			return linkname;
		}

		public void setLinkname(String linkname) {
			this.linkname = linkname;
		}

		@Override
		public void setServletRequest(HttpServletRequest arg0) {
			request = arg0;
		}

		@Override
		public void setServletResponse(HttpServletResponse arg0) {
			response = arg0;
		}
		
		public String execute() throws IOException, JSONException {
			ArrayList<Location> location = new ArrayList<Location>();
			try {		
				switch(ZABAction.getHTTPMethod(request)) {
				case POST:	
					
					
					break;
				case GET:
					if(request.getParameter("id")!=null){
						location = Location.getStatesByCountryId(request.getParameter("id")); 
					} else if(request.getParameter("country_id")!=null){
						location = Location.getCitiesByCountryId(request.getParameter("country_id")); 
					}
					else if(request.getParameter("search_string")!=null){
					location = Location.getDetailsFromSearchString(request.getParameter("search_string"));
					} else{
						location = Location.getCountries();
					}
					break;
				case DELETE:
					
					break;
				case PUT:
					
					break;
				}
			} catch(Exception ex){
				ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), AudienceConstants.API_MODULE));
				return null; 	
			}		
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getLocationResponse(request, location));		
		    return null;
		}

	


}
