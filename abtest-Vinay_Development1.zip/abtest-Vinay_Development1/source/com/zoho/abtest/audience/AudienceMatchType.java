//$Id$
package com.zoho.abtest.audience;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.json.JSONException;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.ATTRIBUTE_MATCHTYPE_MAPPING;
import com.zoho.abtest.AUDIENCE_ATTRIBUTE_MATCHTYPE;
import com.zoho.abtest.audience.AudienceAttributeConstants.AudienceAttributeMatchTypes;
import com.zoho.abtest.audience.AudienceAttributeConstants.AudienceAttributes;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.dimension.Dimension;
import com.zoho.abtest.dimension.DimensionConstants;
import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.project.ProjectConstants;

public class AudienceMatchType extends ZABModel{
	
	/**
	 * 
	 */
	
	private static final Logger LOGGER = Logger.getLogger(Audience.class.getName());
	
	private static final long serialVersionUID = 1L;


	private Integer attributeMatchTypeId;
	
	private String attributeMatchTypeName;
	
	private ArrayList<Dimension> dimension = new ArrayList<Dimension>();
	
	private ArrayList<AudienceMatchType> matchType = new ArrayList<AudienceMatchType>();

	public ArrayList<Dimension> getDimensionDetails() {
		return dimension;
	}

	public void setDimensionDetails(ArrayList<Dimension> dimension) {
		this.dimension = dimension;
	}

	public ArrayList<AudienceMatchType> getMatchTypeDetails() {
		return matchType;
	}

	public void setMatchTypeDetails(ArrayList<AudienceMatchType> matchType) {
		this.matchType = matchType;
	}
	
	public Integer getAttributeMatchTypeId() {
		return attributeMatchTypeId;
	}

	public void setAttributeMatchTypeId(Integer attributeMatchTypeId) {
		this.attributeMatchTypeId = attributeMatchTypeId;
	}

	public String getAttributeMatchTypeName() {
		return attributeMatchTypeName;
	}

	public void setAttributeMatchTypeName(String attributeMatchTypeName) {
		this.attributeMatchTypeName = attributeMatchTypeName;
	}
	
	public static ArrayList<AudienceMatchType> getAudienceMatchTypeDetails(Integer id) {
		ArrayList<AudienceMatchType> matchtypes = new ArrayList<AudienceMatchType>();
		try {
			AudienceAttributes attribs = AudienceAttributes.getAudienceAttributeById(id);
			if(attribs!=null) {
				attribs.getMatchTypes().forEach((AudienceAttributeMatchTypes mt) -> {
					AudienceMatchType matchType = new AudienceMatchType();
					matchType.setAttributeMatchTypeId(mt.getTypeId());
					matchType.setAttributeMatchTypeName(mt.getDisplayName());
					matchType.setSuccess(Boolean.TRUE);
					matchtypes.add(matchType);
				});
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return matchtypes;
	}
	
//	public static ArrayList<AudienceMatchType> getAudienceMatchTypeDetails(Integer id) {
//		ArrayList<AudienceMatchType> matchtype = new ArrayList<AudienceMatchType>();
//		try {
//			
//			Criteria c = new Criteria(new Column(ATTRIBUTE_MATCHTYPE_MAPPING.TABLE, ATTRIBUTE_MATCHTYPE_MAPPING.ATTRIBUTE_ID), id, QueryConstants.EQUAL);
//			Join join1=new Join(AUDIENCE_ATTRIBUTE_MATCHTYPE.TABLE,ATTRIBUTE_MATCHTYPE_MAPPING.TABLE,new String[]{AUDIENCE_ATTRIBUTE_MATCHTYPE.MATCHTYPE_ID},new String[]{ATTRIBUTE_MATCHTYPE_MAPPING.MATCHTYPE_ID},Join.LEFT_JOIN);
//			
//			DataObject dobj = getRow(AUDIENCE_ATTRIBUTE_MATCHTYPE.TABLE, c, new Join[]{join1});
//			if(dobj.containsTable(AUDIENCE_ATTRIBUTE_MATCHTYPE.TABLE)) {
//				Iterator<?> it = dobj.getRows(AUDIENCE_ATTRIBUTE_MATCHTYPE.TABLE);
//				while(it.hasNext()) {
//					Row row = (Row)it.next();
//					matchtype.add(getAudienceAttributeDetailsFromRow(row));
//				}
//			}
//		} catch (Exception e) {
//			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
//		}
//		return matchtype;
//	}
//	
	public static AudienceMatchType getAudienceAttributeDetailsFromRow(Row row) throws JSONException {
			
		AudienceMatchType audiencematchtype = new AudienceMatchType();
			audiencematchtype.setAttributeMatchTypeId((Integer)row.get(AUDIENCE_ATTRIBUTE_MATCHTYPE.MATCHTYPE_ID));
			audiencematchtype.setAttributeMatchTypeName((String)row.get(AUDIENCE_ATTRIBUTE_MATCHTYPE.MATCHTYPE_NAME));
			audiencematchtype.setSuccess(Boolean.TRUE);
			return audiencematchtype;
			
		}
	
	
	public static AudienceMatchType getAudienceMatchType(Integer id,String projectLinkname) throws ZABException{
		AudienceMatchType matchtype = new AudienceMatchType();
		matchtype.setMatchTypeDetails(AudienceMatchType.getAudienceMatchTypeDetails(id));
		matchtype.setDimensionDetails(getDimensionDetails(id,projectLinkname));
		return matchtype;
	}

	public static ArrayList<Dimension> getDimensionDetails(Integer id,String projectLinkname) throws ZABException {
		
		ArrayList<Dimension> dimensions = new ArrayList<Dimension>();
		AudienceAttributes attr = AudienceAttributes.getAudienceAttributeById(id);
//		try{
			switch(attr){
				case CURRENT_URL:
				case REFERRAL_URL:
				case VISITOR_TYPE:
				case USERAGENT:
				case DAY_OF_WEEK:
				case SOURCE:
				case HOUR_OF_THE_DAY:
				{
					dimensions = Dimension.getDimensionCodes(id);
					break;
				}
				case COOKIE_VALUE:
				case QUERY_PARAMETER:
				case JS_VARIABLE:
				case CUSTOM_DIMENSION:
				{
					if(projectLinkname == null) {
						//Need to move to I18N properties
						throw new ZABException(ZABAction.getMessage(ZABConstants.MANDATORY_QPARAM_ERROR, new String[]{DimensionConstants.PROJECT_LINK_NAME}));
					}
					Long projectId = Project.getProjectId(projectLinkname);
					if(projectId==null) {
						//Need to move to I18N properties
						throw new ZABException(ZABAction.getMessage(ZABConstants.RESOURCE_WITHLNAME_NOTEXISTS, new String[]{ProjectConstants.PROJECT_LABEL, projectLinkname})); 
					}
					dimensions = Dimension.getDimensionCodes(id,projectId);
					break;
				}
				case OS:
				{
					dimensions = Dimension.getCommonDimensionCodes("OS_DETAIL");//No I18N
					break;
				}
				case DEVICE:
				{
					dimensions = Dimension.getCommonDimensionCodes("DEVICE_DETAIL");//No I18N
					break;
				}
				case MOBILE_OS:
				{
					dimensions = Dimension.getCommonDimensionCodes("MOBILE_DEVICE_DETAIL");//No I18N
					break;
				}
				case BROWSER:
				{
					dimensions = Dimension.getCommonDimensionCodes("BROWSER_DETAIL");//No I18N
					break;
				}
				case LOCATION:
				{
					dimensions = Dimension.getCommonDimensionCodes("COUNTRY_DETAIL");//No I18N
					break;
				}
				case ADWORDS_CAMPAIGN:
				{
					dimensions = Dimension.getAdwordsCampaign(projectLinkname);//No I18N
					break;
				}
				case ADWORDS_GROUP:
				{
					dimensions = Dimension.getAdwordsAdGroup(projectLinkname);//No I18N
					break;
				}
				case GOALS:
				{
					dimensions = Dimension.getProjectGoalsAsDimension(projectLinkname);
					break;
				}
				
				default:
					break;
			}	
//		}catch(Exception ex){
//			ex.printStackTrace();
//		}
		return dimensions;
	}
}
