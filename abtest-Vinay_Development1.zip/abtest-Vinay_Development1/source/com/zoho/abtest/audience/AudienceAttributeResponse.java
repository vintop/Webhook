//$Id$
package com.zoho.abtest.audience;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;

public class AudienceAttributeResponse {
	private static final Logger LOGGER = Logger.getLogger(AudienceAttributeResponse.class.getName());

	public static String jsonResponse(HttpServletRequest request,ArrayList<AudienceAttribute> lst) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(lst);			
			JSONObject json = ZABResponse.updateMetaInfo(request, AudienceAttributeConstants.API_MODULE, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){
			
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			
		}
		return returnBuffer.toString();
	}
	
	public static JSONArray getJSONArray(ArrayList<AudienceAttribute> lst) throws JSONException {
		JSONArray array = new JSONArray();
		int size =lst.size();
		for (int i=0;i<size;i++) {
			AudienceAttribute ld=lst.get(i);
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(AudienceAttributeConstants.ATTRIBUTE_ID, ld.getAttributeId());
			jsonObj.put(AudienceAttributeConstants.ATTRIBUTE_DISPLAYNAME, ld.getAttributeDisplayName());
			jsonObj.put(AudienceAttributeConstants.ATTRIBUTE_KEYNAME, ld.getAttributeKeyName());
			jsonObj.put(AudienceAttributeConstants.ATTRIBUTE_DESCRIPTION, ld.getAttributeDescription());
			jsonObj.put(AudienceAttributeConstants.IS_DYNAMIC_ATTRIBUTE, ld.getIsDynamicAttribute());
			
			if(ld.getMatchTypeDetails()!=null) {	
				try {					
					jsonObj.put(AudienceAttributeConstants.ATTRIBUTE_META, AudienceMatchTypeResponse.getJSONObject(ld.getMatchTypeDetails()));
				} catch (Exception e) {
					LOGGER.log(Level.SEVERE,"Exception Occurred",e);
				}
			}
			jsonObj.put(ZABConstants.RESPONSE_STRING, ld.getResponseString());
			jsonObj.put(ZABConstants.STATUS_CODE, ld.getResponseCode());
			jsonObj.put(ZABConstants.SUCCESS, ld.getSuccess());
			array.put(jsonObj);
		}
		return array;
	}
}