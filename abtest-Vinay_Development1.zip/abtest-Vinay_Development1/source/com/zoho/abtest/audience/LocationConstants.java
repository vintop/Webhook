//$Id$
package com.zoho.abtest.audience;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.zoho.abtest.CITIES_JSON;
import com.zoho.abtest.COUNTRIES_JSON;
import com.zoho.abtest.STATES_JSON;
import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.ZABConstants;

public class LocationConstants {
	
	 public static final String API_MODULE = "location"; //No I18N 
	public static final String COUNTRY = "country";  //No I18N
	public static final String STATES = "states";  //No I18N
	public static final String CITIES = "cities";  //No I18N
	public static final String DATA = "data";  //No I18N

	public static final String TEXT = "text";  //No I18N


	public static final String ID = "id";  //No I18N
	public static final String COUNTRY_ID = "country_id";  //No I18N
	public static final String STATE_ID = "state_id";  //No I18N


	public static final String SORTNAME = "sortname"; //No I18N
	public static final String NAME = "name"; //No I18N
 
	public final static List<Constants> COUNTRY_TABLE;
	public final static List<Constants> STATE_TABLE;
	public final static List<Constants> CITIES_TABLE;


	
	static{
		ArrayList<Constants> list = new ArrayList<Constants>();
		list.add(new Constants(ID,COUNTRIES_JSON.ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		list.add(new Constants(NAME,COUNTRIES_JSON.NAME,ZABConstants.STRING,Boolean.FALSE,Boolean.FALSE));
		COUNTRY_TABLE = (List<Constants>) Collections.unmodifiableList(list);
	}
	
	static{
		ArrayList<Constants> list = new ArrayList<Constants>();
		list.add(new Constants(ID,STATES_JSON.ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		list.add(new Constants(NAME,STATES_JSON.NAME,ZABConstants.STRING,Boolean.FALSE,Boolean.FALSE));
		list.add(new Constants(COUNTRY_ID,STATES_JSON.COUNTRY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		STATE_TABLE = (List<Constants>) Collections.unmodifiableList(list);
	}
	
	static{
		ArrayList<Constants> list = new ArrayList<Constants>();
		list.add(new Constants(ID,CITIES_JSON.ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		list.add(new Constants(NAME,CITIES_JSON.NAME,ZABConstants.STRING,Boolean.FALSE,Boolean.FALSE));
		list.add(new Constants(STATE_ID,CITIES_JSON.STATE_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		list.add(new Constants(COUNTRY_ID,CITIES_JSON.COUNTRY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));

		CITIES_TABLE = (List<Constants>) Collections.unmodifiableList(list);
	}
}
