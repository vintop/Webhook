//$Id$
package com.zoho.abtest.audience;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;

public class LocationResponse {

	private static final Logger LOGGER = Logger.getLogger(LocationResponse.class.getName());

	public static String jsonResponse(HttpServletRequest request, ArrayList<Location> location) {
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(location);			
			JSONObject json = ZABResponse.updateMetaInfo(request, LocationConstants.API_MODULE, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){
			
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
			
		}
		return returnBuffer.toString();
	}

	public static JSONArray getJSONArray(ArrayList<Location> location) {
		JSONArray array = new JSONArray();
		try{
		for(int i = 0; i < location.size(); i++){
			JSONObject json = new JSONObject();
			Location l = location.get(i);
			json.put(ZABConstants.RESPONSE_STRING, l.getResponseString());
			json.put(ZABConstants.STATUS_CODE, l.getResponseCode());
			json.put(ZABConstants.SUCCESS, l.getSuccess());			
			if(l.getCountry()!=null){
				json.put(LocationConstants.COUNTRY, Country.getCountry(l.getCountry()));
			}
			if(l.getStates()!=null){
				json.put(LocationConstants.STATES, States.getStates(l.getStates()));
			}
			if(l.getCities()!=null){
				json.put(LocationConstants.CITIES, Cities.getCities(l.getCities()));
			}
			if(l.getJsonArray()!=null){
				json.put(LocationConstants.DATA,l.getJsonArray() );
			}
			array.put(json);
		}
		}catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		return array;
	}

}
