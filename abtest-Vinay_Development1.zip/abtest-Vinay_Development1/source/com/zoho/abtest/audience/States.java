//$Id$
package com.zoho.abtest.audience;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONObject;

import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.STATES_JSON;

public class States {
	
	private static final Logger LOGGER = Logger.getLogger(States.class.getName());

	private String id, name;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public static States getStateFromRow(Row row) {
		States s = new States();
		s.setId((String)row.get(STATES_JSON.ID));
		s.setName((String)row.get(STATES_JSON.NAME));
		return s;
	}
	
	public static ArrayList<States> getStatesFromDobj(DataObject dobj) throws DataAccessException
	{
		ArrayList<States> states=new ArrayList<States>();
		if(dobj.containsTable(STATES_JSON.TABLE)) {
			Iterator it = dobj.getRows(STATES_JSON.TABLE);
			while(it.hasNext()) {
				Row row = (Row)it.next();
				States s = getStateFromRow(row);
				states.add(s);
			}
		}
		return states;
	}
	
	public static JSONArray getStates(ArrayList<States> states){
		JSONArray array = new JSONArray();
		try{
		for(int i = 0; i < states.size(); i++){
			States s = states.get(i);
			JSONObject json = new JSONObject();
			json.put(LocationConstants.ID, s.getId());
			json.put(LocationConstants.NAME, s.getName());
			array.put(json);
		}
		}catch(Exception e){
		LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		return array;
	}

}
