//$Id$
package com.zoho.abtest.audience;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;
import com.zoho.abtest.dimension.Dimension;
import com.zoho.abtest.dimension.DimensionConstants;
import com.zoho.abtest.utility.ZABUtil;

public class AudienceMatchTypeResponse {
	private static final Logger LOGGER = Logger.getLogger(AudienceMatchTypeResponse.class.getName());

	public static String jsonResponse(HttpServletRequest request,ArrayList<AudienceMatchType> lst) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(lst);			
			JSONObject json = ZABResponse.updateMetaInfo(request, AudienceMatchTypeConstants.API_MODULE, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){
			
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			
		}
		return returnBuffer.toString();
	}
	
	public static JSONArray getJSONArray(ArrayList<AudienceMatchType> lst) throws JSONException {
		
//		ArrayList<AudienceMatchType> matchType = new ArrayList<AudienceMatchType>();
//		ArrayList<Dimension> dimension = new ArrayList<Dimension>();
//		
//		AudienceMatchType am=lst.get(0);
//		
//		matchType = am.getMatchTypeDetails();
//		dimension = am.getDimensionDetails();
//		
//		
		JSONArray array = new JSONArray();
//		JSONObject jObj = new JSONObject();
//		
//		JSONArray array1 = new JSONArray();
//		int matchTypeSize =matchType.size();
//		
//		for (int i=0;i<matchTypeSize;i++) {
//			AudienceMatchType ld=matchType.get(i);
//			JSONObject jsonObj = new JSONObject();
////			jsonObj.put(AudienceAttributeConstants.ATTRIBUTE_ID, ld.getAttributeId());
//			jsonObj.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, ld.getAttributeMatchTypeId());
//			jsonObj.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_NAME, ld.getAttributeMatchTypeName());
//			jsonObj.put(ZABConstants.RESPONSE_STRING, ld.getResponseString());
//			jsonObj.put(ZABConstants.STATUS_CODE, ld.getResponseCode());
//			jsonObj.put(ZABConstants.SUCCESS, ld.getSuccess());
//			array1.put(jsonObj);
//		}
//
//		
//		JSONArray array2 = new JSONArray();
//		
//		int dimensionSize =dimension.size();
//		
//		for (int i=0;i<dimensionSize;i++) {
//			Dimension ld=dimension.get(i);
//			JSONObject jsonObj = new JSONObject();
			/*
			jsonObj.put(DimensionConstants.BROWSER_CODE, ld.getBrowserCode());
			jsonObj.put(DimensionConstants.BROWSER_DETAIL_ID, ld.getBrowserId());
			jsonObj.put(DimensionConstants.DIMENSION_VALUE, ld.getDimensionValue());
			
			jsonObj.put(DimensionConstants.DEVICE_CODE, ld.getDeviceCode());
			jsonObj.put(DimensionConstants.DEVICE_DETAIL_ID, ld.getDeviceId());
			jsonObj.put(DimensionConstants.DIMENSION_VALUE, ld.getDimensionValue());
			
			jsonObj.put(DimensionConstants.COUNTRY_CODE, ld.getCountryCode());
			jsonObj.put(DimensionConstants.COUNTRY_DETAIL_ID, ld.getCountryId());
			jsonObj.put(DimensionConstants.DIMENSION_VALUE, ld.getDimensionValue());
			jsonObj.put(DimensionConstants.COUNTRY_DISPLAY_NAME, ld.getCountryDisplayName());
			
			jsonObj.put(DimensionConstants.OS_CODE, ld.getOSCode());
			jsonObj.put(DimensionConstants.OS_DETAIL_ID, ld.getOSId());
			jsonObj.put(DimensionConstants.DIMENSION_VALUE, ld.getDimensionValue());
			
			jsonObj.put(DimensionConstants.DIMENSION_VALUE, ld.getTextValue());
			jsonObj.put(DimensionConstants.DIMENSION_VALUE, ld.getDimensionValue());
			
			jsonObj.put(DimensionConstants.DIMENSION_VALUE, ld.getDimensionValue());
			jsonObj.put(DimensionConstants.DIMENSION_VALUE, ld.getDimensionValue());
			
			jsonObj.put(DimensionConstants.DIMENSION_VALUE, ld.getDimensionValue());
			jsonObj.put(DimensionConstants.DIMENSION_VALUE, ld.getDimensionValue());
			jsonObj.put(DimensionConstants.DIMENSION_VALUE, ld.getDimensionValue());*/
//			jsonObj.put(DimensionConstants.DIMENSION_VALUE, ld.getDimensionValue());
			
			
			
//			jsonObj.put(ZABConstants.RESPONSE_STRING, ld.getResponseString());
//			jsonObj.put(ZABConstants.STATUS_CODE, ld.getResponseCode());
//			jsonObj.put(ZABConstants.SUCCESS, ld.getSuccess());
//			array2.put(jsonObj);
//		}
//		
//		
//		
//		jObj.put(AudienceAttributeConstants.MATCH_TYPE,array1);
//		jObj.put(AudienceAttributeConstants.ATTRIBUTE_VALUE,array2);
//		
		array.put(getJSONObject(lst.get(0)));		
		return array;
	}
	
	public static JSONObject getJSONObject(AudienceMatchType am) throws JSONException {
		ArrayList<AudienceMatchType> matchType = new ArrayList<AudienceMatchType>();
		ArrayList<Dimension> dimension = new ArrayList<Dimension>();
		
		matchType = am.getMatchTypeDetails();
		dimension = am.getDimensionDetails();
		
		JSONObject jObj = new JSONObject();
		
		JSONArray array1 = new JSONArray();
		int matchTypeSize =matchType.size();
		
		for (int i=0;i<matchTypeSize;i++) {
			AudienceMatchType ld=matchType.get(i);
			JSONObject jsonObj = new JSONObject();
//			jsonObj.put(AudienceAttributeConstants.ATTRIBUTE_ID, ld.getAttributeId());
			jsonObj.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, ld.getAttributeMatchTypeId());
			jsonObj.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_NAME, ld.getAttributeMatchTypeName());
			jsonObj.put(ZABConstants.RESPONSE_STRING, ld.getResponseString());
			jsonObj.put(ZABConstants.STATUS_CODE, ld.getResponseCode());
			jsonObj.put(ZABConstants.SUCCESS, ld.getSuccess());
			array1.put(jsonObj);
		}

		
		JSONArray array2 = new JSONArray();
		
		int dimensionSize =dimension.size();
		
		for (int i=0;i<dimensionSize;i++) {
			Dimension ld=dimension.get(i);
			JSONObject jsonObj = new JSONObject();
			/*
			jsonObj.put(DimensionConstants.BROWSER_CODE, ld.getBrowserCode());
			jsonObj.put(DimensionConstants.BROWSER_DETAIL_ID, ld.getBrowserId());
			jsonObj.put(DimensionConstants.DIMENSION_VALUE, ld.getDimensionValue());
			
			jsonObj.put(DimensionConstants.DEVICE_CODE, ld.getDeviceCode());
			jsonObj.put(DimensionConstants.DEVICE_DETAIL_ID, ld.getDeviceId());
			jsonObj.put(DimensionConstants.DIMENSION_VALUE, ld.getDimensionValue());
			
			jsonObj.put(DimensionConstants.COUNTRY_CODE, ld.getCountryCode());
			jsonObj.put(DimensionConstants.COUNTRY_DETAIL_ID, ld.getCountryId());
			jsonObj.put(DimensionConstants.DIMENSION_VALUE, ld.getDimensionValue());
			jsonObj.put(DimensionConstants.COUNTRY_DISPLAY_NAME, ld.getCountryDisplayName());
			
			jsonObj.put(DimensionConstants.OS_CODE, ld.getOSCode());
			jsonObj.put(DimensionConstants.OS_DETAIL_ID, ld.getOSId());
			jsonObj.put(DimensionConstants.DIMENSION_VALUE, ld.getDimensionValue());
			
			jsonObj.put(DimensionConstants.DIMENSION_VALUE, ld.getTextValue());
			jsonObj.put(DimensionConstants.DIMENSION_VALUE, ld.getDimensionValue());
			
			jsonObj.put(DimensionConstants.DIMENSION_VALUE, ld.getDimensionValue());
			jsonObj.put(DimensionConstants.DIMENSION_VALUE, ld.getDimensionValue());
			
			jsonObj.put(DimensionConstants.DIMENSION_VALUE, ld.getDimensionValue());
			jsonObj.put(DimensionConstants.DIMENSION_VALUE, ld.getDimensionValue());
			jsonObj.put(DimensionConstants.DIMENSION_VALUE, ld.getDimensionValue());*/
			jsonObj.put(DimensionConstants.DIMENSION_VALUE, ld.getDimensionValue());
			jsonObj.put(DimensionConstants.DIMENSION_CODE, ld.getDimensionCode());
			jsonObj.put(DimensionConstants.DIMENSION_DISPLAY_NAME, ld.getDimensionDisplayName());
			
			
			jsonObj.put(ZABConstants.RESPONSE_STRING, ld.getResponseString());
			jsonObj.put(ZABConstants.STATUS_CODE, ld.getResponseCode());
			jsonObj.put(ZABConstants.SUCCESS, ld.getSuccess());
			array2.put(jsonObj);
		}
		
		
		
		jObj.put(AudienceAttributeConstants.MATCH_TYPE,array1);
		jObj.put(AudienceAttributeConstants.ATTRIBUTE_VALUE,array2);
		return jObj;
	}
}
