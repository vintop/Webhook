//$Id$
package com.zoho.abtest.audience;

import java.util.ArrayList;
import java.util.HashMap;

import com.adventnet.persistence.DataObject;
import com.zoho.abtest.AUDIENCE;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.EXPERIMENT_AUDIENCE;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.eventactivity.EventActivityConstants;
import com.zoho.abtest.eventactivity.EventActivityWrapper;
import com.zoho.abtest.eventactivity.EventActivityConstants.Module;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentStatus;
import com.zoho.abtest.goal.GoalConstants;
import com.zoho.abtest.listener.ZABNotifier;
import com.zoho.abtest.project.ProjectTreeEventConstants;
import com.zoho.abtest.project.ProjectTreeEventWrapper;
import com.zoho.abtest.project.ProjectTreeEventConstants.OperationType;
import com.zoho.abtest.utility.ZABUtil;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.Row;
import com.adventnet.persistence.WritableDataObject;


public class ExperimentAudience extends ZABModel{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final Logger LOGGER = Logger.getLogger(Audience.class.getName());
	
	private Long experimentId;
	
	private Long experimentAudienceId;
	
	private Long audienceId;
	
	private String audienceLinkName;
	private Boolean isPrimary;
	
	public Boolean getIsPrimary() {
		return isPrimary;
	}

	public void setIsPrimary(Boolean isPrimary) {
		this.isPrimary = isPrimary;
	
	}

	

	public Long getExperimentId() {
		return experimentId;
	}

	public void setExperimentId(Long experimentId) {
		this.experimentId = experimentId;
	}

	public Long getAudienceId() {
		return audienceId;
	}

	public void setAudienceId(Long audienceId) {
		this.audienceId = audienceId;
	}

	public String getAudienceLinkName() {
		return audienceLinkName;
	}

	public void setAudienceLinkName(String audienceLinkName) {
		this.audienceLinkName = audienceLinkName;
	}

	public Long getExperimentAudienceId() {
		return experimentAudienceId;
	}

	public void setExperimentAudienceId(Long experimentAudienceId) {
		this.experimentAudienceId = experimentAudienceId;
	}
	
	public static void createExperimentAudienceWithoutEvent(Long audienceId, Long experimentid) throws Exception{
		DataObject dobj = new WritableDataObject();
		Row row = new Row(EXPERIMENT_AUDIENCE.TABLE);
		row.set(EXPERIMENT_AUDIENCE.AUDIENCE_ID, audienceId);
		row.set(EXPERIMENT_AUDIENCE.EXPERIMENT_ID, experimentid);
		dobj.addRow(row);
		updateDataObject(dobj);
	}

	public static ArrayList<ExperimentAudience> createExperimentAudience(HashMap<String, String> hs, boolean isUserEvent) {
		ArrayList<ExperimentAudience> audiences = new ArrayList<ExperimentAudience>();
		try {
			
			createRow(ExperimentAudienceConstants.EXPERIMENT_AUDIENCE_TABLE, EXPERIMENT_AUDIENCE.TABLE, hs);
			
			Long audienceId = Long.parseLong( hs.get(ExperimentAudienceConstants.AUDIENCE_ID));
			audiences.add(getExperimentAudienceByAudienceId(audienceId));
			//Trigger event 
			ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
			wrapper.setModel(audiences.get(0));
			wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
			wrapper.setType(OperationType.CREATE);
			ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);
			
			//Event Activity Log
			if(isUserEvent)
			{
				HashMap<String, String> updatedValues = new HashMap<String, String>();
				Long experimentId = Long.valueOf(hs.get(ExperimentAudienceConstants.EXPERIMENT_ID));
				updatedValues.put(EventActivityConstants.EXPERIMENT_ID, experimentId.toString());
				updatedValues.put(EventActivityConstants.USER_ID, ZABUtil.getCurrentUser().getUserId().toString());
				updatedValues.put(EventActivityConstants.TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
				updatedValues.put(AudienceConstants.AUDIENCE_ID, audienceId.toString());
				EventActivityWrapper activityWrapper = new EventActivityWrapper();
				activityWrapper.setModule(Module.EXPERIMENT_AUDIENCE);
				activityWrapper.setOperationType(com.zoho.abtest.eventactivity.EventActivityConstants.OperationType.CREATE);
				activityWrapper.setDbSpace(ZABUtil.getCurrentUserDbSpace());
				activityWrapper.setUpdatedValues(updatedValues);
				ZABNotifier.notifyListeners(EventActivityConstants.EVENT_MODULE_NAME, activityWrapper);
			}
			
		} catch (Exception e) {
			
			ExperimentAudience audience = new ExperimentAudience();
			audience.setSuccess(Boolean.FALSE);
			audience.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			audiences.add(audience);
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return audiences;
	}
	
	public static ExperimentAudience getExperimentAudienceByAudienceId(Long audienceid) {
		ExperimentAudience audience = null;
		
		try {
			Criteria c = new Criteria(new Column(EXPERIMENT_AUDIENCE.TABLE, EXPERIMENT_AUDIENCE.AUDIENCE_ID), audienceid, QueryConstants.EQUAL);
			DataObject dobj = getRow(EXPERIMENT_AUDIENCE.TABLE, c);
			if(dobj.containsTable(EXPERIMENT_AUDIENCE.TABLE)) {
				Row row = dobj.getFirstRow(EXPERIMENT_AUDIENCE.TABLE);
				audience = getExperimentAudienceFromRow(row);
			}
			
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return audience;
	}
	
	public static ExperimentAudience getExperimentAudienceByExperimentId(Long experimentid) {
		ExperimentAudience audience = null;
		try {
			Criteria c = new Criteria(new Column(EXPERIMENT_AUDIENCE.TABLE, EXPERIMENT_AUDIENCE.EXPERIMENT_ID), experimentid, QueryConstants.EQUAL);
			DataObject dobj = getRow(EXPERIMENT_AUDIENCE.TABLE, c);
			if(dobj.containsTable(EXPERIMENT_AUDIENCE.TABLE)) {
				Row row = dobj.getFirstRow(EXPERIMENT_AUDIENCE.TABLE);
				audience = getExperimentAudienceFromRow(row);
			}
			
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return audience;
	}
	
	public static ArrayList<Experiment> getRunningExperimentForAudience(String audienceLinkname, Long projectId) {
		ArrayList<Experiment> experiments = new ArrayList<Experiment>();
		try {
			Criteria c1 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_STATUS), ExperimentStatus.RUNNING.getStatusCode(), QueryConstants.EQUAL);
			Criteria c2 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.PROJECT_ID), projectId, QueryConstants.EQUAL);
			Criteria c3 = new Criteria(new Column(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME), audienceLinkname, QueryConstants.EQUAL);
			Join join1=new Join(EXPERIMENT.TABLE,EXPERIMENT_AUDIENCE.TABLE,new String[]{EXPERIMENT.EXPERIMENT_ID},new String[]{EXPERIMENT_AUDIENCE.EXPERIMENT_ID},Join.INNER_JOIN);
			Join join2=new Join(EXPERIMENT_AUDIENCE.TABLE,AUDIENCE.TABLE,new String[]{EXPERIMENT_AUDIENCE.AUDIENCE_ID},new String[]{AUDIENCE.AUDIENCE_ID},Join.INNER_JOIN);
			DataObject dobj =getRow(EXPERIMENT.TABLE, c1.and(c2).and(c3), new Join[]{join1, join2});
			if(dobj.containsTable(EXPERIMENT.TABLE)) {
				experiments = Experiment.getExperimentFromDobj(dobj);
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return experiments;
	}
	
	public static ExperimentAudience getExperimentAudienceFromRow(Row row) {
		ExperimentAudience audience = new ExperimentAudience();
		audience.setAudienceId((Long)row.get(EXPERIMENT_AUDIENCE.AUDIENCE_ID));
		
		Long audienceId = (Long)row.get(EXPERIMENT_AUDIENCE.AUDIENCE_ID);
		String audienceLinkName = Audience.getAudienceLinkNameFromAudienceId(audienceId);
		audience.setAudienceLinkName(audienceLinkName);
		
		audience.setExperimentId((Long)row.get(EXPERIMENT_AUDIENCE.EXPERIMENT_ID));
		audience.setExperimentAudienceId((Long)row.get(EXPERIMENT_AUDIENCE.EXPERIMENT_AUDIENCE_ID));
		return audience;
	}
	
	public static  ArrayList<ExperimentAudience> updateExperimentAudience(HashMap<String, String> hs) {
		ArrayList<ExperimentAudience> audiences = new ArrayList<ExperimentAudience>();
		ExperimentAudience audience = new ExperimentAudience();
		try {
			String experimentlinkname = hs.get(ZABConstants.LINKNAME);
			Long experimentId = Experiment.getExperimentId(experimentlinkname);
			String audienceId = hs.get(AudienceConstants.AUDIENCE_ID);
			
			Criteria c = new Criteria(new Column(EXPERIMENT_AUDIENCE.TABLE, EXPERIMENT_AUDIENCE.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
			hs.put(ExperimentAudienceConstants.AUDIENCE_ID, audienceId);
			
			updateRow(ExperimentAudienceConstants.EXPERIMENT_AUDIENCE_TABLE, EXPERIMENT_AUDIENCE.TABLE, hs, c, AudienceConstants.API_RESOURCE);
			audience = new ExperimentAudience();	
			audience.setSuccess(Boolean.TRUE);
			audience.setExperimentId(experimentId);
			audiences.add(audience);
			
			//Event Activity Log
			HashMap<String, String> updatedValues = new HashMap<String, String>();
			updatedValues.put(EventActivityConstants.EXPERIMENT_ID, experimentId.toString());
			updatedValues.put(EventActivityConstants.USER_ID, ZABUtil.getCurrentUser().getUserId().toString());
			updatedValues.put(EventActivityConstants.TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
			updatedValues.put(AudienceConstants.AUDIENCE_ID, audienceId.toString());
			EventActivityWrapper activityWrapper = new EventActivityWrapper();
			activityWrapper.setModule(Module.EXPERIMENT_AUDIENCE);
			activityWrapper.setOperationType(com.zoho.abtest.eventactivity.EventActivityConstants.OperationType.UPDATE);
			activityWrapper.setDbSpace(ZABUtil.getCurrentUserDbSpace());
			activityWrapper.setUpdatedValues(updatedValues);
			ZABNotifier.notifyListeners(EventActivityConstants.EVENT_MODULE_NAME, activityWrapper);
			
		}  catch (Exception e) {
			audience = new ExperimentAudience();
			audience.setSuccess(Boolean.FALSE);
			audience.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			audiences.add(audience);
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return audiences;
	}
	
}
