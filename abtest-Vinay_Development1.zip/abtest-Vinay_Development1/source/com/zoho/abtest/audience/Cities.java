//$Id$
package com.zoho.abtest.audience;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONObject;

import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.CITIES_JSON;

public class Cities {
	
	private static final Logger LOGGER = Logger.getLogger(Cities.class.getName());

	private String id, name;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public static Cities getCitiesFromRow(Row row) {
		Cities c = new Cities();
		c.setId((String)row.get(CITIES_JSON.ID));
		c.setName((String)row.get(CITIES_JSON.NAME));
		return c;
	}
	
	public static ArrayList<Cities> getCitiesFromDobj(DataObject dobj) throws DataAccessException
	{
		ArrayList<Cities> cities=new ArrayList<Cities>();
		if(dobj.containsTable(CITIES_JSON.TABLE)) {
			Iterator it = dobj.getRows(CITIES_JSON.TABLE);
			while(it.hasNext()) {
				Row row = (Row)it.next();
				Cities c = getCitiesFromRow(row);
				cities.add(c);
			}
		}
		return cities;
	}
	
	public static JSONArray getCities(ArrayList<Cities> cities){
		JSONArray array = new JSONArray();
		try{
		for(int i = 0; i < cities.size(); i++){
			Cities c = cities.get(i);
			JSONObject json = new JSONObject();
			json.put(LocationConstants.ID, c.getId());
			json.put(LocationConstants.NAME, c.getName());
			array.put(json);
		}
		}catch(Exception e){
		LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		return array;
	}


}
