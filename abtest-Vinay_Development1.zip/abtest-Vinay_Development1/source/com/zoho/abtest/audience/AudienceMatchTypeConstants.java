//$Id$
package com.zoho.abtest.audience;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.zoho.abtest.ATTRIBUTE_MATCHTYPE_MAPPING;
import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.ZABConstants;

public class AudienceMatchTypeConstants {
	
	public static final String API_MODULE = "audienceattrdetails"; //No I18N
	
	public static final String API_RESOURCE = "resource.audiencematchtype"; //NO I18N
	
	public static final String API_RESOURCE_INITIAL = "resource.audiencematchtype.initial"; //NO I18N
	
	public static final String ATTRIBUTE_ID = "attribute_id"; //No I18N
	
	public static final String ATTRIBUTE_MATCHTYPE_ID = "attribute_matchtype_id"; //No I18N
		
	public static final String ATTRIBUTE_MATCHTYPE_NAME = "attribute_matchtype_name"; //No I18N
	
	
	public final static List<Constants> ATTRIBUTE_MATCHTYPE_MAPPING_TABLE;
	static{
		ArrayList<Constants> list = new ArrayList<Constants>();
		list.add(new Constants(ATTRIBUTE_ID,ATTRIBUTE_MATCHTYPE_MAPPING.ATTRIBUTE_ID,ZABConstants.INTEGER,Boolean.TRUE));
		list.add(new Constants(ATTRIBUTE_MATCHTYPE_ID,ATTRIBUTE_MATCHTYPE_MAPPING.MATCHTYPE_ID,ZABConstants.INTEGER,Boolean.TRUE));
		ATTRIBUTE_MATCHTYPE_MAPPING_TABLE = (List<Constants>) Collections.unmodifiableList(list);
	}
}
