//$Id$
package com.zoho.abtest.audience;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.TransactionManager;

import org.json.JSONException;
import org.json.JSONObject;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.DataSet;
import com.adventnet.ds.query.GroupByClause;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.ds.query.SelectQueryImpl;
import com.adventnet.ds.query.Table;
import com.adventnet.mfw.bean.BeanUtil;
import com.adventnet.persistence.DataAccess;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.persistence.WritableDataObject;
import com.zoho.abtest.AUDIENCE;
import com.zoho.abtest.BROWSER_DETAIL;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.EXPERIMENT_AUDIENCE;
import com.zoho.abtest.PROJECT;
import com.zoho.abtest.PROJECT_AUDIENCE;
import com.zoho.abtest.VARIATION_VISITS;
import com.zoho.abtest.audience.AudienceAttributeConstants.AudienceAttributes;
import com.zoho.abtest.audience.AudienceConstants.AudienceEnum;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.dimension.Dimension;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.project.ProjectTreeEventConstants;
import com.zoho.abtest.project.ProjectTreeEventWrapper;
import com.zoho.abtest.project.ProjectTreeEventConstants.OperationType;
import com.zoho.abtest.exception.ResourceNotFoundException;
import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentStatus;
import com.zoho.abtest.goal.GoalConstants;
import com.zoho.abtest.listener.ZABNotifier;
import com.zoho.abtest.utility.DataSetWrapper;
import com.zoho.abtest.utility.ZABUserBean;
import com.zoho.abtest.utility.ZABUtil;

public class Audience extends ZABModel{
	
	/**
	 * 
	 */
	
	private static final Logger LOGGER = Logger.getLogger(Audience.class.getName());
	
	private static final long serialVersionUID = 1L;

	private Long audienceId;
	
	private Long projectId;
	
	private String audienceName;
	
	private String audienceLinkName;
	
	private String description;
	
	private JSONObject conditionJson;

	private Boolean isCountry;
	
	private Boolean isSelected;
	
	private Boolean isPresetAudience;
	
	private Integer experimentCount;
	
	private Integer ordinal;
	
	private ArrayList<Experiment> experiments = new ArrayList<Experiment>();
	
	public Integer getExperimentCount() {
		return experimentCount;
	}

	public void setExperimentCount(Integer experimentCount) {
		this.experimentCount = experimentCount;
	}

	public Boolean getIsPresetAudience() {
		return isPresetAudience;
	}

	public void setIsPresetAudience(Boolean isPresetAudience) {
		this.isPresetAudience = isPresetAudience;
	}

	public ArrayList<Experiment> getExperiments() {
		return experiments;
	}

	public void setExperiments(ArrayList<Experiment> experiments) {
		this.experiments = experiments;
	}
	
	public Long getAudienceId() {
		return audienceId;
	}

	public void setAudienceId(Long audienceId) {
		this.audienceId = audienceId;
	}

	public Long getProjectId() {
		return projectId;
	}

	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}

	public String getAudienceName() {
		return audienceName;
	}

	public void setAudienceName(String audienceName) {
		this.audienceName = audienceName;
	}
	
	public String getAudienceLinkName() {
		return audienceLinkName;
	}
	
	public void setAudienceIsSelected(Boolean isSelected) {
		this.isSelected = isSelected;
	}
	
	public Boolean getAudienceIsSelected() {
		return isSelected;
	}
	
	public void setAudienceLinkName(String audienceLinkName) {
		this.audienceLinkName = audienceLinkName;
	}

	public String getAudienceDescription() {
		return description;
	}

	public void setAudienceDescription(String description) {
		this.description = description;
	}

	public JSONObject getAudienceConditionJSON() {
		return conditionJson;
	}

	public void setAudienceConditionJSON(JSONObject conditionJson) {
		this.conditionJson = conditionJson;
	}

	public Boolean getAudienceIsCountry() {
		return isCountry;
	}

	public void setAudienceIsCountry(Boolean isCountry) {
		this.isCountry = isCountry;
	}
	
	public Integer getOrdinal() {
		return ordinal;
	}

	public void setOrdinal(Integer ordinal) {
		this.ordinal = ordinal;
	}
	
	static final Comparator<Audience> ORDINAL_ORDER = 
			new Comparator<Audience>() {
		public int compare(Audience e1, Audience e2) {
			
			return e1.getOrdinal() - e2.getOrdinal();
		}
	};


	public Boolean isInvolvedRunningExperiments() {
		Boolean flag = false;
		Criteria c = new Criteria(new Column(EXPERIMENT_AUDIENCE.TABLE, EXPERIMENT_AUDIENCE.AUDIENCE_ID), this.getAudienceId(), QueryConstants.EQUAL);
		Criteria c2 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_STATUS), ExperimentStatus.RUNNING.getStatusCode(), QueryConstants.EQUAL);
		Join join1=new Join(EXPERIMENT_AUDIENCE.TABLE,EXPERIMENT.TABLE,new String[]{EXPERIMENT_AUDIENCE.EXPERIMENT_ID},new String[]{EXPERIMENT.EXPERIMENT_ID},Join.INNER_JOIN);
		try {
			DataObject dobj = getRow(EXPERIMENT_AUDIENCE.TABLE, c.and(c2), join1);
			flag = dobj.containsTable(EXPERIMENT_AUDIENCE.TABLE);
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Exception occured:", e);
		}
		return flag;
	}
	
	public static Audience getAudienceByLinkName(String linkname,Long experimentId) {
		Audience audience = null;
		try {
			Criteria c = new Criteria(new Column(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME), linkname, QueryConstants.EQUAL);
			DataObject dobj = getRow(AUDIENCE.TABLE, c);
			if(dobj.containsTable(AUDIENCE.TABLE)) {
				Row row = dobj.getFirstRow(AUDIENCE.TABLE);
				audience = getAudienceFromRow(row,experimentId);
			}
			
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return audience;
	}
	
	public static Long getProjectIdFromAudienceLinkName(String linkname) {
		Long projectId = null;
		try {
			Criteria c = new Criteria(new Column(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME), linkname, QueryConstants.EQUAL);
			Join join1=new Join(AUDIENCE.TABLE,PROJECT_AUDIENCE.TABLE,new String[]{AUDIENCE.AUDIENCE_ID},new String[]{PROJECT_AUDIENCE.AUDIENCE_ID},Join.INNER_JOIN);
			DataObject dobj = getRow(AUDIENCE.TABLE, c, new Join[]{join1});
			projectId = (Long)dobj.getFirstValue(PROJECT_AUDIENCE.TABLE, PROJECT_AUDIENCE.PROJECT_ID);
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
			projectId = null;
		}
		return projectId;
	}
	
	public static String getAudienceLinkNameFromAudienceId(Long audienceId) {
		String audienceLinkName = null;
		try {
			Criteria c = new Criteria(new Column(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_ID), audienceId, QueryConstants.EQUAL);
			DataObject dobj = getRow(AUDIENCE.TABLE, c);
			audienceLinkName = (String)dobj.getFirstValue(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME);
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
			audienceLinkName = null;
		}
		return audienceLinkName;
	}
	
	public static void setExperimentInvolvedCount(final HashMap<Long, Audience> audienceMap) throws Exception {
		Set<Long> audienceIds = audienceMap.keySet();
		Criteria c = new Criteria(new Column(EXPERIMENT_AUDIENCE.TABLE, EXPERIMENT_AUDIENCE.AUDIENCE_ID), audienceIds.toArray(new Long[audienceIds.size()]), QueryConstants.IN);
		SelectQuery query = new SelectQueryImpl(new Table(EXPERIMENT_AUDIENCE.TABLE));
		Column sum = new Column(EXPERIMENT_AUDIENCE.TABLE, EXPERIMENT_AUDIENCE.EXPERIMENT_ID).count();
		Column audienceId = new Column(EXPERIMENT_AUDIENCE.TABLE, EXPERIMENT_AUDIENCE.AUDIENCE_ID);
		sum.setColumnAlias("EXPERIMENT_COUNT");
		query.addSelectColumn(sum);
		query.addSelectColumn(audienceId);
		GroupByClause gc = new GroupByClause(Arrays.asList(new Column(EXPERIMENT_AUDIENCE.TABLE, EXPERIMENT_AUDIENCE.AUDIENCE_ID)));
		query.setGroupByClause(gc);
		query.setCriteria(c);
		ZABUserBean bean= (ZABUserBean)BeanUtil.lookup(ZABUserBean.BEAN_NAME, ZABUtil.getCurrentUserDbSpace());
		bean.executeQuery(query, new DataSetWrapper() {

			@Override
			public void execute(DataSet ds) throws Exception {
					while(ds.next()) {
						Long audienceId = (Long)ds.getValue(EXPERIMENT_AUDIENCE.AUDIENCE_ID);
						Integer count = (Integer)ds.getValue("EXPERIMENT_COUNT");
						audienceMap.get(audienceId).setExperimentCount(count);
					}
			    }
			});

	}
	
	public static ArrayList<Audience> getAudiences(String projectLinkName,String experimentLinkName) {
		
		ArrayList<Audience> audiences = new ArrayList<Audience>();
		try {
			
			//Getting selected audience for experiment
			if(projectLinkName == null && experimentLinkName!=null) {
				Long experimentId = Experiment.getExperimentId(experimentLinkName);
				return getAudienceByExperimentId(experimentId);
			}
			
			
			Long experimentId = experimentLinkName!=null?Experiment.getExperimentId(experimentLinkName):null;
			Long ProjectId = projectLinkName!=null?Project.getProjectId(projectLinkName):null;
			
			ExperimentAudience exp = null;
			if(experimentId != null && ProjectId!=null) {					
				exp = ExperimentAudience.getExperimentAudienceByExperimentId(experimentId);
			}
			
			Criteria c = new Criteria(new Column(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_IS_PRESET), true, QueryConstants.EQUAL);
			DataObject dobj = ZABModel.getRow(AUDIENCE.TABLE, c);
			audiences.addAll(getAudienceFromDobj(dobj, exp, Boolean.TRUE));
			
			Criteria c1 = new Criteria(new Column(PROJECT_AUDIENCE.TABLE, PROJECT_AUDIENCE.PROJECT_ID), ProjectId, QueryConstants.EQUAL);
			Join join1=new Join(PROJECT_AUDIENCE.TABLE,AUDIENCE.TABLE,new String[]{PROJECT_AUDIENCE.AUDIENCE_ID},new String[]{AUDIENCE.AUDIENCE_ID},Join.INNER_JOIN);
			DataObject dobj1 = ZABModel.getRow(PROJECT_AUDIENCE.TABLE, c1, join1);
			
			if(dobj1.containsTable(PROJECT_AUDIENCE.TABLE)) {
				Iterator<?> it = dobj1.getRows(PROJECT_AUDIENCE.TABLE);
				HashMap<Long, Audience> audienceMap = new HashMap<Long, Audience>();
				while(it.hasNext()) {
					Row row = (Row)it.next();
					Long audience_id = (Long)row.get(PROJECT_AUDIENCE.AUDIENCE_ID);
					Criteria c2 = new Criteria(new Column(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_ID), audience_id, QueryConstants.EQUAL);
					Row arow = dobj1.getRow(AUDIENCE.TABLE, c2);
					Audience audience = getAudienceFromRow(arow);
					audience.setAudienceIsSelected((exp!=null && exp.getAudienceId().equals(audience.getAudienceId())));
					audience.setIsPresetAudience(Boolean.FALSE);
					audience.setExperimentCount(0);
					audienceMap.put(audience_id, audience);
				}
				
				setExperimentInvolvedCount(audienceMap);
				audiences.addAll(audienceMap.values());
			}
			
		} catch (Exception e) {
			Audience audience = new Audience();
			audience.setSuccess(Boolean.FALSE);
			audience.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			audiences.add(audience);
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		audiences = rearrangeAudiences(audiences);
		return audiences;
	}
	
	private static ArrayList<Audience> rearrangeAudiences(
			ArrayList<Audience> audiences) {
		ArrayList<Audience> finalList = new ArrayList<Audience>();
		ArrayList<Audience> customAudList = new ArrayList<Audience>();
		for(int i=0;i<audiences.size();i++){
			Audience audAttr = audiences.get(i);
			String audName = audAttr.getAudienceName();
			AudienceEnum aud = AudienceEnum.getAudienceByName(audName);
			if(aud!=null){
				audAttr.setOrdinal(aud.ordinal());
				finalList.add(audAttr);
			}else{
				customAudList.add(audAttr);
			}
		}
		Collections.sort(finalList,ORDINAL_ORDER);
		finalList.addAll(customAudList);
		
		return finalList;
	}

	public static ArrayList<Audience> getAudienceFromDobj(DataObject dobj,ExperimentAudience exp, Boolean isPreset) throws DataAccessException, JSONException {
		ArrayList<Audience> audiences = new ArrayList<Audience>();
		if(dobj.containsTable(AUDIENCE.TABLE)) {
			Iterator<?> it = dobj.getRows(AUDIENCE.TABLE);
			while(it.hasNext()) {
				Row row = (Row)it.next();
				Audience audience = getAudienceFromRow(row);
				audience.setIsPresetAudience(isPreset);
				audience.setAudienceIsSelected((exp!=null && exp.getAudienceId().equals(audience.getAudienceId())));
				audiences.add(audience);
			}
		}
		return audiences;
	}
	
	public static Audience getAudienceById(Long id,Long experimentId) {
		Audience audience = null;
		try {
			Criteria c = new Criteria(new Column(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_ID), id, QueryConstants.EQUAL);
			DataObject dobj = getRow(AUDIENCE.TABLE, c);
			if(dobj.containsTable(AUDIENCE.TABLE)) {
				Row row = dobj.getFirstRow(AUDIENCE.TABLE);
				audience = getAudienceFromRow(row,experimentId);
			}
			
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return audience;
	}
	
	
	
	public static Audience getAudienceFromRow(Row row,Long experimentId) throws JSONException {
		Audience audience = getAudienceFromRow(row);
		
		if(experimentId!=null && experimentId!=0){
			Long audienceId = (Long)row.get(AUDIENCE.AUDIENCE_ID);
			ExperimentAudience exp = null;
			exp = ExperimentAudience.getExperimentAudienceByExperimentId(experimentId);
			int comp = audienceId.compareTo(exp.getAudienceId());
			if(comp == 0){
				audience.setAudienceIsSelected(Boolean.TRUE);
			}else{
				audience.setAudienceIsSelected(Boolean.FALSE);
			}
		}
		
		return audience;
	}
	
	public static Audience getAudienceFromRow(Row row) throws JSONException {
		
		Audience audience = new Audience();
		audience.setAudienceId((Long)row.get(AUDIENCE.AUDIENCE_ID));
		audience.setAudienceName((String)row.get(AUDIENCE.AUDIENCE_NAME));
		audience.setAudienceLinkName((String)row.get(AUDIENCE.AUDIENCE_LINK_NAME));
		
		String audience_cond_json = (String)row.get(AUDIENCE.AUDIENCE_CONDITION_JSON);
		if(audience_cond_json!=null&&!audience_cond_json.isEmpty()){
			JSONObject audience_json = new JSONObject(audience_cond_json);
			audience.setAudienceConditionJSON(audience_json);
			
		}
		
		
		//audience.setProjectId((Long)row.get(AUDIENCE.PROJECT_ID));
		audience.setAudienceDescription((String)row.get(AUDIENCE.AUDIENCE_DESCRIPTION));
		audience.setSuccess(Boolean.TRUE);
		return audience;
	}
	
	
	public static ArrayList<Audience> createAudience(HashMap<String, String> hs) {
		ArrayList<Audience> audiences = new ArrayList<Audience>();
		Audience audience = new Audience();
		try {
			String projectLinkname = hs.get(AudienceConstants.PROJECT_LINK_NAME);
			Long projectId = Project.getProjectId(projectLinkname);
			String experimentLinkname = hs.get(AudienceConstants.EXPERIMENT_LINK_NAME);
			Long experimentId = Experiment.getExperimentId(experimentLinkname);
			if(projectId!=null) {
				String linkName = generateLinkName(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME, null, null, hs.get(AudienceConstants.AUDIENCE_NAME));
				hs.put(AudienceConstants.AUDIENCE_LINKNAME, linkName);
				
				String audienceJson = hs.get(AudienceConstants.AUDIENCE_CONDITION_JSON);
				String isCountry = parseAudienceJSON(audienceJson);
				if(isCountry.equals("true")){
					audience.setAudienceIsCountry(Boolean.TRUE);
					hs.put(AudienceConstants.AUDIENCE_IS_COUNTRY, Boolean.TRUE.toString());
				}else{
					hs.put(AudienceConstants.AUDIENCE_IS_COUNTRY, Boolean.FALSE.toString());
				}
				hs.put(AudienceConstants.AUDIENCE_IS_PRESET, Boolean.FALSE.toString());
				
				audience.setProjectId(projectId);
				audience.setAudienceLinkName(linkName);
				audience.setAudienceName(hs.get(AudienceConstants.AUDIENCE_NAME));
				audience.setIsPresetAudience(Boolean.FALSE);
				/*
				JSONObject audience_json = new JSONObject(hs.get(AUDIENCE.AUDIENCE_CONDITION_JSON));
				String a = "";
				audience.setAudienceConditionJSON((JSONObject)audience_json);
				*/
				
				audiences.add(audience);
				
				DataObject dobj = createRow(AudienceConstants.AUDIENCE_TABLE, AUDIENCE.TABLE, hs);
				Row row = dobj.getRow(AUDIENCE.TABLE);
				Long audienceId = (Long)row.get(AUDIENCE.AUDIENCE_ID);
				audience.setSuccess(Boolean.TRUE);
				audience.setAudienceId(audienceId);
				
				//Create ProjectAudience
				hs.put(AudienceConstants.PROJECT_ID, projectId.toString());
				HashMap<String, String> hs_project_audience =  new HashMap<String, String>();
				hs_project_audience.put(ProjectAudienceConstants.AUDIENCE_ID, audienceId.toString());
				hs_project_audience.put(ProjectAudienceConstants.PROJECT_ID, hs.get(AudienceConstants.PROJECT_ID));
				ProjectAudience.createProjectAudience(hs_project_audience);
				
				//Update ExperimentAudience
				HashMap<String, String> hs_exp_audience =  new HashMap<String, String>();
				hs_exp_audience.put(AudienceConstants.AUDIENCE_ID, audienceId.toString());
				hs_exp_audience.put(ZABConstants.LINKNAME, experimentLinkname);
				ExperimentAudience.updateExperimentAudience(hs_exp_audience);
				
				//Notify event
				/*ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
				wrapper.setModel(audience);
				wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
				wrapper.setType(OperationType.CREATE);
				ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);*/
				
			} else {
				
				audience.setSuccess(Boolean.FALSE);
				audience.setResponseString(ZABAction.getMessage(AudienceConstants.AUDIENCE_NOT_EXISTS));
				audiences.add(audience);
			}
			
			
		} catch (Exception e) {

			audience.setSuccess(Boolean.FALSE);
			audience.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			audiences.add(audience);
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return audiences;
	}
	
	public static  ArrayList<Audience> updateAudience(HashMap<String, String> hs) {
		ArrayList<Audience> audiences = new ArrayList<Audience>();
		Audience audience = new Audience();
		try {
			String linkname = hs.get(AudienceConstants.AUDIENCE_LINKNAME);
			Criteria c = new Criteria(new Column(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME), linkname, QueryConstants.EQUAL);
			
			String audienceJson = hs.get(AudienceConstants.AUDIENCE_CONDITION_JSON);
			String isCountry = parseAudienceJSON(audienceJson);
			if(isCountry.equals("true")){
				audience.setAudienceIsCountry(Boolean.TRUE);
				hs.put(AudienceConstants.AUDIENCE_IS_COUNTRY, Boolean.TRUE.toString());
			}else{
				hs.put(AudienceConstants.AUDIENCE_IS_COUNTRY, Boolean.FALSE.toString());
			}
			
			updateRow(AudienceConstants.AUDIENCE_TABLE, AUDIENCE.TABLE, hs, c, AudienceConstants.API_RESOURCE);
			audience = new Audience();	
			audience.setSuccess(Boolean.TRUE);
			audience.setAudienceLinkName(linkname);
			audiences.add(audience);
			
			//Notify event
			ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
			wrapper.setModel(audience);
			wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
			wrapper.setType(OperationType.UPDATE);
			ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);
			
		} catch(ResourceNotFoundException re) {
			LOGGER.log(Level.SEVERE,"Resource Not Found Exception Occurred",re);
			audience = new Audience();
			setModelWithRNFData(audience, re);
		} catch (Exception e) {
			audience = new Audience();
			audience.setSuccess(Boolean.FALSE);
			audience.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			audiences.add(audience);
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return audiences;
	}
	
	public static ArrayList<Audience> getAudienceByExperimentId(Long experimentId) {
		ArrayList<Audience> audiences = new ArrayList<Audience>();
		try {
			Criteria c = new Criteria(new Column(EXPERIMENT_AUDIENCE.TABLE, EXPERIMENT_AUDIENCE.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
			Join join1=new Join(AUDIENCE.TABLE,EXPERIMENT_AUDIENCE.TABLE,new String[]{AUDIENCE.AUDIENCE_ID},new String[]{EXPERIMENT_AUDIENCE.AUDIENCE_ID},Join.INNER_JOIN);
			DataObject dobj = getRow(AUDIENCE.TABLE, c, join1);
			if(dobj.containsTable(AUDIENCE.TABLE)) {
				Iterator it = dobj.getRows(AUDIENCE.TABLE);
				while(it.hasNext()) {
					Row row = (Row)it.next();
					audiences.add(getAudienceFromRow(row,experimentId));
				}
			}
			
		} catch(Exception e) {
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return audiences;
	}
	
	public static Audience deleteAudience(String linkname,Long experimentId){
		Audience audience = null;
		
		try {
			Criteria c = new Criteria(new Column(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME), linkname, QueryConstants.EQUAL);
			Join join1=new Join(AUDIENCE.TABLE,EXPERIMENT_AUDIENCE.TABLE,new String[]{AUDIENCE.AUDIENCE_ID},new String[]{EXPERIMENT_AUDIENCE.AUDIENCE_ID},Join.LEFT_JOIN);
			Join join2=new Join(EXPERIMENT_AUDIENCE.TABLE,EXPERIMENT.TABLE,new String[]{EXPERIMENT_AUDIENCE.EXPERIMENT_ID},new String[]{EXPERIMENT.EXPERIMENT_ID},Join.LEFT_JOIN);
			
			DataObject dobj = getRow(AUDIENCE.TABLE, c, new Join[]{join1, join2});
			if(dobj.containsTable(AUDIENCE.TABLE)) {
				Row row = dobj.getFirstRow(AUDIENCE.TABLE);
				audience = getAudienceFromRow(row,experimentId);
				if(dobj.containsTable(EXPERIMENT.TABLE)) {
					Iterator it = dobj.getRows(EXPERIMENT.TABLE);
					while(it.hasNext()) {
						Row erow = (Row)it.next();
						audience.getExperiments().add(Experiment.getExperimentFromRow(erow));
					}
				}
				deleteResource(row);
			} else {
				throw new ResourceNotFoundException(AudienceConstants.API_MODULE);
			}
			
			//Notify event
			ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
			wrapper.setModel(audience);
			wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
			wrapper.setType(OperationType.DELETE);
			ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);
		}catch(ResourceNotFoundException re) {
			LOGGER.log(Level.SEVERE,"Resouce Not Found Exception Occurred",re);
			audience = new Audience();
			setModelWithRNFData(audience, re);
		}  catch (Exception e) {
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
			audience = new Audience();
			audience.setSuccess(Boolean.FALSE);
			audience.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
		}
		
		return audience;
	}
	
	public static String parseAudienceJSON(String audienceJSON){
		
		String isCountry = "false";
	    
	    int substr = audienceJSON.indexOf("\"type\":\"location\"");
	    if(substr!=-1){
	    	isCountry = "true";
	    }
	    
		return isCountry;
		
	}


}
