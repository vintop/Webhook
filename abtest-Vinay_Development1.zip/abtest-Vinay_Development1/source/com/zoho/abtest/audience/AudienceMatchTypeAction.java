//$Id$
package com.zoho.abtest.audience;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.json.JSONException;

import com.opensymphony.xwork2.ActionSupport;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;

public class AudienceMatchTypeAction extends ActionSupport implements ServletResponseAware, ServletRequestAware{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private HttpServletRequest request;
	
	private HttpServletResponse response;
	
	private String linkname;
	
	public String getLinkname() {
		return linkname;
	}

	public void setLinkname(String linkname) {
		this.linkname = linkname;
	}

	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		request = arg0;
	}

	@Override
	public void setServletResponse(HttpServletResponse arg0) {
		response = arg0;
	}
	
	public String execute() throws IOException,JSONException {
		ArrayList<AudienceMatchType> matchType = new ArrayList<AudienceMatchType>();
		try {		
			switch(ZABAction.getHTTPMethod(request)) {
			case GET:
//				if(linkname!=null) {
//					matchType.add(AudienceMatchType.getAudienceMatchType(linkname,0L));
//				}else{
//					String attribute_id = request.getParameter(AudienceMatchTypeConstants.ATTRIBUTE_ID);
//					String projectLinkName = request.getParameter(DimensionConstants.PROJECT_LINK_NAME);
//					Long projectId = Project.getProjectId(projectLinkName);
//					matchType.add(AudienceMatchType.getAudienceMatchType(attribute_id,projectId));
//				}
				break;
			}
		}	
		catch(Exception ex){
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), AudienceMatchTypeConstants.API_MODULE));
			return null; 	
		}		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getAudienceMatchTypeResponse(request, matchType));		
	    return null;
	}

}
