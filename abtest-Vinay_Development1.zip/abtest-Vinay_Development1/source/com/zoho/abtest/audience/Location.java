//$Id$
package com.zoho.abtest.audience;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.zoho.abtest.CITIES_JSON;
import com.zoho.abtest.COUNTRIES_JSON;
import com.zoho.abtest.STATES_JSON;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.utility.ZABUtil;

import org.json.JSONArray;




public class Location extends ZABModel {
	
	private static final Logger LOGGER = Logger.getLogger(Location.class.getName());
	
	private JSONArray jsonArray ;
	
	private ArrayList<Country> country;
	
	private ArrayList<States> states;
	
	private ArrayList<Cities> cities;
	
	public JSONArray getJsonArray() {
		return jsonArray;
	}

	public void setJsonArray(JSONArray jsonArray) {
		this.jsonArray = jsonArray;
	}

	public ArrayList<Cities> getCities() {
		return cities;
	}

	public void setCities(ArrayList<Cities> cities) {
		this.cities = cities;
	}

	public ArrayList<States> getStates() {
		return states;
	}

	public void setStates(ArrayList<States> states) {
		this.states = states;
	}

	public ArrayList<Country> getCountry() {
		return country;
	}

	public void setCountry(ArrayList<Country> country) {
		this.country = country;
	}

	

	public static ArrayList<Location> getCountries() {
		
		ArrayList<Location> countries = new ArrayList<Location>();
		try{
		Location location = new Location();
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		DataObject  dobj =  getRow(COUNTRIES_JSON.TABLE, null);
		ArrayList<Country> c = Country.getCountriesFromDobj(dobj);
		location.setCountry(c);
		location.setSuccess(Boolean.TRUE);
		countries.add(location);
		ZABUtil.setDBSpace(existingDBSpace);	
		} catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		return countries;
	}
	
	public static ArrayList<Location> getStatesByCountryId(String id){
		ArrayList<Location> states = new ArrayList<Location>();
		try{
			Location location = new Location();
			String existingDBSpace = ZABUtil.getDBSpace();
			ZABUtil.setDBSpace("sharedspace");	//No I18N
			Criteria c = new Criteria(new Column(STATES_JSON.TABLE,STATES_JSON.COUNTRY_ID),id,QueryConstants.EQUAL);
			DataObject  dobj =  getRow(STATES_JSON.TABLE, c);
			ArrayList<States>  s = States.getStatesFromDobj(dobj); 
			location.setStates(s);
			location.setSuccess(Boolean.TRUE);
			states.add(location);
			ZABUtil.setDBSpace(existingDBSpace);	

			
		} catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		return states;
	}
	
	public static ArrayList<Location> getCitiesByCountryId(String id){
		ArrayList<Location> cities = new ArrayList<Location>();
		try{
			Location location = new Location();
			String existingDBSpace = ZABUtil.getDBSpace();
			ZABUtil.setDBSpace("sharedspace");	//No I18N
			Criteria c1 = new Criteria(new Column(CITIES_JSON.TABLE,CITIES_JSON.COUNTRY_ID),id,QueryConstants.EQUAL);
			DataObject  dobj =  getRow(CITIES_JSON.TABLE, c1);
			ArrayList<Cities>  c = Cities.getCitiesFromDobj(dobj); 
			location.setCities(c);
			location.setSuccess(Boolean.TRUE);
			cities.add(location);
			ZABUtil.setDBSpace(existingDBSpace);	

			
		} catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		return cities;
	}
	
	public static ArrayList<Location> getDetailsFromSearchString(String str){
		
		ArrayList<Location> location = new ArrayList<Location>();
		JSONArray json = new JSONArray();
		String searchString = str+"*";
		
		try{
		Location l = new Location();
		JSONArray json1 = new JSONArray();
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		Criteria c = new Criteria(new Column(COUNTRIES_JSON.TABLE,COUNTRIES_JSON.NAME),searchString,QueryConstants.LIKE,false);
		Criteria c1 = new Criteria(new Column(STATES_JSON.TABLE,STATES_JSON.NAME),searchString,QueryConstants.LIKE,false);
		Criteria c2 = new Criteria(new Column(CITIES_JSON.TABLE,CITIES_JSON.NAME),searchString,QueryConstants.LIKE,false);
		
		DataObject dobj = getRow(COUNTRIES_JSON.TABLE,c,20);
		json1 = Country.getCountriesJsonFromDobj(dobj);
		for(int i = 0; i < json1.length(); i++){
			json.put(json1.getJSONObject(i));
		}
		
		Join join = new Join( STATES_JSON.TABLE,COUNTRIES_JSON.TABLE,new String[]{STATES_JSON.COUNTRY_ID},new String[]{COUNTRIES_JSON.ID},Join.INNER_JOIN);
		dobj = getRow(STATES_JSON.TABLE,c1,join,20);
		json1 = Country.getStatesAndCountriesFromDataObject(dobj);
		for(int i = 0; i < json1.length(); i++){
			json.put(json1.getJSONObject(i));
		}
		
		Join join1 = new Join( CITIES_JSON.TABLE,STATES_JSON.TABLE,new String[]{CITIES_JSON.STATE_ID},new String[]{STATES_JSON.ID},Join.INNER_JOIN);
		dobj = getRow(CITIES_JSON.TABLE,c2,new Join[]{join1,join},20);
		json1 = Country.getCitiesAndStatesAndCountriesFromDataObject(dobj);
		for(int i = 0; i < json1.length(); i++){
			json.put(json1.getJSONObject(i));
		}
		ZABUtil.setDBSpace(existingDBSpace);
		l.setJsonArray(json);
		l.setSuccess(Boolean.TRUE);
		location.add(l);
		
		} catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		
		return location;
	}

}



//try{
//String st = ZABUtil.getResponseStrFromURL("https://raw.githubusercontent.com/hiiamrohit/Countries-States-Cities-database/master/countries.json");
//JSONObject json = new JSONObject(st);
//JSONArray array = json.getJSONArray("countries");
//for(int i = 0; i < array.length(); i++){
//	JSONObject innerjson = array.getJSONObject(i);
//	HashMap<String,String> hs = new HashMap<String,String>();
//	hs.put(LocationConstants.ID, innerjson.getString(LocationConstants.ID));
//	hs.put(LocationConstants.NAME, innerjson.getString(LocationConstants.NAME));
//	hs.put(LocationConstants.SORTNAME, innerjson.getString(LocationConstants.SORTNAME));
//	createRow(LocationConstants.COUNTRY_TABLE,COUNTRIES_JSON.TABLE,hs);
//}
//
//String st1 = ZABUtil.getResponseStrFromURL("https://raw.githubusercontent.com/hiiamrohit/Countries-States-Cities-database/master/states.json");
//JSONObject json1 = new JSONObject(st1);
//JSONArray array1 = json1.getJSONArray("states");
//for(int i = 0; i < array1.length(); i++){
//	JSONObject innerjson = array1.getJSONObject(i);
//	HashMap<String,String> hs = new HashMap<String,String>();
//	hs.put(LocationConstants.ID, innerjson.getString(LocationConstants.ID));
//	hs.put(LocationConstants.NAME, innerjson.getString(LocationConstants.NAME));
//	if(innerjson.getString(LocationConstants.ID).equals("2181")){
//		hs.put(LocationConstants.COUNTRY_ID, "124");
//	}else {
//			hs.put(LocationConstants.COUNTRY_ID, innerjson.getString(LocationConstants.COUNTRY_ID));
//	}
//	createRow(LocationConstants.STATE_TABLE,STATES_JSON.TABLE,hs);
//}
//
//String st2 = ZABUtil.getResponseStrFromURL("https://raw.githubusercontent.com/hiiamrohit/Countries-States-Cities-database/master/cities.json");
//JSONObject json2 = new JSONObject(st2);
//JSONArray array2 = json2.getJSONArray("cities");
//for(int i = 0; i < array2.length(); i++){
//	JSONObject innerjson = array2.getJSONObject(i);
//	HashMap<String,String> hs = new HashMap<String,String>();
//	hs.put(LocationConstants.ID, innerjson.getString(LocationConstants.ID));
//	hs.put(LocationConstants.NAME, innerjson.getString(LocationConstants.NAME));
//	if(innerjson.getString(LocationConstants.ID).equals("2321")){
//		hs.put(LocationConstants.STATE_ID, "21");
//	}
//	else if(innerjson.getString(LocationConstants.ID).equals("4478")){
//		hs.put(LocationConstants.STATE_ID, "36");
//	}
//	else if(innerjson.getString(LocationConstants.ID).equals("6628")){
//		hs.put(LocationConstants.STATE_ID, "269");
//	}
//	else if(innerjson.getString(LocationConstants.ID).equals("8720")){
//		hs.put(LocationConstants.STATE_ID, "516");
//	}
//	else if(innerjson.getString(LocationConstants.ID).equals("10717")){
//		hs.put(LocationConstants.STATE_ID, "673");
//	}
//	else if(innerjson.getString(LocationConstants.ID).equals("12819")){
//		hs.put(LocationConstants.STATE_ID, "781");
//	}
//	else if(innerjson.getString(LocationConstants.ID).equals("14848")){
//		hs.put(LocationConstants.STATE_ID, "936");
//	}
//	else if(innerjson.getString(LocationConstants.ID).equals("16908")){
//		hs.put(LocationConstants.STATE_ID, "1162");
//	}
//	else if(innerjson.getString(LocationConstants.ID).equals("18749")){
//		hs.put(LocationConstants.STATE_ID, "1357");
//	}
//	else if(innerjson.getString(LocationConstants.ID).equals("20677")){
//		hs.put(LocationConstants.STATE_ID, "1491");
//	}
//	else if(innerjson.getString(LocationConstants.ID).equals("22587")){
//		hs.put(LocationConstants.STATE_ID, "1826");
//	}
//	else if(innerjson.getString(LocationConstants.ID).equals("24462")){
//		hs.put(LocationConstants.STATE_ID, "1930");
//	}
//	else if(innerjson.getString(LocationConstants.ID).equals("26476")){
//		hs.put(LocationConstants.STATE_ID, "2236");
//	}
//	else if(innerjson.getString(LocationConstants.ID).equals("28354")){
//		hs.put(LocationConstants.STATE_ID, "2442");
//	}
//	else if(innerjson.getString(LocationConstants.ID).equals("30256")){
//		hs.put(LocationConstants.STATE_ID, "2594");
//	}
//	else if(innerjson.getString(LocationConstants.ID).equals("32239")){
//		hs.put(LocationConstants.STATE_ID, "2848");
//	}
//	else if(innerjson.getString(LocationConstants.ID).equals("34196")){
//		hs.put(LocationConstants.STATE_ID, "2950");
//	}
//	else if(innerjson.getString(LocationConstants.ID).equals("36162")){
//		hs.put(LocationConstants.STATE_ID, "2986");
//	}
//	else if(innerjson.getString(LocationConstants.ID).equals("38097")){
//		hs.put(LocationConstants.STATE_ID, "3244");
//	}
//	else if(innerjson.getString(LocationConstants.ID).equals("40027")){
//		hs.put(LocationConstants.STATE_ID, "3634");
//	}
//	else if(innerjson.getString(LocationConstants.ID).equals("41994")){
//		hs.put(LocationConstants.STATE_ID, "3842");
//	}
//	else if(innerjson.getString(LocationConstants.ID).equals("43877")){
//		hs.put(LocationConstants.STATE_ID, "3930");
//	}
//	else if(innerjson.getString(LocationConstants.ID).equals("45777")){
//		hs.put(LocationConstants.STATE_ID, "3959");
//	}
//	else if(innerjson.getString(LocationConstants.ID).equals("47576")){
//		hs.put(LocationConstants.STATE_ID, "4120");
//	}
//	else if(innerjson.getString(LocationConstants.ID).equals("48314")){
//		hs.put(LocationConstants.STATE_ID, "3976");
//	}
//	else {
//		hs.put(LocationConstants.STATE_ID, innerjson.getString(LocationConstants.STATE_ID));
//	}
//	createRow(LocationConstants.CITIES_TABLE,CITIES_JSON.TABLE,hs);
//}
//}catch(Exception e){
//	
//}