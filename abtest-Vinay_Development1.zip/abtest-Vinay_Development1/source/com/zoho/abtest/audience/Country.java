//$Id$
package com.zoho.abtest.audience;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONObject;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.CITIES_JSON;
import com.zoho.abtest.COUNTRIES_JSON;
import com.zoho.abtest.STATES_JSON;
import com.zoho.abtest.common.ZABModel;

public class Country extends ZABModel {
	
	private static final Logger LOGGER = Logger.getLogger(Country.class.getName());

	private String id;
	private String name;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public static Country getCountryFromRow(Row row) {
		Country c = new Country();
		c.setId((String)row.get(COUNTRIES_JSON.ID));
		c.setName((String)row.get(COUNTRIES_JSON.NAME));
		return c;
	}
	
	public static ArrayList<Country> getCountriesFromDobj(DataObject dobj) throws DataAccessException
	{
		ArrayList<Country> countries=new ArrayList<Country>();
		if(dobj.containsTable(COUNTRIES_JSON.TABLE)) {
			Iterator it = dobj.getRows(COUNTRIES_JSON.TABLE);
			while(it.hasNext()) {
				Row row = (Row)it.next();
				Country c = getCountryFromRow(row);
				countries.add(c);
			}
		}
		return countries;
	}

	public static JSONArray getCountriesJsonFromDobj(DataObject dobj) throws DataAccessException
	{
		JSONArray array=new JSONArray();
		try{
		if(dobj.containsTable(COUNTRIES_JSON.TABLE)) {
			Iterator it = dobj.getRows(COUNTRIES_JSON.TABLE);
			while(it.hasNext()) {
				Row row = (Row)it.next();
				JSONObject json = new JSONObject();
				json.put(LocationConstants.TEXT,(String)row.get(COUNTRIES_JSON.NAME));
				array.put(json);
			}
		}
		} catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		return array;
	}
	
	public static JSONArray getStatesAndCountriesFromDataObject(DataObject dobj) throws DataAccessException{
		JSONArray array=new JSONArray();
		try{
		if(dobj.containsTable(COUNTRIES_JSON.TABLE)&&dobj.containsTable(STATES_JSON.TABLE)) {
			Iterator it = dobj.getRows(STATES_JSON.TABLE);
			while(it.hasNext()) {
				Row row = (Row)it.next();
				String state = (String)row.get(STATES_JSON.NAME);
				String country="";

				Long  countryId = (Long)row.get(STATES_JSON.COUNTRY_ID);
				Criteria c = new Criteria(new Column(COUNTRIES_JSON.TABLE,COUNTRIES_JSON.ID),countryId,QueryConstants.EQUAL);

				Iterator it1 = dobj.getRows(COUNTRIES_JSON.TABLE,c);
				if(it1.hasNext()){
					Row row1 = (Row)it1.next();
					country = (String)row1.get(COUNTRIES_JSON.NAME);
				}
				
				String combined = state+","+country;
				JSONObject json = new JSONObject();
				json.put(LocationConstants.TEXT,combined);
				array.put(json);
			}
		}
		} catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		return array;
	}
	
	public static JSONArray getCitiesAndStatesAndCountriesFromDataObject(DataObject dobj)throws DataAccessException{
		JSONArray array=new JSONArray();
		try{
		if(dobj.containsTable(COUNTRIES_JSON.TABLE)&&dobj.containsTable(STATES_JSON.TABLE)&&dobj.containsTable(CITIES_JSON.TABLE)) {
			Iterator it = dobj.getRows(CITIES_JSON.TABLE);
			while(it.hasNext()) {
				Row row = (Row)it.next();
				String city = (String)row.get(CITIES_JSON.NAME);
				String country="";
				String state = "";

				Long stateId = (Long)row.get(CITIES_JSON.STATE_ID);
				Long countryId =  (Long)row.get(CITIES_JSON.COUNTRY_ID);
				
				Criteria c = new Criteria(new Column(COUNTRIES_JSON.TABLE,COUNTRIES_JSON.ID),countryId,QueryConstants.EQUAL);
				Criteria c1 = new Criteria(new Column(STATES_JSON.TABLE,STATES_JSON.ID),stateId,QueryConstants.EQUAL);

				Iterator it1 = dobj.getRows(COUNTRIES_JSON.TABLE,c);
				if(it1.hasNext()){
					Row row1 = (Row)it1.next();
					country = (String)row1.get(COUNTRIES_JSON.NAME);
				}
				
				Iterator it2 = dobj.getRows(STATES_JSON.TABLE,c1);
				if(it2.hasNext()){
					Row row1 = (Row)it2.next();
					state = (String)row1.get(STATES_JSON.NAME);
				}
				
				String combined = city+","+state+","+country;
				JSONObject json = new JSONObject();
				json.put(LocationConstants.TEXT,combined);
				array.put(json);
			}
		}
		} catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		return array;
	}
	
	
	public static JSONArray getCountry(ArrayList<Country> country){
		JSONArray array = new JSONArray();
		try{
		for(int i = 0; i < country.size(); i++){
			Country c = country.get(i);
			JSONObject json = new JSONObject();
			json.put(LocationConstants.ID, c.getId());
			json.put(LocationConstants.NAME, c.getName());
			array.put(json);
		}
		}catch(Exception e){
		LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		return array;
	}
}
