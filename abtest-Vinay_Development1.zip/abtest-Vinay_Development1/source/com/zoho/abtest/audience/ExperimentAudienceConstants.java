//$Id$
package com.zoho.abtest.audience;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.zoho.abtest.EXPERIMENT_AUDIENCE;
import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.ZABConstants;

public class ExperimentAudienceConstants {
	public static final String API_MODULE = "experimentaudience"; //No I18N
	
	public static final String API_RESOURCE = "resource.experimentaudience"; //NO I18N
	
	public static final String API_RESOURCE_INITIAL = "resource.experimentaudience.initial"; //NO I18N
	
	public static final String EXPERIMENT_AUDIENCE_ID = "experiment_audience_id"; //No I18N
	
	public static final String EXPERIMENT_ID = "experiment_id"; //NO I18N
	
	public static final String AUDIENCE_ID = "audience_id"; //No I18N
	
	public static final String AUDIENCE_LINK_NAME = "audience_link_name"; //No I18N
	
	
	public final static List<Constants> EXPERIMENT_AUDIENCE_TABLE;
	static{
		ArrayList<Constants> list = new ArrayList<Constants>();
		list.add(new Constants(EXPERIMENT_AUDIENCE_ID,EXPERIMENT_AUDIENCE.EXPERIMENT_AUDIENCE_ID,ZABConstants.LONG,Boolean.TRUE));
		list.add(new Constants(EXPERIMENT_ID,EXPERIMENT_AUDIENCE.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE));
		list.add(new Constants(AUDIENCE_ID,EXPERIMENT_AUDIENCE.AUDIENCE_ID,ZABConstants.LONG,Boolean.TRUE));
		EXPERIMENT_AUDIENCE_TABLE = (List<Constants>) Collections.unmodifiableList(list);
	}

	
}
