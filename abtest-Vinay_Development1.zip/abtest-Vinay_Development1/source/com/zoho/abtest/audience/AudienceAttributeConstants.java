//$Id$
package com.zoho.abtest.audience;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.zoho.abtest.ATTRIBUTE_MATCHTYPE_MAPPING;
import com.zoho.abtest.AUDIENCE_ATTRIBUTE;
import com.zoho.abtest.AUDIENCE_ATTRIBUTE_MATCHTYPE;
import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.sessionrecording.SessionReportConstants;

public class AudienceAttributeConstants {
	
	public static final String API_MODULE = "audienceattributes"; //No I18N
	
	public static final String API_RESOURCE = "resource.audienceattributes"; //NO I18N
	
	public static final String API_RESOURCE_INITIAL = "resource.audienceattributes.initial"; //NO I18N
	
	public static final String ATTRIBUTE_ID = "attribute_id"; //No I18N
	
	public static final String ATTRIBUTE_DISPLAYNAME = "attribute_displayname"; //NO I18N
	
	public static final String ATTRIBUTE_KEYNAME = "attribute_keyname"; //NO I18N
	
	public static final String ATTRIBUTE_DESCRIPTION = "attribute_description"; //NO I18N
	
	public static final String IS_DYNAMIC_ATTRIBUTE = "is_dynamic_attribute"; //No I18N
	
	public static final String ATTRIBUTE_META = "attribute_meta"; //NO I18N
	
	public static final String ATTRIBUTE_MATCHTYPE_ID = "attribute_matchtype_id"; //No I18N
		
	public static final String ATTRIBUTE_MATCHTYPE_NAME = "attribute_matchtype_name"; //No I18N
	
	public static final String DIMENSION_DETAILS = "dimension_details"; //No I18N
	
	public static final String MATCH_TYPE = "match_type"; //No I18N
	
	public static final String ATTRIBUTE_VALUE = "attribute_vlist"; //No I18N
	
	public static final String FOR_EXPERIMENT_REPORT = "for_experiment_report"; //No I18N
	
	public static enum AudienceAttributeMatchTypes {
		EQUALS(1, "audience.matchtype.equals"), //NO I18N
		NOT_EQUALS(2, "audience.matchtype.notequals"), //NO I18N
		CONTAINS(3, "audience.matchtype.contains"), //NO I18N
		DOESNOT_CONTAINS(4, "audience.matchtype.notcontains"), //NO I18N
		IS_EMPTY(5, "audience.matchtype.isempty"), //NO I18N
		ISNOT_EMPTY(6, "audience.matchtype.isnotempty"), //NO I18N
		IS_UNDEFINED(7, "audience.matchtype.isundefined"), //NO I18N
		REGEX(8, "audience.matchtype.regex"), //NO I18N
		STARTS_WITH(9, "audience.matchtype.startswith"), //NO I18N
		ENDS_WITH(10, "audience.matchtype.endswith"), //NO I18N
		LESSTHAN(11, "audience.matchtype.lessthan"), //NO I18N
		MORETHAN(12, "audience.matchtype.morethan"), //NO I18N
		BETWEEN(13, "audience.matchtype.between"), //NO I18N
		HASANY(14, "audience.matchtype.hasany"); //NO I18N
		
		private Integer typeId;
		
		private String displayKey;
		
		AudienceAttributeMatchTypes(Integer typeId, String displayKey) {
			this.typeId = typeId;
			this.displayKey = displayKey;
		}

		public Integer getTypeId() {
			return typeId;
		}

		public String getDisplayKey() {
			return displayKey;
		}
		
		public String getDisplayName() {
			return ZABAction.getMessage(this.displayKey);
		}
		
		public static AudienceAttributeMatchTypes getAudienceMatchTypeById(Integer id) {
			for(AudienceAttributeMatchTypes attr: AudienceAttributeMatchTypes.values()) {
				if(id!=null && attr.getTypeId().equals(id)) {
					return attr;
				}
			}
			return null;
		}
		
	}
	
	public static enum AudienceAttributes {
		
		CURRENT_URL(1, "audience.attribute.current_url.name", "current_url", " ", Boolean.FALSE.toString()), //NO I18N
		REFERRAL_URL(2, "audience.attribute.referral_url.name", "referral_url", " ", Boolean.FALSE.toString()),//NO I18N
		QUERY_PARAMETER(5, "audience.attribute.query_parameter.name", "query_parameter", " ", Boolean.TRUE.toString()),//NO I18N
		SOURCE(19, "audience.attribute.source.name", "source", " ", Boolean.FALSE.toString()),//NO I18N
		LOCATION(11, "audience.attribute.location.name", "location", " ", Boolean.FALSE.toString()),//NO I18N
		VISITOR_TYPE(3, "audience.attribute.visitor_type.name", "visitor_type", " ", Boolean.FALSE.toString()),//NO I18N
		DEVICE(7, "audience.attribute.device.name", "device", " ", Boolean.FALSE.toString()),//NO I18N
		BROWSER(9, "audience.attribute.browser.name", "browser", " ", Boolean.FALSE.toString()),//NO I18N
		OS(6, "audience.attribute.os.name", "os", " ", Boolean.FALSE.toString()),//NO I18N
		DAY_OF_WEEK(12, "audience.attribute.day_of_week.name", "day_of_week", " ", Boolean.FALSE.toString()),//NO I18N
		HOUR_OF_THE_DAY(13, "audience.attribute.hour_of_the_day.name", "hour_of_the_day", " ", Boolean.FALSE.toString()),//NO I18N
		
		
		COOKIE_VALUE(4, "audience.attribute.cookie_value.name", "cookie_value", " ", Boolean.TRUE.toString()),//NO I18N
		MOBILE_OS(8, "audience.attribute.mobile_os.name", "mobile_os", " ", Boolean.FALSE.toString()),//NO I18N
		USERAGENT(10, "audience.attribute.useragent.name", "useragent", " ", Boolean.FALSE.toString()),//NO I18N
		JS_VARIABLE(14, "audience.attribute.js_variable.name", "js_variable", " ", Boolean.TRUE.toString()),//NO I18N
		CUSTOM_DIMENSION(15, "audience.attribute.custom_dimension.name", "custom_dimension", " ", Boolean.TRUE.toString()),//NO I18N
		ADWORDS_CAMPAIGN(16, "audience.attribute.adwords_campaign.name", "adwords_campaign", " ", Boolean.FALSE.toString()),//NO I18N
		ADWORDS_GROUP(17, "audience.attribute.adwords_group.name", "adwords_group", " ", Boolean.FALSE.toString()),//NO I18N
		//AD_CAMPAIGN(18, "audience.attribute.ad_campaign.name", "ad_campaign", " ", Boolean.FALSE.toString()),//NO I18N
		
		GOALS(20, "audience.attribute.goals.name", SessionReportConstants.GOALS, " ", Boolean.FALSE.toString());//NO I18N
		
		
		private Integer audienceAttrId;
		
		private String displayNameKey;
		
		private String keyName;
		
		
		private String descriptionKey;
		
		private String isDynamicAttribute;
		
		AudienceAttributes(Integer attributeId, String displayName, String keyname, String desc, String isDynamicAttr) {
			this.audienceAttrId = attributeId;
			this.displayNameKey = displayName;
			this.keyName = keyname;
			this.descriptionKey = desc;
			this.isDynamicAttribute = isDynamicAttr;
		}

		public static AudienceAttributes getAudienceAttributeById(Integer id) {
			for(AudienceAttributes attr: AudienceAttributes.values()) {
				if(id!=null && attr.getAudienceAttrId().equals(id)) {
					return attr;
				}
			}
			return null;
		}
		
		public Integer getAudienceAttrId() {
			return audienceAttrId;
		}

		public String getDisplayName() {
			return ZABAction.getMessage(this.displayNameKey);
		}

		public String getKeyName() {
			return keyName;
		}

		public void setKeyName(String keyName) {
			this.keyName = keyName;
		}

		public String getDescription() {
			return ZABAction.getMessage(this.descriptionKey);
		}
		
		public String getIsDynamicAttribute() {
			return isDynamicAttribute;
		}
		
		public ArrayList<AudienceAttributeMatchTypes> getMatchTypes() {
			ArrayList<AudienceAttributeMatchTypes> matchTypes = new ArrayList<AudienceAttributeMatchTypes>();
			switch(this) {
			//case AD_CAMPAIGN:
			case COOKIE_VALUE:
			case QUERY_PARAMETER:
				matchTypes.add(AudienceAttributeMatchTypes.EQUALS);
				matchTypes.add(AudienceAttributeMatchTypes.NOT_EQUALS);
				matchTypes.add(AudienceAttributeMatchTypes.IS_EMPTY);
				matchTypes.add(AudienceAttributeMatchTypes.ISNOT_EMPTY);
				break;
			case CUSTOM_DIMENSION:
			case SOURCE:
			case VISITOR_TYPE:
			case OS:
			case DEVICE:
			case MOBILE_OS:
			case BROWSER:
			case LOCATION:
			case DAY_OF_WEEK:
			case HOUR_OF_THE_DAY:
				matchTypes.add(AudienceAttributeMatchTypes.EQUALS);
				matchTypes.add(AudienceAttributeMatchTypes.NOT_EQUALS);
				break;
			case CURRENT_URL:
			case REFERRAL_URL:
			case USERAGENT:
				matchTypes.add(AudienceAttributeMatchTypes.EQUALS);
				matchTypes.add(AudienceAttributeMatchTypes.NOT_EQUALS);
				matchTypes.add(AudienceAttributeMatchTypes.CONTAINS);
				matchTypes.add(AudienceAttributeMatchTypes.DOESNOT_CONTAINS);
				break;
			case JS_VARIABLE:
				matchTypes.add(AudienceAttributeMatchTypes.EQUALS);
				matchTypes.add(AudienceAttributeMatchTypes.NOT_EQUALS);
				matchTypes.add(AudienceAttributeMatchTypes.IS_EMPTY);
				matchTypes.add(AudienceAttributeMatchTypes.ISNOT_EMPTY);
				matchTypes.add(AudienceAttributeMatchTypes.IS_UNDEFINED);
				break;
			case ADWORDS_GROUP:
			case ADWORDS_CAMPAIGN:	
				matchTypes.add(AudienceAttributeMatchTypes.EQUALS);
				matchTypes.add(AudienceAttributeMatchTypes.NOT_EQUALS);
				matchTypes.add(AudienceAttributeMatchTypes.HASANY);
				break;
			default:
				matchTypes.add(AudienceAttributeMatchTypes.EQUALS);
				matchTypes.add(AudienceAttributeMatchTypes.NOT_EQUALS);
				break;
			}
			return matchTypes;
			
		}

	}
	
	public final static List<Constants> AUDIENCE_ATTRIBUTE_TABLE;
	static{
		ArrayList<Constants> list = new ArrayList<Constants>();
		list.add(new Constants(ATTRIBUTE_ID,AUDIENCE_ATTRIBUTE.ATTRIBUTE_ID,ZABConstants.INTEGER,Boolean.TRUE));
		list.add(new Constants(ATTRIBUTE_DISPLAYNAME,AUDIENCE_ATTRIBUTE.ATTRIBUTE_DISPLAY_NAME,ZABConstants.STRING,Boolean.TRUE));
		list.add(new Constants(ATTRIBUTE_KEYNAME,AUDIENCE_ATTRIBUTE.ATTRIBUTE_KEY_NAME,ZABConstants.STRING,Boolean.TRUE));
		list.add(new Constants(ATTRIBUTE_DESCRIPTION,AUDIENCE_ATTRIBUTE.ATTRIBUTE_DESCRIPTION,ZABConstants.STRING,Boolean.TRUE));
		list.add(new Constants(IS_DYNAMIC_ATTRIBUTE,AUDIENCE_ATTRIBUTE.IS_DYNAMIC_ATTRICUTE,ZABConstants.BOOLEAN,Boolean.FALSE));
		AUDIENCE_ATTRIBUTE_TABLE = (List<Constants>) Collections.unmodifiableList(list);
	}

	public final static List<Constants> AUDIENCE_ATTRIBUTE_MATCHTYPE_TABLE;
	static{
		ArrayList<Constants> list = new ArrayList<Constants>();
		list.add(new Constants(ATTRIBUTE_MATCHTYPE_ID,AUDIENCE_ATTRIBUTE_MATCHTYPE.MATCHTYPE_ID,ZABConstants.INTEGER,Boolean.TRUE));
		list.add(new Constants(ATTRIBUTE_MATCHTYPE_NAME,AUDIENCE_ATTRIBUTE_MATCHTYPE.MATCHTYPE_NAME,ZABConstants.STRING,Boolean.TRUE));
		AUDIENCE_ATTRIBUTE_MATCHTYPE_TABLE = (List<Constants>) Collections.unmodifiableList(list);
	}
	
	public final static List<Constants> ATTRIBUTE_MATCHTYPE_MAPPING_TABLE;
	static{
		ArrayList<Constants> list = new ArrayList<Constants>();
		list.add(new Constants(ATTRIBUTE_ID,ATTRIBUTE_MATCHTYPE_MAPPING.ATTRIBUTE_ID,ZABConstants.INTEGER,Boolean.TRUE));
		list.add(new Constants(ATTRIBUTE_MATCHTYPE_ID,ATTRIBUTE_MATCHTYPE_MAPPING.MATCHTYPE_ID,ZABConstants.INTEGER,Boolean.TRUE));
		ATTRIBUTE_MATCHTYPE_MAPPING_TABLE = (List<Constants>) Collections.unmodifiableList(list);
	}
}
