//$Id$
package com.zoho.abtest.audience;

import java.util.ArrayList;
import java.util.HashMap;

import com.adventnet.persistence.DataObject;
import com.zoho.abtest.PROJECT_AUDIENCE;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.Row;


public class ProjectAudience extends ZABModel{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final Logger LOGGER = Logger.getLogger(Audience.class.getName());
	
	private Long projectId;
	private Long experimentAudienceId;
	private Long audienceId;
	private String audienceLinkName;

	public Long getProjectId() {
		return projectId;
	}

	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}

	public Long getAudienceId() {
		return audienceId;
	}

	public void setAudienceId(Long audienceId) {
		this.audienceId = audienceId;
	}

	public String getAudienceLinkName() {
		return audienceLinkName;
	}

	public void setAudienceLinkName(String audienceLinkName) {
		this.audienceLinkName = audienceLinkName;
	}

	public Long getProjectAudienceId() {
		return experimentAudienceId;
	}

	public void setProjectAudienceId(Long experimentAudienceId) {
		this.experimentAudienceId = experimentAudienceId;
	}
	
	
	public static ArrayList<ProjectAudience> createProjectAudience(HashMap<String, String> hs) {
		ArrayList<ProjectAudience> audiences = new ArrayList<ProjectAudience>();
		try {
			
			createRow(ProjectAudienceConstants.PROJECT_AUDIENCE_TABLE, PROJECT_AUDIENCE.TABLE, hs);
			Long audienceId = Long.parseLong(hs.get(ExperimentAudienceConstants.AUDIENCE_ID));
			audiences.add(getProjectAudienceByAudienceId(audienceId));
			//Trigger event 
			/*ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
			wrapper.setModel(audiences.get(0));
			wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
			wrapper.setType(OperationType.CREATE);
			ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);
			
			//Event Activity Log
			HashMap<String, String> updatedValues = new HashMap<String, String>();
			Long experimentId = Long.valueOf(hs.get(ExperimentAudienceConstants.EXPERIMENT_ID));
			updatedValues.put(EventActivityConstants.EXPERIMENT_ID, experimentId.toString());
			updatedValues.put(EventActivityConstants.USER_ID, ZABUtil.getCurrentUser().getUserId().toString());
			updatedValues.put(EventActivityConstants.TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
			updatedValues.put(AudienceConstants.AUDIENCE_ID, audienceId.toString());
			EventActivityWrapper activityWrapper = new EventActivityWrapper();
			activityWrapper.setModule(Module.EXPERIMENT_AUDIENCE);
			activityWrapper.setOperationType(com.zoho.abtest.eventactivity.EventActivityConstants.OperationType.CREATE);
			activityWrapper.setDbSpace(ZABUtil.getCurrentUserDbSpace());
			activityWrapper.setUpdatedValues(updatedValues);
			ZABNotifier.notifyListeners(EventActivityConstants.EVENT_MODULE_NAME, activityWrapper);*/
			
		} catch (Exception e) {
			
			ProjectAudience audience = new ProjectAudience();
			audience.setSuccess(Boolean.FALSE);
			audience.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			audiences.add(audience);
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return audiences;
	}
	
	public static ProjectAudience getProjectAudienceByAudienceId(Long audienceid) {
		ProjectAudience audience = null;
		
		try {
			Criteria c = new Criteria(new Column(PROJECT_AUDIENCE.TABLE, PROJECT_AUDIENCE.AUDIENCE_ID), audienceid, QueryConstants.EQUAL);
			DataObject dobj = getRow(PROJECT_AUDIENCE.TABLE, c);
			if(dobj.containsTable(PROJECT_AUDIENCE.TABLE)) {
				Row row = dobj.getFirstRow(PROJECT_AUDIENCE.TABLE);
				audience = getProjectAudienceFromRow(row);
			}
			
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return audience;
	}
	
	public static ProjectAudience getProjectAudienceByExperimentId(Long projectid) {
		ProjectAudience audience = null;
		try {
			Criteria c = new Criteria(new Column(PROJECT_AUDIENCE.TABLE, PROJECT_AUDIENCE.PROJECT_ID), projectid, QueryConstants.EQUAL);
			DataObject dobj = getRow(PROJECT_AUDIENCE.TABLE, c);
			if(dobj.containsTable(PROJECT_AUDIENCE.TABLE)) {
				Row row = dobj.getFirstRow(PROJECT_AUDIENCE.TABLE);
				audience = getProjectAudienceFromRow(row);
			}
			
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return audience;
	}
	
	/*public static ArrayList<Project> getRunningProjectForAudience(String audienceLinkname, Long projectId) {
		ArrayList<Project> projects = new ArrayList<Project>();
		try {
			Criteria c1 = new Criteria(new Column(PROJECT.TABLE, PROJECT.EXPERIMENT_STATUS), ExperimentStatus.RUNNING.getStatusCode(), QueryConstants.EQUAL);
			Criteria c2 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.PROJECT_ID), projectId, QueryConstants.EQUAL);
			Criteria c3 = new Criteria(new Column(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME), audienceLinkname, QueryConstants.EQUAL);
			Join join1=new Join(EXPERIMENT.TABLE,EXPERIMENT_AUDIENCE.TABLE,new String[]{EXPERIMENT.EXPERIMENT_ID},new String[]{EXPERIMENT_AUDIENCE.EXPERIMENT_ID},Join.INNER_JOIN);
			Join join2=new Join(EXPERIMENT_AUDIENCE.TABLE,AUDIENCE.TABLE,new String[]{EXPERIMENT_AUDIENCE.AUDIENCE_ID},new String[]{AUDIENCE.AUDIENCE_ID},Join.INNER_JOIN);
			DataObject dobj =getRow(EXPERIMENT.TABLE, c1.and(c2).and(c3), new Join[]{join1, join2});
			if(dobj.containsTable(EXPERIMENT.TABLE)) {
				experiments = Experiment.getExperimentFromDobj(dobj);
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return experiments;
	}*/
	
	public static ProjectAudience getProjectAudienceFromRow(Row row) {
		ProjectAudience audience = new ProjectAudience();
		audience.setAudienceId((Long)row.get(PROJECT_AUDIENCE.AUDIENCE_ID));
		
		Long audienceId = (Long)row.get(PROJECT_AUDIENCE.AUDIENCE_ID);
		String audienceLinkName = Audience.getAudienceLinkNameFromAudienceId(audienceId);
		audience.setAudienceLinkName(audienceLinkName);
		
		audience.setProjectId((Long)row.get(PROJECT_AUDIENCE.PROJECT_ID));
		audience.setProjectAudienceId((Long)row.get(PROJECT_AUDIENCE.PROJECT_AUDIENCE_ID));
		return audience;
	}
	
}
