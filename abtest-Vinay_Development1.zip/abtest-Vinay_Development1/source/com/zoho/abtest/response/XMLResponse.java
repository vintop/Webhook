//$Id$
package com.zoho.abtest.response;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;

import com.zoho.abtest.adminconsole.AdminConsole;
import com.zoho.abtest.adminconsole.AdminConsoleUserDetail;
import com.zoho.abtest.audience.Audience;
import com.zoho.abtest.audience.AudienceAttribute;
import com.zoho.abtest.audience.AudienceMatchType;
import com.zoho.abtest.audience.ExperimentAudience;
import com.zoho.abtest.audience.Location;
import com.zoho.abtest.audience.ProjectAudience;
import com.zoho.abtest.customevent.CustomEvent;
import com.zoho.abtest.customevent.CustomEventReports;
import com.zoho.abtest.dimension.CustomDimension;
import com.zoho.abtest.dimension.Dimension;
import com.zoho.abtest.dimension.DynamicAttributes;
import com.zoho.abtest.dimension.ExperimentDynamicAttribute;
import com.zoho.abtest.dynamicconf.DynamicConfiguration;
import com.zoho.abtest.elastic.ESQuickFilterStatistics;
import com.zoho.abtest.elastic.ESQuickFilterWrapper;
import com.zoho.abtest.elastic.adminconsole.ESAdminConsole;
import com.zoho.abtest.eventactivity.EventActivityLog;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.forms.Form;
import com.zoho.abtest.forms.FormDayWiseReport;
import com.zoho.abtest.forms.FormRawData;
import com.zoho.abtest.forms.FormReport;
import com.zoho.abtest.forms.FormResponse;
import com.zoho.abtest.funnel.FunnelStep;
import com.zoho.abtest.funnel.report.FunnelReport;
import com.zoho.abtest.funnel.report.FunnelTimelineReport;
import com.zoho.abtest.goal.Goal;
import com.zoho.abtest.goal.GoalReports;
import com.zoho.abtest.heatmaps.Heatmap;
import com.zoho.abtest.heatmaps.Scrollmap;
import com.zoho.abtest.image.ImageUpload;
import com.zoho.abtest.integration.GoogleAdwords;
import com.zoho.abtest.integration.GoogleAnalytics;
import com.zoho.abtest.integration.GoogleTagManager;
import com.zoho.abtest.integration.Integration;
import com.zoho.abtest.license.PortalLicenseMapping;
import com.zoho.abtest.misc.SampleSizeCalculator;
import com.zoho.abtest.portal.Portal;
import com.zoho.abtest.privacyconsent.Privacy;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.report.ChartReport;
import com.zoho.abtest.report.ReportRawData;
import com.zoho.abtest.report.ReportStatistics;
import com.zoho.abtest.revenue.RevenueChartReport;
import com.zoho.abtest.revenue.RevenueReport;
import com.zoho.abtest.script.CheckScript;
import com.zoho.abtest.search.Search;
import com.zoho.abtest.sessionrecording.SessionPage;
import com.zoho.abtest.sessionrecording.clipmeta.SessionRecordingClipMeta;
import com.zoho.abtest.sessionrecording.eventstream.SessionEventStream;
import com.zoho.abtest.sessionrecording.playlist.SessionPlayList;
import com.zoho.abtest.sessionrecording.playlist.SessionPlayListWrapper;
import com.zoho.abtest.tour.ZABTour;
import com.zoho.abtest.trigger.Trigger;
import com.zoho.abtest.user.ProjectUserRoleWrapper;
import com.zoho.abtest.user.Role;
import com.zoho.abtest.user.ZABUser;
import com.zoho.abtest.variation.Variation;
import com.zoho.abtest.webhook.Webhook;
import com.zoho.abtest.audience.Audience;
import com.zoho.abtest.audience.AudienceAttribute;
import com.zoho.abtest.audience.AudienceMatchType;
import com.zoho.abtest.audience.ExperimentAudience;
import com.zoho.abtest.audience.ProjectAudience;
import com.zoho.abtest.auditlog.AdminConsoleAuditLog;
import com.zoho.abtest.dimension.Dimension;
import com.zoho.abtest.dynamicconf.DynamicConfiguration;
import com.zoho.abtest.integration.GoogleAnalytics;
import com.zoho.abtest.integration.GoogleAdwords;
import com.zoho.abtest.integration.Integration;
import com.zoho.abtest.forms.Form;
import com.zoho.abtest.forms.FormDayWiseReport;
import com.zoho.abtest.forms.FormRawData;
import com.zoho.abtest.forms.FormReport;
import com.zoho.abtest.forms.FormResponse;
import com.zoho.abtest.experimentscount.*;


public class XMLResponse implements ResponseProvider {

	@Override
	public String getExceptionString(String exceptionString, String moduleName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getExperimentResponse(HttpServletRequest request,
			ArrayList<Experiment> experiments) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getVariationResponse(HttpServletRequest request,
			ArrayList<Variation> variations) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}


	public String getReportResponse(HttpServletRequest request,
			ArrayList<ReportStatistics> visitorReports) throws JSONException {
		
		return null;
	}

	@Override
	public String getProjectResponse(HttpServletRequest request,
			ArrayList<Project> projects) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getNotMemberOfApp() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public String getReportRawDataResponse(HttpServletRequest request, List<ReportRawData> reportRawDataList) throws Exception
	{
		return null;
	}

	@Override
	public String getGoalResponse(HttpServletRequest request,
			ArrayList<Goal> goals) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public String getAudienceResponse(HttpServletRequest request,
			ArrayList<Audience> audience) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public String getAudienceAttributeResponse(HttpServletRequest request,
			ArrayList<AudienceAttribute> audience_attribute) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public String getAudienceMatchTypeResponse(HttpServletRequest request,
			ArrayList<AudienceMatchType> audience_matchType) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getExperimentAudienceResponse(HttpServletRequest request,
			ArrayList<ExperimentAudience> experimentaudience) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public String getProjectAudienceResponse(HttpServletRequest request,
			ArrayList<ProjectAudience> projectaudience) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public String getInvalidInputFormatException(String moduleName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override

	public String getDimensionResponse(HttpServletRequest request,
			ArrayList<Dimension> dimension) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}

	public String getDynamicAttributesResponse(HttpServletRequest request,
			List<DynamicAttributes> dynamicAttributes) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getUserResponse(HttpServletRequest request,
			ArrayList<ZABUser> users) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}
	
	public String getCustomDimensionResponse(HttpServletRequest request,
			List<CustomDimension> customDimensions) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	
	public String getSampleSizeResponse(HttpServletRequest request,ArrayList<SampleSizeCalculator> audience) throws JSONException {
		
		return null;
	}

	@Override
	public String getExperimentDynamicAttributeResponse(
			HttpServletRequest request,
			List<ExperimentDynamicAttribute> experimentDynamicAttributes)
			throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCheckScriptResponse(HttpServletRequest request,
			CheckScript checkScript) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override

	public String getChartRpeortResponse(HttpServletRequest request,
			ArrayList<ChartReport> charts) throws JSONException {
		return null;
	}

	public String getEventActivityResponse(HttpServletRequest request,
			List<EventActivityLog> eventActivityList) throws JSONException {

		return null;
	}

	@Override
	public String getImageUploadResponse(HttpServletRequest request,
			ArrayList<ImageUpload> imageUploads) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getAccessDeniedResponse() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getProjectUserRoleResponse(HttpServletRequest request,
			List<ProjectUserRoleWrapper> projectUserRoleWrappers) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getRoleResponse(HttpServletRequest request, List<Role> roles)
			throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getHeatmapDataResponse(HttpServletRequest request,
			ArrayList<Heatmap> heatmapdata) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIntegrationResponse(HttpServletRequest request,
			ArrayList<Integration> integration) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	@Override
	public String getRevenueResponse(HttpServletRequest request,
			ArrayList<RevenueReport> revenueReports) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getRevenueChartRpeortResponse(HttpServletRequest request,
			ArrayList<RevenueChartReport> charts) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getPortalResponse(HttpServletRequest request,
			List<Portal> portals) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getNoSuchResourceResponse() {
		return null;
	}
	
	public String getPortalNotExistsException(String portalName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getUserNotPortalMemberException(String portalName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getExperimentEventActivityResponse(
			HttpServletRequest request, List<EventActivityLog> eventActivityList)
			throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getProjectEventActivityResponse(HttpServletRequest request,
			List<EventActivityLog> eventActivityList) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getUserEventActivityResponse(HttpServletRequest request,
			List<EventActivityLog> eventActivityList) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getSearchResponse(HttpServletRequest request, ArrayList<Search> search)
			throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getGoogleAnalyticsResponse(HttpServletRequest request,
			ArrayList<GoogleAnalytics> googleanalytics) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public String getGoogleAdwordsResponse(HttpServletRequest request,
			ArrayList<GoogleAdwords> googleadwords) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getGoogleTagManagerResponse(HttpServletRequest request,
			ArrayList<GoogleTagManager> googletagmanager) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	@Override
	public String getDynamicConfigurationResponse(HttpServletRequest request,
			List<DynamicConfiguration> dynamicConfs) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getESAdminConsoleResponse(HttpServletRequest request,
			ESAdminConsole esAdminConsole) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getESDefaultIndicesResponse(HttpServletRequest request)
			throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFunnelReportResponse(HttpServletRequest request,
			ArrayList<FunnelReport> funnelReports) throws JSONException {
		return null;
		
	}
	
	public String getScrollmapDataResponse(HttpServletRequest request,
			ArrayList<Scrollmap> scrollmapdata) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}
	

	@Override
	public String getFormResponse(HttpServletRequest request,
			ArrayList<Form> form) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}
	
	public String getFormResponse(HttpServletRequest request,
			JSONArray jsonarray) throws JSONException {
		return FormResponse.jsonResponse(request,jsonarray);
	}
	
    @Override
    public String getOrgNoAccessException() {
        // TODO Auto-generated method stub
        return null;
    }

	@Override
	public String getFunnelStepResponse(HttpServletRequest request,
			ArrayList<FunnelStep> steps) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFunnelReportTimelineResponse(HttpServletRequest request,
			ArrayList<FunnelTimelineReport> funnelReports) throws JSONException {
		return null;
	}

	public String getCustomEventResponse(HttpServletRequest request,
			ArrayList<CustomEvent> customevents) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getActivationAwaitedException() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getApplyAccessRequest() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getTourResponse(HttpServletRequest request,
			ArrayList<ZABTour> tours) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getAdminConsoleDashboardResponse(HttpServletRequest request,
			AdminConsole acObj) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getZohoOneTrialExpiredException(String redirectUrl) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getZohoOneUserDeactivatedException() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getPortalLicenseMappingResponse(HttpServletRequest request,
			ArrayList<PortalLicenseMapping> userLicenseMappingList)
			throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getQuickFilterSegmentVisitorResponse(
			HttpServletRequest request,
			List<ESQuickFilterStatistics> visitorReports) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getQuickFilterAttrResponse(HttpServletRequest request,
			List<ESQuickFilterWrapper> qfAttributes) throws JSONException {

		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getLocationResponse(HttpServletRequest request,
			ArrayList<Location> location) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getAdminConsolePortalList(HttpServletRequest request, AdminConsole acObj) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getAdminConsolePortalDetails(HttpServletRequest request, AdminConsole acObj) throws Exception {
		return null;
	}
	
	@Override
	public String getUsageStatsResponse(HttpServletRequest request, ArrayList<Project> projects) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFormDayWiseReportResponse(HttpServletRequest request,
			ArrayList<FormDayWiseReport> form) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getAttentionmapDataResponse(HttpServletRequest request,
			ArrayList<Scrollmap> attentionmapdata) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}
    
	public String getFormRawDataResponse(HttpServletRequest request,
			ArrayList<FormRawData> formrawdata) throws JSONException {
		// TODO Auto-generated method stub
		return null;
    }

	@Override
	public String getFormReportResponse(HttpServletRequest request,
			ArrayList<FormReport> formreport) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getSessionPlayLists(HttpServletRequest request,
			ArrayList<SessionPlayListWrapper> playLists) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getSessionRecordingClipMetas(HttpServletRequest request,
			ArrayList<SessionRecordingClipMeta> clipMetas) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getSessionPageDetails(HttpServletRequest request,
			ArrayList<SessionPage> pages) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getAdminConsoleAuditLogResponse(HttpServletRequest request,
			List<AdminConsoleAuditLog> auditLogList) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCustomEventReportResponse(HttpServletRequest request,
			ArrayList<CustomEventReports> customeventsreports) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getGoalReportResponse(HttpServletRequest request,
			ArrayList<GoalReports> goalreports) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getSuggestedNameList(HttpServletRequest request,
			AdminConsole adObj) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getPrivacyResponse(HttpServletRequest request,
			ArrayList<Privacy> privacy) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getACUserDetailsResponse(HttpServletRequest request,
			ArrayList<AdminConsoleUserDetail> lst) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public String getExperimentsCountresponse(HttpServletRequest request,
			ArrayList<ExperimentsCount> experimentscount) throws JSONException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getWebhookResponse(HttpServletRequest request,
			ArrayList<Webhook> webhooks) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getTriggerResponse(HttpServletRequest request,
			ArrayList<Trigger> webhooks) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getVariableResponse(HttpServletRequest request, ArrayList<String> variables) {
		// TODO Auto-generated method stub
		return null;
	}

}
