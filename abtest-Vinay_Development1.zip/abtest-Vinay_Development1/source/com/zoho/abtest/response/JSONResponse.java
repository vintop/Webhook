//$Id$
package com.zoho.abtest.response;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.adminconsole.AdminConsole;
import com.zoho.abtest.adminconsole.AdminConsoleResponse;
import com.zoho.abtest.adminconsole.AdminConsoleUserDetail;
import com.zoho.abtest.audience.Audience;
import com.zoho.abtest.audience.AudienceAttribute;
import com.zoho.abtest.audience.AudienceAttributeResponse;
import com.zoho.abtest.audience.AudienceMatchType;
import com.zoho.abtest.audience.AudienceMatchTypeResponse;
import com.zoho.abtest.audience.AudienceResponse;
import com.zoho.abtest.audience.ExperimentAudience;
import com.zoho.abtest.audience.ExperimentAudienceResponse;
import com.zoho.abtest.audience.Location;
import com.zoho.abtest.audience.LocationResponse;
import com.zoho.abtest.audience.ProjectAudience;
import com.zoho.abtest.audience.ProjectAudienceResponse;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.customevent.CustomEvent;
import com.zoho.abtest.customevent.CustomEventReportResponse;
import com.zoho.abtest.customevent.CustomEventReports;
import com.zoho.abtest.customevent.CustomEventResponse;
import com.zoho.abtest.dimension.CustomDimension;
import com.zoho.abtest.dimension.CustomDimensionResponse;
import com.zoho.abtest.dimension.Dimension;
import com.zoho.abtest.dimension.DimensionResponse;
import com.zoho.abtest.dimension.DynamicAttributeResponse;
import com.zoho.abtest.dimension.DynamicAttributes;
import com.zoho.abtest.dimension.ExperimentDynamicAttribute;
import com.zoho.abtest.dimension.ExperimentDynamicAttributeResponse;
import com.zoho.abtest.dynamicconf.DynamicConfiguration;
import com.zoho.abtest.dynamicconf.DynamicConfigurationResponse;
import com.zoho.abtest.elastic.ESQuickFilterAttrResponse;
import com.zoho.abtest.elastic.ESQuickFilterResponse;
import com.zoho.abtest.elastic.ESQuickFilterStatistics;
import com.zoho.abtest.elastic.ESQuickFilterWrapper;
import com.zoho.abtest.elastic.adminconsole.ESAdminConsole;
import com.zoho.abtest.elastic.adminconsole.ESAdminConsoleResponse;
import com.zoho.abtest.elastic.adminconsole.ESDefaultIndicesResponse;
import com.zoho.abtest.eventactivity.EventActivityConstants;
import com.zoho.abtest.eventactivity.EventActivityLog;
import com.zoho.abtest.eventactivity.EventActivityResponse;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentResponse;
import com.zoho.abtest.experimentscount.ExperimentsCount;
import com.zoho.abtest.experimentscount.ExperimentsCountResponse;
import com.zoho.abtest.forms.Form;
import com.zoho.abtest.forms.FormDayWiseReport;
import com.zoho.abtest.forms.FormDayWiseReportResponse;
import com.zoho.abtest.forms.FormRawData;
import com.zoho.abtest.forms.FormRawDataResponse;
import com.zoho.abtest.forms.FormReport;
import com.zoho.abtest.forms.FormReportResponse;
import com.zoho.abtest.forms.FormResponse;
import com.zoho.abtest.funnel.FunnelStep;
import com.zoho.abtest.funnel.FunnelStepResponse;
import com.zoho.abtest.funnel.report.FunnelReport;
import com.zoho.abtest.funnel.report.FunnelReportResponse;
import com.zoho.abtest.funnel.report.FunnelReportTimelineResponse;
import com.zoho.abtest.funnel.report.FunnelTimelineReport;
import com.zoho.abtest.goal.Goal;
import com.zoho.abtest.goal.GoalReportResponse;
import com.zoho.abtest.goal.GoalReports;
import com.zoho.abtest.goal.GoalResponse;
import com.zoho.abtest.heatmaps.AttentionmapDataResponse;
import com.zoho.abtest.heatmaps.Heatmap;
import com.zoho.abtest.heatmaps.HeatmapDataResponse;
import com.zoho.abtest.heatmaps.Scrollmap;
import com.zoho.abtest.heatmaps.ScrollmapDataResponse;
import com.zoho.abtest.image.ImageUpload;
import com.zoho.abtest.image.ImageUploadResponse;
import com.zoho.abtest.integration.GoogleAdwords;
import com.zoho.abtest.integration.GoogleAdwordsResponse;
import com.zoho.abtest.integration.GoogleAnalytics;
import com.zoho.abtest.integration.GoogleAnalyticsResponse;
import com.zoho.abtest.integration.GoogleTagManager;
import com.zoho.abtest.integration.GoogleTagManagerResponse;
import com.zoho.abtest.integration.Integration;
import com.zoho.abtest.integration.IntegrationResponse;
import com.zoho.abtest.license.PortalLicenseMapping;
import com.zoho.abtest.license.PortalLicenseMappingResponse;
import com.zoho.abtest.misc.SampleSizeCalculator;
import com.zoho.abtest.misc.SampleSizeCalculatorResponse;
import com.zoho.abtest.portal.Portal;
import com.zoho.abtest.portal.PortalResponse;
import com.zoho.abtest.privacyconsent.Privacy;
import com.zoho.abtest.privacyconsent.PrivacyResponse;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.project.ProjectResponse;
import com.zoho.abtest.report.ChartReport;
import com.zoho.abtest.report.ChartReportResponse;
import com.zoho.abtest.report.ReportRawData;
import com.zoho.abtest.report.ReportRawDataResponse;
import com.zoho.abtest.report.ReportResponse;
import com.zoho.abtest.report.ReportStatistics;
import com.zoho.abtest.revenue.RevenueChartReport;
import com.zoho.abtest.revenue.RevenueChartReportResponse;
import com.zoho.abtest.revenue.RevenueReport;
import com.zoho.abtest.revenue.RevenueResponse;
import com.zoho.abtest.script.CheckScript;
import com.zoho.abtest.script.CheckScriptResponse;
import com.zoho.abtest.search.Search;
import com.zoho.abtest.search.SearchResponse;
import com.zoho.abtest.sessionrecording.SessionPage;
import com.zoho.abtest.sessionrecording.SessionPageResponse;
import com.zoho.abtest.sessionrecording.clipmeta.SessionRecordingClipMeta;
import com.zoho.abtest.sessionrecording.clipmeta.SessionRecordingClipMetaResponse;
import com.zoho.abtest.sessionrecording.playlist.SessionPlayListResponse;
import com.zoho.abtest.sessionrecording.playlist.SessionPlayListWrapper;
import com.zoho.abtest.tour.ZABTour;
import com.zoho.abtest.tour.ZABTourResponse;
import com.zoho.abtest.trigger.Trigger;
import com.zoho.abtest.trigger.TriggerResponse;
import com.zoho.abtest.user.ProjectUserRoleResponse;
import com.zoho.abtest.user.ProjectUserRoleWrapper;
import com.zoho.abtest.user.Role;
import com.zoho.abtest.user.RoleResponse;
import com.zoho.abtest.user.ZABUser;
import com.zoho.abtest.user.ZABUserResponse;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.abtest.variable.VariableResponse;
import com.zoho.abtest.variation.Variation;
import com.zoho.abtest.variation.VariationResponse;
import com.zoho.abtest.webhook.Webhook;
import com.zoho.abtest.webhook.WebhookResponse;
import com.zoho.abtest.adminconsole.AdminConsole;
import com.zoho.abtest.adminconsole.AdminConsoleResponse;
import com.zoho.abtest.audience.Audience;
import com.zoho.abtest.audience.AudienceResponse;
import com.zoho.abtest.audience.AudienceAttribute;
import com.zoho.abtest.audience.AudienceAttributeResponse;
import com.zoho.abtest.audience.AudienceMatchType;
import com.zoho.abtest.audience.AudienceMatchTypeResponse;
import com.zoho.abtest.audience.ExperimentAudience;
import com.zoho.abtest.audience.ExperimentAudienceResponse;
import com.zoho.abtest.audience.Location;
import com.zoho.abtest.audience.LocationResponse;
import com.zoho.abtest.audience.ProjectAudience;
import com.zoho.abtest.audience.ProjectAudienceResponse;
import com.zoho.abtest.auditlog.AdminConsoleAuditLog;
import com.zoho.abtest.auditlog.AdminConsoleAuditLogResponse;
import com.zoho.abtest.auditlog.AuditLogConstants;
import com.zoho.abtest.dimension.Dimension;
import com.zoho.abtest.dimension.DimensionResponse;
import com.zoho.abtest.dynamicconf.DynamicConfiguration;
import com.zoho.abtest.dynamicconf.DynamicConfigurationResponse;
import com.zoho.abtest.integration.GoogleAnalytics;
import com.zoho.abtest.integration.GoogleAnalyticsResponse;
import com.zoho.abtest.integration.GoogleAdwords;
import com.zoho.abtest.integration.GoogleAdwordsResponse;
import com.zoho.abtest.integration.GoogleTagManager;
import com.zoho.abtest.integration.GoogleTagManagerResponse;
import com.zoho.abtest.integration.Integration;
import com.zoho.abtest.integration.IntegrationResponse;
import com.zoho.abtest.forms.Form;
import com.zoho.abtest.forms.FormDayWiseReport;
import com.zoho.abtest.forms.FormDayWiseReportResponse;
import com.zoho.abtest.forms.FormResponse;
import com.zoho.abtest.forms.FormRawData;
import com.zoho.abtest.forms.FormRawDataResponse;
import com.zoho.abtest.forms.FormReport;
import com.zoho.abtest.forms.FormReportResponse;

public class JSONResponse implements ResponseProvider {
	
	public String getNotMemberOfApp() {
		//TODO:

//		String email = "";
//		try{
//			Join join = new Join(APP_USER.TABLE,ROLES.TABLE,new String[]{APP_USER.ROLE_ID},new String[]{ROLES.ROLE_ID},Join.INNER_JOIN);
//			Criteria c = new Criteria(new Column(ROLES.TABLE,ROLES.ROLE_LINK_NAME),"super-admin",QueryConstants.EQUAL);//	NO I18N
//			DataObject userDobj = ZMModel.getRow(APP_USER.TABLE, c,join);
//			Iterator<?> userItr = userDobj.getRows(APP_USER.TABLE);
//			if(userItr.hasNext()){
//				Row r  = (Row)userItr.next();
//				 email =  (String) r.get(APP_USER.EMAIL_ADDRESS);
//				
//			}	
//		}catch(Exception e){
//			e.printStackTrace();
//		}
		
		return "{\""+ZABConstants.STATUS_CODE+"\":\""+ZABConstants.ErrorMessages.NOT_USER_OF_APP.getErrorCode()+"\",\""+ZABConstants.STATUS_STRING+"\":\"Please Contact Admin of the Organization \",\""+ZABConstants.COUNT+"\":0}";//No I18N
		
		
	}
	
	public String getPortalNotExistsException(String portalName){
		JSONObject json = new JSONObject();
		try
		{
			json.put(ZABConstants.STATUS_CODE, ZABConstants.ErrorMessages.PORTAL_NOT_EXISTS.getErrorCode());
			json.put(ZABConstants.STATUS_STRING, ZABAction.getMessage(ZABConstants.ErrorMessages.PORTAL_NOT_EXISTS.getErrorString(),new String[]{portalName}));
			json.put(ZABConstants.COUNT, 0);
		}
		catch(JSONException ex)
		{
			json = new JSONObject();
		}
		return json.toString();
	}
	
	public String getUserNotPortalMemberException(String portalName){
		JSONObject json = new JSONObject();
		try
		{
			json.put(ZABConstants.STATUS_CODE, ZABConstants.ErrorMessages.USER_NOT_PORTAL_MEMBER.getErrorCode());
			json.put(ZABConstants.STATUS_STRING, ZABAction.getMessage(ZABConstants.ErrorMessages.USER_NOT_PORTAL_MEMBER.getErrorString(),new String[]{portalName}));
			json.put(ZABConstants.COUNT, 0);
		}
		catch(JSONException ex)
		{
			json = new JSONObject();
		}
		return json.toString();
	}
	
	public String getZohoOneTrialExpiredException(String redirectUrl){
		JSONObject json = new JSONObject();
		try
		{
			json.put(ZABConstants.STATUS_CODE, ZABConstants.ErrorMessages.ZOHOONE_TRIAL_EXPIRED.getErrorCode());
			json.put(ZABConstants.STATUS_STRING, "");
			json.put(ZABConstants.REDIRECT_URL, redirectUrl);
			json.put(ZABConstants.COUNT, 0);
		}
		catch(JSONException ex)
		{
			json = new JSONObject();
		}
		return json.toString();
	}
	
	public String getZohoOneUserDeactivatedException(){
		JSONObject json = new JSONObject();
		try
		{
			json.put(ZABConstants.STATUS_CODE, ZABConstants.ErrorMessages.ZOHOONE_USER_DEACTIVATED.getErrorCode());
			json.put(ZABConstants.STATUS_STRING, ZABAction.getMessage(ZABConstants.ErrorMessages.ZOHOONE_USER_DEACTIVATED.getErrorString()));
			json.put(ZABConstants.COUNT, 0);
		}
		catch(JSONException ex)
		{
			json = new JSONObject();
		}
		return json.toString();
	}
	
	public String getOrgNoAccessException(){
		JSONObject json = new JSONObject();
		try
		{
			json.put(ZABConstants.STATUS_CODE, ZABConstants.ErrorMessages.ORG_NOACCESS.getErrorCode());
			//json.put(ZABConstants.STATUS_STRING, ZABAction.getMessage(ZABConstants.ErrorMessages.ORG_NOACCESS.getErrorString()));
			json.put(ZABConstants.STATUS_STRING, "Our Product access is not yet available to you. Kindly wait for the release."); //No I18N
			json.put(ZABConstants.COUNT, 0);
		}
		catch(JSONException ex)
		{
			json = new JSONObject();
		}
		return json.toString();
	}
	
	public String getActivationAwaitedException(){
		JSONObject json = new JSONObject();
		try
		{
			json.put(ZABConstants.STATUS_CODE, ZABConstants.ErrorMessages.ACTIVATION_AWAITED.getErrorCode());
			json.put(ZABConstants.STATUS_STRING, ZABAction.getMessage(ZABConstants.ErrorMessages.ACTIVATION_AWAITED.getErrorString()));
			//json.put(ZABConstants.STATUS_STRING, "Our Product access is not yet available to you. Kindly wait for the release."); //No I18N
			json.put(ZABConstants.COUNT, 0);
		}
		catch(JSONException ex)
		{
			json = new JSONObject();
		}
		return json.toString();
	}
	
	public String getApplyAccessRequest(){
		JSONObject json = new JSONObject();
		try
		{
			json.put(ZABConstants.STATUS_CODE, ZABConstants.ErrorMessages.APPLY_ACCESS_REQUEST.getErrorCode());
			json.put(ZABConstants.STATUS_STRING, ZABAction.getMessage(ZABConstants.ErrorMessages.APPLY_ACCESS_REQUEST.getErrorString()));
			//json.put(ZABConstants.STATUS_STRING, "Our Product access is not yet available to you. Kindly wait for the release."); //No I18N
			json.put(ZABConstants.COUNT, 0);
		}
		catch(JSONException ex)
		{
			json = new JSONObject();
		}
		return json.toString();
	}
	
	public String getInvalidInputFormatException(String moduleName){	
		String outString = "";
		try{
			Long endTime = ZABUtil.getCurrentTimeInMilliSeconds();
			Long startTime = (Long)ZABUtil.getCurrentRequest().getAttribute("RequestStartTime");
			JSONObject json = new JSONObject();
			json.put(ZABConstants.STATUS_CODE, ZABConstants.ErrorMessages.API_ALL_FAILURE.getErrorCode());
			json.put(ZABConstants.STATUS_STRING, "Invalid JSON Format");
			json.put(ZABConstants.COUNT, 0);
			json.put(moduleName, new JSONArray());
			json.put(ZABConstants.TIME_TAKEN,endTime-startTime+" ms" );
			json.put(ZABConstants.CREATE_COUNT, ZABUtil.getDBCallCountMap().get(ZABConstants.CREATE_COUNT));
			json.put(ZABConstants.READ_COUNT,ZABUtil.getDBCallCountMap().get(ZABConstants.READ_COUNT));
			json.put(ZABConstants.UPDATE_COUNT, ZABUtil.getDBCallCountMap().get(ZABConstants.UPDATE_COUNT));
			json.put(ZABConstants.DELETE_COUNT, ZABUtil.getDBCallCountMap().get(ZABConstants.DELETE_COUNT));
			outString = json.toString();
		}catch(JSONException ex)
		{
			ex.printStackTrace();
		}
		return outString;
	}
	public String getExceptionString(String exceptionString,String moduleName){	
		String outString = "";
		try{
			Long endTime = ZABUtil.getCurrentTimeInMilliSeconds();
			Long startTime = (Long)ZABUtil.getCurrentRequest().getAttribute("RequestStartTime");
			JSONObject json = new JSONObject();
			json.put(ZABConstants.STATUS_CODE, ZABConstants.ErrorMessages.API_ALL_FAILURE.getErrorCode());
			json.put(ZABConstants.STATUS_STRING, exceptionString);
			json.put(ZABConstants.COUNT, 0);
			json.put(moduleName, new JSONArray());
			json.put(ZABConstants.TIME_TAKEN,endTime-startTime+" ms" );
			json.put(ZABConstants.CREATE_COUNT, ZABUtil.getDBCallCountMap().get(ZABConstants.CREATE_COUNT));
			json.put(ZABConstants.READ_COUNT,ZABUtil.getDBCallCountMap().get(ZABConstants.READ_COUNT));
			json.put(ZABConstants.UPDATE_COUNT, ZABUtil.getDBCallCountMap().get(ZABConstants.UPDATE_COUNT));
			json.put(ZABConstants.DELETE_COUNT, ZABUtil.getDBCallCountMap().get(ZABConstants.DELETE_COUNT));
			outString = json.toString();
		}catch(JSONException ex)
		{
			ex.printStackTrace();
		}
		return outString;
	}
	
	public String getInvalidModuleResponse(String moduleName){
		String outString = "";
		try{
			Long endTime = ZABUtil.getCurrentTimeInMilliSeconds();
			Long startTime = (Long)ZABUtil.getCurrentRequest().getAttribute("RequestStartTime");
			JSONObject json = new JSONObject();
			json.put(ZABConstants.STATUS_CODE, ZABConstants.ErrorMessages.API_ALL_FAILURE.getErrorCode());
			json.put(ZABConstants.STATUS_STRING, "Invalid Module Name in the URL");
			json.put(ZABConstants.COUNT, 0);
			json.put(moduleName, new JSONArray());
			json.put(ZABConstants.TIME_TAKEN,endTime-startTime+" ms" );
			json.put(ZABConstants.CREATE_COUNT, ZABUtil.getDBCallCountMap().get(ZABConstants.CREATE_COUNT));
			json.put(ZABConstants.READ_COUNT,ZABUtil.getDBCallCountMap().get(ZABConstants.READ_COUNT));
			json.put(ZABConstants.UPDATE_COUNT, ZABUtil.getDBCallCountMap().get(ZABConstants.UPDATE_COUNT));
			json.put(ZABConstants.DELETE_COUNT, ZABUtil.getDBCallCountMap().get(ZABConstants.DELETE_COUNT));
			outString = json.toString();
		}catch(JSONException ex)
		{
			ex.printStackTrace();
		}
		return outString;
	}
	public String getAccessDeniedResponse(){
		String outString = "";
		try{
			JSONObject json = new JSONObject();
			json.put(ZABConstants.STATUS_CODE, ZABConstants.ErrorMessages.ACCESS_DENIED.getErrorCode());
			json.put(ZABConstants.STATUS_STRING, ZABAction.getMessage(ZABConstants.ErrorMessages.ACCESS_DENIED.getErrorString()));
			json.put(ZABConstants.COUNT, 0);
			json.put(ZABConstants.CREATE_COUNT, ZABUtil.getDBCallCountMap().get(ZABConstants.CREATE_COUNT));
			json.put(ZABConstants.READ_COUNT,ZABUtil.getDBCallCountMap().get(ZABConstants.READ_COUNT));
			json.put(ZABConstants.UPDATE_COUNT, ZABUtil.getDBCallCountMap().get(ZABConstants.UPDATE_COUNT));
			json.put(ZABConstants.DELETE_COUNT, ZABUtil.getDBCallCountMap().get(ZABConstants.DELETE_COUNT));
			outString = json.toString();
		}catch(JSONException ex)
		{
			ex.printStackTrace();
		}
		return outString;
	}
	public String getNoSuchResourceResponse(){
		String outString = "";
		try{
			JSONObject json = new JSONObject();
			json.put(ZABConstants.STATUS_CODE, ZABConstants.ErrorMessages.API_ALL_FAILURE.getErrorCode());
			json.put(ZABConstants.STATUS_STRING, "No such Resource found");
			json.put(ZABConstants.COUNT, 0);
			json.put(ZABConstants.CREATE_COUNT, ZABUtil.getDBCallCountMap().get(ZABConstants.CREATE_COUNT));
			json.put(ZABConstants.READ_COUNT,ZABUtil.getDBCallCountMap().get(ZABConstants.READ_COUNT));
			json.put(ZABConstants.UPDATE_COUNT, ZABUtil.getDBCallCountMap().get(ZABConstants.UPDATE_COUNT));
			json.put(ZABConstants.DELETE_COUNT, ZABUtil.getDBCallCountMap().get(ZABConstants.DELETE_COUNT));
			outString = json.toString();
		}catch(JSONException ex)
		{
			ex.printStackTrace();
		}
		return outString;
	}
	
	@Override
	public String getExperimentResponse(HttpServletRequest request,
			ArrayList<Experiment> experiments) throws JSONException {
		return ExperimentResponse.jsonResponse(request, experiments);
	}
	@Override
	public String getVariationResponse(HttpServletRequest request,
			ArrayList<Variation> variations) throws JSONException {
		return VariationResponse.jsonResponse(request, variations);
	}

	public String getReportResponse(HttpServletRequest request,
			ArrayList<ReportStatistics> visitorReports) throws JSONException {
		return ReportResponse.jsonResponse(request, visitorReports);
	}

	public String getHeatmapDataResponse(HttpServletRequest request,
			ArrayList<Heatmap> heatmapdata) throws JSONException {
		return HeatmapDataResponse.jsonResponse(request, heatmapdata);
	}
	
	public String getScrollmapDataResponse(HttpServletRequest request,
			ArrayList<Scrollmap> scrollmapdata) throws JSONException {
		return ScrollmapDataResponse.jsonResponse(request, scrollmapdata);
	}
	
	public String getAttentionmapDataResponse(HttpServletRequest request,
			ArrayList<Scrollmap> attentionmapdata) throws JSONException {
		return AttentionmapDataResponse.jsonResponse(request, attentionmapdata);
	}
	
	public String getProjectResponse(HttpServletRequest request,
			ArrayList<Project> projects) throws JSONException {
		return ProjectResponse.jsonResponse(request, projects);
	}
	
	
	
	public String getReportRawDataResponse(HttpServletRequest request, List<ReportRawData> reportRawDataList) throws Exception
	{
		return ReportRawDataResponse.jsonResponse(request, reportRawDataList);
	}
	
	public String getDynamicAttributesResponse(HttpServletRequest request, List<DynamicAttributes> dynamicAttributes) throws Exception
	{
		return DynamicAttributeResponse.jsonResponse(request, dynamicAttributes);
	}
	
	@Override
	public String getProjectUserRoleResponse(HttpServletRequest request, List<ProjectUserRoleWrapper> projectUserRoleWrappers) throws Exception {
		return ProjectUserRoleResponse.jsonResponse(request, projectUserRoleWrappers);
	}
	
	@Override
	public String getRoleResponse(HttpServletRequest request, List<Role> roles) throws Exception {
		return RoleResponse.jsonResponse(request, roles);
	}
	
	public String getExperimentDynamicAttributeResponse(HttpServletRequest request, List<ExperimentDynamicAttribute> experimentDynamicAttributes) throws Exception
	{
		return ExperimentDynamicAttributeResponse.jsonResponse(request, experimentDynamicAttributes);
	}
	
	public String getCustomDimensionResponse(HttpServletRequest request, List<CustomDimension> customDimensions) throws Exception
	{
		return CustomDimensionResponse.jsonResponse(request, customDimensions);
	}

	public String getPortalResponse(HttpServletRequest request, List<Portal> portals) throws Exception
	{
		return PortalResponse.jsonResponse(request, portals);
	}
	
	@Override
	public String getGoalResponse(HttpServletRequest request,
			ArrayList<Goal> goals) throws JSONException {
		return GoalResponse.jsonResponse(request, goals);
	}
	

	public String getAudienceResponse(HttpServletRequest request,
			ArrayList<Audience> audience) throws JSONException {
		return AudienceResponse.jsonResponse(request, audience);
	}


	public String getAudienceAttributeResponse(HttpServletRequest request,
			ArrayList<AudienceAttribute> audience_attribute) throws JSONException {
		return AudienceAttributeResponse.jsonResponse(request, audience_attribute);
	}

	public String getAudienceMatchTypeResponse(HttpServletRequest request,
			ArrayList<AudienceMatchType> audience_matchtype) throws JSONException {
		return AudienceMatchTypeResponse.jsonResponse(request, audience_matchtype);
	}
	
	public String getExperimentAudienceResponse(HttpServletRequest request,
			ArrayList<ExperimentAudience> experimentaudience) throws JSONException {
		return ExperimentAudienceResponse.jsonResponse(request, experimentaudience);
	}
	public String getProjectAudienceResponse(HttpServletRequest request,
			ArrayList<ProjectAudience> projectaudience) throws JSONException {
		return ProjectAudienceResponse.jsonResponse(request, projectaudience);
	}
	@Override
	public String getDimensionResponse(HttpServletRequest request,
			ArrayList<Dimension> dimension) throws JSONException {
		return DimensionResponse.jsonResponse(request, dimension);
	}
	
	@Override
	public String getExperimentEventActivityResponse(HttpServletRequest request,List<EventActivityLog> eventActivityList) throws JSONException {
		return EventActivityResponse.jsonResponse(request, eventActivityList, EventActivityConstants.EAPI_MODULE);
	}
	
	@Override
	public String getProjectEventActivityResponse(HttpServletRequest request,List<EventActivityLog> eventActivityList) throws JSONException {
		return EventActivityResponse.jsonResponse(request, eventActivityList, EventActivityConstants.PAPI_MODULE);
	}
	
	@Override
	public String getUserEventActivityResponse(HttpServletRequest request,List<EventActivityLog> eventActivityList) throws JSONException {
		return EventActivityResponse.jsonResponse(request, eventActivityList, EventActivityConstants.UAPI_MODULE);
	}
	
	@Override
	public String getAdminConsoleAuditLogResponse(HttpServletRequest request,List<AdminConsoleAuditLog> auditLogList) throws JSONException {
		return AdminConsoleAuditLogResponse.jsonResponse(request, auditLogList, AuditLogConstants.API_MODULE);
	}
	
	public String getSampleSizeResponse(HttpServletRequest request,
			ArrayList<SampleSizeCalculator> audience) throws JSONException {
		return SampleSizeCalculatorResponse.jsonResponse(request, audience);
	}

	@Override
	public String getUserResponse(HttpServletRequest request,
			ArrayList<ZABUser> users) throws JSONException {
		return ZABUserResponse.jsonResponse(request, users);
	}

	@Override
	public String getCheckScriptResponse(HttpServletRequest request,
			CheckScript checkScript) throws JSONException {
		return CheckScriptResponse.jsonResponse(request, checkScript);
	}

	
	public String getChartRpeortResponse(HttpServletRequest request,
			ArrayList<ChartReport> charts) throws JSONException {
		
		return ChartReportResponse.jsonResponse(request, charts);
	}
	
	public String getRevenueChartRpeortResponse(HttpServletRequest request,
			ArrayList<RevenueChartReport> charts) throws JSONException {
		
		return RevenueChartReportResponse.jsonResponse(request, charts);
	}

	public String getSearchResponse(HttpServletRequest request,
			ArrayList<Search> search) throws JSONException {
		
		return SearchResponse.jsonResponse(request, search);
	}


	@Override
	public String getImageUploadResponse(HttpServletRequest request,
			ArrayList<ImageUpload> imageUploads) throws JSONException {
		return ImageUploadResponse.jsonResponse(request, imageUploads);
	}


	public String getIntegrationResponse(HttpServletRequest request,
			ArrayList<Integration> integration) throws JSONException {
		return IntegrationResponse.jsonResponse(request, integration);
	}
	


	public String getRevenueResponse(HttpServletRequest request,
			ArrayList<RevenueReport> revenueReports) throws JSONException {
		return RevenueResponse.jsonResponse(request, revenueReports);
	}

	@Override
	public String getGoogleAnalyticsResponse(HttpServletRequest request,ArrayList<GoogleAnalytics> googleanalytics) throws JSONException {
		return GoogleAnalyticsResponse.jsonResponse(request,googleanalytics);
	}
	
	@Override
	public String getGoogleAdwordsResponse(HttpServletRequest request,ArrayList<GoogleAdwords> googleadwords) throws JSONException {
		return GoogleAdwordsResponse.jsonResponse(request,googleadwords);
	}

	@Override
	public String getGoogleTagManagerResponse(HttpServletRequest request,ArrayList<GoogleTagManager> googletagmanager) throws JSONException {
		return GoogleTagManagerResponse.jsonResponse(request,googletagmanager);
	}
	
	public String getDynamicConfigurationResponse(HttpServletRequest request, List<DynamicConfiguration> dynamicConfs) throws Exception
	{
		return DynamicConfigurationResponse.jsonResponse(request, dynamicConfs);
	}

	@Override
	public String getESAdminConsoleResponse(HttpServletRequest request, ESAdminConsole esAdminConsole) throws Exception 
	{
		return ESAdminConsoleResponse.jsonResponse(request, esAdminConsole);
	}

	@Override
	public String getESDefaultIndicesResponse(HttpServletRequest request) throws Exception {
		return ESDefaultIndicesResponse.jsonResponse(request);
	}
	
	public String getFormResponse(HttpServletRequest request,
			ArrayList<Form> form) throws JSONException {
		return FormResponse.jsonResponse(request, form);
	}
	
	public String getFormResponse(HttpServletRequest request,
			JSONArray jsonarray) throws JSONException {
		return FormResponse.jsonResponse(request,jsonarray);
	}
	
	public String getFormDayWiseReportResponse(HttpServletRequest request,
			ArrayList<FormDayWiseReport> form) throws JSONException {
		return FormDayWiseReportResponse.jsonResponse(request, form);
	}
	
	
	public String getFormRawDataResponse(HttpServletRequest request,
			ArrayList<FormRawData> formrawdata) throws JSONException {
		return FormRawDataResponse.jsonResponse(request, formrawdata);
	}

	public String getFormReportResponse(HttpServletRequest request,
			ArrayList<FormReport> formreports) throws JSONException {
		return FormReportResponse.jsonResponse(request, formreports);
	}


	@Override
	public String getFunnelReportResponse(HttpServletRequest request,
			ArrayList<FunnelReport> funnelReports) throws JSONException {
		return FunnelReportResponse.jsonResponse(request, funnelReports);
	}
	
	public String getCustomEventResponse(HttpServletRequest request,
			ArrayList<CustomEvent> customEvents) throws JSONException {
		return CustomEventResponse.jsonResponse(request, customEvents);
	}
	
	public String getCustomEventReportResponse(HttpServletRequest request,
			ArrayList<CustomEventReports> customeventsreports) throws Exception {
		return CustomEventReportResponse.jsonResponse(request, customeventsreports);
	}
	
	@Override
	public String getFunnelStepResponse(HttpServletRequest request,
			ArrayList<FunnelStep> steps) throws Exception {
		return new FunnelStepResponse().jsonResponse(request, steps);
	}

	@Override
	public String getFunnelReportTimelineResponse(HttpServletRequest request,
			ArrayList<FunnelTimelineReport> funnelReports) throws JSONException {
		return FunnelReportTimelineResponse.jsonResponse(request, funnelReports);
	}

	@Override
	public String getTourResponse(HttpServletRequest request, ArrayList<ZABTour> tours) {
		return ZABTourResponse.jsonResponse(request, tours);
	}

	@Override
	public String getAdminConsoleDashboardResponse(HttpServletRequest request,
			AdminConsole acObj) throws Exception {
		// TODO Auto-generated method stub
		return AdminConsoleResponse.jsonResponse(request, acObj);
	}

	@Override
	public String getPortalLicenseMappingResponse(HttpServletRequest request,
			ArrayList<PortalLicenseMapping> userLicenseMappingList)
			throws JSONException {
		// TODO Auto-generated method stub
		return PortalLicenseMappingResponse.jsonResponse(request, userLicenseMappingList);
	}
	
	public String getACUserDetailsResponse(HttpServletRequest request,ArrayList<AdminConsoleUserDetail> lst) throws JSONException
	{
		return AdminConsoleResponse.jsonACUserDetailsResponse(request, lst);
	}
	
	public String getQuickFilterSegmentVisitorResponse(
			HttpServletRequest request,
			List<ESQuickFilterStatistics> visitorReports) throws JSONException {
		// TODO Auto-generated method stub
		return ESQuickFilterResponse.jsonResponse(request, visitorReports);
	}

	@Override
	public String getQuickFilterAttrResponse(HttpServletRequest request,
			List<ESQuickFilterWrapper> qfAttributes) throws JSONException {
		// TODO Auto-generated method stub
		return ESQuickFilterAttrResponse.jsonResponse(request, qfAttributes);
	}
	public String getLocationResponse(HttpServletRequest request,
			ArrayList<Location> location) {
		// TODO Auto-generated method stub
		return LocationResponse.jsonResponse(request, location);
	}

	@Override
	public String getAdminConsolePortalList(HttpServletRequest request, AdminConsole acObj) throws Exception{
		// TODO Auto-generated method stub
		return AdminConsoleResponse.portalListResponse(request, acObj);
	}

	@Override
	public String getAdminConsolePortalDetails(HttpServletRequest request, AdminConsole acObj) throws Exception{
		// TODO Auto-generated method stub
		return AdminConsoleResponse.projectDetailResponse(request, acObj);
	}
	
	@Override
	public String getUsageStatsResponse(HttpServletRequest request, ArrayList<Project> projects) throws JSONException {
		return ProjectResponse.usageStatsJsonResponse(request, projects);
	}

	@Override
	public String getSessionPlayLists(HttpServletRequest request,
			ArrayList<SessionPlayListWrapper> playLists) {
		return SessionPlayListResponse.jsonResponse(request, playLists);
	}

	@Override
	public String getSessionRecordingClipMetas(HttpServletRequest request,
			ArrayList<SessionRecordingClipMeta> clipMetas) {
		return SessionRecordingClipMetaResponse.jsonResponse(request, clipMetas);
	}

	@Override
	public String getSessionPageDetails(HttpServletRequest request,
			ArrayList<SessionPage> pages) {
		return SessionPageResponse.jsonResponse(request, pages);
	}

	@Override
	public String getGoalReportResponse(HttpServletRequest request,
			ArrayList<GoalReports> goalreports) throws JSONException {
		
		return GoalReportResponse.jsonResponse(request, goalreports);
	}

	@Override
	public String getSuggestedNameList(HttpServletRequest request,
			AdminConsole acObj) throws Exception {
		// TODO Auto-generated method stub
		return AdminConsoleResponse.userListResponse(request, acObj);
	}

	@Override
	public String getPrivacyResponse(HttpServletRequest request,
			ArrayList<Privacy> privacy) throws JSONException {
		// TODO Auto-generated method stub
		return PrivacyResponse.jsonResponse(request, privacy);	
	}

	@Override
	public String getWebhookResponse(HttpServletRequest request,
			ArrayList<Webhook> webhooks) {
		// TODO Auto-generated method stub
		return WebhookResponse.jsonResponse(request,webhooks);
	}
	public String getTriggerResponse(HttpServletRequest request,
			ArrayList<Trigger> triggers) {
		// TODO Auto-generated method stub
		return TriggerResponse.jsonResponse(request,triggers);
	}public String getVariableResponse(HttpServletRequest request,
			ArrayList<String> variables) {
		// TODO Auto-generated method stub
		return VariableResponse.jsonResponse(request,variables);
	}
	public String getExperimentsCountresponse(HttpServletRequest request,
			ArrayList<ExperimentsCount> experimentscount) throws JSONException {
		
		return ExperimentsCountResponse.jsonResponse(request,experimentscount);
	}
}

