//$Id$
package com.zoho.abtest.script;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.json.JSONException;

import com.opensymphony.xwork2.ActionSupport;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;

public class CheckScriptAction  extends ActionSupport implements ServletResponseAware, ServletRequestAware{

	/**
	 * 
	 */
	
	private static final Logger LOGGER = Logger.getLogger(CheckScriptAction.class.getName());
	
	private static final long serialVersionUID = 1L;

	private HttpServletRequest request;
	
	private HttpServletResponse response;
	
	private String experimentLinkname;
	
	private String variationLinkname; 
	
	private String projectLinkname;
	
	public String getProjectLinkname() {
		return projectLinkname;
	}

	public void setProjectLinkname(String projectLinkname) {
		this.projectLinkname = projectLinkname;
	}

	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		request = arg0;
	}

	@Override
	public void setServletResponse(HttpServletResponse arg0) {
		response = arg0;
	}

	public String getExperimentLinkname() {
		return experimentLinkname;
	}

	public void setExperimentLinkname(String experimentLinkname) {
		this.experimentLinkname = experimentLinkname;
	}

	public String getVariationLinkname() {
		return variationLinkname;
	}

	public void setVariationLinkname(String variationLinkname) {
		this.variationLinkname = variationLinkname;
	}

	public String execute() throws IOException, JSONException {
		CheckScript script = null;
		try {	
			script = CheckScript.checkScript(experimentLinkname, variationLinkname);
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), CheckScriptConstants.API_MODULE));
			return null;
		}
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getCheckScriptResponse(request, script));
		return null;
	}
	
	public String checkScriptByURL() throws IOException, JSONException {
		CheckScript script = null;
		try {	
			String url = request.getParameter(CheckScriptConstants.URL);
			script = CheckScript.checkScriptByURL(projectLinkname, url);
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), CheckScriptConstants.API_MODULE));
			return null;
		}
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getCheckScriptResponse(request, script));
		return null;
	}
}
