//$Id$
package com.zoho.abtest.script;

import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.experiment.ABSplitExperiment;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentType;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.utility.ScriptChecker;
import com.zoho.abtest.variation.Variation;
import com.zoho.conf.Configuration;

public class CheckScript extends ZABModel{
	
	private Boolean isScriptAvailable;
	
	private Boolean loadViaProxy;
	
	private String experimentLinkname;
	
	private HashMap<String, Boolean> variations = new HashMap<String, Boolean>();
	
	private static final Logger LOGGER = Logger.getLogger(CheckScript.class.getName());

	public Boolean getIsScriptAvailable() {
		return isScriptAvailable;
	}
		

	public String getExperimentLinkname() {
		return experimentLinkname;
	}


	public void setExperimentLinkname(String experimentLinkname) {
		this.experimentLinkname = experimentLinkname;
	}



	public void setIsScriptAvailable(Boolean isScriptAvailable) {
		this.isScriptAvailable = isScriptAvailable;
	}

	public HashMap<String, Boolean> getVariations() {
		return variations;
	}

	public void setVariations(HashMap<String, Boolean> variations) {
		this.variations = variations;
	}
	
	
	
//	public static CheckScript checkScript(String experimentLinkname) {
//		CheckScript checkScript = new CheckScript();
//		checkScript.setIsScriptAvailable(Boolean.FALSE);
//		try {			
//			Experiment experiment = Experiment.getExperimentByLinkname(experimentLinkname);
//			if(experiment!=null) {					
//				String serverUrl = Configuration.getString(ZABConstants.SCRIPT_CDN);
//				checkScript.setIsScriptAvailable(ScriptChecker.checkIfScriptExists(experiment.getExperimentUrl(), serverUrl+experiment.getProjectId()+".js")); //No I18N
//				checkScript.setSuccess(Boolean.TRUE);
//				checkScript.setExperimentLinkname(experimentLinkname);				
//			}
//		} catch (Exception e) {
//			LOGGER.log(Level.SEVERE, e.getMessage(),e);
//		}
//		return checkScript;
//	}
	
	public Boolean getLoadViaProxy() {
		return loadViaProxy;
	}


	public void setLoadViaProxy(Boolean loadViaProxy) {
		this.loadViaProxy = loadViaProxy;
	}


	public static CheckScript checkScriptByURL(String projectLinkname, String experimentUrl) {
		CheckScript checkScript = new CheckScript();
		checkScript.setIsScriptAvailable(Boolean.FALSE);
		try {			
			Long projectId = Project.getProjectId(projectLinkname);
			if(projectId!=null) {
				Project project = Project.getProjectByProjectId(projectId);
				String scripturl = Project.getProjectJsSnippetPrimaryUrl(project.getProjectKey());//serverUrl+experiment.getProjectId()+".js"; //NO I18N
				String altScriptUrl = Project.getProjectJsSnippetAltUrl(project.getProjectKey());
				ScriptChecker checker = ScriptChecker.checkIfScriptExists(experimentUrl, scripturl, altScriptUrl);
				checkScript.setIsScriptAvailable(checker.getScriptAvailable());
				checkScript.setLoadViaProxy(checker.getLoadViaProxy());
				checkScript.setSuccess(Boolean.TRUE);
			}
		} catch (ZABException e) {
			checkScript.setSuccess(Boolean.FALSE);
			checkScript.setIsScriptAvailable(Boolean.FALSE);
			checkScript.setResponseString(e.getMessage());
		}
		catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		return checkScript;
	}
	
	public static CheckScript checkScript(String experimentLinkname, String variationLinkname) {
		CheckScript checkScript = new CheckScript();
		checkScript.setIsScriptAvailable(Boolean.FALSE);
		try {
			ABSplitExperiment experiment = ABSplitExperiment.getABSplitExperimentDetail(experimentLinkname);
			if(experiment!=null) {
				String url = experiment.getExperimentUrl();
				if(variationLinkname!=null && experiment.getExperimentType().equals(ExperimentType.SPLITURL.getTypeNumber())) {
					Variation variation = Variation.getVariationByLinkname(variationLinkname).get(0);
					url = variation.getTargetUrl();
				}
				Project project = Project.getProjectByProjectId(experiment.getProjectId());
				String scripturl = Project.getProjectJsSnippetPrimaryUrl(project.getProjectKey());//serverUrl+experiment.getProjectId()+".js"; //NO I18N
				String altScriptUrl = Project.getProjectJsSnippetAltUrl(project.getProjectKey());
				ScriptChecker checker = ScriptChecker.checkIfScriptExists(url, scripturl, altScriptUrl);
				checkScript.setIsScriptAvailable(checker.getScriptAvailable());
				checkScript.setLoadViaProxy(checker.getLoadViaProxy());
				checkScript.setSuccess(Boolean.TRUE);
				checkScript.setExperimentLinkname(experimentLinkname);				
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		return checkScript;
	}
}
