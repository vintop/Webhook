//$Id$
package com.zoho.abtest.script;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;

public class CheckScriptResponse {
	
	private static final Logger LOGGER = Logger.getLogger(CheckScriptResponse.class.getName());
	
	public static String jsonResponse(HttpServletRequest request,CheckScript lst) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(lst);			
			JSONObject json = ZABResponse.updateMetaInfo(request, CheckScriptConstants.API_MODULE, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex) {
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		return returnBuffer.toString();
	}
	
	public static JSONArray getJSONArray(CheckScript ld) throws JSONException {
		JSONArray array = new JSONArray();
		JSONObject object = new JSONObject();
		object.put(CheckScriptConstants.SCRIPT_AVAILABLE, ld.getIsScriptAvailable());
		object.put(CheckScriptConstants.LOAD_VIA_PROXY, ld.getLoadViaProxy());
		object.put(ZABConstants.SUCCESS, ld.getSuccess());		
		object.put(ZABConstants.LINKNAME, ld.getExperimentLinkname());  
		array.put(object);
		return array;
	}
	
} 
