//$Id$
package com.zoho.abtest.script;

public class CheckScriptConstants {
	
	public static final String API_MODULE="checkscripts"; //NO I18N
	
	public static final String SCRIPT_AVAILABLE="script_available"; //NO I18N
	
	public static final String LOAD_VIA_PROXY ="load_via_proxy"; //NO I18N
	
	public static final String PROJECT_LINKNAME="project_link_name"; //NO I18N
	
	public static final String URL="url"; //NO I18N
	
}
