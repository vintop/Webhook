//$Id$
package com.zoho.abtest.licenseactivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.zoho.abtest.LICENSE_ACTIVITY_LOG;
import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.experiment.ExperimentConstants;

public class LicenseActivityConstants extends ZABConstants{
	
	public static final String EVENT_MODULE_NAME = "LicenseActivityListener"; //No I18N
	
	public static final String LICENSE_ACTIVITY_LOG_ID = "license_activity_log_id";			// No I18N

	public static final String EVENT_TYPE = "event_type";			// No I18N
	public static final String LICENSE_TYPE = "license_type";			// No I18N
	public static final String OLD_LICENSE_TYPE = "old_license_type";			// No I18N
	public static final String TIME = "time";			// No I18N
	public static final String USER_ID = "user_id";			// No I18N
	public static final String FORMATTED_TIME = "formatted_time";			// No I18N
	public static final String FORMATTED_TIME_ONLY = "formatted_time_only";			// No I18N
	public static final String FORMATTED_DATE_ONLY = "formatted_date_only";			// No I18N
	public static final String MESSAGE = "message";			// No I18N
	
	
	
	public static enum LicenseLogTypes
	{
		LICENSE_ACTIVATE("license_activate",1,"license.activate"), //No I18N
		LICENSE_UPGRADE("license_upgrade",2,"license.upgrade"), //No I18N
		LICENSE_EXPIRED("license_expired",3,"license.expired"), //No I18N
		LICENSE_PAUSED("license_paused",4,"license.paused"), //No I18N
		LICENSE_RESUMED("license_resumed",5,"license.resumed"), //No I18N
		LICENSE_RENEWED("license_renewed",6,"license.renewed"); //No I18N
		
		
		private String eventName;
		private Integer eventValue;
		private String eventMessagekey;
		
		public String getEventName() {
			return eventName;
		}
		public void setEventName(String eventName) {
			this.eventName = eventName;
		}
		public Integer getEventValue() {
			return eventValue;
		}
		public void setEventValue(Integer eventValue) {
			this.eventValue = eventValue;
		}
		public String getEventMessageKey() {
			return eventMessagekey;
		}
		public void setEventMessageKey(String eventMessagekey) {
			this.eventMessagekey = eventMessagekey;
		}
		
		private LicenseLogTypes(String eventName, Integer eventValue, String eventMessagekey)
		{
			this.eventName = eventName;
			this.eventValue = eventValue;
			this.eventMessagekey = eventMessagekey;
		}
		
		public static LicenseLogTypes getEventTypeByValue(int eventValue)
		{
			LicenseLogTypes eType = null; 
			for(LicenseLogTypes eventType:LicenseLogTypes.values())
			{
				if(eventType.getEventValue().equals(eventValue))
				{
					eType = eventType;
					break;
				}
			}
			return eType;
		}
		
	}
	
	public static final List<Constants> LICENSE_ACTIVITY_LOG_CONSTANTS;
	
	static{
		List<Constants> eventActivityLogConstants = new ArrayList<Constants>();
		eventActivityLogConstants.add(new Constants(LICENSE_ACTIVITY_LOG_ID,LICENSE_ACTIVITY_LOG.LICENSE_ACTIVITY_LOG_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		eventActivityLogConstants.add(new Constants(EVENT_TYPE,LICENSE_ACTIVITY_LOG.EVENT_TYPE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		eventActivityLogConstants.add(new Constants(LICENSE_TYPE,LICENSE_ACTIVITY_LOG.LICENSE_TYPE,ZABConstants.LONG,Boolean.TRUE,Boolean.TRUE));
		eventActivityLogConstants.add(new Constants(OLD_LICENSE_TYPE,LICENSE_ACTIVITY_LOG.OLD_LICENSE_TYPE,ZABConstants.LONG,Boolean.TRUE,Boolean.TRUE));
		eventActivityLogConstants.add(new Constants(USER_ID,LICENSE_ACTIVITY_LOG.ZUID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		eventActivityLogConstants.add(new Constants(TIME,LICENSE_ACTIVITY_LOG.TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		LICENSE_ACTIVITY_LOG_CONSTANTS = Collections.unmodifiableList(eventActivityLogConstants);
	}
	
	
	// Collection to maintain the readable text for each property to be used for event logging
	public static final Map<String, String> READABLE_TEXT_COLLECTION;
	
	static
	{
		HashMap<String, String> readableText = new HashMap<String, String>();
		
		readableText.put(ExperimentConstants.EXPERIMENT_NAME, "Display name"); //No I18N
		readableText.put(ExperimentConstants.EXPERIMENT_URL, "Experiment url"); //No I18N
		readableText.put(ExperimentConstants.EXPERIMENT_STATUS, "Experiment status"); //No I18N
		readableText.put(ExperimentConstants.PERMITTED_TRAFFIC, "Permitted traffic"); //No I18N
		readableText.put(ExperimentConstants.STATISTICAL_SIGNIFICANCE, "Statistical significance"); //No I18N
		readableText.put(ExperimentConstants.START_DATE, "Start date"); //No I18N
		readableText.put(ExperimentConstants.END_DATE, "End date"); //No I18N
		
		READABLE_TEXT_COLLECTION = Collections.unmodifiableMap(readableText);
	}

}
