//$Id$
package com.zoho.abtest.licenseactivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.SortColumn;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.LICENSE_ACTIVITY_LOG;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.eventactivity.EventActivityLog;
import com.zoho.abtest.license.LicenseDetail;
import com.zoho.abtest.licenseactivity.LicenseActivityConstants.LicenseLogTypes;
import com.zoho.abtest.utility.ZABUtil;

public class LicenseActivityLog extends ZABModel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = Logger.getLogger(EventActivityLog.class.getName());
	
	private Integer eventType;
	private Long licenseType;
	private Long oldLicenseType;
	private Long time;
	private Long userId;
	
	private String message;
	private String formattedTime;
	private String dateOnly;
	private String timeOnly;


	
	public String getMessage() {
		return message;
	}



	public void setMessage(String message) {
		this.message = message;
	}



	public String getFormattedTime() {
		return formattedTime;
	}



	public void setFormattedTime(String formattedTime) {
		this.formattedTime = formattedTime;
	}



	public String getDateOnly() {
		return dateOnly;
	}



	public void setDateOnly(String dateOnly) {
		this.dateOnly = dateOnly;
	}



	public String getTimeOnly() {
		return timeOnly;
	}



	public void setTimeOnly(String timeOnly) {
		this.timeOnly = timeOnly;
	}



	public Integer getEventType() {
		return eventType;
	}



	public void setEventType(Integer eventType) {
		this.eventType = eventType;
	}



	public Long getLicenseType() {
		return licenseType;
	}



	public void setLicenseType(Long licenseType) {
		this.licenseType = licenseType;
	}



	public Long getOldLicenseType() {
		return oldLicenseType;
	}



	public void setOldLicenseType(Long oldLicenseType) {
		this.oldLicenseType = oldLicenseType;
	}



	public Long getTime() {
		return time;
	}



	public void setTime(Long time) {
		this.time = time;
	}
	
	public Long getUserId() {
		return userId;
	}



	public void setUserId(Long userId) {
		this.userId = userId;
	}



	public static void createLicenseActivityLog(HashMap<String, String> hs)
	{
		String currentdb = ZABUtil.getCurrentUserDbSpace();
		try
		{
			ZABUtil.setDBSpace("sharedspace");	// NO I18N
			ZABModel.createRow(LicenseActivityConstants.LICENSE_ACTIVITY_LOG_CONSTANTS, LICENSE_ACTIVITY_LOG.TABLE, hs);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		ZABUtil.setDBSpace(currentdb);
	}
	
	public static List<LicenseActivityLog> getLicenseActivityLogOfUser(Long userid, Long startDate, Long endDate)
	{
		ArrayList<LicenseActivityLog> licenseActivityLogs = new ArrayList<LicenseActivityLog>();
		LicenseActivityLog licenseActivityLog;
		String currentdbSpace =  ZABUtil.getCurrentUserDbSpace();
		try
		{
			ZABUtil.setDBSpace("sharedspace");	// NO I18N
			Criteria finalCriteria = null;
			Criteria criteria = new Criteria(new Column(LICENSE_ACTIVITY_LOG.TABLE,LICENSE_ACTIVITY_LOG.ZUID),userid,QueryConstants.EQUAL);
			finalCriteria = criteria;
			if(startDate != null)
			{
				Criteria startDateCriteria = new Criteria(new Column(LICENSE_ACTIVITY_LOG.TABLE,LICENSE_ACTIVITY_LOG.TIME),startDate,QueryConstants.GREATER_EQUAL);
				finalCriteria = finalCriteria.and(startDateCriteria);
			}
			if(endDate != null)
			{
				Criteria endDateCriteria = new Criteria(new Column(LICENSE_ACTIVITY_LOG.TABLE,LICENSE_ACTIVITY_LOG.TIME),endDate,QueryConstants.LESS_EQUAL);
				finalCriteria = finalCriteria.and(endDateCriteria);
			}
			SortColumn sortColumn = new SortColumn(LICENSE_ACTIVITY_LOG.TABLE, LICENSE_ACTIVITY_LOG.TIME, Boolean.FALSE);
			DataObject dataObj = ZABModel.getRow(LICENSE_ACTIVITY_LOG.TABLE, finalCriteria, sortColumn,null);	
			Iterator<?> iterator = dataObj.getRows(LICENSE_ACTIVITY_LOG.TABLE);
			while(iterator.hasNext())
			{
				Row row = (Row)iterator.next();
				licenseActivityLog = getLicenseActivityLogFromRow(row);
				licenseActivityLogs.add(licenseActivityLog);
			}
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		ZABUtil.setDBSpace(currentdbSpace);
		return licenseActivityLogs;
	}
	
	
	
	public static LicenseActivityLog getLicenseActivityLogFromRow(Row row )
	{
		LicenseActivityLog licenseActivityLog = new LicenseActivityLog();
		
		try
		{
			
			Long time = (Long)row.get(LICENSE_ACTIVITY_LOG.TIME);
			Long userId = (Long)row.get(LICENSE_ACTIVITY_LOG.ZUID);
			
		
			Integer eventType = (Integer)row.get(LICENSE_ACTIVITY_LOG.EVENT_TYPE);
			Long licenseType = (Long)row.get(LICENSE_ACTIVITY_LOG.LICENSE_TYPE);
			Long oldlicenseType = (Long)row.get(LICENSE_ACTIVITY_LOG.OLD_LICENSE_TYPE);
			String message = "";
			
			
			String licenseName = null;
			if(licenseType!=null){
				licenseName = LicenseDetail.getLicenseDetail(licenseType).getLicenseName();
			}
			
			String oldlicenseName = null;
			if(oldlicenseType!=null){
				oldlicenseName = LicenseDetail.getLicenseDetail(oldlicenseType).getLicenseName();
			}
			message = prepareActivityMessage(eventType, licenseName, oldlicenseName);
			
		
			licenseActivityLog.setEventType(eventType);
			licenseActivityLog.setOldLicenseType(oldlicenseType);
			licenseActivityLog.setLicenseType(licenseType);
			
			licenseActivityLog.setMessage(message);
			HashMap<String, String> formattedTimes = ZABUtil.getDateTimeAllFormatted(time);
			String formattedTime = formattedTimes.get(ZABConstants.DATETIME);
			String formattedTimeOnly = formattedTimes.get(ZABConstants.TIME);
			String formattedDateOnly = formattedTimes.get(ZABConstants.DATE);
			licenseActivityLog.setTime(time);
			licenseActivityLog.setFormattedTime(formattedTime);
			licenseActivityLog.setDateOnly(formattedDateOnly);
			licenseActivityLog.setTimeOnly(formattedTimeOnly);
			licenseActivityLog.setUserId(userId);

			
			licenseActivityLog.setSuccess(Boolean.TRUE);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			licenseActivityLog.setSuccess(Boolean.FALSE);
		}
		
		return licenseActivityLog;
	}
	
	public static String prepareActivityMessage(Integer eventType, String value, String oldValue)
	{
		String message = "";
		try
		{
			LicenseLogTypes event = LicenseLogTypes.getEventTypeByValue(eventType);
			switch(event)
			{
			case LICENSE_ACTIVATE:
			case LICENSE_EXPIRED:
			case LICENSE_PAUSED:
			case LICENSE_RENEWED:
			case LICENSE_RESUMED:
				message += ZABAction.getMessage(event.getEventMessageKey(),new String[]{value});
				
			case LICENSE_UPGRADE:
				message += ZABAction.getMessage(event.getEventMessageKey(),new String[]{value,oldValue});
				break;
		
			default:
				message = "";
				break;
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			message = "";
		}
		return message;
	}




}
