//$Id$
package com.zoho.abtest.customevent;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;

import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABRequest;
import com.zoho.abtest.experiment.ExperimentConstants;

public class CustomEventRequest extends ZABRequest{
	public void updateFromRequest(HashMap<String, String> map,
			HttpServletRequest request) {
		String linkName = (String)request.getAttribute(ZABConstants.LINKNAME);
		if(linkName!=null) {			
			map.put(ZABConstants.LINKNAME, linkName);
		}
	}

	
	public void specificValidation(HashMap<String, String> map,
			HttpServletRequest request) throws IOException, JSONException {
			
			String httpMethod = ZABAction.getHTTPMethod(request).toString();
			
			if(httpMethod.equalsIgnoreCase("POST")){
					ArrayList<String> fields = new ArrayList<String>();
					if(isNullOrEmpty(map, CustomEventConstants.EVENT_NAME)){
						fields.add(CustomEventConstants.EVENT_NAME);
					}
					if(isNullOrEmpty(map, CustomEventConstants.PROJECT_LINKNAME)){
						fields.add(CustomEventConstants.PROJECT_LINKNAME);
					}
					
					if(!fields.isEmpty()) {
						ZABRequest.updateError(map, ZABAction.getAppropriateMessage(ZABConstants.ErrorMessages.MANDATORY_FIELD_MISSING.getErrorString(),fields));
					}
					
				}
			
			if(httpMethod.equalsIgnoreCase("GET")){
				String projectLinkname = request.getParameter(CustomEventConstants.PROJECT_LINKNAME);
				if(projectLinkname == null || projectLinkname.isEmpty()) {
				ZABRequest
						.updateError(map, ZABAction.getAppropriateMessage(ZABConstants.ErrorMessages.MANDATORY_FIELD_MISSING.getErrorString(),
												new ArrayList(Arrays.asList(CustomEventConstants.PROJECT_LINKNAME))));
				}
			}
			
			if(httpMethod.equalsIgnoreCase("PUT")){
				ArrayList<String> fields = new ArrayList<String>();
				if(!map.containsKey(ZABConstants.LINKNAME)) {
						fields.add(ZABConstants.LINKNAME);
				}
				
				if(map.containsKey(CustomEventConstants.EVENT_NAME) && map.get(CustomEventConstants.EVENT_NAME).isEmpty()){
					fields.add(CustomEventConstants.EVENT_NAME);
				}
				
				if(!fields.isEmpty()) {
					ZABRequest.updateError(map, ZABAction.getAppropriateMessage(ZABConstants.ErrorMessages.MANDATORY_FIELD_MISSING.getErrorString(),fields));
				}
			}
			
	}

}
