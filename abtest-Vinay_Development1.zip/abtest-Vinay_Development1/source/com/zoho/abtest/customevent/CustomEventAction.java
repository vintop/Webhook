//$Id$
package com.zoho.abtest.customevent;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.json.JSONException;

import com.opensymphony.xwork2.ActionSupport;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.project.ProjectConstants;
import com.zoho.abtest.utility.ZABUtil;

public class CustomEventAction extends ActionSupport implements ServletResponseAware, ServletRequestAware{

	private static final Logger LOGGER = Logger.getLogger(CustomEventAction.class.getName());
	
	private static final long serialVersionUID = 1L;
	
	private HttpServletRequest request;
	
	private HttpServletResponse response;
	
	private String linkname;
	
	public String getLinkname() {
		return linkname;
	}

	public void setLinkname(String linkname) {
		this.linkname = linkname;
	}

	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		request = arg0;
	}

	@Override
	public void setServletResponse(HttpServletResponse arg0) {
		response = arg0;
	}

	public String execute() throws Exception {
		ArrayList<CustomEvent> cusEvents = new ArrayList<CustomEvent>();
		try {			
			switch(ZABAction.getHTTPMethod(request)) {
			case POST:	
				HashMap<String,String> hs = ZABAction.getRequestParser(request).parseCustomEvent(request);
				if(hs.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					CustomEvent cusEvent = new CustomEvent();
					cusEvent.setSuccess(Boolean.FALSE);
					cusEvent.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
					cusEvents.add(cusEvent);
				}else{
					cusEvents.add(CustomEvent.createCustomEvent(hs));
				}
				break;
			case GET:
				if(linkname!=null && !linkname.isEmpty()){
					cusEvents.add(CustomEvent.getCustomEventByLinkname(linkname));
				}else{
					String search = request.getParameter(CustomEventConstants.SEARCH);
					String projectLinkname = request.getParameter(CustomEventConstants.PROJECT_LINKNAME);
					cusEvents.addAll(CustomEvent.searchCustomEvent(search, projectLinkname));
					
				}
				
			
				break;
			case DELETE:
				cusEvents.add(CustomEvent.deleteCustomEvent(linkname));
				break;
			case PUT:
				HashMap<String,String> hs1 = ZABAction.getRequestParser(request).parseCustomEvent(request);
				if(hs1.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs1.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					CustomEvent cusEvent = new CustomEvent();
					cusEvent.setSuccess(Boolean.FALSE);
					cusEvent.setResponseString(hs1.get(ZABConstants.RESPONSE_STRING));
					cusEvents.add(cusEvent);
				}else{
					cusEvents.add(CustomEvent.updateCustomEvent(hs1));
				}
				break;
			}
		}catch(JSONException ex){	
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getInvalidInputFormatException(CustomEventConstants.API_MODULE_PLURAL));
			return null; 	
		}  catch(Exception ex){
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ProjectConstants.API_MODULE_PLURAL));
			return null; 	
		}		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getCustomEventResponse(request, cusEvents));	
	    return null;
	}
	
	public String eventReport() throws Exception {
		ArrayList<CustomEventReports> reports = new ArrayList<CustomEventReports> ();
		try {			

			if(linkname!=null && !linkname.isEmpty()){
				reports.addAll(CustomEventReports.getEventReportsForEvent( linkname));
			}else{
				String projectLinkname = request.getParameter(CustomEventConstants.PROJECT_LINKNAME);
				reports.addAll(CustomEventReports.getEventReportsForProject(Project.getProjectId(projectLinkname)));

			}

		}catch(Exception ex){
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ProjectConstants.API_MODULE_PLURAL));
			return null; 	
		}		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getCustomEventReportResponse(request, reports));	
	    return null;
	}
	 
	
	
	
}
