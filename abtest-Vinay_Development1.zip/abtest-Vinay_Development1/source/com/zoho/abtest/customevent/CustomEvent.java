//$Id$
package com.zoho.abtest.customevent;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.MatchQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.CUSTOM_EVENT_GOAL;
import com.zoho.abtest.EVENTS;
import com.zoho.abtest.FUNNEL_STEP_EVENTS;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.elastic.ElasticSearchStatistics;
import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.listener.ZABNotifier;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.project.ProjectConstants;
import com.zoho.abtest.project.ProjectTreeEventConstants;
import com.zoho.abtest.project.ProjectTreeEventWrapper;
import com.zoho.abtest.project.ProjectTreeEventConstants.OperationType;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.utility.ZABUtil;

public class CustomEvent extends ZABModel{


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final Logger LOGGER = Logger.getLogger(CustomEvent.class.getName());

	private Long customEventId;
	private String customEventName;
	private String customEventLinkName;
	private String customEventDescription;
	private Integer projectLinkName;
	private Long projectId;


	public Long getCustomEventId() {
		return customEventId;
	}

	public void setCustomEventId(Long customEventId) {
		this.customEventId = customEventId;
	}

	public String getCustomEventName() {
		return customEventName;
	}

	public void setCustomEventName(String customEventName) {
		this.customEventName = customEventName;
	}

	public String getCustomEventLinkName() {
		return customEventLinkName;
	}

	public void setCustomEventLinkName(String customEventLinkName) {
		this.customEventLinkName = customEventLinkName;
	}

	public String getCustomEventDescription() {
		return customEventDescription;
	}

	public void setCustomEventDescription(String customEventDescription) {
		this.customEventDescription = customEventDescription;
	}

	public Integer getProjectLinkName() {
		return projectLinkName;
	}

	public void setProjectLinkName(Integer projectLinkName) {
		this.projectLinkName = projectLinkName;
	}

	public Long getProjectId() {
		return projectId;
	}

	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}

	public static CustomEvent getCustomEventFromRow(Row row) {
		CustomEvent cusEvent = new CustomEvent();
		cusEvent.setSuccess(Boolean.TRUE);
		cusEvent.setCustomEventId((Long)row.get(EVENTS.EVENT_ID));
		cusEvent.setProjectId((Long)row.get(EVENTS.PROJECT_ID));
		cusEvent.setCustomEventName((String)row.get(EVENTS.EVENT_NAME));
		cusEvent.setCustomEventLinkName((String)row.get(EVENTS.EVENT_LINKNAME));
		cusEvent.setCustomEventDescription((String)row.get(EVENTS.EVENT_DESCRIPTION));
		return cusEvent;
	}
	
	public static ArrayList<CustomEvent> getCustomEventFromDobj(DataObject dobj) throws DataAccessException {
		ArrayList<CustomEvent> cusEvents = new ArrayList<CustomEvent>();
		if(dobj.containsTable(EVENTS.TABLE)) {
			Iterator<?> it = dobj.getRows(EVENTS.TABLE);
			while(it.hasNext()) {
				Row row = (Row)it.next();
				CustomEvent cusEvent = getCustomEventFromRow(row);
				cusEvents.add(cusEvent);
			}
		}
		return cusEvents;
	}

	public static CustomEvent createCustomEvent(HashMap<String, String> hs) {
		CustomEvent cusEvent = null;
		try {
			
			
			String displayName = hs.get(CustomEventConstants.EVENT_NAME);
			displayName = displayName.trim();
			if(displayName.length() == 0 ){
				throw new ZABException(ZABAction.getMessage(CustomEventConstants.EVENT_EMPTY_NAME,null));
			}
			
			String projectIdParam = hs.get(CustomEventConstants.PROJECT_ID);
			Long projectId = null;
			if(projectIdParam!=null) {
				projectId = Long.parseLong(projectIdParam);
			} else {				
				String pl = hs.get(CustomEventConstants.PROJECT_LINKNAME);
				projectId = Project.getProjectId(pl);
			}
			
			Criteria c = new Criteria(new Column(EVENTS.TABLE, EVENTS.EVENT_NAME), displayName, QueryConstants.EQUAL, false);
			Criteria c2 = new Criteria(new Column(EVENTS.TABLE, EVENTS.PROJECT_ID), projectId, QueryConstants.EQUAL);
			if(resourceExists(EVENTS.TABLE, c.and(c2))) {
				throw new ZABException(ZABAction.getMessage(CustomEventConstants.EVENT_ALREADY_EXISTS,new String[]{displayName}));
			}
			
			String linkName = generateLinkName(EVENTS.TABLE, EVENTS.EVENT_LINKNAME, null, null, displayName);
			
			if(projectId == null) {
				throw new ZABException(ZABAction.getMessage(ZABConstants.ErrorMessages.RESOURCE_NOT_FOUND.getErrorString(), new String[]{ZABAction.getMessage(ProjectConstants.API_MODULE)}));
			}
			
			hs.put(CustomEventConstants.PROJECT_ID, projectId+"");
			hs.put(ZABConstants.LINKNAME, linkName);
			hs.put(CustomEventConstants.CREATED_TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
			hs.put(CustomEventConstants.CREATED_BY, ZABUtil.getCurrentUser().getUserId().toString());
			DataObject dobj = createRow(CustomEventConstants.CUSTOM_EVENT_TABLE, EVENTS.TABLE, hs);
			Long eventId = (Long)dobj.getFirstValue(EVENTS.TABLE, EVENTS.EVENT_ID);
			cusEvent = new CustomEvent();
			cusEvent.setProjectId(projectId);
			cusEvent.setSuccess(Boolean.TRUE);
			cusEvent.setCustomEventLinkName(linkName);
			cusEvent.setCustomEventId(eventId);
			ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
			wrapper.setModel(cusEvent);
			wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
			wrapper.setType(OperationType.CREATE);
			ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);

		}
		catch (ZABException e) {
			cusEvent = new CustomEvent();
			cusEvent.setSuccess(Boolean.FALSE);
			cusEvent.setResponseString(e.getMessage());
			
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		catch (Exception e) {
			cusEvent = new CustomEvent();
			cusEvent.setSuccess(Boolean.FALSE);
			cusEvent.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		return cusEvent;
	}
	
	
	
	
	public static CustomEvent updateCustomEvent(HashMap<String, String> hs) {
		CustomEvent cusEvent = null;
		try {
			
			String linkname = hs.get(ZABConstants.LINKNAME);
			CustomEvent oldCusEvent = CustomEvent.getCustomEventByLinkname(linkname);
			String displayName = hs.get(CustomEventConstants.EVENT_NAME);
			Criteria c1 = new Criteria(new Column(EVENTS.TABLE, EVENTS.EVENT_NAME), displayName, QueryConstants.EQUAL);
			Criteria c2 = new Criteria(new Column(EVENTS.TABLE, EVENTS.EVENT_ID), oldCusEvent.getCustomEventId(), QueryConstants.NOT_EQUAL);
			Criteria c3 = new Criteria(new Column(EVENTS.TABLE, EVENTS.PROJECT_ID), oldCusEvent.getProjectId(), QueryConstants.EQUAL);
			if(resourceExists(EVENTS.TABLE, c1.and(c2).and(c3))) {
				throw new ZABException(ZABAction.getMessage(CustomEventConstants.EVENT_ALREADY_EXISTS,new String[]{displayName}));
			}
			
			Criteria c = new Criteria(new Column(EVENTS.TABLE, EVENTS.EVENT_LINKNAME), linkname, QueryConstants.EQUAL);
			ZABModel.updateRow(CustomEventConstants.CUSTOM_EVENT_TABLE, EVENTS.TABLE, hs, c, CustomEventConstants.API_MODULE);
			cusEvent = new CustomEvent();
			cusEvent.setProjectId(oldCusEvent.getProjectId());
			cusEvent.setSuccess(Boolean.TRUE);
			cusEvent.setCustomEventLinkName(linkname);
			
			ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
			wrapper.setModel(cusEvent);
			wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
			wrapper.setType(OperationType.UPDATE);
			ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);
			
		}  catch (Exception e) {
			cusEvent = new CustomEvent();
			cusEvent.setSuccess(Boolean.FALSE);
			cusEvent.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		return cusEvent;
	}

	
	public static ArrayList<CustomEvent> getCustomEventByCriteria(Criteria c) {
		ArrayList<CustomEvent> cusEvents = new ArrayList<CustomEvent>();
		try {
			DataObject dobj = ZABModel.getRow(EVENTS.TABLE, c);
			cusEvents.addAll(getCustomEventFromDobj(dobj));
		} catch (Exception e) {
			CustomEvent cusEvent = new CustomEvent();
			cusEvent.setSuccess(Boolean.FALSE);
			cusEvent.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			cusEvents.add(cusEvent);
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		return cusEvents;
	}
	
	public static ArrayList<CustomEvent> searchCustomEvent(String searchString, String projectLinkname) {
		Criteria c = null;
		if(searchString!=null && !searchString.isEmpty()) {
			c = new Criteria (new Column(EVENTS.TABLE,EVENTS.EVENT_NAME),searchString, QueryConstants.CONTAINS,Boolean.FALSE);
		}
		Long projectId = Project.getProjectId(projectLinkname);
		if(projectId == null) {
			CustomEvent cusEvent = new CustomEvent();
			cusEvent.setSuccess(Boolean.FALSE);
			cusEvent.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_WITHLNAME_NOTEXISTS, new String[]{ProjectConstants.PROJECT_LABEL, projectLinkname}));
			return new ArrayList<CustomEvent>(Arrays.asList(cusEvent));
		}
		
		Criteria c2 = new Criteria(new Column(EVENTS.TABLE, EVENTS.PROJECT_ID), projectId, QueryConstants.EQUAL);
		c = (c == null)? c2: c.and(c2);
		return getCustomEventByCriteria(c);
	}

	
	
	public static CustomEvent getCustomEventByLinkname(String linkName) {
		CustomEvent cusEvent = new CustomEvent();
		try {
			Criteria c = new Criteria(new Column(EVENTS.TABLE, EVENTS.EVENT_LINKNAME), linkName, QueryConstants.EQUAL);
			DataObject dobj = getRow(EVENTS.TABLE, c);
			if(dobj.containsTable(EVENTS.TABLE)) {
				Iterator<?> it = dobj.getRows(EVENTS.TABLE);
				while(it.hasNext()) {
					Row row = (Row)it.next();
					cusEvent = getCustomEventFromRow(row);
				return cusEvent;
				}
			}
		}catch (Exception e) {
			cusEvent.setSuccess(Boolean.FALSE);
			cusEvent.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			
		}
		return cusEvent;
	}
	public static CustomEvent getCustomEventByName(String eventName) {
		CustomEvent cusEvent = new CustomEvent();
		try {
			Criteria c = new Criteria(new Column(EVENTS.TABLE, EVENTS.EVENT_NAME), eventName, QueryConstants.EQUAL);
			cusEvent = getCustomEventByCriteria(c).get(0);
		}catch (Exception e) {
			cusEvent.setSuccess(Boolean.FALSE);
			cusEvent.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		
		return cusEvent;
	}
	
	public static CustomEvent getCustomEventById(Long id) {
		
		try {
			Criteria c = new Criteria(new Column(EVENTS.TABLE, EVENTS.EVENT_ID), id, QueryConstants.EQUAL);
			DataObject dobj = getRow(EVENTS.TABLE, c);
			if(dobj.containsTable(EVENTS.TABLE)) {
				Iterator<?> it = dobj.getRows(EVENTS.TABLE);
				while(it.hasNext()) {
					Row row = (Row)it.next();
					CustomEvent cusEvent = getCustomEventFromRow(row);
				return cusEvent;
				}
			}
		}catch (Exception e) {
			CustomEvent cusEvent = new CustomEvent();
			cusEvent.setSuccess(Boolean.FALSE);
			cusEvent.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			return cusEvent;
		}
		
		return null;
	}
	
	public static CustomEvent getCustomEventByLinkname(String linkName, Long projectId) {
		
		try {
			Criteria c1 = new Criteria(new Column(EVENTS.TABLE, EVENTS.EVENT_LINKNAME), linkName, QueryConstants.EQUAL);
			Criteria c2 = new Criteria(new Column(EVENTS.TABLE, EVENTS.PROJECT_ID), projectId, QueryConstants.EQUAL);
			DataObject dobj = getRow(EVENTS.TABLE, c1.and(c2));
			if(dobj.containsTable(EVENTS.TABLE)) {
				Iterator<?> it = dobj.getRows(EVENTS.TABLE);
				while(it.hasNext()) {
					Row row = (Row)it.next();
					CustomEvent cusEvent = getCustomEventFromRow(row);
				return cusEvent;
				}
			}
		}catch (Exception e) {
			CustomEvent cusEvent = new CustomEvent();
			cusEvent.setSuccess(Boolean.FALSE);
			cusEvent.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			return cusEvent;
		}
		
		return null;
	}
	public static CustomEvent deleteCustomEvent(String linkName)
	{
		CustomEvent event = new CustomEvent();
		Criteria c = new Criteria(new Column(EVENTS.TABLE,EVENTS.EVENT_LINKNAME),linkName,QueryConstants.EQUAL);
		Join customGoalJoin = new Join(EVENTS.TABLE,CUSTOM_EVENT_GOAL.TABLE,new String[]{EVENTS.EVENT_ID}, new String[]{CUSTOM_EVENT_GOAL.EVENT_ID},Join.LEFT_JOIN );
		Join customFunnelStepJoin = new Join(EVENTS.TABLE,FUNNEL_STEP_EVENTS.TABLE,new String[]{EVENTS.EVENT_ID}, new String[]{FUNNEL_STEP_EVENTS.EVENT_ID},Join.LEFT_JOIN );
		try {
			CustomEvent oldevent = CustomEvent.getCustomEventByLinkname(linkName);
			DataObject dobj = ZABModel.getRow(EVENTS.TABLE, c, new Join[]{customFunnelStepJoin,customGoalJoin});
			if(dobj.containsTable(CUSTOM_EVENT_GOAL.TABLE) || dobj.containsTable(FUNNEL_STEP_EVENTS.TABLE)){
				event.setSuccess(Boolean.FALSE);
				event.setCustomEventLinkName(linkName);
				event.setResponseString(ZABAction.getMessage(CustomEventConstants.EVENT_DELETE_ERROR));
				return event;
			}
			ZABModel.deleteResource(c);
		
			ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
			wrapper.setModel(oldevent);
			wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
			wrapper.setType(OperationType.DELETE);
			ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);
			
			ElasticSearchUtil.deleteEventData(oldevent.getCustomEventId());
			
			event.setSuccess(Boolean.TRUE);
			event.setCustomEventLinkName(linkName);
			
		} catch (Exception e) {
			event.setSuccess(Boolean.FALSE);
			event.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		return event;
		
	}
	
	public static BoolQueryBuilder queryBuilder(String portal,Long projectid,Long eventId, Long startTime, Long endTime, String multisegmentCriteria ){
		
		BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
		MatchQueryBuilder portalMatch = QueryBuilders.matchQuery(ElasticSearchConstants.PORTAL, portal);
		MatchQueryBuilder projectMatch = QueryBuilders.matchQuery(ElasticSearchConstants.PROJECTID, projectid);
		
		List<QueryBuilder> conditionList = new ArrayList<QueryBuilder>();
		conditionList.add(portalMatch);
		conditionList.add(projectMatch);
		
		if(eventId != null){
			MatchQueryBuilder eventMatch = QueryBuilders.matchQuery(ElasticSearchConstants.EVENTID, eventId);
			conditionList.add(eventMatch);
		}

		if(startTime != null && endTime != null)
		{
			RangeQueryBuilder timeRange = QueryBuilders.rangeQuery("time").gte(startTime).lte(endTime); // No I18N
			conditionList.add(timeRange);
		}
		if(multisegmentCriteria!=null){
			BoolQueryBuilder multiSegmentQuery = ElasticSearchStatistics.generateMultiSegmentCriteria(multisegmentCriteria);
			conditionList.add(multiSegmentQuery);
		}
		
		boolQueryBuilder.must().addAll(conditionList);
		
		return boolQueryBuilder;
	}
	
	
}
