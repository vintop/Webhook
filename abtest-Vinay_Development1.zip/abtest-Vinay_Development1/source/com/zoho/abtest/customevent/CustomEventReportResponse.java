//$Id$
package com.zoho.abtest.customevent;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABResponse;

public class CustomEventReportResponse {
	public static String jsonResponse(HttpServletRequest request,ArrayList<CustomEventReports> lst) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(lst);			
			JSONObject json = ZABResponse.updateMetaInfo(request, CustomEventConstants.API_MODULE_PLURAL, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){}
		return returnBuffer.toString();
	}
	
	private static JSONObject getJSONObject(CustomEventReports ld) throws JSONException {
		JSONObject jsonObj = new JSONObject();
		jsonObj.put(CustomEventConstants.EVENT_ID, ld.getEventId());
		jsonObj.put(CustomEventConstants.UNIQUEL_EVENT_ACHIEVED_COUNT, ld.getUniqueEventCount());
		jsonObj.put(CustomEventConstants.TOTAL_EVENT_ACHIEVED_COUNT, ld.getTotalEventCount());
		jsonObj.put(CustomEventConstants.AVG_EVENT_ACHIEVED_TIME, ld.getAvgTimeToAchieveEvent());
		jsonObj.put(CustomEventConstants.UNIQUE_VISITORS, ld.getUniqueVisitors());
		jsonObj.put(CustomEventConstants.TOTAL_VISITORS, ld.getTotalVisitors());
	
		return jsonObj;
	}
	
	public static JSONArray getJSONArray(ArrayList<CustomEventReports> lst) throws JSONException {
		JSONArray array = new JSONArray();
		int size =lst.size();
		for (int i=0;i<size;i++) {
			CustomEventReports ld=lst.get(i);
			if(ld!=null) {				
				array.put(getJSONObject(ld));
			}
		}
		return array;
	}


}
