//$Id$
package com.zoho.abtest.customevent;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.zoho.abtest.EVENTS;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.project.ProjectConstants;

public class CustomEventConstants {

	public static final String API_MODULE = "customevent"; //No I18N
	public static final String API_MODULE_PLURAL = "customevents"; //No I18N
	public static final String API_RESOURCE = "resource.customevent"; //NO I18N
	public static final String API_RESOURCE_INITIAL = "resource.customevent.initial"; //NO I18N
	
	public static final String CUSTOM_EVENT_REPORTS = "eventreports"; //No I18N

	public static final String EVENT_EMPTY_NAME = "customevent.empty.name"; //NO I18N
	public static final String EVENT_ALREADY_EXISTS = "customevent.name.exists"; //NO I18N
	public static final String EVENT_DELETE_ERROR = "customevent.delete.error"; //NO I18N
	
	
	public static final String EVENT_ID = "event_id";	// NO I18N
	public static final String EVENT_NAME = "event_name";	// NO I18N
	public static final String EVENT_DESCRIPTION = "event_description";	// NO I18N
	public static final String PROJECT_ID = "project_id"; //No I18N
	public static final String CREATED_BY = ExperimentConstants.CREATED_BY;
	public static final String CREATED_TIME = ExperimentConstants.CREATED_TIME;
	
	public static final String PROJECT_LINKNAME = "project_linkname";	// NO I18N
	
	public static final String UNIQUE_VISITORS = "unique_visitors";	// NO I18N
	public static final String TOTAL_VISITORS = "total_visitors";	// NO I18N
	
	public static final String TOTAL_EVENT_ACHIEVED_COUNT = "total_count";	// NO I18N
	public static final String UNIQUEL_EVENT_ACHIEVED_COUNT = "unique_count";	// NO I18N
	public static final String AVG_EVENT_ACHIEVED_TIME = "avg_event_time";	// NO I18N
	
	public static final String SEARCH = "search";	// NO I18N
	public final static List<Constants> CUSTOM_EVENT_TABLE;
	static{
		ArrayList<Constants> list = new ArrayList<Constants>();

		list.add(new Constants(EVENT_ID,EVENTS.EVENT_ID,ZABConstants.LONG,Boolean.FALSE));
		list.add(new Constants(EVENT_NAME,EVENTS.EVENT_NAME,ZABConstants.STRING,Boolean.TRUE));
		list.add(new Constants(ZABConstants.LINKNAME,EVENTS.EVENT_LINKNAME,ZABConstants.STRING,Boolean.FALSE));
		list.add(new Constants(EVENT_DESCRIPTION,EVENTS.EVENT_DESCRIPTION,ZABConstants.STRING,Boolean.TRUE));
		list.add(new Constants(PROJECT_ID,EVENTS.PROJECT_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		list.add(new Constants(CREATED_BY,EVENTS.CREATED_BY,ZABConstants.LONG,Boolean.FALSE));
		list.add(new Constants(CREATED_TIME,EVENTS.CREATED_TIME,ZABConstants.LONG,Boolean.FALSE));
		CUSTOM_EVENT_TABLE = (List<Constants>) Collections.unmodifiableList(list);
	}
	
	


}
