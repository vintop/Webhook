//$Id$
package com.zoho.abtest.customevent;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.MatchQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.index.query.TermsQueryBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.filters.Filters;
import org.elasticsearch.search.aggregations.bucket.filters.FiltersAggregationBuilder;
import org.elasticsearch.search.aggregations.bucket.filters.FiltersAggregator;
import org.elasticsearch.search.aggregations.bucket.filters.FiltersAggregator.KeyedFilter;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.aggregations.metrics.avg.AvgAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.avg.InternalAvg;
import org.elasticsearch.search.aggregations.metrics.cardinality.InternalCardinality;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.EVENTS;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.common.ZABRequest;
import com.zoho.abtest.elastic.ESQuickFilterConstants;
import com.zoho.abtest.elastic.ElasticSearchStatistics;
import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.heatmaps.HeatmapDataRequest;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.report.ReportConstants;
import com.zoho.abtest.report.ReportRequest;
import com.zoho.abtest.revenue.RevenueReport;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.abtest.variation.Variation;

public class CustomEventReports extends ZABModel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(CustomEventReports.class.getName());
	
	
	private Long eventId;
	private Long uniqueVisitors;
	private Long totalVisitors;
	private Long uniqueEventCount;
	private Long totalEventCount;
	private Long avgTimeToAchieveEvent;
	
	
	
	public Long getEventId() {
		return eventId;
	}
	public void setEventId(Long eventId) {
		this.eventId = eventId;
	}
	public Long getUniqueVisitors() {
		return uniqueVisitors;
	}
	public void setUniqueVisitors(Long uniqueVisitors) {
		this.uniqueVisitors = uniqueVisitors;
	}
	public Long getTotalVisitors() {
		return totalVisitors;
	}
	public void setTotalVisitors(Long totalVisitors) {
		this.totalVisitors = totalVisitors;
	}
	public Long getUniqueEventCount() {
		return uniqueEventCount;
	}
	public void setUniqueEventCount(Long uniqueEventCount) {
		this.uniqueEventCount = uniqueEventCount;
	}
	public Long getTotalEventCount() {
		return totalEventCount;
	}
	public void setTotalEventCount(Long totalEventCount) {
		this.totalEventCount = totalEventCount;
	}
	public Long getAvgTimeToAchieveEvent() {
		return avgTimeToAchieveEvent;
	}
	public void setAvgTimeToAchieveEvent(Long avgTimeToAchieveEvent) {
		this.avgTimeToAchieveEvent = avgTimeToAchieveEvent;
	}
	public static HashMap<Long , String> getEventVisitorsReport(HashMap<Long,Long> eventTimeMappingHs , Long projId ,Long startTime,Long endTime, String multisegmentCriteria){
		HashMap<Long , String> visitorInfo = new HashMap<Long,String>();
		try {
			String portalName = ZABUtil.getPortalName();
			String indexName = ElasticSearchUtil.getIndexByPortal(portalName);
			ArrayList<KeyedFilter> keyedFilters = new ArrayList<KeyedFilter>();

			Iterator<?> itr = eventTimeMappingHs.keySet().iterator();
			while(itr.hasNext()){

				Long eventid = (Long) itr.next();
				Long createdTime = eventTimeMappingHs.get(eventid);
				RangeQueryBuilder timeRange = QueryBuilders.rangeQuery("time").gte(createdTime); // No I18N
				KeyedFilter  keyedFilter = new FiltersAggregator.KeyedFilter(eventid.toString(),timeRange);
				keyedFilters.add(keyedFilter);

			}

			BoolQueryBuilder query = CustomEvent.queryBuilder(portalName,projId,null,startTime,endTime,multisegmentCriteria);
			FiltersAggregationBuilder filteragg = AggregationBuilders.filters("filters",  keyedFilters.toArray(new KeyedFilter[keyedFilters.size()])).subAggregation(ElasticSearchStatistics.getVisitorCardinalityAggr());   // NO I18N

			SearchResponse response = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.VISITOR_RAW_TYPE, 0, query, filteragg);
			visitorInfo.putAll(readEvnetVisitorsResponse(response));

		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		return visitorInfo;	

	}
	private static HashMap<Long , String> readEvnetVisitorsResponse(SearchResponse response) {
		HashMap<Long , String> visitorInfo = new HashMap<Long,String>();
		Aggregations aggrResponse = response.getAggregations();
		Filters filters = aggrResponse.get("filters");
		for (Filters.Bucket entry : filters.getBuckets()) {
			Long eventId  = Long.parseLong(entry.getKeyAsString());          
			Long totalVisitors = entry.getDocCount();        
			InternalCardinality cardinality = entry.getAggregations().get("distinct_visitors");	// NO I18N
			Long uniquevisitors = cardinality.getValue();

			visitorInfo.put(eventId, totalVisitors+":"+uniquevisitors);

		}
		return visitorInfo;

	}

	public static HashMap<Long , HashMap<String,Long>> getEventAchievedReport(Long projId ,Long eventId ,Long startTime,Long endtime,String multisegmentCriteria){
		HashMap<Long , HashMap<String,Long>> eventAchievedInfo = new HashMap<Long , HashMap<String,Long>>();
		try {
			String portalName = ZABUtil.getPortalName();
			String indexName = ElasticSearchUtil.getIndexByPortal(portalName);
			BoolQueryBuilder query = CustomEvent.queryBuilder(portalName, projId, eventId ,startTime, endtime, multisegmentCriteria);
			AvgAggregationBuilder avgAggr = AggregationBuilders.avg("avg_time").field(ElasticSearchConstants.TIME_SPENT); // No I18N
			TermsAggregationBuilder finalAggr = AggregationBuilders.terms("eventid").  // No I18N
							field(ElasticSearchConstants.EVENTID).
							size(ElasticSearchConstants.EVENT_MAX_COUNT).
								subAggregation(ElasticSearchStatistics.getVisitorCardinalityAggr()).subAggregation(avgAggr) ;

		
			SearchResponse response = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.GOAL_RAW_TYPE, 0, query, finalAggr);
		    eventAchievedInfo =  readEvnetAchievedResponse(response);
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		return eventAchievedInfo;	

	}
	private static HashMap<Long , HashMap<String,Long>> readEvnetAchievedResponse(SearchResponse response) {
		HashMap<Long , HashMap<String,Long>> eventAchievedInfo = new HashMap<Long , HashMap<String,Long>>();
		
		Aggregations aggrResponse = response.getAggregations();
		Terms terms = aggrResponse.get("eventid");
		List<? extends Bucket> buckets = terms.getBuckets();
		for(Bucket bucket:buckets)
		{
			Long eventid = (Long)bucket.getKey();
			Aggregations buckaggrResponse = bucket.getAggregations();
			InternalAvg avg = buckaggrResponse.get("avg_time");
			Double avgTime  = avg.getValue();
			InternalCardinality card = buckaggrResponse.get("distinct_visitors");
			
			HashMap<String , Long> hs = new HashMap<String, Long>();
			hs.put(CustomEventConstants.AVG_EVENT_ACHIEVED_TIME, avgTime.longValue());
			hs.put(CustomEventConstants.UNIQUEL_EVENT_ACHIEVED_COUNT,card.getValue());
			hs.put(CustomEventConstants.TOTAL_EVENT_ACHIEVED_COUNT, bucket.getDocCount());
			
			eventAchievedInfo.put(eventid, hs);
			
		}
		return eventAchievedInfo;

	}

	public static ArrayList<CustomEventReports> getEventReportsForProject(Long projectId){

		ArrayList<CustomEventReports> reports = new ArrayList<CustomEventReports>();
		HashMap<Long , String> visitorsInfo = new HashMap<Long , String>();
		HashMap<Long , HashMap<String,Long>> eventsAcievedInfo = new HashMap<Long , HashMap<String,Long>>();
		try {
			HashMap<Long,Long> eventTimeMappingHs = new HashMap<Long, Long>();
			Criteria c = new Criteria(new Column(EVENTS.TABLE,EVENTS.PROJECT_ID),projectId,QueryConstants.EQUAL);
			DataObject dobj = ZABModel.getRow(EVENTS.TABLE, c);
			Iterator<?> itr = dobj.getRows(EVENTS.TABLE);


			while(itr.hasNext()){
				Row row = (Row)itr.next();
				Long eventid = (Long)row.get(EVENTS.EVENT_ID);
				Long createdTime = (Long)row.get(EVENTS.CREATED_TIME);
				if(createdTime!=null){
					eventTimeMappingHs.put(eventid, createdTime);
				}else{
					visitorsInfo.put(eventid, "0:0");
				}
			}

			visitorsInfo.putAll(getEventVisitorsReport(eventTimeMappingHs,projectId,null,null,null));
			eventsAcievedInfo = getEventAchievedReport(projectId, null , null, null, null);
			reports  = prepareEventReports(visitorsInfo,eventsAcievedInfo);
			
			
		} catch (Exception e) {

			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		return reports;
	}
	
	public static ArrayList<CustomEventReports> getEventReportsForEvent(String eventLinkName){
		
		ArrayList<CustomEventReports> reports = new ArrayList<CustomEventReports>();
		HashMap<Long , String> visitorsInfo = new HashMap<Long , String>();
		HashMap<Long , HashMap<String,Long>> eventsAcievedInfo = new HashMap<Long , HashMap<String,Long>>();
		try {
			HashMap<String,String> hs = new ReportRequest().parseSingleResourceJSON(ZABUtil.getCurrentRequest() , CustomEventConstants.CUSTOM_EVENT_REPORTS, false);
			Long startTime =null , endTime = null;
			String multiSegmentCriteria = null;
			if(hs.containsKey(ReportConstants.MULTISEGMENT_CRITERIA)){
				multiSegmentCriteria = hs.get(ReportConstants.MULTISEGMENT_CRITERIA);
			}
			if(hs.containsKey(ReportConstants.START_DATE)){
				startTime = ZABUtil.getTimeInLongFromDateFormStr(hs.get(ReportConstants.START_DATE), "yyyy-MM-dd");		// NO I18N
			}
			if(hs.containsKey(ReportConstants.END_DATE)){
				endTime = ZABUtil.getTimeInLongFromDateFormStr(hs.get(ReportConstants.END_DATE), "yyyy-MM-dd");		// NO I18N
				//Get the long value end date's last milli second
				endTime =  ZABUtil.getNthDayDateInLong(endTime, 1) - 1;
			}
			
			
			HashMap<Long,Long> eventTimeMappingHs = new HashMap<Long, Long>();
			Criteria c2 = new Criteria(new Column(EVENTS.TABLE,EVENTS.EVENT_LINKNAME),eventLinkName,QueryConstants.EQUAL);
			DataObject dobj = ZABModel.getRow(EVENTS.TABLE, c2);
			Iterator<?> itr = dobj.getRows(EVENTS.TABLE);
			Long eventid = null;
			Long projectId = null;

			if(itr.hasNext()){
				Row row = (Row)itr.next();
				eventid = (Long)row.get(EVENTS.EVENT_ID);
				Long createdTime = (Long)row.get(EVENTS.CREATED_TIME);
				projectId = (Long)row.get(EVENTS.PROJECT_ID);
				if(createdTime!=null){
					eventTimeMappingHs.put(eventid, createdTime);
				}else{
					visitorsInfo.put(eventid, "0:0");
				}
			}else{
				return reports;
			}

			visitorsInfo.putAll(getEventVisitorsReport(eventTimeMappingHs,projectId,startTime,endTime,multiSegmentCriteria));
			eventsAcievedInfo = getEventAchievedReport(projectId, eventid,startTime,endTime,multiSegmentCriteria);
			
			reports  = prepareEventReports(visitorsInfo,eventsAcievedInfo);
			
			
		} catch (Exception e) {

			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		return reports;
	}

	public static ArrayList<CustomEventReports> prepareEventReports(HashMap<Long , String> visitorsInfo , HashMap<Long , HashMap<String,Long>> eventsAcievedInfo ){
		
		ArrayList<CustomEventReports> reports = new ArrayList<CustomEventReports>();
		Iterator<Long> keyItr = visitorsInfo.keySet().iterator();
		while(keyItr.hasNext()){
			Long eventID = keyItr.next();
			String val = visitorsInfo.get(eventID);
			String valArr[] = val.split(":");
			
			 
			CustomEventReports eventReport = new CustomEventReports();
			eventReport.setUniqueVisitors(Long.parseLong(valArr[1]));
			eventReport.setTotalVisitors(Long.parseLong(valArr[0]));
			eventReport.setEventId(eventID);
			if(eventsAcievedInfo.containsKey(eventID)){
				 HashMap<String,Long> innerhs = eventsAcievedInfo.get(eventID);
				eventReport.setTotalEventCount(innerhs.get(CustomEventConstants.TOTAL_EVENT_ACHIEVED_COUNT));
				eventReport.setUniqueEventCount(innerhs.get(CustomEventConstants.UNIQUEL_EVENT_ACHIEVED_COUNT));
				eventReport.setAvgTimeToAchieveEvent(innerhs.get(CustomEventConstants.AVG_EVENT_ACHIEVED_TIME));
			}
			reports.add(eventReport);
		}
		return reports;
	}

}
