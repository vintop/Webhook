//$Id$
package com.zoho.abtest.auditlog;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.SortColumn;
import com.adventnet.iam.IAMProxy;
import com.adventnet.iam.ServiceOrg;
import com.adventnet.iam.User;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.ADMIN_CONSOLE_AUDIT_LOG;
import com.zoho.abtest.auditlog.AuditLogConstants.AuditLogEntityType;
import com.zoho.abtest.auditlog.AuditLogConstants.AuditLogType;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUtil;

public class AdminConsoleAuditLog extends ZABModel
{
	private static final long serialVersionUID = 1L;

	private static final Logger LOGGER = Logger.getLogger(AdminConsoleAuditLog.class.getName());
	
	private Long adminConsoleAuditLogId;
	private Integer logType;
	private Integer entityType;
	private String entityValue;
	private String newValue;
	private String oldValue;
	private Long time;
	private String formattedTime;
	private String dateOnly;
	private String timeOnly;
	private Long userZuid;
	private String userName;
	private String message;
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getFormattedTime() {
		return formattedTime;
	}
	public void setFormattedTime(String formattedTime) {
		this.formattedTime = formattedTime;
	}
	public String getDateOnly() {
		return dateOnly;
	}
	public void setDateOnly(String dateOnly) {
		this.dateOnly = dateOnly;
	}
	public String getTimeOnly() {
		return timeOnly;
	}
	public void setTimeOnly(String timeOnly) {
		this.timeOnly = timeOnly;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Long getAdminConsoleAuditLogId() {
		return adminConsoleAuditLogId;
	}
	public void setAdminConsoleAuditLogId(Long adminConsoleAuditLogId) {
		this.adminConsoleAuditLogId = adminConsoleAuditLogId;
	}
	public Integer getLogType() {
		return logType;
	}
	public void setLogType(Integer logType) {
		this.logType = logType;
	}
	public Integer getEntityType() {
		return entityType;
	}
	public void setEntityType(Integer entityType) {
		this.entityType = entityType;
	}
	public String getEntityValue() {
		return entityValue;
	}
	public void setEntityValue(String entityValue) {
		this.entityValue = entityValue;
	}
	public String getNewValue() {
		return newValue;
	}
	public void setNewValue(String newValue) {
		this.newValue = newValue;
	}
	public String getOldValue() {
		return oldValue;
	}
	public void setOldValue(String oldValue) {
		this.oldValue = oldValue;
	}
	public Long getTime() {
		return time;
	}
	public void setTime(Long time) {
		this.time = time;
	}
	public Long getUserZuid() {
		return userZuid;
	}
	public void setUserZuid(Long userZuid) {
		this.userZuid = userZuid;
	}
	
	public static void createAdminConsoleAuditLog(HashMap<String, String> hs) 
	{
		try
		{
			ZABModel.createRow(AuditLogConstants.ADMIN_CONSOLE_AUDIT_LOG_CONSTANTS, ADMIN_CONSOLE_AUDIT_LOG.TABLE, hs);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
	
	public static void createAdminConsoleAuditLog(ArrayList<HashMap<String, String>> hsList) 
	{
		try
		{
			ZABModel.createRow(AuditLogConstants.ADMIN_CONSOLE_AUDIT_LOG_CONSTANTS, ADMIN_CONSOLE_AUDIT_LOG.TABLE, hsList);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
	
	public static List<AdminConsoleAuditLog> getAdminConsoleAuditLog(Long startTime, Long endTime)
	{
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		List<AdminConsoleAuditLog> logList = new ArrayList<AdminConsoleAuditLog>();
		try
		{
			Criteria criteria1 = new Criteria(new Column(ADMIN_CONSOLE_AUDIT_LOG.TABLE, ADMIN_CONSOLE_AUDIT_LOG.TIME), new Long[]{startTime,endTime}, QueryConstants.BETWEEN);
			SortColumn sortColumn = new SortColumn(ADMIN_CONSOLE_AUDIT_LOG.TABLE, ADMIN_CONSOLE_AUDIT_LOG.TIME, Boolean.FALSE);
			DataObject dataObj = ZABModel.getRow(ADMIN_CONSOLE_AUDIT_LOG.TABLE, criteria1,sortColumn,null);
			Iterator<?> iter = dataObj.getRows(ADMIN_CONSOLE_AUDIT_LOG.TABLE);
			while(iter.hasNext())
			{
				Row row = (Row)iter.next();
				AdminConsoleAuditLog logObj = getAdminConsoleAuditLogFromRow(row);
				logList.add(logObj);
			}
			
			//construct readable messages
			populateAuditLogReadableEntries(logList);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		return logList;
	}
	
	public static void populateAuditLogReadableEntries(List<AdminConsoleAuditLog> logList)
	{
		if(logList.size() == 0)
		{
			return;
		}
		
		try
		{
			Set<Long> zuids = new HashSet<Long>();
			Set<Long> zsoids = new HashSet<Long>();
			
			//Get zuid and zsoid list
			for(AdminConsoleAuditLog auditLog:logList)
			{
				if(auditLog.getEntityType().equals(AuditLogEntityType.USER.getEntityType()))
				{
					zuids.add(Long.parseLong(auditLog.getEntityValue()));
				}
				else if(auditLog.getEntityType().equals(AuditLogEntityType.SPACE.getEntityType()))
				{
					zsoids.add(Long.parseLong(auditLog.getEntityValue()));
				}
				zuids.add(auditLog.getUserZuid());
			}
			
			//Fetch the user and serviceorg details from IAM
			List<ServiceOrg> serviceOrgList = ZABServiceOrgUtil.getServiceOrgs(zsoids.toArray(new Long[zsoids.size()]));
			HashMap<Long, ServiceOrg> sOrgHs = new HashMap<Long, ServiceOrg>();
			if(serviceOrgList != null)
			{
				for(ServiceOrg sOrg:serviceOrgList)
				{
					sOrgHs.put(sOrg.getZSOID(), sOrg);
				}
			}
			
			List<User> userList = IAMProxy.getInstance().getUserAPI().getUsers(zuids.toArray(new Long[zuids.size()]));
			HashMap<Long, User> userHs = new HashMap<Long, User>();
			if(userList != null)
			{
				for(User user:userList)
				{
					userHs.put(user.getZUID(), user);
				}
			}
			
			//Prepare the readable entries
			for(AdminConsoleAuditLog auditLog:logList)
			{
				String message = prepareAuditLogMessage(auditLog, userHs, sOrgHs);
				User userObj = userHs.get(auditLog.getUserZuid());
				String userName = userObj.getLastName() + " " + userObj.getFirstName();
				HashMap<String, String> formattedTimes = ZABUtil.getDateTimeAllFormatted(auditLog.getTime());
				String formattedTime = formattedTimes.get(ZABConstants.DATETIME);
				String formattedTimeOnly = formattedTimes.get(ZABConstants.TIME);
				String formattedDateOnly = formattedTimes.get(ZABConstants.DATE);
				auditLog.setMessage(message);
				auditLog.setUserName(userName);
				auditLog.setFormattedTime(formattedTime);
				auditLog.setDateOnly(formattedDateOnly);
				auditLog.setTimeOnly(formattedTimeOnly);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
	
	public static AdminConsoleAuditLog getAdminConsoleAuditLogFromRow(Row row)
	{
		AdminConsoleAuditLog logObj = new AdminConsoleAuditLog();
		logObj.setAdminConsoleAuditLogId((Long)row.get(ADMIN_CONSOLE_AUDIT_LOG.ADMIN_CONSOLE_AUDIT_LOG_ID));
		logObj.setEntityType((Integer)row.get(ADMIN_CONSOLE_AUDIT_LOG.ENTITY_TYPE));
		logObj.setEntityValue((String)row.get(ADMIN_CONSOLE_AUDIT_LOG.ENTITY_VALUE));
		logObj.setLogType((Integer)row.get(ADMIN_CONSOLE_AUDIT_LOG.LOG_TYPE));
		logObj.setOldValue((String)row.get(ADMIN_CONSOLE_AUDIT_LOG.OLD_VALUE));
		logObj.setNewValue((String)row.get(ADMIN_CONSOLE_AUDIT_LOG.NEW_VALUE));
		logObj.setTime((Long)row.get(ADMIN_CONSOLE_AUDIT_LOG.TIME));
		logObj.setUserZuid((Long)row.get(ADMIN_CONSOLE_AUDIT_LOG.USER_ZUID));
		logObj.setSuccess(true);
		return logObj;
	}
	
	public static String prepareAuditLogMessage(AdminConsoleAuditLog logObj, HashMap<Long, User> userHs, HashMap<Long, ServiceOrg> serviceOrgHs)
	{
		String message = "";
		try
		{
			//userMail or space name
			String primaryDisplayName = "";
			String entityValue = logObj.getEntityValue();
			String oldValue = logObj.getOldValue();
			String newValue = logObj.getNewValue();
			
			AuditLogEntityType entityType = AuditLogEntityType.getAuditLogEntityType(logObj.getEntityType());
			switch(entityType)
			{
			case USER:
				Long zuid = Long.parseLong(entityValue);
				primaryDisplayName = userHs.get(zuid).getPrimaryEmail();
				break;
			case SPACE:
				Long zsoid = Long.parseLong(entityValue);
				ServiceOrg sOrg = serviceOrgHs.get(zsoid);
				primaryDisplayName = sOrg.getOrgName() + " - " + sOrg.getZSOID();
				break;
			}
			
			AuditLogType logType = AuditLogType.getAuditLogType(logObj.getLogType());
			switch(logType)
			{
			case VIEW_USER_SPACE_DETAILS:
				message = ZABAction.getMessage(AuditLogType.VIEW_USER_SPACE_DETAILS.getMessageKey(), new String[]{primaryDisplayName});
				break;
			case EDIT_SPACE_LICENSE_ENDDATE:
				oldValue = ZABUtil.getDateTimeFormatted(Long.parseLong(oldValue));
				newValue = ZABUtil.getDateTimeFormatted(Long.parseLong(newValue));
				message = ZABAction.getMessage(AuditLogType.EDIT_SPACE_LICENSE_ENDDATE.getMessageKey(), new String[]{primaryDisplayName,oldValue,newValue});
				break;
			case EDIT_SPACE_LICENSE_PROJECTCOUNT:
				message = ZABAction.getMessage(AuditLogType.EDIT_SPACE_LICENSE_PROJECTCOUNT.getMessageKey(), new String[]{primaryDisplayName,oldValue,newValue});
				break;
			case EDIT_SPACE_LICENSE_VISITORCOUNT:
				message = ZABAction.getMessage(AuditLogType.EDIT_SPACE_LICENSE_VISITORCOUNT.getMessageKey(), new String[]{primaryDisplayName,oldValue,newValue});
				break;
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		return message;
	}
}
