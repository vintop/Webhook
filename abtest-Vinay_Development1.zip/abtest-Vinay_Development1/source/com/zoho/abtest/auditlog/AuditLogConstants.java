//$Id$
package com.zoho.abtest.auditlog;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.zoho.abtest.ADMIN_CONSOLE_AUDIT_LOG;
import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.license.LicenseConstants;

public class AuditLogConstants 
{
	public static final String API_MODULE = "auditlog";			// No I18N
	
	public static final String ADMIN_CONSOLE_AUDIT_LOG_ID = "admin_console_audit_log_id";			// No I18N
	public static final String LOG_TYPE = "log_type";			// No I18N
	public static final String ENTITY_TYPE = "entity_type";			// No I18N
	public static final String ENTITY_VALUE = "entity_value";			// No I18N
	public static final String NEW_VALUE = "new_value";			// No I18N
	public static final String OLD_VALUE = "old_value";			// No I18N
	public static final String TIME = "time";			// No I18N
	public static final String USER_ZUID = "user_zuid";			// No I18N
	
	public static enum AuditLogType
	{
		VIEW_USER_SPACE_DETAILS(1,"auditlog.view.userspace"), // No I18N
		EDIT_SPACE_LICENSE_ENDDATE(2,"auditlog.edit.spacelicense.enddate"), // No I18N
		EDIT_SPACE_LICENSE_PROJECTCOUNT(3,"auditlog.edit.spacelicense.projectcount"), // No I18N
		EDIT_SPACE_LICENSE_VISITORCOUNT(4,"auditlog.edit.spacelicense.visitorcount"); // No I18N
		
		private Integer logType;
		private String messageKey;
		
		private AuditLogType(Integer logType, String messageKey)
		{
			this.logType = logType;
			this.messageKey = messageKey;
		}
		
		public Integer getLogType() {
			return logType;
		}
		public void setLogType(Integer logType) {
			this.logType = logType;
		}
		public String getMessageKey() {
			return messageKey;
		}
		public void setMessageKey(String messageKey) {
			this.messageKey = messageKey;
		}
		
		public static AuditLogType getAuditLogType(Integer logType)
		{
			AuditLogType logTypeObj = null;
			for(AuditLogType auditLogType:AuditLogType.values())
			{
				if(auditLogType.getLogType().equals(logType))
				{
					logTypeObj = auditLogType;
					break;
				}
			}
			return logTypeObj;
		}
	}
	
	public static enum AuditLogEntityType
	{
		USER(1),
		SPACE(2);
		
		private Integer entityType;
		
		private AuditLogEntityType(Integer entityType)
		{
			this.entityType = entityType;
		}

		public Integer getEntityType() {
			return entityType;
		}

		public void setEntityType(Integer entityType) {
			this.entityType = entityType;
		}
		
		public static AuditLogEntityType getAuditLogEntityType(Integer entityType)
		{
			AuditLogEntityType entityTypeObj = null;
			for(AuditLogEntityType entityObj:AuditLogEntityType.values())
			{
				if(entityObj.getEntityType().equals(entityType))
				{
					entityTypeObj = entityObj;
					break;
				}
			}
			return entityTypeObj;
		}
	}
	
	public static final List<Constants> ADMIN_CONSOLE_AUDIT_LOG_CONSTANTS;
	
	static{
		List<Constants> acAuditLogConstants = new ArrayList<Constants>();
		acAuditLogConstants.add(new Constants(ADMIN_CONSOLE_AUDIT_LOG_ID,ADMIN_CONSOLE_AUDIT_LOG.ADMIN_CONSOLE_AUDIT_LOG_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		acAuditLogConstants.add(new Constants(LOG_TYPE,ADMIN_CONSOLE_AUDIT_LOG.LOG_TYPE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.TRUE));
		acAuditLogConstants.add(new Constants(ENTITY_TYPE,ADMIN_CONSOLE_AUDIT_LOG.ENTITY_TYPE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.TRUE));
		acAuditLogConstants.add(new Constants(ENTITY_VALUE,ADMIN_CONSOLE_AUDIT_LOG.ENTITY_VALUE,ZABConstants.STRING,Boolean.TRUE,Boolean.TRUE));
		acAuditLogConstants.add(new Constants(NEW_VALUE,ADMIN_CONSOLE_AUDIT_LOG.NEW_VALUE,ZABConstants.STRING,Boolean.TRUE,Boolean.TRUE));
		acAuditLogConstants.add(new Constants(OLD_VALUE,ADMIN_CONSOLE_AUDIT_LOG.OLD_VALUE,ZABConstants.STRING,Boolean.TRUE,Boolean.TRUE));
		acAuditLogConstants.add(new Constants(TIME,ADMIN_CONSOLE_AUDIT_LOG.TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		acAuditLogConstants.add(new Constants(USER_ZUID,ADMIN_CONSOLE_AUDIT_LOG.USER_ZUID,ZABConstants.LONG,Boolean.TRUE,Boolean.TRUE));
		ADMIN_CONSOLE_AUDIT_LOG_CONSTANTS = Collections.unmodifiableList(acAuditLogConstants);
	}
	
	public static final List<String> LICENSE_UPDATE_ATTR_TO_TRACE;
	
	static
	{
		List<String> licenseUpdateAttrToTrace = new ArrayList<String>();
		licenseUpdateAttrToTrace.add(LicenseConstants.END_TIME);
		licenseUpdateAttrToTrace.add(LicenseConstants.PROJECT_COUNT);
		licenseUpdateAttrToTrace.add(LicenseConstants.TOTAL_COUNT);
		LICENSE_UPDATE_ATTR_TO_TRACE = Collections.unmodifiableList(licenseUpdateAttrToTrace);
	}
}
