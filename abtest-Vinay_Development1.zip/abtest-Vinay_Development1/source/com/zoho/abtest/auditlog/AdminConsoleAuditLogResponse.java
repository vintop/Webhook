//$Id$
package com.zoho.abtest.auditlog;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;
import com.zoho.abtest.eventactivity.EventActivityConstants;

public class AdminConsoleAuditLogResponse 
{
	private static final Logger LOGGER = Logger.getLogger(AdminConsoleAuditLogResponse.class.getName());
	
	public static String jsonResponse(HttpServletRequest request,List<AdminConsoleAuditLog> lst, String module) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(lst);			
			JSONObject json = ZABResponse.updateMetaInfo(request, module, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		return returnBuffer.toString();
	}
	
	public static JSONArray getJSONArray(List<AdminConsoleAuditLog> lst) throws JSONException {
		JSONArray array = new JSONArray();
		int size =lst.size();
		for (int i=0;i<size;i++) {
			AdminConsoleAuditLog auditLog=lst.get(i);
			JSONObject jsonObj = new JSONObject();
			
			jsonObj.put(AuditLogConstants.ADMIN_CONSOLE_AUDIT_LOG_ID, auditLog.getAdminConsoleAuditLogId());
			jsonObj.put(AuditLogConstants.ENTITY_TYPE, auditLog.getEntityType());
			jsonObj.put(AuditLogConstants.ENTITY_VALUE, auditLog.getEntityValue());
			jsonObj.put(AuditLogConstants.LOG_TYPE, auditLog.getLogType());
			jsonObj.put(AuditLogConstants.NEW_VALUE, auditLog.getNewValue());
			jsonObj.put(EventActivityConstants.OLD_VALUE, auditLog.getOldValue());
			jsonObj.put(EventActivityConstants.MESSAGE, auditLog.getMessage());
			jsonObj.put(EventActivityConstants.TIME, auditLog.getTime());
			jsonObj.put(EventActivityConstants.FORMATTED_TIME, auditLog.getFormattedTime());
			jsonObj.put(EventActivityConstants.FORMATTED_TIME_ONLY, auditLog.getTimeOnly());
			jsonObj.put(EventActivityConstants.FORMATTED_DATE_ONLY, auditLog.getDateOnly());
			jsonObj.put(EventActivityConstants.USER_ID, auditLog.getUserZuid());
			jsonObj.put(EventActivityConstants.USER_NAME, auditLog.getUserName());
			jsonObj.put(ZABConstants.SUCCESS, auditLog.getSuccess());
			array.put(jsonObj);
		}
		return array;
	}
}
