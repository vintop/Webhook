//$Id$
package com.zoho.abtest.heatmaps;

public class ScrollmapConstants {
	
	public static final String API_MODULE = "scrollmapreports"; //NO I18N
	
	public static final String EXPERIMENT_LINKNAME = "EXPERIMENT_LINKNAME"; //NO I18N
	public static final String VARIATION_LINKNAME = "VARIATION_LINKNAME"; //NO I18N
	public static final String START_DATE = "START_DATE"; //NO I18N
	public static final String END_DATE = "END_DATE"; //NO I18N
	
	public static final String EXPERIMENT_ID = "EXPERIMENT_ID"; //NO I18N
	public static final String VARIATION_ID = "VARIATION_ID"; //NO I18N
	public static final String POINT_Y1 = "POINT_Y1"; //NO I18N
	public static final String POINT_Y2 = "POINT_Y2"; //NO I18N
	public static final String HEIGHT = "HEIGHT"; //NO I18N
	public static final String CURRENTURL_CODE = "CURRENTURL_CODE"; //NO I18N
	public static final String DEVICE_CODE = "DEVICE_CODE"; //NO I18N
	public static final String USERTYPE_CODE = "USERTYPE_CODE"; //NO I18N
	public static final String DAYOFWEEK_CODE = "DAYOFWEEK_CODE"; //NO I18N
	public static final String HOUROFDAY_CODE = "HOUROFDAY_CODE"; //NO I18N
	public static final String VISIT_ID = "VISIT_ID"; //NO I18N
	public static final String UNIQUECOUNT_FLAG = "UNIQUECOUNT_FLAG"; //NO I18N
	public static final String TOTALCOUNT_FLAG = "TOTALCOUNT_FLAG"; //NO I18N
	public static final String TIME = "TIME"; //NO I18N
	public static final String TOTAL_COUNT = "TOTAL_COUNT"; //NO I18N
	public static final String DATE = "DATE"; //NO I18N
	public static final String HOUR = "HOUR"; //NO I18N
	
}
