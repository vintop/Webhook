//$Id$
package com.zoho.abtest.heatmaps;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Logger;

import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.experiment.Experiment;

public class Heatmap extends ZABModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = Logger.getLogger(Experiment.class.getName());

	private Long experimentId;
	private String experimentLinkname;
	private String variationLinkname;
	private Long startDate ;
	private Long endDate ;
	private Long activeDays;
	private Long visitsCount;
	private Long visitorsCount;
	private Long engagedVisitorCount;
	private double engagedVisitorPercentage;
	private double totalClicks;
	private double clicksPerVisit;
	
	private ArrayList<HashMap<String,Object>> deviceVisits = new ArrayList<HashMap<String,Object>>();
	private ArrayList<HashMap<String,Object>> topclicks = new ArrayList<HashMap<String,Object>>();
	private HashMap<String,ArrayList<ArrayList<Double>>> heatmapPoints;
	private HashMap<String,String> hmpoints;
	private HashMap<String,HashMap<String,Object>> urldetails;
	
	public Long getExperimentId() {
		return experimentId;
	}

	public void setExperimentId(Long experimentId) {
		this.experimentId = experimentId;
	}
	
	public HashMap<String,ArrayList<ArrayList<Double>>> getHeatmapPoints() {
		return heatmapPoints;
	}

	public void setHeatmapPoints(HashMap<String,ArrayList<ArrayList<Double>>> heatmapPoints) {
		this.heatmapPoints = heatmapPoints;
	}

	public String getExperimentLinkname() {
		return experimentLinkname;
	}

	public void setExperimentLinkname(String experimentLinkname) {
		this.experimentLinkname = experimentLinkname;
	}

	public String getVariationLinkname() {
		return variationLinkname;
	}

	public void setVariationLinkname(String variationLinkname) {
		this.variationLinkname = variationLinkname;
	}
	
	public Long getEndDate() {
		return endDate;
	}

	public void setEndDate(Long endDate) {
		this.endDate = endDate;
	}

	public Long getStartDate() {
		return startDate;
	}

	public void setStartDate(Long startDate) {
		this.startDate = startDate;
	}
	
	public Long getActiveDays() {
		return activeDays;
	}

	public void setActiveDays(Long activeDays) {
		this.activeDays = activeDays;
	}

	public double getClicksPerVisit() {
		return clicksPerVisit;
	}

	public void setClicksPerVisit(double clicksPerVisit) {
		this.clicksPerVisit = clicksPerVisit;
	}

	public Long getVisitsCount() {
		return visitsCount;
	}
	
	public void setVisitsCount(Long visitsCount) {
		this.visitsCount = visitsCount;
	}
	
	public Long getVisitorsCount() {
		return visitorsCount;
	}

	public void setVisitorsCount(Long visitorsCount) {
		this.visitorsCount = visitorsCount;
	}

	public Long getEngagedVisitorCount() {
		return engagedVisitorCount;
	}

	public void setEngagedVisitorCount(Long engagedVisitorCount) {
		this.engagedVisitorCount = engagedVisitorCount;
	}
	
	public HashMap<String,String> getHmpoints() {
		return hmpoints;
	}

	public void setHmpoints(HashMap<String,String> hmpoints) {
		this.hmpoints = hmpoints;
	}

	public double getTotalClicks() {
		return totalClicks;
	}

	public void setTotalClicks(double totalClicks2) {
		this.totalClicks = totalClicks2;
	}
	
	public ArrayList<HashMap<String,Object>> getTopclicks() {
		return topclicks;
	}

	public void setTopclicks(ArrayList<HashMap<String,Object>> topclicks) {
		this.topclicks = topclicks;
	}

	public double getEngagedVisitorPercentage() {
		return engagedVisitorPercentage;
	}

	public void setEngagedVisitorPercentage(double engagedVisitorPercentage) {
		this.engagedVisitorPercentage = engagedVisitorPercentage;
	}

	public ArrayList<HashMap<String,Object>> getDeviceVisits() {
		return deviceVisits;
	}

	public void setDeviceVisits(ArrayList<HashMap<String,Object>> deviceVisits) {
		this.deviceVisits = deviceVisits;
	}

	public HashMap<String,HashMap<String,Object>> getUrldetails() {
		return urldetails;
	}

	public void setUrldetails(HashMap<String,HashMap<String,Object>> urldetails) {
		this.urldetails = urldetails;
	}



}
