//$Id$
package com.zoho.abtest.heatmaps;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.json.JSONException;

import com.opensymphony.xwork2.ActionSupport;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUtil;

public class HeatmapAction extends ActionSupport implements ServletResponseAware, ServletRequestAware{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = Logger.getLogger(HeatmapAction.class.getName());

	private HttpServletRequest request;
	
	private HttpServletResponse response;
	private String experimentLinkName ;
	private String variationLinkName ;
	private String portalname ;
	
	public void setServletRequest(HttpServletRequest arg0) {
		request = arg0;
	}


	public void setServletResponse(HttpServletResponse arg0) {
		response = arg0;
	}
	
	public String getPortalname() {
		return portalname;
	}


	public void setPortalname(String portalname) {
		this.portalname = portalname;
	}
	
	public String getExperimentLinkName() {
		return experimentLinkName;
	}

	public void setExperimentLinkName(String experimentLinkName) {
		this.experimentLinkName = experimentLinkName;
		request.setAttribute(HeatmapConstants.EXPERIMENT_LINKNAME, experimentLinkName);
	}
	
	public void setVariationLinkName(String variationLinkName) {
		this.variationLinkName = variationLinkName;
		request.setAttribute(HeatmapConstants.VARIATION_LINKNAME, variationLinkName);
	}
	
	public String getExperimentHeatmapUrls() throws Exception{
		
		ArrayList<Heatmap> heatmap = new ArrayList<Heatmap>();
		try {			
			switch(ZABAction.getHTTPMethod(request)) {
				case GET:
					String experimentLinkname = (String)request.getParameter(HeatmapConstants.EXPERIMENT_LINKNAME.toLowerCase());
					heatmap.add(HeatmapElasticSearch.getExperiemntURLCollection(experimentLinkname));
					break;
			}
		}
		catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), HeatmapExperimentConstants.API_MODULE_PLURAL));
			return null; 	
		}	
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getHeatmapDataResponse(request, heatmap));
		return null;	
	}
	
	public String getHeatmapElasticReport() throws Exception 
	{
		
		ArrayList<Heatmap> heatmapreport = new ArrayList<Heatmap>();
		HashMap<String,String> hs;
		try {			
			
			switch(ZABAction.getHTTPMethod(request)) {
			case POST:	
 
				hs = ZABAction.getRequestParser(request).parseHeatmapReport(request);

				if(hs.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					Heatmap report = new Heatmap();
					report.setSuccess(Boolean.FALSE);
					report.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
					heatmapreport.add(report);
					LOGGER.log(Level.SEVERE,hs.get(ZABConstants.RESPONSE_STRING));
				}else{
					//TODO ES
					heatmapreport.addAll(HeatmapElasticSearch.getHeatmapInformation(hs));
				}
				break;
			default:
				break;
			}
		} catch(Exception ex){
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), HeatmapConstants.API_MODULE));
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
			return null; 	
		}	
		
		//response.setHeader("Access-Control-Allow-Origin","*"); //NO I18N
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getHeatmapDataResponse(request, heatmapreport));		  
		return null;
	}
	
	public String getScrollmapElasticReport() throws IOException, JSONException 
	{
		
		ArrayList<Scrollmap> scrollmapdata = new ArrayList<Scrollmap>();
		HashMap<String,String> hs;
		try {			
			
			switch(ZABAction.getHTTPMethod(request)) {
			case POST:	
 
				hs = ZABAction.getRequestParser(request).parseScrollmapReport(request);

				if(hs.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					Scrollmap report = new Scrollmap();
					report.setSuccess(Boolean.FALSE);
					report.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
					scrollmapdata.add(report);
					LOGGER.log(Level.SEVERE,hs.get(ZABConstants.RESPONSE_STRING));
				}else{
					//TODO ES
					scrollmapdata.addAll(ScrollmapElasticSearch.getScrollmapInformation(hs));
				}
				break;
			default:
				break;
			}
		} catch(Exception ex){
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ScrollmapConstants.API_MODULE));
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
			return null; 	
		}	
		
		//response.setHeader("Access-Control-Allow-Origin","*"); //NO I18N
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getScrollmapDataResponse(request, scrollmapdata));		  
		return null;
	}
	
	public String getAttentionmapElasticReport() throws IOException, JSONException 
	{
		//Attentionmap is similar to scrollmap except the data aggregation part
		ArrayList<Scrollmap> attentionmapdata = new ArrayList<Scrollmap>();
		HashMap<String,String> hs;
		try {			
			
			switch(ZABAction.getHTTPMethod(request)) {
			case POST:	
 
				hs = ZABAction.getRequestParser(request).parseAttentionmapReport(request);

				if(hs.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					Scrollmap report = new Scrollmap();
					report.setSuccess(Boolean.FALSE);
					report.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
					attentionmapdata.add(report);
					LOGGER.log(Level.SEVERE,hs.get(ZABConstants.RESPONSE_STRING));
				}else{
					//TODO ES
					attentionmapdata.addAll(AttentionmapElasticSearch.getAttentionmapInformation(hs));
				}
				break;
			default:
				break;
			}
		} catch(Exception ex){
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), HeatmapConstants.ATTENTIONMAP_API_MODULE));
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
			return null; 	
		}	
		
		//response.setHeader("Access-Control-Allow-Origin","*"); //NO I18N
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getAttentionmapDataResponse(request, attentionmapdata));		  
		return null;
	}
	
	public String getHeatmapReport() throws IOException, JSONException {
		
		ArrayList<Heatmap> heatmapdata = new ArrayList<Heatmap>();
		HashMap<String,String> hs = new HashMap<String, String>();
		
		try{
			
			String dbSpaceId = null;
			Long zsoid = ZABServiceOrgUtil.getZSOIDFromDomain(portalname);
			if(zsoid != null)
			{
				dbSpaceId = zsoid.toString();
			}
			else
			{
				LOGGER.log(Level.SEVERE,"Invalid portal provided :"+portalname);
			}
			
			ZABUtil.setDBSpace(dbSpaceId);
			
			hs.put(HeatmapConstants.PORTAL,portalname);
			hs.put(HeatmapConstants.EXPERIMENT_LINKNAME,experimentLinkName);
			hs.put(HeatmapConstants.VARIATION_LINKNAME, variationLinkName);
			hs.put(HeatmapConstants.START_DATE, request.getParameter(HeatmapConstants.START_DATE.toLowerCase()));
			hs.put(HeatmapConstants.END_DATE, request.getParameter(HeatmapConstants.END_DATE.toLowerCase()));
			hs.put(HeatmapConstants.DEVICE, request.getParameter(HeatmapConstants.DEVICE.toLowerCase()));

			//heatmapdata.addAll(Heatmap.getHeatmapInformation(hs));
			heatmapdata.addAll(HeatmapElasticSearch.getHeatmapInformation(hs));

			
		}catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), HeatmapConstants.API_MODULE));
			return null; 	
		}	
		
		response.setHeader("Access-Control-Allow-Origin","*"); //NO I18N
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getHeatmapDataResponse(request, heatmapdata));		  
		return null;
	}

}