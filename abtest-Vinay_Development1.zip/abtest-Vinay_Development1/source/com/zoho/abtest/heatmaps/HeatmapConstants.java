//$Id$
package com.zoho.abtest.heatmaps;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.zoho.abtest.EXPERIMENT_HEATMAP;
import com.zoho.abtest.HEATMAP_EXPERIMENT_VISITS;
import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.ZABConstants;

public class HeatmapConstants {
	
	public static final String API_MODULE = "heatmapreports"; //NO I18N
	public static final String ATTENTIONMAP_API_MODULE = "attentionmapreports"; //NO I18N
	
	public static final String HEATMAP_EXPERIMENT_VISITS_ID = "HEATMAP_EXPERIMENT_VISITS_ID"; //NO I18N
	public static final String HEATMAP_EXPERIMENT_ID = "HEATMAP_EXPERIMENT_ID"; //NO I18N
	public static final String HEATMAP_ENABLED_EXPERIMENT_ID = "HEATMAP_EXPERIMENT_ID"; //NO I18N
	public final static String DEFAULT_MAX_VISITOR_COUNT = "5000"; //NO I18N
	
	public static final String EXPERIMENT_LINKNAME = "EXPERIMENT_LINKNAME"; //NO I18N
	public static final String VARIATION_LINKNAME = "VARIATION_LINKNAME"; //NO I18N
	public static final String HEATMAP_POINTS = "HEATMAP_POINTS"; //NO I18N
	public static final String SCROLL_POINTS = "SCROLL_POINTS"; //NO I18N
	public static final String START_DATE = "START_DATE"; //NO I18N
	public static final String END_DATE = "END_DATE"; //NO I18N
	public static final String VISITS_COUNT = "VISITS_COUNT"; //NO I18N
	public static final String VISITORS_COUNT = "VISITORS_COUNT"; //NO I18N
	
	public static final String CLICK_DATA = "CLICK_DATA"; //NO I18N
	public static final String SCROLL_DATA = "SCROLL_DATA"; //NO I18N
	public static final String AVERAGE_FOLD = "AVERAGE_FOLD"; //NO I18N
	public static final String URL_DETAILS = "URL_DETAILS"; //NO I18N
	public static final String ATTENTION_DATA = "ATTENTION_DATA"; //NO I18N
	
	public static final String TOTAL_CLICKS = "TOTAL_CLICKS"; //NO I18N
	public static final String ENGAGED_VISITORS = "ENGAGED_VISITORS"; //NO I18N
	public static final String ENGAGED_VISITORS_PERCENTAGE = "ENGAGED_VISITORS_PERCENTAGE"; //NO I18N
	public static final String CLICKS_PER_VISIT = "CLICKS_PER_VISIT"; //NO I18N
	public static final String ACTIVE_DAYS = "ACTIVE_DAYS"; //NO I18N
	public static final String TOP_CLICKS = "TOP_CLICKS"; //NO I18N
	public static final String ALL_DEVICE_VISITS = "ALL_DEVICE_VISITS"; //NO I18N
	public static final String URLS = "URLS"; //NO I18N
	
	public static final String PORTAL = "PORTAL"; //NO I18N
	public static final String EXPERIMENT_ID = "EXPERIMENT_ID"; //NO I18N
	public static final String VARIATION_ID = "VARIATION_ID"; //NO I18N
	public static final String SELECTOR = "SELECTOR"; //NO I18N
	public static final String POINT_X = "POINT_X"; //NO I18N
	public static final String POINT_Y = "POINT_Y"; //NO I18N
	public static final String CLICKS = "CLICKS"; //NO I18N
	public static final String DEVICE = "DEVICE"; //NO I18N
	public static final String CURRENTURL_CODE = "CURRENTURL_CODE"; //NO I18N
	public static final String DEVICE_CODE = "DEVICE_CODE"; //NO I18N
	public static final String USERTYPE_CODE = "USERTYPE_CODE"; //NO I18N
	public static final String DAYOFWEEK_CODE = "DAYOFWEEK_CODE"; //NO I18N
	public static final String HOUROFDAY_CODE = "HOUROFDAY_CODE"; //NO I18N
	public static final String VISIT_ID = "VISIT_ID"; //NO I18N
	public static final String UNIQUECOUNT_FLAG = "UNIQUECOUNT_FLAG"; //NO I18N
	public static final String TOTALCOUNT_FLAG = "TOTALCOUNT_FLAG"; //NO I18N
	public static final String TIME = "TIME"; //NO I18N
	public static final String TOTAL_COUNT = "TOTAL_COUNT"; //NO I18N
	public static final String DATE = "DATE"; //NO I18N
	public static final String HOUR = "HOUR"; //NO I18N
	
	public static final String UNIQUE_VISITOR_COUNT = "unique_visitor_count"; //No I18N
	public static final String TOTAL_VISITOR_COUNT = "total_visitor_count"; //No I18N
	
	public final static List<Constants> HEATMAP_EXPERIMENT_VISITS_CONSTANTS;
	static
	{
		List<Constants> heatmapexperimentvisitsConstants = new ArrayList<Constants>();
		heatmapexperimentvisitsConstants.add(new Constants(HEATMAP_EXPERIMENT_VISITS_ID,HEATMAP_EXPERIMENT_VISITS.HEATMAP_EXPERIMENT_VISITS_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		heatmapexperimentvisitsConstants.add(new Constants(EXPERIMENT_ID,HEATMAP_EXPERIMENT_VISITS.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		heatmapexperimentvisitsConstants.add(new Constants(UNIQUE_VISITOR_COUNT,HEATMAP_EXPERIMENT_VISITS.UNIQUE_VISITOR_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		heatmapexperimentvisitsConstants.add(new Constants(TOTAL_VISITOR_COUNT,HEATMAP_EXPERIMENT_VISITS.TOTAL_VISITOR_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		heatmapexperimentvisitsConstants.add(new Constants(TOTAL_CLICKS,HEATMAP_EXPERIMENT_VISITS.TOTAL_CLICKS,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		
		HEATMAP_EXPERIMENT_VISITS_CONSTANTS = Collections.unmodifiableList(heatmapexperimentvisitsConstants);
	}
	
	public final static List<Constants> EXPERIMENT_HEATMAP_TABLE;
	static
	{
		List<Constants> experimentheatmapconst = new ArrayList<Constants>();
		experimentheatmapconst.add(new Constants(EXPERIMENT_ID,EXPERIMENT_HEATMAP.EXPERIMENT_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		experimentheatmapconst.add(new Constants(HEATMAP_EXPERIMENT_ID,EXPERIMENT_HEATMAP.HEATMAP_EXPERIMENT_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		
		EXPERIMENT_HEATMAP_TABLE = Collections.unmodifiableList(experimentheatmapconst);
	}
	
}
