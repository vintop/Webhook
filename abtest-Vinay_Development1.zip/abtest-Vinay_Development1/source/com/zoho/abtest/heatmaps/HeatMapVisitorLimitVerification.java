//$Id$
package com.zoho.abtest.heatmaps;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.TermQueryBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.metrics.cardinality.CardinalityAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.cardinality.InternalCardinality;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.iam.ServiceOrg;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.ABSPLITEXPERIMENT;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.EXPERIMENT_HEATMAP;
import com.zoho.abtest.HEATMAP_EXPERIMENT;
import com.zoho.abtest.PORTAL_LICENSE_MAPPING;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.elastic.ElasticSearchStatistics;
import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.experiment.ExperimentHandler;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentStatus;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentType;
import com.zoho.abtest.license.PortalLicenseMapping;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUtil;

public class HeatMapVisitorLimitVerification 
{
	private static final Logger LOGGER = Logger.getLogger(HeatMapVisitorLimitVerification.class.getName());
	
	public static void verifyHeatMapVisitorLimitForABSplit()
	{
		LOGGER.log(Level.INFO, "verifyHeatMapVisitorLimitForABSplit process started ");
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		try
		{
			Criteria criteria1 = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.IS_APP_ACTIVE), Boolean.TRUE, QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(PORTAL_LICENSE_MAPPING.TABLE, criteria1);
			Iterator<?> iterator = dataObj.getRows(PORTAL_LICENSE_MAPPING.TABLE);
			while(iterator.hasNext())
			{
				Row row = (Row)iterator.next();
				PortalLicenseMapping portalLicenseMappingObj =  PortalLicenseMapping.getPortalLicenseMappingFromRow(row);
				Long zsoid = portalLicenseMappingObj.getZsoid();
				try
				{
					LOGGER.log(Level.INFO, "verifyHeatMapVisitorLimitForABSplit started for - {0}", new String[]{zsoid.toString()});
					verifyHeatMapVisitorLimitForABSplit(zsoid);
					LOGGER.log(Level.INFO, "verifyHeatMapVisitorLimitForABSplit completed for - {0}", new String[]{zsoid.toString()});
				}
				catch(Exception ex)
				{
					LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
					LOGGER.log(Level.SEVERE, "verifyHeatMapVisitorLimitForABSplit error for - {0}", new String[]{zsoid.toString()});
				}
			}
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "verifyHeatMapVisitorLimitForABSplit generic Error",ex);
		}
		LOGGER.log(Level.INFO, "verifyHeatMapVisitorLimitForABSplit process completed ");
	}
	
	public static void verifyHeatMapVisitorLimitForABSplit(Long zsoid) throws Exception
	{
		ZABUtil.setDBSpace(zsoid.toString());
		ServiceOrg sOrg = ZABServiceOrgUtil.getServiceOrg(zsoid);
		if(sOrg != null && sOrg.isEnabled())
		{
			String domainName = sOrg.getDomains().get(0).getDomain();
			ZABUtil.setPortaldomain(domainName);
			Criteria criteria1 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_TYPE), new Integer[]{ExperimentType.ABTEST.getTypeNumber(), ExperimentType.SPLITURL.getTypeNumber()}, QueryConstants.IN);
			Criteria criteria2 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_STATUS), ExperimentStatus.RUNNING.getStatusCode() , QueryConstants.EQUAL);
			Criteria criteria3 = new Criteria(new Column(ABSPLITEXPERIMENT.TABLE, ABSPLITEXPERIMENT.IS_HEATMAP_ENABLED), Boolean.TRUE , QueryConstants.EQUAL);
			Criteria criteria4 = new Criteria(new Column(HEATMAP_EXPERIMENT.TABLE, HEATMAP_EXPERIMENT.MAX_VISITOR_COUNT), new Integer(-1) , QueryConstants.NOT_EQUAL);

			Join join1 = new Join(EXPERIMENT.TABLE, ABSPLITEXPERIMENT.TABLE, new String[]{EXPERIMENT.EXPERIMENT_ID}, new String[]{ABSPLITEXPERIMENT.EXPERIMENT_ID}, Join.INNER_JOIN);
			Join join2 = new Join(EXPERIMENT.TABLE, EXPERIMENT_HEATMAP.TABLE, new String[]{EXPERIMENT.EXPERIMENT_ID}, new String[]{EXPERIMENT_HEATMAP.EXPERIMENT_ID}, Join.INNER_JOIN);
			Join join3 = new Join(EXPERIMENT_HEATMAP.TABLE, HEATMAP_EXPERIMENT.TABLE, new String[]{EXPERIMENT_HEATMAP.HEATMAP_EXPERIMENT_ID}, new String[]{HEATMAP_EXPERIMENT.EXPERIMENT_ID}, Join.INNER_JOIN);
			DataObject dataObj = ZABModel.getRow(EXPERIMENT.TABLE, criteria1.and(criteria2).and(criteria3).and(criteria4), new Join[]{join1,join2,join3});
			Iterator<?> iterator = dataObj.getRows(EXPERIMENT.TABLE);
			while(iterator.hasNext())
			{
				Row row = (Row)iterator.next();
				Long experimentId = (Long)row.get(EXPERIMENT.EXPERIMENT_ID);
				String expLinkName = (String)row.get(EXPERIMENT.EXPERIMENT_LINK_NAME);
				try
				{
					Criteria expCriteria = new Criteria(new Column(EXPERIMENT_HEATMAP.TABLE, EXPERIMENT_HEATMAP.EXPERIMENT_ID), experimentId , QueryConstants.EQUAL); 
					Row expHeatmapRow = dataObj.getRow(EXPERIMENT_HEATMAP.TABLE, expCriteria);
					Long heapmapExpId = (Long)expHeatmapRow.get(EXPERIMENT_HEATMAP.HEATMAP_EXPERIMENT_ID);
					Criteria heatmapExpCriteria = new Criteria(new Column(HEATMAP_EXPERIMENT.TABLE, HEATMAP_EXPERIMENT.EXPERIMENT_ID), heapmapExpId , QueryConstants.EQUAL);
					Row heatmapExpRow = dataObj.getRow(HEATMAP_EXPERIMENT.TABLE, heatmapExpCriteria);
					Integer maxVisitorCount = (Integer)heatmapExpRow.get(HEATMAP_EXPERIMENT.MAX_VISITOR_COUNT);
					
					String indexName = ElasticSearchUtil.getIndexByPortal(domainName);
					Long hmTrackedVisitorCount = getHeatMapVisitorTrackedCount(indexName, domainName, experimentId);
					LOGGER.log(Level.INFO, "verifyHeatMapVisitorLimitForABSplit HM experiment visitor tracked count - {0} - {1} - {2}", new String[]{zsoid.toString(),experimentId.toString(),hmTrackedVisitorCount.toString()});
					if(hmTrackedVisitorCount >=  maxVisitorCount)
					{
						HashMap<String, String> experimentHs = new HashMap<String, String>();
						experimentHs.put(ExperimentConstants.EXPERIMENT_LINKNAME, expLinkName);
						experimentHs.put(ExperimentConstants.IS_HEATMAP_ENABLED, Boolean.FALSE.toString());
						experimentHs.put(ExperimentConstants.IS_EXP_STATUS_CHANGED, Boolean.TRUE.toString());
						ExperimentHandler.handleExperimentUpdation(experimentHs);
						LOGGER.log(Level.INFO, "verifyHeatMapVisitorLimitForABSplit HM experiment paused for - {0} - {1} - {2}", new String[]{zsoid.toString(),experimentId.toString(),hmTrackedVisitorCount.toString()});
					}
				}
				catch(Exception ex)
				{
					LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
					LOGGER.log(Level.SEVERE, "verifyHeatMapVisitorLimitForABSplit error experiment for - {0}", new String[]{experimentId.toString()});
				}
			}
		}
	}
	
	public static Long getHeatMapVisitorTrackedCount(String indexName, String domainName, Long expId)
	{
		Long visitorCount = 0l;
		try
		{
			BoolQueryBuilder query = QueryBuilders.boolQuery();
			TermQueryBuilder portalQuery = QueryBuilders.termQuery(ElasticSearchConstants.PORTAL, domainName);
			TermQueryBuilder expQuery = QueryBuilders.termQuery(ElasticSearchConstants.EXPERIMENTID, expId);
			TermQueryBuilder heatmapFlagQuery = QueryBuilders.termQuery(ElasticSearchConstants.IS_HEATMAP_ENABLED, "true");
			query.filter().add(portalQuery);
			query.filter().add(expQuery);
			query.filter().add(heatmapFlagQuery);
			
			ArrayList<AggregationBuilder> cabs = new ArrayList<AggregationBuilder>();

			CardinalityAggregationBuilder cardAggr = ElasticSearchStatistics.getVisitorCardinalityAggr();
			CardinalityAggregationBuilder uuidAggrJson = ElasticSearchStatistics.getUUIDVisitorCardinalityAggr();
			
			cabs.add(cardAggr);
			cabs.add(uuidAggrJson);

			
			SearchResponse visitorResponse = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.VISITOR_RAW_TYPE, 0, query, cabs);
			
			Aggregations visitorAggrResponse = visitorResponse.getAggregations();
			InternalCardinality cardinality = visitorAggrResponse.get("distinct_visitors");
			visitorCount = cardinality.getValue();
			InternalCardinality uuidCardinality = visitorAggrResponse.get("distinct_uuid_visitors");
			visitorCount = visitorCount + uuidCardinality.getValue();

		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			LOGGER.log(Level.SEVERE, "getHeatMapVisitorTrackedCount error experiment for - {0}", new String[]{expId.toString()});
		}
		return visitorCount;
	}
}
