//$Id$
package com.zoho.abtest.heatmaps;

import java.util.ArrayList;
import java.util.HashMap;

import com.zoho.abtest.common.ZABModel;

public class Scrollmap extends ZABModel{
	
	private Long experimentId;
	private String experimentLinkname;
	private String variationLinkname;
	private Long startDate ;
	private Long endDate ;
	private Long visitorCount ;
	private Long visitsCount ;
	private double averageFold ;
	
	private ArrayList<HashMap<String,Object>> deviceVisits = new ArrayList<HashMap<String,Object>>();
	private HashMap<String,Long> scrollmapPoints;
	private HashMap<String,HashMap<String,Long>> attentionData;
	
	public Long getExperimentId() {
		return experimentId;
	}
	public void setExperimentId(Long experimentId) {
		this.experimentId = experimentId;
	}
	public Long getStartDate() {
		return startDate;
	}
	public void setStartDate(Long startDate) {
		this.startDate = startDate;
	}
	public Long getEndDate() {
		return endDate;
	}
	public void setEndDate(Long endDate) {
		this.endDate = endDate;
	}
	public HashMap<String,Long> getScrollmapPoints() {
		return scrollmapPoints;
	}
	public void setScrollmapPoints(HashMap<String,Long> scrollmapPoints) {
		this.scrollmapPoints = scrollmapPoints;
	}
	public Long getVisitorCount() {
		return visitorCount;
	}
	public void setVisitorCount(Long visitorCount) {
		this.visitorCount = visitorCount;
	}
	public Long getVisitsCount() {
		return visitsCount;
	}
	public void setVisitsCount(Long visitsCount) {
		this.visitsCount = visitsCount;
	}
	public String getExperimentLinkname() {
		return experimentLinkname;
	}
	public void setExperimentLinkname(String experimentLinkname) {
		this.experimentLinkname = experimentLinkname;
	}
	public String getVariationLinkname() {
		return variationLinkname;
	}
	public void setVariationLinkname(String variationLinkname) {
		this.variationLinkname = variationLinkname;
	}
	public double getAverageFold() {
		return averageFold;
	}
	public void setAverageFold(double averageFold) {
		this.averageFold = averageFold;
	}
	public ArrayList<HashMap<String,Object>> getDeviceVisits() {
		return deviceVisits;
	}
	public void setDeviceVisits(ArrayList<HashMap<String,Object>> deviceVisits) {
		this.deviceVisits = deviceVisits;
	}
	public HashMap<String,HashMap<String,Long>> getAttentionData() {
		return attentionData;
	}
	public void setAttentionData(HashMap<String,HashMap<String,Long>> attentionData) {
		this.attentionData = attentionData;
	}
}
