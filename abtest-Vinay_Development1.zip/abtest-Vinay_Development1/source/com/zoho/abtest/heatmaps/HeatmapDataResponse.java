//$Id$
package com.zoho.abtest.heatmaps;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;

public class HeatmapDataResponse {
	
	private static final Logger LOGGER = Logger.getLogger(HeatmapDataResponse.class.getName());
	
	public static String jsonResponse(HttpServletRequest request,ArrayList<Heatmap> lst) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(lst);			
			JSONObject json = ZABResponse.updateMetaInfo(request, HeatmapConstants.API_MODULE, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		return returnBuffer.toString();
	}

	public static JSONArray getJSONArray(ArrayList<Heatmap> lst) throws JSONException {
		
		JSONArray array = new JSONArray();
		int size =lst.size();
		for (int i=0;i<size;i++) {
			Heatmap ld=lst.get(i);
			JSONObject jsonObj = new JSONObject();

			if(ld.getUrldetails() != null){
				jsonObj.put(HeatmapConstants.URL_DETAILS.toLowerCase(),getHeatmapExperimentUrls1(ld.getUrldetails()));
			}else{
				
				jsonObj.put(HeatmapConstants.VARIATION_LINKNAME.toLowerCase(), ld.getVariationLinkname());
				jsonObj.put(HeatmapConstants.START_DATE.toLowerCase(), ld.getStartDate());
				jsonObj.put(HeatmapConstants.END_DATE.toLowerCase(), ld.getEndDate());
				jsonObj.put(HeatmapConstants.VISITORS_COUNT.toLowerCase(), ld.getVisitorsCount());
				jsonObj.put(HeatmapConstants.VISITS_COUNT.toLowerCase(), ld.getVisitsCount());
				jsonObj.put(HeatmapConstants.TOTAL_CLICKS.toLowerCase(), ld.getTotalClicks());
				jsonObj.put(HeatmapConstants.ENGAGED_VISITORS.toLowerCase(), ld.getEngagedVisitorCount());
				jsonObj.put(HeatmapConstants.ENGAGED_VISITORS_PERCENTAGE.toLowerCase(), ld.getEngagedVisitorPercentage());
				jsonObj.put(HeatmapConstants.CLICKS_PER_VISIT.toLowerCase(), Math.round(ld.getClicksPerVisit()*100.0)/100.0);
				jsonObj.put(HeatmapConstants.ACTIVE_DAYS.toLowerCase(), ld.getActiveDays());
				jsonObj.put(HeatmapConstants.TOP_CLICKS.toLowerCase(),getTopClicks(ld.getTopclicks()));
				jsonObj.put(HeatmapConstants.ALL_DEVICE_VISITS.toLowerCase(),getAllDeviceVisits(ld.getDeviceVisits()));    
				//jsonObj.put(HeatmapConstants.HEATMAP_POINTS.toLowerCase(),getHeatmapPointsObject(ld.getHmpoints()));
				jsonObj.put(HeatmapConstants.HEATMAP_POINTS.toLowerCase(),getHeatmapPointsObject1(ld.getHeatmapPoints()));

			}
			
			jsonObj.put(HeatmapConstants.EXPERIMENT_ID.toLowerCase(), ld.getExperimentId());
			jsonObj.put(HeatmapConstants.EXPERIMENT_LINKNAME.toLowerCase(), ld.getExperimentLinkname());
			jsonObj.put(ZABConstants.SUCCESS, ld.getSuccess());
			
			array.put(jsonObj);
		}
		return array;
	}

	public static JSONArray getHeatmapExperimentUrls1(HashMap<String,HashMap<String,Object>> hmurldetails){
		
		JSONArray arr = new JSONArray();
		try {
			
			if(hmurldetails == null){
				return null;
			}
			
			
			for(Entry<String, HashMap<String, Object>> mapp : hmurldetails.entrySet()){
				JSONObject object = new JSONObject();
				HashMap<String,Object> hmurld = mapp.getValue();
				for(Entry<String, Object> map : hmurld.entrySet()){
					object.put(map.getKey(), map.getValue());
				}
				object.put("url",mapp.getKey());
				arr.put(object);
			}
			
			return arr;
				
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return arr;
		
	}
	
	public static JSONObject getHeatmapExperimentUrls(HashMap<String,HashMap<String,Object>> hmurldetails){
		
		JSONObject obj = new JSONObject();
		try {
			
			if(hmurldetails == null){
				return null;
			}
			
			for(Entry<String, HashMap<String, Object>> mapp : hmurldetails.entrySet()){
				JSONObject object = new JSONObject();
				HashMap<String,Object> hmurld = mapp.getValue();
				for(Entry<String, Object> map : hmurld.entrySet()){
					object.put(map.getKey(), map.getValue());
				}
				obj.put(mapp.getKey(),object);
			}
			
			return obj;
				
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return obj;
		
	}
	public static JSONObject getHeatmapPointsObject(HashMap<String,String> hmpoints) throws JSONException {
		
		if(hmpoints == null){
			return null;
		}
		JSONObject object = new JSONObject();
		
		for(Entry<String, String> map : hmpoints.entrySet()){
			
			object.put(map.getKey(), map.getValue());
		}
		
		return object;
	}
	
	public static JSONArray getTopClicks(ArrayList<HashMap<String,Object>> topclicks) throws JSONException {
		
		if(topclicks == null){
			return null;
		}
		JSONArray array = new JSONArray();
		
		for(int i=0; i< topclicks.size(); i++){
			
			JSONObject object = new JSONObject();
			HashMap<String,Object> topclick = topclicks.get(i);
			for(Entry<String, Object> map : topclick.entrySet()){
				object.put(map.getKey(), map.getValue());
			}
			array.put(object);
		}
		
		return array;
	}
	
	public static JSONArray getAllDeviceVisits(ArrayList<HashMap<String,Object>> deviceVisits) throws JSONException {
		
		if(deviceVisits == null){
			return null;
		}
		JSONArray array = new JSONArray();
		
		for(int i=0; i< deviceVisits.size(); i++){
			
			JSONObject object = new JSONObject();
			HashMap<String,Object> topclick = deviceVisits.get(i);
			for(Entry<String, Object> map : topclick.entrySet()){
				object.put(map.getKey(), map.getValue());
			}
			array.put(object);
		}
		
		return array;
	}
	
	public static JSONObject getHeatmapPointsObject1(HashMap<String,ArrayList<ArrayList<Double>>> hmpoints) throws JSONException {
		
		if(hmpoints == null){
			return null;
		}
		JSONObject object = new JSONObject();
		
		for(Entry<String, ArrayList<ArrayList<Double>>> map : hmpoints.entrySet()){
			
			object.put(map.getKey(), map.getValue());
		}
		
		return object;
	}
}
