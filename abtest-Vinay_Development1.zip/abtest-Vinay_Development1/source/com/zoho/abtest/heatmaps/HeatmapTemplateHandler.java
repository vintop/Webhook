//$Id$
package com.zoho.abtest.heatmaps;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import com.adventnet.db.persistence.metadata.MetaDataException;
import com.adventnet.db.persistence.metadata.TableDefinition;
import com.adventnet.db.persistence.metadata.util.TemplateMetaHandler;
import com.adventnet.ds.query.AlterTableQuery;
import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.report.ReportRawDataConstants;

public class HeatmapTemplateHandler implements TemplateMetaHandler {

	private static final Logger LOGGER = Logger.getLogger(HeatmapTemplateHandler.class.getName());
	private String hmtemplateName = ReportRawDataConstants.HEATMAP_DATA_RAW;
	private String smtemplateName = ReportRawDataConstants.SCROLLMAP_DATA_RAW;
	public static List<String> templateInstanceName = new ArrayList<String>();
	
	@Override
	public void addTemplate(String arg0, TableDefinition arg1)
			throws MetaDataException {
		// TODO Auto-generated method stub
	}

	@Override
	public void addTemplateInstance(String templateName, String instanceId) throws MetaDataException {
		templateInstanceName.add(templateName+"_"+instanceId);
	}

	@Override
	public void alterTemplate(AlterTableQuery arg0) throws MetaDataException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getTemplateName(String tableName) {
		if(tableName.contains("HEATMAP_DATA_RAW")){
			return hmtemplateName;
		}
		if(tableName.contains("SCROLLMAP_DATA_RAW")){
			return smtemplateName;
		}
		return null;
	}

	@Override
	public List<String> getTemplateTableInstances(String arg0)
			throws MetaDataException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isTemplate(String arg0) {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public void removeTemplate(String arg0) throws MetaDataException {
		// TODO Auto-generated method stub
		hmtemplateName = null;
		smtemplateName = null;
	}

	@Override
	public boolean removeTemplateInstance(String templateName, String instanceId) throws MetaDataException {
        templateInstanceName.remove(templateName + "_" + instanceId);
		return true;
	}

}
