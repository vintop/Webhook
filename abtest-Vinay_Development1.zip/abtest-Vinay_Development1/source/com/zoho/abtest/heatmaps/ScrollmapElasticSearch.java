//$Id$
package com.zoho.abtest.heatmaps;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.avg.Avg;
import org.elasticsearch.search.aggregations.metrics.avg.AvgAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.cardinality.InternalCardinality;
import org.elasticsearch.search.aggregations.metrics.max.Max;
import org.elasticsearch.search.aggregations.metrics.max.MaxAggregationBuilder;
import org.json.JSONArray;

import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.report.ReportConstants;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.abtest.variation.Variation;

public class ScrollmapElasticSearch {
	
	private static final Logger LOGGER = Logger.getLogger(HeatmapElasticSearch.class.getName());
	
	public static ArrayList<Scrollmap> getScrollmapInformation(HashMap<String,String> hs) throws Exception
	{
		ArrayList<Scrollmap> reports = new ArrayList<Scrollmap>();
		try{
		
			String experimentLinkName = hs.get("EXPERIMENT_LINKNAME");
			Experiment exp  = Experiment.getExperimentByLinkname(experimentLinkName);
	
			if(exp == null){
				Scrollmap report = new Scrollmap();
				report.setSuccess(Boolean.FALSE);
				reports.add(report);
				return reports;
				//report.setResponseString();
			}
			
			Long experimentId = exp.getExperimentId();
			String variationLinkname = hs.get(HeatmapConstants.VARIATION_LINKNAME);
			Long variationId = null;
			Boolean invalidVariation = false;
			Boolean isabtestexp = false;
			
			if(Variation.getExperimentVariationCount(experimentId) > 0){
				ArrayList<Variation> variation = Variation.getVariationByLinkname(variationLinkname);
				if(variation == null){
					invalidVariation = true;
				}else{
					variationId = variation.get(0).getVariationId();
					isabtestexp = true;
				}
			}else{
				if(!variationLinkname.equals("original")){
					invalidVariation = true;
				}
			}
			
			if(invalidVariation){
				
				Scrollmap report = new Scrollmap();
				report.setSuccess(Boolean.FALSE);
				reports.add(report);
				return reports;
			}
			
			String startTime = null;
			String endTime = null;
			
			if(hs.containsKey(HeatmapConstants.START_DATE.toLowerCase())){
				startTime = hs.get(HeatmapConstants.START_DATE.toLowerCase());
			}else{
				startTime = exp.getActualStartTime().toString();
			}
			
			if(hs.containsKey(HeatmapConstants.END_DATE.toLowerCase())){
				endTime  = hs.get(HeatmapConstants.END_DATE.toLowerCase());
			}
			
			Long startTimeInMillis = null;
			if(startTime!=null&&!startTime.isEmpty()){
				 startTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(startTime, "yyyy-MM-dd");		// NO I18N
			}
			
			Long endTimeInMillis = null;
			if(endTime!=null&&!endTime.isEmpty()){
				endTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(endTime, "yyyy-MM-dd");		// NO I18N
				endTimeInMillis = ZABUtil.getNthDayDateInLong(endTimeInMillis, 1);
			}else{
				endTimeInMillis = ZABUtil.getCurrentTimeInMilliSeconds();
			}
			
			//long timedifference = ZABUtil.getDaysDifferenceBetweenDates(startTime,endTime);
			
			String segmentType= hs.get(ReportConstants.SEGMENT_TYPE);
			String reportType = hs.get(ReportConstants.REPORT_TYPE);
			String dynamicAttrLinkName = hs.get(ReportConstants.DYNAMIC_ATTRIBUTE_LINK_NAME);
			String multisegmentCriteria = hs.get(ReportConstants.MULTISEGMENT_CRITERIA);
			String heatmapReqCriteria = hs.get(ReportConstants.HEATMAP_REQUIRED_CRITERIA);
			
			String[] valueArray = null;
			
			String values = hs.get(ReportConstants.VALUES);
			if(values != null)
			{
				JSONArray array  = new JSONArray(values);
				valueArray = new String[array.length()];
				
				for(int i=0;i<array.length();i++){
					valueArray[i] = array.getString(i).toUpperCase();
				}
			}
			
			reports = getElasticScrollmapData(experimentId, variationId, experimentLinkName, variationLinkname, startTimeInMillis, endTimeInMillis, reportType, segmentType, valueArray, dynamicAttrLinkName, multisegmentCriteria, heatmapReqCriteria, isabtestexp);
					
		}catch(Exception ex ){
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		return reports;
	}
	
	public static ArrayList<Scrollmap> getElasticScrollmapData(Long expId, Long varId, String experimentLinkname, String variationLinkname, Long starttime, Long endtime, String reportType, String segmentType, String[] segmentValueCodes, String dynamicAttrLinkName, String multisegmentCriteria,String heatmapReqCriteria, Boolean isheatmapenabled)
	{
		ArrayList<Scrollmap> heatmapdeatils = new ArrayList<Scrollmap>();
		Scrollmap scrollmap = null;
		BoolQueryBuilder filterJson =  null;
		BoolQueryBuilder filterJson1 =  null;
		List<AggregationBuilder> aggrsJson = null;
		List<AggregationBuilder> aggrsJson1 = null;
		TermsAggregationBuilder aggrsJson2 = null;
		
		try
		{
	
			String portal = ZABUtil.getPortaldomain();//IAMUtil.getCurrentServiceOrg().getDomains().get(0).getDomain();
			String index = ElasticSearchUtil.getIndexByPortal(portal);
			String msc1 = null;
			int size = 0;
			
			if(heatmapReqCriteria!=null){
				msc1 = HeatmapElasticSearch.getCriteriasWithoutDevice(heatmapReqCriteria).toString();
			}			
			filterJson = HeatmapElasticSearch.generateSourceQueryJson(portal,reportType,segmentType, expId, varId,starttime,endtime,dynamicAttrLinkName,segmentValueCodes,multisegmentCriteria, heatmapReqCriteria,null);
			filterJson1 = HeatmapElasticSearch.generateSourceQueryJson(portal,reportType,segmentType, expId, varId,starttime,endtime,dynamicAttrLinkName,null, multisegmentCriteria, msc1,isheatmapenabled);
			
			aggrsJson  = generateScrollmapAggregateJson();
			aggrsJson1 = HeatmapElasticSearch.generateAllVistorsAggregateJson();
			aggrsJson2 = HeatmapElasticSearch.generateAllDevicesVisitsAggredateJson();
			
			SearchResponse response = ElasticSearchUtil.getData(index, ElasticSearchConstants.SCROLLMAP_RAW_TYPE, size, filterJson, aggrsJson);
			SearchResponse response1 = ElasticSearchUtil.getData(index, ElasticSearchConstants.SCROLLMAP_RAW_TYPE, size, filterJson, aggrsJson1);
			SearchResponse response2 = ElasticSearchUtil.getData(index, ElasticSearchConstants.VISITOR_RAW_TYPE, size, filterJson1, aggrsJson2);
			
			
			scrollmap = readScrollmapResponseData(response,response1,response2);
			scrollmap.setExperimentId(expId);
			scrollmap.setExperimentLinkname(experimentLinkname);
			scrollmap.setVariationLinkname(variationLinkname);
			
			scrollmap.setSuccess(Boolean.TRUE);
			
		}catch(Exception ex)
		{
			scrollmap = new Scrollmap();
			scrollmap.setSuccess(Boolean.FALSE);
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		
		heatmapdeatils.add(scrollmap);
		return heatmapdeatils;
	}
	
	public static List<AggregationBuilder> generateScrollmapAggregateJson()
	{
		List<AggregationBuilder> agglist = new ArrayList<AggregationBuilder>();
		try
		{
			TermsAggregationBuilder visitsAgg = AggregationBuilders.terms("group_by_"+ElasticSearchConstants.UVID).field(ElasticSearchConstants.UVID).size(ElasticSearchConstants.VISITOR_MAX_COUNT).order(Terms.Order.aggregation("max_"+ElasticSearchConstants.SCROLL_Y2,false));  //NO I18N
			MaxAggregationBuilder maxAgg = AggregationBuilders.max("max_"+ElasticSearchConstants.SCROLL_Y2).field(ElasticSearchConstants.SCROLL_Y2); //NO I18N
			AvgAggregationBuilder averagefold = AggregationBuilders.avg("average_"+ElasticSearchConstants.HEIGHT).field(ElasticSearchConstants.HEIGHT);  //NO I18N
			
			visitsAgg.subAggregation(maxAgg);
			agglist.add(visitsAgg);
			agglist.add(averagefold);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		return agglist;
	}
	
	public static Scrollmap readScrollmapResponseData(SearchResponse response,SearchResponse response1,SearchResponse response2)
	{
		Scrollmap scrollmap = new Scrollmap();
		LinkedHashMap<String,Long> scrolldata = new LinkedHashMap<String,Long>();
		ArrayList<HashMap<String,Object>> deviceVisits = new ArrayList<HashMap<String,Object>>();
		
		try
		{
			Aggregations aggrResponse = response.getAggregations();
			Aggregations aggrResponse1 = response1.getAggregations();
			
			InternalCardinality cardinality1 = aggrResponse1.get("distinct_visitors");
			long visitors = cardinality1.getValue();
			long uuidVisitors = HeatmapElasticSearch.getUUIDVisitorsCount(aggrResponse1);
			long totalVisitors = visitors + uuidVisitors;
			scrollmap.setVisitorCount(totalVisitors);
			InternalCardinality cardinality2 = aggrResponse1.get("total_visits");
			Long totalvisits = cardinality2.getValue();
			scrollmap.setVisitsCount(totalvisits);
			
			Avg average = aggrResponse.get("average_"+ElasticSearchConstants.HEIGHT);
			double avg_value = average.getValue();
			scrollmap.setAverageFold((int)Math.round(avg_value));
			
			deviceVisits = HeatmapElasticSearch.getAllDeviceVisits(response2);
			scrollmap.setDeviceVisits(deviceVisits);
			
			//Terms terms = aggrResponse.get("group_by_"+ElasticSearchConstants.SCROLL_LIST);
			Terms terms = aggrResponse.get("group_by_"+ElasticSearchConstants.UVID);
			List<? extends Bucket> buckets = terms.getBuckets();
			String preString = "";
			for(Bucket bucketSelector:buckets)
			{
				Max maxScroll = bucketSelector.getAggregations().get("max_"+ElasticSearchConstants.SCROLL_Y2); //NO I18N
				int max = new Double(maxScroll.getValue()).intValue();
				
				if(max < 50){
					max = 50;
				}
				
				String stringkey = (max-50)+"-"+(max);
				
				if(!stringkey.equals(preString) && scrolldata.containsKey(preString)){
					scrolldata.put(stringkey,scrolldata.get(preString));
				}
				
				if(scrolldata.containsKey(stringkey)){
					Long prevcount  = scrolldata.get(stringkey);
					prevcount += 1;
					if(prevcount > totalvisits){
						prevcount = totalvisits;
					}
					scrolldata.put(stringkey,prevcount);
				}else{
					scrolldata.put(stringkey,1l);
				}	
				
				preString = stringkey;
			}
			scrollmap.setScrollmapPoints(scrolldata);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			scrollmap = null;
		}
		return scrollmap;
	}

}
