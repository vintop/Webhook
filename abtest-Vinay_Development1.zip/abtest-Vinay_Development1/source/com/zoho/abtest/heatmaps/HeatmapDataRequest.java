//$Id$
package com.zoho.abtest.heatmaps;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;

import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABRequest;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.report.ReportConstants;
import com.zoho.abtest.utility.ZABUtil;

public class HeatmapDataRequest extends ZABRequest{

	@Override
	public void updateFromRequest(HashMap<String, String> map,
			HttpServletRequest request) {
		// TODO Auto-generated method stub
		String experimentLinkName  = (String)request.getAttribute(HeatmapConstants.EXPERIMENT_LINKNAME);
		String variationLinkName  = (String)request.getAttribute(HeatmapConstants.VARIATION_LINKNAME);


		if(experimentLinkName!=null) 
		{
			map.put(HeatmapConstants.EXPERIMENT_LINKNAME,experimentLinkName);
		}
		
		if(variationLinkName!=null) 
		{
			map.put(HeatmapConstants.VARIATION_LINKNAME,variationLinkName);
		}
	}

	@Override
	public void specificValidation(HashMap<String, String> map,HttpServletRequest request) throws IOException, JSONException {
		
		// TODO Auto-generated method stub
		String httpMethod = ZABAction.getHTTPMethod(request).toString();
		
		if(httpMethod.equalsIgnoreCase("POST")){
			ArrayList<String> fields = new ArrayList<String>();
			
			if(!map.containsKey(HeatmapConstants.EXPERIMENT_LINKNAME)) {
				fields.add(HeatmapConstants.EXPERIMENT_LINKNAME);
			}
			if(!map.containsKey(HeatmapConstants.VARIATION_LINKNAME)) {
				fields.add(HeatmapConstants.VARIATION_LINKNAME);
			}
			if (!map.containsKey(ReportConstants.START_DATE)) {
				fields.add(ReportConstants.START_DATE);
			}
			if (!map.containsKey(ReportConstants.END_DATE)) {
				fields.add(ReportConstants.END_DATE);
			}/*else{
				String endTime  = map.get(ReportConstants.END_DATE);
				try{
					if(endTime!=null&&!endTime.isEmpty()){
						Long endTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(endTime, "yyyy-MM-dd");		// NO I18N
						Long currentTime = ZABUtil.getCurrentTimeInMilliSeconds();
						if(currentTime <endTimeInMillis) {	// END DATE IS A DATE GREATER THAN TODAY 
							fields.add(ReportConstants.END_DATE);
						}
					}
					
				}catch(Exception e){
					fields.add(ReportConstants.END_DATE);
				}
				
			}*/
			
			if(!map.containsKey(ReportConstants.REPORT_TYPE)){
				fields.add(ReportConstants.REPORT_TYPE);
			}
			else{
				String reportType = map.get(ReportConstants.REPORT_TYPE);
				if(reportType.equals(ReportConstants.SEGMENT)){
					if (!map.containsKey(ReportConstants.SEGMENT_TYPE)) {
						fields.add(ReportConstants.SEGMENT_TYPE);
					}
					if (!map.containsKey(ReportConstants.VALUES)) {
						fields.add(ReportConstants.VALUES);
					}
				}
				else if(reportType.equals(ReportConstants.MULTISEGMENT)){
					if (!map.containsKey(ReportConstants.MULTISEGMENT_CRITERIA)) {
						fields.add(ReportConstants.MULTISEGMENT_CRITERIA);
					}
				}
				
			}
			
		    if(fields.size() > 0)
		    {
		    	ZABRequest.updateError(map, ZABAction.getAppropriateMessage(ZABConstants.ErrorMessages.MANDATORY_FIELD_MISSING.getErrorString(),fields));
		    }
		}
	}
}
