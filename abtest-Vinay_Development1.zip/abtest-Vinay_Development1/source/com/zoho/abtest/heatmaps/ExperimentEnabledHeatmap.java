//$Id$
package com.zoho.abtest.heatmaps;

import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;


import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.amazonaws.services.applicationdiscovery.model.ResourceNotFoundException;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.EXPERIMENT_HEATMAP;
import com.zoho.abtest.HEATMAP_EXPERIMENT;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;

public class ExperimentEnabledHeatmap extends Experiment{

	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = Logger.getLogger(Experiment.class.getName());

	private Long experimentId;
	private Long experimentHeatmapId;
	
	public Long getExperimentId() {
		return experimentId;
	}
	public void setExperimentId(Long experimentId) {
		this.experimentId = experimentId;
	}
	public Long getExperimentHeatmapId() {
		return experimentHeatmapId;
	}
	public void setExperimentHeatmapId(Long experimentHeatmapId) {
		this.experimentHeatmapId = experimentHeatmapId;
	}
	
	public static HeatmapExperiment createEnabledHeatmapExperiment(HashMap<String, String> hs) {
		
		HeatmapExperiment hmExp = null;
		
		try {
				Experiment experiment = createExperiment(hs);
				Long experimentId = experiment.getExperimentId();
				
				if(experiment.getSuccess().equals(Boolean.TRUE) && experimentId  != null) {
					
					hs.put(ExperimentConstants.EXPERIMENT_ID, experimentId.toString());
					hs.put(ExperimentConstants.EXPERIMENT_URL,"");
					addDefaultValueIfNotAvailable(hs,HeatmapExperimentConstants.MAX_VISITORS, HeatmapConstants.DEFAULT_MAX_VISITOR_COUNT);
					
					DataObject dobj = createRow(HeatmapExperimentConstants.HEATMAP_EXPERIMENT_TABLE, HEATMAP_EXPERIMENT.TABLE, hs);		
					Row hmRow = dobj.getFirstRow(HEATMAP_EXPERIMENT.TABLE);					
					hmExp = new HeatmapExperiment(experiment);
					HeatmapExperiment.getHeatmapExperimentFromRow(hmRow, hmExp);
					
					if(hmExp.getExperimentId() != null){
						
						HashMap<String, String> enabledHM = new HashMap<String,String>();
						enabledHM.put(HeatmapConstants.EXPERIMENT_ID,hs.get(HeatmapConstants.HEATMAP_ENABLED_EXPERIMENT_ID.toLowerCase()));
						enabledHM.put(HeatmapConstants.HEATMAP_EXPERIMENT_ID,experimentId.toString());
						dobj = createRow(HeatmapConstants.EXPERIMENT_HEATMAP_TABLE, EXPERIMENT_HEATMAP.TABLE, enabledHM);		
						//Row hmEnabledRow = dobj.getFirstRow(EXPERIMENT_HEATMAP.TABLE);
					}
				}
				else
				{
					LOGGER.log(Level.SEVERE,"Exception Occurred while creating experiment. Hence rolledback changes.");
					hmExp = new HeatmapExperiment();
					hmExp.setSuccess(Boolean.FALSE);
					hmExp.setResponseString(experiment!=null? experiment.getResponseString():ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
				}	
			
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,"Exception Occurred while creating Heatmap Expriment",e);
			hmExp = new HeatmapExperiment();
			hmExp.setSuccess(Boolean.FALSE);
			hmExp.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
		}
		
		return hmExp;
	}

	public static HeatmapExperiment updateHeatmapEnabledExperiment(HashMap<String, String> hs) {
		
		HeatmapExperiment heatmapExperiment = null;
		Long experimentId = null;
		
		try {
			
			String linkName = hs.get(ExperimentConstants.EXPERIMENT_LINKNAME);
			
			//Logging event activity purpose
			HeatmapExperiment oldHeatmapExp = HeatmapExperiment.getHeatmapExperiment(linkName);
			//HashMap<String,String> oldValues = HeatmapExperiment.generateHashMapFromHeatmapExperimentObj(oldHeatmapExp,hs);
			
			experimentId = oldHeatmapExp.getExperimentId();
			
			/*Experiment Validations START*/
			
			/*Experiment Validations END*/
			
			Experiment experiment = Experiment.updateExperiment(hs);
			if(!experiment.getSuccess())
			{
				heatmapExperiment = new HeatmapExperiment();
				heatmapExperiment.setSuccess(Boolean.FALSE);
				heatmapExperiment.setResponseString(experiment.getResponseString());
				return heatmapExperiment;
			}
			
			Criteria c = new Criteria(new Column(HEATMAP_EXPERIMENT.TABLE, HeatmapExperimentConstants.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
			updateRow(HeatmapExperimentConstants.HEATMAP_EXPERIMENT_TABLE, HEATMAP_EXPERIMENT.TABLE, hs, c, ExperimentConstants.API_RESOURCE);
			
			heatmapExperiment = new HeatmapExperiment(experiment);
			Row latestHeatmapRow = HeatmapExperiment.getHeatmapExperimentRow(experimentId);
			HeatmapExperiment.getHeatmapExperimentFromRow(latestHeatmapRow, heatmapExperiment);
			
		} catch (ResourceNotFoundException | ZABException e) {
			
			heatmapExperiment = new HeatmapExperiment();
			heatmapExperiment.setSuccess(Boolean.FALSE);
			heatmapExperiment.setResponseString(e.getMessage());
			if(e instanceof ResourceNotFoundException) {
				heatmapExperiment.setResponseCode(((ResourceNotFoundException) e).getErrorCode());
			}
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		} catch (Exception e) {
			heatmapExperiment = new HeatmapExperiment();
			heatmapExperiment.setSuccess(Boolean.FALSE);
			heatmapExperiment.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		return heatmapExperiment;
	}

	public static ExperimentEnabledHeatmap getExperimentHeatmapByExperimentId(Long experimentId){
		
		ExperimentEnabledHeatmap exp = null;
		try
		{
			Criteria c = new Criteria(new Column(EXPERIMENT_HEATMAP.TABLE, EXPERIMENT.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(EXPERIMENT_HEATMAP.TABLE, c);
			if(dataObj.containsTable(EXPERIMENT_HEATMAP.TABLE)){
				
				exp = new ExperimentEnabledHeatmap();
				Row expHMRow = dataObj.getFirstRow(EXPERIMENT_HEATMAP.TABLE);
				exp.setExperimentId((Long)expHMRow.get(HeatmapConstants.EXPERIMENT_ID));
				exp.setExperimentHeatmapId((Long)expHMRow.get(HeatmapConstants.HEATMAP_EXPERIMENT_ID));
				exp.setSuccess(Boolean.TRUE);
			}
		}
		catch(Exception ex)
		{
			exp = new ExperimentEnabledHeatmap();
			exp.setSuccess(Boolean.FALSE);
		}
		return exp;
	}
	
	public static ExperimentEnabledHeatmap getExperimentHeatmapFromRow(Row heatmapRow) {
		
		ExperimentEnabledHeatmap experiment = new ExperimentEnabledHeatmap();
		experiment.setExperimentId((Long)heatmapRow.get(EXPERIMENT_HEATMAP.EXPERIMENT_ID));
		experiment.setExperimentHeatmapId((Long)heatmapRow.get(EXPERIMENT_HEATMAP.HEATMAP_EXPERIMENT_ID));
		
		experiment.setSuccess(Boolean.TRUE);
		return experiment;
	}
	
	public static HashMap<String, String> generateHeatmapHSFromExperiment(HashMap<String, String> hs, Long experimentId) {
		
		HashMap<String, String> heatmap = null;
		ExperimentEnabledHeatmap exp = getExperimentHeatmapByExperimentId(experimentId);
		if(exp!=null){
			
			heatmap = new HashMap<String, String>();
			Experiment expp = Experiment.getExperimentById(exp.getExperimentHeatmapId());
			heatmap.put(ExperimentConstants.EXPERIMENT_LINKNAME, expp.getExperimentLinkname());
			
			if(hs.containsKey(ExperimentConstants.HEATMAP_MAX_VISITORS)){
				heatmap.put(HeatmapExperimentConstants.MAX_VISITORS, hs.get(ExperimentConstants.HEATMAP_MAX_VISITORS));
			}
			if(hs.containsKey(ExperimentConstants.EXPERIMENT_STATUS)){
				heatmap.put(ExperimentConstants.EXPERIMENT_STATUS, hs.get(ExperimentConstants.EXPERIMENT_STATUS).toString());
			}
		}
		
		return heatmap;
	}
}
