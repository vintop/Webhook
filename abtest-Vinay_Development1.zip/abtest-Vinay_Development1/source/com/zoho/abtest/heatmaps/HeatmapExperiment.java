//$Id$
package com.zoho.abtest.heatmaps;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.transaction.Transaction;
import javax.transaction.TransactionManager;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.iam.IAMUtil;
import com.adventnet.iam.ServiceOrg;
import com.adventnet.persistence.DataAccess;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.persistence.WritableDataObject;
import com.amazonaws.services.applicationdiscovery.model.ResourceNotFoundException;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.HEATMAP_EXPERIMENT;
import com.zoho.abtest.HEATMAP_EXPERIMENT_VISITS;
import com.zoho.abtest.PROJECT;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.eventactivity.EventActivityConstants;
import com.zoho.abtest.eventactivity.EventActivityConstants.Module;
import com.zoho.abtest.eventactivity.EventActivityLog;
import com.zoho.abtest.eventactivity.EventActivityWrapper;
import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentStatus;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentType;
import com.zoho.abtest.funnel.FunnelAnalysisConstants;
import com.zoho.abtest.funnel.FunnelStep;
import com.zoho.abtest.goal.ExperimentGoal;
import com.zoho.abtest.goal.Goal;
import com.zoho.abtest.listener.ZABNotifier;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.project.ProjectTreeEventConstants;
import com.zoho.abtest.project.ProjectTreeEventConstants.OperationType;
import com.zoho.abtest.project.ProjectTreeEventWrapper;
import com.zoho.abtest.report.ReportRawDataConstants;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.logs.apache.commons.lang3.StringEscapeUtils;

public class HeatmapExperiment extends Experiment{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = Logger.getLogger(Experiment.class.getName());

	private Long heatmapExperimentId;
	private Long experimentId;
	private String experimentUrl;
	private String excludedUrls;
	private String includedUrls;
	private Integer permittedTraffic;
	private Long visitorCount;
	private Long visitsCount;
	private double clicksPerVisit;
	private double totalClicks;
	private Integer maxVisitors;
	

	public Long getHeatmapExperimentId() {
		return heatmapExperimentId;
	}

	public void setHeatmapExperimentId(Long heatmapExperimentId) {
		this.heatmapExperimentId = heatmapExperimentId;
	}

	public Long getExperimentId() {
		return experimentId;
	}

	public void setExperimentId(Long experimentId) {
		this.experimentId = experimentId;
	}

	
	public String getExperimentUrl() {
		return experimentUrl;
	}

	public void setExperimentUrl(String experimentUrl) {
		this.experimentUrl = experimentUrl;
	}

	public String getExcludedUrls() {
		return excludedUrls;
	}

	public void setExcludedUrls(String excludedUrls) {
		this.excludedUrls = excludedUrls;
	}

	public Long getVisitorCount() {
		return visitorCount;
	}

	public void setVisitorCount(Long visitorCount) {
		this.visitorCount = visitorCount;
	}
	
	public double getClicksPerVisit() {
		return clicksPerVisit;
	}

	public void setClicksPerVisit(double clicksPerVisit) {
		this.clicksPerVisit = clicksPerVisit;
	}

	public double getTotalClicks() {
		return totalClicks;
	}

	public void setTotalClicks(double totalClicks2) {
		this.totalClicks = totalClicks2;
	}

	public Long getVisitsCount() {
		return visitsCount;
	}

	public void setVisitsCount(Long visitsCount) {
		this.visitsCount = visitsCount;
	}
	
	public Integer getPermittedTraffic() {
		return permittedTraffic;
	}

	public void setPermittedTraffic(Integer permittedTraffic) {
		this.permittedTraffic = permittedTraffic;
	}

	public Integer getMaxVisitors() {
		return maxVisitors;
	}

	public void setMaxVisitors(Integer maxVisitors) {
		this.maxVisitors = maxVisitors;
	}
	
	public HeatmapExperiment() {
		
	}

	public String getIncludedUrls() {
		return includedUrls;
	}

	public void setIncludedUrls(String includedUrls) {
		this.includedUrls = includedUrls;
	}
	 
	public HeatmapExperiment(Experiment experiment)
	{
		setExperimentId(experiment.getExperimentId());
		setProjectId(experiment.getProjectId());
		setExperimentName(experiment.getExperimentName());
		setCreateBy(experiment.getCreateBy());
		setCreatedByName(experiment.getCreatedByName());
		setExperimentKey(experiment.getExperimentKey());
		setExperimentLinkname(experiment.getExperimentLinkname());
		setExperimentType(experiment.getExperimentType());
		setExperimentStatus(experiment.getExperimentStatus());
		setDuration(experiment.getDuration());
		setStartDate(experiment.getStartDate());
		setEndDate(experiment.getEndDate());
		setActualStartTime(experiment.getActualStartTime());
		setActualEndTime(experiment.getActualEndTime());
		setCreatedTime(experiment.getCreatedTime());
		setModifiedTime(experiment.getModifiedTime());
		setIsActive(experiment.getIsActive());
		setMakePublic(experiment.getMakePublic());
		setShareUrl(experiment.getShareUrl());
		setProjectLinkname(experiment.getProjectLinkname());
		setSmallThumbnailUrl(experiment.getSmallThumbnailUrl());
		setLargeThumbnailUrl(experiment.getLargeThumbnailUrl());
	}
	
	public static HeatmapExperiment createHeatmapExperiment(HashMap<String, String> hs) {
		
		HeatmapExperiment hmExp = null;
		TransactionManager mgr = DataAccess.getTransactionManager();
		
		try {
				mgr.begin();
			
				Experiment experiment = createExperiment(hs);
				Long experimentId = experiment.getExperimentId();
				
				if(experiment.getSuccess().equals(Boolean.TRUE) && experimentId  != null) {
										
					hs.put(ExperimentConstants.EXPERIMENT_ID, experimentId.toString());
					addDefaultValueIfNotAvailable(hs,HeatmapExperimentConstants.MAX_VISITORS, HeatmapConstants.DEFAULT_MAX_VISITOR_COUNT);
					
					DataObject dobj = createRow(HeatmapExperimentConstants.HEATMAP_EXPERIMENT_TABLE, HEATMAP_EXPERIMENT.TABLE, hs);		
					Row hmRow = dobj.getFirstRow(HEATMAP_EXPERIMENT.TABLE);					
					hmExp = new HeatmapExperiment(experiment);
					getHeatmapExperimentFromRow(hmRow, hmExp);
					
					mgr.commit();
					
					//Trigger event 
					ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
					wrapper.setModel(hmExp);
					wrapper.setChangeSets(hs);
					wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
					wrapper.setType(OperationType.CREATE);
					Long zsoid;
					ServiceOrg currentServiceOrg = IAMUtil.getCurrentServiceOrg();
					if(currentServiceOrg != null)
					{
						zsoid = currentServiceOrg.getZSOID();
						wrapper.setZsoid(zsoid.toString());
					}
					ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);
					
					//Event Activity Log
					HashMap<String, String> updatedValues = new HashMap<String, String>();
					updatedValues.put(EventActivityConstants.EXPERIMENT_ID, experimentId.toString());
					updatedValues.put(EventActivityConstants.USER_ID, ZABUtil.getCurrentUser().getUserId().toString());
					updatedValues.put(EventActivityConstants.TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
					EventActivityWrapper activityWrapper = new EventActivityWrapper();
					activityWrapper.setModule(Module.EXPERIMENT);
					activityWrapper.setOperationType(com.zoho.abtest.eventactivity.EventActivityConstants.OperationType.CREATE);
					activityWrapper.setDbSpace(ZABUtil.getCurrentUserDbSpace());
					activityWrapper.setUpdatedValues(updatedValues);
					ZABNotifier.notifyListeners(EventActivityConstants.EVENT_MODULE_NAME, activityWrapper);
				}
				else
				{
					mgr.rollback();
					LOGGER.log(Level.SEVERE,"Exception Occurred while creating experiment. Hence rolledback changes.");
					hmExp = new HeatmapExperiment();
					hmExp.setSuccess(Boolean.FALSE);
					hmExp.setResponseString(experiment!=null? experiment.getResponseString():ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
				}	
			
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,"Exception Occurred while creating Heatmap Expriment",e);
			hmExp = new HeatmapExperiment();
			hmExp.setSuccess(Boolean.FALSE);
			hmExp.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
		}
		
		return hmExp;
	}
	
	public static void updateHeatmapExperimentUrl(HashMap<String, String> hs) throws Exception {
		
		String linkName = hs.get(ExperimentConstants.EXPERIMENT_LINKNAME);
		
		HeatmapExperiment oldHeatmapExperiment = HeatmapExperiment.getHeatmapExperiment(linkName);
		
		//Logging event activity purpose
		HashMap<String,String> oldValues = generateHashMapFromHeatmapExperimentObj(oldHeatmapExperiment, hs);
		hs.put(ExperimentConstants.MODIFIED_TIME, ZABUtil.getCurrentTimeInMilliSeconds()+"");
		Criteria c = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_LINK_NAME), linkName, QueryConstants.EQUAL);
		updateRow(ExperimentConstants.EXPERIMENT_TABLE, EXPERIMENT.TABLE, hs, c, ExperimentConstants.API_RESOURCE);
		
		Criteria c1 = new Criteria(new Column(HEATMAP_EXPERIMENT.TABLE, HeatmapExperimentConstants.EXPERIMENT_ID), oldHeatmapExperiment.getExperimentId(), QueryConstants.EQUAL);
		updateRow(HeatmapExperimentConstants.HEATMAP_EXPERIMENT_TABLE, HEATMAP_EXPERIMENT.TABLE, hs, c1, ExperimentConstants.API_RESOURCE);
		
		HeatmapExperiment experiment = new HeatmapExperiment();
		experiment.setExperimentLinkname(linkName);
		experiment.setSuccess(Boolean.TRUE);
		
		ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
		wrapper.setModel(experiment);
		wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
		wrapper.setType(OperationType.UPDATE);
		ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);
		
		//Event Activity Log
		HashMap<String, String> updatedValues = new HashMap<String, String>();
		updatedValues.putAll(hs);
		updatedValues.put(EventActivityConstants.EXPERIMENT_ID, oldHeatmapExperiment.getExperimentId().toString());
		updatedValues.put(EventActivityConstants.USER_ID, ZABUtil.getCurrentUser().getUserId().toString());
		updatedValues.put(EventActivityConstants.TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
		EventActivityWrapper activityWrapper = new EventActivityWrapper();
		activityWrapper.setModule(Module.EXPERIMENT);
		activityWrapper.setOperationType(com.zoho.abtest.eventactivity.EventActivityConstants.OperationType.UPDATE);
		activityWrapper.setDbSpace(ZABUtil.getCurrentUserDbSpace());
		activityWrapper.setUpdatedValues(updatedValues);
		activityWrapper.setOldValues(oldValues);
		ZABNotifier.notifyListeners(EventActivityConstants.EVENT_MODULE_NAME, activityWrapper);
	}

	public static HeatmapExperiment updateHeatmapExperiment(HashMap<String, String> hs) {
		
		HeatmapExperiment heatmapExperiment = null;
		TransactionManager mgr = null;
		Boolean alreadyInTransaction = false;
		Long experimentId = null;
		
		try {
			
			
			String linkName = hs.get(ExperimentConstants.EXPERIMENT_LINKNAME);
			
			//Logging event activity purpose
			HeatmapExperiment oldHeatmapExp = HeatmapExperiment.getHeatmapExperiment(linkName);
			HashMap<String,String> oldValues = generateHashMapFromHeatmapExperimentObj(oldHeatmapExp,hs);
			
			experimentId = oldHeatmapExp.getExperimentId();
			
			/*Experiment Validations START*/
			
			/*Experiment Validations END*/
			
			Experiment experiment = Experiment.updateExperiment(hs);
			if(!experiment.getSuccess())
			{
				heatmapExperiment = new HeatmapExperiment();
				heatmapExperiment.setSuccess(Boolean.FALSE);
				heatmapExperiment.setResponseString(experiment.getResponseString());
				return heatmapExperiment;
			}
			
			mgr = DataAccess.getTransactionManager();
			Transaction trans = mgr.getTransaction();
			alreadyInTransaction = (trans!=null);
			if(!alreadyInTransaction) {				
				mgr.begin();
			}
			
			if(hs.containsKey(ExperimentConstants.INCLUDE_URLS)){
				hs.put(ExperimentConstants.INCLUDE_URLS, StringEscapeUtils.unescapeJava(hs.get(ExperimentConstants.INCLUDE_URLS)));
			}
			
			if(hs.containsKey(ExperimentConstants.EXCLUDE_URLS)){
				hs.put(ExperimentConstants.EXCLUDE_URLS, StringEscapeUtils.unescapeJava(hs.get(ExperimentConstants.EXCLUDE_URLS)));
			}
			
			Criteria c = new Criteria(new Column(HEATMAP_EXPERIMENT.TABLE, HeatmapExperimentConstants.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
			updateRow(HeatmapExperimentConstants.HEATMAP_EXPERIMENT_TABLE, HEATMAP_EXPERIMENT.TABLE, hs, c, ExperimentConstants.API_RESOURCE);
			
			if(!alreadyInTransaction) {
				mgr.commit();
			}
			
			heatmapExperiment = new HeatmapExperiment(experiment);
			Row latestHeatmapRow = getHeatmapExperimentRow(experimentId);
			getHeatmapExperimentFromRow(latestHeatmapRow, heatmapExperiment);
			
			
			//Notify event
			ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
			wrapper.setModel(heatmapExperiment);
			if (hs.containsKey(ExperimentConstants.IS_ACTIVE)
					
					|| (hs.containsKey(ExperimentConstants.EXPERIMENT_STATUS) && (ExperimentStatus.PAUSED
							.getStatusCode()
							.equals(Integer.parseInt(hs
									.get(ExperimentConstants.EXPERIMENT_STATUS))) || ExperimentStatus.RUNNING
							.getStatusCode()
							.equals(Integer.parseInt(hs
									.get(ExperimentConstants.EXPERIMENT_STATUS)))))) {
			   //Flag to update CDN only is the status is changed to paused or running
			   wrapper.setCustomObject(true);
			}
			wrapper.setChangeSets(hs);
			wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
			wrapper.setType(OperationType.UPDATE);
			ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);
			
			//Event Activity Log
			HashMap<String, String> updatedValues = new HashMap<String, String>();
			updatedValues.putAll(hs);
			updatedValues.put(EventActivityConstants.EXPERIMENT_ID, experimentId.toString());
			if(ZABUtil.getCurrentUser() != null)
			{
				updatedValues.put(EventActivityConstants.USER_ID, ZABUtil.getCurrentUser().getUserId().toString());
			}
			updatedValues.put(EventActivityConstants.TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
			EventActivityWrapper activityWrapper = new EventActivityWrapper();
			activityWrapper.setModule(Module.EXPERIMENT);
			activityWrapper.setOperationType(com.zoho.abtest.eventactivity.EventActivityConstants.OperationType.UPDATE);
			activityWrapper.setDbSpace(ZABUtil.getCurrentUserDbSpace());
			activityWrapper.setUpdatedValues(updatedValues);
			activityWrapper.setOldValues(oldValues);
			ZABNotifier.notifyListeners(EventActivityConstants.EVENT_MODULE_NAME, activityWrapper);
		} catch (ResourceNotFoundException | ZABException e) {
			
			heatmapExperiment = new HeatmapExperiment();
			heatmapExperiment.setSuccess(Boolean.FALSE);
			heatmapExperiment.setResponseString(e.getMessage());
			if(e instanceof ResourceNotFoundException) {
				heatmapExperiment.setResponseCode(((ResourceNotFoundException) e).getErrorCode());
			}
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
			if(mgr!=null && !alreadyInTransaction) {
				try {
					mgr.rollback();
				} catch (Exception e1) {
					LOGGER.log(Level.SEVERE,"Exception Occurred",e1);
				}
			}
		} catch (Exception e) {
			heatmapExperiment = new HeatmapExperiment();
			heatmapExperiment.setSuccess(Boolean.FALSE);
			heatmapExperiment.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			if(mgr!=null && !alreadyInTransaction) {
				try {
					mgr.rollback();
				} catch (Exception e1) {
					LOGGER.log(Level.SEVERE,"Exception Occurred",e1);
				}
			}
		}
		return heatmapExperiment;
	}
	
	public static HeatmapExperiment getHeatmapExperimentDetailsFromLinkname(String expLinkname){
		
		HeatmapExperiment experiment = null;
		try
		{
			Criteria c = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_LINK_NAME), expLinkname, QueryConstants.EQUAL);
			Join join = new Join(EXPERIMENT.TABLE, HEATMAP_EXPERIMENT.TABLE, new String[]{EXPERIMENT.EXPERIMENT_ID}, new String[]{HeatmapExperimentConstants.EXPERIMENT_ID}, Join.INNER_JOIN);
			Join join1=new Join(EXPERIMENT.TABLE,PROJECT.TABLE,new String[]{EXPERIMENT.PROJECT_ID},new String[]{PROJECT.PROJECT_ID},Join.INNER_JOIN);
			Join join2 = new Join(EXPERIMENT.TABLE, HEATMAP_EXPERIMENT_VISITS.TABLE, new String[]{EXPERIMENT.EXPERIMENT_ID}, new String[]{HeatmapExperimentConstants.EXPERIMENT_ID}, Join.LEFT_JOIN);
			
			DataObject dataObj = ZABModel.getRow(EXPERIMENT.TABLE, c,new Join[]{join,join1,join2});
			Row expRow = dataObj.getFirstRow(EXPERIMENT.TABLE);	
			
			if(expRow!=null){
				
				Row hmRow = dataObj.getFirstRow(HEATMAP_EXPERIMENT.TABLE);
				experiment = getHeatmapExperimentFromRow(expRow,hmRow);
				experiment.setProjectLinkname(Project.getProjectLinkname(dataObj, experiment.getProjectId()));
				
				/*if(dataObj.containsTable(HEATMAP_EXPERIMENT_VISITS.TABLE)) {
					
					Criteria c1 = new Criteria(new Column(HEATMAP_EXPERIMENT_VISITS.TABLE, HEATMAP_EXPERIMENT_VISITS.EXPERIMENT_ID), experiment.getExperimentId(), QueryConstants.EQUAL);
					Iterator it = dataObj.getRows(HEATMAP_EXPERIMENT_VISITS.TABLE, c1);
					
					
					if(it.hasNext())
					{
						Row row1 = (Row)it.next();
						experiment.setVisitorCount((Long)row1.get(HEATMAP_EXPERIMENT_VISITS.UNIQUE_VISITOR_COUNT));
						
						long totalVisits = (Long)row1.get(HEATMAP_EXPERIMENT_VISITS.TOTAL_VISITOR_COUNT);
						double totalclicks = (Long)row1.get(HEATMAP_EXPERIMENT_VISITS.TOTAL_CLICKS);
						double clicks_per_visit = totalclicks/totalVisits;
						
						experiment.setVisitsCount(totalVisits);
						experiment.setTotalClicks(totalclicks);
						experiment.setClicksPerVisit((double)Math.round((double)clicks_per_visit*10)/ 10);
					}
				}*/
				HeatmapElasticSearch.setHeatmapExperimentDetailsFromES(experiment);
			}
		}
		catch(Exception ex)
		{
			experiment = new HeatmapExperiment();
			experiment.setSuccess(Boolean.FALSE);
		}
		return experiment;
	}
	
	public static HeatmapExperiment getHeatmapExperiment(String expLinkname)
	{
		HeatmapExperiment exp = null;
		try
		{
			Criteria c = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_LINK_NAME), expLinkname, QueryConstants.EQUAL);
			Join join = new Join(EXPERIMENT.TABLE, HEATMAP_EXPERIMENT.TABLE, new String[]{EXPERIMENT.EXPERIMENT_ID}, new String[]{HeatmapExperimentConstants.EXPERIMENT_ID}, Join.INNER_JOIN);
			DataObject dataObj = ZABModel.getRow(EXPERIMENT.TABLE, c, join);
			Row expRow = dataObj.getFirstRow(EXPERIMENT.TABLE);	
			if(expRow!=null){
				
				Row hmRow = dataObj.getFirstRow(HEATMAP_EXPERIMENT.TABLE);
				exp = getHeatmapExperimentFromRow(hmRow);
			}
		}
		catch(Exception ex)
		{
			exp = new HeatmapExperiment();
			exp.setSuccess(Boolean.FALSE);
		}
		return exp;
	}
	
	public static HeatmapExperiment addDuplicateHeatmapExperimentRow(Row row, HeatmapExperiment experiment) throws Exception {
		
		DataObject wdobj = new WritableDataObject();
		Row newERow = new Row(HEATMAP_EXPERIMENT.TABLE);
		
		newERow.set(HEATMAP_EXPERIMENT.EXPERIMENT_ID, experiment.getExperimentId());
		newERow.set(HEATMAP_EXPERIMENT.EXPERIMENT_URL, (String)row.get(HEATMAP_EXPERIMENT.EXPERIMENT_URL));
		newERow.set(HEATMAP_EXPERIMENT.EXCLUDE_URLS, (String)row.get(HEATMAP_EXPERIMENT.EXCLUDE_URLS));
		newERow.set(HEATMAP_EXPERIMENT.INCLUDE_URLS, (String)row.get(HEATMAP_EXPERIMENT.INCLUDE_URLS));
		newERow.set(HEATMAP_EXPERIMENT.MAX_VISITOR_COUNT, (Integer)row.get(HEATMAP_EXPERIMENT.MAX_VISITOR_COUNT));
		wdobj.addRow(newERow);
		updateDataObject(wdobj);
		return getHeatmapExperimentFromRow(newERow, experiment);
	}
	
	public static HeatmapExperiment getHeatmapExperimentDetails(String expLinkname)
	{
		HeatmapExperiment exp = null;
		try
		{
			Criteria c = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_LINK_NAME), expLinkname, QueryConstants.EQUAL);
			Join join = new Join(EXPERIMENT.TABLE, HEATMAP_EXPERIMENT.TABLE, new String[]{EXPERIMENT.EXPERIMENT_ID}, new String[]{HEATMAP_EXPERIMENT.EXPERIMENT_ID}, Join.INNER_JOIN);
			DataObject dataObj = ZABModel.getRow(EXPERIMENT.TABLE, c, join);
			Row heatmapRow = dataObj.getFirstRow(HEATMAP_EXPERIMENT.TABLE);
			Row expRow = dataObj.getFirstRow(EXPERIMENT.TABLE);
			exp = getHeatmapExperimentFromRow(expRow, heatmapRow);
		}
		catch(Exception ex)
		{
			exp = new HeatmapExperiment();
			exp.setSuccess(Boolean.FALSE);
		}
		return exp;
	}
	
	public static ArrayList<HeatmapExperiment> getHeatmapExperimentFromDobj(DataObject dobj) throws DataAccessException {
		ArrayList<HeatmapExperiment> experiments = new ArrayList<HeatmapExperiment>();
		if(dobj.containsTable(HEATMAP_EXPERIMENT.TABLE)) {
			Iterator it = dobj.getRows(HEATMAP_EXPERIMENT.TABLE);
			while(it.hasNext()) {
				Row hmrow = (Row)it.next();
				Long experimentId = (Long)hmrow.get(EXPERIMENT.EXPERIMENT_ID);
				Criteria criteria1 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
				Row experimentRow = dobj.getRow(EXPERIMENT.TABLE, criteria1);
				HeatmapExperiment experiment = getHeatmapExperimentFromRow(experimentRow, hmrow);
				experiment.setProjectLinkname(Project.getProjectLinkname(dobj, experiment.getProjectId()));
				experiments.add(experiment);
			}
		}
		return experiments;
	}
	
	public static void setExperimentValuesInHeatmap(HeatmapExperiment heatmapExp, Experiment experiment)
	{
		heatmapExp.setExperimentId(experiment.getExperimentId());
		heatmapExp.setProjectId(experiment.getProjectId());
		heatmapExp.setExperimentName(experiment.getExperimentName());
		heatmapExp.setCreateBy(experiment.getCreateBy());
		heatmapExp.setCreatedByName(experiment.getCreatedByName());
		heatmapExp.setExperimentKey(experiment.getExperimentKey());
		heatmapExp.setExperimentLinkname(experiment.getExperimentLinkname());
		heatmapExp.setExperimentType(experiment.getExperimentType());
		heatmapExp.setExperimentStatus(experiment.getExperimentStatus());
		heatmapExp.setDuration(experiment.getDuration());
		heatmapExp.setStartDate(experiment.getStartDate());
		heatmapExp.setEndDate(experiment.getEndDate());
		heatmapExp.setActualStartTime(experiment.getActualStartTime());
		heatmapExp.setActualEndTime(experiment.getActualEndTime());
		heatmapExp.setCreatedTime(experiment.getCreatedTime());
		heatmapExp.setModifiedTime(experiment.getModifiedTime());
		heatmapExp.setIsActive(experiment.getIsActive());
		heatmapExp.setProjectLinkname(experiment.getProjectLinkname());
		heatmapExp.setSmallThumbnailUrl(experiment.getSmallThumbnailUrl());
		heatmapExp.setLargeThumbnailUrl(experiment.getLargeThumbnailUrl());
	}
	
	public static HeatmapExperiment getHeatmapExperimentFromRow(Row heatmapRow, HeatmapExperiment experiment) {
		
		experiment.setExperimentUrl((String)heatmapRow.get(HEATMAP_EXPERIMENT.EXPERIMENT_URL));
		experiment.setExcludedUrls((String)heatmapRow.get(HEATMAP_EXPERIMENT.EXCLUDE_URLS));
		experiment.setIncludedUrls((String)heatmapRow.get(HEATMAP_EXPERIMENT.INCLUDE_URLS));
		//experiment.setPermittedTraffic((Integer)heatmapRow.get(HeatmapExperimentConstants.PERMITTED_TRAFFIC));
		experiment.setMaxVisitors((Integer)heatmapRow.get(HEATMAP_EXPERIMENT.MAX_VISITOR_COUNT));
		
		experiment.setSuccess(Boolean.TRUE);
		return experiment;
	}
	
	public static HeatmapExperiment getHeatmapExperimentFromRow(Row expRow, Row heatmapRow) {
		
			HeatmapExperiment experiment = new HeatmapExperiment();
			
			getExperimentFromRow(expRow, experiment);
			
			experiment.setExperimentUrl((String)heatmapRow.get(HEATMAP_EXPERIMENT.EXPERIMENT_URL));
			experiment.setExcludedUrls((String)heatmapRow.get(HEATMAP_EXPERIMENT.EXCLUDE_URLS));
			experiment.setIncludedUrls((String)heatmapRow.get(HEATMAP_EXPERIMENT.INCLUDE_URLS));
			//experiment.setPermittedTraffic((Integer)heatmapRow.get(HEATMAP_EXPERIMENT.PERMITTED_TRAFFIC));
			experiment.setMaxVisitors((Integer)heatmapRow.get(HEATMAP_EXPERIMENT.MAX_VISITOR_COUNT));
			
			experiment.setSuccess(Boolean.TRUE);
			return experiment;
	}
	
	public static HeatmapExperiment getHeatmapExperimentFromRow(Row heatmapRow) {
		
		HeatmapExperiment experiment = new HeatmapExperiment();
		experiment.setExperimentId((Long)heatmapRow.get(HEATMAP_EXPERIMENT.EXPERIMENT_ID));
		experiment.setExperimentUrl((String)heatmapRow.get(HEATMAP_EXPERIMENT.EXPERIMENT_URL));
		experiment.setExcludedUrls((String)heatmapRow.get(HEATMAP_EXPERIMENT.EXCLUDE_URLS));
		experiment.setIncludedUrls((String)heatmapRow.get(HEATMAP_EXPERIMENT.INCLUDE_URLS));
		//experiment.setPermittedTraffic((Integer)heatmapRow.get(HeatmapExperimentConstants.PERMITTED_TRAFFIC));
		experiment.setMaxVisitors((Integer)heatmapRow.get(HEATMAP_EXPERIMENT.MAX_VISITOR_COUNT));
		
		experiment.setSuccess(Boolean.TRUE);
		return experiment;
	}
	
	public static Row getHeatmapExperimentRow(Long expId) throws Exception
	{
		Criteria c = new Criteria(new Column(HEATMAP_EXPERIMENT.TABLE, HeatmapExperimentConstants.EXPERIMENT_ID), expId, QueryConstants.EQUAL);
		DataObject dataObj = ZABModel.getRow(HEATMAP_EXPERIMENT.TABLE, c);
		Row heatmapRow = dataObj.getFirstRow(HEATMAP_EXPERIMENT.TABLE);
		return heatmapRow;
	}
	
	public static HashMap<String,String> generateHashMapFromHeatmapExperimentObj(HeatmapExperiment exp, HashMap<String,String> hs) {
		HashMap<String,String> oldValues = new HashMap<String,String>();
		try
		{
			for(String attributeName:EventActivityConstants.HEATMPA_EXPERIMENT_ATTR_TO_TRACE)
			{
				if(hs.containsKey(attributeName))
				{
					switch(attributeName)
					{
					case HeatmapExperimentConstants.EXPERIMENT_URL:
						oldValues.put(HeatmapExperimentConstants.EXPERIMENT_URL, exp.getExperimentUrl());
						break;
					case HeatmapExperimentConstants.EXCLUDE_URLS:
						oldValues.put(HeatmapExperimentConstants.EXCLUDE_URLS, exp.getExcludedUrls());
						break;
					case HeatmapExperimentConstants.INCLUDE_URLS:
						oldValues.put(HeatmapExperimentConstants.INCLUDE_URLS, exp.getIncludedUrls());
						break;
					case HeatmapExperimentConstants.PERMITTED_TRAFFIC:
						oldValues.put(HeatmapExperimentConstants.PERMITTED_TRAFFIC, exp.getPermittedTraffic().toString());
						break;
					case HeatmapExperimentConstants.MAX_VISITORS:
						oldValues.put(HeatmapExperimentConstants.MAX_VISITORS, exp.getMaxVisitors().toString());
						break;
					}
				}
			}
			oldValues.put(ExperimentConstants.EVENT_EXPERIMENT_TYPE,ExperimentType.HEATMAP.getTypeNumber().toString());
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		return oldValues;
	}
	
	public static void updateHeatmapVisits(HashMap<String,String> inpuths)
	{
		try
		{
			boolean isNewVisitor = Boolean.parseBoolean(inpuths.get(ReportRawDataConstants.IS_NEW_VISITOR));
			Long uniqueVisitorCount = isNewVisitor?1l:0l;
			Long totalVisitorCount = 1l;
			HashMap<String, String> visitsHs = new HashMap<String,String>(); 
			visitsHs.put(HeatmapConstants.EXPERIMENT_ID,  inpuths.get(ReportRawDataConstants.EXPERIMENT_ID));
			visitsHs.put(HeatmapConstants.UNIQUE_VISITOR_COUNT, uniqueVisitorCount.toString());
			visitsHs.put(HeatmapConstants.TOTAL_VISITOR_COUNT, totalVisitorCount.toString());
			HeatmapExperimentVisits.updateHeatmapExperimentVisits(visitsHs,isNewVisitor); 
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
			LOGGER.log(Level.SEVERE,"Exception occured while updating variation visits count");
		}
	}
	
	public static void updateHeatmapVisitsClicks(String experimentId,String clicks)
	{
		try
		{
			HashMap<String, String> visitsHs = new HashMap<String,String>(); 
			visitsHs.put(HeatmapConstants.EXPERIMENT_ID, experimentId);
			visitsHs.put(HeatmapConstants.TOTAL_CLICKS,clicks);
			HeatmapExperimentVisits.updateHeatmapExperimentVisitsClicks(visitsHs); 
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
			LOGGER.log(Level.SEVERE,"Exception occured while updating variation visits count");
		}
	}
	
	private static long getActiveDaysFromLogs(List<EventActivityLog> status_logs,Long endtime){
		
		String last_status_runnig_date = null;
		String last_status_paused_date = null;
		String current_status_running_date = null;
		String current_status_pause_date = null;
		long activedays = 0;
		
		try{
		
		
			for(int i=0; i< status_logs.size() ; i++){
				
				EventActivityLog event = status_logs.get(i);
				String date = ZABUtil.getDateTimeFormatted(event.getTime(),"yyyy-MM-dd"); //NO I18N
				
				if(event.getValue().equals("RUNNING")){ //NO I18N
		
					if(date.equals(last_status_runnig_date) || date.equals(last_status_paused_date)){
						current_status_running_date =  ZABUtil.getDateTimeFormatted(ZABUtil.getNthDayDateInLong(event.getTime(),1),"yyyy-MM-dd"); //NO I18N
					}else{
						current_status_running_date = date;
					}
				}
				if(event.getValue().equals("PAUSED") && !date.equals(last_status_paused_date)){ //NO I18N
					
					current_status_pause_date = date;
				}
				
				if(current_status_running_date!=null && current_status_pause_date != null){
					
					activedays += ZABUtil.getInclusiveDaysDifferenceBetweenDates(current_status_running_date,current_status_pause_date);
					
					last_status_runnig_date = current_status_running_date;
					last_status_paused_date = current_status_pause_date;
					current_status_running_date = null;
					current_status_pause_date = null;
				}
			}
			
			if(current_status_running_date!=null){
				
				current_status_pause_date =  ZABUtil.getDateTimeFormatted(endtime,"yyyy-MM-dd"); //NO I18N
				activedays += ZABUtil.getInclusiveDaysDifferenceBetweenDates(current_status_running_date, current_status_pause_date);
			}
		}catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
			LOGGER.log(Level.SEVERE,"Exception occured while calculating experiment active days"); //NO I18N
		}
		
		return activedays;
		
	}
	public static long getExperimentActiveDays(Long experimentId,Long starttime,Long endtime){
		
		long activedays0 = 0;
		long activedays1= 0;
		long activedays = 0;
		Long log_endtime;
		
		try{
					
			List<EventActivityLog> all_status_logs = EventActivityLog.getEventActivityLogByExperimentAndType(experimentId, null, null,EventActivityConstants.EventType.EXPERIMENT_STATUS_UPDATE.getEventValue());
			
			EventActivityLog event = all_status_logs.get(0);
			Long first_start_time = event.getTime(); 
			
			if(first_start_time > endtime){
				return 0;
			}
			
			activedays0 = getActiveDaysFromLogs(all_status_logs,endtime);
			
			log_endtime = ZABUtil.getNthDayDateInLong(starttime,-1);
			List<EventActivityLog> status_logs = EventActivityLog.getEventActivityLogByExperimentAndType(experimentId, null, starttime,EventActivityConstants.EventType.EXPERIMENT_STATUS_UPDATE.getEventValue());
			activedays1 = getActiveDaysFromLogs(status_logs,log_endtime);
			
			activedays = activedays0 - activedays1;
			
		}catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
			LOGGER.log(Level.SEVERE,"Exception occured while getting experiment active days"); //NO I18N
		}
		
		return activedays;
	}
	
	public static HeatmapExperiment duplicateHeatmapExperiment(String linkname) {
		
		HeatmapExperiment hmExperiment = null;
		TransactionManager mgr = DataAccess.getTransactionManager();
		try {		
			Criteria c = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_LINK_NAME), linkname, QueryConstants.EQUAL);
			DataObject dobj = getPersonality(ExperimentConstants.EXPERIMENT_DETAIL_PERSONALITY, c);
			if(dobj.containsTable(EXPERIMENT.TABLE)) {
				
				mgr.begin();
				
				Experiment experiment = Experiment.duplicateExperiment(dobj);
				
				if(experiment != null && experiment.getExperimentId() != null)
				{
					Row hmRow = dobj.getRow(HEATMAP_EXPERIMENT.TABLE);
					hmExperiment = new HeatmapExperiment(experiment);
					
					//Add Heatmap Experiment row
					addDuplicateHeatmapExperimentRow(hmRow,hmExperiment);	
				}
				
				//Done have to trigger event to update javascript here as the status of this experiment will be in draft

				mgr.commit();
				
			} else {
				
				hmExperiment = new HeatmapExperiment();
				hmExperiment.setSuccess(Boolean.FALSE);
				hmExperiment.setResponseString(ZABAction.getMessage(ZABConstants.ErrorMessages.RESOURCE_NOT_FOUND.getErrorString(),new String[]{ExperimentConstants.API_MODULE}));
				return hmExperiment;
			}
			
			ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
			ServiceOrg currentServiceOrg = IAMUtil.getCurrentServiceOrg();
			if(currentServiceOrg != null)
			{
				wrapper.setZsoid(currentServiceOrg.getZSOID()+"");
			}
			wrapper.setModel(hmExperiment);
			wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
			wrapper.setType(OperationType.CREATE);
			ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);
			
		} catch (Exception e) {
			
			try
			{
				mgr.rollback();
			}
			catch(Exception e1)
			{
				LOGGER.log(Level.SEVERE,"Exception Occurred",e1);
			}
			
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
			hmExperiment = new HeatmapExperiment();
			hmExperiment.setSuccess(Boolean.FALSE);
			hmExperiment.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
		}

		return hmExperiment;
	}
}
