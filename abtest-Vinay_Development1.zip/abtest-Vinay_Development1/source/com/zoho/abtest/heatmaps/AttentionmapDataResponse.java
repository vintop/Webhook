//$Id$
package com.zoho.abtest.heatmaps;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;

public class AttentionmapDataResponse {
	
	private static final Logger LOGGER = Logger.getLogger(HeatmapDataResponse.class.getName());
	
	public static String jsonResponse(HttpServletRequest request,ArrayList<Scrollmap> lst) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(lst);			
			JSONObject json = ZABResponse.updateMetaInfo(request, HeatmapConstants.ATTENTIONMAP_API_MODULE, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		return returnBuffer.toString();
	}

	public static JSONArray getJSONArray(ArrayList<Scrollmap> lst) throws JSONException {
		
		JSONArray array = new JSONArray();
		int size =lst.size();
		for (int i=0;i<size;i++) {
			Scrollmap ld=lst.get(i);
			JSONObject jsonObj = new JSONObject();

			jsonObj.put(HeatmapConstants.EXPERIMENT_ID.toLowerCase(), ld.getExperimentId());

			jsonObj.put(HeatmapConstants.EXPERIMENT_LINKNAME.toLowerCase(), ld.getExperimentLinkname());
			jsonObj.put(HeatmapConstants.VARIATION_LINKNAME.toLowerCase(), ld.getVariationLinkname());
			jsonObj.put(HeatmapConstants.START_DATE.toLowerCase(), ld.getStartDate());
			jsonObj.put(HeatmapConstants.END_DATE.toLowerCase(), ld.getEndDate());
			jsonObj.put(HeatmapConstants.VISITS_COUNT.toLowerCase(), ld.getVisitsCount());
			jsonObj.put(HeatmapConstants.VISITORS_COUNT.toLowerCase(), ld.getVisitorCount());
			jsonObj.put(HeatmapConstants.AVERAGE_FOLD.toLowerCase(),ld.getAverageFold());
			jsonObj.put(HeatmapConstants.ALL_DEVICE_VISITS.toLowerCase(),getAllDeviceVisits(ld.getDeviceVisits()));
			jsonObj.put(HeatmapConstants.SCROLL_POINTS.toLowerCase(),getScrollDataPointsObject(ld.getScrollmapPoints()));
			jsonObj.put(HeatmapConstants.ATTENTION_DATA.toLowerCase(),getAttentionmapDataPointsObject(ld.getAttentionData()));

			jsonObj.put(ZABConstants.SUCCESS, ld.getSuccess());
			
			array.put(jsonObj);
		}
		return array;
	}
	
	public static JSONArray getAllDeviceVisits(ArrayList<HashMap<String,Object>> deviceVisits) throws JSONException {
		
		if(deviceVisits == null){
			return null;
		}
		JSONArray array = new JSONArray();
		
		for(int i=0; i< deviceVisits.size(); i++){
			
			JSONObject object = new JSONObject();
			HashMap<String,Object> topclick = deviceVisits.get(i);
			for(Entry<String, Object> map : topclick.entrySet()){
				object.put(map.getKey(), map.getValue());
			}
			array.put(object);
		}
		
		return array;
	}
	
	public static JSONObject getAttentionmapDataPointsObject(HashMap<String,HashMap<String,Long>> attentionData) throws JSONException {
		
		if(attentionData == null){
			return null;
		}
		JSONObject object = new JSONObject();
		
		for(Entry<String, HashMap<String,Long>> map : attentionData.entrySet()){
			
			JSONObject innerObject = new JSONObject();
			HashMap<String,Long> mapValue = map.getValue();
			for(Entry<String, Long> innerMap : mapValue.entrySet()){
				innerObject.put(innerMap.getKey(), innerMap.getValue());
			}
			object.put(map.getKey(),innerObject);
		}
		
		return object;
	}

	public static JSONObject getScrollDataPointsObject(HashMap<String,Long> smpoints) throws JSONException {
		
		if(smpoints == null){
			return null;
		}
		JSONObject object = new JSONObject();
		
		for(Entry<String, Long> map : smpoints.entrySet()){
			
			object.put(map.getKey(), map.getValue());
		}
		
		return object;
	}
}
