//$Id$
package com.zoho.abtest.heatmaps;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.HEATMAP_EXPERIMENT;
import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.ZABConstants;

public class HeatmapExperimentConstants {
	

	public static final String API_MODULE = "heatmapexperiment"; //No I18N
	
	public static final String API_MODULE_PLURAL = "heatmapexperiments"; //No I18N
	
	//public static final String API_RESOURCE = "resource.experiment"; //NO I18N
	
	//public static final String API_RESOURCE_INITIAL = "resource.experiment.initial"; //NO I18N
	
	public static final String HEATMAP_EXPERIMENT_ID = "experiment_id"; //No I18N
	
	public static final String EXPERIMENT_ID = "experiment_id"; //No I18N
	
	public static final String EXPERIMENT_KEY = "experiment_key"; //No I18N
	
	public static final String EXPERIMENT_URL = "experiment_url"; //No I18N
	
	public static final String EXPERIMENT_STATUS = "experiment_status"; //No I18N

	public static final String PROJECT_LINKNAME = "project_linkname"; //NO I18N
	
	public static final String GOAL_LINKNAME = "goal_linkname"; //NO I18N
	
	public static final String PROJECT_ID = "project_id"; //NO I18N
	
	public static final String EXPERIMENT_NAME = "display_name"; //No I18N
	
	public static final String EXPERIMENT_LINKNAME = "linkname"; //No I18N
		
	public static final String CREATED_TIME = "created_time"; //No I18N
	
	public static final String CREATED_DATE = "created_date"; //No I18N
	
	public static final String CREATED_DATETIME = "created_datetime"; //No I18N
	
	public static final String MODIFIED_TIME = "modified_time"; //No I18N
	
	public static final String MODIFIED_DATE = "modified_date"; //No I18N
	
	public static final String MODIFIED_DATETIME = "modified_datetime"; //No I18N
	
	public static final String VARIATION = "variations"; //No I18N
	
	public static final String DURTATION = "duration"; //No I18N
	
	public static final String START_DATE = "start_date"; //No I18N
	
	public static final String ACTUAL_START_TIME = "actual_start_time"; //No I18N
	
	public static final String ACTUAL_END_TIME = "actual_end_time"; //No I18N
	
	public static final String PERMITTED_TRAFFIC = "permitted_traffic"; //No I18N
	
	public static final String END_DATE = "end_date"; // No I18N

	public static final String DATE_FORMAT = "dd/MM/yyyy HH:mm"; //No I18N
	
	public static final String IS_ACTIVE = "is_active";	// NO I18N
	
	public static final String CREATED_BY = "created_by"; //No I18N
	
	public final static String EXCLUDE_URLS = "exclude_urls"; //NO I18N
	
	public final static String INCLUDE_URLS = "include_urls"; //NO I18N
	
	public final static String MAX_VISITORS = "max_visitor_count"; //NO I18N
	
	static List<Constants> HEATMAP_EXPERIMENT_TABLE = null;
	
	static{
		ArrayList<Constants> list = new ArrayList<Constants>();
		list.add(new Constants(EXPERIMENT_ID,HEATMAP_EXPERIMENT.EXPERIMENT_ID,ZABConstants.LONG,Boolean.FALSE));
		list.add(new Constants(EXPERIMENT_URL,HEATMAP_EXPERIMENT.EXPERIMENT_URL,ZABConstants.STRING,Boolean.TRUE));
		list.add(new Constants(EXCLUDE_URLS,HEATMAP_EXPERIMENT.EXCLUDE_URLS,ZABConstants.STRING,Boolean.TRUE,Boolean.TRUE));
		list.add(new Constants(INCLUDE_URLS,HEATMAP_EXPERIMENT.INCLUDE_URLS,ZABConstants.STRING,Boolean.TRUE,Boolean.TRUE));
		list.add(new Constants(MAX_VISITORS,HEATMAP_EXPERIMENT.MAX_VISITOR_COUNT,ZABConstants.INTEGER,Boolean.TRUE,Boolean.TRUE));
		HEATMAP_EXPERIMENT_TABLE = (List<Constants>) Collections.unmodifiableList(list);
	}

}
