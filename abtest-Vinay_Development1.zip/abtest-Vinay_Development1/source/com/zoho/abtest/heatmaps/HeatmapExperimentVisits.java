//$Id$
package com.zoho.abtest.heatmaps;


import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Operation;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.UpdateQuery;
import com.adventnet.ds.query.UpdateQueryImpl;
import com.zoho.abtest.HEATMAP_EXPERIMENT_VISITS;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.variation.VariationConstants;
import com.zoho.abtest.variation.VariationVisits;

public class HeatmapExperimentVisits extends ZABModel{

	private static final Logger LOGGER = Logger.getLogger(VariationVisits.class.getName());
	private static final long serialVersionUID = 1L;
	
	private Long heatmapExperimentVisitsId;
	private Long experimentId;
	private Long uniqueVisitorCount;
	private Long totalVisitorCount;
	private Long totalClicks;
	
	public Long getHeatmapExperimentVisitsId() {
		return heatmapExperimentVisitsId;
	}
	public void setHeatmapExperimentVisitsId(Long heatmapExperimentVisitsId) {
		this.heatmapExperimentVisitsId = heatmapExperimentVisitsId;
	}
	public Long getExperimentId() {
		return experimentId;
	}
	public void setExperimentId(Long experimentId) {
		this.experimentId = experimentId;
	}
	public Long getUniqueVisitorCount() {
		return uniqueVisitorCount;
	}
	public void setUniqueVisitorCount(Long uniqueVisitorCount) {
		this.uniqueVisitorCount = uniqueVisitorCount;
	}
	public Long getTotalVisitorCount() {
		return totalVisitorCount;
	}
	public void setTotalVisitorCount(Long totalVisitorCount) {
		this.totalVisitorCount = totalVisitorCount;
	}
	public Long getTotalClicks() {
		return totalClicks;
	}
	public void setTotalClicks(Long totalClicks) {
		this.totalClicks = totalClicks;
	}
	
	public static void updateHeatmapExperimentVisits(HashMap<String, String> hs,boolean isNewVisitor) throws Exception
	{
		try
		{
			Long experimentId = Long.parseLong(hs.get(HeatmapConstants.EXPERIMENT_ID));
			Criteria criteria1 = new Criteria(new Column(HEATMAP_EXPERIMENT_VISITS.TABLE,HEATMAP_EXPERIMENT_VISITS.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
			Boolean isExists = ZABModel.resourceExists(HEATMAP_EXPERIMENT_VISITS.TABLE, criteria1);
			if(isExists)
			{
				Long newUniqueCount = Long.parseLong(hs.get(VariationConstants.UNIQUE_VISITOR_COUNT));
				Long newTotalCount = Long.parseLong(hs.get(VariationConstants.TOTAL_VISITOR_COUNT));
				UpdateQuery s = new UpdateQueryImpl(HEATMAP_EXPERIMENT_VISITS.TABLE);
				if(isNewVisitor)
				{
					Column oper = Column.createOperation(Operation.operationType.ADD, Column.getColumn(HEATMAP_EXPERIMENT_VISITS.TABLE, HEATMAP_EXPERIMENT_VISITS.UNIQUE_VISITOR_COUNT),newUniqueCount);
					s.setUpdateColumn(HEATMAP_EXPERIMENT_VISITS.UNIQUE_VISITOR_COUNT,oper);
				}
				Column oper1 = Column.createOperation(Operation.operationType.ADD, Column.getColumn(HEATMAP_EXPERIMENT_VISITS.TABLE, HEATMAP_EXPERIMENT_VISITS.TOTAL_VISITOR_COUNT),newTotalCount);
				s.setUpdateColumn(HEATMAP_EXPERIMENT_VISITS.TOTAL_VISITOR_COUNT,oper1);
				Criteria c = new Criteria(new Column(HEATMAP_EXPERIMENT_VISITS.TABLE,HEATMAP_EXPERIMENT_VISITS.EXPERIMENT_ID),experimentId, QueryConstants.EQUAL); 
				s.setCriteria(c);
				ZABModel.updateResource(s);
			}
			else
			{
				hs.put(HeatmapConstants.TOTAL_CLICKS,"0");
				ZABModel.createRow(HeatmapConstants.HEATMAP_EXPERIMENT_VISITS_CONSTANTS, HEATMAP_EXPERIMENT_VISITS.TABLE, hs);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			throw ex;
		}
	}
	
	public static void updateHeatmapExperimentVisitsClicks(HashMap<String, String> hs) throws Exception
	{
		try
		{
			Long experimentId = Long.parseLong(hs.get(HeatmapConstants.EXPERIMENT_ID));
			Criteria criteria1 = new Criteria(new Column(HEATMAP_EXPERIMENT_VISITS.TABLE,HEATMAP_EXPERIMENT_VISITS.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
			Boolean isExists = ZABModel.resourceExists(HEATMAP_EXPERIMENT_VISITS.TABLE, criteria1);
			if(isExists)
			{
				Long newClicksCount = Long.parseLong(hs.get(HeatmapConstants.TOTAL_CLICKS));
				UpdateQuery s = new UpdateQueryImpl(HEATMAP_EXPERIMENT_VISITS.TABLE);
				if(newClicksCount!=null)
				{
					Column oper = Column.createOperation(Operation.operationType.ADD, Column.getColumn(HEATMAP_EXPERIMENT_VISITS.TABLE, HEATMAP_EXPERIMENT_VISITS.TOTAL_CLICKS),newClicksCount);
					s.setUpdateColumn(HEATMAP_EXPERIMENT_VISITS.TOTAL_CLICKS,oper);
					Criteria c = new Criteria(new Column(HEATMAP_EXPERIMENT_VISITS.TABLE,HEATMAP_EXPERIMENT_VISITS.EXPERIMENT_ID),experimentId, QueryConstants.EQUAL); 
					s.setCriteria(c);
					ZABModel.updateResource(s);
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			throw ex;
		}
	}
}
