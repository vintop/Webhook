//$Id$
package com.zoho.abtest.heatmaps;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.MatchQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.cardinality.CardinalityAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.cardinality.InternalCardinality;
import org.elasticsearch.search.aggregations.metrics.sum.Sum;
import org.elasticsearch.search.aggregations.metrics.sum.SumAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.tophits.TopHits;
import org.elasticsearch.search.aggregations.metrics.tophits.TopHitsAggregationBuilder;
import org.elasticsearch.search.sort.SortBuilder;
import org.elasticsearch.search.sort.SortBuilders;
import org.elasticsearch.search.sort.SortOrder;
import org.json.JSONArray;
import org.json.JSONObject;

import com.zoho.abtest.dynamicconf.DynamicConfigurationConstants;
import com.zoho.abtest.dynamicconf.DynamicConfigurationUtil;
import com.zoho.abtest.elastic.ElasticSearchStatistics;
import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentType;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.report.ReportConstants;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.abtest.variation.Variation;

public class HeatmapElasticSearch {
	
	private static final Logger LOGGER = Logger.getLogger(HeatmapElasticSearch.class.getName());
	
	public static ArrayList<Heatmap> getHeatmapInformation(HashMap<String,String> hs) throws Exception
	{
		ArrayList<Heatmap> reports = new ArrayList<Heatmap>();
		try{
		
			String experimentLinkName = hs.get("EXPERIMENT_LINKNAME");
			Experiment exp  = Experiment.getExperimentByLinkname(experimentLinkName);
	
			if(exp == null){
				Heatmap report = new Heatmap();
				report.setSuccess(Boolean.FALSE);
				reports.add(report);
				return reports;
				//report.setResponseString();
			}
			Long experimentId = exp.getExperimentId();
			String variationLinkname = hs.get(HeatmapConstants.VARIATION_LINKNAME);
			Long variationId = null;
			Boolean invalidVariation = false;
			Boolean isabtestexp = false;
			
			if(Variation.getExperimentVariationCount(experimentId) > 0){
				ArrayList<Variation> variation = Variation.getVariationByLinkname(variationLinkname);
				if(variation == null){
					invalidVariation = true;
				}else{
					variationId = variation.get(0).getVariationId();
					isabtestexp = true;
				}
			}else{
				if(!variationLinkname.equals("original")){
					invalidVariation = true;
				}
			}
			
			if(invalidVariation){
				
				Heatmap report = new Heatmap();
				report.setSuccess(Boolean.FALSE);
				reports.add(report);
				return reports;
			}
			
			String startTime = null;
			String endTime = null;
			
			if(hs.containsKey(HeatmapConstants.START_DATE.toLowerCase())){
				startTime = hs.get(HeatmapConstants.START_DATE.toLowerCase());
			}else{
				startTime = exp.getActualStartTime().toString();
			}
			
			if(hs.containsKey(HeatmapConstants.END_DATE.toLowerCase())){
				endTime  = hs.get(HeatmapConstants.END_DATE.toLowerCase());
			}
			
			Long startTimeInMillis = null;
			if(startTime!=null&&!startTime.isEmpty()){
				 startTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(startTime, "yyyy-MM-dd");		// NO I18N
			}
			
			Long endTimeInMillis = null;
			if(endTime!=null&&!endTime.isEmpty()){
				endTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(endTime, "yyyy-MM-dd");		// NO I18N
				endTimeInMillis = ZABUtil.getNthDayDateInLong(endTimeInMillis, 1);
			}else{
				endTimeInMillis = ZABUtil.getCurrentTimeInMilliSeconds();
			}
			
			//long timedifference = ZABUtil.getDaysDifferenceBetweenDates(startTime,endTime);
			
			String segmentType= hs.get(ReportConstants.SEGMENT_TYPE);
			String reportType = hs.get(ReportConstants.REPORT_TYPE);
			String dynamicAttrLinkName = hs.get(ReportConstants.DYNAMIC_ATTRIBUTE_LINK_NAME);
			String multisegmentCriteria = hs.get(ReportConstants.MULTISEGMENT_CRITERIA);
			String heatmapReqCriteria = hs.get(ReportConstants.HEATMAP_REQUIRED_CRITERIA);
			
			String[] valueArray = null;
			
			String values = hs.get(ReportConstants.VALUES);
			if(values != null)
			{
				JSONArray array  = new JSONArray(values);
				valueArray = new String[array.length()];
				
				for(int i=0;i<array.length();i++){
					valueArray[i] = array.getString(i).toUpperCase();
				}
			}
			
			reports = getElasticHeatmapData(experimentId, variationId, experimentLinkName, variationLinkname, startTimeInMillis, endTimeInMillis,reportType, segmentType, valueArray, dynamicAttrLinkName, multisegmentCriteria, heatmapReqCriteria, isabtestexp);
					
		}catch(Exception ex ){
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		return reports;
	}
	
	public static ArrayList<Heatmap> getElasticHeatmapData(Long expId, Long varId, String expLinkname, String variationLinkname, Long starttime, Long endtime, String reportType, String segmentType, String[] segmentValueCodes, String dynamicAttrLinkName, String multisegmentCriteria, String heatmapReqCriteria, Boolean isheatmapenabled)
	{
		ArrayList<Heatmap> heatmapdeatils = new ArrayList<Heatmap>();
		Heatmap heatmap = null;
		BoolQueryBuilder filterJson =  null;
		BoolQueryBuilder filterJson1 =  null;
		BoolQueryBuilder filterJson2 =  null;
		List<AggregationBuilder> aggrsJsonList = null;
		List<AggregationBuilder> aggrsJsons = null;
		TermsAggregationBuilder aggrsJson1 = null;
	
		try
		{
	
			String portal = ZABUtil.getPortaldomain();//IAMUtil.getCurrentServiceOrg().getDomains().get(0).getDomain();
			String index = ElasticSearchUtil.getIndexByPortal(portal);
			String msc1 = null;
			int size = 0;
			
			if(heatmapReqCriteria!=null){
				msc1 = getCriteriasWithoutDevice(heatmapReqCriteria).toString();
			}
						
			filterJson = generateSourceQueryJson(portal,reportType,segmentType, expId, varId,starttime,endtime,dynamicAttrLinkName,segmentValueCodes,multisegmentCriteria,heatmapReqCriteria, false);
			filterJson1 = generateSourceQueryJson(portal,reportType,segmentType, expId, varId,starttime,endtime,dynamicAttrLinkName,null,multisegmentCriteria, msc1, isheatmapenabled);
			filterJson2 = generateSourceQueryJson(portal,reportType,segmentType, expId, varId,starttime,endtime,dynamicAttrLinkName,null,multisegmentCriteria, heatmapReqCriteria,isheatmapenabled);
			
			
			aggrsJsonList  =  generateHeatmapAggregateJson();
			aggrsJson1 = generateAllDevicesVisitsAggredateJson();
			aggrsJsons = generateAllVistorsAggregateJson();
			

			SearchResponse response = ElasticSearchUtil.getData(index, ElasticSearchConstants.HEATMAP_RAW_TYPE, size, filterJson, aggrsJsonList);
			SearchResponse response1 = ElasticSearchUtil.getData(index, ElasticSearchConstants.VISITOR_RAW_TYPE, size, filterJson1, aggrsJson1);
			SearchResponse response2 = ElasticSearchUtil.getData(index, ElasticSearchConstants.VISITOR_RAW_TYPE, size, filterJson2, aggrsJsons);

			heatmap = readHeatmapResponseData(response,response1,response2);
			heatmap.setExperimentId(expId);
			heatmap.setExperimentLinkname(expLinkname);
			heatmap.setVariationLinkname(variationLinkname);
			heatmap.setActiveDays(HeatmapExperiment.getExperimentActiveDays(expId,starttime,ZABUtil.getNthDayDateInLong(endtime,-1)));
			
			heatmap.setSuccess(Boolean.TRUE);
			
		}
		catch(Exception ex)
		{
 			heatmap = new Heatmap();
			heatmap.setSuccess(Boolean.FALSE);
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		
		heatmapdeatils.add(heatmap);
		return heatmapdeatils;
	}
	
	public static JSONObject getCriteriasWithoutDevice(String multisegmentCriteria) {
		
		JSONArray json = new JSONArray();
		JSONObject msc = null;
		
		try{
			
			msc = new JSONObject(multisegmentCriteria);
			JSONArray conditions = msc.getJSONArray("conditions").getJSONObject(0).getJSONArray("conditions"); //NO I18N
			
			for(int i= 0; i< conditions.length(); i++){
				JSONObject condition = conditions.getJSONObject(i);
				if(!condition.get("type").equals(ElasticSearchConstants.DEVICE)){
					json.put(condition);
				}
			}
			
			msc.getJSONArray("conditions").getJSONObject(0).remove("conditions"); //NO I18N
			msc.getJSONArray("conditions").getJSONObject(0).put("conditions", json); //NO I18N
			
		}catch(Exception ex){
			
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		
		return msc;
	}

	public static TermsAggregationBuilder generateAllDevicesVisitsAggredateJson(){
		
		TermsAggregationBuilder grpbydeviceJson = null;
		try
		{
			grpbydeviceJson = AggregationBuilders.terms("group_by_"+ElasticSearchConstants.DEVICE).field(ElasticSearchConstants.DEVICE).size(ElasticSearchConstants.VISITOR_MAX_COUNT);  //NO I18N
			
			ArrayList<AggregationBuilder> aggrJson0 = generateAllVistorsAggregateJson();
			grpbydeviceJson.subAggregation(aggrJson0.get(0));
			grpbydeviceJson.subAggregation(aggrJson0.get(1));
			grpbydeviceJson.subAggregation(aggrJson0.get(2));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		return grpbydeviceJson;
	}

	public static ArrayList<AggregationBuilder> generateAllVistorsAggregateJson() {
		
		ArrayList<AggregationBuilder> cabs = new ArrayList<AggregationBuilder>();
		CardinalityAggregationBuilder aggrJson = null;
		try
		{
			CardinalityAggregationBuilder aggrJson0 = generateVistorAggregateJson();
			CardinalityAggregationBuilder uuidAggrJson = generateVisitorUUIDAggregateJson();
			
			int precisionThreshold = DynamicConfigurationConstants.ES_CARDINALITY_THRESHOLD_VALUE;
			String thresholdStr = DynamicConfigurationUtil.getDynamicPropertyValueByName(DynamicConfigurationConstants.ES_CARDINALITY_THRESHOLD);
			if(StringUtils.isNotEmpty(thresholdStr))
			{
				precisionThreshold = Integer.parseInt(thresholdStr);
			}
			
			aggrJson = AggregationBuilders.cardinality("total_visits").  // No I18N
					field(ElasticSearchConstants.UVID).
					precisionThreshold(precisionThreshold);
			
			cabs.add(aggrJson);
			cabs.add(aggrJson0);
			cabs.add(uuidAggrJson);

		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		return cabs;
	}

	public static BoolQueryBuilder generateSourceQueryJson(String portal, String reportType, String segmentType, Long expId, Long varId, Long startTime, Long endTime, String dynamicAttrLinkName, String[] values, String multisegmentCriteria,String heatmapRequiredCriterias,Boolean isheatmapenabled)
	{
		BoolQueryBuilder boolQuery =  null;
		try
		{
			if(reportType.equals(ReportConstants.SUMMARY))
			{
				boolQuery = ElasticSearchStatistics.generateSourceQueryJson(portal,expId,startTime,endTime,false,null,false,null,isheatmapenabled);
			}
			else if(reportType.equals(ReportConstants.SEGMENT))
			{
				boolQuery = ElasticSearchStatistics.generateSourceSegmentQueryJson(portal,expId, startTime, endTime, segmentType, dynamicAttrLinkName, values, false, null, null);
			} 
			else if(reportType.equals(ReportConstants.MULTISEGMENT))
			{
				boolQuery = ElasticSearchStatistics.generateSourceMultiSegmentQueryJson(portal,expId, startTime, endTime, multisegmentCriteria, false, null, null,isheatmapenabled);
			}
			
			if(varId!=null){
				
				MatchQueryBuilder varMatch = QueryBuilders.matchQuery(ElasticSearchConstants.VARIATIONID, varId);
				boolQuery.must().add(varMatch);
			}
			
			if(heatmapRequiredCriterias!=null){
				
				BoolQueryBuilder reqcriteria = ElasticSearchStatistics.generateMultiSegmentCriteria(heatmapRequiredCriterias);
				boolQuery.must().add(reqcriteria);
			}
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		return boolQuery;
	}
	 
	public static TermsAggregationBuilder generateHeatmapURLAggregateJson(){
		
		TermsAggregationBuilder urlJson = null;
		
		try
		{
			urlJson = AggregationBuilders.terms("group_by_"+ElasticSearchConstants.CURRENTURL).field(ElasticSearchConstants.CURRENTURL).size(ElasticSearchConstants.URLS_MAX_COUNT);  //NO I18N
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		return urlJson;
	}
	
	public static List<AggregationBuilder> generateHeatmapAggregateJson()
	{
		ArrayList<AggregationBuilder> aggrJsonlist = new ArrayList<AggregationBuilder>();
		try
		{
			CardinalityAggregationBuilder aggrJson0 = generateVistorAggregateJson();
			CardinalityAggregationBuilder uuidaggrJson = generateVisitorUUIDAggregateJson();
			
			TermsAggregationBuilder selectorJson = AggregationBuilders.terms("group_by_"+ElasticSearchConstants.SELECTOR).field(ElasticSearchConstants.SELECTOR).size(ElasticSearchConstants.VISITOR_MAX_COUNT);  //NO I18N
			SortBuilder<?> sortBuilder = SortBuilders.fieldSort(ElasticSearchConstants.TIME);
            sortBuilder.order(SortOrder.DESC);
			
            TopHitsAggregationBuilder displayTextJsonTopHits = AggregationBuilders.topHits(ElasticSearchConstants.DISPLAY_TEXT).sort(sortBuilder);
			TermsAggregationBuilder pointXJson = AggregationBuilders.terms("group_by_"+ElasticSearchConstants.POINT_X).field(ElasticSearchConstants.POINT_X).size(ElasticSearchConstants.VISITOR_MAX_COUNT);  //NO I18N
			TermsAggregationBuilder pointYJson = AggregationBuilders.terms("group_by_"+ElasticSearchConstants.POINT_Y).field(ElasticSearchConstants.POINT_Y).size(ElasticSearchConstants.VISITOR_MAX_COUNT);  //NO I18N
				
			SumAggregationBuilder sumJson = AggregationBuilders.sum("sum_"+ElasticSearchConstants.CLICKS).field(ElasticSearchConstants.CLICKS);  //NO I18N
			SumAggregationBuilder sumJson1 = AggregationBuilders.sum("total_"+ElasticSearchConstants.CLICKS).field(ElasticSearchConstants.CLICKS);  //NO I18N
		
			TermsAggregationBuilder selectorJson1 = AggregationBuilders.terms("group_by_"+ElasticSearchConstants.SELECTOR+"_1").field(ElasticSearchConstants.SELECTOR).size(ElasticSearchConstants.VISITOR_MAX_COUNT).order(Terms.Order.aggregation("total_"+ElasticSearchConstants.CLICKS, false));  //NO I18N
			
			pointYJson.subAggregation(sumJson);
			pointXJson.subAggregation(pointYJson);
			selectorJson.subAggregation(pointXJson);

			selectorJson1.subAggregation(sumJson1); // instaead of sumjson2
			selectorJson1.subAggregation(displayTextJsonTopHits);
			
			aggrJsonlist.add(aggrJson0);
			aggrJsonlist.add(uuidaggrJson);
			aggrJsonlist.add(selectorJson);
			aggrJsonlist.add(sumJson1);
			aggrJsonlist.add(selectorJson1);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		return aggrJsonlist;
	}
	
	public static CardinalityAggregationBuilder generateVistorAggregateJson()
	{
		CardinalityAggregationBuilder aggr = null
				;
		try
		{
			int precisionThreshold = DynamicConfigurationConstants.ES_CARDINALITY_THRESHOLD_VALUE;
			String thresholdStr = DynamicConfigurationUtil.getDynamicPropertyValueByName(DynamicConfigurationConstants.ES_CARDINALITY_THRESHOLD);
			if(StringUtils.isNotEmpty(thresholdStr))
			{
				precisionThreshold = Integer.parseInt(thresholdStr);
			}
			
			aggr = AggregationBuilders.cardinality("distinct_visitors").  // No I18N
					field(ElasticSearchConstants.VISITORID).
					precisionThreshold(precisionThreshold);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
		return aggr;
	}
	
	public static CardinalityAggregationBuilder generateVisitorUUIDAggregateJson()
	{
		CardinalityAggregationBuilder aggr = null
				;
		try
		{
			int precisionThreshold = DynamicConfigurationConstants.ES_CARDINALITY_THRESHOLD_VALUE;
			String thresholdStr = DynamicConfigurationUtil.getDynamicPropertyValueByName(DynamicConfigurationConstants.ES_CARDINALITY_THRESHOLD);
			if(StringUtils.isNotEmpty(thresholdStr))
			{
				precisionThreshold = Integer.parseInt(thresholdStr);
			}
			
			aggr = AggregationBuilders.cardinality("distinct_uuid_visitors").  // No I18N
					field(ElasticSearchConstants.UUID).
					precisionThreshold(precisionThreshold);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
		return aggr;
	}
	
	public static Heatmap readHeatmapResponseData(SearchResponse response,SearchResponse response1,SearchResponse response2)
	{
		Heatmap heatmap = new Heatmap();
		HashMap<String, ArrayList<ArrayList<Double>>> heatmapSelectorsDeatils = new HashMap<String,ArrayList<ArrayList<Double>>>();
		ArrayList<HashMap<String,Object>> topclicks = new ArrayList<HashMap<String,Object>>();
		ArrayList<HashMap<String,Object>> deviceVisits = new ArrayList<HashMap<String,Object>>();
		
		double totalclicks = 0;
		double eng_per = 0;
		double clicks_per_visit = 0;
		
		try
		{
			Aggregations aggrResponse = response.getAggregations();
			Aggregations aggrResponse1 = response2.getAggregations();
			
			
			InternalCardinality cardinality = aggrResponse.get("distinct_visitors");
			long engvisitors = cardinality.getValue();
			long engUuidVisitors = getUUIDVisitorsCount(aggrResponse);
			
			long totalEngagedVisitors = engvisitors + engUuidVisitors;
			
			heatmap.setEngagedVisitorCount(totalEngagedVisitors);
			
			Sum sum1 = aggrResponse.get("total_clicks");
			totalclicks = sum1.getValue();
			heatmap.setTotalClicks(totalclicks);
			
			InternalCardinality cardinality1 = aggrResponse1.get("distinct_visitors");
			long visitors = cardinality1.getValue();
			long uuidVisitors = getUUIDVisitorsCount(aggrResponse1);
			long totalVisitorsCount = visitors + uuidVisitors;
			heatmap.setVisitorsCount(totalVisitorsCount);
			
			InternalCardinality cardinality2 = aggrResponse1.get("total_visits");
			Long totalvisits = cardinality2.getValue();
			heatmap.setVisitsCount(totalvisits);
			
			if(totalVisitorsCount > 0){
				eng_per = ((double)totalEngagedVisitors/(double)totalVisitorsCount)*100;
				eng_per = (double)Math.round((double)eng_per*100)/ 100;
			}
			
			heatmap.setEngagedVisitorPercentage(eng_per);
			if(totalvisits > 0){
				clicks_per_visit = totalclicks/totalvisits;
			}
			
			Terms terms = aggrResponse.get("group_by_"+ElasticSearchConstants.SELECTOR);
			List<? extends Bucket> buckets = terms.getBuckets();
			for(Bucket bucketSelector:buckets)
			{
				ArrayList<ArrayList<Double>> s_points = new ArrayList<ArrayList<Double>>();
				
				String selector = (String)bucketSelector.getKeyAsString();
				Aggregations aggrPointX = bucketSelector.getAggregations();
				Terms termsX = aggrPointX.get("group_by_"+ElasticSearchConstants.POINT_X);
				List<? extends Bucket> bucketsX = termsX.getBuckets();
				for(Bucket bucketX : bucketsX)
				{	
					long point_x =  (long) bucketX.getKey();
					
					Aggregations aggrPointY = bucketX.getAggregations();
					Terms termsY = aggrPointY.get("group_by_"+ElasticSearchConstants.POINT_Y);
					List<? extends Bucket> bucketsY = termsY.getBuckets();
					
					for(Bucket bucketY : bucketsY)
					{
						ArrayList<Double> points = new ArrayList<Double>();
						long point_y = (long) bucketY.getKey();
				
						Aggregations aggResponse = bucketY.getAggregations();
						Sum sum = aggResponse.get("sum_"+ElasticSearchConstants.CLICKS);
						
						double clicks = (double) sum.getValue();
						
						points.add((double)point_x/1000);
						points.add((double)point_y/1000);
						points.add(clicks);
						s_points.add(points);
					}
					
				}
				
				heatmapSelectorsDeatils.put(selector,s_points);
			}
			
			Terms terms1 = aggrResponse.get("group_by_"+ElasticSearchConstants.SELECTOR+"_1");
			List<? extends Bucket> buckets1 = terms1.getBuckets();
			for(Bucket bucketSelector : buckets1)
			{
				HashMap<String,Object> top_click = new HashMap<String,Object>();
				Aggregations aggr = bucketSelector.getAggregations();
				String selector = (String)bucketSelector.getKeyAsString();
				Sum sum2 = aggr.get("total_clicks");
				
				TopHits topHits = aggr.get(ElasticSearchConstants.DISPLAY_TEXT);
				SearchHit hit = topHits.getHits().getHits()[0];
				
				top_click.put(ElasticSearchConstants.SELECTOR,selector);
				top_click.put(ElasticSearchConstants.CLICKS, sum2.getValue());
				
				String displayText = "";
				if(hit.getSource().get(ElasticSearchConstants.DISPLAY_TEXT) != null)
				{
					displayText = hit.getSource().get(ElasticSearchConstants.DISPLAY_TEXT).toString();
				}
				
				top_click.put(ElasticSearchConstants.DISPLAY_TEXT,displayText);
				Double contribution = (sum2.getValue() / totalclicks) * 100;
				top_click.put("percentage_contribution",(double)Math.round((double)contribution*100)/ 100);
				
				topclicks.add(top_click);
			}
			
			deviceVisits = getAllDeviceVisits(response1);
			
			heatmap.setDeviceVisits(deviceVisits);
			heatmap.setHeatmapPoints(heatmapSelectorsDeatils);
			heatmap.setClicksPerVisit((double)Math.round((double)clicks_per_visit*10)/ 10);
			heatmap.setTopclicks(topclicks);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			heatmap = null;
		}
		return heatmap;
	}
	
	public static Long getUUIDVisitorsCount(Aggregations aggr) {
		InternalCardinality Cardinality = aggr.get("distinct_uuid_visitors");
		long visitorsCount = Cardinality.getValue();
		return visitorsCount;
	}
	
	public static ArrayList<HashMap<String, Object>> getAllDeviceVisits(SearchResponse response) {
		
		ArrayList<HashMap<String,Object>> deviceVisits = new ArrayList<HashMap<String,Object>>();
		
		try{
			
			List<String> devices = Arrays.asList("DESKTOP","MOBILE","TABLET");  //NO I18N
			
			Aggregations aggrResponse2 = response.getAggregations();
			Terms terms2 = aggrResponse2.get("group_by_"+ElasticSearchConstants.DEVICE);
			List<? extends Bucket> buckets2 = terms2.getBuckets();
			for(Bucket bucketSelector : buckets2)
			{
				HashMap<String,Object> deviceV = new HashMap<String,Object>();
				Aggregations aggr = bucketSelector.getAggregations();
				String device = (String)bucketSelector.getKeyAsString();
				
				InternalCardinality cardinality3 = aggr.get("distinct_visitors");
				long visitors2 = cardinality3.getValue();
				long uuidVisitors = getUUIDVisitorsCount(aggr);
				long totalVisitors = visitors2 + uuidVisitors;
				InternalCardinality cardinality4 = aggr.get("total_visits");
				Long totalvisits2 = cardinality4.getValue();
					
				if(devices.contains(device)){
					
					deviceV.put(HeatmapConstants.DEVICE, device);
					deviceV.put(HeatmapConstants.UNIQUE_VISITOR_COUNT,totalVisitors); 
					deviceV.put(HeatmapConstants.TOTAL_VISITOR_COUNT,totalvisits2);
					
					deviceVisits.add(deviceV);
				}
			}
			
			//code for devices not included 
			for(int i=0;i<devices.size();i++){
				
				boolean exisits = false;
				for(HashMap<String, Object> device : deviceVisits){
					if(devices.get(i).equals(device.get(HeatmapConstants.DEVICE))){ 
						exisits = true;
						break;
					}
				}
				if(exisits == false){
					
					HashMap<String,Object> deviceV = new HashMap<String,Object>();
					deviceV.put(HeatmapConstants.DEVICE, devices.get(i));
					deviceV.put(HeatmapConstants.UNIQUE_VISITOR_COUNT,0);
					deviceV.put(HeatmapConstants.TOTAL_VISITOR_COUNT,0);
					
					deviceVisits.add(deviceV);
				}
			}
			
		}catch(Exception ex)
		{
				LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		
		return deviceVisits;
	}
	
	public static Heatmap getExperiemntURLCollection(String experimentLinkname){
	
		BoolQueryBuilder filterJson = null;
		BoolQueryBuilder filterJson1 = null;
		TermsAggregationBuilder aggrsJson = null;
		TermsAggregationBuilder aggrsJson1 = null;
		List<AggregationBuilder> aggrsJson2 = null;
		SumAggregationBuilder sumJson1 = null;
		HashMap<String,HashMap<String,Object>> expurldetails = null;
		Heatmap heatmap = new Heatmap();
		Boolean isheatmapenabled = false;
		try{
	
			Experiment exp  = Experiment.getExperimentByLinkname(experimentLinkname);
			
			if(exp == null){
				heatmap.setSuccess(Boolean.FALSE);
				return heatmap;
			}
			
			Long experimentId = exp.getExperimentId();
			Long variationId = null;
			if(!ExperimentType.HEATMAP.getTypeNumber().equals(exp.getExperimentType())){
				isheatmapenabled = true;
			}
			
			if(ExperimentType.SPLITURL.getTypeNumber().equals(exp.getExperimentType())){
				variationId = Variation.getOriginalVariationId(experimentId);
			}			
			
			String portal = ZABUtil.getPortaldomain();//IAMUtil.getCurrentServiceOrg().getDomains().get(0).getDomain();
			String index = ElasticSearchUtil.getIndexByPortal(portal);
			int size = 0;
			
			filterJson = generateSourceQueryJson(portal,ReportConstants.SUMMARY,null, experimentId , variationId ,null,null,null,null,null,null,null);
			filterJson1 = generateSourceQueryJson(portal,ReportConstants.SUMMARY,null, experimentId , variationId ,null,null,null,null,null,null,isheatmapenabled);
			
			aggrsJson  =  generateHeatmapURLAggregateJson();
			aggrsJson1 = generateHeatmapURLAggregateJson();
			aggrsJson2 = generateAllVistorsAggregateJson();
			
			sumJson1 = AggregationBuilders.sum("total_"+ElasticSearchConstants.CLICKS).field(ElasticSearchConstants.CLICKS); //NO I18N
			aggrsJson.subAggregation(aggrsJson2.get(0));
			aggrsJson.subAggregation(aggrsJson2.get(1));
			aggrsJson.subAggregation(aggrsJson2.get(2));

			aggrsJson.order(Terms.Order.aggregation("total_visits", false)); //NO I18N
			aggrsJson1.subAggregation(sumJson1);
			
            SearchResponse response1 = ElasticSearchUtil.getData(index,ElasticSearchConstants.HEATMAP_RAW_TYPE, size, filterJson, aggrsJson1);
			SearchResponse response = ElasticSearchUtil.getData(index,ElasticSearchConstants.VISITOR_RAW_TYPE, size, filterJson1, aggrsJson);

			
			expurldetails = readHeatmapURLResponseDataForDetails(response,response1);
			heatmap.setUrldetails(expurldetails);
			heatmap.setExperimentLinkname(experimentLinkname);
			heatmap.setExperimentId(experimentId);
			heatmap.setSuccess(Boolean.TRUE);
			
		}catch(Exception ex ){
			
			heatmap.setSuccess(Boolean.TRUE);
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}	
		
		return heatmap;
	}
	
	private static HashMap<String,HashMap<String,Object>> readHeatmapURLResponseDataForDetails(SearchResponse response, SearchResponse response1){
		
		LinkedHashMap<String,HashMap<String,Object>> urldetails = new LinkedHashMap<String,HashMap<String,Object>>();
		double totalclicks = 0;
		double clicks_per_visit = 0;
		
		try{
			
			Aggregations aggrResponse = response.getAggregations();
			Aggregations aggrResponse2 = response1.getAggregations();
			
			Terms terms = aggrResponse.get("group_by_"+ElasticSearchConstants.CURRENTURL);
			Terms terms1 = aggrResponse2.get("group_by_"+ElasticSearchConstants.CURRENTURL);
			
			List<? extends Bucket> buckets = terms.getBuckets();
			for(Bucket bucketSelector:buckets)
			{
				HashMap<String, Object> urld = new HashMap<String, Object>();
				String url = (String)bucketSelector.getKeyAsString();
				
				Aggregations aggrResponse1 = bucketSelector.getAggregations();
				InternalCardinality cardinality1 = aggrResponse1.get("distinct_visitors");
				long visitors = cardinality1.getValue();
				long uuidVisitors = getUUIDVisitorsCount(aggrResponse1);
				long totalVisitorsCount = visitors + uuidVisitors;
				urld.put(HeatmapConstants.VISITORS_COUNT.toLowerCase(),totalVisitorsCount);
				InternalCardinality cardinality2 = aggrResponse1.get("total_visits");
				long totalvisits = cardinality2.getValue();
				urld.put(HeatmapConstants.VISITS_COUNT.toLowerCase(),totalvisits);
				
				urldetails.put(url,urld);
			}
			
			List<? extends Bucket> buckets1 = terms1.getBuckets();
			for(Bucket bucketSelector:buckets1)
			{
				Aggregations aggrResponse1 = bucketSelector.getAggregations();
				String url = (String)bucketSelector.getKeyAsString();
				
				if(urldetails.containsKey(url)){
					
					HashMap<String,Object> urlobj = urldetails.get(url);
					long totalvisits = (long)urlobj.get(HeatmapConstants.VISITS_COUNT.toLowerCase());
					Sum sum = aggrResponse1.get("total_clicks");
					totalclicks = sum.getValue();
					if(totalvisits > 0){
						clicks_per_visit = totalclicks/totalvisits;
					}
					urldetails.get(url).put(HeatmapConstants.CLICKS_PER_VISIT.toLowerCase(),(double)Math.round((double)clicks_per_visit*10)/ 10);
				}
			}			
		}catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		
		return urldetails;
			
	}
    
	private static Heatmap getHeatmapExperimentCardDetails(Long experimentId){
		
		ArrayList<AggregationBuilder> aggrsJson = null;
		BoolQueryBuilder filterJson =  null;
		Heatmap heatmap = null;
		
		try
		{
			String portal = ZABUtil.getPortaldomain();//IAMUtil.getCurrentServiceOrg().getDomains().get(0).getDomain();
			String index = ElasticSearchUtil.getIndexByPortal(portal);
			int sum = 0;
			
			filterJson = generateSourceQueryJson(portal, ReportConstants.SUMMARY, null, experimentId, null, null, null, null, null, null, null, null);
			aggrsJson  =  generateAllVistorsAggregateJson();
			
			SumAggregationBuilder sumJson1 = AggregationBuilders.sum("total_"+ElasticSearchConstants.CLICKS).field(ElasticSearchConstants.CLICKS);
					
			SearchResponse response = ElasticSearchUtil.getData(index, ElasticSearchConstants.HEATMAP_RAW_TYPE, sum, filterJson, sumJson1);			
			SearchResponse response1 = ElasticSearchUtil.getData(index, ElasticSearchConstants.VISITOR_RAW_TYPE, sum, filterJson, aggrsJson);
			
			heatmap = readHeatmapResponseDataForDetails(response,response1);
			heatmap.setSuccess(Boolean.TRUE);
		}
		catch(Exception ex)
		{
			heatmap = new Heatmap();
			heatmap.setSuccess(Boolean.FALSE);
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		
		return heatmap;
	}

	private static Heatmap readHeatmapResponseDataForDetails(SearchResponse response, SearchResponse response1) {
		
		Heatmap heatmap = new Heatmap();
		double clicks_per_visit = 0;
	
		try{
		
			Aggregations aggrResponse = response.getAggregations();
			Aggregations aggrResponse1 = response1.getAggregations();
			
			Sum sum1 = aggrResponse.get("total_clicks");
			double totalclicks = sum1.getValue();
			heatmap.setTotalClicks(totalclicks);
			
			InternalCardinality cardinality1 = aggrResponse1.get("distinct_visitors");
			long visitorsCount = cardinality1.getValue();
			long uuidVisitorsCount = getUUIDVisitorsCount(aggrResponse1);
			long totalVisitorsCount = visitorsCount + uuidVisitorsCount;
			
			heatmap.setVisitorsCount(totalVisitorsCount);
			InternalCardinality cardinality2 = aggrResponse1.get("total_visits");
			Long totalvisits = cardinality2.getValue();
			heatmap.setVisitsCount(totalvisits);
			
			if(totalvisits>0){
				clicks_per_visit = totalclicks/totalvisits;
			}
			
			heatmap.setClicksPerVisit((double)Math.round((double)clicks_per_visit*100)/ 100);
			
		}catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			heatmap = null;
		}
		
		return heatmap;
	}

	public static void setHeatmapExperimentDetailsFromES(HeatmapExperiment experiment) {
		// TODO Auto-generated method stub
		Heatmap heatmap = null;
		try{
			
			Long experimentId = experiment.getExperimentId();		
			heatmap = getHeatmapExperimentCardDetails(experimentId);
	
			experiment.setVisitsCount(heatmap.getVisitsCount());
			experiment.setTotalClicks(heatmap.getTotalClicks());
			experiment.setClicksPerVisit(heatmap.getClicksPerVisit());
		}catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
	}
}
