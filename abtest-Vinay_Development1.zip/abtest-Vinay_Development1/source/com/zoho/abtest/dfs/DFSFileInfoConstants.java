//$Id$
package com.zoho.abtest.dfs;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.zoho.abtest.DFS_FILE_INFO;
import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.ZABConstants;

public class DFSFileInfoConstants {
	
	public static final String API_MODULE = "dfsfileinfo"; //NO I18N
	
	public static final String DFS_FILE_BLOCKID = "FILE_BLOCKID"; //NO I18N
	public static final String DFS_FILE_PATH = "FILE_PATH"; //NO I18N
	public static final String TIME = "TIME"; //NO I18N
	
	public static final List<Constants> DFS_FILE_INFO_TABLE;
	static{
		ArrayList<Constants> list = new ArrayList<Constants>();
		list.add(new Constants(DFS_FILE_BLOCKID,DFS_FILE_INFO.FILE_BLOCKID,ZABConstants.STRING,Boolean.FALSE));
		list.add(new Constants(DFS_FILE_PATH,DFS_FILE_INFO.FILE_PATH,ZABConstants.STRING,Boolean.FALSE));
		list.add(new Constants(TIME,DFS_FILE_INFO.TIME,ZABConstants.LONG,Boolean.FALSE));
		DFS_FILE_INFO_TABLE = (List<Constants>) Collections.unmodifiableList(list);
	}
}
