//$Id$
package com.zoho.abtest.dfs;

import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.DFS_FILE_INFO;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.utility.ZABUtil;

public class DFSFileInfo extends ZABModel {
	
	/**
	 * 
	 */
	private static final Logger LOGGER = Logger.getLogger(DFSFileInfo.class.getName());
	
	private static final long serialVersionUID = 1L;
	private String blockId;
	private String filepath;
	private Long time;
	
	public String getBlockId() {
		return blockId;
	}
	public void setBlockId(String blockId) {
		this.blockId = blockId;
	}
	public String getFilepath() {
		return filepath;
	}
	public void setFilepath(String filepath) {
		this.filepath = filepath;
	}
	public Long getTime() {
		return time;
	}
	public void setTime(Long time) {
		this.time = time;
	}

	public static DFSFileInfo getDFSFileInfoFromFilepath(String filepath) throws Exception{
		
		DFSFileInfo fileinfo = null;
		Criteria c = new Criteria(new Column(DFS_FILE_INFO.TABLE, DFS_FILE_INFO.FILE_PATH), filepath, QueryConstants.EQUAL);
		DataObject dobj = getRow(DFS_FILE_INFO.TABLE, c);
		if(dobj.containsTable(DFS_FILE_INFO.TABLE)) {
			fileinfo = new DFSFileInfo();
			Iterator it = dobj.getRows(DFS_FILE_INFO.TABLE);
			while(it.hasNext()) {
				Row row = (Row)it.next();
				fileinfo.setBlockId((String)row.get("FILE_BLOCKID"));
				fileinfo.setFilepath((String)row.get("FILE_PATH"));
				fileinfo.setTime((Long)row.get("TIME"));
			}
		}
		return fileinfo;
	}
	
	public static void addDFSFileInfo(String blockId,String filepath){
	
		try{
			
			HashMap<String,String> dfshm = new HashMap<String, String>();
			dfshm.put(DFSFileInfoConstants.DFS_FILE_BLOCKID,blockId);
			dfshm.put(DFSFileInfoConstants.DFS_FILE_PATH,filepath);
			dfshm.put(DFSFileInfoConstants.TIME,ZABUtil.getCurrentTimeInMilliSeconds().toString());
		
			createRow(DFSFileInfoConstants.DFS_FILE_INFO_TABLE, DFS_FILE_INFO.TABLE, dfshm);
			LOGGER.log(Level.INFO, "[DFS_FILE_INFO] INFO STORED IN DATABSE : ",dfshm);
			
		}catch(Exception ex){
			
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		
	}
}
