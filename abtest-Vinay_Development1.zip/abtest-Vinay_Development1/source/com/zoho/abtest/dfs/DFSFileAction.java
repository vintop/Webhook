//$Id$
package com.zoho.abtest.dfs;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;

import com.adventnet.iam.IAMUtil;
import com.opensymphony.xwork2.ActionSupport;
import com.zoho.abtest.report.ReportRawDataAction;
import com.zoho.abtest.utility.ZABUtil;

public class DFSFileAction extends ActionSupport implements ServletResponseAware, ServletRequestAware{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(ReportRawDataAction.class.getName());
	
	private HttpServletRequest request;
	private HttpServletResponse response;
	private String filename;

	public void setServletRequest(HttpServletRequest arg0) {
		// TODO Auto-generated method stub
		request = arg0;
	}

	@Override
	public void setServletResponse(HttpServletResponse arg0) {
		// TODO Auto-generated method stub
		response = arg0;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	private String getPortalName(){
		
		String portalName = null;
		if(IAMUtil.getCurrentServiceOrg() != null)
		{
			portalName = IAMUtil.getCurrentServiceOrg().getDomains().get(0).getDomain();
		}
		else
		{
			portalName = ZABUtil.getPortaldomain();
		}
		
		return portalName;
	}
	
	public void getThumbnailFromDFS(){
		
		DFSFileInfo fileinfo = null;
		InputStream in = null;
		OutputStream out = null;
		
		try{
			
			filename = filename + ".png"; //NO I18N
			fileinfo = DFSFileInfo.getDFSFileInfoFromFilepath(filename);
			if(fileinfo !=null ){
				
				String portalName = getPortalName();
				byte[] imageInBytes = DFS.retrieveFromDFS(fileinfo.getBlockId(), fileinfo.getFilepath(), portalName);
				int IMG_WIDTH = 640;
			    int IMG_HEIGHT = 480;
				
				in = new ByteArrayInputStream(imageInBytes);
				BufferedImage bi = ImageIO.read(in);
				
				BufferedImage tag= new BufferedImage(IMG_WIDTH,IMG_HEIGHT,BufferedImage.TYPE_INT_RGB);
				tag.getGraphics().drawImage(bi.getScaledInstance(IMG_WIDTH, IMG_HEIGHT, Image.SCALE_SMOOTH), 0, 0, null);
				
				
				response.setContentType("image/jpg");//NO I18N
				out = response.getOutputStream();
				ImageIO.write(tag,"jpg",out); //NO I18N
			}
			
		}catch(Exception ex){
			
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
		}finally{
				
			try {
					 if(in!=null){
						in.close();
					 }
					 if(out!=null){
						out.close();
					 }
				} catch (IOException ex) {
					
					LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
				}
		}	
	}
}
