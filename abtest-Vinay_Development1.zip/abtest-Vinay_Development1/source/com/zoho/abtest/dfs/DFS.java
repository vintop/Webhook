//$Id$
package com.zoho.abtest.dfs;

import java.io.*;

import com.adventnet.dfs.*;
import com.zoho.abtest.utility.ApplicationProperty;
import com.zoho.ear.common.util.EARException;
import com.zoho.ear.fileencryptagent.FileEncryptAgent;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.io.IOUtils;


public class DFS
{
	private static final Logger LOGGER = Logger.getLogger(DFS.class.getName());
	
    private final static String SERVICENAME = ApplicationProperty.getString("abtest.zoho.dfs.servicename");//No I18N
    
    private static final String EAR_KEY = ApplicationProperty.getString("com.zoho.abtest.ear.key");//No I18N
	
    private static DFSClient getDFSClient(String portnalName) throws DFSException 
    {	  	
    	LOGGER.log(Level.INFO, "[GET_DFS_CLIENT] PORTALNAME : "+portnalName);
    	return DFSClientPool.getDFSClient(portnalName, SERVICENAME);
    }

    private static void closeDFSClient(DFSClient dfs) 
    {
        if (dfs != null) 
        {
            DFSClientPool.returnDFSClient(dfs);
        }
    }
       
    public static String storeInDFS(byte[] data, String filePath, String portalName) throws IOException, DFSException
    {
        OutputStream out = null;
        DFSClient dfsClient = null;
        String blockId = null;
        try 
        {
            dfsClient = getDFSClient(portalName);
            out = dfsClient.write(filePath);
            out.write(data);
            out.close();
            blockId = dfsClient.getBlockId();
            LOGGER.log(Level.INFO, "[DFS_STORE] FILE "+filePath+" STORED IN DFS WITH BLOCK_ID "+blockId);
        }
        finally 
        {
            closeDFSClient(dfsClient);
            
            if(out!=null) {
            	try {
            		out.close();					
				} catch (Exception e) {
					LOGGER.log(Level.SEVERE, "Exception occured", e);
				}
            }
        }
        return blockId;
    }
    
    public static String storeInDFS(InputStream is, String filePath, String portalName) throws IOException, DFSException
    {
        OutputStream out = null;
        DFSClient dfsClient = null;
        String blockId = null;
        try 
        {
            dfsClient = getDFSClient(portalName);
            out = dfsClient.write(filePath);
            IOUtils.copy(is, out);
            out.close();
            blockId = dfsClient.getBlockId();
            LOGGER.log(Level.INFO, "[DFS_STORE] FILE "+filePath+" STORED IN DFS WITH BLOCK_ID "+blockId);
        }
        finally 
        {
            closeDFSClient(dfsClient);
            
            if(out!=null) {
            	try {
            		out.close();					
				} catch (Exception e) {
					LOGGER.log(Level.SEVERE, "Exception occured", e);
				}
            }
            
            if(is!=null) {
            	try {
            		is.close();					
				} catch (Exception e) {
					LOGGER.log(Level.SEVERE, "Exception occured", e);
				}
            }
        }
        return blockId;
    }
    
    public static String storeInDFSWithEncryption(byte[] data, String filePath, Long zsoid) throws IOException, DFSException, EARException
    {
        OutputStream out = null;
        OutputStream encout = null;
        DFSClient dfsClient = null;
        String blockId = null;
        try 
        {
            dfsClient = getDFSClient(zsoid.toString());
            out = dfsClient.write(filePath);
            encout = FileEncryptAgent.getInstance().getEncryptOutputStream(zsoid, out, Boolean.TRUE, EAR_KEY);
            encout.write(data);
            encout.close();
            blockId = dfsClient.getBlockId();
            LOGGER.log(Level.INFO, "[DFS_STORE] FILE "+filePath+" STORED IN DFS WITH BLOCK_ID "+blockId);
        }
        finally 
        {
            closeDFSClient(dfsClient);
            
            if(out!=null) {
            	try {
            		out.close();					
				} catch (Exception e) {
					LOGGER.log(Level.SEVERE, "Exception occured", e);
				}
            }
            
            if(encout!=null) {
            	try {
            		encout.close();					
				} catch (Exception e) {
					LOGGER.log(Level.SEVERE, "Exception occured", e);
				}
            }
        }
        return blockId;
    }
    
    public static void storeInDFS(byte[] data, String filePath, String portalName, String blockId) throws IOException, DFSException
    {
        OutputStream out = null;
        DFSClient dfsClient = null;
        try 
        {
            dfsClient = getDFSClient(portalName);
            out = dfsClient.writeFileForBlock(filePath, blockId,true);
            out.write(data);
        } 
        finally 
        {
        	if(out!=null) { 
        		try {					
        			out.close();
				} catch (Exception e) {
					LOGGER.log(Level.SEVERE, "Exception occured", e);
				}
        	}
            closeDFSClient(dfsClient);
        }
    }
    
    public static boolean deleteFromDFS(String blockId, String filePath, String portalName) throws DFSException
    { 
        DFSClient dfsClient = null;
        boolean isDeleted = false;
        try 
        {
            dfsClient = getDFSClient(portalName);
            if(dfsClient.exists(filePath, blockId)){
                isDeleted = dfsClient.delete(filePath, blockId);
            }
        } 
        finally 
        {
            closeDFSClient(dfsClient);
        }
        return isDeleted;
    }
    
    public static boolean deleteDirectoryFromDFS(String filePath, String portalName) throws DFSException
    { 
        DFSClient dfsClient = null;
        boolean isDeleted = false;
        try 
        {
            dfsClient = getDFSClient(portalName);
            if(dfsClient.directoryExist(filePath)){
                isDeleted = dfsClient.deleteDirectory(filePath);
            }
        } 
        finally 
        {
            closeDFSClient(dfsClient);
        }
        return isDeleted;
    }
    
    public static void deleteFromDFS(String blockId, List<String> filePath, String portalName) throws DFSException
    {
        DFSClient dfsClient = null;
        try 
        {
            dfsClient = getDFSClient(portalName);
            dfsClient.delete(filePath, blockId);
        } 
        finally 
        {
            closeDFSClient(dfsClient);
        }
    }

    public static byte[] retrieveFromDFS(String blockId, String filePath, String portalName) throws DFSException, IOException
    {
        DFSClient dfsClient = null;
        InputStream is = null;
        try 
        {
        	LOGGER.log(Level.INFO, "[DFS_RETREIVE] FILE "+filePath+" BEING RETREIVED USING BLOCK_ID "+blockId);
            dfsClient = getDFSClient(portalName);
            is = dfsClient.read(filePath, blockId, Boolean.TRUE);
            byte[] data = IOUtils.toByteArray(is);
            return data;
        } 
        finally 
        {
        	if(is!=null){
        		try {
        			is.close();					
				} catch (Exception e) {
					LOGGER.log(Level.SEVERE, "Exception occured", e);
				}
        	}
        	
            closeDFSClient(dfsClient);
        }
    }
    
    public static byte[] retrieveDecryptedFromDFS(String blockId, String filePath, Long zsoid) throws DFSException, IOException, EARException
    {
        DFSClient dfsClient = null;
        InputStream is = null;
        InputStream isdecrypted = null;
        try 
        {
        	LOGGER.log(Level.INFO, "[DFS_RETREIVE] FILE "+filePath+" BEING RETREIVED USING BLOCK_ID "+blockId);
            dfsClient = getDFSClient(zsoid.toString());
            is = dfsClient.read(filePath, blockId, Boolean.TRUE);
            isdecrypted = FileEncryptAgent.getInstance().getDecryptInputStream(zsoid, is, true, EAR_KEY);
            byte[] data = IOUtils.toByteArray(isdecrypted);
            return data;
        } 
        finally 
        {
        	if(is!=null){
        		try {
        			is.close();					
				} catch (Exception e) {
					LOGGER.log(Level.SEVERE, "Exception occured", e);
				}
        	}
        	
        	if(isdecrypted!=null){
        		try {
        			isdecrypted.close();					
				} catch (Exception e) {
					LOGGER.log(Level.SEVERE, "Exception occured", e);
				}
        	}
        	
            closeDFSClient(dfsClient);
        }
    }
    
    public static void copyFile(String srcFilePath, String srcBlockId, String destFilePath, String portalName) throws DFSException, IOException
    {
        DFSClient dfsClient = null;
        InputStream is = null;
        OutputStream out = null;
        try 
        {
            dfsClient = getDFSClient(portalName);
            is = dfsClient.read(srcFilePath, srcBlockId, Boolean.TRUE);
            byte[] data = IOUtils.toByteArray(is);
            out = dfsClient.writeFileForBlock(destFilePath, srcBlockId);
            out.write(data);
        } 
        finally 
        {
        	if(out!=null) {   
        		try {					
        			out.close();
				} catch (Exception e) {
					LOGGER.log(Level.SEVERE, "Exception occured", e);
				}
        	}
        	
        	if(is!=null) {
        		try {					
        			is.close();
				} catch (Exception e) {
					LOGGER.log(Level.SEVERE, "Exception occured", e);
				}
        	}
        	
            closeDFSClient(dfsClient);
        }
    }
}

