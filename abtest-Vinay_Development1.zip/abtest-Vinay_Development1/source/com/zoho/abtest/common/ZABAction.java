//$Id$
package com.zoho.abtest.common;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.struts2.util.ServletContextAware;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.adventnet.iam.IAMUtil;
import com.adventnet.iam.security.SecurityRequestWrapper;
import com.adventnet.iam.xss.IAMEncoder;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.request.JSONRequestParser;
import com.zoho.abtest.request.RequestParser;
import com.zoho.abtest.request.XMLRequestParser;
import com.zoho.abtest.response.JSONResponse;
import com.zoho.abtest.response.ResponseProvider;
import com.zoho.abtest.response.XMLResponse;
import com.zoho.abtest.utility.ZABUtil;

public class ZABAction extends ActionSupport implements ServletContextAware{
	/**
	 * 
	 */
	private ServletContext context;
	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = Logger.getLogger(ZABAction.class.getName());
	
	public static final String JSON_FORMAT = "application/json; charset=UTF-8"; //No I18N
	
	private static final String XML_FORMAT = "application/xml; charset=UTF-8"; //No I18N
	
	private static Logger logger = Logger.getLogger(ZABAction.class.getName());
	
	@Override
	public void setServletContext(ServletContext context) {
		this.context = context;
	}
	
	public static enum HTTPMethod {
	    GET, PUT, POST, DELETE;
	} 
		public static ArrayList<HashMap<String,String>> parseJSON (JSONArray array) throws JSONException
		{
		ArrayList<HashMap<String,String>> arrayHashMap = new ArrayList<HashMap<String,String>>();			
			for(int i=0;i<array.length();i++)
			{
			 	JSONObject jObject = array.getJSONObject(i);
				arrayHashMap.add(parseJSON(jObject));
			}		
		return arrayHashMap;
	}
		
	public static HashMap<String,String> parseJSON (JSONObject jObject) throws JSONException
	{
	
		 	HashMap<String, String> map = new HashMap<String, String>();
		 	Iterator<?> keys = jObject.keys();
			while( keys.hasNext() ){
				String key = (String) keys.next();
				String value = jObject.getString(key); 
					map.put(key, value);
			}				
			return map;
	}
	public static JSONArray parseModuleInputArray(String inputString, String moduleName) throws JSONException
	{
		JSONObject jb = new JSONObject(inputString);
		if(!jb.has(moduleName))
		{
			throw new JSONException(ZABAction.getMessage(ZABConstants.INVALID_INPUT_FORMAT));
		}
		return jb.getJSONArray(moduleName);
	}
	
	public static JSONObject parseModuleInputObject(String inputString, String moduleName) throws JSONException
	{
		JSONObject jb = new JSONObject(inputString);
		if(!jb.has(moduleName))
		{
			throw new JSONException(ZABAction.getMessage(ZABConstants.INVALID_INPUT_FORMAT));
		}
		return jb.getJSONObject(moduleName);
	}
	
	
	public static String getInputString(HttpServletRequest request) throws IOException
	{		
		
		String inputJson = SecurityRequestWrapper.getInstance(request).getFilteredStreamContent();
		/*if(StringUtils.isNotEmpty(inputJson))
		{
			inputJson =URLDecoder.decode(inputJson, "UTF-8");
		}*/
		return inputJson;
	}	
	public static HTTPMethod getHTTPMethod(HttpServletRequest request) throws IOException
	{
		String httpMethod = request.getParameter("method");		
		if(httpMethod!=null&&parseHTTPMethod(httpMethod)!=null)
		{
			return parseHTTPMethod(httpMethod);
		}
		return HTTPMethod.valueOf(request.getMethod());
	}
	public static HTTPMethod parseHTTPMethod(String httpMethod)
	{
		for(HTTPMethod method: HTTPMethod.values())
		{
			if(method.toString().equalsIgnoreCase(httpMethod))
			{
				return method;
			}
		}
		return null;
	}
	public static Boolean isGETMethod(HttpServletRequest request)
	{
		try{
		return ZABAction.getHTTPMethod(request).toString().equalsIgnoreCase(ZABAction.HTTPMethod.GET.toString());
		}catch(Exception ex){
			return false;
		}
		
	};
	public static ArrayList<String> parseJSONArray(HttpServletRequest request) throws IOException, JSONException
	{
		ArrayList<String> list = new ArrayList<String>();
		String inputString = ZABUtil.getCurrentInputString();
		if(!inputString.isEmpty()){
			JSONArray array = new JSONArray(inputString);
			if (array != null) { 
				for (int i=0;i<array.length();i++){ 
					   list.add(array.get(i).toString());}
				} 
			}
		return list;
	}
	public static void sendResponse(HttpServletRequest request, HttpServletResponse response, String responseString) throws IOException
	{
		response.setContentType(ZABAction.getResponseContentType(request.getContentType()));
		PrintWriter writer = response.getWriter();
		writer.println(responseString); //NO OUTPUTENCODING
	    writer.flush();
	}
	public static void sendHTMLResponse(HttpServletRequest request, HttpServletResponse response, String responseString) throws IOException
	{
		response.setContentType("text/html");// No I18N
		PrintWriter writer = response.getWriter();
		writer.println(IAMEncoder.encodeHTML(responseString));
	    writer.flush();
	}
	public static RequestParser getRequestParser(HttpServletRequest request)
	{
		String contentType = request.getContentType();
		if(JSON_FORMAT.equalsIgnoreCase(contentType))
		{                                        
			return new JSONRequestParser();
		}
		else if("xml".equalsIgnoreCase(contentType))
		{
			return new XMLRequestParser();
		}
		/*else if(contentType.equalsIgnoreCase("multipart/form-data;"))
		{
			return new FormDataRequestParser();
		}*/
		else 
		{
			return new JSONRequestParser();
		}
	}
	public static ResponseProvider getResponseProvider(HttpServletRequest request)
	{
		String contentType = request.getContentType();
		if(contentType!=null) {
			
			if(contentType.equalsIgnoreCase(JSON_FORMAT))
			{
				return  new JSONResponse();
			}
			else if(contentType.equalsIgnoreCase("xml"))
			{
				return new XMLResponse();
			}
			else 
			{
				return new JSONResponse();
			}
			
		}
		else 
		{			
			return new JSONResponse();
		}
	}
	
	public static String getResponseContentType(String contentType){
		
		if(contentType != null) {
			if(contentType.equalsIgnoreCase("json"))
			{
				return  JSON_FORMAT;
			}
			else if(contentType.equalsIgnoreCase("xml"))
			{
				return  XML_FORMAT;
			}
		}
		return  JSON_FORMAT;		
	}
	
	public static String parseVersion(String version)
	{
		return version.substring(1);
	}
	public static HashMap<String, String> parseStringToJSON(String inputString) throws JSONException
	{
		HashMap<String, String> map = new HashMap<String, String>();
			JSONObject json = new JSONObject(inputString);			
		 	Iterator<?> keys = json.keys();
			while( keys.hasNext() ){
				String key = (String) keys.next();
				String value = json.getString(key); 
					map.put(key, value);
			}			
		return map;
	}
	public static String getMessage(String message,String[] params)
	{
		if(ActionContext.getContext() == null) {
			//TODO: need to handle params
			try {
				if(params!=null) {
					int length = params.length;
					String localeMessage = ZABUtil.getResourceBundle().getString(message);
					for(int i=0; i<length; i++) {
						String token = "{"+i+"}"; //No I18N
						localeMessage = localeMessage.replace(token, params[i]);
					}					
					return localeMessage;
				}
			} catch (Exception e) {
				logger.log(Level.SEVERE,"Exception Occurred",e);
				return message;
			}
		}
		else
		{
			if(IAMUtil.getCurrentUser()!=null)
			{
				Locale locale = ZABUtil.getLocaleFromIamUser();
				if(ActionContext.getContext()!=null){
					ActionContext.getContext().setLocale(locale);
				}	
			}
		}
		return new ZABAction().getText(message, params);
	}
	
	public static String getMessage(String message)
	{
		try{
			if(ActionContext.getContext() == null)
			{
			
				try {
					return ZABUtil.getResourceBundle().getString(message);
				} catch (Exception e) {
					logger.log(Level.SEVERE,"Exception Occurred",e);
					return message;
				}
			}
			else
			{
				if(IAMUtil.getCurrentUser()!=null)
				{
					Locale locale = ZABUtil.getLocaleFromIamUser();
					if(ActionContext.getContext()!=null){
						ActionContext.getContext().setLocale(locale);
					}	
				}
			}
		
			return new ZABAction().getText(message);
		
		}catch(Exception ex)
		{
			logger.log(Level.SEVERE,"Exception Occurred",ex);
			return message;
		}
	}
	public static String getAppropriateMessage(String message,ArrayList<String> params)
	{
		String fieldString="";
		if(params.size()==1){
			fieldString = params.get(0);
			String fieldLabel = getMessage(fieldString);
			if(StringUtils.isNotEmpty(fieldLabel))
			{
				fieldString = fieldLabel;
			}
			return getMessage(message+".singular", new String[]{fieldString});//No I18N
		}
		else if(params.size()>=1)
		{
			fieldString = params.get(0);
			String fieldLabel = getMessage(fieldString);
			if(StringUtils.isNotEmpty(fieldLabel))
			{
				fieldString = fieldLabel;
			}
			for(int i=1;i<params.size();i++)
			{
				fieldLabel = getMessage( params.get(i));
				if(StringUtils.isEmpty(fieldLabel))
				{
					fieldLabel = params.get(i);
				}
				fieldString = fieldString +", "+fieldLabel;
			}
			int index = fieldString.lastIndexOf(',');
			  if (index != -1){
				  fieldString = fieldString.substring(0, index) + " and"//No I18N
				          + fieldString.substring(index+",".length());
			  }
			return getMessage(message+".plural", new String[]{fieldString});//No I18N
		}else{
			return getMessage(message+".singular");//No I18N
		}	
	}
}
