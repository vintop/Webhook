//$Id$
package com.zoho.abtest.common;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.struts2.util.URLDecoderUtil;
import org.json.JSONException;

import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.dimension.DimensionConstants;
import com.zoho.abtest.report.ReportRawDataConstants;
import com.zoho.abtest.utility.ZABUtil;

public abstract class ZABRequest {
	
	public static Boolean isNullOrEmpty(HashMap<String, String> hs, String key) {
		return !hs.containsKey(key) || hs.get(key)==null || hs.get(key).trim().isEmpty();
	}
	
	public ArrayList<HashMap<String,String>> parseJSON(HttpServletRequest request, String moduleName) throws JSONException, IOException
	{
		String httpMethod = ZABAction.getHTTPMethod(request).toString();
		if(httpMethod.equalsIgnoreCase("GET")||httpMethod.equalsIgnoreCase("DELETE")){
			getUpdateFromRequest(request);
			return null;
			}
		
		String string = ZABUtil.getCurrentInputString();
		ArrayList<HashMap<String,String>> mapArray = ZABAction.parseJSON(ZABAction.parseModuleInputArray(string,moduleName));
				
		for(HashMap<String,String> map:mapArray)
		{
			updateFromRequest(map,request);
			ZABRequest.commonUpdateFromRequest(map, request);
			ZABRequest.commonValidation(map,request);	
			specificValidation(map,request);
		}
		return mapArray;
	}
	
	public HashMap<String,String> parseSingleResourceJSON(HttpServletRequest request, String moduleName, Boolean specificValidation) throws JSONException, IOException
	{
		String httpMethod = ZABAction.getHTTPMethod(request).toString();
		if(httpMethod.equalsIgnoreCase("GET")){
			getUpdateFromRequest(request);
			return null;
			}
		
		String string = ZABUtil.getCurrentInputString();
		HashMap<String,String> map = new HashMap<String,String>();
		if(string != null)
		{
			map = ZABAction.parseJSON(ZABAction.parseModuleInputObject(string,moduleName));
		}
		
		updateFromRequest(map,request);
		ZABRequest.commonUpdateFromRequest(map, request);
		ZABRequest.commonValidation(map,request);
		if(specificValidation) {			
			specificValidation(map,request);
		}
		return map;
	}
	
	public String parseSingleResourceJSONasString(HttpServletRequest request, String moduleName, Boolean specificValidation) throws JSONException, IOException
	{
		String httpMethod = ZABAction.getHTTPMethod(request).toString();
		String response = "";
		if(httpMethod.equalsIgnoreCase("GET")){
			getUpdateFromRequest(request);
			return null;
			}
		
		String string = ZABUtil.getCurrentInputString();
		HashMap<String,String> map = new HashMap<String,String>();
		if(string != null)
		{
			response = ZABAction.parseModuleInputObject(string,moduleName).toString();
		}
		
		updateFromRequest(map,request);
		ZABRequest.commonUpdateFromRequest(map, request);
		ZABRequest.commonValidation(map,request);
		if(specificValidation) {			
			specificValidation(map,request);
		}
		return response;
	}
	
	public HashMap<String,String> parseSingleResourceJSON(HttpServletRequest request, String moduleName) throws JSONException, IOException
	{
		return parseSingleResourceJSON(request, moduleName, true);
	}
	
	public ArrayList<HashMap<String,String>> parseJSONRawdata(HttpServletRequest request, String moduleName, Boolean isExperimentData) throws JSONException, IOException
	{
		String inputJson = request.getParameter("raw");
		String string = inputJson;
		//string = URLDecoder.decode(string, "UTF-8");
		//TODO this needs to verified whether it will work fine for visitorrawdata, goalrawdata also. since unescapeHtml4 is applied considering heatmaprawdata 
		//string = StringEscapeUtils.unescapeHtml4(string);
		
		ArrayList<HashMap<String,String>> mapArray = null;
		
		if(isExperimentData)
		{
			mapArray = ZABAction.parseJSON(ZABAction.parseModuleInputArray(string,moduleName));
			
			for(HashMap<String,String> map:mapArray)
			{
				updateFromRequest(map,request);
				ZABRequest.commonUpdateFromRequest(map, request);
				ZABRequest.commonValidation(map,request);	
				specificValidation(map,request);
			}
		}
		else
		{
			mapArray = new ArrayList<HashMap<String,String>>(); 
			HashMap<String,String> map = ZABAction.parseJSON(ZABAction.parseModuleInputObject(string,moduleName));
			validateUserAgentRawdata(map);
			mapArray.add(map);
		}
		
		return mapArray;
	}
	
	public static HashMap<String, String> parseRawDataJSONObject(HttpServletRequest request, String moduleName) throws JSONException {
		String inputJson = request.getParameter("raw");
		if(inputJson!=null) {			
			return ZABAction.parseJSON(ZABAction.parseModuleInputObject(inputJson, moduleName));
		}
		return null;
	}
	
	public static ArrayList<HashMap<String,String>> parseRawDataJSONArray(HttpServletRequest request, String moduleName) throws JSONException {
		String inputJson = request.getParameter("raw");
		if(inputJson!=null) {			
			return ZABAction.parseJSON(ZABAction.parseModuleInputArray(inputJson, moduleName));
		}
		return null;
	}
	
	public ArrayList<HashMap<String,String>> parseHeatmapJSONFromUrlParam(HttpServletRequest request, String moduleName, Boolean isExperimentData) throws JSONException, IOException
	{
		String inputJson = request.getParameter("raw");
		String string = inputJson;
	
		ArrayList<HashMap<String,String>> mapArray = null;
		
		switch(moduleName)
		{ 
			case ReportRawDataConstants.API_MODULE_HEATMAP_RAW_SH :
				
					mapArray = ZABAction.parseJSON(ZABAction.parseModuleInputArray(string,moduleName));
					for(HashMap<String,String> map:mapArray)
					{
						updateFromRequest(map,request);
						ZABRequest.commonUpdateFromRequest(map, request);
						ZABRequest.commonValidation(map,request);	
						specificValidation(map,request);
					}
					
				break;
			case ReportRawDataConstants.API_MODULE_HEATMAP_POINTS_SH :
				
					mapArray = ZABAction.parseJSON(ZABAction.parseModuleInputArray(string,moduleName));
				break;
			case ReportRawDataConstants.API_MODULE_USERAGENT_RAW_SH :
				
					mapArray = new ArrayList<HashMap<String,String>>(); 
					HashMap<String,String> map = ZABAction.parseJSON(ZABAction.parseModuleInputObject(string,moduleName));
					validateUserAgentRawdata(map);
					mapArray.add(map);
				break;
			default : 
				break;
		}
		
		return mapArray;
	}
	
	public ArrayList<HashMap<String,String>> parseScrollmapJSONFromUrlParam(HttpServletRequest request, String moduleName, Boolean isExperimentData) throws JSONException, IOException
	{
		String inputJson = request.getParameter("raw");
		String string = inputJson;
	
		ArrayList<HashMap<String,String>> mapArray = null;
		
		switch(moduleName)
		{ 
			case ReportRawDataConstants.API_MODULE_SCROLLMAP_RAW_SH :
				
					mapArray = ZABAction.parseJSON(ZABAction.parseModuleInputArray(string,moduleName));
					for(HashMap<String,String> map:mapArray)
					{
						updateFromRequest(map,request);
						ZABRequest.commonUpdateFromRequest(map, request);
						ZABRequest.commonValidation(map,request);	
						specificValidation(map,request);
					}
					
				break;
			case ReportRawDataConstants.API_MODULE_SCROLL_DATA_SH :
				
//					mapArray = new ArrayList<HashMap<String,String>>(); 
//					HashMap<String,String> map1 = ZABAction.parseJSON(ZABAction.parseModuleInputObject(string,moduleName));
//					mapArray.add(map1);
					mapArray = ZABAction.parseJSON(ZABAction.parseModuleInputArray(string,moduleName));
				break;
			case ReportRawDataConstants.API_MODULE_USERAGENT_RAW_SH :
				
					mapArray = new ArrayList<HashMap<String,String>>(); 
					HashMap<String,String> map = ZABAction.parseJSON(ZABAction.parseModuleInputObject(string,moduleName));
					validateUserAgentRawdata(map);
					mapArray.add(map);
				break;
			default : 
				break;
		}
		
		return mapArray;
	}
	
	public static void validateUserAgentRawdata(HashMap<String,String> map)
	{
		if(!map.containsKey(ReportRawDataConstants.BROWSER_VALUE))
		{
			map.put(ReportRawDataConstants.BROWSER_VALUE, ReportRawDataConstants.UNKNOWN_VALUE);
		}
		if(!map.containsKey(ReportRawDataConstants.DEVICE_VALUE))
		{
			map.put(ReportRawDataConstants.DEVICE_VALUE, ReportRawDataConstants.UNKNOWN_VALUE);
		}
		if(!map.containsKey(ReportRawDataConstants.LANGUAGE_VALUE))
		{
			map.put(ReportRawDataConstants.LANGUAGE_VALUE, ReportRawDataConstants.UNKNOWN_VALUE);
		}
		if(!map.containsKey(ReportRawDataConstants.OS_VALUE))
		{
			map.put(ReportRawDataConstants.OS_VALUE, ReportRawDataConstants.UNKNOWN_VALUE);
		}
		if(!map.containsKey(ReportRawDataConstants.TRAFFICSOURCE_VALUE))
		{
			map.put(ReportRawDataConstants.TRAFFICSOURCE_VALUE, ReportRawDataConstants.UNKNOWN_VALUE);
		}
		if(!map.containsKey(ReportRawDataConstants.REFFERERURL_VALUE))
		{
			map.put(ReportRawDataConstants.REFFERERURL_VALUE, ReportRawDataConstants.UNKNOWN_VALUE);
		}
		if(!map.containsKey(ReportRawDataConstants.CURRENTURL_VALUE))
		{
			map.put(ReportRawDataConstants.CURRENTURL_VALUE, ReportRawDataConstants.UNKNOWN_VALUE);
		}
	}
	
	public static void updateError(HashMap<String, String> map,String errorString)
	{
		map.put(ZABConstants.SUCCESS, Boolean.FALSE.toString());
		map.put(ZABConstants.RESPONSE_STRING, errorString);
	}
	public static void updateError(HashMap<String, String> map,String errorString, String errorCode)
	{
		map.put(ZABConstants.SUCCESS, Boolean.FALSE.toString());
		map.put(ZABConstants.RESPONSE_STRING, errorString);
		map.put(ZABConstants.STATUS_CODE, errorCode);
	}
	public static void commonValidation(HashMap<String, String> map, HttpServletRequest request)
	{

	}
	public static void commonUpdateFromRequest(HashMap<String, String> map, HttpServletRequest request)
	{
		String sort = ((String)request.getParameter(ZABConstants.SORT_BY));
		if(sort!=null&&!sort.isEmpty())
		{
			String order = ((String)request.getParameter(ZABConstants.SORT_ORDER));
			request.setAttribute(ZABConstants.SORT_BY, sort);
			if(order!=null&&!order.isEmpty())
			{
				request.setAttribute(ZABConstants.SORT_ORDER, order);
			}
		}			
	}
	public static void getUpdateFromRequest(HttpServletRequest request)
	{
		String sort = ((String)request.getParameter(ZABConstants.SORT_BY));
		if(sort!=null&&!sort.isEmpty())
		{
			String order = ((String)request.getParameter(ZABConstants.SORT_ORDER));
			request.setAttribute(ZABConstants.SORT_BY, sort);
			if(order!=null&&!order.isEmpty())
			{
				request.setAttribute(ZABConstants.SORT_ORDER, order);
			}
		}			
	}
	public abstract void updateFromRequest(HashMap<String, String> map, HttpServletRequest request);
	public abstract void specificValidation(HashMap<String, String> map, HttpServletRequest request) throws IOException, JSONException;
}
