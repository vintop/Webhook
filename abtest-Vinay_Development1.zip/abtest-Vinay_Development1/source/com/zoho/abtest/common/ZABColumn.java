//$Id$
package com.zoho.abtest.common;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

//This is an experimental annotation
// Let's see how this rolls as a useful util
//
/**
 * 
 * Specify the column name you want to map with this variable.
 * This column name will be used when you create or fetch using the POJO
 *
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface ZABColumn {
	String name();
}
