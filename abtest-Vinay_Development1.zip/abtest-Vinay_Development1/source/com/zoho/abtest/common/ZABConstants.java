//$Id$
package com.zoho.abtest.common;

import com.zoho.abtest.utility.ApplicationProperty;
import com.zoho.conf.Configuration;

public abstract class ZABConstants {
	
	public static final String LONG = "long";//No I18N
	public static final String INTEGER = "Integer";//No I18N
	public static final String NUMBER = "number";//No I18N
	public static final String LOGICAL = "logical";//No I18N
	public static final String DATE = "date";//No I18N
	public static final String STRING = "string";//No I18N
	public static final String DOUBLE = "Double";//No I18N
	public static final String FLOAT = "Float";//No I18N
	public static final String BOOLEAN = "boolean";//No I18N
	public static final String TABLE = "table";//No I18N
	
	public static final String UNDERSCORE = "_";//No I18N
	public static final String COMMA = ",";//No I18N
	public static final String GREATER_THAN = ">";//No I18N
	public static final String GREATER_EQUAL = ">=";//No I18N
	public static final String LESSER_THAN = "<";//No I18N
	public static final String LESSER_EQUAL = "<=";//No I18N
	public static final String AND = "AND";//No I18N
	
	public static final String STATUS_CODE = "status_code"; //No I18N
	public static final String STATUS_STRING = "status_string"; //No I18N
	public static final String REDIRECT_URL = "redirect_url"; //No I18N
	public static final String SUCCESS = "success"; //No I18N
	public static final String RESPONSE_STRING = "response_string"; //No I18N
	public static final String SORT_BY = "sort"; //No I18N
	public static final String SORT_ORDER = "order";//No I18N
	public static final String PAGINATION = "pagination"; //No I18N
	public static final String COUNT = "count";//No I18N
	
	public static final String DATETIME = "datetime";//No I18N
	public static final String TIME = "time";//No I18N
	
	public static final String START_FROM = "start_from"; //No I18N
	public static final String OFFSET = "offset"; //No I18N
	public static final String RANGE = "range"; //No I18N
	public static final String TOTAL_COUNT = "total_count"; //No I18N
	public static final String NEXT_URL = "next_url"; //No I18N
	public static final String PREVIOUS_URL = "previous_url"; //No I18N
	public static final String PAGE_COUNT = "page_count";//No I18N
	public static final String TOTAL_PAGE_COUNT = "total_page_count";//No I18N
	
	// METRIC CONSTANTS
	public static final String CREATE_COUNT = "create_db_count";//No I18N
	public static final String READ_COUNT = "read_db_count";//No I18N
	public static final String UPDATE_COUNT = "update_db_count";//No I18N
	public static final String DELETE_COUNT = "delete_db_count";//No I18N
	public static final String TIME_TAKEN = "timeTakenToProcessTheRequest";//No I18N
	
	public static final String RESOURCE_ADD_SUCCESS = "resource.add.success"; //No I18N
	public static final String RESOURCE_UPDATE_SUCCESS = "resource.update.success"; //No I18N
	public static final String RESOURCE_DELETE_SUCCESS = "resource.delete.success"; //No I18N
	public static final String RESOURCE_PROCESSING_FAILURE = "error.processing.resource"; //No I18N
	public static final String RESOURCE_DISPLAYNAME_ALREADY_EXISTS = "resource.displayname.exists"; //NO I18N
	public static final String INVALID_URL_MESSAGE = "invalid.url.error"; //No I18N
	public static final String INVALID_REGEX_MESSAGE = "invalid.regex.error"; //No I18N
	public static final String MANDATORY_QPARAM_ERROR = "mandatory.qparam.error"; //No I18N
	public static final String RESOURCE_WITHLNAME_NOTEXISTS = "resource.withlname.notexits.error"; //No I18N
	public static final String USER_INVITE_FAILED = "user.invite.failed"; //No I18N
	public static final String USER_DELETE_ERROR = "currentuser.delete.error"; //No I18N
	public static final String CDN_FILE_NAME_ERROR = "cdn.file.name.error"; //No I18N
	public static final String INVALID_INPUT_FORMAT = "invalid.input.format"; //No I18N
	public static final String INVALID_JSON = "invalid.json"; //No I18N
	public static final String THUMBNAIL_EXCEPTION = "thumbnail.create.exception"; //No I18N
	
	public static final String TRAFFIC_ALLOCATION_ERROR = "error.trafficallocation";//NO I18N
	
	public static final String SCRIPT_CDN = "cdn.zohoabtest.js.url"; //No I18N
	
	public static final String SCRIPT_CDN_ALT = "cdn.alt.zohoabtest.js.url"; //No I18N
	
	public static final String START_MQUEUE_CONSUMER = "com.abtest.mqueue.consumer.start"; //No I18N
	
	public static final String IMAGE_CDN = "cdn.zohoabtest.images.url"; //No I18N
	
	public static final String ZPFS_URL = "abtest.publicserver.url"; //No I18N
	
	public static final String CDN_BASE_URL = "cdn.zohoabtest.base.url"; //No I18N
	
	
	public static final String LINKNAME = "linkname";//No I18N
	public static final String TRIGGERID = "triggerid";//No I18N

	public static final String DISPLAY_NAME = "display_name";//No I18N
	
	public static final String ERROR_CODE = "error_code"; //No I18N
	
	public static final String CAN_ACCESS = "can_access"; //No I18N
	public static final String PROJECT_ID = "project_id"; //No I18N
	
	public static final String DAY_LABEL = "resource.day.singular"; //No I18N
	public static final String DAYS_LABEL = "resource.day.plural"; //No I18N
	public static final String HOUR_LABEL = "resource.hour.singular"; //No I18N
	public static final String HOURS_LABEL = "resource.hour.plural"; //No I18N
	
	public static final boolean IS_RO_SETUP = ApplicationProperty.getBoolean("com.abtest.ro.setup"); //No I18N
	public static final boolean IS_PRODUCION_MODE = ApplicationProperty.getBoolean("com.abtest.productionmode"); //NO I18N
	
	public enum ErrorMessages{
		//SUCCESS
		API_ALL_SUCCESS("10000","all.success.response"),		
		//INPUT ERROR
		API_PARTIAL_SUCCESS("20000","partial.success.response"),
		INVALID_EMAIL_ADDRESS("20016","emailaddress.invalid"),
		LINK_NAME_ERROR("20002","resource.linkname.duplicate"),
		INVALID_INPUT_ERROR("20008","invalid.input.error"),
		READ_LIMIT_EXCEEDED("20003","read.limit.exceeded"),
		RESOURCE_NOT_FOUND("20004","resource.not.exist"),
		MANDATORY_FIELD_MISSING("20006","mandatory.field.missing"),
		NOT_USER_OF_APP("3009","Not user of Marketing Automation"),
		API_ALL_FAILURE("30000","all.failure.response"),
		PORTAL_NOT_EXISTS("40000","portal.not.exists"),
		USER_NOT_PORTAL_MEMBER("40001","user.not.portalmember"),
		ACCESS_DENIED("40002","access.denied"),
		USER_EMAIL_DUPLICATE("20001","emailaddress.duplicate"),
		ZOHOONE_USER_DEACTIVATED("99995","zohoone.user.deactivated"),
		ZOHOONE_TRIAL_EXPIRED("99996",""),
		APPLY_ACCESS_REQUEST("99997","apply.access.request"),
		ACTIVATION_AWAITED("99998","activation.awaited.error"),
		ORG_NOACCESS("99999","org.noaccess.error");
		
		private String errorCode;
		private String errorString;
		public String getErrorCode() {
			return errorCode;
		}
		public void setErrorCode(String errorCode) {
			this.errorCode = errorCode;
		}
		public String getErrorString() {
			return errorString;
		}
		public void setErrorString(String errorString) {
			this.errorString = errorString;
		}
		private ErrorMessages(String errorCode, String errorString) {
			this.errorCode = errorCode;
			this.errorString = errorString;
		}
	}
}
