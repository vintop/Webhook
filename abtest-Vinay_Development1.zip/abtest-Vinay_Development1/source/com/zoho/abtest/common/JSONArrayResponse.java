//$Id$
package com.zoho.abtest.common;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONObject;

import com.zoho.abtest.common.JSONArrayResponse;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;

public class JSONArrayResponse extends ZABResponse{
	
	private static Logger logger = Logger.getLogger(JSONArrayResponse.class.getName());
	
	public static String jsonResponse(HttpServletRequest request,JSONArray json,String apiName) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONObject json1 =new JSONObject();
			json1.put(ZABConstants.STATUS_STRING, ZABAction.getMessage(ZABConstants.ErrorMessages.API_ALL_SUCCESS.getErrorString()));
			json1.put(ZABConstants.STATUS_CODE, ZABConstants.ErrorMessages.API_ALL_SUCCESS.getErrorCode());
			json1.put(ZABConstants.COUNT, json.length());
			json1.put(apiName, json);
			returnBuffer.append(json1);
			json=null;
		}catch(Exception ex){
			logger.log(Level.SEVERE,"Exception Occurred",ex);
		}
		return returnBuffer.toString();
	}
}
