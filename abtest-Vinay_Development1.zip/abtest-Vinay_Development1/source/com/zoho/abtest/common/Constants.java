
//$Id$	
package com.zoho.abtest.common;
	
	
public class Constants {
	    
	private String apiName;
	private String databaseName;
	private String databaseType;
	private Boolean editable;
	private Boolean nullable;
	
	/**
	 * @param apiName
	 * @param databaseName
	 * @param databaseType
	 * @param editable
	 */
	public Constants(String apiName, String databaseName, String databaseType, Boolean editable)
	{
	    this.apiName = apiName;
        this.databaseName = databaseName;
	    this.databaseType = databaseType;
	    this.editable = editable;
	    this.nullable = false;
	}
	
	
	/**
	 * @param apiName
	 * @param databaseName
	 * @param databaseType
	 * @param editable
	 * @param nullable
	 */
	public Constants(String apiName, String databaseName, String databaseType, Boolean editable,Boolean nullable)
	{
	    this.apiName = apiName;
    this.databaseName = databaseName;
    this.databaseType = databaseType;
	    this.editable = editable;
	    this.nullable = nullable;
	}
	public String getApiName() {
	    return apiName;
	}
public void setApiName(String apiName) {
	    this.apiName = apiName;
	}
	public String getDatabaseName() {
	    return databaseName;
	}
	public void setDatabaseName(String databaseName) {
	    this.databaseName = databaseName;
	}
	public String getDatabaseType() {
	    return databaseType;
	}
	public void setDatabaseType(String databaseType) {
	    this.databaseType = databaseType;
	}
	public Boolean isEditable() {
	    return editable;
}
	public void setEditable(Boolean editable) {
	    this.editable = editable;
	}
	public Boolean getNullable() {
	    return nullable;
	}
	public void setNullable(Boolean nullable) {
	    this.nullable = nullable;
}
	
	}
 