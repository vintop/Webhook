//$Id$
package com.zoho.abtest.common;

public enum MatchType {
	
		SIMPLE_MATCH(1),
		EXACT_MATCH(2),
		PATTERN_MATCH(3),
		REGEX_MATCH(4),
		CONTAINS_MATCH(5),
		STARTS_WITH(6),
		ENDS_WITH(7);
		
		private Integer matchTypeId;
		
		private MatchType(Integer matchTypeId) {
			this.matchTypeId = matchTypeId;
		}

		public Integer getMatchTypeId() {
			return matchTypeId;
		}
		
		public static MatchType getMatchTypeById(Integer matchTypeId) {
			if(matchTypeId!=null) {
				for(MatchType mtype: MatchType.values()) {
					if(matchTypeId.equals(mtype.getMatchTypeId())) {
						return mtype;
					}
				}
			}
			return null;
	   }
}
