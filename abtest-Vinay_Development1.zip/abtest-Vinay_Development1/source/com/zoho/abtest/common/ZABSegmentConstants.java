//$Id$
package com.zoho.abtest.common;

import java.util.HashMap;

public class ZABSegmentConstants {

	public static final HashMap<String, String> OS_SWAP_VALUES;
	static {
		OS_SWAP_VALUES = new HashMap<String, String>();
		OS_SWAP_VALUES.put("MAC OS", "Mac OS");
		OS_SWAP_VALUES.put("IOS", "iOS");
		OS_SWAP_VALUES.put("CHROMIUM OS", "Chromium OS");
	}
	
	public static final HashMap<String, String> SOURCE_SWAP_VALUES;
	static {
		SOURCE_SWAP_VALUES = new HashMap<String, String>();
		SOURCE_SWAP_VALUES.put("Search", "Organic Search");
		SOURCE_SWAP_VALUES.put("Campaign", "Paid Campaigns");
	}
	
}
