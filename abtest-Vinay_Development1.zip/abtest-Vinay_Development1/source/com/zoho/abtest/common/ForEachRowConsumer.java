//$Id$
package com.zoho.abtest.common;

import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;

public interface ForEachRowConsumer {
	public void execute(DataObject dobj, Row row, ZABModel model);
}
