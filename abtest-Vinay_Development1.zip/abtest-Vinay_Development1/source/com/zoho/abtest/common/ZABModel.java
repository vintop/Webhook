//$Id$
package com.zoho.abtest.common;

import java.io.Serializable;
import java.lang.annotation.Annotation;
import java.lang.invoke.MethodHandles;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.DeleteQuery;
import com.adventnet.ds.query.DeleteQueryImpl;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.Range;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.ds.query.SelectQueryImpl;
import com.adventnet.ds.query.SortColumn;
import com.adventnet.ds.query.Table;
import com.adventnet.ds.query.UpdateQuery;
import com.adventnet.ds.query.UpdateQueryImpl;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Persistence;
import com.adventnet.persistence.Row;
import com.adventnet.persistence.WritableDataObject;
import com.zoho.abtest.VISITOR_DETAIL;
import com.zoho.abtest.exception.InvalidInputValueException;
import com.zoho.abtest.exception.ResourceNotFoundException;
import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.utility.ZABUtil;

public class ZABModel implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public Boolean success;
	public String responseString = null;
	public String responseCode = null;
	public Boolean getSuccess() {
		return success;
	}
	public void setSuccess(Boolean success) {
		this.success = success;
	}	
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}	
	public String getResponseCode() {
		return this.responseCode;
	}
	public String getResponseString() {
		return responseString;
	}
	public void setResponseString(String responseString) {
		this.responseString = responseString;
	}	
	public static String getAddResourceSuccessMessage(String resourceName)
	{
		return ZABAction.getMessage(ZABConstants.RESOURCE_ADD_SUCCESS,new String[]{resourceName});
	}
	public static String getUpdateResourceSuccessMessage(String resourceName)
	{
		return ZABAction.getMessage(ZABConstants.RESOURCE_UPDATE_SUCCESS,new String[]{resourceName});
	}
	public static String getDeleteResourceSuccessMessage(String resourceName)
	{
		return ZABAction.getMessage(ZABConstants.RESOURCE_DELETE_SUCCESS,new String[]{resourceName});
	}

	/**
	 * @param columnName
	 * @param apiFieldName
	 * @param columnType
	 * @param hs
	 * @param row
	 * @return true if column is added or else returns false
	 * @throws InvalidInputValueException
	 */
	public static boolean setColumnValue(String columnName, String apiFieldName, String columnType,  HashMap<String, String> hs, Row row) throws InvalidInputValueException {
		if(hs.containsKey(apiFieldName)&&hs.get(apiFieldName)!=null)
		{
			if(columnType.equals(ZABConstants.LONG))
			{
				row.set(columnName, ZABUtil.parseLong(hs.get(apiFieldName),apiFieldName));
			}
			else if(columnType.equals(ZABConstants.FLOAT))
			{
				row.set(columnName, ZABUtil.parseFloat(hs.get(apiFieldName),apiFieldName));
			}
			else if(columnType.equals(ZABConstants.INTEGER))
			{
				row.set(columnName, ZABUtil.parseInteger(hs.get(apiFieldName),apiFieldName));
			}else if(columnType.equals(ZABConstants.BOOLEAN))
			{
				row.set(columnName, ZABUtil.parseBoolean(hs.get(apiFieldName),apiFieldName));
			}else if(columnType.equals(ZABConstants.STRING))
			{
				row.set(columnName, hs.get(apiFieldName));
			}else if(columnType.equals("integer[][]"))
			{
				String array = hs.get(apiFieldName);
				 array = array.replaceAll("\\{", "").replaceAll("\\},", "|").replaceAll("\\}", "").replaceAll("\\],", "|").replaceAll("\\]","").replaceAll("\\[", "").replaceAll("\\s", "");
				 String[]items = array.split("\\|");
				Integer[][] value = new Integer[items.length][];
			    for(int i=0;i<items.length;i++){
			    	String[] nums = items[i].split(",");
			    	Integer[] val = new Integer[nums.length];
			    	for(int j=0;j<nums.length;j++){
			    	  val[j] = Integer.parseInt(nums[j]);	
			    	}
			    	value[i] = val;
			    }
				row.set(columnName, value);
			}
			
			return true;
		}	
		return false;
	}
	
	/**
	 * @param columnName
	 * @param apiFieldName
	 * @param columnType
	 * @param hs
	 * @param s
	 * @return true if column is updated or else returns false
	 * @throws InvalidInputValueException
	 * Sets column values in update query
	 */
	public static boolean updateColumnValue(String columnName, String apiFieldName, String columnType, Boolean nullable, HashMap<String, String> hs, UpdateQuery s) throws InvalidInputValueException {
		if(hs.containsKey(apiFieldName)) {	
			if(nullable && hs.get(apiFieldName) == null) {
				s.setUpdateColumn(columnName, null);
			} else if(columnType.equals(ZABConstants.LONG))
			{
				s.setUpdateColumn(columnName, ZABUtil.parseLong(hs.get(apiFieldName),apiFieldName));
			}else if(columnType.equals(ZABConstants.FLOAT))
			{
				s.setUpdateColumn(columnName, ZABUtil.parseFloat(hs.get(apiFieldName),apiFieldName));
			}else if(columnType.equals(ZABConstants.INTEGER))
			{
				s.setUpdateColumn(columnName, ZABUtil.parseInteger(hs.get(apiFieldName),apiFieldName));
			}else if(columnType.equals(ZABConstants.BOOLEAN))
			{
				s.setUpdateColumn(columnName, ZABUtil.parseBoolean(hs.get(apiFieldName),apiFieldName));
			}else if(columnType.equals(ZABConstants.STRING))
			{
				s.setUpdateColumn(columnName, hs.get(apiFieldName));
			}
			return true;
		}
		return false;
	}
	

	/**
	 * @param columnName
	 * @param apiFieldName
	 * @param columnType
	 * @param hs
	 * @param s
	 * @return true if column is updated or else returns false
	 * @throws InvalidInputValueException
	 * Sets column values in update query
	 */
	public static boolean updateDefColumnValue(String columnName, String apiFieldName, String columnType,  HashMap<String, String> hs, UpdateQuery s) throws InvalidInputValueException {
		if(hs.containsKey(apiFieldName)) {			
			if(columnType.equals(ZABConstants.LONG))
			{
				s.setUpdateColumn(columnName, 0l);
			}else if(columnType.equals(ZABConstants.FLOAT))
			{
				s.setUpdateColumn(columnName, 0f);
			}else if(columnType.equals(ZABConstants.INTEGER))
			{
				s.setUpdateColumn(columnName, ZABUtil.parseInteger(hs.get(apiFieldName),apiFieldName));
			}else if(columnType.equals(ZABConstants.BOOLEAN))
			{
				s.setUpdateColumn(columnName, false);
			}else if(columnType.equals(ZABConstants.STRING))
			{
				s.setUpdateColumn(columnName, "");
			}
			return true;
		}
		return false;
	}
	
	public static Row createRowObj(List<Constants> listConstants, String table, HashMap<String, String> hs) throws Exception
	{
		Row row = new Row(table);
		Integer size = listConstants.size();
		for(int i=0;i<size;i++) 
		{
			Constants constant = listConstants.get(i);
			String columnName = constant.getDatabaseName();
			String apiFieldName = constant.getApiName();
			String columnType = constant.getDatabaseType();
			setColumnValue(columnName, apiFieldName, columnType, hs, row);
		}	
		
	    return row;
	}
	
	public static DataObject createRow(List<Constants> listConstants, String table, HashMap<String, String> hs) throws Exception
	{
		Row row = createRowObj(listConstants, table, hs);
		DataObject d = createResource(row);
	    ZABUtil.incrementCreateDBCallCount();
	    return d;
	}
	
	public static DataObject createRow(List<Constants> listConstants, String table, ArrayList<HashMap<String, String>> hsArray) throws Exception
	{
		DataObject d=new WritableDataObject();
		for(HashMap<String, String> hs:hsArray)
		{
			d.addRow(createRowObj(listConstants, table, hs));
		}
		addDataObject(d);
	    ZABUtil.incrementCreateDBCallCount();
	    return d;
	}
	public static DataObject createRow(Map<String,String> column, Map<String,String> dataType, HashMap<String, String> hs) throws Exception
	{
		Row row = new Row(column.get(ZABConstants.TABLE));
		for(Map.Entry<String,String> entry:column.entrySet())
		{
			String columnName = entry.getKey();
			String apiFieldName = entry.getValue();
			String columnType = dataType.get(columnName);
			setColumnValue(columnName, apiFieldName, columnType, hs, row);			
		}			
	    return createResource(row);
	}
	
	public static boolean updateRow(List<Constants> listConstants, String table, HashMap<String, String> hs,Criteria c, String resourceName) throws Exception
	{
		return updateRow(listConstants, table, hs, c, resourceName, Boolean.FALSE);		
	}
	
	public static boolean updateRow(List<Constants> listConstants, String table, HashMap<String, String> hs,Criteria c, String resourceName, Boolean skipResourceCheck) throws Exception
	{
		Boolean updateColumnAdded = false;
		if(!resourceExists(table,c) && !skipResourceCheck)
		{
			throw new ResourceNotFoundException(ZABAction.getMessage(resourceName));
		}
		UpdateQuery s = new UpdateQueryImpl(table);
		Integer size = listConstants.size();
		for(int i=0;i<size;i++)
		{
			Constants constant = listConstants.get(i);
			String columnName = constant.getDatabaseName();
			String apiFieldName = constant.getApiName();
			String columnType = constant.getDatabaseType();
			Boolean nullable = constant.getNullable();
			if(updateColumnValue(columnName, apiFieldName, columnType, nullable, hs, s) &&constant.isEditable())
			{
				updateColumnAdded = true;
			}			
		}	
		if(updateColumnAdded)
		{
			s.setCriteria(c);
			updateRow(s);	
			ZABUtil.incrementUpdateDBCallCount();
			return true;
		}
		return false;		
	}
	public static void updateRow(UpdateQuery updateQuery) throws Exception{
		Persistence per= ZABUtil.getPersistenceBean();
		per.update(updateQuery);	
		ZABUtil.incrementUpdateDBCallCount();
	}
	public static void updateDataObject(DataObject dObj) throws Exception
	{
		Persistence per= ZABUtil.getPersistenceBean();
		per.update(dObj);		
		ZABUtil.incrementUpdateDBCallCount();
	}
	public static void addDataObject(DataObject dObj) throws Exception
	{
		Persistence per= ZABUtil.getPersistenceBean();
		per.add(dObj);		
		ZABUtil.incrementUpdateDBCallCount();
	}
	public static void replaceRow(List<Constants> listConstants, String table, HashMap<String, String> hs,Criteria c, String resourceName) throws Exception
	{
		UpdateQuery s = new UpdateQueryImpl(table);
		if(!resourceExists(table,c))
		{
			throw new ResourceNotFoundException(ZABAction.getMessage(resourceName));
		}
		Integer size = listConstants.size();
		for(int i=0;i<size;i++)
		{
			Constants constant = listConstants.get(i);
			String columnName = constant.getDatabaseName();
			String apiFieldName = constant.getApiName();
			String columnType = constant.getDatabaseType();
			Boolean nullable = constant.getNullable();
			if(!updateColumnValue(columnName, apiFieldName, columnType, nullable, hs, s))
			{
				if(constant.isEditable())
				{
					if(nullable)
					{
						s.setUpdateColumn(columnName, null);
					}else{
						updateDefColumnValue(columnName, apiFieldName, columnType, hs, s);	
					}
				}
			}		
		}	
		s.setCriteria(c);
		updateResource(s);
	}
	public static DataObject getRow(String tableName,Criteria c,Join join,int limit) throws Exception
	{
		return getRow(null,tableName, c,join,limit);
	}
	public static DataObject getRow(String tableName,Criteria c,Join join) throws Exception
	{
		return getRow(null,tableName, c,join);
	}
	public static DataObject getRow(String tableName,Criteria c,Join[] joins) throws Exception
	{
		return getRow(null,tableName, c,joins);
	}
	public static DataObject getRow(String tableName,Criteria c,Join[] joins,int limit) throws Exception
	{
		return getRow(null,tableName, c,joins,limit);
	}
	public static DataObject getRow(Column[] columnArray, String tableName,Criteria c,Join[] joins) throws Exception
	{		
		Table table1 = new Table(tableName);
		SelectQuery selectQuery = new SelectQueryImpl(table1);
		if(columnArray!=null&&columnArray.length!=0)
		{
			for(Column col:columnArray)
			{
				selectQuery.addSelectColumn(col);
			}
		}else{
			selectQuery.addSelectColumn(new Column(tableName,"*"));
		}		
		selectQuery.setCriteria(c);
		for(Join join:joins)
		{selectQuery.addSelectColumn(new Column(join.getBaseTableName(),"*"));
			selectQuery.addSelectColumn(new Column(join.getReferencedTableName(),"*"));
			
			selectQuery.addJoin(join);
		}
		return getResource(selectQuery);
		
	}
	public static DataObject getRow(Column[] columnArray, String tableName,Criteria c,Join[] joins,int limit) throws Exception
	{		
		Table table1 = new Table(tableName);
		SelectQuery selectQuery = new SelectQueryImpl(table1);
		if(columnArray!=null&&columnArray.length!=0)
		{
			for(Column col:columnArray)
			{
				selectQuery.addSelectColumn(col);
			}
		}else{
			selectQuery.addSelectColumn(new Column(tableName,"*"));
		}		
		selectQuery.setCriteria(c);
		Range r =new Range(0,limit);
		selectQuery.setRange(r);
		for(Join join:joins)
		{selectQuery.addSelectColumn(new Column(join.getBaseTableName(),"*"));
			selectQuery.addSelectColumn(new Column(join.getReferencedTableName(),"*"));
			
			selectQuery.addJoin(join);
		}
		return getResource(selectQuery);
		
	}
	public static DataObject getRow(Column[] columnArray, String tableName,Criteria c,Join join) throws Exception
	{		
		Table table1 = new Table(tableName);
		SelectQuery selectQuery = new SelectQueryImpl(table1);
		if(columnArray!=null&&columnArray.length!=0)
		{
			for(Column col:columnArray)
			{
				selectQuery.addSelectColumn(col);
			}
		}else{
			selectQuery.addSelectColumn(new Column(tableName,"*"));
		}
		selectQuery.addSelectColumn(new Column(join.getReferencedTableName(),"*"));
		selectQuery.setCriteria(c);
		selectQuery.addJoin(join);
		return getResource(selectQuery);
		
	}
	public static DataObject getRow(Column[] columnArray, String tableName,Criteria c,Join join,int limit) throws Exception
	{		
		Table table1 = new Table(tableName);
		SelectQuery selectQuery = new SelectQueryImpl(table1);
		if(columnArray!=null&&columnArray.length!=0)
		{
			for(Column col:columnArray)
			{
				selectQuery.addSelectColumn(col);
			}
		}else{
			selectQuery.addSelectColumn(new Column(tableName,"*"));
		}
		selectQuery.addSelectColumn(new Column(join.getReferencedTableName(),"*"));
		Range r = new Range(0,limit);
		selectQuery.setCriteria(c);
		selectQuery.setRange(r);
		selectQuery.addJoin(join);
		return getResource(selectQuery);
		
	}
	public static DataObject getRow(String tableName,Criteria c,int limit) throws Exception
	{
		return getRow(null,tableName, c,limit);
	}
	public static DataObject getRow(String tableName,Criteria c) throws Exception
	{
		return getRow(null,tableName, c);
	}
	public static Row getFirstRow(String tableName,Criteria c) throws Exception
	{
		DataObject dobj =  getRow(null,tableName, c);
		return dobj.getFirstRow(tableName);
	}
	public static DataObject getRow(String[] columnArray, String tableName,Criteria c) throws Exception
	{		
		Table table1 = new Table(tableName);
		SelectQuery selectQuery = new SelectQueryImpl(table1);
		if(columnArray!=null&&columnArray.length!=0)
		{
			for(String col:columnArray)
			{
				selectQuery.addSelectColumn(new Column(tableName,col));
			}
		}else{
			selectQuery.addSelectColumn(new Column(tableName,"*"));
		}
		selectQuery.setCriteria(c);
		return getResource(selectQuery);
		
	}
	public static DataObject getRow(String[] columnArray, String tableName,Criteria c,int limit) throws Exception
	{		
		Table table1 = new Table(tableName);
		SelectQuery selectQuery = new SelectQueryImpl(table1);
		if(columnArray!=null&&columnArray.length!=0)
		{
			for(String col:columnArray)
			{
				selectQuery.addSelectColumn(new Column(tableName,col));
			}
		}else{
			selectQuery.addSelectColumn(new Column(tableName,"*"));
		}
		selectQuery.setCriteria(c);
		Range range = new Range(0, limit);
		selectQuery.setRange(range);
		return getResource(selectQuery);
		
	}
	public static String generateUniqueId(String tableName,String columnName, Persistence per) throws Exception
	{
		Boolean uniqueIdGenerated = false;
		String privaterKey=null;
		while(!uniqueIdGenerated)
		{
			privaterKey = UUID.randomUUID().toString();
			privaterKey = privaterKey.replace("-", "");
			Table table1 = new Table(tableName);
			SelectQuery selectQuery = new SelectQueryImpl(table1);
			selectQuery.addSelectColumn(new Column(tableName, "*"));
			Criteria c = new Criteria(new Column(tableName, columnName),privaterKey, QueryConstants.EQUAL); 
			selectQuery.setCriteria(c);
			DataObject dobj = per.get(selectQuery);
			Iterator<?> it = dobj.getRows(tableName);
			if(!it.hasNext())
			{
				uniqueIdGenerated = true;
			}
		}
		ZABUtil.incrementCreateDBCallCount();
		return privaterKey;
	}
	
	public static String generateUniqueId(String tableName,String columnName) throws Exception
	{
		Persistence per= ZABUtil.getPersistenceBean();
		return generateUniqueId(tableName, columnName, per);
	}
	public static DataObject getRow(String tableName,Criteria c,SortColumn sort, Join[] joins) throws Exception
	{
		return getRow(null,tableName, c,sort,joins);
	}
	public static DataObject getRow(String[] columnArray, String tableName,Criteria c,SortColumn sort, Join[] joins) throws Exception
	{		
		Table table1 = new Table(tableName);
		SelectQuery selectQuery = new SelectQueryImpl(table1);
		if(columnArray!=null&&columnArray.length!=0)
		{
			for(String col:columnArray)
			{
				selectQuery.addSelectColumn(new Column(tableName,col));
			}
		}else{
			selectQuery.addSelectColumn(new Column(tableName,"*"));
		}
		selectQuery.setCriteria(c);
		if(sort!=null){
			selectQuery.addSortColumn(sort);
			
		}
		if(joins!=null)
		{
			for(Join join:joins)
			{
			selectQuery.addSelectColumn(new Column(join.getReferencedTableName(),"*"));
			selectQuery.addJoin(join);
			}
		}
		return getResource(selectQuery);
		
	}
	
	public static DataObject getRow(String tableName,Criteria c,SortColumn sort,int limit) throws Exception
	{		
		Table table1 = new Table(tableName);
		SelectQuery selectQuery = new SelectQueryImpl(table1);
		selectQuery.addSelectColumn(new Column(tableName,"*"));
		if(c != null)
		{
			selectQuery.setCriteria(c);
		}
		if(sort!=null)
		{
			selectQuery.addSortColumn(sort);
		}
		Range range = new Range(0, limit);
		selectQuery.setRange(range);
		return getResource(selectQuery);
	}
	
	public static Boolean resourceExists(String tableName,Criteria c) throws Exception  
	{
		Boolean resourceExists = false;
		DataObject dobj = getRow(tableName,c);
		Iterator<?> it = dobj.getRows(tableName);
        if(it.hasNext()){
        	resourceExists = true;
        }
		return resourceExists;
	}
	public static ArrayList<String> deleteMultipleRow(String tableName,Criteria c,String resourceName) throws Exception
	{		
		ArrayList<String> deletedArray = new ArrayList<String>();
		String [] totalArray = (String [])c.getValue();
		if(!resourceExists(tableName,c))
		{
			return deletedArray;
		}
		Persistence per= ZABUtil.getPersistenceBean(); 
		DataObject dobj = getRow(tableName,c);		
		for(String linkName:totalArray)
		{
			Criteria c1 = new Criteria(c.getColumn(),linkName, QueryConstants.EQUAL);
			Row row = dobj.getRow(tableName, c1);
			if(row!=null)
			{
				deletedArray.add(linkName);
			}
		}		
		dobj.deleteRows(tableName, c);
		per.update(dobj);
		ZABUtil.incrementDeleteDBCallCount();
		return deletedArray;
  
	}
	public static ArrayList<Long> deleteMultipleRowWithId(String tableName,Criteria c,String resourceName) throws Exception
	{		
		ArrayList<Long> deletedArray = new ArrayList<Long>();
		Long [] totalArray = (Long [])c.getValue();
		if(!resourceExists(tableName,c))
		{
			return deletedArray;
		}
		Persistence per= ZABUtil.getPersistenceBean(); 
		DataObject dobj = getRow(tableName,c);		
		for(Long linkName:totalArray)
		{
			Criteria c1 = new Criteria(c.getColumn(),linkName, QueryConstants.EQUAL);
			Row row = dobj.getRow(tableName, c1);
			if(row!=null)
			{
				deletedArray.add(linkName);
			}
		}		
		dobj.deleteRows(tableName, c);
		per.update(dobj);
		ZABUtil.incrementDeleteDBCallCount();
		return deletedArray;
  
	}
	public static HashMap<String, Long> deleteMultipleRow(String tableName,Criteria c,String columnName, String resourceName) throws Exception
	{		
		HashMap<String, Long> deletedArray = new HashMap<String, Long>();
		String [] totalArray = (String [])c.getValue();
		if(!resourceExists(tableName,c))
		{
			return deletedArray;
		}
		Persistence per= ZABUtil.getPersistenceBean(); 
		DataObject dobj = getRow(tableName,c);
	
		for(String linkName:totalArray)
		{
			Criteria c1 = new Criteria(c.getColumn(),linkName, QueryConstants.EQUAL);
			Row row = dobj.getRow(tableName, c1);
			if(row!=null)
			{
				deletedArray.put(linkName, (Long)row.get(columnName));
			}
		}		
		dobj.deleteRows(tableName, c);
		per.update(dobj);
		ZABUtil.incrementDeleteDBCallCount();
		return deletedArray;
  
	}
	public static ArrayList<Row> deleteRow(String tableName,Criteria c,String resourceName) throws Exception
	{		
		ArrayList<Row> objs = new ArrayList<Row>();
		if(!resourceExists(tableName,c))
		{
			throw new ResourceNotFoundException(ZABAction.getMessage(resourceName));
		}
		Persistence per= ZABUtil.getPersistenceBean(); 
		DataObject dobj = getRow(tableName,c);
		Iterator<?> its = dobj.getRows(tableName);
		while(its.hasNext())
		{
			Row r = (Row)its.next();
			if(c.getColumn()!=null)
			{
				objs.add(r);
			}			
		}
		dobj.deleteRows(tableName, c);
		per.update(dobj);
		ZABUtil.incrementDeleteDBCallCount();
		return objs;
	}
	public static void deleteAllRows(String tableName) throws Exception
	{		
		Criteria c = null;
		Persistence per= ZABUtil.getPersistenceBean(); 
		DataObject dobj = getRow(tableName,c);
		dobj.deleteRows(tableName, c);
		per.update(dobj);
		ZABUtil.incrementDeleteDBCallCount();
	}
	public static DataObject createResource(Row row) throws Exception
	{
		
		DataObject d=new WritableDataObject();
	    Persistence per= ZABUtil.getPersistenceBean();
	    d.addRow(row);
	    per.add(d);
	    ZABUtil.incrementCreateDBCallCount();
	    return d;
	}
	public static DataObject createResource(ArrayList<Row> rows) throws Exception
	{
		DataObject d=new WritableDataObject();
	    Persistence per= ZABUtil.getPersistenceBean();
	    for(Row row:rows)
	    {
	    	d.addRow(row);
	    }
	    per.add(d);
	    ZABUtil.incrementCreateDBCallCount();
	    return d;
	}
	public static void deleteResource(Row row) throws Exception
	{
	    Persistence per= ZABUtil.getPersistenceBean();
	    per.delete(row);
	    ZABUtil.incrementDeleteDBCallCount();
	}
	public static DataObject createResource(DataObject d) throws Exception
	{
	    Persistence per= ZABUtil.getPersistenceBean();
	    per.add(d);
	    ZABUtil.incrementCreateDBCallCount();
	    return d;
	}
	public static void updateResource(UpdateQuery selectQuery) throws Exception
	{
		Persistence per= ZABUtil.getPersistenceBean(); 
    	per.update(selectQuery);
    	ZABUtil.incrementUpdateDBCallCount();
	}
	public static DataObject getResource(SelectQuery selectQuery) throws Exception
	{
		Persistence per= ZABUtil.getPersistenceBean(); 
    	DataObject dobj = per.get(selectQuery); 
    	ZABUtil.incrementReadDBCallCount();
    	return dobj;
	}
	
	public static void deleteResource(Criteria criteria) throws Exception
	{
		Persistence per= ZABUtil.getPersistenceBean(); 
    	per.delete(criteria);
    	ZABUtil.incrementDeleteDBCallCount();
	}
	
	public static int deleteResource(DeleteQuery deleteQuery) throws Exception
	{
		int deleteRowCount = 0;
		Persistence per= ZABUtil.getPersistenceBean();
		deleteRowCount = per.delete(deleteQuery);
		ZABUtil.incrementDeleteDBCallCount();
		return deleteRowCount;
	}
	
	public static String generateName(String tableName, String nameColumn, String displayName, Criteria c2) throws Exception
	{
		Integer suffix = 1;
		String uniqueName = displayName;
		Criteria c1 = new Criteria(new Column(tableName,nameColumn),uniqueName,QueryConstants.STARTS_WITH);
		Criteria c=c1.and(c2);
		ArrayList<String> linkNameArray = getLinkName(tableName, nameColumn, c);
    	if(!linkNameArray.isEmpty())
        {    						
			Boolean uniqueNameFlag = false;
			while(!uniqueNameFlag){
				uniqueNameFlag = true;				
					if(linkNameArray.contains(uniqueName))
					{
						uniqueNameFlag = false;
						uniqueName = displayName +" ("+(suffix++)+")";
					}
					
			}		
        }
		return uniqueName;
	}	
	
	public static String generateLinkName(String tableName, String linkNameColumn, Criteria c2, String linkName, String displayName) throws Exception
	{
		if(linkName!=null&&verifyLinkName(tableName, linkNameColumn, c2, linkName))
		{
			return linkName;
		}		
		displayName = ZABUtil.removeSplChars(displayName);
		displayName = ZABUtil.replaceSpaceWith(displayName);
		displayName = displayName.toLowerCase();
		ArrayList<String> linkNameArray=new ArrayList<String>();
		Integer suffix = 1;
		String uniqueLinkName = displayName;
		Criteria c1 = new Criteria(new Column(tableName,linkNameColumn),uniqueLinkName,QueryConstants.STARTS_WITH);
		Criteria c=c1.and(c2);
		linkNameArray = getLinkName(tableName,linkNameColumn,c);
    	if(!linkNameArray.isEmpty())
        {    						
			Boolean uniqueNameFlag = false;
			while(!uniqueNameFlag){
				uniqueNameFlag = true;				
					if(linkNameArray.contains(uniqueLinkName))
					{
						uniqueNameFlag = false;
						uniqueLinkName = displayName +"-"+(++suffix);
					}
					
			}		
        }
		return uniqueLinkName;
	}	
	public static ArrayList<String> getLinkName(String tableName, String linkNameColumn, Criteria c) throws Exception
	{
		ArrayList<String> linkNameArray=new ArrayList<String>();
		Table table = new Table(tableName);
		SelectQuery selectQuery = new SelectQueryImpl(table);
		selectQuery.addSelectColumn(new Column(tableName, "*"));
    	selectQuery.setCriteria(c);
    	Persistence per= ZABUtil.getPersistenceBean();
    	DataObject dobj = per.get(selectQuery);
    	Iterator<?> it = dobj.getRows(tableName);
    	while(it.hasNext())
    	{
    		Row r = (Row)it.next();
    		linkNameArray.add((String)r.get(linkNameColumn));
    	}	
		return linkNameArray;
	}
	public static Boolean verifyLinkName(String tableName, String linkNameColumn, Criteria c2, String linkName) throws Exception
	{
		if(ZABUtil.containsSpecialChars(linkName)){
			return false;}
		if(ZABUtil.containsSpace(linkName)){
			return false;}
		Criteria c1 = new Criteria(new Column(tableName,linkNameColumn),linkName,QueryConstants.EQUAL);
		Criteria c=c1.and(c2);
		ArrayList<String> linkNameArray = getLinkName(tableName,linkNameColumn,c);
		if(linkNameArray.isEmpty()){
			return true;}
		else{
			throw new ZABException(ZABConstants.ErrorMessages.LINK_NAME_ERROR);
			
			}
	}	
	public static DataObject getPersonality(String personalityName, Criteria c) throws Exception
	{
		Persistence per= ZABUtil.getPersistenceBean(); 	        
	    return per.getForPersonality(personalityName, c);   //No I18N 
	    
	}
	
	protected static void setModelWithRNFData(ZABModel model, ResourceNotFoundException re) {
		model.setSuccess(Boolean.FALSE);
		model.setResponseCode(re.getErrorCode());
		model.setResponseString(re.getMessage());
	}
	
	/**
	 * Checks if resource with displayName exists within project
	 * @param tableName
	 * @param columnName
	 * @param displayName
	 * @param projectId
	 * @return boolean
	 * @throws Exception 
	 */
	protected static boolean isResourceExistsInProject(String tableName, String columnName, String displayName, String projectIdColumnName, Long projectId, Criteria c) throws Exception {
		Criteria c1 = new Criteria(new Column(tableName, columnName), displayName, QueryConstants.EQUAL);
		Criteria c2 = new Criteria(new Column(tableName, projectIdColumnName), projectId, QueryConstants.EQUAL);
		return resourceExists(tableName, c1.and(c2).and(c));
	}
	
	protected static ArrayList<Column> getColumnsWithAliasPrefix(List<Constants> listConstants, String prefix, String tableName) {
		int size = listConstants.size();
		ArrayList<Column> columns = new ArrayList<Column>();
		for(int i=0; i<size; i++) {
			Constants constant = listConstants.get(i);
			constant.getDatabaseName();
			Column experimentCols = new Column(tableName, constant.getDatabaseName(),prefix+constant.getDatabaseName());
			columns.add(experimentCols);
		}
		return columns;
	}
	
	public static  <T extends ZABModel> T getModelFromRow(Row row, Class cls) throws InstantiationException, IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException, JSONException {
		Object model =  cls.newInstance();
		for(Field field : cls.getDeclaredFields()){
			  Class type = field.getType();
			  String name = field.getName();
			  Boolean isColumnValPresent = field.isAnnotationPresent(ZABColumn.class);
			  if(isColumnValPresent) {
				  ZABColumn column = field.getAnnotation(ZABColumn.class);
				  String columnName = column.name();
				  String setter = "set" + name.substring(0, 1).toUpperCase() + name.substring(1);
				  Method method = cls.getMethod(setter, type);
				  Object value = row.get(columnName);
				  
				  //Handling special cases for json
				  //Case - To enjoy the support of mickey, in some cases we are saving json as string. So it is converted in retrieval
				  if(value!=null) {
					  if(type.getName().equals(JSONObject.class.getName())) {
						  value = new JSONObject((String) value);
					  } else if(type.getName().equals(JSONArray.class.getName())) {
						  value = new JSONArray((String) value);
					  }
					  method.invoke(model, value);  
				  }
			  }
		}
		return (T)model;
	}
	
	public static  <T extends ZABModel> ArrayList<T> getModelsFromDobj(DataObject dobj, String tableName, Class cls, Boolean success) throws InstantiationException, IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException, DataAccessException, JSONException {
		return getModelsFromDobj(dobj, tableName, cls, success, null);
	}
	
	public static  <T extends ZABModel> ArrayList<T> getModelsFromDobj(DataObject dobj, String tableName, Class cls, Boolean success, ForEachRowConsumer con) throws InstantiationException, IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException, DataAccessException, JSONException {
		ArrayList<T> models = new ArrayList<T>();
		if(dobj.containsTable(tableName)) {
			Iterator it = dobj.getRows(tableName);
			while(it.hasNext()) {
				Row row = (Row)it.next();
				T mod = (T) getModelFromRow(row, cls);
				if(con!=null) {
					con.execute(dobj, row, mod);
				}
				mod.setSuccess(success);
				models.add(mod);
			}
		}
		return models;
	}
	
	public static  <T extends ZABModel> T getFirstModelFromDobj(DataObject dobj, String tableName, Class cls) throws InstantiationException, IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException, DataAccessException, JSONException {
		T model = null;
		if(dobj.containsTable(tableName)) {
			model = getModelFromRow(dobj.getFirstRow(tableName), cls);
		}
		return model;
	}
	
	public <T extends ZABModel> void extractValues(T a) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		Class<T> cls = (Class<T>) a.getClass();
		for(Field field : cls.getDeclaredFields()){
			  Class type = field.getType();
			  String name = field.getName();
			  Boolean isColumnValPresent = field.isAnnotationPresent(ZABColumn.class);
			  if(isColumnValPresent) {
				  String getter = "get" + name.substring(0, 1).toUpperCase() + name.substring(1); //NO I18N
				  String setter = "set" + name.substring(0, 1).toUpperCase() + name.substring(1); //NO I18N
				  Method getterMethod = cls.getMethod(getter);
				  Method setterMethod = cls.getMethod(setter, type);
				  Object value = getterMethod.invoke(a);
				  setterMethod.invoke(this, value);
			  }
		}
	}
	
	public <T extends ZABModel> void saveRecord() throws Exception {
		Class<T> cls  = (Class<T>) this.getClass();
		if(cls.isAnnotationPresent(ZABTable.class)) {
			ZABTable table = cls.getAnnotation(ZABTable.class);
			String tableName = table.name();
			DataObject dobj = new WritableDataObject();
			Row row = new Row(tableName);
			for(Field field : cls.getDeclaredFields()){
				  Class type = field.getType();
				  String name = field.getName();
				  Boolean isColumnValPresent = field.isAnnotationPresent(ZABColumn.class);
				  if(isColumnValPresent) {
					  ZABColumn column = field.getAnnotation(ZABColumn.class);
					  String columnName = column.name();
					  String getter = "get" + name.substring(0, 1).toUpperCase() + name.substring(1); //NO I18N
					  Method method = cls.getMethod(getter);
					  Object value = method.invoke(this);
					  if(value!=null) {						  
						  row.set(columnName, value);
					  }
				  }
			}
			dobj.addRow(row);
			updateDataObject(dobj);
			T model = getModelFromRow(row, this.getClass());
			this.extractValues(model);
		}
	}
	
}
