//$Id$
package com.zoho.abtest.common;


import java.util.HashSet;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.utility.ZABUtil;

public class ZABResponse {
	
	private static final Logger LOGGER = Logger.getLogger(ZABResponse.class.getName());
	
	public static JSONObject updateMetaInfo(HttpServletRequest request,String moduleName, JSONArray array) throws JSONException, NumberFormatException
	{
		Integer count = array.length(),successCount=0;
		JSONObject jsonParent = new JSONObject();
		Set<String> statusCodes = new HashSet<String>();
		for(int i=0;i<count;i++){
			JSONObject json = array.getJSONObject(i);
			if(json.has(ZABConstants.SUCCESS)&&json.getBoolean(ZABConstants.SUCCESS))
			{
				successCount++;
			}
			if(json.has(ZABConstants.STATUS_CODE)) {
				statusCodes.add(json.getString(ZABConstants.STATUS_CODE));
			}
		}		
		if((ZABUtil.isIndividualResourceRequest()) && (count==0 || statusCodes.contains(ZABConstants.ErrorMessages.RESOURCE_NOT_FOUND.getErrorCode())))
		{
			jsonParent.put(ZABConstants.STATUS_CODE, ZABConstants.ErrorMessages.RESOURCE_NOT_FOUND.getErrorCode());
			jsonParent.put(ZABConstants.STATUS_STRING, ZABAction.getMessage(ZABConstants.ErrorMessages.RESOURCE_NOT_FOUND.getErrorString(), new String[]{moduleName}));
		}
		else if(count.equals(successCount))
		{
			jsonParent.put(ZABConstants.STATUS_CODE, ZABConstants.ErrorMessages.API_ALL_SUCCESS.getErrorCode());
			jsonParent.put(ZABConstants.STATUS_STRING, ZABAction.getMessage(ZABConstants.ErrorMessages.API_ALL_SUCCESS.getErrorString()));
		}else if(successCount==0){			
			if(count==successCount)
			{
				jsonParent.put(ZABConstants.STATUS_CODE, ZABConstants.ErrorMessages.READ_LIMIT_EXCEEDED.getErrorCode());
				jsonParent.put(ZABConstants.STATUS_STRING,ZABAction.getMessage(ZABConstants.ErrorMessages.READ_LIMIT_EXCEEDED.getErrorString()));
			}else{
				jsonParent.put(ZABConstants.STATUS_CODE, ZABConstants.ErrorMessages.API_ALL_FAILURE.getErrorCode());
				jsonParent.put(ZABConstants.STATUS_STRING,ZABAction.getMessage(ZABConstants.ErrorMessages.API_ALL_FAILURE.getErrorString()));
			}			
		}else{
			jsonParent.put(ZABConstants.STATUS_CODE,ZABConstants.ErrorMessages.API_PARTIAL_SUCCESS.getErrorCode());
			jsonParent.put(ZABConstants.STATUS_STRING, ZABAction.getMessage(ZABConstants.ErrorMessages.API_PARTIAL_SUCCESS.getErrorString()));
		}
		Boolean paginate = (Boolean)request.getAttribute(ZABConstants.PAGINATION);
		if(paginate!=null&&paginate)
		{			
			jsonParent.put(ZABConstants.PAGINATION,  setPagination(array.length()));
		}	
		String sortby = (String) request.getAttribute(ZABConstants.SORT_BY);
		if(sortby!=null) {
			jsonParent.put(ZABConstants.SORT_BY,sortby);
		}
		String sortorder = (String) request.getAttribute(ZABConstants.SORT_ORDER);
		if(sortorder!=null) {
			jsonParent.put(ZABConstants.SORT_ORDER,sortorder);
		}
		jsonParent.put(moduleName, array);
		jsonParent.put(ZABConstants.COUNT, count);
		
		if(ZABUtil.getCurrentRequest()!=null)
		{
		Long startTime = (Long)ZABUtil.getCurrentRequest().getAttribute("RequestStartTime");		
		if(startTime!=null)
		{
		Long endTime = ZABUtil.getCurrentTimeInMilliSeconds();
		jsonParent.put(ZABConstants.TIME_TAKEN, endTime-startTime+" ms");
		LOGGER.log(Level.INFO, "Request ends - End Time:"+endTime+", Total time taken:"+(endTime-startTime)+"ms");
		}
		
		jsonParent.put(ZABConstants.CREATE_COUNT, ZABUtil.getDBCallCountMap().get(ZABConstants.CREATE_COUNT));
		jsonParent.put(ZABConstants.UPDATE_COUNT, ZABUtil.getDBCallCountMap().get(ZABConstants.UPDATE_COUNT));
		jsonParent.put(ZABConstants.READ_COUNT, ZABUtil.getDBCallCountMap().get(ZABConstants.READ_COUNT));
		jsonParent.put(ZABConstants.DELETE_COUNT, ZABUtil.getDBCallCountMap().get(ZABConstants.DELETE_COUNT));
		}
		return jsonParent;
	}
	public static JSONObject setPagination(int currentCount) throws NumberFormatException, JSONException
	{
		HttpServletRequest request = null;
		request = ZABUtil.getCurrentRequest();
		JSONObject paginateJson = new JSONObject();			
		String requestUrl = request.getRequestURL().append('?').append(request.getQueryString()).toString();	
		if(requestUrl.contains("startfrom"))
		{
			requestUrl = requestUrl.replaceAll("[&?]startfrom.*?(?=&|\\?|$)", "");//NO I18n
		}
		if(requestUrl.contains("limit"))
		{
			requestUrl = requestUrl.replaceAll("[&?]limit.*?(?=&|\\?|$)", "");//NO I18n
		}
		String nextUrl = null;
		String previousUrl= requestUrl;	
		String totalCount = (String)request.getAttribute(ZABConstants.TOTAL_COUNT);
		String startFrom = (String)request.getAttribute(ZABConstants.START_FROM);
		String limit = (String)request.getAttribute(ZABConstants.OFFSET);				
		if(Long.parseLong(startFrom)-Long.parseLong(limit)>0)
		{
			Long newStartingFrom = Long.parseLong(startFrom)-Long.parseLong(limit);
			newStartingFrom = newStartingFrom<0?0l:newStartingFrom;					
			if(requestUrl.contains("?")){
				previousUrl= requestUrl+"&startfrom="+newStartingFrom+"&limit="+limit;//No I18N
			}else{
				previousUrl= requestUrl+"?startfrom="+newStartingFrom+"&limit="+limit;//No I18N
			}
		}
		if(Long.parseLong(startFrom)+Long.parseLong(limit)<=Long.parseLong(totalCount))
		{
			if(requestUrl.contains("?")){
				nextUrl = requestUrl+"&startfrom="+(Long.parseLong(startFrom)+Long.parseLong(limit))+"&limit="+limit;		//No I18N
			}else{
				nextUrl = requestUrl+"?startfrom="+(Long.parseLong(startFrom)+Long.parseLong(limit))+"&limit="+limit;		//No I18N
			}
			
		}
		if(limit.equals("1")){
			paginateJson.put(ZABConstants.PAGE_COUNT,  ((Long.parseLong(startFrom)/Long.parseLong(limit))));
		}else{
			paginateJson.put(ZABConstants.PAGE_COUNT,  ((Long.parseLong(startFrom)/Long.parseLong(limit))+1));
		}
		
		paginateJson.put(ZABConstants.COUNT, new Long(currentCount));
		paginateJson.put(ZABConstants.START_FROM, Long.parseLong(startFrom));
		
		
		if(!((Long)paginateJson.get(ZABConstants.PAGE_COUNT)==1)){
			paginateJson.put(ZABConstants.PREVIOUS_URL,  previousUrl);
		}
		
		if(nextUrl!=null) {
			paginateJson.put(ZABConstants.NEXT_URL,  nextUrl);
		}
		
			
		return paginateJson;
	}
}
