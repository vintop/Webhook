//$Id$
package com.zoho.abtest.misc;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.sas.util.DBUtil;
import com.zoho.abtest.utility.ApplicationProperty;


public class InstrumentationUpdate {
	private static final Logger LOGGER = Logger.getLogger(InstrumentationUpdate.class.getName());
	public static void updateInstrrumentation(){

		try       
		{               
			String propvalue = ApplicationProperty.getString("com.zoho.abtest.instrumentation");
			com.adventnet.sas.ds.SASThreadLocal.setToMainDatabase();       
			DBUtil.executeUpdate("update GridConfiguration set PROPVAL='"+propvalue+"' where PROPNAME='monitoring-domain-name'"); // NO I18N
		}       
		catch(Exception ex )      
		{         
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}      
	}
}
