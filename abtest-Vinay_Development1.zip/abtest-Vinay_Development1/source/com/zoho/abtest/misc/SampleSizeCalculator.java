//$Id$
package com.zoho.abtest.misc;

import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.math3.distribution.NormalDistribution;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.VARIATION;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.report.CumulativeReportConstants;

public class SampleSizeCalculator extends ZABModel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = Logger.getLogger(SampleSizeCalculator.class.getName());
	private Long visitorsRequired;
	private Long noOfDays;

	public Long getVisitorsRequired() {
		return visitorsRequired;
	}

	public void setVisitorsRequired(Long visitorsRequired) {
		this.visitorsRequired = visitorsRequired;
	}
	
	public Long getNoOfDays() {
		return noOfDays;
	}

	public void setNoOfDays(Long noOfDays) {
		this.noOfDays = noOfDays;
	}
	
	public static SampleSizeCalculator calculateSampleSize(HashMap<String,String> hs){
		Double expectedImprovement = Double.parseDouble(hs.get(CumulativeReportConstants.EXPECTED_IMPROVEMENT));
		Double conversion_rate = Double.parseDouble(hs.get(CumulativeReportConstants.CONVERSION_RATE));
		
		Integer dailyVisitors  = null;
		String expLinkName = null;
		if(hs.containsKey(CumulativeReportConstants.DAILY_VISITORS)){
			 dailyVisitors  = Integer.parseInt(hs.get(CumulativeReportConstants.DAILY_VISITORS));
		}
		if(hs.containsKey(ExperimentConstants.EXPERIMENT_LINKNAME)){
			expLinkName  =hs.get(ExperimentConstants.EXPERIMENT_LINKNAME);
		}
		Integer significance  = Integer.parseInt(hs.get(ExperimentConstants.STATISTICAL_SIGNIFICANCE));
		return	calculateSampleSize(expectedImprovement,conversion_rate,dailyVisitors, expLinkName,significance);
	}
	/*  Improvement is relative,  with baseline conversion rate of 20 and improvement of 10 , then the conversion rate is on the range of 18-22% */
	public static SampleSizeCalculator calculateSampleSize(Double improvement, Double conversionRate, Integer dailyVisitors, String  expLinkName, Integer expSignificance){
		
		//improvement/=100;
		//conversionRate/=100;
		Double result = 0d;
		
		if(conversionRate > 1){
			result  = conversionRate*(1-conversionRate);
			if(result<0){
				result*=-1;
			}
			result= Math.sqrt(result);
			result = result/(conversionRate*improvement);
			result = Math.pow(result, 2d);
			result*=16;
		}
		
		
		Double Significance = (double) expSignificance/100.0;
		Significance = 1.0-Significance;
		if(improvement<0){
			improvement = improvement*-1;
		}
	
		double delta =  improvement * conversionRate;
		NormalDistribution nd = new NormalDistribution(0,1);
		if (conversionRate > 0.5) {
			conversionRate = 1.0 - conversionRate;
		}


		double t_alpha2 = nd.inverseCumulativeProbability(1.0-Significance/2);
		double t_beta = nd.inverseCumulativeProbability(0.8);

		double sd1 = Math.sqrt(2 * conversionRate * (1.0 - conversionRate));
		double sd2 = Math.sqrt(conversionRate * (1.0 - conversionRate) + (conversionRate + delta) * (1.0 - conversionRate - delta));

		result =(t_alpha2 * sd1 + t_beta * sd2) * (t_alpha2 * sd1 + t_beta * sd2) / (delta * delta);
		result = (double) Math.round(result);
		
		try{
			if(expLinkName!=null){
				Integer noOfVariations= 0;
				Criteria c = new Criteria (new Column(EXPERIMENT.TABLE,EXPERIMENT.EXPERIMENT_LINK_NAME),expLinkName , QueryConstants.EQUAL);
				Join join = new Join(VARIATION.TABLE,EXPERIMENT.TABLE, new String[]{VARIATION.EXPERIMENT_ID}, new String[]{EXPERIMENT.EXPERIMENT_ID},Join.INNER_JOIN);
				DataObject dobj = ZABModel.getRow(VARIATION.TABLE, c, join);
				Iterator <?> itr = dobj.getRows(VARIATION.TABLE);
				while(itr.hasNext()){
					itr.next();
					noOfVariations++;

				}
				result= result*noOfVariations;
			}
			
		}catch(Exception e ){
			LOGGER.log(Level.SEVERE, "Exception occured:", e);
		}
		
		SampleSizeCalculator sizeCalc= new SampleSizeCalculator();
		sizeCalc.setVisitorsRequired(Math.round(result));
		if(dailyVisitors != null &&  dailyVisitors > 0){
			Long days =  Math.round(result/dailyVisitors);
			if(days == 0){
				days++;
			}
			sizeCalc.setNoOfDays(days);
		}
		sizeCalc.setSuccess(Boolean.TRUE);
		return sizeCalc;
	
	}
	/*public static SampleSizeCalculator calculateSampleSizeAbsolute(Double improvement, Double conversionRate, Integer dailyVisitors, String  expLinkName){
		SampleSizeCalculator sizeCalc  = new SampleSizeCalculator();
		sizeCalc = calculateSampleSize(improvement/conversionRate,conversionRate,dailyVisitors, expLinkName);
		return sizeCalc;
	}*/

}
