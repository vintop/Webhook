//$Id$
package com.zoho.abtest.misc;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.json.JSONException;

import com.opensymphony.xwork2.ActionSupport;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.report.CumulativeReportConstants;
import com.zoho.abtest.report.ReportStatistics;
import com.zoho.abtest.utility.ZABUtil;

public class SampleSizeCalculatorAction extends ActionSupport implements ServletResponseAware, ServletRequestAware{

	private static final long serialVersionUID = 1L;
	private HttpServletRequest request;
	private HttpServletResponse response;
	private static final Logger LOGGER = Logger.getLogger(SampleSizeCalculatorAction.class.getName());

	public void setServletRequest(HttpServletRequest request) {
		this.request=request;
	}

	
	public void setServletResponse(HttpServletResponse response) {
		this.response= response;
		
	}
	
	public String execute() throws IOException, JSONException {
		HashMap<String,String> hs;
		ArrayList<SampleSizeCalculator> visitorRequiredArray = new ArrayList<SampleSizeCalculator>();
		
		try {			
 			switch(ZABAction.getHTTPMethod(request)) {
			case POST:
				
				hs = ZABAction.getRequestParser(request).parseSampleSize(request);
					if(hs.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
						SampleSizeCalculator sizeCalc = new SampleSizeCalculator();
						sizeCalc.setSuccess(Boolean.FALSE);
						sizeCalc.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
						visitorRequiredArray.add(sizeCalc);
					}else{
						visitorRequiredArray.add(SampleSizeCalculator.calculateSampleSize(hs));
					}
				
				
				break;
 			}
 		}catch(Exception e){
 			LOGGER.log(Level.SEVERE, "Exception occured: ",e);
 			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), CumulativeReportConstants.SAMPLE_SIZE));
			return null; 	
		
				
		}
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getSampleSizeResponse(request, visitorRequiredArray));		
		   
		return null;
	}
	
	
	
}
