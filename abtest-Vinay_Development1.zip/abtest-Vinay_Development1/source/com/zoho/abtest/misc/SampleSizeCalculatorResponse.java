//$Id$
package com.zoho.abtest.misc;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;
import com.zoho.abtest.report.CumulativeReportConstants;

public class SampleSizeCalculatorResponse {
	
	private static final Logger LOGGER = Logger.getLogger(SampleSizeCalculatorResponse.class.getName());

	public static String jsonResponse(HttpServletRequest request,ArrayList<SampleSizeCalculator> lst) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(lst);			
			JSONObject json = ZABResponse.updateMetaInfo(request, CumulativeReportConstants.SAMPLE_SIZE, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE, "Exception occured: ",ex);
		}
		return returnBuffer.toString();
	}

	public static JSONArray getJSONArray(ArrayList<SampleSizeCalculator> lst) throws JSONException {
		JSONArray array = new JSONArray();
		int size =lst.size();
		for (int i=0;i<size;i++) {
			SampleSizeCalculator ld=lst.get(i);
			JSONObject jsonObj = new JSONObject();

			jsonObj.put(CumulativeReportConstants.VISITORS_REQUIRED, ld.getVisitorsRequired());
			jsonObj.put(CumulativeReportConstants.DAYS_REQUIRED, ld.getNoOfDays());
			jsonObj.put(ZABConstants.SUCCESS, ld.getSuccess());


			array.put(jsonObj);
		}
		return array;
	}


}
