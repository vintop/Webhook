//$Id$
package com.zoho.abtest.misc;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;

import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABRequest;
import com.zoho.abtest.report.CumulativeReportConstants;

public class SampleSizeCalculatorRequest  extends ZABRequest{

	public void updateFromRequest(HashMap<String, String> map,
			HttpServletRequest request) {
		

	}

	
	
	public void specificValidation(HashMap<String, String> map, HttpServletRequest request) throws IOException, JSONException { 
		String httpMethod = ZABAction.getHTTPMethod(request).toString();
		if(httpMethod.equalsIgnoreCase("POST")){
			ArrayList<String> fields = new ArrayList<String>();
			if(!(map.containsKey(CumulativeReportConstants.CONVERSION_RATE) &&map.containsKey(CumulativeReportConstants.EXPECTED_IMPROVEMENT))) {
				if(!map.containsKey(CumulativeReportConstants.CONVERSION_RATE)) { fields.add(CumulativeReportConstants.CONVERSION_RATE);}
				if(!map.containsKey(CumulativeReportConstants.EXPECTED_IMPROVEMENT)) { fields.add(CumulativeReportConstants.EXPECTED_IMPROVEMENT);}
				ZABRequest.updateError(map, ZABAction.getAppropriateMessage(ZABConstants.ErrorMessages.MANDATORY_FIELD_MISSING.getErrorString(),fields));

			}

		}
	}


}
