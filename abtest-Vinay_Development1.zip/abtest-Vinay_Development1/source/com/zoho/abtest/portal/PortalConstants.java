//$Id$
package com.zoho.abtest.portal;

import com.zoho.abtest.utility.ApplicationProperty;

public class PortalConstants 
{
	public static final String API_MODULE = "portal"; //No I18N
	public static final String API_MODULE_PLURAL = "portals"; //No I18N
	
	public static final String PORTALNAME = "portalname"; //No I18N
	public static final String DOMAINNAME = "domainname"; //No I18N
	public static final String ZSOID = "zsoid"; //No I18N
	public static final String CREATEDBY = "createdby"; //No I18N
	public static final String CREATEDBYNAME = "createdbyname"; //No I18N
	public static final String CREATEDTIME = "createdtime"; //No I18N
	public static final String CREATEDDATE = "createddate"; //No I18N
	public static final String ISDEFAULT = "isdefault"; //No I18N
	public static final String DBSPACEID = "dbspaceid"; //No I18N
	public static final String ISSIGNUP = "issignup"; //No I18N
	public static final String ISZOHOONE = "iszohoone"; //No I18N
	public static final String ZOHOONE_USERINVITE_LINK = "zohoone_userinvite_link"; //No I18N
	public static final String ZOHOONE_CAN_SHOW_LAUNCHER = "zohoone_can_show_launcher"; //No I18N
	public static final String ZOHOONE_LAUNCHER_URL = "zohoone_launcher_url"; //No I18N
	public static final String SUBSCRIPTION_LINK = "subscription_link"; //No I18N
	public static final String PLAN_NAME = "plan_name"; //No I18N
	public static final String IS_APP_ACTIVE = "is_app_active"; //No I18N
	
	public static final String DEFAUT_PORTALNAME_LABEL = "My Space"; //No I18N
	
	public static final String PORTAL_ALREADY_EXISTS = "portal.exists"; //No I18N
	public static final String PORTAL_DISPLAYNAME_ALREADY_EXISTS = "portal.displayname.exists"; //No I18N
	public static final String PORTAL_ADMIN_ERROR = "portal.admin.error"; //No I18N
	
	public static final int PORTAL_DOMAIN_LENGTH = 8;
	
	public static final int PORTAL_DOMAIN_INTERNAL_CHECK = ApplicationProperty.getInteger("com.abtest.domain.internal.check"); //No I18N
	public static final int DAYS_COUNT_AFTER_DELETE = ApplicationProperty.getInteger("days.datapersist.afterdelete"); //No I18N
	
	public static final String API_SERVICE_MODULE = "service"; //No I18N
	public static final String API_RESOURCE = "resource.integration"; //NO I18N
	public static final String API_RESOURCE_INITIAL = "resource.sites.initial"; //NO I18N
	public static final String PROJECTNAME = "projectname"; //No I18N
	public static final String PROJECTKEY = "projectKey"; //No I18N
	public static final String PROJECTID = "projectId"; //No I18N
	public static final String PROJECTSCRIPTURL = "projectscripturl"; //No I18N

	
	
}



