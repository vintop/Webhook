//$Id$
package com.zoho.abtest.portal;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;

import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABRequest;
//import com.zoho.abtest.integration.SitesConstants;

public class PortalRequest extends ZABRequest
{
	@Override
	public void updateFromRequest(HashMap<String, String> map, HttpServletRequest request) 
	{
		String linkName = (String)request.getAttribute(PortalConstants.PORTALNAME);
		if(linkName!=null) {			
			map.put(PortalConstants.PORTALNAME, linkName);
		}
	}
	
	@Override
	public void specificValidation(HashMap<String, String> map, HttpServletRequest request) throws IOException, JSONException 
	{
		ArrayList<String> fields = new ArrayList<String>();
		String httpMethod = ZABAction.getHTTPMethod(request).toString();
		if(httpMethod.equalsIgnoreCase("POST")){
			if(isNullOrEmpty(map, PortalConstants.PORTALNAME)){
				fields.add(PortalConstants.PORTALNAME);
			}
			/*if(!map.containsKey(PortalConstants.DOMAINNAME))
			{
				fields.add(PortalConstants.DOMAINNAME);
			}*/
		}
		else if(httpMethod.equalsIgnoreCase("PUT")){
			/*if(!map.containsKey(PortalConstants.ZSOID)){
				fields.add(PortalConstants.ZSOID);
			}*/
			if(!map.containsKey(PortalConstants.PORTALNAME)){
				fields.add(PortalConstants.PORTALNAME);
			}
		}
		if(!fields.isEmpty()) {
			ZABRequest.updateError(map, ZABAction.getAppropriateMessage(ZABConstants.ErrorMessages.MANDATORY_FIELD_MISSING.getErrorString(),fields));
		}
	}
}
