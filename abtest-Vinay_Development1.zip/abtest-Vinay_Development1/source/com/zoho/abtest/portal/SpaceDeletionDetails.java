//$Id$
package com.zoho.abtest.portal;

import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.SPACE_DELETION_DETAILS;
import com.zoho.abtest.adminconsole.AdminConsoleConstants;
import com.zoho.abtest.adminconsole.AdminConsoleWrapper;
import com.zoho.abtest.adminconsole.AdminConsoleConstants.AcOperationType;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.elastic.ElasticSearchIndexConstants;
import com.zoho.abtest.listener.ZABNotifier;
import com.zoho.abtest.utility.ZABUtil;

public class SpaceDeletionDetails extends ZABModel
{
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(SpaceDeletionDetails.class.getName());
	
	private Long spaceDeletionDetailsId;
	private Long zsoid;
	private String portalName;
	private Long deletionTime;
	private Boolean isDataRemoved;
	
	public Long getSpaceDeletionDetailsId() {
		return spaceDeletionDetailsId;
	}
	public void setSpaceDeletionDetailsId(Long spaceDeletionDetailsId) {
		this.spaceDeletionDetailsId = spaceDeletionDetailsId;
	}
	public Long getZsoid() {
		return zsoid;
	}
	public void setZsoid(Long zsoid) {
		this.zsoid = zsoid;
	}
	public String getPortalName() {
		return portalName;
	}
	public void setPortalName(String portalName) {
		this.portalName = portalName;
	}
	public Long getDeletionTime() {
		return deletionTime;
	}
	public void setDeletionTime(Long deletionTime) {
		this.deletionTime = deletionTime;
	}
	public Boolean getIsDataRemoved() {
		return isDataRemoved;
	}
	public void setIsDataRemoved(Boolean isDataRemoved) {
		this.isDataRemoved = isDataRemoved;
	}
	
	public static void createSpaceDeletionDetails(HashMap<String, String> hs)
	{
		try
		{
			ZABModel.createRow(ElasticSearchIndexConstants.SPACE_DELETION_DETAILS_CONSTANTS, SPACE_DELETION_DETAILS.TABLE, hs);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
	}
	
	public static void updateSpaceDeletionDetails(Long spaceDeletionDetailsId, HashMap<String, String> hs)
	{
		try
		{
			Criteria c1  = new Criteria(new Column(SPACE_DELETION_DETAILS.TABLE, SPACE_DELETION_DETAILS.SPACE_DELETION_DETAILS_ID), spaceDeletionDetailsId, QueryConstants.EQUAL);
			ZABModel.updateRow(ElasticSearchIndexConstants.SPACE_DELETION_DETAILS_CONSTANTS, SPACE_DELETION_DETAILS.TABLE, hs, c1, null, true);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
	}
	
	public static void deleteSpaceDeletionDetails(Long zsoid)
	{
		try
		{
			Criteria c1  = new Criteria(new Column(SPACE_DELETION_DETAILS.TABLE, SPACE_DELETION_DETAILS.ZSOID), zsoid, QueryConstants.EQUAL);
			ZABModel.deleteRow(SPACE_DELETION_DETAILS.TABLE, c1, null);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
	}
	
	public static SpaceDeletionDetails getSpaceDeletionDetails(Long zsoid)
	{
		SpaceDeletionDetails spaceDeletionDetails = null;
		try
		{
			Criteria c1  = new Criteria(new Column(SPACE_DELETION_DETAILS.TABLE, SPACE_DELETION_DETAILS.ZSOID), zsoid, QueryConstants.EQUAL);
			Row row = ZABModel.getFirstRow(SPACE_DELETION_DETAILS.TABLE, c1);
			spaceDeletionDetails = getSpaceDeletionDetailsFromRow(row);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		return spaceDeletionDetails;
	}
	
	public static void cleanupDeletedSpaceData()
	{
		try
		{
			Long timeToCheck = ZABUtil.getNthServerDayInLong(ZABUtil.getCurrentTimeInMilliSeconds(), -PortalConstants.DAYS_COUNT_AFTER_DELETE); 
			Criteria c1 = new Criteria(new Column(SPACE_DELETION_DETAILS.TABLE, SPACE_DELETION_DETAILS.IS_DATA_REMOVED), Boolean.FALSE, QueryConstants.EQUAL);
			Criteria c2 = new Criteria(new Column(SPACE_DELETION_DETAILS.TABLE, SPACE_DELETION_DETAILS.DELETED_TIME), timeToCheck, QueryConstants.LESS_EQUAL);
			DataObject dataObj = ZABModel.getRow(SPACE_DELETION_DETAILS.TABLE, c1.and(c2));
			Iterator<?> iter = dataObj.getRows(SPACE_DELETION_DETAILS.TABLE);
			while(iter.hasNext())
			{
				Row row = (Row)iter.next();
				SpaceDeletionDetails spaceDeletionDetails = getSpaceDeletionDetailsFromRow(row);
				try
				{
					cleanupSpaceData(spaceDeletionDetails);
				}
				catch(Exception ex)
				{
					LOGGER.log(Level.SEVERE, "Exception while deleting data for portal {0}",new String[]{spaceDeletionDetails.getZsoid().toString()});
					LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
	}
	
	public static void cleanupSpaceData(SpaceDeletionDetails spaceDeletionDetails) throws Exception
	{
		LOGGER.log(Level.INFO, "Deletion started for "+spaceDeletionDetails.getZsoid());
		PortalAction.dbSpaceDeletion(spaceDeletionDetails.getZsoid().toString(), spaceDeletionDetails.getPortalName());
		LOGGER.log(Level.INFO, "Deletion completed for "+spaceDeletionDetails.getZsoid());
		//Update the flag in DB
		HashMap<String, String> hs = new HashMap<String, String>();
		hs.put(ElasticSearchIndexConstants.IS_DATA_REMOVED, Boolean.TRUE.toString());
		SpaceDeletionDetails.updateSpaceDeletionDetails(spaceDeletionDetails.getSpaceDeletionDetailsId(), hs);
		//Remove from Admin console table
		HashMap<String, String> acHs = new HashMap<String, String>();
		acHs.put(AdminConsoleConstants.ZSOID, spaceDeletionDetails.getZsoid().toString());
		AdminConsoleWrapper acWrapper = new AdminConsoleWrapper();
		acWrapper.setValueHs(acHs);
		acWrapper.setOperationType(AcOperationType.PORTAL_DELETE);
		ZABNotifier.notifyListeners(AdminConsoleConstants.ADMIN_CONSOLE_MODULE_NAME,acWrapper);
	}
	
	public static SpaceDeletionDetails getSpaceDeletionDetailsFromRow(Row row)
	{
		SpaceDeletionDetails spaceDeletionDetails = new SpaceDeletionDetails();
		spaceDeletionDetails.setSpaceDeletionDetailsId((Long)row.get(SPACE_DELETION_DETAILS.SPACE_DELETION_DETAILS_ID));
		spaceDeletionDetails.setZsoid((Long)row.get(SPACE_DELETION_DETAILS.ZSOID));
		spaceDeletionDetails.setPortalName((String)row.get(SPACE_DELETION_DETAILS.PORTAL_NAME));
		spaceDeletionDetails.setDeletionTime((Long)row.get(SPACE_DELETION_DETAILS.DELETED_TIME));
		spaceDeletionDetails.setIsDataRemoved((Boolean)row.get(SPACE_DELETION_DETAILS.IS_DATA_REMOVED));
		return spaceDeletionDetails;
	}
	
}
