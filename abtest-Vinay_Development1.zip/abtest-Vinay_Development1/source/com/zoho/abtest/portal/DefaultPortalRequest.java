//$Id$
package com.zoho.abtest.portal;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;

import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABRequest;

public class DefaultPortalRequest extends ZABRequest
{
	@Override
	public void updateFromRequest(HashMap<String, String> map, HttpServletRequest request) 
	{
		
	}
	
	@Override
	public void specificValidation(HashMap<String, String> map, HttpServletRequest request) throws IOException, JSONException 
	{
		ArrayList<String> fields = new ArrayList<String>();
		String httpMethod = ZABAction.getHTTPMethod(request).toString();
		if(httpMethod.equalsIgnoreCase("POST")){
			if(!map.containsKey(PortalConstants.ZSOID)){
				fields.add(PortalConstants.ZSOID);
			}
			if(!fields.isEmpty()) {
				ZABRequest.updateError(map, ZABAction.getAppropriateMessage(ZABConstants.ErrorMessages.MANDATORY_FIELD_MISSING.getErrorString(),fields));
			}
		}
	}
}
