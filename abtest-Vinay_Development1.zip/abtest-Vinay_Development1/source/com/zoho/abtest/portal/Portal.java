//$Id$
package com.zoho.abtest.portal;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.RandomStringUtils;
import org.json.JSONObject;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.iam.IAMProxy;
import com.adventnet.iam.IAMUtil;
import com.adventnet.iam.ServiceOrg;
import com.adventnet.iam.User;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.PORTAL_LICENSE_MAPPING;
import com.zoho.abtest.PROJECT;
import com.zoho.abtest.adminconsole.AdminConsoleConstants;
import com.zoho.abtest.adminconsole.AdminConsoleConstants.AcOperationType;
import com.zoho.abtest.adminconsole.AdminConsoleWrapper;
import com.zoho.abtest.cdn.AWSCDN;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.filter.PageSenseOrgFilter;
import com.zoho.abtest.license.LicenseVerification;
import com.zoho.abtest.listener.ZABNotifier;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.project.ProjectJSONService;
import com.zoho.abtest.project.ProjectTreeEventConstants.Module;
import com.zoho.abtest.user.ZABUser;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUtil;

public class Portal extends ZABModel
{
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(Portal.class.getName());
	
	private String portalName;
	private String domainName;
	private Long zsoid;
	private Long createdBy;
	private String createdByName;
	private Long createdTime;
	private Boolean isDefault;
	private Boolean isSignUp;
	private String zohoOneUserInviteLink;
	private String subscriptionLink;
	private Boolean isZohoOne;
	private String planName;
	private String projectName;
	private String projectLinkName;
	private String projectKey;
	private Long projectId;
	private Boolean isAppActive;
	private int specialRefferer;
	private Boolean canShowOneLauncher;
	private String oneLauncherUrl;
	
	public Boolean getCanShowOneLauncher() {
		return canShowOneLauncher;
	}

	public void setCanShowOneLauncher(Boolean canShowOneLauncher) {
		this.canShowOneLauncher = canShowOneLauncher;
	}

	public String getOneLauncherUrl() {
		return oneLauncherUrl;
	}

	public void setOneLauncherUrl(String oneLauncherUrl) {
		this.oneLauncherUrl = oneLauncherUrl;
	}
	
	public int getSpecialRefferer() {
		return specialRefferer;
	}

	public void setSpecialRefferer(int specialRefferer) {
		this.specialRefferer = specialRefferer;
	}

	public Boolean getIsAppActive() {
		return isAppActive;
	}

	public void setIsAppActive(Boolean isAppActive) {
		this.isAppActive = isAppActive;
	}
	public Boolean getIsZohoOne() {
		return isZohoOne;
	}

	public void setIsZohoOne(Boolean isZohoOne) {
		this.isZohoOne = isZohoOne;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public String getSubscriptionLink() {
		return subscriptionLink;
	}

	public void setSubscriptionLink(String subscriptionLink) {
		this.subscriptionLink = subscriptionLink;
	}
	
	public String getZohoOneUserInviteLink() {
		return zohoOneUserInviteLink;
	}

	public void setZohoOneUserInviteLink(String zohoOneUserInviteLink) {
		this.zohoOneUserInviteLink = zohoOneUserInviteLink;
	}

	public Boolean getIsSignUp() {
		return isSignUp;
	}

	public void setIsSignUp(Boolean isSignUp) {
		this.isSignUp = isSignUp;
	}

	public String getCreatedByName() {
		return createdByName;
	}

	public void setCreatedByName(String createdByName) {
		this.createdByName = createdByName;
	}

	public Long getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Long createdTime) {
		this.createdTime = createdTime;
	}

	public Boolean isDefault() {
		return isDefault;
	}

	public void setDefault(Boolean isDefault) {
		this.isDefault = isDefault;
	}

	public String getPortalName() {
		return portalName;
	}

	public void setPortalName(String portalName) {
		this.portalName = portalName;
	}

	public String getDomainName() {
		return domainName;
	}

	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	public Long getZsoid() {
		return zsoid;
	}

	public void setZsoid(Long zsoid) {
		this.zsoid = zsoid;
	}

	public Long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}
	
	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	
	public String getProjectKey() {
		return projectKey;
	}

	public void setProjectKey(String projectKey) {
		this.projectKey = projectKey;
	}
	
	public Long getProjectId() {
		return projectId;
	}

	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}
	
	public String getProjectLinkName() {
		return projectLinkName;
	}

	public void setProjectLinkName(String projectLinkName) {
		this.projectLinkName = projectLinkName;
	}


	public static List<Portal> getUserPortals(Long zuid)
	{
		List<Portal> portalList = new ArrayList<Portal>();
		try
		{
			List<ServiceOrg> serviceOrgList = ZABServiceOrgUtil.getServiceOrgs(zuid);
			if(serviceOrgList != null)
			{
				Set<Long> userIds = new HashSet<Long>();
				HashMap<Long, User> userMap = new HashMap<Long, User>();
				for(ServiceOrg serviceOrg:serviceOrgList)
				{
					//if(serviceOrg.isEnabled())
					//{
						userIds.add(serviceOrg.getCreatedBy());
						Portal portal = getPortalFromServiceOrg(serviceOrg);
						portalList.add(portal);
					//}
				}
				
				//Get User names from IAM
				List<User> userList = IAMProxy.getInstance().getUserAPI().getUsers(userIds.toArray(new Long[userIds.size()]));
				for(User user:userList)
				{
					userMap.put(user.getZUID(), user);
				}
				for(Portal portal:portalList)
				{
					Long uid = portal.getCreatedBy();
					User userDetail = userMap.get(uid);
					String name = userDetail.getFirstName() + " " + userDetail.getLastName();
					portal.setCreatedByName(name);
				}
				
				//Default portal find and set
				Portal defaultPortal = getDefaultPortal(zuid);
				if(defaultPortal != null && defaultPortal.getZsoid() != null)
				{
					Long defaultPortalSoid = defaultPortal.getZsoid();
					for(Portal portal:portalList)
					{
						if(portal.getZsoid().equals(defaultPortalSoid))
						{
							portal.setDefault(true);
							break;
						}
					}
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			portalList = new ArrayList<Portal>();
		}
		return portalList;
	}
	
	public static int getUserPortalsCount(Long zuid)throws Exception
	{
		int portalCount = 0;
		List<ServiceOrg> serviceOrgList = ZABServiceOrgUtil.getAllServiceOrgs(zuid);
		if(serviceOrgList != null)
		{
			portalCount = serviceOrgList.size();
		}
		return portalCount;
	}
	
	//Note if u are changing anything in this method
	//Considering changing it in ZohoONeHandlerImpl also
	//As those created from ZohoOne callback will be called inn that class and will be reusing the same below methods there also
	public static Portal addPortal(HashMap<String,String> hs,Long zuid,HttpServletRequest request)
	{
		Portal portal = null;
		String serviceOrgName = hs.get(PortalConstants.PORTALNAME);
		try
		{
			boolean isNameAvailable = isUserPortalNameAvailable(serviceOrgName, zuid);
			if(!isNameAvailable)
			{
				portal = new Portal();
				portal.setPortalName(serviceOrgName);
				portal.setSuccess(Boolean.FALSE);
				portal.setResponseString(ZABAction.getMessage(PortalConstants.PORTAL_DISPLAYNAME_ALREADY_EXISTS));
				return portal;
			}
			
			Long zsoid = ZABServiceOrgUtil.addServiceOrg(serviceOrgName, zuid);
			
			String domainName = serviceOrgName.toLowerCase().replaceAll("[^a-z0-9]",""); //No I18N
			boolean isPortalExists = ZABServiceOrgUtil.isPortalExists(domainName);
			if(domainName.length() > 0 && !isPortalExists)
			{
				//Add the domain
				ZABServiceOrgUtil.addDomain(domainName, zsoid);
			}
			else
			{
				domainName = Portal.mapDomainToPortal(zsoid);
			}
			hs.put(PortalConstants.DOMAINNAME, domainName);
			boolean isdefault = false;
			if(hs.containsKey(PortalConstants.ISDEFAULT))
			{
				isdefault = Boolean.parseBoolean(hs.get(PortalConstants.ISDEFAULT));
				if(isdefault)
				{
					hs.put(PortalConstants.ZSOID, zsoid.toString());
					setDefaultPortal(hs, zuid);
				}
			}
			ServiceOrg serviceOrg = ZABServiceOrgUtil.getServiceOrg(zsoid);
			portal = getPortalFromServiceOrg(serviceOrg);
			if(isdefault)
			{
				portal.setDefault(isdefault);
			}
			
			String ipAddress = ZABUtil.getIpAddressFromRequest(request);
			
			HashMap<String, String> crmPotentialValues = PageSenseOrgFilter.getSignUpRequestCookiesForCrmPotentials(request);
			//Admin console record
			HashMap<String, String> acHs = new HashMap<String, String>();
			acHs.put(AdminConsoleConstants.ZSOID, portal.getZsoid().toString());
			acHs.put(AdminConsoleConstants.PORTAL_NAME, portal.getPortalName());
			acHs.put(AdminConsoleConstants.PORTAL_DOMAIN, portal.getDomainName());
			acHs.put(AdminConsoleConstants.CREATED_ZUID, zuid.toString());
			acHs.put(AdminConsoleConstants.CREATED_TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
			acHs.put(AdminConsoleConstants.IS_APP_SCREEN, Boolean.TRUE.toString());
			acHs.put(AdminConsoleConstants.IPADDRESS, ipAddress);
			PageSenseOrgFilter.copyPotentialValuesIntoACHs(crmPotentialValues, acHs);
			
			int specialReferrer = 0;
			if(crmPotentialValues.containsKey(PageSenseOrgFilter.FROM_PRODUCT_HUNT))
			{
				specialReferrer = 1;
			}
			else if(crmPotentialValues.containsKey(PageSenseOrgFilter.SWITCH_FROM_OPTIMIZELY))
			{
				specialReferrer = 2;
			}
			portal.setSpecialRefferer(specialReferrer);
			
			AdminConsoleWrapper acWrapper = new AdminConsoleWrapper();
			acWrapper.setValueHs(acHs);
			acWrapper.setOperationType(AcOperationType.PORTAL_CREATE);
			ZABNotifier.notifyListeners(AdminConsoleConstants.ADMIN_CONSOLE_MODULE_NAME,acWrapper);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			portal = new Portal();
			portal.setPortalName(serviceOrgName);
			portal.setSuccess(Boolean.FALSE);
		}
		return portal;
	}
	
	public static String mapDomainToPortal(Long zsoid)
	{
		boolean domainStatus = false;
		String domainName = null;
		try
		{
			while(!domainStatus)
			{
				domainName = RandomStringUtils.randomAlphanumeric(PortalConstants.PORTAL_DOMAIN_LENGTH).toLowerCase();
				boolean isPortalExists = ZABServiceOrgUtil.isPortalExists(domainName);
				if(!isPortalExists)
				{
					domainStatus = ZABServiceOrgUtil.addDomain(domainName, zsoid);
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		return domainName;
	}
	
	public static boolean isUserPortalNameAvailable(String portalName, long zuid)
	{
		boolean isAvailable = true;
		try
		{
			List<ServiceOrg> serviceOrgList = ZABServiceOrgUtil.getServiceOrgs(zuid);
			if(serviceOrgList != null)
			{
				for(ServiceOrg serviceOrg:serviceOrgList)
				{
					if(serviceOrg.getOrgName().equals(portalName))
					{
						isAvailable = false;
						break;
					}
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			isAvailable = true;
		}
		return isAvailable;
	}
	
	public static Portal updatePortal(HashMap<String,String> hs,String domainName, Long zuid)
	{
		Portal portal = null;
		boolean isUpdated = false;
		try
		{
			String newServiceOrgName = hs.get(PortalConstants.PORTALNAME);
			long zsoid = ZABServiceOrgUtil.getZSOIDFromDomain(domainName);
			
			//Validation
			boolean isAdmin = ZABServiceOrgUtil.isServiceOrgAdmin(zsoid, zuid);
			if(!isAdmin)
			{
				portal = new Portal();
				portal.setDomainName(domainName);
				portal.setPortalName(newServiceOrgName);
				portal.setSuccess(Boolean.FALSE);
				portal.setResponseString(ZABAction.getMessage(PortalConstants.PORTAL_ADMIN_ERROR));
				return portal;
			}
			
			
			boolean isNameAvailable = isUserPortalNameAvailable(newServiceOrgName, zuid);
			if(!isNameAvailable)
			{
				portal = new Portal();
				portal.setDomainName(domainName);
				portal.setPortalName(newServiceOrgName);
				portal.setSuccess(Boolean.FALSE);
				portal.setResponseString(ZABAction.getMessage(PortalConstants.PORTAL_DISPLAYNAME_ALREADY_EXISTS));
				return portal;
			}
			
			isUpdated = ZABServiceOrgUtil.updateServiceOrg(zsoid, newServiceOrgName);
			portal = new Portal();
			portal.setDomainName(domainName);
			portal.setZsoid(zsoid);
			portal.setPortalName(newServiceOrgName);
			portal.setSuccess(isUpdated);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			portal = new Portal();
			portal.setDomainName(domainName);
			portal.setSuccess(Boolean.FALSE);
		}
		return portal;
	}
	
	public static Portal setDefaultPortal(HashMap<String,String> hs, long zuid)
	{
		Portal portal = null;
		Long zsoid = Long.parseLong(hs.get(PortalConstants.ZSOID));
		String domainName = hs.get(PortalConstants.DOMAINNAME);
		try
		{
			ZABServiceOrgUtil.setDefaultPortal(zsoid, zuid);
			portal = new Portal();
			portal.setZsoid(zsoid);
			portal.setDomainName(domainName);
			portal.setDefault(Boolean.TRUE);
			portal.setSuccess(Boolean.TRUE);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			portal = new Portal();
			portal.setZsoid(zsoid);
			portal.setSuccess(Boolean.FALSE);
		}
		return portal;
	}
	
	public static Portal getDefaultPortal(long zuid) throws Exception
	{
		Portal portal = null;
		try
		{
			ServiceOrg serviceOrg = ZABServiceOrgUtil.getDefaultPortal(zuid);
			if(serviceOrg != null && serviceOrg.isEnabled())
			{
				portal = getPortalFromServiceOrg(serviceOrg);
				portal.setDefault(Boolean.TRUE);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			throw ex;
		}
		return portal;
	}
	
	public static Portal revertPortalDeletion(Long zsoid)
	{
		Portal portal = new Portal();
		try
		{
			ZABUtil.setDBSpace("sharedspace");	//No I18N
			SpaceDeletionDetails spaceDeletionDetails = SpaceDeletionDetails.getSpaceDeletionDetails(zsoid);
			if(spaceDeletionDetails != null)
			{
				if(spaceDeletionDetails.getIsDataRemoved().equals(Boolean.FALSE))
				{
					ZABServiceOrgUtil.enableServiceOrg(zsoid);
					SpaceDeletionDetails.deleteSpaceDeletionDetails(zsoid);
					portal.setSuccess(true);
					portal.setResponseString("Space will be accessible now !"); //NO I18N
				}
				else
				{
					portal.setSuccess(false);
					portal.setResponseString("Sorry! The requested portal has been cleaned up."); //NO I18N
				}
			}
			else
			{
				portal.setSuccess(false);
				portal.setResponseString("The requested portal is not in delete queue."); //NO I18N
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			portal.setSuccess(false);
			portal.setResponseString("Unknown error occurred."); //NO I18N
		}
		return portal;
	}
	
	public static Portal immediateDeletedSpaceCleanup(Long zsoid)
	{
		Portal portal = new Portal();
		try
		{
			ZABUtil.setDBSpace("sharedspace");	//No I18N
			SpaceDeletionDetails spaceDeletionDetails = SpaceDeletionDetails.getSpaceDeletionDetails(zsoid);
			if(spaceDeletionDetails != null)
			{
				if(spaceDeletionDetails.getIsDataRemoved().equals(Boolean.FALSE))
				{
					SpaceDeletionDetails.cleanupSpaceData(spaceDeletionDetails);
					portal.setSuccess(true);
					portal.setResponseString("Space details has been cleaned up !"); //NO I18N
				}
				else
				{
					portal.setSuccess(false);
					portal.setResponseString("FYI! The requested portal has been cleaned up already."); //NO I18N
				}
			}
			else
			{
				portal.setSuccess(false);
				portal.setResponseString("The requested portal is not in delete queue."); //NO I18N
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			portal.setSuccess(false);
			portal.setResponseString("Unknown error occurred."); //NO I18N
		}
		return portal;
	}
	
	public static Portal deletePortal(String domain, Long zsoid, Long zuid) throws Exception
	{
		Portal portal = new Portal();
		try
		{
			boolean isAdmin = ZABServiceOrgUtil.isServiceOrgAdmin(zsoid, zuid);
			if(isAdmin)
			{
				//Pause all running experiments
				LicenseVerification.pausePortalRunningExperiments(zsoid);
				//Delete scripts once license is expired
				Portal.deleteScriptsWithinPortal(zsoid);
				//Disable sorg in IAM
				boolean deleteStatus = ZABServiceOrgUtil.deleteServiceOrg(zsoid, domain);
				if(deleteStatus)
				{
					portal.setSuccess(Boolean.TRUE);
					portal.setDomainName(domain);
					portal.setZsoid(zsoid);
				}
				else
				{
					portal.setSuccess(Boolean.FALSE);
					portal.setDomainName(domain);
					portal.setZsoid(zsoid);
				}
			}
			else
			{
				portal.setSuccess(Boolean.FALSE);
				portal.setDomainName(domain);
				portal.setZsoid(zsoid);
				portal.setResponseString(ZABAction.getMessage(PortalConstants.PORTAL_ADMIN_ERROR));
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			portal.setSuccess(Boolean.FALSE);
			portal.setDomainName(domain);
			portal.setZsoid(zsoid);
			portal.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
		}
		return portal;
	}
	
	public static Portal getPortalFromServiceOrg(ServiceOrg serviceOrg)
	{
		Portal portal = new Portal();
		portal.setPortalName(serviceOrg.getOrgName());
		if(serviceOrg.getDomains() != null)
		{
			portal.setDomainName(serviceOrg.getDomains().get(0).getDomain());
		}
		portal.setZsoid(serviceOrg.getZSOID());
		portal.setCreatedBy(serviceOrg.getCreatedBy());
		portal.setCreatedTime(serviceOrg.getCreatedTime());
		portal.setDefault(Boolean.FALSE);
		portal.setSuccess(Boolean.TRUE);
		return portal;
	}
	
	public static ArrayList<Portal> getPortals()
	{
		Portal portal= null;
		ArrayList<Portal> portals = new ArrayList<Portal>();
		try{
			
			Long zuid = IAMUtil.getCurrentUser().getZUID();
			
			List<Portal> portallist = Portal.getUserPortals(zuid);
			for(Portal portal1:portallist)
			{	
				portal = new Portal();
				portal.setPortalName(portal1.getPortalName());
				portal.setDomainName(portal1.getDomainName());
				portal.setSuccess(Boolean.TRUE);
				portals.add(portal);
			}
			
	   }
	   catch(Exception e){
		   portal = new Portal();
		   portal.setSuccess(Boolean.FALSE);
		   portal.setResponseString(e.getMessage());
		   portals.add(portal);
		   LOGGER.log(Level.SEVERE,e.getMessage(),e);
        }
		return portals;
	}

	public static ArrayList<Portal> getProjects( String domainName, String portalName)
	{
		String existingDBSpace = ZABUtil.getDBSpace();
		Long zsoid = ZABServiceOrgUtil.getZSOIDFromDomain(domainName);
		ZABUtil.setDBSpace(zsoid.toString());
		
		
		ArrayList<Portal> portals = new ArrayList<Portal>();
		try{
			Long userId = ZABUser.getUserIdFromZuid(IAMUtil.getCurrentUser().getZUID());
			ArrayList<Project> projects = Project.getProjects(userId);
			for(Project project:projects)
			{
				Portal portal= new Portal();
				portal.setProjectName(project.getProjectName());
				portal.setProjectLinkName(project.getProjectLinkName());
				portal.setProjectId(project.getProjectId());
				portal.setPortalName(portalName);
				portal.setDomainName(domainName);
				portal.setProjectKey(project.getProjectKey());
				portal.setSuccess(Boolean.TRUE);
				portals.add(portal);
			}
			
			
	   }
	   catch(Exception e){
		    Portal portal= new Portal();
		    portal = new Portal();
		   	portal.setSuccess(Boolean.FALSE);
		   	portal.setResponseString(e.getMessage());
		   	portals.add(portal);
	    	LOGGER.log(Level.SEVERE,e.getMessage(),e);
        }
		ZABUtil.setDBSpace(existingDBSpace);
		return portals;
	}
	
	public static ArrayList<Portal> createServicePortal( String portalname, String projectname ,HttpServletRequest request ){
		
		Portal portal = new Portal();
		ArrayList<Portal> portals = new ArrayList<Portal>();
		try{
			HashMap<String,String> hs = new HashMap<String,String>();
			
			Long zuid = IAMUtil.getCurrentUser().getZUID();
			User iamUser = IAMUtil.getCurrentUser();
			
			hs.put(PortalConstants.PORTALNAME, portalname);
			
			PortalAction pa = new PortalAction();
			Portal portal1 = pa.createPortal(hs, zuid, request, iamUser, projectname);
			
			portals = Portal.getProjects(portal1.getDomainName(), portalname);
			
		}catch(Exception e){
		   	portal = new Portal();
		   	portal.setSuccess(Boolean.FALSE);
	    	portal.setResponseString(e.getMessage());
	    	portals.add(portal);
	    	LOGGER.log(Level.SEVERE,e.getMessage(),e);
        }
		
		return portals;
	}
	
	public static void regenerateScriptsinPortal(String zsoid) throws DataAccessException, Exception {
		Long zsoidL = Long.parseLong(zsoid);
		regenerateScriptsinPortal(zsoidL);
	}
	
	public static void onPortalLicenseResurrection(Long zsoid) {
		String existingDBSpace = ZABUtil.getDBSpace();
		try {
			LOGGER.log(Level.INFO, "Handling portal resuraction");
			//Regenrate all the scripts in the portal
			regenerateScriptsinPortal(zsoid);
			LOGGER.log(Level.INFO, "Handling portal resuraction success");
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Exception occured while handling PortalLicenseResuraction", e);
		} finally {
			ZABUtil.setDBSpace(existingDBSpace);
		}
	}
	
	
	public static void regenerateScriptsinPortal(Long zsoid) throws DataAccessException, Exception {
			
			ZABUtil.setDBSpace("sharedspace"); //NO I18N
			
			Criteria c = null;
			
			if(zsoid!=null) {				
				c = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.ZSOID), zsoid, QueryConstants.EQUAL);
			}
			
			Criteria c2 = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.IS_APP_ACTIVE), true, QueryConstants.EQUAL);
			c = c == null? c2:c.and(c2);

			DataObject dobj1 = ZABModel.getRow(PORTAL_LICENSE_MAPPING.TABLE, c);
			
			if(dobj1.containsTable(PORTAL_LICENSE_MAPPING.TABLE)) {
				Iterator it1 = dobj1.getRows(PORTAL_LICENSE_MAPPING.TABLE);
				while(it1.hasNext()) {
					Row rw = (Row)it1.next();
					Long sorgId = (Long) rw.get(PORTAL_LICENSE_MAPPING.ZSOID);
					
					ServiceOrg org = ZABServiceOrgUtil.getServiceOrg(sorgId);
					
					String portalName = org.getDomains().get(0).getDomain();
					
					LOGGER.log(Level.INFO, "Going to migrate script for portal:"+portalName);
					
					Boolean isAppActive = (Boolean)rw.get(PORTAL_LICENSE_MAPPING.IS_APP_ACTIVE);
					LOGGER.log(Level.INFO, "Checking license for portal::"+org.getDomains().get(0));
					if(isAppActive) {
						LOGGER.log(Level.INFO, "App is active for portal::"+org.getDomains().get(0));
						ZABUtil.setDBSpace(sorgId.toString());
						DataObject dobj = ZABModel.getRow(PROJECT.TABLE, null);
						Iterator it = dobj.getRows(PROJECT.TABLE);
						int totalcounter = 0;
						int successcounter = 0;
						while(it.hasNext()) {
							totalcounter++;
							Row row = (Row)it.next();
							Long projectId = (Long)row.get(PROJECT.PROJECT_ID);
							String projectName = (String)row.get(PROJECT.PROJECT_NAME);
							try {							
								JSONObject projectJSON = ProjectJSONService.constructProjectJSON(projectId, portalName);
								ProjectJSONService.updateProjectJSON(projectId, portalName, projectJSON.toString(), Module.EXPERIMENT, null);
								LOGGER.log(Level.INFO, "Uploaded to s3 via handler for project is successful for project:" + projectName);
								successcounter++;
							} catch (Exception e) {
								LOGGER.log(Level.SEVERE, "Failed to upload script for project:" + projectName);
							}
						}
						LOGGER.log(Level.INFO, "Uploaded to s3 is completed for portal:" + portalName);
						LOGGER.log(Level.INFO, "AWS Upgrade status (totalcount/successcount):"+totalcounter+"/"+successcounter);
					}
				}
			}
	}
	
	public static void deleteScriptsWithinPortal(Long zsoid) {
		try {
			if(zsoid!=null) {				
				ServiceOrg org = ZABServiceOrgUtil.getServiceOrg(zsoid.toString());
				if(org!=null) {					
					String portalName = org.getDomains().get(0).getDomain();
					
					String existingDBSpace = ZABUtil.getDBSpace();
					
					ZABUtil.setDBSpace(zsoid.toString());
					DataObject dobj = ZABModel.getRow(PROJECT.TABLE, null);
					Iterator it = dobj.getRows(PROJECT.TABLE);
					int totalcounter = 0;
					int successcounter = 0;
					while(it.hasNext()) {
						totalcounter++;
						Row rowpro = (Row)it.next();
						String projectName = (String)rowpro.get(PROJECT.PROJECT_NAME);
						String projectKey = (String)rowpro.get(PROJECT.PROJECT_KEY);
						try {							
							String path = "js/" +Project.getAbsoluteScriptUrl(projectKey, portalName); //NO I18N
							AWSCDN cdn = new AWSCDN();
							cdn.deleteFile(path);
							successcounter++;
							LOGGER.log(Level.INFO, "Deleted file::"+path);
						} catch (Exception e) {
							LOGGER.log(Level.SEVERE, "Failed to upload script for project:" + projectName);
						}
					}
					LOGGER.log(Level.INFO, "Deleted file success stats" + successcounter + "/" + totalcounter+" for portal:"+portalName);
					ZABUtil.setDBSpace(existingDBSpace);
				}
			}
			
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
	}

}
