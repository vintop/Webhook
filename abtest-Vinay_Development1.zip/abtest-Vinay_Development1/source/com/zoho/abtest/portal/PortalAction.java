//$Id$
package com.zoho.abtest.portal;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.json.JSONArray;
import org.json.JSONObject;

import com.adventnet.collaboration.Collaboration;
import com.adventnet.iam.IAMProxy;
import com.adventnet.iam.IAMUtil;
import com.adventnet.iam.ServiceOrg;
import com.adventnet.iam.User;
import com.adventnet.mfw.bean.BeanUtil;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.zoho.abtest.APP_USER;
import com.zoho.abtest.ATTRIBUTE_MATCHTYPE_MAPPING;
import com.zoho.abtest.AUDIENCE;
import com.zoho.abtest.AUDIENCE_ATTRIBUTE;
import com.zoho.abtest.AUDIENCE_ATTRIBUTE_MATCHTYPE;
import com.zoho.abtest.BROWSER_DETAIL;
import com.zoho.abtest.CITIES_JSON;
import com.zoho.abtest.COUNTRIES_JSON;
import com.zoho.abtest.COUNTRY_DETAIL;
import com.zoho.abtest.CURRENTURL_DETAIL;
import com.zoho.abtest.DEVICE_DETAIL;
import com.zoho.abtest.INTEGRATION;
import com.zoho.abtest.LANGUAGE_DETAIL;
import com.zoho.abtest.MOBILE_DEVICE_DETAIL;
import com.zoho.abtest.OS_DETAIL;
import com.zoho.abtest.REFFERERURL_DETAIL;
import com.zoho.abtest.STATES_JSON;
import com.zoho.abtest.TRAFFICSOURCE_DETAIL;
import com.zoho.abtest.adminconsole.AdminConsole;
import com.zoho.abtest.audience.AudienceAttributeConstants;
import com.zoho.abtest.audience.AudienceAttributeConstants.AudienceAttributes;
import com.zoho.abtest.audience.AudienceConstants;
import com.zoho.abtest.audience.LocationConstants;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.dimension.Dimension;
import com.zoho.abtest.dimension.DimensionConstants;
import com.zoho.abtest.elastic.ElasticSearchIndexConstants;
import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.filter.PageSenseOrgFilter;
import com.zoho.abtest.integration.IntegrationConstants;
import com.zoho.abtest.license.LicenseConstants;
import com.zoho.abtest.license.LicenseDetail;
import com.zoho.abtest.license.LicenseConstants.License;
import com.zoho.abtest.license.PortalLicenseMapping;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.project.ProjectConstants;
import com.zoho.abtest.report.ArchieveCumulativeTableMeta;
import com.zoho.abtest.report.ArchieveTableMeta;
import com.zoho.abtest.report.CumulativeReportConstants.CumulativeTableMetaValues;
import com.zoho.abtest.report.ReportArchieveDimensionConstants;
import com.zoho.abtest.report.ReportArchieveDimensionConstants.ArchieveTableMetaValues;
import com.zoho.abtest.report.ReportRawDataConstants;
import com.zoho.abtest.user.Feature;
import com.zoho.abtest.user.FeatureConstants;
import com.zoho.abtest.user.FeatureConstants.AppFeatures;
import com.zoho.abtest.user.Role;
import com.zoho.abtest.user.RoleConstants;
import com.zoho.abtest.user.RoleConstants.UserRoles;
import com.zoho.abtest.user.RoleFeature;
import com.zoho.abtest.user.RoleFeatureConstants;
import com.zoho.abtest.user.ZABUser;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABTableCreationBean;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.zohoone.ZohoOneAPIUtil;
import com.zoho.zohoone.ZohoOneUtil;
import com.zoho.zohoone.ZohoOneUtil.RedirectURLAction;
import com.zoho.zohoone.vo.ZohoOneOrg;
import com.zoho.abtest.zcampaigns.ZCampaignBridge;

public class PortalAction extends ZABAction implements ServletResponseAware, ServletRequestAware   
{
	private static final Logger LOGGER = Logger.getLogger(PortalAction.class.getName());
	
	private static final long serialVersionUID = 1L;

	private HttpServletRequest request;
	private HttpServletResponse response;
	
	private String domainName;
	
	public String getDomainName() {
		return domainName;
	}

	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	@Override
	public void setServletRequest(HttpServletRequest request) {
		this.request = request;
	}

	@Override
	public void setServletResponse(HttpServletResponse response) {
		this.response = response;
	}
	
	public void processPortalRequest() throws Exception
	{
		List<Portal> portals = new ArrayList<Portal>();
		try
		{
			ZABUtil.setCurrentRequest(request);
			ZABUtil.setDBCallCountMap(null);
			Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
			ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
			String inputString = null;
			
			if(ZABAction.getHTTPMethod(request).equals(ZABAction.HTTPMethod.POST) || ZABAction.getHTTPMethod(request).equals(ZABAction.HTTPMethod.PUT))
			{
				inputString = ZABAction.getInputString(request);
			}
			
			ZABUtil.setCurrentInputString(inputString);
			
			User iamUser = IAMUtil.getCurrentUser();
			Long zuid = IAMUtil.getCurrentUser().getZUID();
			HashMap<String,String> hs;
			switch(ZABAction.getHTTPMethod(request))
			{
			case GET:	
				portals.addAll(Portal.getUserPortals(zuid));
				break;
			case POST:	
				hs = ZABAction.getRequestParser(request).parsePortal(request);
				if(hs.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS))
				{
					Portal portal = new Portal();
					portal.setSuccess(Boolean.FALSE);
					portal.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
					portals.add(portal);
				}
				else
				{
					int status = PageSenseOrgFilter.checkAppAccessUserEligibility();
					if(status == PageSenseOrgFilter.ELIGIBLE)
					{
						//TODO - Check user portalcount created should be zero
						int userPortalCount = AdminConsole.getUserCreatedPortalCount(zuid);
						if(userPortalCount == 0)
						{
							Portal portal = createPortal(hs, zuid, request, iamUser, "");
							portals.add(portal);
						}
						else
						{
							Portal portal = new Portal();
							portal.setSuccess(Boolean.FALSE);
							portal.setResponseString(ZABAction.getMessage(LicenseConstants.LICENSE_PORTAL_LIMIT));
							portals.add(portal);
						}
					}
					else
					{
						if(status == PageSenseOrgFilter.REQUEST_RECEIVED)
						{
							String errorString = ZABAction.getResponseProvider(request).getActivationAwaitedException();
							ZABAction.sendResponse(request, response, errorString);
							return;
						}
						else if(status == PageSenseOrgFilter.NOT_REGISTERED)
						{
							int userPortalCount = Portal.getUserPortalsCount(zuid);
							if(userPortalCount == 0)
							{
								String errorString = ZABAction.getResponseProvider(request).getOrgNoAccessException();
								ZABAction.sendResponse(request, response, errorString);
								return;
							}
							else
							{
								String errorString = ZABAction.getResponseProvider(request).getApplyAccessRequest();
								ZABAction.sendResponse(request, response, errorString);
								return;
							}
						}
					}
				}
				break;
			case PUT:	
				hs = ZABAction.getRequestParser(request).parsePortal(request);
				if(hs.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS))
				{
					Portal portal = new Portal();
					portal.setSuccess(Boolean.FALSE);
					portal.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
					portals.add(portal);
				}
				else
				{
					Portal portal = Portal.updatePortal(hs, domainName, zuid);
					portals.add(portal);
				}
				break;
			case DELETE:
				if(domainName != null)
				{
					Long zsoid = ZABServiceOrgUtil.getZSOIDFromDomain(domainName);
					Portal portal = Portal.deletePortal(domainName, zsoid, zuid);
					if(portal.getSuccess())
					{
						ZABUtil.setDBSpace("sharedspace");	//No I18N
						HashMap<String, String> spaceDeletionHs = new HashMap<String, String>();
						spaceDeletionHs.put(ElasticSearchIndexConstants.ZSOID, zsoid.toString());
						spaceDeletionHs.put(ElasticSearchIndexConstants.PORTAL_NAME, domainName);
						spaceDeletionHs.put(ElasticSearchIndexConstants.DELETED_TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
						spaceDeletionHs.put(ElasticSearchIndexConstants.IS_DATA_REMOVED, Boolean.FALSE.toString());
						SpaceDeletionDetails.createSpaceDeletionDetails(spaceDeletionHs);
						LOGGER.log(Level.INFO, "Portal data Deletion action inserted into the table - {0} {1}" , new String[]{zsoid.toString(),domainName});
					}
					portals.add(portal);
				}
				
			}
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getPortalResponse(request, portals));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), PortalConstants.API_MODULE_PLURAL));
		}
	}
	
	//Note if u are changing anything in this method
	//COnsidering changing it in ZohoONeHandlerImpl and ZABIAMCSHandler also
	//As those created from ZohoOne/Customsignup callback will be called inn that class and will be reusing the same below methods there also
	public Portal createPortal(HashMap<String,String> hs, Long zuid, HttpServletRequest request, User iamUser, String projectname) throws Exception
	{
		Portal portal = null;
		
		portal = Portal.addPortal(hs, zuid,request);
		if(portal != null && portal.getZsoid() != null)
		{
			String domainName = portal.getDomainName();
			ZABUtil.setPortaldomain(domainName);
			dbSpaceCreation(iamUser, portal.getZsoid().toString(), request, projectname);
			
			assignTrialLicenseToZsoid(portal.getZsoid(), portal.getSpecialRefferer());
		}
		return portal;
	}
	
	public static void assignTrialLicenseToZsoid(Long zsoid, int specialReferrer)
	{
		//Once the portal is created - assign trial license for that portal
		Integer licenseTimespan = LicenseConstants.MONTH_DAYS_COUNT;
		Long startTime = ZABUtil.getCurrentTimeInMilliSeconds();
		Long endTime = ZABUtil.getNthServerDayInLong(startTime, licenseTimespan) - 1;
		Integer totalCount = LicenseConstants.TRIAL_VISITOR_COUNT;
		Long yearEndTime = null;
		boolean isAnnual = false;
		//viaProductHunt
		if(specialReferrer == 1)
		{
			endTime = ZABUtil.getNthServerDayInLong(startTime, LicenseConstants.PRODUCTHUNT_DAYS_COUNT) - 1;
			isAnnual = false;
			totalCount = LicenseConstants.PRODUCTHUNT_VISITOR_COUNT;
		}
		//switch from optimizely blog
		else if(specialReferrer == 2)
		{
			endTime = ZABUtil.getNthServerDayInLong(startTime, LicenseConstants.SWITCHOPTIMIZELY_DAYS_COUNT) - 1;
			isAnnual = false;
			totalCount = LicenseConstants.SWITCHOPTIMIZELY_VISITOR_COUNT;
		}
		ArrayList<HashMap<String, String>> addonList = new ArrayList<HashMap<String,String>>();
		Long storeAddonId = 0l;
        HashMap<String,String> addonHs = new HashMap<String, String>();
        addonHs.put(LicenseConstants.STORE_ADDON_ID, storeAddonId.toString());
        addonHs.put(LicenseConstants.TOTAL_COUNT, totalCount.toString());
        addonList.add(addonHs);
		PortalLicenseMapping.assignLicenseToPortal(License.TRIAL.getLicenseType(), zsoid, isAnnual,startTime,endTime,yearEndTime,null,addonList);
	}
	
	public void revertPortalDeletion() throws Exception
	{
		List<Portal> portals = new ArrayList<Portal>();
		try
		{
			ZABUtil.setCurrentRequest(request);
			ZABUtil.setDBCallCountMap(null);
			Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
			ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
			Long zsoid = Long.parseLong(request.getParameter("zsoid"));
			Portal portal = Portal.revertPortalDeletion(zsoid);
			portals.add(portal);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getPortalResponse(request, portals));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), PortalConstants.API_MODULE));
		}
	}
	
	public void immediateDeletedSpaceCleanup() throws Exception
	{
		List<Portal> portals = new ArrayList<Portal>();
		try
		{
			ZABUtil.setCurrentRequest(request);
			ZABUtil.setDBCallCountMap(null);
			Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
			ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
			Long zsoid = Long.parseLong(request.getParameter("zsoid"));
			Portal portal = Portal.immediateDeletedSpaceCleanup(zsoid);
			portals.add(portal);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getPortalResponse(request, portals));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), PortalConstants.API_MODULE));
		}
	}
	
	public void processDefaultPortal() throws Exception
	{
		List<Portal> portals = new ArrayList<Portal>();
		try
		{
			ZABUtil.setCurrentRequest(request);
			ZABUtil.setDBCallCountMap(null);
			Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
			ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
			String inputString = null;
			
			if(ZABAction.getHTTPMethod(request).equals(ZABAction.HTTPMethod.POST) || ZABAction.getHTTPMethod(request).equals(ZABAction.HTTPMethod.PUT))
			{
				inputString = ZABAction.getInputString(request);
			}
			
			ZABUtil.setCurrentInputString(inputString);
			
			User iamUser = IAMUtil.getCurrentUser();
			Long zuid = IAMUtil.getCurrentUser().getZUID();
			Portal portal = null;
			HashMap<String, String> hs = null;
			switch(ZABAction.getHTTPMethod(request))
			{
			case GET:
				LOGGER.log(Level.INFO, "INside process defalt portal:"+zuid);
				portal = Portal.getDefaultPortal(zuid);
				
				if(portal !=null)
				{
					LOGGER.log(Level.INFO, "Def POrtal exists:"+zuid);
					portals.add(portal);
				}
				else
				{
					int userPortalCount = Portal.getUserPortalsCount(zuid);
					// For first time user, create a space and make it default
					LOGGER.log(Level.INFO, "Def POrtal Not exists:"+zuid);
					if(userPortalCount == 0)
					{
						LOGGER.log(Level.INFO, "NO POrtal:"+zuid);
						//EARLY ACCESS BLOCK CHECK
						int status = PageSenseOrgFilter.checkAppAccessUserEligibility();
						
						LOGGER.log(Level.INFO, "Eligibility status: "+status);
						if(status == PageSenseOrgFilter.ELIGIBLE)
						{
							LOGGER.log(Level.INFO, "User is eligable"+zuid);
							/*
							 * 
							hs = new HashMap<String,String>();
							hs.put(PortalConstants.PORTALNAME, PortalConstants.DEFAUT_PORTALNAME_LABEL);
							hs.put(PortalConstants.ISDEFAULT, Boolean.TRUE.toString());
							portal = createPortal(hs, zuid, request, iamUser);
							*/
							// In client it should be redirected to welcome page 
							portal = new Portal();
							portal.setZsoid(-1l);
							portal.setSuccess(Boolean.TRUE);
							portal.setIsSignUp(Boolean.TRUE);
							portals.add(portal);
						}
						else
						{
							LOGGER.log(Level.INFO, "User NOT eligable"+zuid);
							if(status == PageSenseOrgFilter.REQUEST_RECEIVED)
							{
								String errorString = ZABAction.getResponseProvider(request).getActivationAwaitedException();
								ZABAction.sendResponse(request, response, errorString);
								return;
							}
							else if(status == PageSenseOrgFilter.NOT_REGISTERED)
							{
								String errorString = ZABAction.getResponseProvider(request).getOrgNoAccessException();
								ZABAction.sendResponse(request, response, errorString);
								return;
							}
						}
					}
				}
				break;
			case POST:
				hs = new HashMap<String, String>();
				Long zsoid = ZABServiceOrgUtil.getZSOIDFromDomain(domainName);
				hs.put(PortalConstants.DOMAINNAME, domainName);
				hs.put(PortalConstants.ZSOID, zsoid.toString());
				boolean isServiceOrgMember = ZABServiceOrgUtil.isServiceOrgMember(zsoid, zuid);
				if(isServiceOrgMember)
				{
					portal = Portal.setDefaultPortal(hs, zuid);
				}
				else
				{
					portal = new Portal();
					portal.setZsoid(zsoid);
					portal.setSuccess(Boolean.FALSE);
				}
				
				if(portal !=null)
				{
					portals.add(portal);
				}
				break;
			}
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getPortalResponse(request, portals));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), PortalConstants.API_MODULE));
		}
	}
	
	public void getCurrentPortalDetail() throws Exception
	{
		List<Portal> portals = new ArrayList<Portal>();
		try
		{
			Portal portal = null;
			ServiceOrg serviceOrg = IAMUtil.getCurrentServiceOrg();
			portal = Portal.getPortalFromServiceOrg(serviceOrg);
			//Set Zohoone related properties
			ZohoOneOrg zoOrg = ZohoOneUtil.getCurrentZohoOneOrg();
			String subscriptionLink = null;
			if (zoOrg != null)
			{ 
				portal.setIsZohoOne(true);
				if(zoOrg.canRedirectOnAddUser())
				{
					String userInviteLink = ZohoOneUtil.getRedirectURL(zoOrg.getOrgId(), RedirectURLAction.NEW_USER, IAMProxy.getInstance().getCurrentServiceName(), null);
					portal.setZohoOneUserInviteLink(userInviteLink);
				}
				if(zoOrg.canChangeSubscriptionLink())
				{
					subscriptionLink = ZohoOneUtil.getRedirectURL(zoOrg.getOrgId(), RedirectURLAction.SUBSCRIPTION, IAMProxy.getInstance().getCurrentServiceName(), null);
				}
				
				//for zohoone launcher
				boolean canShowOneLauncher = zoOrg.canShowLauncher();
				portal.setCanShowOneLauncher(canShowOneLauncher);
				if(canShowOneLauncher)
				{
					String oneLauncherUrl = ZohoOneAPIUtil.getZohoOneLauncherURL(zoOrg.getOrgId(), portal.getZsoid().toString(), IAMProxy.getInstance().getCurrentServiceName());
					portal.setOneLauncherUrl(oneLauncherUrl);
				}
			}
			//If not under zohoone and currentuser is the owner of the current portal, then show them the zoho store link
			else if(portal.getCreatedBy().equals(IAMUtil.getCurrentUser().getZUID()))
			{
				String paymentsDomain = IAMProxy.getInstance().getServiceAPI().getService(LicenseConstants.ZOHOSTORE_IAMSERVICENAME).getWebUrl();
				subscriptionLink = paymentsDomain+"/html/store/index.html#subscription?serviceId="+ LicenseConstants.ZOHOSTORE_PAGESENSE_ID +"&customId=" + portal.getZsoid(); //NO I18N
			}
			portal.setSubscriptionLink(subscriptionLink);
			
			//Get portal license plan name
			LicenseDetail licdetail = PortalLicenseMapping.getLicenseDetailOfPortal(portal.getZsoid());
			if(licdetail != null)
			{
				String planName = licdetail.getLicenseName();
				planName = LicenseDetail.getReadablePlanName(planName);
				portal.setPlanName(planName);
			}
			Boolean status = PortalLicenseMapping.getLicenseStatus();
			portal.setIsAppActive(status);
			portals.add(portal);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getPortalResponse(request, portals));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), PortalConstants.API_MODULE));
		}
	}
	
	public Boolean dbSpaceCreation(User iamUser, String dbSpaceId, HttpServletRequest request, String projectname) throws DataAccessException, Exception
	{
		Collaboration c = (Collaboration)BeanUtil.lookup("CollaborationBean");		


		if(!(c.dataSpaceExists(dbSpaceId))){ /*&&ZMUtil.dataPatchCompleted(dbSpaceId)*/

			synchronized(this){
				if(!c.dataSpaceExists(dbSpaceId)) {
					//ZMUtil.startDataPatch(dbSpaceId);
					c.reserveDataSpace(dbSpaceId);
					ZABUtil.setDBSpace(dbSpaceId);
					ZABUtil.setCurrentUser(ZABUser.createAdminUser(iamUser));  	
					ZABUtil.setCurrentRequest(request); 
					dataSpacePatchUp(dbSpaceId, projectname);
					//TODO ES
					ElasticSearchUtil.doIndexPortalMapping(ZABUtil.getPortaldomain(), dbSpaceId);
					//ZMUtil.stopDataPatch(dbSpaceId);
				}
			}	
			return false;
		}else{
			return true;
		}
	}
	
	public static void dbSpaceDeletion(String dbSpaceId, String domainName) throws Exception
	{
		Collaboration c = (Collaboration)BeanUtil.lookup("CollaborationBean");
		if(c.dataSpaceExists(dbSpaceId))
		{
			try
			{
				c.unreserveDataSpace(dbSpaceId);
				LOGGER.log(Level.INFO, "successfully unreserved dbspace - "+ dbSpaceId);
			}
			catch(Exception ex)
			{
				LOGGER.log(Level.SEVERE, "Exception occurred while unreserving dbspace - "+ dbSpaceId);
				LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			}
			//Delete portal data from ES 
			ElasticSearchUtil.deletePortalData(domainName);
			ElasticSearchUtil.undoIndexPortalMapping(domainName);
		}
	}
	
	public void dataSpacePatchUp(String dbSpaceId, String projectname) throws Exception
	{
		/*ZABUtil.setDBSpace("admin"); //NO I18N
		Criteria  cri = new Criteria(new Column(SASACCOUNTS.TABLE,SASACCOUNTS.LOGINNAME),dbSpaceId,QueryConstants.EQUAL);
		Join join = new Join(USERDOMAINS.TABLE,SASACCOUNTS.TABLE,new String[]{USERDOMAINS.ID},new String[]{SASACCOUNTS.ID},Join.INNER_JOIN);
		Join join2 = new Join(USERDOMAINS.TABLE,CUSTOMERDATABASE.TABLE,new String[]{USERDOMAINS.CUSTOMERID},new String[]{CUSTOMERDATABASE.CUSTOMERID},Join.INNER_JOIN);
		DataObject dobj = ZABModel.getRow(USERDOMAINS.TABLE, cri, new Join[]{join,join2});
		String schemaname = (String) dobj.getFirstValue(CUSTOMERDATABASE.TABLE, CUSTOMERDATABASE.SCHEMANAME);		
		ZABUtil.setDBSpace(dbSpaceId);*/
		
		//ZABTableCreationBean userAction = (ZABTableCreationBean)BeanUtil.lookup("ZABTableCreationBean",ZABUtil.getCurrentUserDbSpace());
		//userAction.createProjectJSONTable();
		//userAction.createReportRawDataTables(dbSpaceId);
		//userAction.createHeatmapDataTable();
		//userAction.createCombinationJsonTables(dbSpaceId);
		//userAction.createReportArchiveVisitorIdsTables(dbSpaceId);
		//userAction.createFunnelRawTable(ZABUtil.getCurrentUserDbSpace());
		
//		ZMUserBean userAction = (ZMUserBean)BeanUtil.lookup("ZMUserBean",ZMUtil.getCurrentUserDbSpace());
//		userAction.createTrigger(schemaname);
		
		
//		LOGGER.log(Level.INFO,"Started loading default templates for Email Builder in the database",request);
		dataPopulation(projectname);
//		LOGGER.log(Level.INFO,"Completed loading default templates for Email Builder in the database",request);
	}
	
	public void dataPopulation(String projectname)
	{
		try
		{
			populateDefaultValuesForStandardDimensions();
			//populateArchieveTableMetaValues();
			//populateArchieveCumulativeTableMetaValues();
			populateUserRolesAndFeatures();
			
			audienceAttributeDataPopulation();			
			//audienceAttributeMatchTypeDataPopulation();
			//audienceMatchTypeAttributeMappingDataPopulation();
			
			//integrationDataPopulation();
			
			populateDefaultProject(projectname);
			
			audienceDataPopulation();
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Error occurred during data population",ex);
		}
	}
	
	public void populateDefaultProject(String projectname) throws Exception
	{
		try
		{
			HashMap<String,String> hs = new HashMap<String,String>();
			if(projectname == null || projectname.equals("")){
				hs.put(ProjectConstants.PROJECT_NAME, ProjectConstants.DEFAULT_PROJECT_NAME);
			}else{
				hs.put(ProjectConstants.PROJECT_NAME, projectname);
			}
			Project.createProject(hs);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Error occurred during default project creation",ex);
			throw ex;
		}
	}
	
	public void populateArchieveTableMetaValues() throws Exception
	{
		try
		{
			ArrayList<HashMap<String, String>> hsList = new ArrayList<HashMap<String, String>>();
			HashMap<String, String> hs = null;
			ArchieveTableMetaValues[] archieveTableMetaValues = ArchieveTableMetaValues.values(); 
			
			for(ArchieveTableMetaValues archieveTableMetaValue:archieveTableMetaValues)
			{
				String columnName = archieveTableMetaValue.getColumnName();
				String groupByColumns = archieveTableMetaValue.getGroupByColumns();
				String resultArchiveTable = archieveTableMetaValue.getResultArchieveTable();
				String visitorIdsTable = archieveTableMetaValue.getVisitorIdsTable();
				Integer durationType = archieveTableMetaValue.getDurationType();
				Integer moduleType = archieveTableMetaValue.getModuleType();
				Boolean isStandardDimension = archieveTableMetaValue.getIsStandardDimension();
				
				hs = new HashMap<String, String>();
				hs.put(ReportArchieveDimensionConstants.COLUMN_NAME, columnName);
				hs.put(ReportArchieveDimensionConstants.GROUP_BY_COLUMNS, groupByColumns);
				hs.put(ReportArchieveDimensionConstants.RESULT_ARCHIEVE_TABLE, resultArchiveTable);
				hs.put(ReportArchieveDimensionConstants.VISITOR_IDS_TABLE, visitorIdsTable);
				hs.put(ReportArchieveDimensionConstants.DURATION_TYPE, durationType.toString());
				hs.put(ReportArchieveDimensionConstants.MODULE_TYPE, moduleType.toString());
				hs.put(ReportArchieveDimensionConstants.LAST_ARCHIEVED_TIME, "0");
				hs.put(ReportArchieveDimensionConstants.IS_STANDARD_DIMENSION, isStandardDimension.toString());
				
				hsList.add(hs);
			}
			
			ArchieveTableMeta.createArchieveTableMeta(hsList);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Error occurred during ArchieveTableMetaValues data population",ex);
		}
	}
	
	public void populateArchieveCumulativeTableMetaValues() throws Exception
	{
		try
		{
			ArrayList<HashMap<String, String>> hsList = new ArrayList<HashMap<String, String>>();
			HashMap<String, String> hs = null;
			CumulativeTableMetaValues[] archieveCumTableMetaValues = CumulativeTableMetaValues.values(); 
			
			for(CumulativeTableMetaValues archieveCumTableMetaValue:archieveCumTableMetaValues)
			{
				String resultArchiveTable = archieveCumTableMetaValue.getResultTable();
				hs = new HashMap<String, String>();
				hs.put(ReportArchieveDimensionConstants.RESULT_ARCHIEVE_TABLE, resultArchiveTable);
				hs.put(ReportArchieveDimensionConstants.LAST_ARCHIEVED_TIME, "0");
				hsList.add(hs);
			}
			
			ArchieveCumulativeTableMeta.createArchieveCumulativeTableMetaDetails(hsList);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Error occurred during ArchieveCumulativeTableMetaValues data population",ex);
		}
	}
	
	public static void populateDefaultValuesForCommonStandardDimensions() throws Exception
	{
		try
		{
			//HashMap<String,String> browserHs = new HashMap<String,String>(); 
			//browserHs.put(DimensionConstants.BROWSER_VALUE, ReportRawDataConstants.UNKNOWN_VALUE); //TODO
			//Dimension.createDimensionCodeValue(BROWSER_DETAIL.TABLE, BROWSER_DETAIL.BROWSER_CODE, DimensionConstants.BROWSER_CODE, browserHs, DimensionConstants.BROWSER_DETAIL_CONSTANTS);
			browserDataPopulation();
			
			
			//HashMap<String,String> deviceHs = new HashMap<String,String>(); 
			//deviceHs.put(DimensionConstants.DEVICE_VALUE, ReportRawDataConstants.UNKNOWN_VALUE); //TODO
			//Dimension.createDimensionCodeValue(DEVICE_DETAIL.TABLE, DEVICE_DETAIL.DEVICE_CODE, DimensionConstants.DEVICE_CODE, deviceHs, DimensionConstants.DEVICE_DETAIL_CONSTANTS);
			deviceDataPopulation();
			
			mobileDeviceDataPopulation();
			//HashMap<String,String> countryHs = new HashMap<String,String>(); 
			//countryHs.put(DimensionConstants.COUNTRY_VALUE, ReportRawDataConstants.UNKNOWN_COUNTRY_CODE); //TODO
			//countryHs.put(DimensionConstants.COUNTRY_DISPLAY_NAME, ReportRawDataConstants.UNKNOWN_VALUE); //TODO
			//Dimension.createDimensionCodeValue(COUNTRY_DETAIL.TABLE, COUNTRY_DETAIL.COUNTRY_CODE, DimensionConstants.COUNTRY_CODE, countryHs, DimensionConstants.COUNTRY_DETAIL_CONSTANTS);
			countryDataPopulation();
			
			//HashMap<String,String> languageHs = new HashMap<String,String>(); 
			//languageHs.put(DimensionConstants.LANGUAGE_VALUE, ReportRawDataConstants.UNKNOWN_LANGUAGE_CODE); //TODO
			//languageHs.put(DimensionConstants.LANGUAGE_DISPLAY_NAME, ReportRawDataConstants.UNKNOWN_VALUE); //TODO
			//Dimension.createDimensionCodeValue(LANGUAGE_DETAIL.TABLE, LANGUAGE_DETAIL.LANGUAGE_CODE, DimensionConstants.LANGUAGE_CODE, languageHs, DimensionConstants.LANGUAGE_DETAIL_CONSTANTS);
			languageDataPopulation();
			
			/* user type is maintained in ENUM*/
			/*
			HashMap<String,String> usertypeHs = new HashMap<String,String>(); 
			usertypeHs.put(DimensionConstants.USERTYPE_VALUE, ReportRawDataConstants.UNKNOWN_VALUE); //TODO
			Dimension.createDimensionCodeValue(USERTYPE_DETAIL.TABLE, USERTYPE_DETAIL.USERTYPE_CODE, DimensionConstants.USERTYPE_CODE, usertypeHs, DimensionConstants.USERTYPE_DETAIL_CONSTANTS);
			*/
			
			//HashMap<String,String> osHs = new HashMap<String,String>(); 
			//osHs.put(DimensionConstants.OS_VALUE, ReportRawDataConstants.UNKNOWN_VALUE); //TODO
			//Dimension.createDimensionCodeValue(OS_DETAIL.TABLE, OS_DETAIL.OS_CODE, DimensionConstants.OS_CODE, osHs, DimensionConstants.OS_DETAIL_CONSTANTS);
			platformDataPopulation();
			
			locationDataPopulation();
			
			HashMap<String,String> trafficsourceHs = new HashMap<String,String>(); 
			trafficsourceHs.put(DimensionConstants.TRAFFICSOURCE_VALUE, ReportRawDataConstants.UNKNOWN_VALUE); //TODO
			Dimension.createDimensionCodeValue(TRAFFICSOURCE_DETAIL.TABLE, TRAFFICSOURCE_DETAIL.TRAFFICSOURCE_CODE, DimensionConstants.TRAFFICSOURCE_CODE, trafficsourceHs, DimensionConstants.TRAFFICSOURCE_DETAIL_CONSTANTS);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Error occurred during data population for common standard dimensions",ex);
		}
	}
	
	public void populateDefaultValuesForStandardDimensions() throws Exception
	{
		try
		{
			HashMap<String,String> reffererurlHs = new HashMap<String,String>(); 
			reffererurlHs.put(DimensionConstants.REFFERERURL_VALUE, ReportRawDataConstants.UNKNOWN_VALUE); //TODO
			Dimension.createDimensionCodeValue(REFFERERURL_DETAIL.TABLE, REFFERERURL_DETAIL.REFFERERURL_CODE, DimensionConstants.REFFERERURL_CODE, reffererurlHs, DimensionConstants.REFFERERURL_DETAIL_CONSTANTS);
			
			HashMap<String,String> currenturlHs = new HashMap<String,String>(); 
			currenturlHs.put(DimensionConstants.CURRENTURL_VALUE, ReportRawDataConstants.UNKNOWN_VALUE); //TODO
			Dimension.createDimensionCodeValue(CURRENTURL_DETAIL.TABLE, CURRENTURL_DETAIL.CURRENTURL_CODE, DimensionConstants.CURRENTURL_CODE, currenturlHs, DimensionConstants.CURRENTURL_DETAIL_CONSTANTS);
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Error occurred during data population for standard dimensions",ex);
		}
	}
	
	public void populateUserRolesAndFeatures()
	{
		try
		{
			//Populate Roles
			List<Role> rolesList = new ArrayList<Role>();
			UserRoles[] userRoles = UserRoles.values();
			for(UserRoles userRole:userRoles)
			{
				HashMap<String, String> hs = new HashMap<String, String>();
				hs.put(RoleConstants.ROLE_NAME, userRole.getRole());
				hs.put(RoleConstants.ROLE_DESCRIPTION, userRole.getRoleDescription());
				hs.put(RoleConstants.ROLE_VALUE, userRole.getRoleValue().toString());
				rolesList.add(Role.createRole(hs));
			}
			
			//Populate Features
			List<Feature> featureList = new ArrayList<Feature>();
			AppFeatures[] features = AppFeatures.values();
			for(AppFeatures feature:features)
			{
				HashMap<String, String> hs = new HashMap<String, String>();
				hs.put(FeatureConstants.FEATURE_NAME, feature.getFeature());
				hs.put(FeatureConstants.FEATURE_DESCRIPTION, feature.getFeatureDescription());
				hs.put(FeatureConstants.ROLE_VALUE, feature.getRoleValue().toString());
				featureList.add(Feature.createFeature(hs));
			}
			
			//Mapping of Features with its Roles
			for(Role role:rolesList)
			{
				ArrayList<HashMap<String, String>> hsArray = new ArrayList<HashMap<String, String>>();
				for(Feature feature:featureList)
				{
					Integer featureRoleValue = feature.getRoleValue();
					HashMap<String, String> hs = new HashMap<String, String>();
					switch(role.getRoleName())
					{
					//Admin has access to all features
					case "ADMIN": //No I18N 
						hs.put(RoleFeatureConstants.ROLE_ID, role.getRoleId().toString());
						hs.put(RoleFeatureConstants.FEATURE_ID, feature.getFeatureId().toString());
						hsArray.add(hs);
						break;
					case "PROJECTADMIN": //No I18N 
						//Project admin can have access to editor features and spectator features and additional specific features
						if(featureRoleValue.equals(UserRoles.PROJECTADMIN.getRoleValue()) || featureRoleValue.equals(UserRoles.EDITOR.getRoleValue()) || featureRoleValue.equals(UserRoles.SPECTATOR.getRoleValue()))
						{
							hs.put(RoleFeatureConstants.ROLE_ID, role.getRoleId().toString());
							hs.put(RoleFeatureConstants.FEATURE_ID, feature.getFeatureId().toString());
							hsArray.add(hs);
						}
						break;
					case "EDITOR": //No I18N 
						//Editor can have access to spectator features and additional specific features
						if(featureRoleValue.equals(UserRoles.EDITOR.getRoleValue()) || featureRoleValue.equals(UserRoles.SPECTATOR.getRoleValue()))
						{
							hs.put(RoleFeatureConstants.ROLE_ID, role.getRoleId().toString());
							hs.put(RoleFeatureConstants.FEATURE_ID, feature.getFeatureId().toString());
							hsArray.add(hs);
						}
						break;
					case "SPECTATOR": //No I18N 
						//Spectator can have access to spectator features
						if(featureRoleValue.equals(UserRoles.SPECTATOR.getRoleValue()))
						{
							hs.put(RoleFeatureConstants.ROLE_ID, role.getRoleId().toString());
							hs.put(RoleFeatureConstants.FEATURE_ID, feature.getFeatureId().toString());
							hsArray.add(hs);
						}
						break;
					}
				}
				RoleFeature.createRoleFeature(hsArray);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Error occurred during data population for User Roles and Features",ex);
		}
	}
	
	public static void browserDataPopulation(){
		try{
			
			ArrayList<HashMap<String, String>> myList = new ArrayList<HashMap<String, String>>();

			String browserValue[]={"Firefox","Chrome","Internet Explorer","Safari","Edge","Opera","Others"}; //No I18N
			for(int i=0;i<browserValue.length;i++){
				HashMap<String, String> data = new HashMap<String, String>();
				data.put(DimensionConstants.BROWSER_VALUE, browserValue[i]); //TODO
				data.put(DimensionConstants.BROWSER_CODE, i+"");
				myList.add(data);
			}
			
			ZABModel.createRow(DimensionConstants.BROWSER_DETAIL_CONSTANTS, BROWSER_DETAIL.TABLE, myList);

		}catch(Exception ex){
			ex.printStackTrace();
		}
		
	}
	

	public static void platformDataPopulation(){
		try{
			
			ArrayList<HashMap<String, String>> myList = new ArrayList<HashMap<String, String>>();
			
			String osValue[] = {"Linux","UNIX","MacOS","Windows","Others"}; //No I18N

			for(int i=0;i<osValue.length;i++){
				HashMap<String, String> data = new HashMap<String, String>();
				data.put(DimensionConstants.OS_VALUE, osValue[i]); //TODO
				data.put(DimensionConstants.OS_CODE, i+"");
				myList.add(data);
			}
			
			ZABModel.createRow(DimensionConstants.OS_DETAIL_CONSTANTS, OS_DETAIL.TABLE, myList);

		}catch(Exception ex){
			ex.printStackTrace();
		}
		
	}
	
	public static void locationDataPopulation(){
		
		try{
			String countryUrl = "https://raw.githubusercontent.com/hiiamrohit/Countries-States-Cities-database/master/countries.json"; //No I18N
			String statesUrl = "https://raw.githubusercontent.com/hiiamrohit/Countries-States-Cities-database/master/states.json"; //No I18N
			String citiesUrl = "https://raw.githubusercontent.com/hiiamrohit/Countries-States-Cities-database/master/cities.json"; //No I18N
			String st = ZABUtil.getResponseStrFromProxyURL(countryUrl); 
			JSONObject json = new JSONObject(st);
			JSONArray array = json.getJSONArray("countries"); //No I18N
			for(int i = 0; i < array.length(); i++){
				JSONObject innerjson = array.getJSONObject(i);
				HashMap<String,String> hs = new HashMap<String,String>();
				hs.put(LocationConstants.ID, innerjson.getString(LocationConstants.ID));
				hs.put(LocationConstants.NAME, innerjson.getString(LocationConstants.NAME));
				ZABModel.createRow(LocationConstants.COUNTRY_TABLE,COUNTRIES_JSON.TABLE,hs);
			}
			
			String st1 = ZABUtil.getResponseStrFromProxyURL(statesUrl);
			JSONObject json1 = new JSONObject(st1);
			JSONArray array1 = json1.getJSONArray("states"); //No I18N
			for(int i = 0; i < array1.length(); i++){
				JSONObject innerjson = array1.getJSONObject(i);
				HashMap<String,String> hs = new HashMap<String,String>();
				hs.put(LocationConstants.ID, innerjson.getString(LocationConstants.ID));
				hs.put(LocationConstants.NAME, innerjson.getString(LocationConstants.NAME));
				if(innerjson.getString(LocationConstants.ID).equals("2181")){
					hs.put(LocationConstants.COUNTRY_ID, "124");
					innerjson.put(LocationConstants.COUNTRY_ID, "124");
					array1.put(i, innerjson);
				}else {
						hs.put(LocationConstants.COUNTRY_ID, innerjson.getString(LocationConstants.COUNTRY_ID));
				}
				ZABModel.createRow(LocationConstants.STATE_TABLE,STATES_JSON.TABLE,hs);
			}
			
			String st2 = ZABUtil.getResponseStrFromProxyURL(citiesUrl);
			JSONObject json2 = new JSONObject(st2);
			JSONArray array2 = json2.getJSONArray("cities"); //No I18N
			for(int i = 0; i < array2.length(); i++){
				JSONObject innerjson = array2.getJSONObject(i);
				HashMap<String,String> hs = new HashMap<String,String>();
				hs.put(LocationConstants.ID, innerjson.getString(LocationConstants.ID));
				hs.put(LocationConstants.NAME, innerjson.getString(LocationConstants.NAME));
				if(innerjson.getString(LocationConstants.ID).equals("2321")){
					hs.put(LocationConstants.STATE_ID, "21");
					innerjson.put(LocationConstants.STATE_ID, "21");
				}
				else if(innerjson.getString(LocationConstants.ID).equals("4478")){
					hs.put(LocationConstants.STATE_ID, "36");
					innerjson.put(LocationConstants.STATE_ID, "36");

				}
				else if(innerjson.getString(LocationConstants.ID).equals("6628")){
					hs.put(LocationConstants.STATE_ID, "269");
					innerjson.put(LocationConstants.STATE_ID, "269");

				}
				else if(innerjson.getString(LocationConstants.ID).equals("8720")){
					hs.put(LocationConstants.STATE_ID, "516");
					innerjson.put(LocationConstants.STATE_ID, "516");

				}
				else if(innerjson.getString(LocationConstants.ID).equals("10717")){
					hs.put(LocationConstants.STATE_ID, "673");
					innerjson.put(LocationConstants.STATE_ID, "673");

				}
				else if(innerjson.getString(LocationConstants.ID).equals("12819")){
					hs.put(LocationConstants.STATE_ID, "781");
					innerjson.put(LocationConstants.STATE_ID, "781");

				}
				else if(innerjson.getString(LocationConstants.ID).equals("14848")){
					hs.put(LocationConstants.STATE_ID, "936");
					innerjson.put(LocationConstants.STATE_ID, "936");

				}
				else if(innerjson.getString(LocationConstants.ID).equals("16908")){
					hs.put(LocationConstants.STATE_ID, "1162");
					innerjson.put(LocationConstants.STATE_ID, "1162");

				}
				else if(innerjson.getString(LocationConstants.ID).equals("18749")){
					hs.put(LocationConstants.STATE_ID, "1357");
					innerjson.put(LocationConstants.STATE_ID, "1357");

				}
				else if(innerjson.getString(LocationConstants.ID).equals("20677")){
					hs.put(LocationConstants.STATE_ID, "1491");
					innerjson.put(LocationConstants.STATE_ID, "1491");

				}
				else if(innerjson.getString(LocationConstants.ID).equals("22587")){
					hs.put(LocationConstants.STATE_ID, "1826");
					innerjson.put(LocationConstants.STATE_ID, "1826");

				}
				else if(innerjson.getString(LocationConstants.ID).equals("24462")){
					hs.put(LocationConstants.STATE_ID, "1930");
					innerjson.put(LocationConstants.STATE_ID, "1930");

				}
				else if(innerjson.getString(LocationConstants.ID).equals("26476")){
					hs.put(LocationConstants.STATE_ID, "2236");
					innerjson.put(LocationConstants.STATE_ID, "2236");

				}
				else if(innerjson.getString(LocationConstants.ID).equals("28354")){
					hs.put(LocationConstants.STATE_ID, "2442");
					innerjson.put(LocationConstants.STATE_ID, "2442");

				}
				else if(innerjson.getString(LocationConstants.ID).equals("30256")){
					hs.put(LocationConstants.STATE_ID, "2594");
					innerjson.put(LocationConstants.STATE_ID, "2594");

				}
				else if(innerjson.getString(LocationConstants.ID).equals("32239")){
					hs.put(LocationConstants.STATE_ID, "2848");
					innerjson.put(LocationConstants.STATE_ID, "2848");

				}
				else if(innerjson.getString(LocationConstants.ID).equals("34196")){
					hs.put(LocationConstants.STATE_ID, "2950");
					innerjson.put(LocationConstants.STATE_ID, "2950");

				}
				else if(innerjson.getString(LocationConstants.ID).equals("36162")){
					hs.put(LocationConstants.STATE_ID, "2986");
					innerjson.put(LocationConstants.STATE_ID, "2986");

				}
				else if(innerjson.getString(LocationConstants.ID).equals("38097")){
					hs.put(LocationConstants.STATE_ID, "3244");
					innerjson.put(LocationConstants.STATE_ID, "3244");

				}
				else if(innerjson.getString(LocationConstants.ID).equals("40027")){
					hs.put(LocationConstants.STATE_ID, "3634");
					innerjson.put(LocationConstants.STATE_ID, "3634");

				}
				else if(innerjson.getString(LocationConstants.ID).equals("41994")){
					hs.put(LocationConstants.STATE_ID, "3842");
					innerjson.put(LocationConstants.STATE_ID, "3842");

				}
				else if(innerjson.getString(LocationConstants.ID).equals("43877")){
					hs.put(LocationConstants.STATE_ID, "3930");
					innerjson.put(LocationConstants.STATE_ID, "3930");

				}
				else if(innerjson.getString(LocationConstants.ID).equals("45777")){
					hs.put(LocationConstants.STATE_ID, "3959");
					innerjson.put(LocationConstants.STATE_ID, "3959");

				}
				else if(innerjson.getString(LocationConstants.ID).equals("47576")){
					hs.put(LocationConstants.STATE_ID, "4120");
					innerjson.put(LocationConstants.STATE_ID, "4120");

				}
				else if(innerjson.getString(LocationConstants.ID).equals("48314")){
					hs.put(LocationConstants.STATE_ID, "3976");
					innerjson.put(LocationConstants.STATE_ID, "3976");

				}
				else {
					hs.put(LocationConstants.STATE_ID, innerjson.getString(LocationConstants.STATE_ID));
				}
				String countryId = getCountryIdFromStateId(array1,innerjson.getString(LocationConstants.STATE_ID));
				hs.put(LocationConstants.COUNTRY_ID, countryId);

				ZABModel.createRow(LocationConstants.CITIES_TABLE,CITIES_JSON.TABLE,hs);
			}
			}catch(Exception e){
				LOGGER.log(Level.SEVERE,e.getMessage(),e);
			}
	}
	
	public static String getCountryIdFromStateId(JSONArray array, String id){
		String countryId = "";
		try{
		for(int i = 0; i < array.length(); i++){
			JSONObject object = array.getJSONObject(i);
			if((object.getString("id")).equals(id)){
				return object.getString("country_id");
			}
		}
		}catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		return countryId;
	}
	
	public static void deviceDataPopulation(){
		try{
			
			ArrayList<HashMap<String, String>> myList = new ArrayList<HashMap<String, String>>();
			
			String deviceValue[] = {"Desktop","Mobile","Tablet"}; //No I18N

			for(int i=0;i<deviceValue.length;i++){
				HashMap<String, String> data = new HashMap<String, String>();
				data.put(DimensionConstants.DEVICE_VALUE, deviceValue[i]); //TODO
				data.put(DimensionConstants.DEVICE_CODE, i+"");
				myList.add(data);
			}
			
			ZABModel.createRow(DimensionConstants.DEVICE_DETAIL_CONSTANTS, DEVICE_DETAIL.TABLE, myList);
		}catch(Exception ex){
			ex.printStackTrace();
		}
	
	}
	
	public static void mobileDeviceDataPopulation(){
		try{
			
			ArrayList<HashMap<String, String>> myList = new ArrayList<HashMap<String, String>>();
			
			String mobileDeviceValue[] = {"Android","BlackBerry","IOS","Opera","Windows"};  //No I18N
			
			for(int i=0;i<mobileDeviceValue.length;i++){
				HashMap<String, String> data = new HashMap<String, String>();
				data.put(DimensionConstants.MOBILE_DEVICE_VALUE, mobileDeviceValue[i]); //TODO
				data.put(DimensionConstants.MOBILE_DEVICE_CODE, i+"");
				myList.add(data);
			}
			
			ZABModel.createRow(DimensionConstants.MOBILE_DEVICE_DETAIL_CONSTANTS, MOBILE_DEVICE_DETAIL.TABLE, myList);

		}catch(Exception ex){
			ex.printStackTrace();
		}
	
	}
	
	public static void countryDataPopulation(){
		try{
			
			ArrayList<HashMap<String, String>> myList = new ArrayList<HashMap<String, String>>();
			
			HashMap<String, String> data = new HashMap<String, String>();
			data.put(DimensionConstants.COUNTRY_VALUE , ReportRawDataConstants.UNKNOWN_VALUE); //TODO
			data.put(DimensionConstants.COUNTRY_DISPLAY_NAME, ReportRawDataConstants.UNKNOWN_VALUE);
			data.put(DimensionConstants.COUNTRY_CODE, "0");
			myList.add(data);
			
			String[] locales = Locale.getISOCountries();
			int i = 1;
			for (String countryCode : locales) {
				Locale obj = new Locale("", countryCode);
				HashMap<String, String> data1 = new HashMap<String, String>();
				data1.put(DimensionConstants.COUNTRY_VALUE , obj.getDisplayCountry()); //TODO
				data1.put(DimensionConstants.COUNTRY_DISPLAY_NAME, obj.getDisplayCountry());
				data1.put(DimensionConstants.COUNTRY_CODE, ""+i++);
				myList.add(data1);
				
			}
	
			
			ZABModel.createRow(DimensionConstants.COUNTRY_DETAIL_CONSTANTS, COUNTRY_DETAIL.TABLE, myList);

		}catch(Exception ex){
			ex.printStackTrace();
		}
	
	}
	
	public static void languageDataPopulation(){
		try{
			
			ArrayList<HashMap<String, String>> myList = new ArrayList<HashMap<String, String>>();
			
			HashMap<String, String> data = new HashMap<String, String>();
			data.put(DimensionConstants.LANGUAGE_VALUE , ReportRawDataConstants.UNKNOWN_VALUE); //TODO
			data.put(DimensionConstants.LANGUAGE_DISPLAY_NAME, ReportRawDataConstants.UNKNOWN_VALUE);
			data.put(DimensionConstants.LANGUAGE_CODE, "0");
			
			myList.add(data);
			
			String[] languages = Locale.getISOLanguages();
			Locale obj = null;
			int i = 1;
			for (String languageCode : languages) {
				
				obj = new Locale(languageCode);
				
				HashMap<String, String> data1 = new HashMap<String, String>();
				data1.put(DimensionConstants.LANGUAGE_VALUE , obj.getDisplayLanguage());
				data1.put(DimensionConstants.LANGUAGE_DISPLAY_NAME, obj.getDisplayLanguage());
				data1.put(DimensionConstants.LANGUAGE_CODE, ""+i++);
				myList.add(data1);
				
			}
			
			ZABModel.createRow(DimensionConstants.LANGUAGE_DETAIL_CONSTANTS, LANGUAGE_DETAIL.TABLE, myList);

		}catch(Exception ex){
			ex.printStackTrace();
		}
	
	}
	
	public static void audienceAttributeDataPopulation(){
		try{
			
			ArrayList<HashMap<String, String>> myList = new ArrayList<HashMap<String, String>>();
			
			for(AudienceAttributes attrib: AudienceAttributes.values()) {
				HashMap<String, String> data = new HashMap<String, String>();
				data.put(AudienceAttributeConstants.ATTRIBUTE_ID, attrib.getAudienceAttrId().toString());
				data.put(AudienceAttributeConstants.ATTRIBUTE_DISPLAYNAME, attrib.getDisplayName());
				data.put(AudienceAttributeConstants.ATTRIBUTE_KEYNAME, attrib.getKeyName());
				data.put(AudienceAttributeConstants.ATTRIBUTE_DESCRIPTION, attrib.getDescription());
				data.put(AudienceAttributeConstants.IS_DYNAMIC_ATTRIBUTE, attrib.getIsDynamicAttribute());
				myList.add(data);
			}

			ZABModel.createRow(AudienceAttributeConstants.AUDIENCE_ATTRIBUTE_TABLE, AUDIENCE_ATTRIBUTE.TABLE, myList);

		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	public static void audienceAttributeMatchTypeDataPopulation(){
		try{
			
			ArrayList<HashMap<String, String>> myList = new ArrayList<HashMap<String, String>>();
			
			HashMap<String, String> data1 = new HashMap<String, String>();
			data1.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");
			data1.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_NAME, "equals");

			HashMap<String, String> data2 = new HashMap<String, String>();
			data2.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");
			data2.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_NAME, "not equals");
			
			HashMap<String, String> data3 = new HashMap<String, String>();
			data3.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "3");
			data3.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_NAME, "contains");
			
			HashMap<String, String> data4 = new HashMap<String, String>();
			data4.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "4");
			data4.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_NAME, "does not contains");
			
			HashMap<String, String> data5 = new HashMap<String, String>();
			data5.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "5");
			data5.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_NAME, "is empty");
			
			HashMap<String, String> data6 = new HashMap<String, String>();
			data6.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "6");
			data6.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_NAME, "is not empty");
			
			
			HashMap<String, String> data7 = new HashMap<String, String>();
			data7.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "7");
			data7.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_NAME, "is undefined");
	
			myList.add(data1);
			myList.add(data2);
			myList.add(data3);
			myList.add(data4);
			myList.add(data5);
			myList.add(data6);
			myList.add(data7);
			
			
			ZABModel.createRow(AudienceAttributeConstants.AUDIENCE_ATTRIBUTE_MATCHTYPE_TABLE, AUDIENCE_ATTRIBUTE_MATCHTYPE.TABLE, myList);

		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	public static void audienceMatchTypeAttributeMappingDataPopulation(){
		try{
			
			ArrayList<HashMap<String, String>> myList = new ArrayList<HashMap<String, String>>();
			
			HashMap<String, String> data1 = new HashMap<String, String>();
			data1.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.CURRENT_URL.getAudienceAttrId().toString());
			data1.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

			HashMap<String, String> data2 = new HashMap<String, String>();
			data2.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.CURRENT_URL.getAudienceAttrId().toString());
			data2.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");

			HashMap<String, String> data3 = new HashMap<String, String>();
			data3.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.REFERRAL_URL.getAudienceAttrId().toString());
			data3.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

			HashMap<String, String> data4 = new HashMap<String, String>();
			data4.put(AudienceAttributeConstants.ATTRIBUTE_ID,  AudienceAttributes.REFERRAL_URL.getAudienceAttrId().toString());
			data4.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");

			HashMap<String, String> data5 = new HashMap<String, String>();
			data5.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.VISITOR_TYPE.getAudienceAttrId().toString());
			data5.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

			HashMap<String, String> data6 = new HashMap<String, String>();
			data6.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.VISITOR_TYPE.getAudienceAttrId().toString());
			data6.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");

			HashMap<String, String> data7 = new HashMap<String, String>();
			data7.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.COOKIE_VALUE.getAudienceAttrId().toString());
			data7.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

			HashMap<String, String> data8 = new HashMap<String, String>();
			data8.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.COOKIE_VALUE.getAudienceAttrId().toString());
			data8.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");

			HashMap<String, String> data9 = new HashMap<String, String>();
			data9.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.COOKIE_VALUE.getAudienceAttrId().toString());
			data9.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "3");

			HashMap<String, String> data10 = new HashMap<String, String>();
			data10.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.COOKIE_VALUE.getAudienceAttrId().toString());
			data10.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "4");

			HashMap<String, String> data11 = new HashMap<String, String>();
			data11.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.QUERY_PARAMETER.getAudienceAttrId().toString());
			data11.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

			HashMap<String, String> data12 = new HashMap<String, String>();
			data12.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.QUERY_PARAMETER.getAudienceAttrId().toString());
			data12.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");

			HashMap<String, String> data13 = new HashMap<String, String>();
			data13.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.QUERY_PARAMETER.getAudienceAttrId().toString());
			data13.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "3");

			HashMap<String, String> data14 = new HashMap<String, String>();
			data14.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.QUERY_PARAMETER.getAudienceAttrId().toString());
			data14.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "4");

			HashMap<String, String> data15 = new HashMap<String, String>();
			data15.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.OS.getAudienceAttrId().toString());
			data15.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

			HashMap<String, String> data16 = new HashMap<String, String>();
			data16.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.OS.getAudienceAttrId().toString());
			data16.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");

			HashMap<String, String> data17 = new HashMap<String, String>();
			data17.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.DEVICE.getAudienceAttrId().toString());
			data17.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

			HashMap<String, String> data18 = new HashMap<String, String>();
			data18.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.DEVICE.getAudienceAttrId().toString());
			data18.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");

			HashMap<String, String> data19 = new HashMap<String, String>();
			data19.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.MOBILE_OS.getAudienceAttrId().toString());
			data19.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

			HashMap<String, String> data20 = new HashMap<String, String>();
			data20.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.MOBILE_OS.getAudienceAttrId().toString());
			data20.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");

			HashMap<String, String> data21 = new HashMap<String, String>();
			data21.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.BROWSER.getAudienceAttrId().toString());
			data21.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

			HashMap<String, String> data22 = new HashMap<String, String>();
			data22.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.BROWSER.getAudienceAttrId().toString());
			data22.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");

			HashMap<String, String> data23 = new HashMap<String, String>();
			data23.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.USERAGENT.getAudienceAttrId().toString());
			data23.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

			HashMap<String, String> data24 = new HashMap<String, String>();
			data24.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.USERAGENT.getAudienceAttrId().toString());
			data24.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");

			HashMap<String, String> data25 = new HashMap<String, String>();
			data25.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.USERAGENT.getAudienceAttrId().toString());
			data25.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "3");

			HashMap<String, String> data26 = new HashMap<String, String>();
			data26.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.USERAGENT.getAudienceAttrId().toString());
			data26.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "4");

			HashMap<String, String> data27 = new HashMap<String, String>();
			data27.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.LOCATION.getAudienceAttrId().toString());
			data27.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

			HashMap<String, String> data28 = new HashMap<String, String>();
			data28.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.LOCATION.getAudienceAttrId().toString());
			data28.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");

			HashMap<String, String> data29 = new HashMap<String, String>();
			data29.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.DAY_OF_WEEK.getAudienceAttrId().toString());
			data29.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

			HashMap<String, String> data30 = new HashMap<String, String>();
			data30.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.DAY_OF_WEEK.getAudienceAttrId().toString());
			data30.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");

			HashMap<String, String> data31 = new HashMap<String, String>();
			data31.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.HOUR_OF_THE_DAY.getAudienceAttrId().toString());
			data31.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

			HashMap<String, String> data32 = new HashMap<String, String>();
			data32.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.HOUR_OF_THE_DAY.getAudienceAttrId().toString());
			data32.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");
			
			HashMap<String, String> data33 = new HashMap<String, String>();
			data33.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.JS_VARIABLE.getAudienceAttrId().toString());
			data33.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

			HashMap<String, String> data34 = new HashMap<String, String>();
			data34.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.JS_VARIABLE.getAudienceAttrId().toString());
			data34.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");
			
			HashMap<String, String> data35 = new HashMap<String, String>();
			data35.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.JS_VARIABLE.getAudienceAttrId().toString());
			data35.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "3");
			
			HashMap<String, String> data36 = new HashMap<String, String>();
			data36.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.JS_VARIABLE.getAudienceAttrId().toString());
			data36.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "4");
			
			HashMap<String, String> data37 = new HashMap<String, String>();
			data37.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.CUSTOM_DIMENSION.getAudienceAttrId().toString());
			data37.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

			HashMap<String, String> data38 = new HashMap<String, String>();
			data38.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.CUSTOM_DIMENSION.getAudienceAttrId().toString());
			data38.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");
			
			HashMap<String, String> data39 = new HashMap<String, String>();
			data39.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.CUSTOM_DIMENSION.getAudienceAttrId().toString());
			data39.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "3");
			
			HashMap<String, String> data40 = new HashMap<String, String>();
			data40.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.CUSTOM_DIMENSION.getAudienceAttrId().toString());
			data40.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "4");

			HashMap<String, String> data41 = new HashMap<String, String>();
			data41.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.ADWORDS_CAMPAIGN.getAudienceAttrId().toString());
			data41.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

			HashMap<String, String> data42 = new HashMap<String, String>();
			data42.put(AudienceAttributeConstants.ATTRIBUTE_ID,  AudienceAttributes.ADWORDS_CAMPAIGN.getAudienceAttrId().toString());
			data42.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");

			HashMap<String, String> data43 = new HashMap<String, String>();
			data43.put(AudienceAttributeConstants.ATTRIBUTE_ID,  AudienceAttributes.ADWORDS_GROUP.getAudienceAttrId().toString());
			data43.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

			HashMap<String, String> data44 = new HashMap<String, String>();
			data44.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.ADWORDS_GROUP.getAudienceAttrId().toString());
			data44.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");
			
//			HashMap<String, String> data45 = new HashMap<String, String>();
//			data45.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.AD_CAMPAIGN.getAudienceAttrId().toString());
//			data45.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");
//
//			HashMap<String, String> data46 = new HashMap<String, String>();
//			data46.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.AD_CAMPAIGN.getAudienceAttrId().toString());
//			data46.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");
//			
//			HashMap<String, String> data47 = new HashMap<String, String>();
//			data47.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.AD_CAMPAIGN.getAudienceAttrId().toString());
//			data47.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "3");
//
//			HashMap<String, String> data48 = new HashMap<String, String>();
//			data48.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.AD_CAMPAIGN.getAudienceAttrId().toString());
//			data48.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "4");
			
			HashMap<String, String> data49 = new HashMap<String, String>();
			data49.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.SOURCE.getAudienceAttrId().toString());
			data49.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

			HashMap<String, String> data50 = new HashMap<String, String>();
			data50.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.SOURCE.getAudienceAttrId().toString());
			data50.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");
			
			HashMap<String, String> data51 = new HashMap<String, String>();
			data51.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.SOURCE.getAudienceAttrId().toString());
			data51.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "3");

			HashMap<String, String> data52 = new HashMap<String, String>();
			data52.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.SOURCE.getAudienceAttrId().toString());
			data52.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "4");
			
			HashMap<String, String> data53 = new HashMap<String, String>();
			data53.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.JS_VARIABLE.getAudienceAttrId().toString());
			data53.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "5");
			
			HashMap<String, String> data54 = new HashMap<String, String>();
			data54.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.JS_VARIABLE.getAudienceAttrId().toString());
			data54.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "6");
			
			HashMap<String, String> data55 = new HashMap<String, String>();
			data55.put(AudienceAttributeConstants.ATTRIBUTE_ID, AudienceAttributes.JS_VARIABLE.getAudienceAttrId().toString());
			data55.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "7");
			
			myList.add(data1);
			myList.add(data2);
			myList.add(data3);
			myList.add(data4);
			myList.add(data5);
			myList.add(data6);
			myList.add(data7);
			myList.add(data8);
			myList.add(data9);
			myList.add(data10);
			myList.add(data11);
			myList.add(data12);
			myList.add(data13);
			myList.add(data14);
			myList.add(data15);
			myList.add(data16);
			myList.add(data17);
			myList.add(data18);
			myList.add(data19);
			myList.add(data20);
			myList.add(data21);
			myList.add(data22);
			myList.add(data23);
			myList.add(data24);
			myList.add(data25);
			myList.add(data26);
			myList.add(data27);
			myList.add(data28);
			myList.add(data29);
			myList.add(data30);
			myList.add(data31);
			myList.add(data32);
			myList.add(data33);
			myList.add(data34);
			myList.add(data35);
			myList.add(data36);
			myList.add(data37);
			myList.add(data38);
			myList.add(data39);
			myList.add(data40);
			myList.add(data41);
			myList.add(data42);
			myList.add(data43);
			myList.add(data44);
//			myList.add(data45);
//			myList.add(data46);
//			myList.add(data47);
//			myList.add(data48);
			myList.add(data49);
			myList.add(data50);
			myList.add(data51);
			myList.add(data52);
			myList.add(data53);
			myList.add(data54);
			myList.add(data55);
			
			ZABModel.createRow(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_MAPPING_TABLE, ATTRIBUTE_MATCHTYPE_MAPPING.TABLE, myList);

		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	public static void integrationDataPopulation(){
		try{
			
			ArrayList<HashMap<String, String>> myList = new ArrayList<HashMap<String, String>>();
			
			HashMap<String, String> data1 = new HashMap<String, String>();
			data1.put(IntegrationConstants.INTEGRATION_ID, "1");
			data1.put(IntegrationConstants.INTEGRATION_NAME, "Google Analytics");
			data1.put(IntegrationConstants.INTEGRATION_DESCRIPTION, " ");

			HashMap<String, String> data2 = new HashMap<String, String>();
			data2.put(IntegrationConstants.INTEGRATION_ID, "2");
			data2.put(IntegrationConstants.INTEGRATION_NAME, "Kissmetrics");
			data2.put(IntegrationConstants.INTEGRATION_DESCRIPTION, " ");
			
			HashMap<String, String> data3 = new HashMap<String, String>();
			data3.put(IntegrationConstants.INTEGRATION_ID, "3");
			data3.put(IntegrationConstants.INTEGRATION_NAME, "Mixpanel");
			data3.put(IntegrationConstants.INTEGRATION_DESCRIPTION, " ");
			
			HashMap<String, String> data4 = new HashMap<String, String>();
			data4.put(IntegrationConstants.INTEGRATION_ID, "4");
			data4.put(IntegrationConstants.INTEGRATION_NAME, "Google Adwords");
			data4.put(IntegrationConstants.INTEGRATION_DESCRIPTION, " ");
			
			HashMap<String, String> data5 = new HashMap<String, String>();
			data5.put(IntegrationConstants.INTEGRATION_ID, "5");
			data5.put(IntegrationConstants.INTEGRATION_NAME, "Clicky");
			data5.put(IntegrationConstants.INTEGRATION_DESCRIPTION, " ");
			
			HashMap<String, String> data6 = new HashMap<String, String>();
			data6.put(IntegrationConstants.INTEGRATION_ID, "6");
			data6.put(IntegrationConstants.INTEGRATION_NAME, "Google Tag Manager");
			data6.put(IntegrationConstants.INTEGRATION_DESCRIPTION, " ");

			
			myList.add(data1);
			myList.add(data2);
			myList.add(data3);
			myList.add(data4);
			myList.add(data5);
			myList.add(data6);


			
			ZABModel.createRow(IntegrationConstants.INTEGRATION_TABLE, INTEGRATION.TABLE, myList);

		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	public static void audienceDataPopulation(){
		try{
			
			ArrayList<HashMap<String, String>> myList = new ArrayList<HashMap<String, String>>();
			
			String linkName = null;
			HashMap<String, String> data1 = new HashMap<String, String>();
			
			data1.put(AudienceConstants.AUDIENCE_NAME, "All Visitors"); //No I18N
			linkName = ZABModel.generateLinkName(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME, null, null, "All");//No I18N
			data1.put(AudienceConstants.AUDIENCE_LINKNAME, linkName);
			data1.put(AudienceConstants.AUDIENCE_DESCRIPTION, "All the visitors reaching your website.");
			data1.put(AudienceConstants.AUDIENCE_CONDITION_JSON, "{}");
			data1.put(AudienceConstants.AUDIENCE_IS_COUNTRY, Boolean.FALSE.toString());
			data1.put(AudienceConstants.AUDIENCE_IS_PRESET, Boolean.TRUE.toString());
					
			HashMap<String, String> data2 = new HashMap<String, String>();
			data2.put(AudienceConstants.AUDIENCE_NAME, "Direct Visitors"); //No I18N
			linkName = ZABModel.generateLinkName(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME, null, null, "Direct");//No I18N
			data2.put(AudienceConstants.AUDIENCE_LINKNAME, linkName);
			data2.put(AudienceConstants.AUDIENCE_DESCRIPTION, "Visitors who come to your website using bookmarks, browser history, favourites or direct URL entry.");
			data2.put(AudienceConstants.AUDIENCE_CONDITION_JSON, "{\"conditions\":[{\"conditions\":[{\"values\":[\"direct visitors\"],\"type\":\"source\",\"operator\":1}],\"condition_type\":1}],\"condition_type\":1}");
			data2.put(AudienceConstants.AUDIENCE_IS_COUNTRY, Boolean.FALSE.toString());
			data2.put(AudienceConstants.AUDIENCE_IS_PRESET, Boolean.TRUE.toString());

			HashMap<String, String> data3 = new HashMap<String, String>();
			data3.put(AudienceConstants.AUDIENCE_NAME, "Referral Traffic"); //No I18N
			linkName = ZABModel.generateLinkName(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME, null, null, "Referral");//No I18N
			data3.put(AudienceConstants.AUDIENCE_LINKNAME, linkName);
			data3.put(AudienceConstants.AUDIENCE_DESCRIPTION, "Visitors from links, buttons or ads put up in other websites");
			data3.put(AudienceConstants.AUDIENCE_CONDITION_JSON, "{\"conditions\":[{\"conditions\":[{\"values\":[\"referral traffic\"],\"type\":\"source\",\"operator\":2}],\"condition_type\":1}],\"condition_type\":1}");
			data3.put(AudienceConstants.AUDIENCE_IS_COUNTRY, Boolean.FALSE.toString());
			data3.put(AudienceConstants.AUDIENCE_IS_PRESET, Boolean.TRUE.toString());

					
			HashMap<String, String> data4 = new HashMap<String, String>();
			data4.put(AudienceConstants.AUDIENCE_NAME, "Social Traffic"); //No I18N
			linkName = ZABModel.generateLinkName(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME, null, null, "Social");//No I18N
			data4.put(AudienceConstants.AUDIENCE_LINKNAME, linkName);
			data4.put(AudienceConstants.AUDIENCE_DESCRIPTION, "Visitors from social media sites (Facebook, Linkedin, Twitter and Google Plus)");
			data4.put(AudienceConstants.AUDIENCE_CONDITION_JSON, "{\"conditions\":[{\"conditions\":[{\"values\":[\"social traffic\"],\"type\":\"source\",\"operator\":1}],\"condition_type\":1}],\"condition_type\":1}");
			data4.put(AudienceConstants.AUDIENCE_IS_COUNTRY, Boolean.FALSE.toString());
			data4.put(AudienceConstants.AUDIENCE_IS_PRESET, Boolean.TRUE.toString());

					
			/*HashMap<String, String> data5 = new HashMap<String, String>();
			data5.put(AudienceConstants.AUDIENCE_NAME, "Search Engine Traffic"); //No I18N
			linkName = ZABModel.generateLinkName(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME, null, null, "Search Engine");//No I18N
			data5.put(AudienceConstants.AUDIENCE_LINKNAME, linkName);
			data5.put(AudienceConstants.AUDIENCE_DESCRIPTION, "Visitors who landed on your website by clicking on web search results"); //No I18N
			data5.put(AudienceConstants.AUDIENCE_CONDITION_JSON, "{\"conditions\":[{\"conditions\":[{\"values\":[\"google.com\",\"yahoo.com\",\"bing.com\",\"aol.com\",\"aolsearch.com\",\"ask.com\",\"lycos.com\",\"about.com\",\"baidu.com\",\"yandex.\",\"seznam.cz\"],\"type\":\"referral_url\",\"operator\":1}],\"condition_type\":1}],\"condition_type\":1}");
			data5.put(AudienceConstants.AUDIENCE_IS_COUNTRY, Boolean.FALSE.toString());
			data5.put(AudienceConstants.AUDIENCE_IS_PRESET, Boolean.TRUE.toString());
		     */
					
			HashMap<String, String> data6 = new HashMap<String, String>();
			data6.put(AudienceConstants.AUDIENCE_NAME, "Mobile and Tablet Traffic"); //No I18N
			linkName = ZABModel.generateLinkName(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME, null, null, "Mobile and Tablet");//No I18N
			data6.put(AudienceConstants.AUDIENCE_LINKNAME, linkName);
			data6.put(AudienceConstants.AUDIENCE_DESCRIPTION, "Visitors from mobiles and tablets"); //No I18N
			data6.put(AudienceConstants.AUDIENCE_CONDITION_JSON, "{\"conditions\":[{\"conditions\":[{\"values\":[\"mobile\",\"tablet\"],\"type\":\"device_type\",\"operator\":1}],\"condition_type\":1}],\"condition_type\":1}");
			data6.put(AudienceConstants.AUDIENCE_IS_COUNTRY, Boolean.FALSE.toString());
			data6.put(AudienceConstants.AUDIENCE_IS_PRESET, Boolean.TRUE.toString());

					
			HashMap<String, String> data7 = new HashMap<String, String>();
			data7.put(AudienceConstants.AUDIENCE_NAME, "Desktop Visitors"); //No I18N
			linkName = ZABModel.generateLinkName(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME, null, null, "Desktop");//No I18N
			data7.put(AudienceConstants.AUDIENCE_LINKNAME, linkName);
			data7.put(AudienceConstants.AUDIENCE_DESCRIPTION, "Visitors from Desktop Devices"); //No I18N
			data7.put(AudienceConstants.AUDIENCE_CONDITION_JSON, "{\"conditions\":[{\"conditions\":[{\"values\":[\"desktop\"],\"type\":\"device_type\",\"operator\":1}],\"condition_type\":1}],\"condition_type\":1}");
			data7.put(AudienceConstants.AUDIENCE_IS_COUNTRY, Boolean.FALSE.toString());			
			data7.put(AudienceConstants.AUDIENCE_IS_PRESET, Boolean.TRUE.toString());

					
			HashMap<String, String> data8 = new HashMap<String, String>();
			data8.put(AudienceConstants.AUDIENCE_NAME, "New Visitors"); //No I18N
			linkName = ZABModel.generateLinkName(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME, null, null, "New");//No I18N
			data8.put(AudienceConstants.AUDIENCE_LINKNAME, linkName);
			data8.put(AudienceConstants.AUDIENCE_DESCRIPTION, "Visitors who are landing on your website for the first time."); //No I18N
			data8.put(AudienceConstants.AUDIENCE_CONDITION_JSON, "{\"conditions\":[{\"conditions\":[{\"values\":[\"new\"],\"type\":\"visitor_type\",\"operator\":1}],\"condition_type\":1}],\"condition_type\":1}");
			data8.put(AudienceConstants.AUDIENCE_IS_COUNTRY, Boolean.FALSE.toString());
			data8.put(AudienceConstants.AUDIENCE_IS_PRESET, Boolean.TRUE.toString());

			HashMap<String, String> data9 = new HashMap<String, String>();
			data9.put(AudienceConstants.AUDIENCE_NAME, "Returning Visitors"); //No I18N
			linkName = ZABModel.generateLinkName(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME, null, null, "Returning");//No I18N
			data9.put(AudienceConstants.AUDIENCE_LINKNAME, linkName);
			data9.put(AudienceConstants.AUDIENCE_DESCRIPTION, "Prior visitors, who return to your website."); //No I18N
			data9.put(AudienceConstants.AUDIENCE_CONDITION_JSON, "{\"conditions\":[{\"conditions\":[{\"values\":[\"returning\"],\"type\":\"visitor_type\",\"operator\":1}],\"condition_type\":1}],\"condition_type\":1}");
			data9.put(AudienceConstants.AUDIENCE_IS_COUNTRY, Boolean.FALSE.toString());
			data9.put(AudienceConstants.AUDIENCE_IS_PRESET, Boolean.TRUE.toString());	
			
			HashMap<String, String> data10 = new HashMap<String, String>();
			data10.put(AudienceConstants.AUDIENCE_NAME, "Organic Search"); //No I18N
			linkName = ZABModel.generateLinkName(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME, null, null, "Organic Search");//No I18N
			data10.put(AudienceConstants.AUDIENCE_LINKNAME, linkName);
			data10.put(AudienceConstants.AUDIENCE_DESCRIPTION, "Visitors who landed on your website by clicking on web search results"); //No I18N
			data10.put(AudienceConstants.AUDIENCE_CONDITION_JSON, "{\"conditions\":[{\"conditions\":[{\"values\":[\"organic search\"],\"type\":\"source\",\"operator\":1}],\"condition_type\":1}],\"condition_type\":1}");
			data10.put(AudienceConstants.AUDIENCE_IS_COUNTRY, Boolean.FALSE.toString());
			data10.put(AudienceConstants.AUDIENCE_IS_PRESET, Boolean.TRUE.toString());

			HashMap<String, String> data11 = new HashMap<String, String>();
			data11.put(AudienceConstants.AUDIENCE_NAME, "Paid Campaigns"); //No I18N
			linkName = ZABModel.generateLinkName(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_LINK_NAME, null, null, "Paid Search");//No I18N
			data11.put(AudienceConstants.AUDIENCE_LINKNAME, linkName);
			data11.put(AudienceConstants.AUDIENCE_DESCRIPTION, "Visitors reaching the webpage through Pay Per Click campaigns"); //No I18N
			data11.put(AudienceConstants.AUDIENCE_CONDITION_JSON, "{\"conditions\":[{\"conditions\":[{\"values\":[\"paid search\"],\"type\":\"source\",\"operator\":1}],\"condition_type\":1}],\"condition_type\":1}");
			data11.put(AudienceConstants.AUDIENCE_IS_COUNTRY, Boolean.FALSE.toString());
			data11.put(AudienceConstants.AUDIENCE_IS_PRESET, Boolean.TRUE.toString());
			
			myList.add(data1);
			myList.add(data2);
			myList.add(data3);
			myList.add(data4);
			//myList.add(data5);
			myList.add(data6);
			myList.add(data7);
			myList.add(data8);
			myList.add(data9);
			myList.add(data10);
			myList.add(data11);

			
			ZABModel.createRow(AudienceConstants.AUDIENCE_TABLE, AUDIENCE.TABLE, myList);
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
}
