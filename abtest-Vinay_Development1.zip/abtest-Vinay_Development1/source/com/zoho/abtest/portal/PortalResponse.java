//$Id$
package com.zoho.abtest.portal;

import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;
import com.zoho.abtest.project.ProjectConstants;
import com.zoho.abtest.utility.ZABUtil;

public class PortalResponse 
{
	private static final Logger LOGGER = Logger.getLogger(PortalResponse.class.getName());
	
	public static String jsonResponse(HttpServletRequest request,List<Portal> portals) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(portals);			
			JSONObject json = ZABResponse.updateMetaInfo(request, PortalConstants.API_MODULE_PLURAL, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		return returnBuffer.toString();
	}
	
	public static JSONArray getJSONArray(List<Portal> portals) throws JSONException {
		JSONArray array = new JSONArray();
		int size =portals.size();
		for (int i=0;i<size;i++) {
			Portal portal = portals.get(i);
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(PortalConstants.PORTALNAME, portal.getPortalName());
			jsonObj.put(PortalConstants.DOMAINNAME, portal.getDomainName());
			jsonObj.put(PortalConstants.ZSOID, portal.getZsoid());
			jsonObj.put(PortalConstants.CREATEDBY, portal.getCreatedBy());
			jsonObj.put(PortalConstants.CREATEDBYNAME, portal.getCreatedByName());
			jsonObj.put(PortalConstants.CREATEDTIME, portal.getCreatedTime());
			if(portal.getCreatedTime() != null)
			{
				HashMap<String, String> formattedTimes = ZABUtil.getDateTimeAllFormatted(portal.getCreatedTime());
				String formattedDateOnly = formattedTimes.get(ZABConstants.DATE);
				jsonObj.put(PortalConstants.CREATEDDATE, formattedDateOnly);
			}
			jsonObj.put(PortalConstants.ISDEFAULT, portal.isDefault());
			jsonObj.put(PortalConstants.ISSIGNUP, portal.getIsSignUp());
			jsonObj.put(PortalConstants.ISZOHOONE, portal.getIsZohoOne());
			jsonObj.put(PortalConstants.ZOHOONE_USERINVITE_LINK, portal.getZohoOneUserInviteLink());
			jsonObj.put(PortalConstants.SUBSCRIPTION_LINK, portal.getSubscriptionLink());
			jsonObj.put(PortalConstants.PLAN_NAME, portal.getPlanName());
			jsonObj.put(PortalConstants.IS_APP_ACTIVE, portal.getIsAppActive());
			jsonObj.put(ProjectConstants.API_MODULE_USAGE_SINGULAR, portal.getDomainName());

			jsonObj.put(ZABConstants.RESPONSE_STRING, portal.getResponseString());
			jsonObj.put(ZABConstants.STATUS_CODE, portal.getResponseCode());
			jsonObj.put(ZABConstants.SUCCESS, portal.getSuccess());
			
			jsonObj.put(ProjectConstants.PROJECT_NAME, portal.getProjectName());
			jsonObj.put(ProjectConstants.PROJECT_LINKNAME, portal.getProjectLinkName());
			jsonObj.put(ProjectConstants.PROJECT_KEY, portal.getProjectKey());
			jsonObj.put(ProjectConstants.PROJECT_ID, portal.getProjectId());
			
			jsonObj.put(PortalConstants.ZOHOONE_CAN_SHOW_LAUNCHER, portal.getCanShowOneLauncher());
			jsonObj.put(PortalConstants.ZOHOONE_LAUNCHER_URL, portal.getOneLauncherUrl());
			
			
			array.put(jsonObj);
		}
		return array;
	}
}
