//$Id$
package com.zoho.abtest.image;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;
import com.zoho.abtest.user.ZABUser;
import com.zoho.abtest.utility.ZABUtil;

public class ImageUploadResponse {
	private static final Logger LOGGER = Logger.getLogger(ImageUploadResponse.class.getName());
	public static String jsonResponse(HttpServletRequest request,ArrayList<ImageUpload> lst) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(lst);			
			JSONObject json = ZABResponse.updateMetaInfo(request, ImageUploadConstants.API_MODULE_PLURAL, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){
			
			LOGGER.log(Level.SEVERE, "Exception occured: ",ex);
			
		}
		return returnBuffer.toString();
	}
	
	public static JSONArray getJSONArray(ArrayList<ImageUpload> lst) throws JSONException {
		JSONArray array = new JSONArray();
		int size =lst.size();
		for (int i=0;i<size;i++) {
			ImageUpload ld=lst.get(i);
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(ImageUploadConstants.IMAGE_NAME, ld.getImageName());
			jsonObj.put(ImageUploadConstants.CDN_IMAGE_URL, ld.getImageUrl());
			jsonObj.put(ImageUploadConstants.ZFS_IMAGE_URL, ld.getZfsUrl());
			jsonObj.put(ImageUploadConstants.CREATED_TIME, ZABUtil.getDateTimeFormatted(ld.getCreatedTime()));
			jsonObj.put(ImageUploadConstants.CREATED_BY, ZABUser.getUserName(ld.getCreatedBy()));
			jsonObj.put(ZABConstants.SUCCESS, ld.getSuccess());
			array.put(jsonObj);
		}
		return array;
	}
}
