//$Id$
package com.zoho.abtest.image;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.json.JSONException;
import org.json.JSONObject;

import com.adventnet.iam.IAMUtil;
import com.adventnet.iam.security.SecurityUtil;
import com.adventnet.iam.security.UploadedFileItem;
import com.adventnet.mfw.bean.BeanUtil;
import com.opensymphony.xwork2.ActionSupport;
import com.zoho.abtest.cdn.ZABCDN;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.project.ProjectConstants;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.conf.Configuration;

public class ImageUploadAction extends ActionSupport implements ServletResponseAware, ServletRequestAware{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = Logger.getLogger(ImageUploadAction.class.getName());

	private HttpServletRequest request;
	
	private HttpServletResponse response;
	
	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		request = arg0;
	}

	@Override
	public void setServletResponse(HttpServletResponse arg0) {
		response = arg0;
	}
	
	public String execute() throws IOException, JSONException  {
		ArrayList<ImageUpload> imageUploads = new ArrayList<ImageUpload>();
		try {			
			switch(ZABAction.getHTTPMethod(request)) {
			case POST:	
				if(request.getAttribute ( SecurityUtil.MULTIPART_FORM_REQUEST ) != null ) {
					ArrayList<UploadedFileItem> filesList = (ArrayList<UploadedFileItem>) request.getAttribute (SecurityUtil.MULTIPART_FORM_REQUEST );
					File file = filesList.get(0).getUploadedFile();
					
//					ZABCDN cdn = (ZABCDN)BeanUtil.lookup("ZABCDN");
//					String fileName = cdn.createFile(filesList.get(0).getFileName(), file, IAMUtil.getCurrentUser().getZUID(), ZABUtil.getCurrentUserDbSpace());
//					JSONObject json = new JSONObject();
//					json.put("file_url", "http://"+InetAddress.getLocalHost().getHostName()+":8080/images/"+ZABUtil.getCurrentUserDbSpace()+"/"+fileName);
//					response.getWriter().append(json.toString());
					
					ImageUpload upload = ImageUpload.createImageUpload(filesList.get(0).getFileName(), file);
					imageUploads.add(upload);
					
				}
				break;
			case GET:
				imageUploads.addAll(ImageUpload.getImageUploads());
				break;
			case DELETE:
				
				break;
			case PUT:
				break;
			}
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE, "Exception occured: ",ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ImageUploadConstants.API_MODULE_PLURAL));
			return null; 	
		}		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getImageUploadResponse(request, imageUploads));		
	    return null;
	}

}
