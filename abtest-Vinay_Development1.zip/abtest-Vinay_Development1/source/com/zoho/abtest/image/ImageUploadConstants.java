//$Id$
package com.zoho.abtest.image;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.zoho.abtest.IMAGE_UPLOAD_DETAILS;
import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.ZABConstants;

public class ImageUploadConstants {
	
	public static final String API_MODULE = "imageupload"; //No I18N
	
	public static final String API_MODULE_PLURAL = "imageuploads"; //No I18N
	
	public static final String IMAGE_NAME = "image_name"; //No I18N
	
	public static final String CDN_IMAGE_URL = "cdn_image_url"; //No I18N
	
	public static final String ZFS_IMAGE_URL = "zfs_image_url"; //No I18N
	
	public static final String CREATED_BY = "created_by"; //No I18N
	
	public static final String CREATED_TIME = "created_time"; //No I18N
	
	public final static List<Constants> IMAGE_UPLOADS_TABLE;
	static {
		ArrayList<Constants> list = new ArrayList<Constants>();
		list.add(new Constants(IMAGE_NAME,IMAGE_UPLOAD_DETAILS.IMAGE_NAME,ZABConstants.STRING,Boolean.TRUE));
		list.add(new Constants(CDN_IMAGE_URL,IMAGE_UPLOAD_DETAILS.CDN_IMAGE_URL,ZABConstants.STRING,Boolean.TRUE));
		list.add(new Constants(ZFS_IMAGE_URL,IMAGE_UPLOAD_DETAILS.ZFS_IMAGE_URL,ZABConstants.STRING,Boolean.TRUE));
		list.add(new Constants(CREATED_BY,IMAGE_UPLOAD_DETAILS.CREATED_BY,ZABConstants.LONG,Boolean.FALSE));
		list.add(new Constants(CREATED_TIME,IMAGE_UPLOAD_DETAILS.CREATED_TIME,ZABConstants.LONG,Boolean.FALSE));
		IMAGE_UPLOADS_TABLE = (List<Constants>) Collections.unmodifiableList(list);
	}
}
