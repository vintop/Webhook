//$Id$
package com.zoho.abtest.image;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.iam.IAMUtil;
import com.adventnet.mfw.bean.BeanUtil;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.IMAGE_UPLOAD_DETAILS;
import com.zoho.abtest.cdn.ZABCDN;
import com.zoho.abtest.cdn.ZPFS;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.utility.ApplicationProperty;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.conf.Configuration;

public class ImageUpload extends ZABModel{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final Logger LOGGER = Logger.getLogger(ImageUpload.class.getName());

	private String imageName;
	
	private String imageUrl;
	
	private String zfsUrl;
	
	private Long createdBy;
	
	private Long createdTime;

	public String getZfsUrl() {
		return zfsUrl;
	}

	public void setZfsUrl(String zfsUrl) {
		this.zfsUrl = zfsUrl;
	}

	public Long getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Long createdTime) {
		this.createdTime = createdTime;
	}

	public String getImageName() {
		return imageName;
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public Long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}
	
	public static ImageUpload getImageUploadFromRow(Row row) {
		ImageUpload upload = new ImageUpload();
		upload.setImageName((String)row.get(IMAGE_UPLOAD_DETAILS.IMAGE_NAME));
		upload.setImageUrl(ApplicationProperty.getString(ZABConstants.CDN_BASE_URL) + (String)row.get(IMAGE_UPLOAD_DETAILS.CDN_IMAGE_URL));
		upload.setZfsUrl(ApplicationProperty.getString(ZABConstants.ZPFS_URL) + (String)row.get(IMAGE_UPLOAD_DETAILS.ZFS_IMAGE_URL));
		upload.setSuccess(Boolean.TRUE);
		upload.setCreatedTime((Long)row.get(IMAGE_UPLOAD_DETAILS.CREATED_TIME));
		upload.setCreatedBy((Long)row.get(IMAGE_UPLOAD_DETAILS.CREATED_BY));
		return upload;
	}
	
	public static ImageUpload createImageUpload(String fileName, File file) {
		ImageUpload imageUpload = new ImageUpload();
		try {
			ZABCDN cdn = (ZABCDN)BeanUtil.lookup("ZABCDN");
			String currentPortal = IAMUtil.getCurrentServiceOrg().getDomains().get(0).getDomain();
			String imageUrl = cdn.createFile(fileName, file, IAMUtil.getCurrentUser().getZUID(), currentPortal);
			//TODO: Need to check we necessarily need to use ZFS or ZPFS is fine
			ZPFS zpfs = new ZPFS();
			String zfsImageUrl = zpfs.createFile(fileName, file, IAMUtil.getCurrentUser().getZUID(), currentPortal);
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(ImageUploadConstants.IMAGE_NAME, fileName);
			hs.put(ImageUploadConstants.CDN_IMAGE_URL, imageUrl);
			hs.put(ImageUploadConstants.ZFS_IMAGE_URL, zfsImageUrl);
			hs.put(ImageUploadConstants.CREATED_BY, ZABUtil.getCurrentUser().getUserId()+"");
			hs.put(ImageUploadConstants.CREATED_TIME, ZABUtil.getCurrentTimeInMilliSeconds()+"");
			DataObject dobj = createRow(ImageUploadConstants.IMAGE_UPLOADS_TABLE, IMAGE_UPLOAD_DETAILS.TABLE, hs);
			Row row = dobj.getFirstRow(IMAGE_UPLOAD_DETAILS.TABLE);
			imageUpload = getImageUploadFromRow(row);
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Exception occured: ",e);
			imageUpload.setSuccess(Boolean.FALSE);
			imageUpload.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
		}
		return imageUpload;
	}
	
	public static ArrayList<ImageUpload> getImageUploads() {
		 ArrayList<ImageUpload> imageUploads = new ArrayList<ImageUpload>();
		try {
			DataObject dobj = getRow(IMAGE_UPLOAD_DETAILS.TABLE, null);
			Iterator it = dobj.getRows(IMAGE_UPLOAD_DETAILS.TABLE);
			while(it.hasNext()) {
				Row row = (Row)it.next(); 
				imageUploads.add(getImageUploadFromRow(row));
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Exception occured: ",e);
			ImageUpload imageUpload = new ImageUpload();
			imageUpload.setSuccess(Boolean.FALSE);
			imageUpload.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			imageUploads.add(imageUpload);
		}
		return imageUploads;
	}
	
}
