//$Id$
package com.zoho.abtest.elastic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import com.zoho.abtest.audience.AudienceAttributeConstants.AudienceAttributeMatchTypes;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentType;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.report.ReportConstants;
import com.zoho.abtest.sessionrecording.SessionReportConstants;

public class ESQuickFilterConstants 
{
	
	/**
	 * Params
	 * field - field name
	 * timezone - Timezone of user
	 * 
	 */
	public static final String DAY_OF_WEEK_SCRIPT = "LocalDateTime.ofInstant(Instant.ofEpochMilli(doc[params.field].value), TimeZone.getTimeZone(params.timezone).toZoneId()).getDayOfWeek()"; //NO I18N
	public static final String HOUR_OF_DAY_SCRIPT = "LocalDateTime.ofInstant(Instant.ofEpochMilli(doc[params.field].value), TimeZone.getTimeZone(params.timezone).toZoneId()).getHour()"; //NO I18N
	public static final String DEFAULT_TIME_ZONE = "UTC"; //NO I18N
	public static final String PAINLESS_LANG = "painless"; //NO I18N
	public static final String TIMEZONE = "timezone"; //NO I18N
	public static final String VALUES = "values"; //NO I18N
	public static final String FIELD = "field"; //NO I18N
	public static final String EXPERIMENT_URL = "qf_url"; //NO I18N
	public static final String VARIATION_LINKNAME = "qf_variation_linkname"; //NO I18N
	public static final String QF_DEVICE = "qf_device"; //NO I18N
	
	public static final String SEGMENT_NAME = "segment_name"; //NO I18N
	
	public static final String QF_MATCH_TYPE = "qf_match_type"; //NO I18N
	
	public static final String ATTRIBUTE_MATCHTYPE_ID = "attribute_matchtype_id"; //No I18N
	
	public static final String ATTRIBUTE_MATCHTYPE_NAME = "attribute_matchtype_name"; //No I18N
	
	public static final String QF_BOUND_UNITS = "qf_bound_units"; //No I18N
	
	public static final String QF_UNIT_KEY = "qf_unit_key"; //No I18N
	
	public static final String QF_UNIT_DISPLAY_NAME = "qf_unit_display_name"; //No I18N
	
	public static final String NEW_VISITOR = "NEW"; //NO I18N
	
	public static final String RETURNING_VISITOR = "RETURNING"; //NO I18N
	
	public static final String[] DOW = {"SUNDAY", "MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY"}; //NO I18N
	
	public static final List<String> TRAFFIC_SOURCE_POSSIBLE_VALS = Arrays.asList("DIRECT", "CAMPAIGN", "REFERRAL", "SEARCH", "SOCIAL"); //NO I18N
	
	public static final List<String> DEVICE_TYPE_POSSIBLE_VALS = Arrays.asList("DESKTOP", "MOBILE", "TABLET"); //NO I18N
	
	public static final List<String> USER_TYPE_POSSIBLE_VALS = Arrays.asList(NEW_VISITOR, RETURNING_VISITOR);
	
	public static final HashMap<ExperimentType, String> ES_INDEX_MAP;
	
	static {
		ES_INDEX_MAP = new HashMap<ExperimentType, String>();
		ES_INDEX_MAP.put(ExperimentType.ABTEST, ElasticSearchConstants.VISITOR_RAW_TYPE);
		ES_INDEX_MAP.put(ExperimentType.SPLITURL, ElasticSearchConstants.VISITOR_RAW_TYPE);
		ES_INDEX_MAP.put(ExperimentType.HEATMAP, ElasticSearchConstants.VISITOR_RAW_TYPE);
		ES_INDEX_MAP.put(ExperimentType.FUNNEL, ElasticSearchConstants.FUNNEL_RAW_TYPE);
		ES_INDEX_MAP.put(ExperimentType.FORMANALYTICS, ElasticSearchConstants.FORM_ANALYTICS_RAW_TYPE);
		ES_INDEX_MAP.put(ExperimentType.SESSION_RECORDING, ElasticSearchConstants.SESSION_RAW_DATA_TYPE);
	}
	
	
	public enum QuickFilterBoundValues {
		SECONDS("seconds", "audience.bounds.seconds"), //No I18N
		MINUTES("minutes", "audience.bounds.minutes"); //No I18N
		
		private String key;
		
		private String displayNameKey;

		public String getKey() {
			return key;
		}

		public void setKey(String key) {
			this.key = key;
		}

		public String getDisplayNameKey() {
			return displayNameKey;
		}

		public void setDisplayNameKey(String displayNameKey) {
			this.displayNameKey = displayNameKey;
		}

		public String getDisplayName() {
			return ZABAction.getMessage(displayNameKey);
		}
		
		QuickFilterBoundValues(String key, String displayNameKey) {
			this.key = key;
			this.displayNameKey = displayNameKey;
		}
		
		public static QuickFilterBoundValues getQuickFilterAttributeByLinkname(String key) {
			for(QuickFilterBoundValues qat: QuickFilterBoundValues.values()) {
				if(key!=null && qat.getKey().equals(key)) {
					return qat;
				}
			}
			return null;
		}
	}
	
	public enum QuickFilterAttributes
	{
		//Order of attrs - Displayname,linkname,type,isabsplit,isheatmap,isfunnel
		//Type - used in Quick filter UI to show -  1 Checkbox, 2 Range, 3 Nested, 4 Text
		USERTYPE("audience.attribute.visitor_type.name","usertype","usertype",1), //NO I18N
		TRAFFICSOURCE("audience.attribute.source.name","trafficsource","trafficsource",1), //NO I18N
		COUNTRY("audience.attribute.country.name","country","location",3), //NO I18N
		DEVICE("audience.attribute.device.name","device","device",1), //NO I18N
		BROWSER("audience.attribute.browser.name","browser","browser",1), //NO I18N
//		City is commented out as it will be residing under nested format.
		CITY("City","city","city",1), //NO I18N
		OS("audience.attribute.os.name","os","os",1), //NO I18N
		DAYOFWEEK("audience.attribute.day_of_week.name",ReportConstants.SEGMENT_DOW,ReportConstants.SEGMENT_DOW,2), //NO I18N
		HOUROFDAY("audience.attribute.hour_of_the_day.name",ReportConstants.SEGMENT_HOD,ReportConstants.SEGMENT_HOD,2), //NO I18N
		
		//Session Quickfilters
		TIMESPENT("audience.attribute.timespent.name",SessionReportConstants.TIMESPENT,SessionReportConstants.TIMESPENT,7), //NO I18N
		PAGECOUNT("audience.attribute.pagecount.name",SessionReportConstants.PAGECOUNT,SessionReportConstants.PAGECOUNT,6), //NO I18N
		URLVISITED("audience.attribute.urlvisited.name",SessionReportConstants.URLVISITED,SessionReportConstants.URLVISITED,5), //NO I18N
		ENTRYPAGE("audience.attribute.entrypage.name",ElasticSearchConstants.CURRENTURL,ElasticSearchConstants.CURRENTURL,5), //NO I18N
		EXITPAGE("audience.attribute.exitpage.name",ElasticSearchConstants.LAST_URL_VISITED,ElasticSearchConstants.LAST_URL_VISITED,5), //NO I18N
		GOALS("audience.attribute.goals.name",SessionReportConstants.GOALS,SessionReportConstants.GOALS,1); //NO I18N
//		GOOGLEADWORDS("Google Adwords","adwords","adwords",3,false,false,true,true, false); //NO I18N
		
		private String displayNameKey;
		private String linkName;
		private String segmentName;
		private int uiType;
		
		private  QuickFilterAttributes(String displayName,String linkName, String segmentName,int uiType)
		{
			this.displayNameKey = displayName;
			this.linkName = linkName;
			this.uiType = uiType;
			this.segmentName = segmentName;
		}
		
		public static QuickFilterAttributes getQuickFilterAttributeByLinkname(String linkname) {
			for(QuickFilterAttributes qat: QuickFilterAttributes.values()) {
				if(linkname!=null && qat.getLinkName().equals(linkname)) {
					return qat;
				}
			}
			return null;
		}
		
		public List<AudienceAttributeMatchTypes> getMatchTypes() {
			List<AudienceAttributeMatchTypes> matchTypes = new ArrayList<AudienceAttributeMatchTypes>();
			switch(this) {
			 case TIMESPENT:
				 matchTypes.add(AudienceAttributeMatchTypes.LESSTHAN);
				 matchTypes.add(AudienceAttributeMatchTypes.MORETHAN);
				 matchTypes.add(AudienceAttributeMatchTypes.BETWEEN);
				 break;
			 case PAGECOUNT:
				 matchTypes.add(AudienceAttributeMatchTypes.LESSTHAN);
				 matchTypes.add(AudienceAttributeMatchTypes.MORETHAN);
				 matchTypes.add(AudienceAttributeMatchTypes.BETWEEN);
				 break;
			 case URLVISITED:
				 matchTypes.add(AudienceAttributeMatchTypes.EQUALS);
				 matchTypes.add(AudienceAttributeMatchTypes.NOT_EQUALS);
				 matchTypes.add(AudienceAttributeMatchTypes.CONTAINS);
				 matchTypes.add(AudienceAttributeMatchTypes.DOESNOT_CONTAINS);
				 matchTypes.add(AudienceAttributeMatchTypes.STARTS_WITH);
				 matchTypes.add(AudienceAttributeMatchTypes.ENDS_WITH);
				 matchTypes.add(AudienceAttributeMatchTypes.REGEX);
				 break;
			 case ENTRYPAGE:
				 matchTypes.add(AudienceAttributeMatchTypes.EQUALS);
				 matchTypes.add(AudienceAttributeMatchTypes.NOT_EQUALS);
				 matchTypes.add(AudienceAttributeMatchTypes.CONTAINS);
				 matchTypes.add(AudienceAttributeMatchTypes.DOESNOT_CONTAINS);
				 matchTypes.add(AudienceAttributeMatchTypes.STARTS_WITH);
				 matchTypes.add(AudienceAttributeMatchTypes.ENDS_WITH);
				 matchTypes.add(AudienceAttributeMatchTypes.REGEX);
				 break;
			 case EXITPAGE:
				 matchTypes.add(AudienceAttributeMatchTypes.EQUALS);
				 matchTypes.add(AudienceAttributeMatchTypes.NOT_EQUALS);
				 matchTypes.add(AudienceAttributeMatchTypes.CONTAINS);
				 matchTypes.add(AudienceAttributeMatchTypes.DOESNOT_CONTAINS);
				 matchTypes.add(AudienceAttributeMatchTypes.STARTS_WITH);
				 matchTypes.add(AudienceAttributeMatchTypes.ENDS_WITH);
				 matchTypes.add(AudienceAttributeMatchTypes.REGEX);
				 break;
			}
			return matchTypes;
		}
		
		public List<QuickFilterBoundValues> getBoundValues() {
			List<QuickFilterBoundValues> matchTypes = new ArrayList<QuickFilterBoundValues>();
			switch(this) {
			 case TIMESPENT:
				 matchTypes.add(QuickFilterBoundValues.SECONDS);
				 matchTypes.add(QuickFilterBoundValues.MINUTES);
				 break;
			}
			return matchTypes;
		}
	
		public static  List<QuickFilterAttributes> getQuickAttributesForABSplit() {
			List<QuickFilterAttributes> qfAttrbibutes = new ArrayList<QuickFilterAttributes>();
			qfAttrbibutes.add(USERTYPE);
			qfAttrbibutes.add(TRAFFICSOURCE);
			qfAttrbibutes.add(COUNTRY);
			qfAttrbibutes.add(DEVICE);
			qfAttrbibutes.add(BROWSER);
			qfAttrbibutes.add(OS);
			qfAttrbibutes.add(DAYOFWEEK);
			qfAttrbibutes.add(HOUROFDAY);
			return qfAttrbibutes;
		}
		
		public static  List<QuickFilterAttributes> getQuickAttributesForFunnel() {
			List<QuickFilterAttributes> qfAttrbibutes = new ArrayList<QuickFilterAttributes>();
			qfAttrbibutes.add(USERTYPE);
			qfAttrbibutes.add(TRAFFICSOURCE);
			qfAttrbibutes.add(COUNTRY);
			qfAttrbibutes.add(DEVICE);
			qfAttrbibutes.add(BROWSER);
			qfAttrbibutes.add(OS);
			qfAttrbibutes.add(DAYOFWEEK);
			qfAttrbibutes.add(HOUROFDAY);
			return qfAttrbibutes;
		}
		
		public static  List<QuickFilterAttributes> getQuickAttributesForHeatmap() {
			List<QuickFilterAttributes> qfAttrbibutes = new ArrayList<QuickFilterAttributes>();
			qfAttrbibutes.add(USERTYPE);
			qfAttrbibutes.add(TRAFFICSOURCE);
			qfAttrbibutes.add(COUNTRY);
			qfAttrbibutes.add(BROWSER);
			qfAttrbibutes.add(OS);
			qfAttrbibutes.add(DAYOFWEEK);
			qfAttrbibutes.add(HOUROFDAY);
			return qfAttrbibutes;
		}
		
		public static  List<QuickFilterAttributes> getQuickAttributesForFormAnalysis() {
			List<QuickFilterAttributes> qfAttrbibutes = new ArrayList<QuickFilterAttributes>();
			qfAttrbibutes.add(USERTYPE);
			qfAttrbibutes.add(TRAFFICSOURCE);
			qfAttrbibutes.add(COUNTRY);
			qfAttrbibutes.add(DEVICE);
			qfAttrbibutes.add(BROWSER);
			qfAttrbibutes.add(OS);
			qfAttrbibutes.add(DAYOFWEEK);
			qfAttrbibutes.add(HOUROFDAY);
			return qfAttrbibutes;
		}
		
		public static  List<QuickFilterAttributes> getQuickAttributesForSessionRecording() {
			List<QuickFilterAttributes> qfAttrbibutes = new ArrayList<QuickFilterAttributes>();
			qfAttrbibutes.add(USERTYPE);
			qfAttrbibutes.add(TRAFFICSOURCE);
			qfAttrbibutes.add(COUNTRY);
			qfAttrbibutes.add(DEVICE);
			qfAttrbibutes.add(GOALS);
			qfAttrbibutes.add(PAGECOUNT);
			qfAttrbibutes.add(URLVISITED);
			qfAttrbibutes.add(ENTRYPAGE);
			qfAttrbibutes.add(EXITPAGE);
			qfAttrbibutes.add(TIMESPENT);
			qfAttrbibutes.add(BROWSER);
			qfAttrbibutes.add(OS);
			qfAttrbibutes.add(DAYOFWEEK);
			qfAttrbibutes.add(HOUROFDAY);
			return qfAttrbibutes;
		}
		
		
		
		public static List<QuickFilterAttributes> getQuickAttributes(Integer expTypeNo)
		{
			List<QuickFilterAttributes> qfAttrbibutes = new ArrayList<QuickFilterAttributes>();
			ExperimentType expType = ExperimentType.getExperimentTypeByNumber(expTypeNo);
			
				switch(expType)
				{
					case ABTEST:
					case SPLITURL:
						qfAttrbibutes = getQuickAttributesForABSplit();
						break;
					case HEATMAP:
					case ENABLED_HEATMAP:
						qfAttrbibutes = getQuickAttributesForHeatmap();
						break;
					case FUNNEL:
						qfAttrbibutes = getQuickAttributesForFunnel();
						break;
					case FORMANALYTICS:
						qfAttrbibutes = getQuickAttributesForFormAnalysis();
						break;
					case SESSION_RECORDING:
						qfAttrbibutes = getQuickAttributesForSessionRecording();
						break;
				}
			
			return qfAttrbibutes;
		}
		
		public String getDisplayName() {
			return ZABAction.getMessage(displayNameKey);
		}
		
		public String getSegmentName() {
			return segmentName;
		}

		public String getLinkName() {
			return linkName;
		}
	
		public int getUiType() {
			return uiType;
		}
	
	}
}
