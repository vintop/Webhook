//$Id$
package com.zoho.abtest.elastic;

import static com.zoho.abtest.funnel.report.FlexibleQueryConstants.END_TIME;
import static com.zoho.abtest.funnel.report.FlexibleQueryConstants.START_TIME;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.MatchQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.script.Script;
import org.elasticsearch.script.ScriptType;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.filter.Filter;
import org.elasticsearch.search.aggregations.bucket.filter.FilterAggregationBuilder;
import org.elasticsearch.search.aggregations.bucket.nested.Nested;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.aggregations.metrics.cardinality.CardinalityAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.cardinality.InternalCardinality;

import com.adventnet.iam.IAMUtil;
import com.zoho.abtest.elastic.ESQuickFilterConstants.QuickFilterAttributes;
import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.funnel.FunnelAnalysis;
import com.zoho.abtest.funnel.report.FlexibleQueryConstants;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.utility.ZABUtil;

public class ESFunnelQuickFilterStatistics {
	
	public static final Logger LOGGER = Logger.getLogger(ESFunnelQuickFilterStatistics.class.getName());

	
	//Used for FUNNEL
	public static List<ESQuickFilterStatistics> getQuickFilterSegmentFunnelVisitorCount(String indexName, String portal,String segmentName, Long expId, Long startTime, Long endTime,HashMap<String, String> qfNestedParentCond)
	{
		List<ESQuickFilterStatistics> visitorReportDetails;
		QueryBuilder query =  null;
		AggregationBuilder aggregation = null;
		int size = 0 ;
		try
		{
			FunnelAnalysis analysis =  FunnelAnalysis.getFunnelAnalysisWithSteps(expId);
			if(!analysis.getSuccess() && analysis.getSteps().size() > 0) {
				throw new ZABException("Exception occured while fetching experiment"); //NO I18N
			}
			Long firstStepId = analysis.getSteps().get(0).getStepId();
			
			query = generateQuickFilterFunnelSourceQueryJson(portal, expId, firstStepId, startTime, endTime,qfNestedParentCond);
			boolean isNestedAggr = isFunnelNestedSegment(segmentName);
			aggregation  =   generateQuickFilterFunnelVistorAggregateJson(segmentName,isNestedAggr);
			SearchResponse response = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.FUNNEL_RAW_TYPE, size, query, aggregation);
			visitorReportDetails = readQuickFilterFunnelVisitorResponseData(response,isNestedAggr, expId, firstStepId, startTime, endTime, segmentName);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage());
			visitorReportDetails = new ArrayList<ESQuickFilterStatistics>();
		}
		return visitorReportDetails;
	}
	
	public static boolean isFunnelNestedSegment(String segmentName) {
		return (segmentName.equals(ElasticSearchConstants.FUSERTYPE)||
				segmentName.equals(QuickFilterAttributes.USERTYPE.getLinkName())||
				segmentName.equals(QuickFilterAttributes.TRAFFICSOURCE.getLinkName())||
				segmentName.equals(QuickFilterAttributes.HOUROFDAY.getLinkName())||
				segmentName.equals(QuickFilterAttributes.DAYOFWEEK.getLinkName()));
	}
	
	//Used for MultiSegment FUNNEL
	public static List<ESQuickFilterWrapper> getQuickFilterMultiSegmentFunnelVisitorCount(String indexName, String portal, Long expId, Long startTime, 
			 Long endTime,
			 List<QuickFilterAttributes> quickFilterAttrs)
		{
			List<ESQuickFilterWrapper> visitorReportDetails;
			QueryBuilder query =  null;
			AggregationBuilder aggregation = null;
			int size = 0 ;
			try
			{
				FunnelAnalysis analysis =  FunnelAnalysis.getFunnelAnalysisWithSteps(expId);
				if(!analysis.getSuccess() && analysis.getSteps().size() > 0) {
					throw new ZABException("Exception occured while fetching experiment"); //NO I18N
				}
				Long firstStepId = analysis.getSteps().get(0).getStepId();
				
				query = generateQuickFilterFunnelSourceQueryJson(portal, expId, firstStepId, startTime, endTime, null);
				
				ArrayList<AggregationBuilder> builders = new ArrayList<AggregationBuilder>();
				for(QuickFilterAttributes attrs: quickFilterAttrs) {								
					String segmentName = attrs.getLinkName();
					boolean isNestedAggr = isFunnelNestedSegment(segmentName);
					aggregation  =   generateQuickFilterFunnelVistorAggregateJson(segmentName, segmentName,isNestedAggr);
					builders.add(aggregation);
				}
				SearchResponse response = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.FUNNEL_RAW_TYPE, size, query, builders);
				
				
				visitorReportDetails = readQuickFilterFunnelVisitorResponseData(response, expId, firstStepId, startTime, endTime, quickFilterAttrs);
			}
			catch(Exception ex)
			{
				LOGGER.log(Level.SEVERE, ex.getMessage());
				visitorReportDetails = new ArrayList<ESQuickFilterWrapper>();
			}
			return visitorReportDetails;
		}
	
	public static BoolQueryBuilder generateQuickFilterFunnelSourceQueryJson( String portal, Long expId, Long firstStepId, Long startTime, Long endTime,HashMap<String, String> qfNestedParentCond)
	{
		BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
		try
		{
			MatchQueryBuilder portalMatch = QueryBuilders.matchQuery(ElasticSearchConstants.PORTAL, portal);
			MatchQueryBuilder expMatch = QueryBuilders.matchQuery(ElasticSearchConstants.EXPERIMENTID, expId);
			List<QueryBuilder> conditionList = new ArrayList<QueryBuilder>();
			conditionList.add(portalMatch);
			conditionList.add(expMatch);
			if(startTime != null)
			{
				HashMap<String, Object> params = new HashMap<String, Object>();
				params.put(ElasticSearchConstants.STEPID, firstStepId);
				params.put(START_TIME, startTime);
				params.put(END_TIME, endTime);
				
				Script script = new Script(ScriptType.INLINE, ESQuickFilterConstants.PAINLESS_LANG, FlexibleQueryConstants.ELASTIC_STEP_VISIT_COUNT, params);
				BoolQueryBuilder build = QueryBuilders.boolQuery().must(QueryBuilders.scriptQuery(script));
				conditionList.add(build);
			}
			if(qfNestedParentCond != null)
			{
				for(Map.Entry<String, String> condEntry :qfNestedParentCond.entrySet())
				{
					MatchQueryBuilder condMatch = QueryBuilders.matchQuery(condEntry.getKey(), condEntry.getValue());
					conditionList.add(condMatch);
				}
			}
			boolQueryBuilder.must().addAll(conditionList);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
		return boolQueryBuilder;
	}
	
	public static AggregationBuilder generateQuickFilterFunnelVistorAggregateJson(String segmentName, String customAggregationName,boolean isNestedDocAggr)
	{
		AggregationBuilder finalAggr = null;
		try
		{
			//CRUFT
			if(segmentName.equals(QuickFilterAttributes.USERTYPE.getLinkName())) {
				segmentName = ElasticSearchConstants.FUSERTYPE;
			}
			CardinalityAggregationBuilder cardinalityAggregation = ElasticSearchStatistics.getFunnelSessionCardinalityAggr();
			
			//TODO have to check for traffic source aggr for funnel
			// For nested aggregation we know that it has errors in it since the traffic source aggregattion returns the
			// aggreaggation of all traffic source nested fields and not the exact filtered inner hits since ES returns the whole document with all nested documents 
			if(isNestedDocAggr)
			{
				/*
				 *  "aggs" : {
				        "segments" : {
				            "nested" : {
				                "path" : "steps"
				            },
				            "aggs" : {
				                "sourceaggrs" : {
						            "terms" : {
						                "field" : "steps.trafficsource"
						            },
						            "aggs": {
						            "session_count_parent": {
						              "reverse_nested": {},
							            "aggs" : {
									        "session_count" : {
									            "cardinality" : {
									                "field" : "sessionid"
									            }
									        }
									    }
									    }
									    }
						        }
				            }
				        }
				    }
				 */
				if(segmentName.equals(QuickFilterAttributes.DAYOFWEEK.getLinkName()) || segmentName.equals(QuickFilterAttributes.HOUROFDAY.getLinkName()))
				{
					HashMap<String, Object> params = new HashMap<String, Object>();
					String timezone =  ElasticSearchUtil.getCurrentUserTimezone();
					
					params.put(ESQuickFilterConstants.TIMEZONE, timezone);
					params.put(ESQuickFilterConstants.FIELD, "steps."+ElasticSearchConstants.TIME);
					String scriptCode = null;
					if(segmentName.equals(QuickFilterAttributes.DAYOFWEEK.getLinkName()))
					{
						scriptCode = ESQuickFilterConstants.DAY_OF_WEEK_SCRIPT;
					}
					else if(segmentName.equals(QuickFilterAttributes.HOUROFDAY.getLinkName()))
					{
						scriptCode = ESQuickFilterConstants.HOUR_OF_DAY_SCRIPT;
					}
					Script script = new Script(ScriptType.INLINE, ESQuickFilterConstants.PAINLESS_LANG, scriptCode, params);
					
					finalAggr = AggregationBuilders.nested(customAggregationName, "steps").subAggregation( //No I18N
							AggregationBuilders.terms("nestedStepsAggr").script(script).size(ElasticSearchConstants.SEGMENT_MAX_COUNT).subAggregation( //No I18N
									AggregationBuilders.reverseNested("session_count_parent").subAggregation(cardinalityAggregation))); //No I18N
				}
				else
				{
					finalAggr = AggregationBuilders.nested(customAggregationName, "steps").subAggregation( //No I18N
							AggregationBuilders.terms("nestedStepsAggr").field("steps."+segmentName).size(ElasticSearchConstants.SEGMENT_MAX_COUNT).subAggregation( //No I18N
									AggregationBuilders.reverseNested("session_count_parent").subAggregation(cardinalityAggregation))); //No I18N
				
				}
			}
			else
			{
				finalAggr = AggregationBuilders.terms(customAggregationName).
						field(segmentName).
						size(ElasticSearchConstants.SEGMENT_MAX_COUNT).
							subAggregation(cardinalityAggregation);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
		return finalAggr;
	}
	
	public static AggregationBuilder generateQuickFilterFunnelVistorAggregateJson(String segmentName, boolean isNestedDocAggr)
	{
		return generateQuickFilterFunnelVistorAggregateJson(segmentName, "segment", isNestedDocAggr); //NO I18N
	}
	
	public static BoolQueryBuilder formQueryForNestedDimsCount(Long startTime, Long endTime, Long stepId, Long expId, String dimension, String value) {
		HashMap<String, Object> params2 = new HashMap<String, Object>();
		params2.put(START_TIME, startTime);
		params2.put(END_TIME, endTime);
		params2.put("step_id", stepId);
		params2.put(FlexibleQueryConstants.DIMENSION, dimension);
		params2.put(FlexibleQueryConstants.DIMENSION_VALUE, value);
		params2.put(ESQuickFilterConstants.TIMEZONE, ElasticSearchUtil.getCurrentUserTimezone());
		Script script2 = new Script(
				ScriptType.INLINE,
				FlexibleQueryConstants.PAINLESS,
				FlexibleQueryConstants.ELASTIC_QUICKF_NESTED_SCRIPT,
				params2);
		
		BoolQueryBuilder builder =  QueryBuilders
										.boolQuery()
											.filter(QueryBuilders
												.boolQuery()
													.must(QueryBuilders
															.termQuery(ElasticSearchConstants.EXPERIMENTID, expId))
													.must(QueryBuilders
															.scriptQuery(script2)));
		return builder;

	}
	
	public static List<ESQuickFilterWrapper> readQuickFilterFunnelVisitorResponseData(
			SearchResponse response, Long expId,
			Long stepId, Long startTime, Long endTime,
			List<QuickFilterAttributes> attribs)
	{
		List<ESQuickFilterWrapper> visitorReportDetails = new ArrayList<ESQuickFilterWrapper>();
		try
		{
			Aggregations aggrResponse = response.getAggregations();
			
			for(QuickFilterAttributes attrib:attribs) {
				String segmentName = attrib.getLinkName();
				
				ESQuickFilterWrapper wrapper = new ESQuickFilterWrapper();
				wrapper.setAttribute(attrib);
				if(isFunnelNestedSegment(segmentName))
				{
					Nested nested = aggrResponse.get(segmentName);
					Aggregations nestedStepsAggr = nested.getAggregations();
					Terms terms = nestedStepsAggr.get("nestedStepsAggr");
					List<? extends Bucket> buckets = terms.getBuckets();
					
					ArrayList<String> possibleValues = new ArrayList<String>();
					for(Bucket bucket:buckets)
					{
						String segmentValue = (String)bucket.getKey();
						possibleValues.add(segmentValue);
					}
					
					ArrayList<AggregationBuilder> filterAggs = new ArrayList<AggregationBuilder>();
					
					if(possibleValues.size() > 0) {
						
						String portalName =null;
						try{
							portalName = IAMUtil.getCurrentServiceOrg().getDomains().get(0).getDomain();
						}catch(Exception e){
							portalName = ZABUtil.getPortaldomain();
							if(portalName == null){
								throw new Exception();
							}
						}
						
						String indexName = ElasticSearchUtil.getIndexByPortal(portalName);
						
						//CRUFT
						if(segmentName.equals(QuickFilterAttributes.USERTYPE.getLinkName())) {
							segmentName = ElasticSearchConstants.FUSERTYPE;
						}
						
						for(String value: possibleValues) {						
							FilterAggregationBuilder builder = AggregationBuilders
									.filter(value,
											formQueryForNestedDimsCount(startTime,
													endTime, stepId, expId,
													segmentName, value));
							filterAggs.add(builder);
						}
						
						SearchResponse sr = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.FUNNEL_RAW_TYPE, 0, QueryBuilders.matchAllQuery(), filterAggs);
						
						for(String value: possibleValues) {
							Filter filter = sr.getAggregations().get(value);
							Long docCount = filter.getDocCount();
							if(docCount > 0) {
								ESQuickFilterStatistics stat = new ESQuickFilterStatistics();
								stat.setSegmentValue(value);
								stat.setVisitorCount(docCount);
								stat.setSuccess(true);
								wrapper.getVisitorData().add(stat);							
							}
						}
						
					}
				}
				else
				{
					Terms terms = aggrResponse.get(segmentName);
					List<? extends Bucket> buckets = terms.getBuckets();
					for(Bucket bucket:buckets)
					{
						String segmentValue = (String)bucket.getKey();
						Long uniqueCount = 0l;
						Aggregations buckaggrResponse = bucket.getAggregations();
						InternalCardinality cardinality = buckaggrResponse.get("distinct_sessions");
						uniqueCount = cardinality.getValue();
						ESQuickFilterStatistics stat = new ESQuickFilterStatistics();
						stat.setSegmentValue(segmentValue);
						stat.setVisitorCount(uniqueCount);
						stat.setSuccess(true);
						wrapper.getVisitorData().add(stat);
					}
				}
				wrapper.sortAndAddFillers();
				visitorReportDetails.add(wrapper);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			visitorReportDetails = new ArrayList<ESQuickFilterWrapper>();
		}
		return visitorReportDetails;
	}
	
	
	public static List<ESQuickFilterStatistics> readQuickFilterFunnelVisitorResponseData(
			SearchResponse response, boolean isNestedAggr, Long expId,
			Long stepId, Long startTime, Long endTime,
			String segmentName)
	{
		List<ESQuickFilterStatistics> visitorReportDetails = new ArrayList<ESQuickFilterStatistics>();
		try
		{
			Aggregations aggrResponse = response.getAggregations();
			
			if(isNestedAggr)
			{
				Nested nested = aggrResponse.get("segment");
				Aggregations nestedStepsAggr = nested.getAggregations();
				Terms terms = nestedStepsAggr.get("nestedStepsAggr");
				List<? extends Bucket> buckets = terms.getBuckets();
				
				ArrayList<String> possibleValues = new ArrayList<String>();
				for(Bucket bucket:buckets)
				{
					String segmentValue = (String)bucket.getKey();
					possibleValues.add(segmentValue);
				}
				
				ArrayList<AggregationBuilder> filterAggs = new ArrayList<AggregationBuilder>();
				
				if(possibleValues.size() > 0) {
					
					String portalName =null;
					try{
						portalName = IAMUtil.getCurrentServiceOrg().getDomains().get(0).getDomain();
					}catch(Exception e){
						portalName = ZABUtil.getPortaldomain();
						if(portalName == null){
							throw new Exception();
						}
					}
					
					String indexName = ElasticSearchUtil.getIndexByPortal(portalName);
					
					
					for(String value: possibleValues) {						
						FilterAggregationBuilder builder = AggregationBuilders
								.filter(value,
										formQueryForNestedDimsCount(startTime,
												endTime, stepId, expId,
												segmentName, value));
						filterAggs.add(builder);
					}
					
					SearchResponse sr = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.FUNNEL_RAW_TYPE, 0, QueryBuilders.matchAllQuery(), filterAggs);
					
					for(String value: possibleValues) {
						Filter filter = sr.getAggregations().get(value);
						Long docCount = filter.getDocCount();
						if(docCount > 0) {
							ESQuickFilterStatistics stat = new ESQuickFilterStatistics();
							stat.setSegmentValue(value);
							stat.setVisitorCount(docCount);
							stat.setSuccess(true);
							visitorReportDetails.add(stat);							
						}
					}
					
				}
			}
			else
			{
				Terms terms = aggrResponse.get("segment");
				List<? extends Bucket> buckets = terms.getBuckets();
				for(Bucket bucket:buckets)
				{
					String segmentValue = (String)bucket.getKey();
					Long uniqueCount = 0l;
					Aggregations buckaggrResponse = bucket.getAggregations();
					InternalCardinality cardinality = buckaggrResponse.get("distinct_sessions");
					uniqueCount = cardinality.getValue();
					ESQuickFilterStatistics stat = new ESQuickFilterStatistics();
					stat.setSegmentValue(segmentValue);
					stat.setVisitorCount(uniqueCount);
					stat.setSuccess(true);
					visitorReportDetails.add(stat);
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			visitorReportDetails = new ArrayList<ESQuickFilterStatistics>();
		}
		return visitorReportDetails;
	}
}
