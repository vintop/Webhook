//$Id$
package com.zoho.abtest.elastic;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.zoho.abtest.ES_INDEX_META;
import com.zoho.abtest.ES_INDEX_PORTAL_MAPPING;
import com.zoho.abtest.ES_FAILED_ENTRY;
import com.zoho.abtest.SPACE_DELETION_DETAILS;
import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.utility.ApplicationProperty;
import com.zoho.conf.Configuration;

public class ElasticSearchIndexConstants 
{
	public static final String ES_INDEX_META_ID = "es_index_meta_id";			// No I18N
	public static final String INDEX_NAME = "index_name";			// No I18N
	public static final String ACTIVE_PORTAL_COUNT = "active_portal_count";			// No I18N
	public static final String INDEX_STATUS = "index_status";			// No I18N
	public static final String MAPPING_ID = "mapping_id";			// No I18N
	public static final String PORTAL_NAME = "portal_name";			// No I18N
	public static final String ZSOID = "zsoid";			// No I18N
	public static final String ENTRY_ID = "entry_id";			// No I18N
	public static final String TYPE = "type";			// No I18N
	public static final String JSON_STRING = "json_string";			// No I18N
	public static final String DOC_ID = "doc_id";			// No I18N
	public static final String OPERATION_TYPE = "operation_type";			// No I18N
	public static final String EXCEPTION_MESSAGE = "exception_message";			// No I18N
	public static final String SPACE_DELETION_DETAILS_ID = "space_deletion_details_id";			// No I18N
	public static final String DELETED_TIME = "deleted_time";			// No I18N
	public static final String IS_DATA_REMOVED = "is_data_removed";			// No I18N
	
	
	public static final int SHARD_COUNT = ApplicationProperty.getInteger("com.abtest.elasticsearch.shardcount"); // No I18N
	//TODO ES this needs to be 2 for production
	public static final int REPLICA_COUNT = ApplicationProperty.getInteger("com.abtest.elasticsearch.replicacount"); // No I18N
	
	public static final String ES_MAIL_FROM_ADDRESS = ApplicationProperty.getString("com.abtest.transmail.mail_from"); // No I18N
	public static final String ES_MAIL_TO_ADDRESS = ApplicationProperty.getString("com.abtest.transmail.es.mail_to"); // No I18N
	
	public static final String ES_CLUSTER_DETAILS_API_MODULE = "esclusterdetails";			// No I18N
	public static final String ES_POPULATE_INDICES_API_MODULE = "espopulateindices";			// No I18N
	public static final String ES_UPDATE_REVENUE_MAPPING = "esupdaterevenuemapping";			// No I18N
	
	public enum ESOpertaionType
	{
		CREATE(1),
		UPDATE(2),
		CREATE_BACKUP(6),
		UPDATE_BACKUP(7);
		
		private Integer operationType;

		public Integer getOperationType() {
			return operationType;
		}

		public void setOperationType(Integer operationType) {
			this.operationType = operationType;
		}
		
		private ESOpertaionType(Integer operationType)
		{
			this.operationType = operationType;
		}
	}
	
	public static final List<Constants> ES_INDEX_META_CONSTANTS;
	
	static{
		List<Constants> esIndexMetaConstants = new ArrayList<Constants>();
		esIndexMetaConstants.add(new Constants(ES_INDEX_META_ID,ES_INDEX_META.ES_INDEX_META_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		esIndexMetaConstants.add(new Constants(INDEX_NAME,ES_INDEX_META.INDEX_NAME,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
		esIndexMetaConstants.add(new Constants(ACTIVE_PORTAL_COUNT,ES_INDEX_META.ACTIVE_PORTAL_COUNT,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		esIndexMetaConstants.add(new Constants(INDEX_STATUS,ES_INDEX_META.INDEX_STATUS,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		ES_INDEX_META_CONSTANTS = Collections.unmodifiableList(esIndexMetaConstants);
	}
	
	public static final List<Constants> ES_INDEX_PORTAL_MAPPING_CONSTANTS;
	
	static{
		List<Constants> esIndexPortalMappingConstants = new ArrayList<Constants>();
		esIndexPortalMappingConstants.add(new Constants(MAPPING_ID,ES_INDEX_PORTAL_MAPPING.MAPPING_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		esIndexPortalMappingConstants.add(new Constants(ES_INDEX_META_ID,ES_INDEX_PORTAL_MAPPING.ES_INDEX_META_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		esIndexPortalMappingConstants.add(new Constants(PORTAL_NAME,ES_INDEX_PORTAL_MAPPING.PORTAL_NAME,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
		esIndexPortalMappingConstants.add(new Constants(ZSOID,ES_INDEX_PORTAL_MAPPING.ZSOID,ZABConstants.LONG,Boolean.TRUE,Boolean.TRUE));
		ES_INDEX_PORTAL_MAPPING_CONSTANTS = Collections.unmodifiableList(esIndexPortalMappingConstants);
	}
	
	public static final List<Constants> ES_FAILED_ENTRY_CONSTANTS;
	
	static{
		List<Constants> esFailedEntryConstants = new ArrayList<Constants>();
		esFailedEntryConstants.add(new Constants(ENTRY_ID,ES_FAILED_ENTRY.ENTRY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		esFailedEntryConstants.add(new Constants(INDEX_NAME,ES_FAILED_ENTRY.INDEX_NAME,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
		esFailedEntryConstants.add(new Constants(TYPE,ES_FAILED_ENTRY.TYPE,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
		esFailedEntryConstants.add(new Constants(JSON_STRING,ES_FAILED_ENTRY.JSON_STRING,ZABConstants.STRING,Boolean.TRUE,Boolean.TRUE));
		esFailedEntryConstants.add(new Constants(DOC_ID,ES_FAILED_ENTRY.DOC_ID,ZABConstants.STRING,Boolean.TRUE,Boolean.TRUE));
		esFailedEntryConstants.add(new Constants(OPERATION_TYPE,ES_FAILED_ENTRY.OPERATION_TYPE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.TRUE));
		esFailedEntryConstants.add(new Constants(EXCEPTION_MESSAGE,ES_FAILED_ENTRY.EXCEPTION_MESSAGE,ZABConstants.STRING,Boolean.TRUE,Boolean.TRUE));
		ES_FAILED_ENTRY_CONSTANTS = Collections.unmodifiableList(esFailedEntryConstants);
	}
	
	public static final List<Constants> SPACE_DELETION_DETAILS_CONSTANTS;
	
	static{
		List<Constants> spaceDeletionDetailsConstants = new ArrayList<Constants>();
		spaceDeletionDetailsConstants.add(new Constants(SPACE_DELETION_DETAILS_ID,SPACE_DELETION_DETAILS.SPACE_DELETION_DETAILS_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		spaceDeletionDetailsConstants.add(new Constants(ZSOID,SPACE_DELETION_DETAILS.ZSOID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		spaceDeletionDetailsConstants.add(new Constants(PORTAL_NAME,SPACE_DELETION_DETAILS.PORTAL_NAME,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
		spaceDeletionDetailsConstants.add(new Constants(DELETED_TIME,SPACE_DELETION_DETAILS.DELETED_TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		spaceDeletionDetailsConstants.add(new Constants(IS_DATA_REMOVED,SPACE_DELETION_DETAILS.IS_DATA_REMOVED,ZABConstants.BOOLEAN,Boolean.TRUE,Boolean.TRUE));
		SPACE_DELETION_DETAILS_CONSTANTS = Collections.unmodifiableList(spaceDeletionDetailsConstants);
	}
}
