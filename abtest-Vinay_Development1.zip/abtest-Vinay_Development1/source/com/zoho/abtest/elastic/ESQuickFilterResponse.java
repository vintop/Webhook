//$Id$
package com.zoho.abtest.elastic;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;
import com.zoho.abtest.report.CumulativeReportConstants;
import com.zoho.abtest.report.ElasticSearchConstants;

public class ESQuickFilterResponse 
{
	private static final Logger LOGGER = Logger.getLogger(ESQuickFilterResponse.class.getName());
	
	public static String jsonResponse(HttpServletRequest request,List<ESQuickFilterStatistics> visitorReports) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(visitorReports);			
			JSONObject json = ZABResponse.updateMetaInfo(request, CumulativeReportConstants.API_MODULE, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		return returnBuffer.toString();
	}
	public static JSONArray getJSONArray(List<ESQuickFilterStatistics> visitorReports) throws JSONException {
		JSONArray array = new JSONArray();
		int size =visitorReports.size();
		for (int i=0;i<size;i++) {
			ESQuickFilterStatistics stat = visitorReports.get(i);
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(ElasticSearchConstants.SEGMENT_VALUE, stat.getSegmentValue());
			jsonObj.put(ElasticSearchConstants.VISITOR_COUNT, stat.getVisitorCount());
			
			String displayName = null;
			
			if(stat.getDiplayName() == null) {				
				displayName = (String) stat.getSegmentValue();
				if(displayName != null)
				{
					displayName = StringUtils.capitalize(displayName.toLowerCase());
				}
			} else {
				displayName = stat.getDiplayName();
			}
			
			
			if(displayName != null ) {				
				if(displayName.equals("Search")){
					displayName ="Organic Search"; //No I18N
				}else if(displayName.equals("Campaign")){
					displayName ="Paid Campaigns"; //No I18N
				}else if(displayName.equals("Ie") ||displayName.equals("Internet explorer") ){
					displayName ="IE";//No I18N
				}else if(displayName.equals("Chromium os")){
					displayName ="Chromium OS";//No I18N
				}else if(displayName.equals("Iphone")){
					displayName ="iPhone";//No I18N
				}else if(displayName.equals("Mac os") || displayName.equals("Macos") ){
					displayName ="Mac OS";//No I18N
				}
				
				jsonObj.put(ElasticSearchConstants.DISPLAY_NAME, displayName);
			}
			
			jsonObj.put(ZABConstants.RESPONSE_STRING, stat.getResponseString());
			jsonObj.put(ZABConstants.SUCCESS, stat.getSuccess());
			array.put(jsonObj);
		}
		return array;
	}
}
