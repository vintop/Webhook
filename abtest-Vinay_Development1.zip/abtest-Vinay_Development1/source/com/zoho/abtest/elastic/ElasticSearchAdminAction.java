//$Id$
package com.zoho.abtest.elastic;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;

import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.elastic.adminconsole.ESAdminConsole;
import com.zoho.abtest.job.ZCampaignScriptVerifyJob;
import com.zoho.abtest.utility.ZABSchedulerUtil;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.abtest.zcampaigns.ZCampaignBridge;

public class ElasticSearchAdminAction extends ZABAction implements ServletResponseAware, ServletRequestAware 
{
	private static final Logger LOGGER = Logger.getLogger(ElasticSearchAdminAction.class.getName());

	private static final long serialVersionUID = 1L;

	private HttpServletRequest request;

	private HttpServletResponse response;

	private Integer maxCompilationSize;

	public Integer getMaxCompilationSize() {
		return maxCompilationSize;
	}

	public void setMaxCompilationSize(Integer maxCompilationSize) {
		this.maxCompilationSize = maxCompilationSize;
	}

	@Override
	public void setServletRequest(HttpServletRequest request) {
		this.request = request;
	}

	@Override
	public void setServletResponse(HttpServletResponse response) {
		this.response = response;
	}

	public void processAdminOperation()
	{
		try
		{
			int type = 0;
			String typeStr = request.getParameter("type");
			if(StringUtils.isNotEmpty(typeStr))
			{
				type = Integer.parseInt(typeStr);
			}
			ElasticSearchUtil.pushFailedEntryIntoES(type);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}

	public void initiateClusterStatusReport()
	{
		try
		{
			ElasticSearchUtil.reportClusterIndicesHealth();
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}

	public void getESClusterCompleteInfo() throws Exception
	{
		try
		{
			ZABUtil.setCurrentRequest(request);
			ZABUtil.setDBCallCountMap(null);
			Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
			ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
			ESAdminConsole esAdminConsole = null;
			esAdminConsole = ElasticSearchUtil.getESHealth();
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getESAdminConsoleResponse(request, esAdminConsole));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ElasticSearchIndexConstants.ES_CLUSTER_DETAILS_API_MODULE));
		}
	}

	public void populateESDefaultIndexes() throws Exception
	{
		try
		{
			LOGGER.log(Level.INFO,"Entered into populateESDefaultIndexes");
			ZABUtil.setCurrentRequest(request);
			ZABUtil.setDBCallCountMap(null);
			Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
			ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);

			String existingDBSpace = ZABUtil.getDBSpace();
			ZABUtil.setDBSpace("sharedspace");	//No I18N
			boolean isIndexMetaExists = ESIndexMeta.isESIndexMetaExists();
			if(!isIndexMetaExists)
			{
				ElasticSearchUtil.populateDefaultIndexes();
			}
			ZABUtil.setDBSpace(existingDBSpace);
			LOGGER.log(Level.INFO,"Completed populateESDefaultIndexes: IndexAlreadyExisted: "+isIndexMetaExists);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getESDefaultIndicesResponse(request));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ElasticSearchIndexConstants.ES_POPULATE_INDICES_API_MODULE));
		}
	}

	public void includeZsoidInIndexPortalMapping() throws Exception
	{
		try
		{
			LOGGER.log(Level.INFO,"Entered into includeZsoidInIndexPortalMapping");
			ZABUtil.setCurrentRequest(request);
			ZABUtil.setDBCallCountMap(null);
			Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
			ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);

			ZABUtil.setDBSpace("sharedspace");	//No I18N
			ESIndexPortalMapping.includeZsoidDetails();
			LOGGER.log(Level.INFO,"Completed includeZsoidInIndexPortalMapping");
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getESDefaultIndicesResponse(request));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ElasticSearchIndexConstants.ES_POPULATE_INDICES_API_MODULE));
		}
	}
	
	public void addCityToAllType() throws Exception
	{
		try
		{
			ZABUtil.setCurrentRequest(request);
			ZABUtil.setDBCallCountMap(null);
			Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
			ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
			ElasticSearchAdminHelper.addCityToAllType();
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getESAdminConsoleResponse(request, null));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ElasticSearchIndexConstants.ES_UPDATE_REVENUE_MAPPING));
		}
		
	}
	
	public void addUuidToSpecificTypes() throws Exception
	{
		try
		{
			ZABUtil.setCurrentRequest(request);
			ZABUtil.setDBCallCountMap(null);
			Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
			ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
			ElasticSearchAdminHelper.addUuidToSpecificTypes();
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getESAdminConsoleResponse(request, null));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred while updating uuid to mapping",ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ElasticSearchIndexConstants.ES_UPDATE_REVENUE_MAPPING));
		}
		
	}
	
	public void addZsoidToAllType() throws Exception
	{
		try
		{
			ZABUtil.setCurrentRequest(request);
			ZABUtil.setDBCallCountMap(null);
			Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
			ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
			ElasticSearchAdminHelper.addZsoidToAllType();
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getESAdminConsoleResponse(request, null));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ElasticSearchIndexConstants.ES_UPDATE_REVENUE_MAPPING));
		}
		
	}
	
	public void addDAToHeatmapScrollmapType() throws Exception
	{
		try
		{
			ZABUtil.setCurrentRequest(request);
			ZABUtil.setDBCallCountMap(null);
			Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
			ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
			ElasticSearchAdminHelper.addDAToESTypes();
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getESAdminConsoleResponse(request, null));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ElasticSearchIndexConstants.ES_UPDATE_REVENUE_MAPPING));
		}

	}
	
	public void addUserTypeMappingToHeatmapScrollmapType() throws Exception
	{
		try
		{
			ZABUtil.setCurrentRequest(request);
			ZABUtil.setDBCallCountMap(null);
			Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
			ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
			ElasticSearchAdminHelper.addUserTypeToHeatmapScrollmapType();
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getESAdminConsoleResponse(request, null));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ElasticSearchIndexConstants.ES_UPDATE_REVENUE_MAPPING));
		}

	}

	public void addHeatmapEnabledMappingToVisitorRawDataType() throws Exception
	{
		try
		{
			ZABUtil.setCurrentRequest(request);
			ZABUtil.setDBCallCountMap(null);
			Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
			ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
			ElasticSearchAdminHelper.addHeatmapEnabledMappingToVisitorRawDataType();
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getESAdminConsoleResponse(request, null));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ElasticSearchIndexConstants.ES_UPDATE_REVENUE_MAPPING));
		}

	}

	public void addTimeSpentMappingToScrollmapRawDataType() throws Exception
	{
		try
		{
			ZABUtil.setCurrentRequest(request);
			ZABUtil.setDBCallCountMap(null);
			Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
			ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
			ElasticSearchAdminHelper.addTimeSpentMappingToScrollmapRawDataType();
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getESAdminConsoleResponse(request, null));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ElasticSearchIndexConstants.ES_UPDATE_REVENUE_MAPPING));
		}

	}
	
	public void updateRevenueMappingInGoalType() throws Exception
	{
		try
		{
			ZABUtil.setCurrentRequest(request);
			ZABUtil.setDBCallCountMap(null);
			Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
			ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
			ElasticSearchAdminHelper.addRevenueMappingToGoalType();
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getESAdminConsoleResponse(request, null));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ElasticSearchIndexConstants.ES_UPDATE_REVENUE_MAPPING));
		}
	}
	public void updateEventMapping() throws Exception
	{
		try
		{
			ZABUtil.setCurrentRequest(request);
			ZABUtil.setDBCallCountMap(null);
			Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
			ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
			ElasticSearchAdminHelper.addEventMapping();
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getESAdminConsoleResponse(request, null));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ElasticSearchIndexConstants.ES_UPDATE_REVENUE_MAPPING));
		}
	}

	public void updateTimeSpentMappingInVisitorType() throws Exception

	{
		try
		{
			ZABUtil.setCurrentRequest(request);
			ZABUtil.setDBCallCountMap(null);
			Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
			ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
			ElasticSearchAdminHelper.addTimeSpentMapping();
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getESAdminConsoleResponse(request, null));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ElasticSearchIndexConstants.ES_UPDATE_REVENUE_MAPPING));
		}
	}

	public void updateScrollListMappingInScrollMapType() throws Exception
	{
		try
		{
			ZABUtil.setCurrentRequest(request);
			ZABUtil.setDBCallCountMap(null);
			Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
			ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
			ElasticSearchAdminHelper.updateScrollListTypeInScrollMapType();
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getESAdminConsoleResponse(request, null));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ElasticSearchIndexConstants.ES_UPDATE_REVENUE_MAPPING));
		}
	}


	public void addHeatMapScrollMapTypes() throws Exception
	{
		try
		{
			ZABUtil.setCurrentRequest(request);
			ZABUtil.setDBCallCountMap(null);
			Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
			ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
			ElasticSearchAdminHelper.addHeatMapAndScrollMapMappings();
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getESAdminConsoleResponse(request, null));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ElasticSearchIndexConstants.ES_UPDATE_REVENUE_MAPPING));
		}
	}

	public void populateESHealthCheckJobInitiation() throws Exception
	{
		try
		{
			LOGGER.log(Level.INFO,"Entered into populateESHealthCheckJobInitiation");
			ZABUtil.setCurrentRequest(request);
			ZABUtil.setDBCallCountMap(null);
			Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
			ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);

			String existingDBSpace = ZABUtil.getDBSpace();
			ZABUtil.setDBSpace("sharedspace");	//No I18N

			ZABSchedulerUtil.submitESPeriodicRepititiveJob();

			ZABUtil.setDBSpace(existingDBSpace);
			LOGGER.log(Level.INFO,"Completed populateESHealthCheckJobInitiation ");
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred in populateESHealthCheckJobInitiation",ex);
		}
	}

	public void updateFunnelTypeMapping()  throws Exception
	{
		try
		{
			ZABUtil.setCurrentRequest(request);
			ZABUtil.setDBCallCountMap(null);
			Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
			ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
			ElasticSearchAdminHelper.addFunnelMapMappings();
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getESAdminConsoleResponse(request, null));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ElasticSearchIndexConstants.ES_UPDATE_REVENUE_MAPPING));
		}
	}
	
	public void updateFunnelTypeVisitorTypeMapping()  throws Exception
	{
		try
		{
			ZABUtil.setCurrentRequest(request);
			ZABUtil.setDBCallCountMap(null);
			Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
			ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
			ElasticSearchAdminHelper.addFunnelMapVisitorTypeMappings();
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getESAdminConsoleResponse(request, null));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ElasticSearchIndexConstants.ES_UPDATE_REVENUE_MAPPING));
		}
	}
	
	public void forceUpdateScriptVerificationToZCampaigns() throws IOException {
		//Temporary API
		try
		{
			ZABUtil.setCurrentRequest(request);
			ZABUtil.setDBCallCountMap(null);
			Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
			ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
			ZCampaignScriptVerifyJob.sendScriptVerificationToZCampaigns();
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getESAdminConsoleResponse(request, null));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ElasticSearchIndexConstants.ES_UPDATE_REVENUE_MAPPING));
		}
	}
	
	public void addFormAndFieldTypes()  throws Exception
	{
		try
		{
			ZABUtil.setCurrentRequest(request);
			ZABUtil.setDBCallCountMap(null);
			Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
			ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
			ElasticSearchAdminHelper.addFormAndFieldMappings();
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getESAdminConsoleResponse(request, null));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ElasticSearchIndexConstants.ES_UPDATE_REVENUE_MAPPING));
		}
	}
	
	public void addAdwordDataMapping()  throws Exception
	{
		try
		{
			ZABUtil.setCurrentRequest(request);
			ZABUtil.setDBCallCountMap(null);
			Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
			ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
			ElasticSearchAdminHelper.addAdwordDataMappings();
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getESAdminConsoleResponse(request, null));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ElasticSearchIndexConstants.ES_UPDATE_REVENUE_MAPPING));
		}
	}

	public void setMaxScriptCompilation() throws IOException {
		try
		{
			ZABUtil.setCurrentRequest(request);
			ZABUtil.setDBCallCountMap(null);
			Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
			ElasticSearchAdminHelper.updateScriptMaxCompilationPerMin(getMaxCompilationSize());
			ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);

			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getESAdminConsoleResponse(request, null));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ElasticSearchIndexConstants.ES_UPDATE_REVENUE_MAPPING));
		}
	}
	
	public void zcampaignZoneSync() throws IOException {
		try
		{
			ZABUtil.setCurrentRequest(request);
			ZABUtil.setDBCallCountMap(null);
			Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
			ZCampaignBridge.syncZonetoCampaigns();
			ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getESAdminConsoleResponse(request, null));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ElasticSearchIndexConstants.ES_UPDATE_REVENUE_MAPPING));
		}
	}
	
	public void addSessionDataMapping() throws IOException {
		try
		{
			ZABUtil.setCurrentRequest(request);
			ZABUtil.setDBCallCountMap(null);
			Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
			ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
			ElasticSearchAdminHelper.addSessionTypeMappings();
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getESAdminConsoleResponse(request, null));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ElasticSearchIndexConstants.ES_UPDATE_REVENUE_MAPPING));
		}
	}
	
//	public void addIdentifyType()  throws Exception
//	{
//		try
//		{
//			ZABUtil.setCurrentRequest(request);
//			ZABUtil.setDBCallCountMap(null);
//			Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
//			ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
//			ElasticSearchAdminHelper.addIdentifyMapping();
//			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getESAdminConsoleResponse(request, null));
//		}
//		catch(Exception ex)
//		{
//			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
//			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ElasticSearchIndexConstants.ES_UPDATE_REVENUE_MAPPING));
//		}
//	}

}
