//$Id$
package com.zoho.abtest.elastic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.MatchQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.index.query.TermsQueryBuilder;
import org.elasticsearch.script.Script;
import org.elasticsearch.script.ScriptType;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.cardinality.CardinalityAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.cardinality.InternalCardinality;
import org.elasticsearch.search.aggregations.metrics.tophits.TopHitsAggregationBuilder;
import org.elasticsearch.search.sort.SortOrder;

import com.zoho.abtest.elastic.ESQuickFilterConstants.QuickFilterAttributes;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentType;
import com.zoho.abtest.forms.ElasticFormReport;
import com.zoho.abtest.forms.FormReportConstants;
import com.zoho.abtest.goal.ExperimentGoal;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.sessionrecording.SessionElasticBand;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.abtest.variation.Variation;

public class ESCommonQuickFilterStatistics {
	
	public static final Logger LOGGER = Logger.getLogger(ESCommonQuickFilterStatistics.class.getName());
	
	public static List<ESQuickFilterStatistics> getQuickFilterSegmentVisitorCount(
			String indexName, String portal, String segmentName, Long expId,
			Integer expType,
			Long startTime, Long endTime,
			HashMap<String, String> qfNestedParentCond,
			HashMap<String, String> additionalFilters)
	{
		List<ESQuickFilterStatistics> visitorReportDetails;
		BoolQueryBuilder query =  null;
		AggregationBuilder aggregation = null;
		int size = 0 ;
		try
		{
			QuickFilterAttributes attrs = QuickFilterAttributes.getQuickFilterAttributeByLinkname(segmentName);
			switch(attrs) {
			case TRAFFICSOURCE:
				if(expType.equals(ExperimentType.ABTEST.getTypeNumber()) ||expType.equals(ExperimentType.SPLITURL.getTypeNumber()))
				{	
					visitorReportDetails = calculateDetailsForSource(indexName, portal, segmentName, expId,
							startTime, endTime,
							qfNestedParentCond, additionalFilters);
					return visitorReportDetails;
	 
				}
				break;
			case USERTYPE:
				if(expType.equals(ExperimentType.ABTEST.getTypeNumber()) ||expType.equals(ExperimentType.SPLITURL.getTypeNumber()))
				{	
					visitorReportDetails = calculateDetailsForVisitorType(indexName, portal, segmentName, expId,
							startTime, endTime,
							qfNestedParentCond, additionalFilters);
					return visitorReportDetails;
	 
				}
				break;
			case GOALS:
				if(expType.equals(ExperimentType.SESSION_RECORDING.getTypeNumber())) {
					visitorReportDetails = SessionElasticBand.getGoalsQuickFilterStatistics(indexName, expId, startTime, endTime);
					return visitorReportDetails;
				}
			
			}
			
			ExperimentType etype = ExperimentType.getExperimentTypeByNumber(expType);

			query = generateQuickFilterSourceQueryJson(portal, expId, startTime, endTime, qfNestedParentCond, additionalFilters,null,null,null);
			
			if(etype.equals(ExperimentType.SESSION_RECORDING)) {
				String experimentKey = Experiment.getExperimentKeyById(expId);
				Long zsoid = Long.parseLong(ZABUtil.getDBSpace());
				query.must(SessionElasticBand.getVisitorBasicCriteria(zsoid, experimentKey));
			}
			
			
			aggregation  =   generateQuickFilterVistorAggregateJson(segmentName, expType);
			SearchResponse response = ElasticSearchUtil.getData(indexName, ESQuickFilterConstants.ES_INDEX_MAP.get(etype), size, query, aggregation);
			
			visitorReportDetails = readQuickFilterVisitorResponseData(response, expType);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage());
			visitorReportDetails = new ArrayList<ESQuickFilterStatistics>();
		}
		return visitorReportDetails;
	}
	
	private static Boolean isABSplit(Integer expType) {
		return expType.equals(ExperimentType.ABTEST.getTypeNumber()) ||expType.equals(ExperimentType.SPLITURL.getTypeNumber());
	}
	
	private static Boolean isABSplitTrafficSource(Integer expType, String segmentName) {
		return isABSplit(expType) && segmentName.equals(QuickFilterAttributes.TRAFFICSOURCE.getLinkName());
	}
	
	private static Boolean isABSplitVisitorType(Integer expType, String segmentName) {
		return isABSplit(expType) && segmentName.equals(QuickFilterAttributes.USERTYPE.getLinkName());
	}
	
	private static Boolean isLazyLoadSegments(Integer expType, String segmentName) {
		if(isABSplit(expType)) {			
			return isABSplitTrafficSource(expType, segmentName) || isABSplitVisitorType(expType, segmentName);
		} else if(expType.equals(ExperimentType.SESSION_RECORDING.getTypeNumber())) {
			return segmentName.equals(QuickFilterAttributes.GOALS.getLinkName()) ||
				   segmentName.equals(QuickFilterAttributes.PAGECOUNT.getLinkName()) ||
				   segmentName.equals(QuickFilterAttributes.URLVISITED.getLinkName()) ||
				   segmentName.equals(QuickFilterAttributes.ENTRYPAGE.getLinkName()) ||
				   segmentName.equals(QuickFilterAttributes.EXITPAGE.getLinkName()) ||
				   segmentName.equals(QuickFilterAttributes.TIMESPENT.getLinkName());
		} else {
			return false;
		}
	}
		
	public static List<ESQuickFilterWrapper> getQuickFilterMultiSegmentVisitorCount(
			String indexName, String portal, Long expId,
			Integer experimentType,
			Long startTime, Long endTime,
			HashMap<String, String> additionalFilters, 
			 List<QuickFilterAttributes> quickFilterAttrs)
	{
		List<ESQuickFilterWrapper> wrappers = new ArrayList<ESQuickFilterWrapper>();
		BoolQueryBuilder query =  null;
		AggregationBuilder aggregation = null;
		int size = 0 ;
		try
		{
			query = generateQuickFilterSourceQueryJson(portal, expId, startTime, endTime, null, additionalFilters, null, null,null);
			
			ArrayList<AggregationBuilder> builders = new ArrayList<AggregationBuilder>();
			for(QuickFilterAttributes attrs: quickFilterAttrs) {	
				if(!isLazyLoadSegments(experimentType, attrs.getLinkName())) {					
					aggregation  =   generateQuickFilterVistorAggregateJson(attrs.getLinkName(), attrs.getLinkName(),experimentType);
					builders.add(aggregation);
				}
			}
			
			ExperimentType etype = ExperimentType.getExperimentTypeByNumber(experimentType);
			
			if(etype.equals(ExperimentType.SESSION_RECORDING)) {
				String experimentKey = Experiment.getExperimentKeyById(expId);
				Long zsoid = Long.parseLong(ZABUtil.getDBSpace());
				query.must(SessionElasticBand.getVisitorBasicCriteria(zsoid, experimentKey));
			}
			
			SearchResponse response = ElasticSearchUtil.getData(indexName,
					ESQuickFilterConstants.ES_INDEX_MAP.get(etype),
					size, query, builders);
			
			wrappers = readQuickFilterVisitorResponseData(response, quickFilterAttrs, experimentType);
			

			//Add data for user type as it is the first data
			if(isABSplit(experimentType)) {	
				try {
					LOGGER.log(Level.INFO, "UserType fetch start for multiquick segment");
					List<ESQuickFilterWrapper> userTypeWrapList = wrappers.stream().filter(
							(a) -> a.getAttribute()
									.getLinkName()
									.equals(QuickFilterAttributes.USERTYPE
											.getLinkName())).collect(Collectors.toList());
					
					List<ESQuickFilterStatistics> visitorTypeData = calculateDetailsForVisitorType(indexName, portal, QuickFilterAttributes.USERTYPE.getLinkName(), expId,
							startTime, endTime,
							null, additionalFilters);
					
					if(userTypeWrapList.size() > 0 && visitorTypeData.size() > 0) {
						userTypeWrapList.get(0).setVisitorData(new ArrayList<ESQuickFilterStatistics>(visitorTypeData));
						userTypeWrapList.get(0).sortAndAddFillers();
					}
					
					LOGGER.log(Level.INFO, "UserType fetch end for multiquick segment");
				} catch (Exception e) {
					LOGGER.log(Level.SEVERE, e.getMessage());
				}
			}
	 
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage());
			wrappers = new ArrayList<ESQuickFilterWrapper>();
		}
		return wrappers;
	}
			

			
			
	public static List<ESQuickFilterStatistics> calculateDetailsForSource(String indexName, String portal, String segmentName, Long expId,
			Long startTime, Long endTime,
			HashMap<String, String> qfNestedParentCond,
			HashMap<String, String> additionalFilters){
		List<ESQuickFilterStatistics> visitorReportDetails = new ArrayList<ESQuickFilterStatistics>();
		int size = 0 ;
		try{

			TopHitsAggregationBuilder tophitsaggr = AggregationBuilders.topHits("tophits").	// NO I18N
					fetchSource(segmentName, null).size(1).sort("time");	// NO I18N

			TermsAggregationBuilder termsaggr= AggregationBuilders.terms("visitorid").  // No I18N
					field("visitorid").	// NO I18N
					size(ElasticSearchConstants.VISITOR_MAX_COUNT)
					.subAggregation(tophitsaggr);
			
			TermsAggregationBuilder uuidTermsaggr= AggregationBuilders.terms("uuidVisitorId").  // No I18N
					field(ElasticSearchConstants.UUID).	
					size(ElasticSearchConstants.VISITOR_MAX_COUNT)
					.subAggregation(tophitsaggr);
			
			List<AggregationBuilder> aggr = new ArrayList<AggregationBuilder>();
			aggr.add(termsaggr);
			aggr.add(uuidTermsaggr);
			/*TODO set goalId for the experiments primary goal*/
			
			Long goalId= ExperimentGoal.getPrimaryGoalLIdofExperiment(expId);
			QueryBuilder query = generateQuickFilterSourceQueryJson(portal, expId, startTime, endTime, qfNestedParentCond, additionalFilters,goalId,null,null);
			SearchResponse response = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.GOAL_RAW_TYPE, size, query, aggr);
			Aggregations aggrResponse = response.getAggregations();
			Terms terms = aggrResponse.get("visitorid");
			List<? extends Bucket> buckets = terms.getBuckets();

			HashMap<String,Long> sourceHs = new HashMap<String,Long>();
			ArrayList<Long> goalAchievedPersons = new ArrayList<Long>();
			ArrayList<String> goalAchievedPersonsString = new ArrayList<String>();
			for(Bucket bucket:buckets)
			{

				Long visitorid = (Long) bucket.getKey();
				Aggregations buckaggrResponse = bucket.getAggregations();
				org.elasticsearch.search.aggregations.metrics.tophits.InternalTopHits tophits = buckaggrResponse.get("tophits");	// NO I18N

				String source = (String) tophits.getHits().getAt(0).getSource().get("trafficsource");	// NO I18N
				if(sourceHs.containsKey(source)){
					Long oldCount = sourceHs.get(source);
					sourceHs.put(source, oldCount+1);
				}else{
					sourceHs.put(source, 1l);
				}
				goalAchievedPersons.add(visitorid);
			}
			
			Aggregations uuidAggrResponse = response.getAggregations();
			Terms uuidTerms = uuidAggrResponse.get("uuidVisitorId");
			List<? extends Bucket> uuidBuckets = uuidTerms.getBuckets();

			for(Bucket bucket:uuidBuckets)
			{

				String visitorid = (String) bucket.getKey();
				Aggregations buckaggrResponse = bucket.getAggregations();
				org.elasticsearch.search.aggregations.metrics.tophits.InternalTopHits tophits = buckaggrResponse.get("tophits");	// NO I18N

				String source = (String) tophits.getHits().getAt(0).getSource().get("trafficsource");	// NO I18N
				if(sourceHs.containsKey(source)){
					Long oldCount = sourceHs.get(source);
					sourceHs.put(source, oldCount+1);
				}else{
					sourceHs.put(source, 1l);
				}
				goalAchievedPersonsString.add(visitorid);
			}
			
			
			query = generateQuickFilterSourceQueryJson(portal, expId, startTime, endTime, qfNestedParentCond, additionalFilters,null,goalAchievedPersons,null);
			response = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.VISITOR_RAW_TYPE, size, query, aggr);
			aggrResponse = response.getAggregations();
			terms = aggrResponse.get("visitorid");	// NO I18N
			buckets = terms.getBuckets();
			for(Bucket bucket:buckets)
			{
				//Long visitorid = (Long) bucket.getKey();
				Aggregations buckaggrResponse = bucket.getAggregations();
				org.elasticsearch.search.aggregations.metrics.tophits.InternalTopHits tophits = buckaggrResponse.get("tophits");	// NO I18N
				String source = (String) tophits.getHits().getAt(0).getSource().get("trafficsource");	// NO I18N
				if(sourceHs.containsKey(source)){
					Long oldval = (Long)sourceHs.get(source);
					sourceHs.put(source, 1+oldval);
				}else{
					sourceHs.put(source, 1l);
				}
				
			}
			
			query = generateQuickFilterSourceQueryJson(portal, expId, startTime, endTime, qfNestedParentCond, additionalFilters,null,null,goalAchievedPersonsString);
			response = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.VISITOR_RAW_TYPE, size, query, aggr);
			aggrResponse = response.getAggregations();
			terms = aggrResponse.get("uuidVisitorId");	// NO I18N
			buckets = terms.getBuckets();
			for(Bucket bucket:buckets)
			{
				Aggregations buckaggrResponse = bucket.getAggregations();
				org.elasticsearch.search.aggregations.metrics.tophits.InternalTopHits tophits = buckaggrResponse.get("tophits");	// NO I18N
				String source = (String) tophits.getHits().getAt(0).getSource().get("trafficsource");	// NO I18N
				if(sourceHs.containsKey(source)){
					Long oldval = (Long)sourceHs.get(source);
					sourceHs.put(source, 1+oldval);
				}else{
					sourceHs.put(source, 1l);
				}
				
			}
			Set<String> keySet = sourceHs.keySet();
			Iterator<String> keyItr = keySet.iterator();
			while(keyItr.hasNext()){
				String key  = keyItr.next();
				Long value  =sourceHs.get(key);
				ESQuickFilterStatistics esq= new ESQuickFilterStatistics();
				esq.setSegmentValue(key);
				esq.setVisitorCount(value);
				esq.setSuccess(Boolean.TRUE);
				visitorReportDetails.add(esq);
			}

		}catch(Exception e){
			LOGGER.log(Level.SEVERE,"Exception occurred in processing source filter",e);
		}

		return visitorReportDetails;
	}
			
	public static List<ESQuickFilterStatistics> calculateDetailsForVisitorType(String indexName, String portal, String segmentName, Long expId,
			Long startTime, Long endTime,
			HashMap<String, String> qfNestedParentCond,
			HashMap<String, String> additionalFilters){
		List<ESQuickFilterStatistics> visitorReportDetails = new ArrayList<ESQuickFilterStatistics>();
		int size = 0 ;
		try{
			
			TopHitsAggregationBuilder tophitsaggr = AggregationBuilders.topHits("tophits").	// NO I18N
					fetchSource(segmentName, null).size(1).sort("time",SortOrder.DESC);	// NO I18N
			
			List<AggregationBuilder> aggr = new ArrayList<AggregationBuilder>();
 			
			TermsAggregationBuilder termsaggr= AggregationBuilders.terms("visitorid").  // No I18N
					field("visitorid").	// NO I18N
					size(ElasticSearchConstants.VISITOR_MAX_COUNT)
					.subAggregation(tophitsaggr);
			
			TermsAggregationBuilder uuidTermsaggr= AggregationBuilders.terms("uuid").  // No I18N
					field(ElasticSearchConstants.UUID).	
					size(ElasticSearchConstants.VISITOR_MAX_COUNT)
					.subAggregation(tophitsaggr);
					
			aggr.add(termsaggr);
			aggr.add(uuidTermsaggr);
		
			QueryBuilder query = generateQuickFilterSourceQueryJson(portal, expId, startTime, endTime, qfNestedParentCond, additionalFilters,null,null,null);
			SearchResponse response = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.VISITOR_RAW_TYPE, size, query, aggr);
			Aggregations aggrResponse = response.getAggregations();
			Terms terms = aggrResponse.get("visitorid");
			List<? extends Bucket> buckets = terms.getBuckets();

			Long newCount = 0l;
			Long returningCount = 0l;
			for(Bucket bucket:buckets)
			{
				Aggregations buckaggrResponse = bucket.getAggregations();
				org.elasticsearch.search.aggregations.metrics.tophits.InternalTopHits tophits = buckaggrResponse.get("tophits");	// NO I18N
				String usertype = (String) tophits.getHits().getAt(0).getSource().get("usertype");	// NO I18N
				if(usertype.equals("NEW")){
					newCount++;
				}else{
					returningCount++;
				}
				
			}
			
			Terms uuidTerms = aggrResponse.get("uuid");
			List<? extends Bucket> uuidBuckets = uuidTerms.getBuckets();

			
			for(Bucket bucket:uuidBuckets)
			{
				Aggregations buckaggrResponse = bucket.getAggregations();
				org.elasticsearch.search.aggregations.metrics.tophits.InternalTopHits tophits = buckaggrResponse.get("tophits");	// NO I18N
				String usertype = (String) tophits.getHits().getAt(0).getSource().get("usertype");	// NO I18N
				if(usertype.equals("NEW")){
					newCount++;
				}else{
					returningCount++;
				}
				
			}
			
			ESQuickFilterStatistics newesq= new ESQuickFilterStatistics();
			newesq.setSegmentValue(ESQuickFilterConstants.NEW_VISITOR);
			newesq.setVisitorCount(newCount);
			newesq.setSuccess(Boolean.TRUE);
			visitorReportDetails.add(newesq);
			
			ESQuickFilterStatistics returnesq= new ESQuickFilterStatistics();
			returnesq.setSegmentValue(ESQuickFilterConstants.RETURNING_VISITOR);
			returnesq.setVisitorCount(returningCount);
			returnesq.setSuccess(Boolean.TRUE);
			visitorReportDetails.add(returnesq);
			

		}catch(Exception e){
			LOGGER.log(Level.SEVERE,"Exception occurred in processing visitor based filter ",e);
		}
		return visitorReportDetails;
	}
			
	public static BoolQueryBuilder generateQuickFilterSourceQueryJson( String portal, Long expId, Long startTime, Long endTime,HashMap<String, String> qfNestedParentCond, HashMap<String, String> additionalFilters , Long goalId,ArrayList<Long> excludeVisitors,ArrayList<String> excludeUuidVisitors)
	{
		BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
		try
		{
			MatchQueryBuilder portalMatch = QueryBuilders.matchQuery(ElasticSearchConstants.PORTAL, portal);
			MatchQueryBuilder expMatch = QueryBuilders.matchQuery(ElasticSearchConstants.EXPERIMENTID, expId);
			List<QueryBuilder> conditionList = new ArrayList<QueryBuilder>();
			conditionList.add(portalMatch);
			conditionList.add(expMatch);
			
			String experimentUrl = additionalFilters.get(ESQuickFilterConstants.EXPERIMENT_URL);
			String variationLinkname = additionalFilters.get(ESQuickFilterConstants.VARIATION_LINKNAME);
			String device = additionalFilters.get(ESQuickFilterConstants.QF_DEVICE);
			
			
			if(startTime != null)
			{
				RangeQueryBuilder timeRange = QueryBuilders.rangeQuery("time").gte(startTime).lte(endTime); // No I18N
				conditionList.add(timeRange);
			}
			if(qfNestedParentCond != null)
			{
				for(Map.Entry<String, String> condEntry :qfNestedParentCond.entrySet())
				{
					MatchQueryBuilder condMatch = QueryBuilders.matchQuery(condEntry.getKey(), condEntry.getValue());
					conditionList.add(condMatch);
				}
			}
			
			if(variationLinkname!=null) {
				ArrayList<Variation> variations = Variation.getVariationByLinkname(variationLinkname);
				if(variations.size() > 0 && variations.get(0).getSuccess()) {					
					Long variationId = variations.get(0).getVariationId();
					MatchQueryBuilder condMatch = QueryBuilders.matchQuery(ElasticSearchConstants.VARIATIONID, variationId);
					conditionList.add(condMatch);
				}
			}
			
			if(experimentUrl!=null) {
				MatchQueryBuilder condMatch = QueryBuilders.matchQuery(ElasticSearchConstants.CURRENTURL, experimentUrl);
				conditionList.add(condMatch);
			}
			
			if(device!=null) {
				MatchQueryBuilder condMatch = QueryBuilders.matchQuery(ElasticSearchConstants.DEVICE, device.toUpperCase());
				conditionList.add(condMatch);
			}
			if(goalId!=null) {
				MatchQueryBuilder condMatch = QueryBuilders.matchQuery(ElasticSearchConstants.GOALID, goalId);
				conditionList.add(condMatch);
			}
			if(excludeVisitors!=null){
				TermsQueryBuilder termsQuery = QueryBuilders.termsQuery("visitorid", excludeVisitors);	// NO I18N
				boolQueryBuilder.mustNot().add(termsQuery);
			}
			if(excludeUuidVisitors!=null){
				TermsQueryBuilder termsQuery = QueryBuilders.termsQuery("uuid", excludeUuidVisitors);	// NO I18N
				boolQueryBuilder.mustNot().add(termsQuery);
			}
			boolQueryBuilder.must().addAll(conditionList);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
		return boolQueryBuilder;
	} 
			
	public static TermsAggregationBuilder generateQuickFilterVistorAggregateJson(String segmentName, int expType)
	{
		return generateQuickFilterVistorAggregateJson(segmentName, "segment", expType); //NO I18N
	}
	
	public static TermsAggregationBuilder generateQuickFilterVistorAggregateJson(String segmentName, String customAggregationName, Integer expType)
	{
		TermsAggregationBuilder finalAggr = null;
		try
		{
			
			CardinalityAggregationBuilder cardinalityAggregation = null;
			CardinalityAggregationBuilder uuidCardinalityAggregation = null;
			if(expType.equals(ExperimentType.FORMANALYTICS.getTypeNumber())){
				cardinalityAggregation = ElasticFormReport.getVisitorCardinalityAggr();
			} else if(expType.equals(ExperimentType.SESSION_RECORDING.getTypeNumber())) {
				cardinalityAggregation = ElasticSearchStatistics.getSRVisitorsCardinalityAggr();
			} else{
				cardinalityAggregation = ElasticSearchStatistics.getVisitorCardinalityAggr();
				uuidCardinalityAggregation = ElasticSearchStatistics.getUUIDVisitorCardinalityAggr();
			}
			
			if(segmentName.equals(QuickFilterAttributes.DAYOFWEEK.getLinkName()) || segmentName.equals(QuickFilterAttributes.HOUROFDAY.getLinkName()))
			{
				HashMap<String, Object> params = new HashMap<String, Object>();
				String timezone =  ElasticSearchUtil.getCurrentUserTimezone();
				
				params.put(ESQuickFilterConstants.TIMEZONE, timezone);
				params.put(ESQuickFilterConstants.FIELD, ElasticSearchConstants.TIME);
				String scriptCode = null;
				if(segmentName.equals(QuickFilterAttributes.DAYOFWEEK.getLinkName()))
				{
					scriptCode = ESQuickFilterConstants.DAY_OF_WEEK_SCRIPT;
				}
				else if(segmentName.equals(QuickFilterAttributes.HOUROFDAY.getLinkName()))
				{
					scriptCode = ESQuickFilterConstants.HOUR_OF_DAY_SCRIPT;
				}
				Script script = new Script(ScriptType.INLINE, ESQuickFilterConstants.PAINLESS_LANG, scriptCode, params);
				if(expType.equals(ExperimentType.ABTEST.getTypeNumber()) || expType.equals(ExperimentType.SPLITURL.getTypeNumber()) || expType.equals(ExperimentType.HEATMAP.getTypeNumber())) {
					finalAggr = AggregationBuilders.terms(customAggregationName).
							script(script).   
								size(ElasticSearchConstants.SEGMENT_MAX_COUNT).
									subAggregation(cardinalityAggregation).subAggregation(uuidCardinalityAggregation);
				} else {
					finalAggr = AggregationBuilders.terms(customAggregationName).
							script(script).   
								size(ElasticSearchConstants.SEGMENT_MAX_COUNT).
									subAggregation(cardinalityAggregation);
					
				}
			}
			else
			{
				if(expType.equals(ExperimentType.ABTEST.getTypeNumber()) || expType.equals(ExperimentType.SPLITURL.getTypeNumber()) || expType.equals(ExperimentType.HEATMAP.getTypeNumber())) {

					finalAggr = AggregationBuilders.terms(customAggregationName).
						field(segmentName).
						size(ElasticSearchConstants.SEGMENT_MAX_COUNT).
							subAggregation(cardinalityAggregation).subAggregation(uuidCardinalityAggregation);
				} else {
					finalAggr = AggregationBuilders.terms(customAggregationName).
							field(segmentName).
							size(ElasticSearchConstants.SEGMENT_MAX_COUNT).
								subAggregation(cardinalityAggregation);
				}
			}
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
		return finalAggr;
	}
	
	public static List<ESQuickFilterStatistics> readQuickFilterVisitorResponseData(SearchResponse response, int expType)
	{
		return readQuickFilterVisitorResponseData(response, "segment", expType); //NO I18N
	}
	
	public static List<ESQuickFilterStatistics> readQuickFilterVisitorResponseData(SearchResponse response, String customSegmentName, Integer expType)
	{
		List<ESQuickFilterStatistics> visitorReportDetails = new ArrayList<ESQuickFilterStatistics>();
		try
		{
		
			Aggregations aggrResponse = response.getAggregations();
			Terms terms = aggrResponse.get("segment");
			List<? extends Bucket> buckets = terms.getBuckets();
			String distinctVisitors = null;
			if(expType.equals(ExperimentType.FORMANALYTICS.getTypeNumber())){
				distinctVisitors = FormReportConstants.FORM_UNIQUE_VISITOR_COUNT;
			} else{
				distinctVisitors = "distinct_visitors"; //No I18N
			}
			for(Bucket bucket:buckets)
			{
				String segmentValue = (String)bucket.getKey();
				Long uniqueCount = 0l;
				Aggregations buckaggrResponse = bucket.getAggregations();
				InternalCardinality cardinality = buckaggrResponse.get(distinctVisitors);
				uniqueCount = cardinality.getValue();
				if(expType.equals(ExperimentType.ABTEST.getTypeNumber()) || expType.equals(ExperimentType.SPLITURL.getTypeNumber()) || expType.equals(ExperimentType.HEATMAP.getTypeNumber())) {
					
					InternalCardinality uuidCardinality = buckaggrResponse.get("distinct_uuid_visitors");
					uniqueCount = uniqueCount + uuidCardinality.getValue();
				}
				ESQuickFilterStatistics stat = new ESQuickFilterStatistics();
				stat.setSegmentValue(segmentValue);
				stat.setVisitorCount(uniqueCount);
				stat.setSuccess(true);
				visitorReportDetails.add(stat);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			visitorReportDetails = new ArrayList<ESQuickFilterStatistics>();
		}
		return visitorReportDetails;
	}
	

	public static List<ESQuickFilterWrapper> readQuickFilterVisitorResponseData(SearchResponse response, List<QuickFilterAttributes> attribs, Integer experimentType)
	{
		List<ESQuickFilterWrapper> visitorReportDetails = new ArrayList<ESQuickFilterWrapper>();
		try
		{
			Aggregations aggrResponse = response.getAggregations();
			String uniqueVisitorVariable = null;
			String uniqueUuidVisitorVariable = "distinct_uuid_visitors"; //No I18N
			if(experimentType.equals(ExperimentType.FORMANALYTICS.getTypeNumber())){
				uniqueVisitorVariable = FormReportConstants.FORM_UNIQUE_VISITOR_COUNT;
			} else{
				uniqueVisitorVariable = "distinct_visitors"; //No I18N
			}
			for(QuickFilterAttributes attrib: attribs) {
				
				ESQuickFilterWrapper wrapper = new ESQuickFilterWrapper();
				wrapper.setAttribute(attrib);
				if(!isLazyLoadSegments(experimentType, attrib.getLinkName())) {
					Terms terms = aggrResponse.get(attrib.getLinkName());
					List<? extends Bucket> buckets = terms.getBuckets();
					for(Bucket bucket:buckets)
					{
						String segmentValue = (String)bucket.getKey();
						Long uniqueCount = 0l;
						Aggregations buckaggrResponse = bucket.getAggregations();
						InternalCardinality cardinality = buckaggrResponse.get(uniqueVisitorVariable);
						uniqueCount = cardinality.getValue();
						if(experimentType.equals(ExperimentType.ABTEST.getTypeNumber()) || experimentType.equals(ExperimentType.SPLITURL.getTypeNumber()) || experimentType.equals(ExperimentType.HEATMAP.getTypeNumber())) {
							InternalCardinality uuidCardinality = buckaggrResponse.get(uniqueUuidVisitorVariable);
							Long uuidUniqueCount = 0l;
							uuidUniqueCount = uuidCardinality.getValue();
							uniqueCount = uniqueCount + uuidUniqueCount;
						}
						ESQuickFilterStatistics stat = new ESQuickFilterStatistics();
						stat.setSegmentValue(segmentValue);
						stat.setVisitorCount(uniqueCount);
						stat.setSuccess(true);
						wrapper.getVisitorData().add(stat);
					}
					wrapper.sortAndAddFillers();
				}
				visitorReportDetails.add(wrapper);
				
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			visitorReportDetails = new ArrayList<ESQuickFilterWrapper>();
		}
		return visitorReportDetails;
	}
}
