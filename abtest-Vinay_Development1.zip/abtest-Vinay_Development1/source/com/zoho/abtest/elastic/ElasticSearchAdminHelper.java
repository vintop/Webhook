//$Id$
package com.zoho.abtest.elastic;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.report.ElasticSearchConstants.ElasticJSONColumn;
import com.zoho.abtest.report.ElasticSearchConstants.HeatmapRawDataType;
import com.zoho.abtest.report.ElasticSearchConstants.ScrollmapRawDataType;
import com.zoho.abtest.report.ElasticSearchConstants.VisitorRawDataType;
import com.zoho.abtest.sessionrecording.SessionElasticDocDetails;
import com.zoho.abtest.sessionrecording.SessionElasticDocDetails.SessionRawDataType;

public class ElasticSearchAdminHelper 
{
	private static final Logger LOGGER = Logger.getLogger(ElasticSearchAdminHelper.class.getName());
	
	
	public static void updateScriptMaxCompilationPerMin(int value) throws UnknownHostException {
		ElasticSearchUtil.updateScriptMaxCompilation(value);
	}
	
	public static void addRevenueMappingToGoalType()
	{
		try
		{
			JSONObject resultJsonObject = new JSONObject();
			JSONObject propertiesJsonObject = new JSONObject();
			String fieldName = ElasticSearchConstants.GaolRawDataType.REVENUE.getFieldName();
			String fieldType = ElasticSearchConstants.GaolRawDataType.REVENUE.getFieldType();
			
			JSONObject fieldJson = new JSONObject();
			fieldJson.put("type", fieldType);
			fieldJson.put("index","not_analyzed");
			propertiesJsonObject.put(fieldName, fieldJson);
			resultJsonObject.put("properties", propertiesJsonObject);
			
			String indexPattern = ElasticSearchConstants.DEFAULT_INDEX_PREFIX + "*";
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.GOAL_RAW_TYPE, resultJsonObject.toString());
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
	}
	
	public static void addEventMapping()
	{
		try
		{
			JSONObject resultJsonObject = new JSONObject();
			JSONObject propertiesJsonObject = new JSONObject();
			String fieldName = ElasticSearchConstants.GaolRawDataType.GOALID.getFieldName();
			String fieldType = ElasticSearchConstants.GaolRawDataType.GOALID.getFieldType();
			
			JSONObject fieldJson = new JSONObject();
			fieldJson.put("type", fieldType);
			fieldJson.put("index","not_analyzed");
			propertiesJsonObject.put(fieldName, fieldJson);
			resultJsonObject.put("properties", propertiesJsonObject);
			
			String indexPattern = ElasticSearchConstants.DEFAULT_INDEX_PREFIX + "*";
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.VISITOR_RAW_TYPE, resultJsonObject.toString());
			
			
			resultJsonObject = new JSONObject();
			propertiesJsonObject = new JSONObject();
			fieldName = ElasticSearchConstants.GaolRawDataType.PROJECTID.getFieldName();
			fieldType = ElasticSearchConstants.GaolRawDataType.PROJECTID.getFieldType();
			
			fieldJson = new JSONObject();
			fieldJson.put("type", fieldType);
			fieldJson.put("index","not_analyzed");
			propertiesJsonObject.put(fieldName, fieldJson);
			resultJsonObject.put("properties", propertiesJsonObject);
			
			indexPattern = ElasticSearchConstants.DEFAULT_INDEX_PREFIX + "*";
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.GOAL_RAW_TYPE, resultJsonObject.toString());
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.VISITOR_RAW_TYPE, resultJsonObject.toString());
			
			
		
			resultJsonObject = new JSONObject();
			propertiesJsonObject = new JSONObject();
			fieldName = ElasticSearchConstants.GaolRawDataType.TIME_SPENT.getFieldName();
			fieldType = ElasticSearchConstants.GaolRawDataType.TIME_SPENT.getFieldType();
			
			fieldJson = new JSONObject();
			fieldJson.put("type", fieldType);
			fieldJson.put("index","not_analyzed");
			propertiesJsonObject.put(fieldName, fieldJson);
			resultJsonObject.put("properties", propertiesJsonObject);
			
			indexPattern = ElasticSearchConstants.DEFAULT_INDEX_PREFIX + "*";
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.GOAL_RAW_TYPE, resultJsonObject.toString());
			
			resultJsonObject = new JSONObject();
			propertiesJsonObject = new JSONObject();
			fieldName = ElasticSearchConstants.GaolRawDataType.IS_PROJECT_GOAL.getFieldName();
			fieldType = ElasticSearchConstants.GaolRawDataType.IS_PROJECT_GOAL.getFieldType();
			
			fieldJson = new JSONObject();
			fieldJson.put("type", fieldType);
			fieldJson.put("index","not_analyzed");
			propertiesJsonObject.put(fieldName, fieldJson);
			resultJsonObject.put("properties", propertiesJsonObject);
			
			indexPattern = ElasticSearchConstants.DEFAULT_INDEX_PREFIX + "*";
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.GOAL_RAW_TYPE, resultJsonObject.toString());
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.VISITOR_RAW_TYPE, resultJsonObject.toString());
			
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
		
	}
	public static void addCityToAllType()
	{
		try
		{
			JSONObject resultJsonObject = new JSONObject();
			JSONObject propertiesJsonObject = new JSONObject();
			
			String cityFieldName = ElasticSearchConstants.VisitorRawDataType.CITY.getFieldName();
			String cityFieldType = ElasticSearchConstants.VisitorRawDataType.CITY.getFieldType();
			
			String regionFieldName = ElasticSearchConstants.VisitorRawDataType.REGION.getFieldName();
			
			JSONObject fieldJson = new JSONObject();
			fieldJson.put("type", cityFieldType);
			fieldJson.put("index","not_analyzed");
			propertiesJsonObject.put(cityFieldName, fieldJson);
			propertiesJsonObject.put(regionFieldName, fieldJson);
			resultJsonObject.put("properties", propertiesJsonObject);
			
			String indexPattern = ElasticSearchConstants.DEFAULT_INDEX_PREFIX + "*";
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.VISITOR_RAW_TYPE, resultJsonObject.toString());
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.GOAL_RAW_TYPE, resultJsonObject.toString());
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.HEATMAP_RAW_TYPE, resultJsonObject.toString());
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.SCROLLMAP_RAW_TYPE, resultJsonObject.toString());
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.FUNNEL_RAW_TYPE, resultJsonObject.toString());
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
	}
	
	public static void addUuidToSpecificTypes()
	{
		try
		{
			JSONObject resultJsonObject = new JSONObject();
			JSONObject propertiesJsonObject = new JSONObject();
			
			String uuidFieldName = ElasticSearchConstants.VisitorRawDataType.UUID.getFieldName();
			String uuidFieldType = ElasticSearchConstants.VisitorRawDataType.UUID.getFieldType();

						
			JSONObject fieldJson = new JSONObject();
			fieldJson.put("type", uuidFieldType);
			fieldJson.put("index","not_analyzed");
			propertiesJsonObject.put(uuidFieldName, fieldJson);
			resultJsonObject.put("properties", propertiesJsonObject);
			
			String indexPattern = ElasticSearchConstants.DEFAULT_INDEX_PREFIX + "*";
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.VISITOR_RAW_TYPE, resultJsonObject.toString());
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.GOAL_RAW_TYPE, resultJsonObject.toString());
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.HEATMAP_RAW_TYPE, resultJsonObject.toString());
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.SCROLLMAP_RAW_TYPE, resultJsonObject.toString());
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
	}
	
	public static void addZsoidToAllType()
	{
		try
		{
			JSONObject resultJsonObject = new JSONObject();
			JSONObject propertiesJsonObject = new JSONObject();
			
			String zsoidFieldName = ElasticSearchConstants.VisitorRawDataType.ZSOID.getFieldName();
			String zsoidFieldType = ElasticSearchConstants.VisitorRawDataType.ZSOID.getFieldType();
			
			JSONObject fieldJson = new JSONObject();
			fieldJson.put("type", zsoidFieldType);
			fieldJson.put("index","not_analyzed");
			propertiesJsonObject.put(zsoidFieldName, fieldJson);
			resultJsonObject.put("properties", propertiesJsonObject);
			
			String indexPattern = ElasticSearchConstants.DEFAULT_INDEX_PREFIX + "*";
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.VISITOR_RAW_TYPE, resultJsonObject.toString());
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.GOAL_RAW_TYPE, resultJsonObject.toString());
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.HEATMAP_RAW_TYPE, resultJsonObject.toString());
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.SCROLLMAP_RAW_TYPE, resultJsonObject.toString());
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.FUNNEL_RAW_TYPE, resultJsonObject.toString());
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
	}
	
	public static void addDAToESTypes()
	{
		try
		{
			JSONObject resultJsonObject = new JSONObject();
			JSONObject mapping = new JSONObject();
			
			List<VisitorRawDataType> visitorDARawDataTypes = new ArrayList<ElasticSearchConstants.VisitorRawDataType>();
			visitorDARawDataTypes.add(VisitorRawDataType.NURLPARAMETER);
			visitorDARawDataTypes.add(VisitorRawDataType.NCOOKIE);
			visitorDARawDataTypes.add(VisitorRawDataType.NJSVARIABLE);
			visitorDARawDataTypes.add(VisitorRawDataType.NCUSTOMDIMENSION);
			
			for(VisitorRawDataType visitorRawDataType:visitorDARawDataTypes)
			{
				String fieldName = visitorRawDataType.getFieldName();
				String fieldValue = visitorRawDataType.getFieldType();
				JSONObject subjson = new JSONObject();
				subjson.put("type", fieldValue);
				JSONObject nestedPropJson = ElasticSearchUtil.getNestedProperties();
				subjson.put("properties",nestedPropJson);
				mapping.put(fieldName,subjson);
			}
			
			resultJsonObject.put("properties", mapping);
			//JSONArray dynamicTemplateArr = ElasticSearchUtil.getDynamicTemplatesForDynamicAttributes();
			//resultJsonObject.put("dynamic_templates", dynamicTemplateArr);
			
			//For funnel start
			JSONObject funnelResultJsonObject = new JSONObject();
			JSONObject stepMapping = new JSONObject();
			
			JSONObject stepNestedMapping = new JSONObject();
			stepNestedMapping.put("properties", mapping);
			stepNestedMapping.put("type", "nested");
			
			stepMapping.put("steps", stepNestedMapping);
			funnelResultJsonObject.put("properties", stepMapping);
			//Funnel completed
			
			String indexPattern = ElasticSearchConstants.DEFAULT_INDEX_PREFIX + "*";
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.VISITOR_RAW_TYPE, resultJsonObject.toString());
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.GOAL_RAW_TYPE, resultJsonObject.toString());
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.HEATMAP_RAW_TYPE, resultJsonObject.toString());
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.SCROLLMAP_RAW_TYPE, resultJsonObject.toString());
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.FUNNEL_RAW_TYPE, funnelResultJsonObject.toString());
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
	}
	
	public static void addUserTypeToHeatmapScrollmapType()
	{
		try
		{
			JSONObject resultJsonObject = new JSONObject();
			JSONObject propertiesJsonObject = new JSONObject();
			String fieldName = ElasticSearchConstants.HeatmapRawDataType.USERTYPE.getFieldName();
			String fieldType = ElasticSearchConstants.HeatmapRawDataType.USERTYPE.getFieldType();
			
			JSONObject fieldJson = new JSONObject();
			fieldJson.put("type", fieldType);
			fieldJson.put("index","not_analyzed");
			propertiesJsonObject.put(fieldName, fieldJson);
			resultJsonObject.put("properties", propertiesJsonObject);
			
			String indexPattern = ElasticSearchConstants.DEFAULT_INDEX_PREFIX + "*";
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.HEATMAP_RAW_TYPE, resultJsonObject.toString());
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.SCROLLMAP_RAW_TYPE, resultJsonObject.toString());
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
	}
	
	public static void addHeatmapEnabledMappingToVisitorRawDataType()
	{
		try
		{
			JSONObject resultJsonObject = new JSONObject();
			JSONObject propertiesJsonObject = new JSONObject();
			String fieldName = ElasticSearchConstants.VisitorRawDataType.HEATMAP_ENABLED.getFieldName();
			String fieldType = ElasticSearchConstants.VisitorRawDataType.HEATMAP_ENABLED.getFieldType();
			
			JSONObject fieldJson = new JSONObject();
			fieldJson.put("type", fieldType);
			propertiesJsonObject.put(fieldName, fieldJson);
			resultJsonObject.put("properties", propertiesJsonObject);
			
			String indexPattern = ElasticSearchConstants.DEFAULT_INDEX_PREFIX + "*";
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.VISITOR_RAW_TYPE, resultJsonObject.toString());
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
	}
	
	public static void addTimeSpentMappingToScrollmapRawDataType()
	{
		try
		{
			JSONObject resultJsonObject = new JSONObject();
			JSONObject propertiesJsonObject = new JSONObject();
			String fieldName = ElasticSearchConstants.ScrollmapRawDataType.TIME_SPENT.getFieldName();
			String fieldType = ElasticSearchConstants.ScrollmapRawDataType.TIME_SPENT.getFieldType();
			
			JSONObject fieldJson = new JSONObject();
			fieldJson.put("type", fieldType);
			propertiesJsonObject.put(fieldName, fieldJson);
			resultJsonObject.put("properties", propertiesJsonObject);
			
			String indexPattern = ElasticSearchConstants.DEFAULT_INDEX_PREFIX + "*";
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.SCROLLMAP_RAW_TYPE, resultJsonObject.toString());
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
	}
	
	public static void updateScrollListTypeInScrollMapType()
	{
		try
		{
			LOGGER.log(Level.INFO,"Started updateScrollListTypeInScrollMapType");
			JSONObject resultJsonObject = new JSONObject();
			JSONObject propertiesJsonObject = new JSONObject();
			String fieldName = ScrollmapRawDataType.SCROLL_LIST.getFieldName();
			String fieldType = ScrollmapRawDataType.SCROLL_LIST.getFieldType();
			
			JSONObject fieldJson = new JSONObject();
			fieldJson.put("type", fieldType);
			fieldJson.put("fielddata", true);
			JSONObject keywordjson = new JSONObject();
			keywordjson.put("type", "keyword");
			JSONObject fieldsjson = new JSONObject();
			fieldsjson.put("keyword", keywordjson);
			fieldJson.put( "fields", fieldsjson);
			propertiesJsonObject.put(fieldName, fieldJson);
			resultJsonObject.put("properties", propertiesJsonObject);
			
			String indexPattern = ElasticSearchConstants.DEFAULT_INDEX_PREFIX + "*";
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.SCROLLMAP_RAW_TYPE, resultJsonObject.toString());
			LOGGER.log(Level.INFO,"Completed updateScrollListTypeInScrollMapType");
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Error updateScrollListTypeInScrollMapType");
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
	}
	
	public static void addHeatMapAndScrollMapMappings()
	{
		try
		{
			JSONObject heatmapTypeJson = ElasticSearchUtil.getHeatmapDataFieldsType();
			JSONObject scrollmapTypeJson = ElasticSearchUtil.getScrollmapDataFieldsType();
			
			String indexPattern = ElasticSearchConstants.DEFAULT_INDEX_PREFIX + "*";
			
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.HEATMAP_RAW_TYPE, heatmapTypeJson.toString());
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.SCROLLMAP_RAW_TYPE, scrollmapTypeJson.toString());
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
	}
	
	public static void addFunnelMapMappings()
	{
		try
		{
			JSONObject funnelTypeJson = ElasticSearchUtil.getFunnelDataFieldsType();
			
			String indexPattern = ElasticSearchConstants.DEFAULT_INDEX_PREFIX + "*";
			
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.FUNNEL_RAW_TYPE, funnelTypeJson.toString());
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
	}
	
	public static void addFormAndFieldMappings()
	{
		try
		{
			JSONObject formTypeJson = ElasticSearchUtil.getFormAnalyticsDataFieldsType();
			
			JSONObject formFieldTypeJson = ElasticSearchUtil.getFormAnalyticsFieldsType();
			
			String indexPattern = ElasticSearchConstants.DEFAULT_INDEX_PREFIX + "*";
			
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.FORM_ANALYTICS_RAW_TYPE, formTypeJson.toString());
			
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.FORM_ANALYTICS_FIELDS_RAW_TYPE, formFieldTypeJson.toString());

		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
	}
	
	public static void addAdwordDataMappings()
	{
		try
		{
			JSONObject adwordTypeJson = ElasticSearchUtil.getAdwordsDataFieldsType();
			
			String indexPattern = ElasticSearchConstants.DEFAULT_INDEX_PREFIX + "*";
			
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.ADWORDS_RAW_TYPE, adwordTypeJson.toString());
			

		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
	}
	
	public static void addFunnelMapVisitorTypeMappings()
	{
		try
		{
			JSONObject funnelTypeJson = ElasticSearchUtil.getFunnelVisitorTypeMapping();
			
			String indexPattern = ElasticSearchConstants.DEFAULT_INDEX_PREFIX + "*";
			
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.FUNNEL_RAW_TYPE, funnelTypeJson.toString());
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
	}
	
	public static void addSessionTypeMappings() throws JSONException
	{
		
			//Setting page path in visitor doc
			String indexPattern = ElasticSearchConstants.DEFAULT_INDEX_PREFIX + "*";
			
			JSONObject mapping = new JSONObject();
			JSONObject maping_prop = new JSONObject();
			JSONObject nestedmapping = new JSONObject();
			JSONObject npropertiesmapping = new JSONObject();
			
			JSONObject subjson = new JSONObject();
			subjson.put("type", "string");
			subjson.put("index","not_analyzed");
			npropertiesmapping.put(ElasticSearchConstants.PAGE_DFS_FILE_PATH,subjson);
			
			nestedmapping.put("properties", npropertiesmapping);
			nestedmapping.put("type", "nested");
			mapping.put(ElasticSearchConstants.URLS_VISITED, nestedmapping);
			maping_prop.put("properties", mapping);
			
			
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.SESSION_RAW_DATA_TYPE, maping_prop.toString());
			
			//Setting resource path in resource doc
			JSONObject resultJsonObject = new JSONObject();
			JSONObject propertiesJsonObject = new JSONObject();
			String fieldName = ElasticSearchConstants.PAGE_RESOURCE_DFS_FILE_PATH;
			String fieldType = "string"; //NO I18N
			
			JSONObject fieldJson = new JSONObject();
			fieldJson.put("type", fieldType);
			fieldJson.put("index","not_analyzed");
			propertiesJsonObject.put(fieldName, fieldJson);
			resultJsonObject.put("properties", propertiesJsonObject);
			
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.SESSION_PAGE_RESOURCE_TYPE, resultJsonObject.toString());
	}
	
	public static void addTimeSpentMapping()
	{
		try
		{
			JSONObject resultJsonObject = new JSONObject();
			JSONObject propertiesJsonObject = new JSONObject();
			String fieldName = ElasticSearchConstants.VisitorRawDataType.TIME_SPENT.getFieldName();
			String fieldType = ElasticSearchConstants.VisitorRawDataType.TIME_SPENT.getFieldType();
			
			JSONObject fieldJson = new JSONObject();
			fieldJson.put("type", fieldType);
			fieldJson.put("index","not_analyzed");
			propertiesJsonObject.put(fieldName, fieldJson);
			resultJsonObject.put("properties", propertiesJsonObject);
			
			String indexPattern = ElasticSearchConstants.DEFAULT_INDEX_PREFIX + "*";
			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.VISITOR_RAW_TYPE, resultJsonObject.toString());
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
	}
	
//	public static void addIdentifyMapping()
//	{
//		try
//		{
//			JSONObject identifyTypeJson = ElasticSearchUtil.getIdentityDataType();
//			
//			String indexPattern = ElasticSearchConstants.DEFAULT_INDEX_PREFIX + "*";
//			
//			ElasticSearchUtil.updateIndexTypeMapping(indexPattern, ElasticSearchConstants.IDENTITY_RAW_DATA_TYPE, identifyTypeJson.toString());
//			
//		}
//		catch(Exception ex)
//		{
//			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
//		}
//	}
	
}
