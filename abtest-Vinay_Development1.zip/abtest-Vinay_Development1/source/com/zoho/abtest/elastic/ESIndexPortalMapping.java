//$Id$
package com.zoho.abtest.elastic;

import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.ES_INDEX_META;
import com.zoho.abtest.ES_INDEX_PORTAL_MAPPING;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.utility.ZABServiceOrgUtil;

public class ESIndexPortalMapping extends ZABModel
{
	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = Logger.getLogger(ESIndexPortalMapping.class.getName());
	
	private Long mappingId;
	private Long esIndexMetaId;
	private String portlaName;
	private Long zsoid;
	
	public Long getZsoid() {
		return zsoid;
	}
	public void setZsoid(Long zsoid) {
		this.zsoid = zsoid;
	}
	public Long getMappingId() {
		return mappingId;
	}
	public void setMappingId(Long mappingId) {
		this.mappingId = mappingId;
	}
	public Long getEsIndexMetaId() {
		return esIndexMetaId;
	}
	public void setEsIndexMetaId(Long esIndexMetaId) {
		this.esIndexMetaId = esIndexMetaId;
	}
	public String getPortlaName() {
		return portlaName;
	}
	public void setPortlaName(String portlaName) {
		this.portlaName = portlaName;
	}
	
	public static ESIndexPortalMapping createESIndexPortalMapping(HashMap<String, String> hs) throws Exception
	{
		ESIndexPortalMapping indexPortalMapping = null;
		try
		{
			DataObject dataObj = ZABModel.createRow(ElasticSearchIndexConstants.ES_INDEX_PORTAL_MAPPING_CONSTANTS, ES_INDEX_PORTAL_MAPPING.TABLE, hs);
			Row row = dataObj.getFirstRow(ES_INDEX_PORTAL_MAPPING.TABLE);
			indexPortalMapping = getESIndexPortalMappingFromRow(row);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			throw ex;
		}
		return indexPortalMapping;
	}
	
	public static void updateESIndexPortalMapping(HashMap<String, String> hs, Long mappingId)
	{
		try
		{
			Criteria criteria = new Criteria(new Column(ES_INDEX_PORTAL_MAPPING.TABLE, ES_INDEX_PORTAL_MAPPING.MAPPING_ID), mappingId, QueryConstants.EQUAL);
			ZABModel.updateRow(ElasticSearchIndexConstants.ES_INDEX_PORTAL_MAPPING_CONSTANTS, ES_INDEX_PORTAL_MAPPING.TABLE, hs, criteria, null, true);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
	}
	
	public static String getIndexByPortal(String portalName) throws Exception
	{
		String indexName = null;
		try
		{
			Criteria criteria = new Criteria(new Column(ES_INDEX_PORTAL_MAPPING.TABLE, ES_INDEX_PORTAL_MAPPING.PORTAL_NAME), portalName, QueryConstants.EQUAL);
			Join join = new Join(ES_INDEX_PORTAL_MAPPING.TABLE, ES_INDEX_META.TABLE, new String[]{ES_INDEX_PORTAL_MAPPING.ES_INDEX_META_ID}, new String[]{ES_INDEX_META.ES_INDEX_META_ID}, Join.INNER_JOIN);
			DataObject dataObj = ZABModel.getRow(ES_INDEX_PORTAL_MAPPING.TABLE, criteria, join);
			if(!dataObj.isEmpty() && dataObj.containsTable(ES_INDEX_META.TABLE) )
			{
				indexName = (String)dataObj.getFirstValue(ES_INDEX_META.TABLE, ES_INDEX_META.INDEX_NAME);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			throw ex;
		}
		return indexName;
	}
	
	public static String assignIndexToPortal(String portalName, Long zsoid) throws Exception
	{
		String indexName = null;
		try
		{
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(ElasticSearchIndexConstants.PORTAL_NAME, portalName);
			hs.put(ElasticSearchIndexConstants.ZSOID, zsoid.toString());
			ESIndexMeta indexMeta = ESIndexMeta.getMostAvailableIndex();
			if(indexMeta != null)
			{
				hs.put(ElasticSearchIndexConstants.ES_INDEX_META_ID, indexMeta.getEsIndexMetaId().toString());
				indexName = indexMeta.getIndexName();
				createESIndexPortalMapping(hs);
				ESIndexMeta.updateIndexAvailability(indexMeta.getEsIndexMetaId());
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			throw ex;
		}
		return indexName;
	}
	
	public static void unAssignPortalIndex(String portalName) throws Exception
	{
		try
		{
			Criteria criteria = new Criteria(new Column(ES_INDEX_PORTAL_MAPPING.TABLE, ES_INDEX_PORTAL_MAPPING.PORTAL_NAME), portalName, QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(ES_INDEX_PORTAL_MAPPING.TABLE, criteria);
			if(!dataObj.isEmpty())
			{
				Row row = dataObj.getFirstRow(ES_INDEX_PORTAL_MAPPING.TABLE);
				ESIndexPortalMapping portalMapping =  getESIndexPortalMappingFromRow(row);
				ESIndexMeta.reduceIndexPortalValue(portalMapping.getEsIndexMetaId());
				ZABModel.deleteRow(ES_INDEX_PORTAL_MAPPING.TABLE, criteria, null);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			throw ex;
		}
	}
	
	public static ESIndexPortalMapping getESIndexPortalMappingFromRow(Row row)
	{
		ESIndexPortalMapping portalMapping = new ESIndexPortalMapping();
		portalMapping.setMappingId((Long)row.get(ES_INDEX_PORTAL_MAPPING.MAPPING_ID));
		portalMapping.setEsIndexMetaId((Long)row.get(ES_INDEX_PORTAL_MAPPING.ES_INDEX_META_ID));
		portalMapping.setPortlaName((String)row.get(ES_INDEX_PORTAL_MAPPING.PORTAL_NAME));
		portalMapping.setZsoid((Long)row.get(ES_INDEX_PORTAL_MAPPING.ZSOID));
		return portalMapping;
	}
	
	public static void includeZsoidDetails()
	{
		try
		{
			LOGGER.log(Level.INFO,"STarted includeZsoidDetails");
			DataObject dataObj  = ZABModel.getRow(ES_INDEX_PORTAL_MAPPING.TABLE, null);
			Iterator<?> iter  = dataObj.getRows(ES_INDEX_PORTAL_MAPPING.TABLE);
			while(iter.hasNext())
			{
				Row row  = (Row)iter.next();
				Long mappingId = (Long)row.get(ES_INDEX_PORTAL_MAPPING.MAPPING_ID);
				String domain = (String)row.get(ES_INDEX_PORTAL_MAPPING.PORTAL_NAME);
				Long zsoid = ZABServiceOrgUtil.getZSOIDFromDomain(domain);
				if(zsoid != null)
				{
					HashMap<String, String> hs = new HashMap<String, String>();
					hs.put(ElasticSearchIndexConstants.ZSOID, zsoid.toString());
					updateESIndexPortalMapping(hs, mappingId);
				}
			}
			LOGGER.log(Level.INFO,"COmpleted includeZsoidDetails");
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
	}
	
}
