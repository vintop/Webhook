//$Id$
package com.zoho.abtest.elastic;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.ActionListener;
import org.elasticsearch.action.admin.cluster.health.ClusterHealthResponse;
import org.elasticsearch.action.admin.cluster.node.stats.NodeStats;
import org.elasticsearch.action.admin.cluster.node.stats.NodesStatsResponse;
import org.elasticsearch.action.admin.cluster.stats.ClusterStatsIndices;
import org.elasticsearch.action.admin.cluster.stats.ClusterStatsResponse;
import org.elasticsearch.action.admin.indices.create.CreateIndexRequestBuilder;
import org.elasticsearch.action.admin.indices.create.CreateIndexResponse;
import org.elasticsearch.action.admin.indices.mapping.put.PutMappingResponse;
import org.elasticsearch.action.admin.indices.stats.IndexStats;
import org.elasticsearch.action.admin.indices.stats.IndicesStatsResponse;
import org.elasticsearch.action.bulk.BulkItemResponse;
import org.elasticsearch.action.bulk.BulkRequestBuilder;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.delete.DeleteResponse;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.action.update.UpdateResponse;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.cluster.health.ClusterHealthStatus;
import org.elasticsearch.cluster.health.ClusterIndexHealth;
import org.elasticsearch.cluster.node.DiscoveryNode;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.ExistsQueryBuilder;
import org.elasticsearch.index.query.MatchQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.reindex.BulkByScrollResponse;
import org.elasticsearch.index.reindex.DeleteByQueryAction;
import org.elasticsearch.index.reindex.DeleteByQueryRequestBuilder;
import org.elasticsearch.indices.NodeIndicesStats;
import org.elasticsearch.monitor.fs.FsInfo;
import org.elasticsearch.monitor.jvm.JvmStats;
import org.elasticsearch.monitor.os.OsStats;
import org.elasticsearch.monitor.process.ProcessStats;
import org.elasticsearch.script.Script;
import org.elasticsearch.script.ScriptType;
import org.elasticsearch.script.mustache.SearchTemplateRequestBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.sort.SortBuilder;
import org.elasticsearch.threadpool.ThreadPoolStats;
import org.elasticsearch.threadpool.ThreadPoolStats.Stats;
import org.elasticsearch.transport.client.PreBuiltTransportClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.adventnet.iam.IAMUtil;
import com.adventnet.iam.ServiceOrg;
import com.zoho.abtest.elastic.ElasticSearchIndexConstants.ESOpertaionType;
import com.zoho.abtest.elastic.adminconsole.ESAdminConsole;
import com.zoho.abtest.elastic.adminconsole.ESClusterDetails;
import com.zoho.abtest.elastic.adminconsole.ESIndexDetails;
import com.zoho.abtest.elastic.adminconsole.ESNodeDetails;
import com.zoho.abtest.elastic.adminconsole.NodeFSStats;
import com.zoho.abtest.elastic.adminconsole.NodeIndexStats;
import com.zoho.abtest.elastic.adminconsole.NodeJvmStats;
import com.zoho.abtest.elastic.adminconsole.NodeOsStats;
import com.zoho.abtest.elastic.adminconsole.NodeProcessStats;
import com.zoho.abtest.elastic.adminconsole.NodeThreadPoolStats;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.report.ElasticSearchConstants.AdwordsRawDataType;
import com.zoho.abtest.report.ElasticSearchConstants.FormFieldRawDataType;
import com.zoho.abtest.report.ElasticSearchConstants.FormRawDataType;
import com.zoho.abtest.report.ElasticSearchConstants.FunnelRawDataType;
import com.zoho.abtest.report.ElasticSearchConstants.GaolRawDataType;
import com.zoho.abtest.report.ElasticSearchConstants.HeatmapRawDataType;
import com.zoho.abtest.report.ElasticSearchConstants.ScrollmapRawDataType;
import com.zoho.abtest.report.ElasticSearchConstants.VisitorRawDataType;
import com.zoho.abtest.sessionrecording.SessionElasticDocDetails;
import com.zoho.abtest.utility.ApplicationProperty;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUtil;

public class ElasticSearchUtil {
  
	private static final Logger LOGGER = Logger.getLogger(ElasticSearchUtil.class.getName());
	
	private static final String ELASTIC_SEARCH_HOST =ApplicationProperty.getString("com.abtest.elasticsearch.host"); //NO I18N
	
	private static final Integer ELASTIC_SEARCH_PORT = Integer.parseInt(ApplicationProperty.getString("com.abtest.elasticsearch.port")); // No I18N
	
	private static final String ELASTIC_SEARCH_URLS =ApplicationProperty.getString("com.abtest.elasticsearch.urls"); //NO I18N
	
	private static final String ELASTIC_SEARCH_URLS_SECONDARY =ApplicationProperty.getString("com.abtest.elasticsearch.urls.secondary"); //NO I18N
	
	private static final Boolean IS_DEV_MODE = Boolean.parseBoolean(ApplicationProperty.getString("com.abtest.devmode").trim());// No I18N
	
	public static final boolean IS_PRODUCTION_MODE = Boolean.parseBoolean(ApplicationProperty.getString("com.abtest.productionmode").trim()); // No I18N

	public static final boolean REPLICATE_ON_SECONDARY = IS_PRODUCTION_MODE && Boolean.parseBoolean(ApplicationProperty.getString("com.abtest.elastic.do_secondary_replication").trim()); //NO I18N
	
	private static String localHostName = "";
	
	private static TransportClient transportClient;
	
	private static TransportClient transportClientSecondary;
	
	private static final String CLUSTER_NAME = ApplicationProperty.getString("com.abtest.elasticsearch.clustername"); //No I18N
	
	private static final String CLUSTER_NAME_SECONDARY = ApplicationProperty.getString("com.abtest.elasticsearch.clustername.secondary"); //No I18N
	
	private static String getIndexModified(String indexName) {
		try {
			localHostName = InetAddress.getLocalHost().getHostName();
			if (IS_DEV_MODE) {
				indexName = localHostName +"__"+ indexName; //No I18N
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,"Exception occurred",e);
		}
		return indexName;
	}
	
	private static String getIndexOriginal(String indexName)
	{
		try {
			if (IS_DEV_MODE) {
				indexName = indexName.split("__")[1];
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,"Exception occurred",e);
		}
		return indexName;
	}
	
	private static TransportClient getTransportClient() throws UnknownHostException {
		if(transportClient==null) {
			synchronized (ElasticSearchUtil.class) {
				if(transportClient==null) {
					LOGGER.log(Level.INFO,"Transport client instance creation started");
					Settings settings = Settings.builder().put("cluster.name", CLUSTER_NAME).put("client.transport.sniff", true).build();
					transportClient = new PreBuiltTransportClient(settings);
					String[] esUrls = ELASTIC_SEARCH_URLS.split(",");
					for(String esUrl:esUrls)
					{
						if(StringUtils.isNotEmpty(esUrl))
						{
							String[] esUrlParts = esUrl.split(":");
							transportClient = transportClient.addTransportAddress(new InetSocketTransportAddress(InetAddress.getByName(esUrlParts[0]), Integer.parseInt(esUrlParts[1])));
						}
					}
					LOGGER.log(Level.INFO,"Transport client instance creation completed");
				}
			}
		}
		return transportClient;
	}
	
	private static TransportClient getTransportClientSecondary() throws UnknownHostException {
		if(transportClientSecondary==null) {
			synchronized (ElasticSearchUtil.class) {
				if(transportClientSecondary==null) {
					LOGGER.log(Level.INFO,"Secondary Transport client instance creation started");
					Settings settings = Settings.builder().put("cluster.name", CLUSTER_NAME_SECONDARY).put("client.transport.sniff", true).build();
					transportClientSecondary = new PreBuiltTransportClient(settings);
					String[] esUrls = ELASTIC_SEARCH_URLS_SECONDARY.split(",");
					for(String esUrl:esUrls)
					{
						if(StringUtils.isNotEmpty(esUrl))
						{
							String[] esUrlParts = esUrl.split(":");
							transportClientSecondary = transportClientSecondary.addTransportAddress(new InetSocketTransportAddress(InetAddress.getByName(esUrlParts[0]), Integer.parseInt(esUrlParts[1])));
						}
					}
					LOGGER.log(Level.INFO,"Secondary Transport client instance creation completed");
				}
			}
		}
		return transportClientSecondary;
	}
	
	/*
	public static IndexResponse createIndex(String indexName, String type, String id, String jsonData) throws Exception {
		indexName = getIndexModified(indexName);
		IndexResponse response = getTransportClient().prepareIndex(indexName, type, id).setSource(jsonData).get();
		LOGGER.log(Level.INFO, "Elastic response {0}", response);
		return response;
	}
	*/
	
	public static IndexResponse createIndex(String indexName, String type, String jsonData) throws Exception {
		IndexResponse response = null;
		try
		{
			String indexNameMod = getIndexModified(indexName);
			response = getTransportClient().prepareIndex(indexNameMod, type).setSource(jsonData).get();
			LOGGER.log(Level.INFO, "Elastic response in createIndex {0}", response);
			
			//In secondary cluster
			if(REPLICATE_ON_SECONDARY && response != null && StringUtils.isNotEmpty(response.getId()))
			{
				String docId = response.getId();
				createIndexInSecondary(indexNameMod, type, jsonData,docId);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred while indexing in primary",ex);
			//If failed make an entry in postgres Failed table, to process later
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(ElasticSearchIndexConstants.INDEX_NAME, indexName);
			hs.put(ElasticSearchIndexConstants.TYPE, type);
			hs.put(ElasticSearchIndexConstants.JSON_STRING, jsonData);
			hs.put(ElasticSearchIndexConstants.OPERATION_TYPE, ESOpertaionType.CREATE.getOperationType().toString());
			hs.put(ElasticSearchIndexConstants.EXCEPTION_MESSAGE, ex.getMessage());
			doDataBackUpForFailedEntry(hs);
		}
		return response;
	}
	
//	public static IndexResponse createIndex(String indexName, String type, String id, String jsonData) throws Exception {
//		IndexResponse response = null;
//		try
//		{
//			String indexNameMod = getIndexModified(indexName);
//			response = getTransportClient().prepareIndex(indexNameMod, type, id).setSource(jsonData).get();
//			LOGGER.log(Level.INFO, "Elastic response in createIndex {0}", response);
//			
//			//In secondary cluster
//			if(REPLICATE_ON_SECONDARY && response != null && StringUtils.isNotEmpty(response.getId()))
//			{
//				String docId = response.getId();
//				createIndexInSecondary(indexNameMod, type, jsonData,docId);
//			}
//		}
//		catch(Exception ex)
//		{
//			LOGGER.log(Level.SEVERE,"Exception occurred while indexing in primary",ex);
//			//If failed make an entry in postgres Failed table, to process later
//			HashMap<String, String> hs = new HashMap<String, String>();
//			hs.put(ElasticSearchIndexConstants.INDEX_NAME, indexName);
//			hs.put(ElasticSearchIndexConstants.TYPE, type);
//			hs.put(ElasticSearchIndexConstants.JSON_STRING, jsonData);
//			hs.put(ElasticSearchIndexConstants.OPERATION_TYPE, ESOpertaionType.CREATE.getOperationType().toString());
//			hs.put(ElasticSearchIndexConstants.EXCEPTION_MESSAGE, ex.getMessage());
//			doDataBackUpForFailedEntry(hs);
//		}
//		return response;
//	}
	
	public static void bulkInsertDocuments(String indexName, String type, ArrayList<JSONObject> jsonDatas) throws Exception {
		
		bulkInsertDocuments(getTransportClient(), ESOpertaionType.CREATE, indexName, type, jsonDatas);
		
		//In secondary cluster
		if(REPLICATE_ON_SECONDARY)
		{
			bulkInsertDocuments(getTransportClientSecondary(), ESOpertaionType.CREATE_BACKUP, indexName, type, jsonDatas);
		}
	}
	
	public static void bulkInsertDocumentsWithIds(String indexName, String type, HashMap<String, JSONObject> jsonDatas) throws Exception {
		
		bulkInsertDocumentsWithIds(getTransportClient(), ESOpertaionType.CREATE, indexName, type, jsonDatas);
		
		//In secondary cluster
		if(REPLICATE_ON_SECONDARY)
		{
			bulkInsertDocumentsWithIds(getTransportClientSecondary(), ESOpertaionType.CREATE_BACKUP, indexName, type, jsonDatas);
		}
	}
	
	public static void bulkInsertDocuments(TransportClient client, ESOpertaionType opType,String indexName, String type, ArrayList<JSONObject> jsonDatas) throws Exception {
		try {
			String indexNameMod = getIndexModified(indexName);
			BulkRequestBuilder bulkRequest = client.prepareBulk();
			for(JSONObject jsonData: jsonDatas) {		
				bulkRequest.add(client.prepareIndex(indexNameMod, type).setSource(jsonData.toString()));
			}
			BulkResponse bulkResponse = bulkRequest.execute().get();
			for(int i = 0; i < bulkResponse.getItems().length; i++) {
				BulkItemResponse itemResponse = bulkResponse.getItems()[i];
				if(itemResponse.isFailed()) {
					LOGGER.log(Level.SEVERE,"Exception occurred while trying insert in secondary cluster: "+itemResponse.getFailureMessage());
					LOGGER.log(Level.SEVERE,"Exception index {0} type {1} ",new String[]{indexName,type});
					HashMap<String, String> hs = new HashMap<String, String>();
					hs.put(ElasticSearchIndexConstants.INDEX_NAME, indexName);
					hs.put(ElasticSearchIndexConstants.TYPE, type);
					
					//CRUFT: Believeing that the response is same as order of the docs given to insert
					hs.put(ElasticSearchIndexConstants.JSON_STRING, jsonDatas.get(i).toString());
					
					hs.put(ElasticSearchIndexConstants.OPERATION_TYPE, opType.getOperationType().toString());
					hs.put(ElasticSearchIndexConstants.EXCEPTION_MESSAGE, itemResponse.getFailureMessage());
					doDataBackUpForFailedEntry(hs);
				}
			}
			
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,"Exception occurred while indexing in primary",e);
			//If failed make an entry in postgres Failed table, to process later
			for(JSONObject jsonData:  jsonDatas) {				
				HashMap<String, String> hs = new HashMap<String, String>();
				hs.put(ElasticSearchIndexConstants.INDEX_NAME, indexName);
				hs.put(ElasticSearchIndexConstants.TYPE, type);
				hs.put(ElasticSearchIndexConstants.JSON_STRING, jsonData.toString());
				hs.put(ElasticSearchIndexConstants.OPERATION_TYPE, opType.getOperationType().toString());
				hs.put(ElasticSearchIndexConstants.EXCEPTION_MESSAGE, e.getMessage());
				doDataBackUpForFailedEntry(hs);
			}
		}
	}
	
	public static void bulkInsertDocumentsWithIds(TransportClient client, ESOpertaionType opType,String indexName, String type, HashMap<String, JSONObject> jsonDatas) throws Exception {
		try {
			String indexNameMod = getIndexModified(indexName);
			
			LOGGER.log(Level.INFO, "IndexModified::"+indexNameMod);
			
			BulkRequestBuilder bulkRequest = client.prepareBulk();
			LOGGER.log(Level.INFO, "Adding Docs::"+jsonDatas);
			for(String id: jsonDatas.keySet()) {	
				JSONObject jsonData = jsonDatas.get(id);
				LOGGER.log(Level.INFO, "DocID::"+id+"::Document::"+jsonData);
				bulkRequest.add(client.prepareIndex(indexNameMod, type, id).setSource(jsonData.toString()));
			}
			LOGGER.log(Level.INFO, "BulkInsertRequest::"+bulkRequest);
			BulkResponse bulkResponse = bulkRequest.execute().get();
			LOGGER.log(Level.INFO, "BulkInsertRespose::"+bulkResponse);
			for(int i = 0; i < bulkResponse.getItems().length; i++) {
				BulkItemResponse itemResponse = bulkResponse.getItems()[i];
				if(itemResponse.isFailed()) {
					LOGGER.log(Level.SEVERE,"Exception occurred while trying insert in secondary cluster: "+itemResponse.getFailureMessage());
					LOGGER.log(Level.SEVERE,"Exception index {0} type {1} ",new String[]{indexName,type});
					HashMap<String, String> hs = new HashMap<String, String>();
					hs.put(ElasticSearchIndexConstants.INDEX_NAME, indexName);
					hs.put(ElasticSearchIndexConstants.TYPE, type);
					String id = itemResponse.getId();
					
					JSONObject jsonData = jsonDatas.get(i);
					jsonData.put("_id", id);
					
					//CRUFT: Believeing that the response is same as order of the docs given to insert
					hs.put(ElasticSearchIndexConstants.JSON_STRING, jsonData.toString());
					
					hs.put(ElasticSearchIndexConstants.OPERATION_TYPE, opType.getOperationType().toString());
					hs.put(ElasticSearchIndexConstants.EXCEPTION_MESSAGE, itemResponse.getFailureMessage());
					doDataBackUpForFailedEntry(hs);
				}
			}
			
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,"Exception occurred while indexing in primary",e);
			//If failed make an entry in postgres Failed table, to process later
			for(String id: jsonDatas.keySet()) {	
				JSONObject jsonData = jsonDatas.get(id);
				jsonData.put("_id", id);
				HashMap<String, String> hs = new HashMap<String, String>();
				hs.put(ElasticSearchIndexConstants.INDEX_NAME, indexName);
				hs.put(ElasticSearchIndexConstants.TYPE, type);
				hs.put(ElasticSearchIndexConstants.JSON_STRING, jsonData.toString());
				hs.put(ElasticSearchIndexConstants.OPERATION_TYPE, opType.getOperationType().toString());
				hs.put(ElasticSearchIndexConstants.EXCEPTION_MESSAGE, e.getMessage());
				doDataBackUpForFailedEntry(hs);
			}
		}
	}
	
	public static void createIndexInSecondary(String indexName, String type, String jsonData, String docId) throws Exception 
	{
		try
		{
			IndexResponse responseSec = getTransportClientSecondary().prepareIndex(indexName, type, docId).setSource(jsonData).get();
			LOGGER.log(Level.INFO, "Elastic response in createIndexInSecondary {0}", responseSec);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred while trying insert in secondary cluster",ex);
			LOGGER.log(Level.SEVERE,"Exception index {0} type {1} docid {2} ",new String[]{indexName,type,docId});
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(ElasticSearchIndexConstants.INDEX_NAME, indexName);
			hs.put(ElasticSearchIndexConstants.TYPE, type);
			hs.put(ElasticSearchIndexConstants.JSON_STRING, jsonData);
			hs.put(ElasticSearchIndexConstants.DOC_ID, docId);
			hs.put(ElasticSearchIndexConstants.OPERATION_TYPE, ESOpertaionType.CREATE_BACKUP.getOperationType().toString());
			hs.put(ElasticSearchIndexConstants.EXCEPTION_MESSAGE, ex.getMessage());
			doDataBackUpForFailedEntry(hs);
		}
	}
	
	public static long deleteDocsByCriteria(String indexName, String type,String columnName, Object value) throws UnknownHostException {
		Long deleteCount = null;
		BulkByScrollResponse response =
			    DeleteByQueryAction.INSTANCE.newRequestBuilder(getTransportClient())
			        .filter(QueryBuilders.matchQuery(columnName, type))
			        .filter(QueryBuilders.matchQuery(columnName, value))
			        .source(indexName)
			        .get();                                             
		deleteCount = response.getDeleted();
		
		//In secondary cluster
		if(REPLICATE_ON_SECONDARY && deleteCount != null)
		{
			try
			{
				BulkByScrollResponse responseSec =
					    DeleteByQueryAction.INSTANCE.newRequestBuilder(getTransportClientSecondary())
					        .filter(QueryBuilders.matchQuery(columnName, type))
					        .filter(QueryBuilders.matchQuery(columnName, value))
					        .source(indexName)
					        .get(); 
			}
			catch(Exception ex)
			{
				LOGGER.log(Level.SEVERE,"Exception occurred while deleteDocsByCriteria",ex);
			}
		}
		return deleteCount;  
	}
	
	public static void deleteDocById(String indexName, String type,String id) throws Exception {
			String indexNameMod = getIndexModified(indexName);
			DeleteResponse response = getTransportClient().prepareDelete(indexNameMod, type, id).setRefreshPolicy("true").get();
			LOGGER.log(Level.INFO, "Elastic response in createIndex {0}", response);
			
			//In secondary cluster
			if(REPLICATE_ON_SECONDARY && response != null && StringUtils.isNotEmpty(response.getId()))
			{
				DeleteResponse responseSec = getTransportClientSecondary().prepareDelete(indexNameMod, type, id).get();
			}
	}
	
	/*
	public static void updateMapping(String indexName, String type, String mapping) throws UnknownHostException, InterruptedException, ExecutionException{
		
		PutMappingResponse putMappingResponse = getTransportClient().admin().indices()
                .preparePutMapping(indexName)
                .setSource(mapping)
                .setType(type).execute().get();
	}
	
	public static void createMapping(String indexName, String type, String mapping) throws UnknownHostException, InterruptedException, ExecutionException{
		indexName = getIndexModified(indexName);
		
		final IndicesExistsResponse res = getTransportClient().admin().indices().prepareExists(indexName).execute().actionGet();
        if (res.isExists()) {
        	updateMapping(indexName,type,mapping);
        }else{
        	getTransportClient().admin().indices().prepareCreate(indexName).addMapping(type, mapping).execute().get();
        }
		
	}
	*/
	
	public static UpdateResponse upsertIndex(String indexName, String type, String id, String jsonData,Script updateScript, Integer noOfRetries) throws Exception {
		UpdateResponse response = null;
		try
		{
			String indexNameMod = getIndexModified(indexName);
			UpdateRequest updateRequest = new UpdateRequest(indexNameMod, type, id);
			updateRequest.script(updateScript);
			updateRequest.upsert(jsonData);
			
			if(noOfRetries!=null) {	
				//Refer: github.com/elastic/elasticsearch/issues/13619
				updateRequest.retryOnConflict(noOfRetries);
			}
			response = getTransportClient().update(updateRequest).get();
			LOGGER.log(Level.INFO, "Elastic response in upsertIndex {0}", response);
			
			//In secondary cluster
			if(REPLICATE_ON_SECONDARY)
			{
				upsertIndexInSecondary(indexName, type, id, jsonData, updateScript, updateRequest);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred while upsert in primary",ex);
			//If failed make an entry in postgres Failed table, to process later
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(ElasticSearchIndexConstants.INDEX_NAME, indexName);
			hs.put(ElasticSearchIndexConstants.TYPE, type);
			hs.put(ElasticSearchIndexConstants.JSON_STRING, jsonData);
			hs.put(ElasticSearchIndexConstants.DOC_ID, id);
			hs.put(ElasticSearchIndexConstants.OPERATION_TYPE, ESOpertaionType.UPDATE.getOperationType().toString());
			hs.put(ElasticSearchIndexConstants.EXCEPTION_MESSAGE, ex.getMessage());
			doDataBackUpForFailedEntry(hs);
		}
		return response;
	}
	
	//Used for Form analytics
	public static UpdateResponse upsertIndex(String indexName, String type, String id, String jsonData) throws Exception {
		UpdateResponse response = null;
		try
		{
			String indexNameMod = getIndexModified(indexName);
			UpdateRequest updateRequest = new UpdateRequest(indexNameMod, type, id);
			updateRequest.doc(jsonData);
			updateRequest.upsert(jsonData);
			response = getTransportClient().update(updateRequest).get();
			LOGGER.log(Level.INFO, "Elastic response in form upsertIndex {0}", response);
			
			//In secondary cluster
			if(REPLICATE_ON_SECONDARY)
			{
				upsertIndexInSecondary(indexName, type, id, jsonData, updateRequest);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred while form upsert in primary",ex);
			//If failed make an entry in postgres Failed table, to process later
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(ElasticSearchIndexConstants.INDEX_NAME, indexName);
			hs.put(ElasticSearchIndexConstants.TYPE, type);
			hs.put(ElasticSearchIndexConstants.JSON_STRING, jsonData);
			hs.put(ElasticSearchIndexConstants.DOC_ID, id);
			hs.put(ElasticSearchIndexConstants.OPERATION_TYPE, ESOpertaionType.UPDATE.getOperationType().toString());
			hs.put(ElasticSearchIndexConstants.EXCEPTION_MESSAGE, ex.getMessage());
			doDataBackUpForFailedEntry(hs);
		}
		return response;
	}
	
	//Used for Form analytics
	public static void upsertIndexInSecondary(String indexName, String type, String id, String jsonData, UpdateRequest updateRequest) throws Exception 
	{
		try
		{
			UpdateResponse responseSec = getTransportClientSecondary().update(updateRequest).get();
			LOGGER.log(Level.INFO, "Elastic response in form upsertIndexInSecondary {0}", responseSec);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred while trying form upsert in secondary cluster",ex);
			LOGGER.log(Level.SEVERE,"Exception index {0} type {1} docid {2} ",new String[]{indexName,type,id});
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(ElasticSearchIndexConstants.INDEX_NAME, indexName);
			hs.put(ElasticSearchIndexConstants.TYPE, type);
			hs.put(ElasticSearchIndexConstants.JSON_STRING, jsonData);
			hs.put(ElasticSearchIndexConstants.DOC_ID, id);
			hs.put(ElasticSearchIndexConstants.OPERATION_TYPE, ESOpertaionType.UPDATE_BACKUP.getOperationType().toString());
			hs.put(ElasticSearchIndexConstants.EXCEPTION_MESSAGE, ex.getMessage());
			doDataBackUpForFailedEntry(hs);
		}
	}
	
	public static UpdateResponse upsertIndex(String indexName, String type, String id, String jsonData,Script updateScript) throws Exception {
		return upsertIndex(indexName, type, id, jsonData, updateScript, null);
	}
	
	public static void upsertIndexInSecondary(String indexName, String type, String id, String jsonData,Script updateScript, UpdateRequest updateRequest) throws Exception 
	{
		try
		{
			UpdateResponse responseSec = getTransportClientSecondary().update(updateRequest).get();
			LOGGER.log(Level.INFO, "Elastic response in upsertIndexInSecondary {0}", responseSec);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred while trying upsert in secondary cluster",ex);
			LOGGER.log(Level.SEVERE,"Exception index {0} type {1} docid {2} ",new String[]{indexName,type,id});
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(ElasticSearchIndexConstants.INDEX_NAME, indexName);
			hs.put(ElasticSearchIndexConstants.TYPE, type);
			hs.put(ElasticSearchIndexConstants.JSON_STRING, jsonData);
			hs.put(ElasticSearchIndexConstants.DOC_ID, id);
			hs.put(ElasticSearchIndexConstants.OPERATION_TYPE, ESOpertaionType.UPDATE_BACKUP.getOperationType().toString());
			hs.put(ElasticSearchIndexConstants.EXCEPTION_MESSAGE, ex.getMessage());
			doDataBackUpForFailedEntry(hs);
		}
	}
	
	public static UpdateResponse updateIndex(String indexName, String type, String id, String jsonData) throws Exception {
		UpdateResponse response = null;
		try
		{
			String indexNameMod = getIndexModified(indexName);
			UpdateRequest updateRequest = new UpdateRequest();
			updateRequest.index(indexNameMod);
			updateRequest.type(type);
			updateRequest.id(id);
			updateRequest.doc(jsonData);
			response = getTransportClient().update(updateRequest).get();
			LOGGER.log(Level.INFO, "Elastic response in updateIndex {0}", response);
			
			//In secondary cluster
			if(REPLICATE_ON_SECONDARY)
			{
				updateIndexInSecondary(indexNameMod, type, id, jsonData, updateRequest);
			}
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred while update in primary",ex);
			//If failed make an entry in postgres Failed table, to process later
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(ElasticSearchIndexConstants.INDEX_NAME, indexName);
			hs.put(ElasticSearchIndexConstants.TYPE, type);
			hs.put(ElasticSearchIndexConstants.JSON_STRING, jsonData);
			hs.put(ElasticSearchIndexConstants.DOC_ID, id);
			hs.put(ElasticSearchIndexConstants.OPERATION_TYPE, ESOpertaionType.UPDATE.getOperationType().toString());
			hs.put(ElasticSearchIndexConstants.EXCEPTION_MESSAGE, ex.getMessage());
			doDataBackUpForFailedEntry(hs);
		}
		return response;
	}
	
	public static void updateIndexInSecondary(String indexName, String type, String id, String jsonData,UpdateRequest updateRequest) throws Exception 
	{
		try
		{
			UpdateResponse responseSec = getTransportClientSecondary().update(updateRequest).get();
			LOGGER.log(Level.INFO, "Elastic response in updateIndexInSecondary {0}", responseSec);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred while trying update in secondary cluster",ex);
			LOGGER.log(Level.SEVERE,"Exception index {0} type {1} docid {2} ",new String[]{indexName,type,id});
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(ElasticSearchIndexConstants.INDEX_NAME, indexName);
			hs.put(ElasticSearchIndexConstants.TYPE, type);
			hs.put(ElasticSearchIndexConstants.JSON_STRING, jsonData);
			hs.put(ElasticSearchIndexConstants.DOC_ID, id);
			hs.put(ElasticSearchIndexConstants.OPERATION_TYPE, ESOpertaionType.UPDATE_BACKUP.getOperationType().toString());
			hs.put(ElasticSearchIndexConstants.EXCEPTION_MESSAGE, ex.getMessage());
			doDataBackUpForFailedEntry(hs);
		}
	}
	
	/*
	public static SearchResponse getAllData(String indexName, String type) throws UnknownHostException, InterruptedException, ExecutionException {
		indexName = getIndexModified(indexName);
		SearchResponse response = getTransportClient().prepareSearch().setIndices(indexName).setTypes(type).execute().get();
		LOGGER.log(Level.INFO, "Elastic response received for - "+indexName);
		return response;
	}
	*/
	
	public static SearchResponse getData(String indexName, String type, String source) throws InterruptedException, ExecutionException, UnsupportedEncodingException, IOException, JSONException {
		indexName = getIndexModified(indexName);
		
		SearchTemplateRequestBuilder builder = new SearchTemplateRequestBuilder(getTransportClient());
		SearchResponse response = builder.setScript(source)
				.setScriptType(ScriptType.INLINE)
				.setScriptParams(new HashMap<String, Object>())                  
		        .setRequest(new SearchRequest(indexName).types(new String[]{type}))                 
		        .get()       
		        .getResponse(); 
		LOGGER.log(Level.INFO, "Elastic response received for - "+indexName);
		
		return response;
	}
	
	public static GetResponse getDataById(String indexName, String type, String id, String[] includes, String[] excludes) throws InterruptedException, ExecutionException, UnsupportedEncodingException, IOException, JSONException {
		indexName = getIndexModified(indexName);
		
		GetResponse response = getTransportClient().prepareGet(indexName, type, id)
				.setFetchSource(includes, excludes)
				.get();
		LOGGER.log(Level.INFO, "Elastic response received for - "+indexName);
		
		return response;
	}
	
	public static SearchResponse getData(String indexName, String type, Integer size, QueryBuilder query ,AggregationBuilder aggregation ) throws InterruptedException, ExecutionException, UnsupportedEncodingException, IOException, JSONException {
		indexName = getIndexModified(indexName);
		
		SearchResponse response= getTransportClient().
									prepareSearch(indexName).
										setTypes(type).
											setSize(size).
												setQuery(query).
													addAggregation(aggregation).
														execute().actionGet();
		
		LOGGER.log(Level.INFO, "Elastic response received for - "+indexName);
		
		return response;
	}
	
	public static SearchResponse getData(String indexName, String type, Integer size, QueryBuilder query ,ArrayList<AggregationBuilder> aggs) throws InterruptedException, ExecutionException, UnsupportedEncodingException, IOException, JSONException {
		indexName = getIndexModified(indexName);
		
		SearchRequestBuilder srb = getTransportClient().
		prepareSearch(indexName).
			setTypes(type).
				setSize(size).
					setQuery(query);
		
		int asize = aggs.size();
		for(int i=0; i<asize; i++) {
			srb.addAggregation(aggs.get(i));
		}
		
		SearchResponse response= srb.execute().actionGet();
		
		LOGGER.log(Level.INFO, "Elastic response received for - "+indexName);
		
		return response;
	}
	
	public static SearchResponse getData(String indexName, String type, QueryBuilder query ) throws InterruptedException, ExecutionException, UnsupportedEncodingException, IOException, JSONException {
		
		SearchResponse response= getData(indexName, type, query, null, null, null, null, null);
        LOGGER.log(Level.INFO, "Elastic response received for - "+indexName);
        return response;
		
    }
	
	public static SearchResponse getData(String indexName, String type, QueryBuilder query, String[] includeFields, String[] excludeFields, Integer size, Integer from,SortBuilder sort) throws InterruptedException, ExecutionException, UnsupportedEncodingException, IOException, JSONException {
		
        LOGGER.log(Level.INFO, "Elastic response received for - "+indexName);
        return getData(indexName, type, query, includeFields, excludeFields, size, from, sort, null);
    }
	
	public static SearchResponse getData(String indexName, String type,
			QueryBuilder query, String[] includeFields, String[] excludeFields,
			Integer size, Integer from, SortBuilder sort, HashMap<String, Script> scriptFields) throws InterruptedException,
			ExecutionException, UnsupportedEncodingException, IOException,
			JSONException {
		indexName = getIndexModified(indexName);
		
		SearchRequestBuilder queryBuilder= getTransportClient().
												prepareSearch(indexName).
													setTypes(type).
															setQuery(query);
		if(size != null)
		{
			queryBuilder.setSize(size);
		}
		
		if(includeFields != null || excludeFields != null)
		{
			queryBuilder.setFetchSource(includeFields, excludeFields);
		}
		

		if(scriptFields!=null) {
			for(String fieldName: scriptFields.keySet()) {
				queryBuilder.addScriptField(fieldName, scriptFields.get(fieldName));
			}
		}
		
		if(sort!=null) {
			queryBuilder.addSort(sort);
		}
		
		if(from!=null) {
			queryBuilder.setFrom(from);
		}
		
		SearchResponse response = queryBuilder.execute().actionGet();
		
        LOGGER.log(Level.INFO, "Elastic response received for - "+indexName);
        
        return response;
    }
    
	public static SearchResponse getData(String indexName, String type, Integer size, QueryBuilder query , List<AggregationBuilder> aggregation ) throws InterruptedException, ExecutionException, UnsupportedEncodingException, IOException, JSONException {
		indexName = getIndexModified(indexName);
		
		SearchRequestBuilder request = getTransportClient().
									prepareSearch(indexName).
										setTypes(type).
											setSize(size).
												setQuery(query);
		
			for(int i=0;i<aggregation.size();i++){
				request.addAggregation(aggregation.get(i));
			}
		
			SearchResponse response = request.execute().actionGet();
		LOGGER.log(Level.INFO, "Elastic response received for - "+indexName);
		
		return response;
	}
	
	//Will be accessed from Admin console
	public static SearchResponse getData(String index, String[] types, Integer size, QueryBuilder query ,AggregationBuilder aggregation ) throws InterruptedException, ExecutionException, UnsupportedEncodingException, IOException, JSONException {
		
		/*
		for(int i=0;i<indexes.length;i++)
		{
			indexes[i] = getIndexModified(indexes[i]);
		}*/
		index = getIndexModified(index);
		SearchRequestBuilder searchBuilder = getTransportClient().prepareSearch(index).setTypes(types).setSize(size);
		if(query != null)
		{
			searchBuilder = searchBuilder.setQuery(query);
		}
		SearchResponse response = searchBuilder.addAggregation(aggregation).execute().actionGet();
		return response;
	}
	
	public static Long getCount(String indexName, String type, String source) throws InterruptedException, ExecutionException, UnsupportedEncodingException, IOException {
		indexName = getIndexModified(indexName);
		SearchTemplateRequestBuilder builder = new SearchTemplateRequestBuilder(getTransportClient());
		SearchResponse response = builder.setScript(source)
				.setScriptType(ScriptType.INLINE)
				.setScriptParams(new HashMap<String, Object>())                  
			    .setRequest(new SearchRequest(indexName).types(new String[]{type}))                 
			    .get()       
			    .getResponse(); 
		LOGGER.log(Level.INFO, "Elastic response {0}", response);
		return response.getHits().getTotalHits();
	}
	
	public static Long getCount(String indexName, String type, QueryBuilder source) throws InterruptedException, ExecutionException, UnsupportedEncodingException, IOException {
		indexName = getIndexModified(indexName);
		SearchResponse response = getTransportClient().prepareSearch(indexName).setTypes(type)
				.setQuery(source)
				.setSize(0)
			    .get();
		LOGGER.log(Level.INFO, "Elastic response {0}", response);
		return response.getHits().getTotalHits();
	}
	
	public static SearchResponse getAggregation(String indexName, String type, AggregationBuilder builder) throws UnknownHostException, InterruptedException, ExecutionException {
		indexName = getIndexModified(indexName);
		SearchResponse response = getTransportClient().prepareSearch().addAggregation(builder).setIndices(indexName).setTypes(type).execute().get();
		LOGGER.log(Level.INFO,  "Elastic response received for - "+indexName);
		return response;
	}
	
	public static CreateIndexResponse createIndex(String indexName) throws Exception 
	{
		CreateIndexResponse response = null;
		try
		{
			indexName = getIndexModified(indexName);
			JSONObject visitorTypeJson = getVisitorDataFieldsType();
			JSONObject goalTypeJson = getGoalDataFieldsType();
			
			JSONObject heatmapTypeJson = getHeatmapDataFieldsType();
			JSONObject scrollmapTypeJson = getScrollmapDataFieldsType();
			JSONObject funnelmapTypeJson = getFunnelDataFieldsType();
			JSONObject formAnalyticsTypeJson=getFormAnalyticsDataFieldsType();
			JSONObject formAnalyticsFieldTypeJson=getFormAnalyticsFieldsType();
			JSONObject adwordsTypeJson = getAdwordsDataFieldsType(); 
		//	JSONObject identityTypeJson = getIdentityDataType();
			
			JSONObject sessionmapTypeJson = SessionElasticDocDetails.getSessionRawDataMapping();
			
			JSONObject sessionEventStreamMapTypeJson = SessionElasticDocDetails.getSessionEventStreamMapping();
			
			JSONObject sessionUserEventMapTypeJson = SessionElasticDocDetails.getSessionUserEventDataMapping();
			
			JSONObject sessionPageResourceMapTypeJson = SessionElasticDocDetails.getSessionPageResourceDataMapping();
			
			
			final CreateIndexRequestBuilder createIndexRequestBuilder = getTransportClient().admin().indices().prepareCreate(indexName);
			createIndexRequestBuilder.setSettings(Settings.builder().put("index.number_of_shards",ElasticSearchIndexConstants.SHARD_COUNT).put("index.number_of_replicas", ElasticSearchIndexConstants.REPLICA_COUNT));
			createIndexRequestBuilder.addMapping(ElasticSearchConstants.VISITOR_RAW_TYPE, visitorTypeJson.toString());
			createIndexRequestBuilder.addMapping(ElasticSearchConstants.GOAL_RAW_TYPE, goalTypeJson.toString());
			createIndexRequestBuilder.addMapping(ElasticSearchConstants.HEATMAP_RAW_TYPE, heatmapTypeJson.toString());
			createIndexRequestBuilder.addMapping(ElasticSearchConstants.SCROLLMAP_RAW_TYPE, scrollmapTypeJson.toString());
			createIndexRequestBuilder.addMapping(ElasticSearchConstants.FUNNEL_RAW_TYPE, funnelmapTypeJson.toString());

			createIndexRequestBuilder.addMapping(ElasticSearchConstants.SESSION_EVENT_STREAM_DATA_TYPE, sessionEventStreamMapTypeJson.toString());
			createIndexRequestBuilder.addMapping(ElasticSearchConstants.SESSION_RAW_DATA_TYPE, sessionmapTypeJson.toString());
			createIndexRequestBuilder.addMapping(ElasticSearchConstants.SESSION_USER_EVENT_DATA_TYPE, sessionUserEventMapTypeJson.toString());
			createIndexRequestBuilder.addMapping(ElasticSearchConstants.SESSION_PAGE_RESOURCE_TYPE, sessionPageResourceMapTypeJson.toString());

			createIndexRequestBuilder.addMapping(ElasticSearchConstants.FORM_ANALYTICS_RAW_TYPE, formAnalyticsTypeJson.toString());
			createIndexRequestBuilder.addMapping(ElasticSearchConstants.FORM_ANALYTICS_FIELDS_RAW_TYPE, formAnalyticsFieldTypeJson.toString());
			createIndexRequestBuilder.addMapping(ElasticSearchConstants.ADWORDS_RAW_TYPE, adwordsTypeJson.toString());
		//	createIndexRequestBuilder.addMapping(ElasticSearchConstants.IDENTITY_RAW_DATA_TYPE, identityTypeJson.toString());

			
			response = createIndexRequestBuilder.execute().actionGet();
			LOGGER.log(Level.INFO, "Elastic response {0}", response);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			throw ex;
		}
		return response;
	}
	
	public static void updateScriptMaxCompilation(int value) throws UnknownHostException {
		Settings settings = Settings.builder().put("script.max_compilations_per_minute", value).build();
		getTransportClient().admin().cluster().prepareUpdateSettings().setTransientSettings(settings).execute();
		
		//In secondary cluster
		if(REPLICATE_ON_SECONDARY)
		{
			try
			{
				getTransportClientSecondary().admin().cluster().prepareUpdateSettings().setTransientSettings(settings).execute();
				getTransportClient().admin().cluster().prepareUpdateSettings().setPersistentSettings(settings).execute();
			}
			catch(Exception ex)
			{
				LOGGER.log(Level.SEVERE,"Exception occurred while updateScriptMaxCompilation",ex);
			}
		}
	}
	
	public static boolean updateIndexTypeMapping(String indexPattern, String type, String mappingObjectJson)
	{
		boolean isAcknowledged = false;
		try
		{
			indexPattern = ElasticSearchUtil.getIndexModified(indexPattern);
			PutMappingResponse putMappingResponse = getTransportClient().admin().indices().preparePutMapping(indexPattern).setType(type).setSource(mappingObjectJson).execute().actionGet();
			isAcknowledged = putMappingResponse.isAcknowledged();
			LOGGER.log(Level.INFO," updateIndexTypeMapping - "+type+" - Acknowledge status - "+isAcknowledged);
			
			//In secondary cluster
			if(REPLICATE_ON_SECONDARY && isAcknowledged)
			{
				try
				{
					getTransportClientSecondary().admin().indices().preparePutMapping(indexPattern).setType(type).setSource(mappingObjectJson).execute().actionGet();
					LOGGER.log(Level.INFO," updateIndexTypeMapping - completed in secondary ");
				}
				catch(Exception ex)
				{
					LOGGER.log(Level.SEVERE,"Exception occurred while updateIndexTypeMapping",ex);
				}
			}
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.INFO," updateIndexTypeMapping - "+type+" - Acknowledge status - "+isAcknowledged);
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			isAcknowledged = false;
		}
		return isAcknowledged;
	}
	
	//Delete In all index
	public static void deleteData(BoolQueryBuilder boolBuilder) throws Exception
	{
		String indexName1 = ElasticSearchConstants.DEFAULT_INDEX_PREFIX + "*";
		final String indexName = getIndexModified(indexName1);
		LOGGER.log(Level.INFO, "Delete data based on query for all index started ");
		DeleteByQueryRequestBuilder deleteBuilder = new DeleteByQueryRequestBuilder(getTransportClient(), DeleteByQueryAction.INSTANCE);
		deleteBuilder.filter(boolBuilder).source(indexName).execute(new ActionListener<BulkByScrollResponse>() {
			@Override
			public void onFailure(Exception ex) {
				LOGGER.log(Level.SEVERE, "Error occured during Delete data based on query for all index ", ex);
			}

			@Override
			public void onResponse(BulkByScrollResponse response) {
				
				LOGGER.log(Level.INFO, "Delete data based on query for all index completed successfully  :count: " + response.getDeleted());
				
				//In secondary cluster
				if(REPLICATE_ON_SECONDARY)
				{
					try
					{
						DeleteByQueryRequestBuilder deleteBuilderSec = new DeleteByQueryRequestBuilder(getTransportClientSecondary(), DeleteByQueryAction.INSTANCE);
						deleteBuilderSec.filter(boolBuilder).source(indexName).execute();
					}
					catch(Exception ex)
					{
						LOGGER.log(Level.SEVERE,"Exception occurred while Delete data based on query for all index in secondary",ex);
					}
				}
				
			}
		});
		LOGGER.log(Level.INFO, "Delete data based on query for all index completed ");
	}
	
	public static void deleteData(String indexName1, BoolQueryBuilder boolBuilder,String[] type) throws Exception
	{
		final String indexName = getIndexModified(indexName1);
		
		LOGGER.log(Level.INFO, "Delete data based on query started - "+indexName);
		DeleteByQueryRequestBuilder deleteBuilder = new DeleteByQueryRequestBuilder(getTransportClient(), DeleteByQueryAction.INSTANCE);
		
		/*SearchRequestBuilder searchRequestBuilder = deleteBuilder.source().setIndices(indexName);
		if(type.length > 0)
		{
			searchRequestBuilder.setTypes(type);
		}
		searchRequestBuilder.setQuery(boolBuilder).execute().actionGet(); 
		*/
		
		deleteBuilder.filter(boolBuilder).source(indexName).execute(new ActionListener<BulkByScrollResponse>() {

			@Override
			public void onFailure(Exception ex) {
				LOGGER.log(Level.SEVERE, "Error occured during Delete data based on query completed ", ex);
			}

			@Override
			public void onResponse(BulkByScrollResponse response) {
				
				LOGGER.log(Level.INFO, "Delete data based on query completed successfully  :count: " + response.getDeleted());
				
				//In secondary cluster
				if(REPLICATE_ON_SECONDARY)
				{
					try
					{
						DeleteByQueryRequestBuilder deleteBuilderSec = new DeleteByQueryRequestBuilder(getTransportClientSecondary(), DeleteByQueryAction.INSTANCE);
						deleteBuilderSec.filter(boolBuilder).source(indexName).execute();
					}
					catch(Exception ex)
					{
						LOGGER.log(Level.SEVERE,"Exception occurred while Delete data based on query",ex);
					}
				}
				
			}
		});
		LOGGER.log(Level.INFO, "Delete data based on query initiation completed - "+indexName);
	}
	
	/*
	public static DeleteResponse deleteIndex(String indexName, String type, String id) throws Exception {
		indexName = getIndexModified(indexName);
		DeleteResponse response = getTransportClient().prepareDelete(indexName, type, id).get();
		LOGGER.log(Level.INFO, "Elastic response {0}", response);
		return response;
	}
	*/
	
	public static void populateDefaultIndexes() throws Exception
	{
		try
		{
			for(int i = 1; i <= ElasticSearchConstants.DEFAULT_INDEX_COUNT; i++)
			{
				String indexName = ElasticSearchConstants.DEFAULT_INDEX_PREFIX + i;
				createIndex(indexName);
				HashMap<String, String> hs = new HashMap<String, String>();
				hs.put(ElasticSearchIndexConstants.INDEX_NAME, indexName);
				hs.put(ElasticSearchIndexConstants.INDEX_STATUS, new Integer(ClusterHealthStatus.GREEN.value()).toString());
				ESIndexMeta.createESIndexMeta(hs);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			//Suppressing the exception as this issue should not affect user sign up and portal creation
		}
	}
	
	public static void doIndexPortalMapping(String portalName, String zsoidStr)
	{
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		try
		{
			Long zsoid = Long.parseLong(zsoidStr);
			ESIndexPortalMapping.assignIndexToPortal(portalName, zsoid);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			//Suppressing the exception as this issue should not affect user sign up and portal creation
		}
		ZABUtil.setDBSpace(existingDBSpace);
	}
	
	public static void undoIndexPortalMapping(String portalName)
	{
		try
		{
			String existingDBSpace = ZABUtil.getDBSpace();
			ZABUtil.setDBSpace("sharedspace");	//No I18N
			ESIndexPortalMapping.unAssignPortalIndex(portalName);
			ZABUtil.setDBSpace(existingDBSpace);
			LOGGER.log(Level.INFO, "successfully unAssignPortalIndex - "+ portalName);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.INFO, "error in unAssignPortalIndex - "+ portalName);
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			//Suppressing the exception as this issue should not affect portal deletion
		}
	}
	
	public static String getIndexByPortal(String portalName) throws Exception
	{
		String index = null;
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		try
		{
			index = ESIndexPortalMapping.getIndexByPortal(portalName);
			/*if(index == null)
			{
				//This block will run only on localzoho, as such case will happen only for already created dbspaces(like migration)
				try
				{
					ServiceOrg serviceOrg = ZABServiceOrgUtil.getServiceOrgForDomain(portalName);
					//Long zsoid = ZABServiceOrgUtil.getZSOIDFromDomain(portalName);
					if(serviceOrg != null && serviceOrg.isEnabled())
					{
						Long zsoid = serviceOrg.getZSOID();
						index = ESIndexPortalMapping.assignIndexToPortal(portalName,zsoid);
					}
				}
				catch(Exception ex)
				{
					LOGGER.log(Level.SEVERE,"Exception occurred",ex);
					index = ESIndexPortalMapping.getIndexByPortal(portalName);
				}
			}*/
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			ZABUtil.setDBSpace(existingDBSpace);
			throw ex;
		}
		ZABUtil.setDBSpace(existingDBSpace);
		return index;
	}
	
	public static void doDataBackUpForFailedEntry(HashMap<String, String> hs) throws Exception
	{
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		ElasticSearchFailedEntry.createElasticSearchFailedEntry(hs);
		ZABUtil.setDBSpace(existingDBSpace);
	}
	
	public static void pushFailedEntryIntoES(int type) throws Exception
	{
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		if(type == 0)
		{
			LOGGER.log(Level.INFO, "Push into primary started");
			ElasticSearchFailedEntry.processESFailedEntry();
			LOGGER.log(Level.INFO, "Push into primary completed");
			LOGGER.log(Level.INFO, "Push into secondaryalone started");
			ElasticSearchFailedEntry.processESFailedEntryInSecondary();
			LOGGER.log(Level.INFO, "Push into secondaryalone completed");
		}
		else if(type == 1)
		{
			LOGGER.log(Level.INFO, "Push into primary started");
			ElasticSearchFailedEntry.processESFailedEntry();
			LOGGER.log(Level.INFO, "Push into primary completed");
		}
		else if(type == 2)
		{
			LOGGER.log(Level.INFO, "Push into secondaryalone started");
			ElasticSearchFailedEntry.processESFailedEntryInSecondary();
			LOGGER.log(Level.INFO, "Push into secondaryalone completed");
		}
		else if(type == 10)
		{
			LOGGER.log(Level.INFO, "Delete all entries started");
			ElasticSearchFailedEntry.deleteAllESFailedEntries();
			LOGGER.log(Level.INFO, "Delete all entries completed");
		}
		ZABUtil.setDBSpace(existingDBSpace);
	}
	
	public static JSONObject getAdwordsDataFieldsType() throws JSONException{
		
		List<String> nestedAttr = getNestedAttributes();
		AdwordsRawDataType[] adwordsRawDataTypes = AdwordsRawDataType.values();
		JSONObject mapping = new JSONObject();
		JSONObject maping_prop = new JSONObject();
		
		for(AdwordsRawDataType adwordsRawDataType:adwordsRawDataTypes)
		{
			String fieldName = adwordsRawDataType.getFieldName();
			String fieldValue = adwordsRawDataType.getFieldType();
			Boolean isAnalyzed = adwordsRawDataType.getIsAnalyzed();
			JSONObject subjson = new JSONObject();
			subjson.put("type", fieldValue);
			
			if((fieldValue != "object" && fieldValue != "nested") && !isAnalyzed){
				subjson.put("index","not_analyzed");
			}
			if(nestedAttr.contains(fieldName))
			{
				JSONObject nestedPropJson = getNestedProperties();
				subjson.put("properties",nestedPropJson);
			}
			mapping.put(fieldName,subjson);
		}
		maping_prop.put("properties", mapping);
		//JSONArray dynamicTemplateArr = getDynamicTemplatesForDynamicAttributes();
		//maping_prop.put("dynamic_templates", dynamicTemplateArr);
		return maping_prop;
	}
	
	public static JSONObject getHeatmapDataFieldsType() throws JSONException{
		
		List<String> nestedAttr = getNestedAttributes();
		HeatmapRawDataType[] heatmapRawDataTypes = HeatmapRawDataType.values();
		JSONObject mapping = new JSONObject();
		JSONObject maping_prop = new JSONObject();
		
		for(HeatmapRawDataType heatmapRawDataType:heatmapRawDataTypes)
		{
			String fieldName = heatmapRawDataType.getFieldName();
			String fieldValue = heatmapRawDataType.getFieldType();
			Boolean isAnalyzed = heatmapRawDataType.getIsAnalyzed();
			JSONObject subjson = new JSONObject();
			subjson.put("type", fieldValue);
			
			if((fieldValue != "object" && fieldValue != "nested") && !isAnalyzed){
				subjson.put("index","not_analyzed");
			}
			if(nestedAttr.contains(fieldName))
			{
				JSONObject nestedPropJson = getNestedProperties();
				subjson.put("properties",nestedPropJson);
			}
			mapping.put(fieldName,subjson);
		}
		maping_prop.put("properties", mapping);
		//JSONArray dynamicTemplateArr = getDynamicTemplatesForDynamicAttributes();
		//maping_prop.put("dynamic_templates", dynamicTemplateArr);
		return maping_prop;
	}
	
//	public static JSONObject getIdentityDataType() throws JSONException{
//		
//		IdentityRawDataType[] identityRawDataTypes = IdentityRawDataType.values();
//		JSONObject mapping = new JSONObject();
//		JSONObject maping_prop = new JSONObject();
//		
//		for(IdentityRawDataType identityRawDataType:identityRawDataTypes)
//		{
//			String fieldName = identityRawDataType.getFieldName();
//			String fieldValue = identityRawDataType.getFieldType();
//			Boolean isAnalyzed = identityRawDataType.getIsAnalyzed();
//			JSONObject subjson = new JSONObject();
//			subjson.put("type", fieldValue);
//			
//			if((fieldValue != "object" && fieldValue != "nested") && !isAnalyzed){
//				subjson.put("index","not_analyzed");
//			}
//			mapping.put(fieldName,subjson);
//		}
//		maping_prop.put("properties", mapping);		
//		return maping_prop;
//	}
	
	public static JSONObject getFunnelDataFieldsType() throws JSONException{
		
		ArrayList<FunnelRawDataType> funnelRawDataTypes = FunnelRawDataType.FIELDS_META;
		JSONObject mapping = new JSONObject();
		JSONObject maping_prop = new JSONObject();
		
		for(FunnelRawDataType funnelRawDataType:funnelRawDataTypes)
		{
			String fieldName = funnelRawDataType.getColumnName();
			String fieldType = funnelRawDataType.getType();
			Boolean isAnalyzed = funnelRawDataType.getIsAnaylsed();
			JSONObject subjson = new JSONObject();
			subjson.put("type", fieldType);
			
			if(fieldType != "object" && !isAnalyzed){
				subjson.put("index","not_analyzed");
			}
			mapping.put(fieldName,subjson);
		}
		List<String> nestedAttr = getNestedAttributes();
		ArrayList<FunnelRawDataType> funnelStepsRawDataTypes = FunnelRawDataType.FunnelStep.FIELDS_META;
		JSONObject nestedmapping = new JSONObject();
		JSONObject npropertiesmapping = new JSONObject();
		for(FunnelRawDataType funnelRawDataType:funnelStepsRawDataTypes)
		{
			String fieldName = funnelRawDataType.getColumnName();
			String fieldValue = funnelRawDataType.getType();
			String fieldType = funnelRawDataType.getType();
			Boolean isAnalyzed = funnelRawDataType.getIsAnaylsed();
			JSONObject subjson = new JSONObject();
			subjson.put("type", fieldValue);
			
			if((fieldType != "object" && fieldType != "nested") && !isAnalyzed){
				subjson.put("index","not_analyzed");
			}
			if(nestedAttr.contains(fieldName))
			{
				JSONObject nestedPropJson = getNestedProperties();
				subjson.put("properties",nestedPropJson);
			}
			npropertiesmapping.put(fieldName,subjson);
		}
		nestedmapping.put("properties", npropertiesmapping);
		nestedmapping.put("type", "nested");
		mapping.put("steps", nestedmapping);
		maping_prop.put("properties", mapping);
		return maping_prop;
	}

	public static JSONObject getFunnelVisitorTypeMapping() throws JSONException{
		
		JSONObject mapping = new JSONObject();
		JSONObject maping_prop = new JSONObject();
		JSONObject nestedmapping = new JSONObject();
		JSONObject npropertiesmapping = new JSONObject();
		
		JSONObject subjson = new JSONObject();
		subjson.put("type", "string");
		subjson.put("index","not_analyzed");
		npropertiesmapping.put(ElasticSearchConstants.FUSERTYPE,subjson);
		
		nestedmapping.put("properties", npropertiesmapping);
		nestedmapping.put("type", "nested");
		mapping.put("steps", nestedmapping);
		maping_prop.put("properties", mapping);
		return maping_prop;
	}

	
	public static JSONObject getScrollmapDataFieldsType() throws JSONException{
		
		List<String> nestedAttr = getNestedAttributes();
		ScrollmapRawDataType[] scrollmapRawDataTypes = ScrollmapRawDataType.values();
		JSONObject mapping = new JSONObject();
		JSONObject maping_prop = new JSONObject();
		
		for(ScrollmapRawDataType scrollmapRawDataType:scrollmapRawDataTypes)
		{
			String fieldName = scrollmapRawDataType.getFieldName();
			String fieldValue = scrollmapRawDataType.getFieldType();
			Boolean isAnalyzed = scrollmapRawDataType.getIsAnalyzed();
			JSONObject subjson = new JSONObject();
			subjson.put("type", fieldValue);
			if(fieldName.equals(ScrollmapRawDataType.SCROLL_LIST.getFieldName()))
			{
				subjson.put("fielddata", true);
				JSONObject keywordjson = new JSONObject();
				keywordjson.put("type", "keyword");
				JSONObject fieldsjson = new JSONObject();
				fieldsjson.put("keyword", keywordjson);
				subjson.put( "fields", fieldsjson);
			}
			else if((fieldValue != "object" && fieldValue != "nested") && !isAnalyzed){
				subjson.put("index","not_analyzed");
			}
			if(nestedAttr.contains(fieldName))
			{
				JSONObject nestedPropJson = getNestedProperties();
				subjson.put("properties",nestedPropJson);
			}
			mapping.put(fieldName,subjson);
		}
		maping_prop.put("properties", mapping);
		//JSONArray dynamicTemplateArr = getDynamicTemplatesForDynamicAttributes();
		//maping_prop.put("dynamic_templates", dynamicTemplateArr);
		return maping_prop;
	}
	
	
	public static JSONObject getFormAnalyticsDataFieldsType() throws JSONException{
		
		List<String> nestedAttr = getNestedAttributes();
		FormRawDataType[] formRawDataTypes = FormRawDataType.values();
		JSONObject mapping = new JSONObject();
		JSONObject maping_prop = new JSONObject();
		
		for(FormRawDataType formRawDataType:formRawDataTypes)
		{
			String fieldName = formRawDataType.getFieldName();
			String fieldValue = formRawDataType.getFieldType();
			Boolean isAnalyzed = formRawDataType.getIsAnalyzed();
			JSONObject subjson = new JSONObject();
			subjson.put("type", fieldValue);
			
			if((fieldValue != "object" && fieldValue != "nested") && !isAnalyzed){
				subjson.put("index","not_analyzed");
			}
			if(nestedAttr.contains(fieldName))
			{
				JSONObject nestedPropJson = getNestedProperties();
				subjson.put("properties",nestedPropJson);
			}
			mapping.put(fieldName,subjson);
		}
		maping_prop.put("properties", mapping);
		return maping_prop;
	}
	
	public static JSONObject getFormAnalyticsFieldsType() throws JSONException{
		
			List<String> nestedAttr = getNestedAttributes();

			FormFieldRawDataType[] formFieldRawDataTypes = FormFieldRawDataType.values();
			JSONObject mapping = new JSONObject();
			JSONObject maping_prop = new JSONObject();
			
			for(FormFieldRawDataType formFieldRawDataType:formFieldRawDataTypes)
			{
				String fieldName = formFieldRawDataType.getFieldName();
				String fieldValue = formFieldRawDataType.getFieldType();
				Boolean isAnalyzed = formFieldRawDataType.getIsAnalyzed();
				JSONObject subjson = new JSONObject();
				subjson.put("type", fieldValue);
				
				if((fieldValue != "object" && fieldValue != "nested") && !isAnalyzed){
					subjson.put("index","not_analyzed");
				}
				if(nestedAttr.contains(fieldName))
				{
					JSONObject nestedPropJson = getNestedProperties();
					subjson.put("properties",nestedPropJson);
				}
				
				mapping.put(fieldName,subjson);
			}
			maping_prop.put("properties", mapping);
			return maping_prop;
	}
	
	public static JSONObject getVisitorDataFieldsType()
	{
		JSONObject resultJsonObject = new JSONObject();
		JSONObject propertiesJsonObject = new JSONObject();
		try
		{
			List<String> nestedAttr = getNestedAttributes();
			VisitorRawDataType[] visitorRawDataTypes = VisitorRawDataType.values();
			for(VisitorRawDataType visitorRawDataType:visitorRawDataTypes)
			{
				String fieldName = visitorRawDataType.getFieldName();
				String fieldType = visitorRawDataType.getFieldType();
				boolean isAnalyzed = visitorRawDataType.isAnalyzed();
				JSONObject fieldJson = new JSONObject();
				fieldJson.put("type", fieldType);
				if((fieldType != "object" && fieldType != "nested") && !isAnalyzed){
					fieldJson.put("index","not_analyzed");
				}
				if(nestedAttr.contains(fieldName))
				{
					JSONObject nestedPropJson = getNestedProperties();
					fieldJson.put("properties",nestedPropJson);
				}
				propertiesJsonObject.put(fieldName, fieldJson);
			}
			resultJsonObject.put("properties", propertiesJsonObject);
			//JSONArray dynamicTemplateArr = getDynamicTemplatesForDynamicAttributes();
			//resultJsonObject.put("dynamic_templates", dynamicTemplateArr);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
		return resultJsonObject;
	}
	
	public static List<String> getNestedAttributes()
	{
		List<String> nestedAttr = new ArrayList<>();
		nestedAttr.add(ElasticSearchConstants.NCOOKIE);
		nestedAttr.add(ElasticSearchConstants.NURLPARAMETER);
		nestedAttr.add(ElasticSearchConstants.NJSVARIABLE);
		nestedAttr.add(ElasticSearchConstants.NCUSTOMDIMENSION);
		return nestedAttr;
	}
	
	public static JSONObject getNestedProperties()
	{
		JSONObject jsonObj = new JSONObject();
		try
		{
			JSONObject valueObj = new JSONObject();
			valueObj.put("type", "string");
			valueObj.put("index", "not_analyzed");
			jsonObj.put(ElasticSearchConstants.NAME, valueObj);
			jsonObj.put(ElasticSearchConstants.VALUE, valueObj);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred in getNestedProperties",ex);
			jsonObj = new JSONObject();
		}
		return jsonObj;
	}
	
	public static JSONObject getGoalDataFieldsType()
	{
		JSONObject resultJsonObject = new JSONObject();
		JSONObject propertiesJsonObject = new JSONObject();
		try
		{
			List<String> nestedAttr = getNestedAttributes();
			GaolRawDataType[] goalRawDataTypes = GaolRawDataType.values();
			for(GaolRawDataType goalRawDataType:goalRawDataTypes)
			{
				String fieldName = goalRawDataType.getFieldName();
				String fieldType = goalRawDataType.getFieldType();
				boolean isAnalyzed = goalRawDataType.isAnalyzed();
				JSONObject fieldJson = new JSONObject();
				fieldJson.put("type", fieldType);
				if((fieldType != "object" && fieldType != "nested") && !isAnalyzed){
					fieldJson.put("index","not_analyzed");
				}
				if(nestedAttr.contains(fieldName))
				{
					JSONObject nestedPropJson = getNestedProperties();
					fieldJson.put("properties",nestedPropJson);
				}
				propertiesJsonObject.put(fieldName, fieldJson);
			}
			resultJsonObject.put("properties", propertiesJsonObject);
			//JSONArray dynamicTemplateArr = getDynamicTemplatesForDynamicAttributes();
			//resultJsonObject.put("dynamic_templates", dynamicTemplateArr);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
		return resultJsonObject;
	}
	
	public static JSONArray getDynamicTemplatesForDynamicAttributes()
	{
		JSONArray array = new JSONArray();
		try
		{
			JSONObject urlParamObj =  getDynamicTemplateJson(ElasticSearchConstants.URLPARAMETER);
			JSONObject cookieObj =  getDynamicTemplateJson(ElasticSearchConstants.COOKIE);
			JSONObject jsVariableObj =  getDynamicTemplateJson(ElasticSearchConstants.JSVARIABLE);
			JSONObject custDimensionObj =  getDynamicTemplateJson(ElasticSearchConstants.CUSTOMDIMENSION);
			array.put(urlParamObj);
			array.put(cookieObj);
			array.put(jsVariableObj);
			array.put(custDimensionObj);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			array = new JSONArray();
		}
		return array;
	}
	
	public static JSONObject getDynamicTemplateJson(String propertyObjectType)
	{
		JSONObject jsonObj = new JSONObject();
		try
		{
			JSONObject typeObj = new JSONObject();
			JSONObject mappingObj = new JSONObject();
			mappingObj.put("type", "string");
			mappingObj.put("index", "not_analyzed");
			typeObj.put("mapping", mappingObj);
			typeObj.put("match_mapping_type", "string");
			typeObj.put("path_match", propertyObjectType+".*");
			jsonObj.put(propertyObjectType+"_strings", typeObj);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			jsonObj = new JSONObject();
		}
		return jsonObj;
	}
	
	public static String getExistingDocumentIdByVisitId(String index, String portal, Long experimentId, String uvid)
	{
		String docId = null;
		try
		{
			MatchQueryBuilder portalMatch = QueryBuilders.matchQuery(ElasticSearchConstants.PORTAL, portal);
			MatchQueryBuilder expMatch = QueryBuilders.matchQuery(ElasticSearchConstants.EXPERIMENTID, experimentId);
			MatchQueryBuilder uvidMatch = QueryBuilders.matchQuery(ElasticSearchConstants.UVID, uvid);
			List<QueryBuilder> conditionList = new ArrayList<QueryBuilder>();
			conditionList.add(portalMatch);
			conditionList.add(expMatch);
			conditionList.add(uvidMatch);
			BoolQueryBuilder boolQuery = QueryBuilders.boolQuery();
			boolQuery.must().addAll(conditionList);
			/*
			JSONObject sourceJson = new JSONObject();
			JSONObject filterJson = new JSONObject();
			JSONObject boolJson = new JSONObject();
			JSONArray mustJsonArr = new JSONArray();
			JSONObject match0Json = new JSONObject();
			match0Json.put(ElasticSearchConstants.PORTAL, portal);
			JSONObject mustJsonObj0 = new JSONObject();
			mustJsonObj0.put("match", match0Json);
			JSONObject matchJson = new JSONObject();
			matchJson.put(ElasticSearchConstants.EXPERIMENTID, experimentId);
			JSONObject mustJsonObj1 = new JSONObject();
			mustJsonObj1.put("match", matchJson);
			JSONObject match2Json = new JSONObject();
			match2Json.put(ElasticSearchConstants.UVID, uvid);
			JSONObject mustJsonObj2 = new JSONObject();
			mustJsonObj2.put("match", match2Json);
			mustJsonArr.put(mustJsonObj0);
			mustJsonArr.put(mustJsonObj1);
			mustJsonArr.put(mustJsonObj2);
			boolJson.put("must", mustJsonArr);
			filterJson.put("bool", boolJson);
			sourceJson.put("query", filterJson);
			sourceJson.put("_source", false);
			*/
			SearchResponse response = ElasticSearchUtil.getData(index, ElasticSearchConstants.VISITOR_RAW_TYPE, boolQuery);
			SearchHits sHits = response.getHits();
			SearchHit hitArr[] = sHits.getHits();
			if(hitArr.length > 0)
			{
				SearchHit hit = hitArr[0];
				docId = hit.getId();
			}
		}
		catch(Exception ex)
		{
			docId = null;
		}
		return docId;
	}
	
	public static String getExistingDocumentIdByGoalActivityId(String index, String portal, Long variationId,Long goalId, String uaid)
	{
		String docId = null;
		try
		{
			MatchQueryBuilder portalMatch = QueryBuilders.matchQuery(ElasticSearchConstants.PORTAL, portal);
			MatchQueryBuilder varMatch = QueryBuilders.matchQuery(ElasticSearchConstants.VARIATIONID, variationId);
			MatchQueryBuilder goalidMatch = QueryBuilders.matchQuery(ElasticSearchConstants.GOALID, goalId);
			MatchQueryBuilder uaidMatch = QueryBuilders.matchQuery(ElasticSearchConstants.UAID, uaid);
			List<QueryBuilder> conditionList = new ArrayList<QueryBuilder>();
			conditionList.add(portalMatch);
			conditionList.add(varMatch);
			conditionList.add(goalidMatch);
			conditionList.add(uaidMatch);
			BoolQueryBuilder boolQuery = QueryBuilders.boolQuery();
			boolQuery.must().addAll(conditionList);
			/*
			JSONObject sourceJson = new JSONObject();
			JSONObject filterJson = new JSONObject();
			JSONObject boolJson = new JSONObject();
			JSONArray mustJsonArr = new JSONArray();
			JSONObject match0Json = new JSONObject();
			match0Json.put(ElasticSearchConstants.PORTAL, portal);
			JSONObject mustJsonObj0 = new JSONObject();
			mustJsonObj0.put("match", match0Json);
			JSONObject matchJson = new JSONObject();
			matchJson.put(ElasticSearchConstants.VARIATIONID, variationId);
			JSONObject mustJsonObj1 = new JSONObject();
			mustJsonObj1.put("match", matchJson);
			JSONObject match2Json = new JSONObject();
			match2Json.put(ElasticSearchConstants.GOALID, goalId);
			JSONObject mustJsonObj2 = new JSONObject();
			mustJsonObj2.put("match", match2Json);
			JSONObject match3Json = new JSONObject();
			match3Json.put(ElasticSearchConstants.UAID, uaid);
			JSONObject mustJsonObj3 = new JSONObject();
			mustJsonObj3.put("match", match3Json);
			mustJsonArr.put(mustJsonObj0);
			mustJsonArr.put(mustJsonObj1);
			mustJsonArr.put(mustJsonObj2);
			mustJsonArr.put(mustJsonObj3);
			boolJson.put("must", mustJsonArr);
			filterJson.put("bool", boolJson);
			sourceJson.put("query", filterJson);
			sourceJson.put("_source", false);*/
			
			SearchResponse response = ElasticSearchUtil.getData(index, ElasticSearchConstants.GOAL_RAW_TYPE, boolQuery);
			SearchHits sHits = response.getHits();
			SearchHit hitArr[] = sHits.getHits();
			if(hitArr.length > 0)
			{
				SearchHit hit = hitArr[0];
				docId = hit.getId();
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			docId = null;
		}
		return docId;
	}
	
	public static String getExistingDocumentIdForPageVisit(String index, String portal, String uaid)
	{
		String docId = null;
		try
		{
			MatchQueryBuilder portalMatch = QueryBuilders.matchQuery(ElasticSearchConstants.PORTAL, portal);
			MatchQueryBuilder uaidMatch = QueryBuilders.matchQuery(ElasticSearchConstants.UVID, uaid);
			List<QueryBuilder> conditionList = new ArrayList<QueryBuilder>();
			conditionList.add(portalMatch);
			conditionList.add(uaidMatch);
			BoolQueryBuilder boolQuery = QueryBuilders.boolQuery();
			boolQuery.must().addAll(conditionList);
			
			
			SearchResponse response = ElasticSearchUtil.getData(index, ElasticSearchConstants.VISITOR_RAW_TYPE, boolQuery);
			SearchHits sHits = response.getHits();
			SearchHit hitArr[] = sHits.getHits();
			if(hitArr.length > 0)
			{
				SearchHit hit = hitArr[0];
				docId = hit.getId();
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			docId = null;
		}
		return docId;
	}
	
	public static String getExistingDocumentIdForProjectGoal(String index, String portal, String uaid,String goalid)
	{
		String docId = null;
		try
		{
			MatchQueryBuilder portalMatch = QueryBuilders.matchQuery(ElasticSearchConstants.PORTAL, portal);
			MatchQueryBuilder uaidMatch = QueryBuilders.matchQuery(ElasticSearchConstants.UVID, uaid);
			MatchQueryBuilder goalidMatch = QueryBuilders.matchQuery(ElasticSearchConstants.GOALID, goalid);
			List<QueryBuilder> conditionList = new ArrayList<QueryBuilder>();
			conditionList.add(portalMatch);
			conditionList.add(uaidMatch);
			conditionList.add(goalidMatch);
			BoolQueryBuilder boolQuery = QueryBuilders.boolQuery();
			boolQuery.must().addAll(conditionList);
			
			
			SearchResponse response = ElasticSearchUtil.getData(index, ElasticSearchConstants.VISITOR_RAW_TYPE, boolQuery);
			SearchHits sHits = response.getHits();
			SearchHit hitArr[] = sHits.getHits();
			if(hitArr.length > 0)
			{
				SearchHit hit = hitArr[0];
				docId = hit.getId();
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			docId = null;
		}
		return docId;
	}
	public static ESAdminConsole getESHealth() throws Exception
	{
		ESAdminConsole esAdminConsole = new ESAdminConsole();
		
		String indexPattern = ElasticSearchConstants.DEFAULT_INDEX_PREFIX + "*";
		indexPattern = getIndexModified(indexPattern);
		
		String indexPrefix = ElasticSearchConstants.DEFAULT_INDEX_PREFIX;
		indexPrefix = getIndexModified(indexPrefix); 
		List<String> indexList = new ArrayList<String>();
		for(int i = 1; i <= ElasticSearchConstants.DEFAULT_INDEX_COUNT; i++)
		{
			indexList.add(indexPrefix+i);
		}
		String[] indexArr = indexList.toArray(new String[indexList.size()]);
		
		ClusterHealthResponse clusterHealths = getTransportClient().admin().cluster().prepareHealth(indexPattern).get();
		ClusterStatsResponse clusterStats = getTransportClient().admin().cluster().prepareClusterStats().get();
		IndicesStatsResponse indicesStatsResponse= getTransportClient().admin().indices().prepareStats(indexArr).get();
		
		/*indicesStatsResponse.getIndices();*/
		
		//Cluster from health
		String clusterName = clusterHealths.getClusterName();
		String status = clusterHealths.getStatus().name();
		
		//Nodes from health
		Integer totalNodes = clusterHealths.getNumberOfNodes();
		Integer totalDataNodes = clusterHealths.getNumberOfDataNodes();
		
		//Shards from health
		Integer activeShards = clusterHealths.getActiveShards();
		Integer activePrimaryShards = clusterHealths.getActivePrimaryShards();
		Integer delayedUnassignedShards = clusterHealths.getDelayedUnassignedShards();
		Integer initializingShards = clusterHealths.getInitializingShards();
		Integer unassignedShards = clusterHealths.getUnassignedShards();
		Integer relocatingShards = clusterHealths.getRelocatingShards();
		
		//Index count and docs count from cluster stats
		ClusterStatsIndices indicesStats = clusterStats.getIndicesStats();
		Integer totalIndexCount = indicesStats.getIndexCount();
		Long docsCount = indicesStats.getDocs().getCount();
				
		ESClusterDetails esClusterDetail = new ESClusterDetails();
		esClusterDetail.setClusterName(clusterName);
		esClusterDetail.setClusterStatus(status);
		esClusterDetail.setTotalNodes(totalNodes);
		esClusterDetail.setDataNodes(totalDataNodes);
		esClusterDetail.setActiveShards(activeShards);
		esClusterDetail.setActivePrimaryShards(activePrimaryShards);
		esClusterDetail.setDelayedUnassignedShards(delayedUnassignedShards);
		esClusterDetail.setInitializingShards(initializingShards);
		esClusterDetail.setUnassignedShards(unassignedShards);
		esClusterDetail.setRelocatingShards(relocatingShards);
		esClusterDetail.setTotalIndices(totalIndexCount);
		esClusterDetail.setTotalDocuments(docsCount);
		
		esAdminConsole.setEsClusterDetail(esClusterDetail);
		
		List<ESIndexDetails> esIndexDetailList = new ArrayList<ESIndexDetails>();
		
		//Each index from health
		for(ClusterIndexHealth indexHealth:clusterHealths.getIndices().values())
		{
			String indexName = indexHealth.getIndex();
			String indexHealthStatus = indexHealth.getStatus().name();
			Integer numberOfShards = indexHealth.getNumberOfShards();
			Integer numberOfActiveShards = indexHealth.getActiveShards();
			Integer numberOfReplicas = indexHealth.getNumberOfReplicas();
			
			IndexStats indexSts = indicesStatsResponse.getIndex(indexName);
			Long memoryInBytes = indexSts.getPrimaries().getTotalMemory().getBytes();
			Long indexDocsCount = indexSts.getTotal().getDocs().getCount();
			
			ESIndexDetails esIndexDetail = new ESIndexDetails();
			esIndexDetail.setIndexName(indexName);
			esIndexDetail.setIndexHealthStatus(indexHealthStatus);
			esIndexDetail.setNumberOfShards(numberOfShards);
			esIndexDetail.setNumberOfActiveShards(numberOfActiveShards);
			esIndexDetail.setNumberOfReplicas(numberOfReplicas);
			esIndexDetail.setMemoryInBytes(memoryInBytes);
			esIndexDetail.setIndexDocsCount(indexDocsCount);
			
			esIndexDetailList.add(esIndexDetail);
		}
		
		
		esAdminConsole.setEsIndexDetailList(esIndexDetailList);
		
		List<ESNodeDetails> esNodeDetailList = new ArrayList<ESNodeDetails>();
		
		NodesStatsResponse nodesStatsResponse = getTransportClient().admin().cluster().prepareNodesStats().all().get();
		List<NodeStats> nodeStatsArr = nodesStatsResponse.getNodes();
		
		//ClusterStatsNodeResponse[] clusterStatsNodes= clusterStats.getNodes();
		
		for(NodeStats nodeStats:nodeStatsArr)
		{
			ESNodeDetails esNodeDetails = new ESNodeDetails();
			
			DiscoveryNode node = nodeStats.getNode();
			String nodeId = node.getId();
			String nodeName = node.getName();
			String nodeAddrs = node.getAddress().getAddress();
			String nodeHost = node.getAddress().getHost();
			Integer nodePort = node.getAddress().getPort();
			Boolean isdataNode = node.isDataNode();
			Boolean ismasterNode = node.isMasterNode();
			esNodeDetails.setNodeId(nodeId);
			esNodeDetails.setNodeName(nodeName);
			esNodeDetails.setNodeAddrs(nodeAddrs);
			esNodeDetails.setNodeHost(nodeHost);
			esNodeDetails.setNodePort(nodePort);
			esNodeDetails.setIsdataNode(isdataNode);
			esNodeDetails.setIsmasterNode(ismasterNode);
			
			//NodeStats  nodeStats = statsNode.nodeStats();
			
			JvmStats jvmStats = nodeStats.getJvm();
			
			Long heapCommitted = jvmStats.getMem().getHeapCommitted().getBytes();
			Long heapUsed = jvmStats.getMem().getHeapUsed().getBytes();
			Long heapMax = jvmStats.getMem().getHeapMax().getBytes();
			Long heapNonUsed = jvmStats.getMem().getNonHeapUsed().getBytes();
			Long heapNonCommitted = jvmStats.getMem().getNonHeapCommitted().getBytes();
			String upTime = jvmStats.getUptime().toString();
			Integer threadCount = jvmStats.getThreads().getCount();
			Integer threadPeakCount = jvmStats.getThreads().getPeakCount();
			NodeJvmStats nodeJvmStats = new NodeJvmStats();
			nodeJvmStats.setHeapCommitted(heapCommitted);
			nodeJvmStats.setHeapUsed(heapUsed);
			nodeJvmStats.setHeapMax(heapMax);
			nodeJvmStats.setHeapNonUsed(heapNonUsed);
			nodeJvmStats.setHeapNonCommitted(heapNonCommitted);
			nodeJvmStats.setUpTime(upTime);
			nodeJvmStats.setThreadCount(threadCount);
			nodeJvmStats.setThreadPeakCount(threadPeakCount);
			esNodeDetails.setNodeJvmStats(nodeJvmStats);
			
			OsStats osStats = nodeStats.getOs();
			osStats.getCpu().getPercent();
			Short cpuPercent = osStats.getCpu().getPercent();
			//The below function is remove in ES 5.5 alternative is osStats.getCpu().getLoadAverage()
//			Double loadAverage = osStats.getLoadAverage();
			Double loadAverage = osStats.getCpu().getLoadAverage()[0];
			Long memTotal = osStats.getMem().getTotal().getBytes();
			Long memUsed = osStats.getMem().getUsed().getBytes();
			Long memFree = osStats.getMem().getFree().getBytes();
			Short memFreePercent = osStats.getMem().getFreePercent();
			Long swapTotal = osStats.getSwap().getTotal().getBytes();
			Long swapUsed = osStats.getSwap().getUsed().getBytes();
			Long swapFree = osStats.getSwap().getFree().getBytes();
			NodeOsStats nodeOsStats = new NodeOsStats();
			nodeOsStats.setCpuPercent(cpuPercent);
			nodeOsStats.setLoadAverage(loadAverage);
			nodeOsStats.setMemTotal(memTotal);
			nodeOsStats.setMemUsed(memUsed);
			nodeOsStats.setMemFree(memFree);
			nodeOsStats.setMemFreePercent(memFreePercent);
			nodeOsStats.setSwapTotal(swapTotal);
			nodeOsStats.setSwapUsed(swapUsed);
			nodeOsStats.setSwapFree(swapFree);
			esNodeDetails.setNodeOsStats(nodeOsStats);
			
			ProcessStats processStats = nodeStats.getProcess();
			Short processCpuPercent = processStats.getCpu().getPercent();
			String cpuTotalTime = processStats.getCpu().getTotal().toString();
			Long maxFileDescriptor = processStats.getMaxFileDescriptors();
			Long openFileDescriptor = processStats.getOpenFileDescriptors();
			Long totalVirtualMemory = processStats.getMem().getTotalVirtual().getBytes();
			NodeProcessStats nodeProcessStats = new NodeProcessStats();
			nodeProcessStats.setProcessCpuPercent(processCpuPercent);
			nodeProcessStats.setCpuTotalTime(cpuTotalTime);
			nodeProcessStats.setMaxFileDescriptor(maxFileDescriptor);
			nodeProcessStats.setOpenFileDescriptor(openFileDescriptor);
			nodeProcessStats.setTotalVirtualMemory(totalVirtualMemory);
			esNodeDetails.setNodeProcessStats(nodeProcessStats);
			
			ThreadPoolStats threadpoolStats = nodeStats.getThreadPool();
			List<NodeThreadPoolStats> nodeThreadPoolStatsList = new ArrayList<NodeThreadPoolStats>();
			Iterator<Stats> statsIterator = threadpoolStats.iterator();
			while(statsIterator.hasNext())
			{
				Stats stat = statsIterator.next();
				String statsName = stat.getName();
				Integer totalCount = stat.getThreads();
				Integer activeCount = stat.getActive();
				Long completedCount = stat.getCompleted();
				Integer queueCount = stat.getQueue();
				Long rejectedCount = stat.getRejected();
				NodeThreadPoolStats nodeThreadPoolStats = new NodeThreadPoolStats();
				nodeThreadPoolStats.setStatsName(statsName);
				nodeThreadPoolStats.setTotalCount(totalCount);
				nodeThreadPoolStats.setActiveCount(activeCount);
				nodeThreadPoolStats.setCompletedCount(completedCount);
				nodeThreadPoolStats.setQueueCount(queueCount);
				nodeThreadPoolStats.setRejectedCount(rejectedCount);
				nodeThreadPoolStatsList.add(nodeThreadPoolStats);
			}
			esNodeDetails.setNodeThreadPoolStatsList(nodeThreadPoolStatsList);
				
			FsInfo fsInfo = nodeStats.getFs();
			String path = fsInfo.getTotal().getPath();
			String mount = fsInfo.getTotal().getMount();
			Long fsTotalMemory  = fsInfo.getTotal().getTotal().getBytes();
			Long fsFreeMemory  = fsInfo.getTotal().getFree().getBytes();
			Long fsAvailableMemory  = fsInfo.getTotal().getAvailable().getBytes();
			String type = fsInfo.getTotal().getType();
			Boolean spins = fsInfo.getTotal().getSpins();
			NodeFSStats nodeFSStats = new NodeFSStats();
			nodeFSStats.setPath(path);
			nodeFSStats.setMount(mount);
			nodeFSStats.setFsTotalMemory(fsTotalMemory);
			nodeFSStats.setFsFreeMemory(fsFreeMemory);
			nodeFSStats.setFsAvailableMemory(fsAvailableMemory);
			nodeFSStats.setType(type);
			nodeFSStats.setSpins(spins);
			esNodeDetails.setNodeFSStats(nodeFSStats);
			
			
			NodeIndicesStats nodeIndicesStats = nodeStats.getIndices();
			Long nodeIndexDocCount = nodeIndicesStats.getDocs().getCount();
			Long docDelCount = nodeIndicesStats.getDocs().getDeleted();
			Long flushTotal = nodeIndicesStats.getFlush().getTotal();
			Long getCount = nodeIndicesStats.getGet().getCount();
			Long getExistsCount = nodeIndicesStats.getGet().getExistsCount();
			Long getMissingCount = nodeIndicesStats.getGet().getMissingCount();
			Long storeSize = nodeIndicesStats.getStore().getSizeInBytes();
			Long searchQueryCount = nodeIndicesStats.getSearch().getTotal().getQueryCount();
			Long searchFetchCount = nodeIndicesStats.getSearch().getTotal().getFetchCount();
			Long indexCount = nodeIndicesStats.getIndexing().getTotal().getIndexCount();
			Long indexFailedCount = nodeIndicesStats.getIndexing().getTotal().getIndexFailedCount();
			NodeIndexStats nodeIndexStats = new NodeIndexStats();
			nodeIndexStats.setNodeIndexDocCount(nodeIndexDocCount);
			nodeIndexStats.setDocDelCount(docDelCount);
			nodeIndexStats.setFlushTotal(flushTotal);
			nodeIndexStats.setGetCount(getCount);
			nodeIndexStats.setGetExistsCount(getExistsCount);
			nodeIndexStats.setGetMissingCount(getMissingCount);
			nodeIndexStats.setStoreSize(storeSize);
			nodeIndexStats.setSearchQueryCount(searchQueryCount);
			nodeIndexStats.setSearchFetchCount(searchFetchCount);
			nodeIndexStats.setIndexCount(indexCount);
			nodeIndexStats.setIndexFailedCount(indexFailedCount);
			esNodeDetails.setNodeIndicesStats(nodeIndexStats);
			
			esNodeDetailList.add(esNodeDetails);
		}
		esAdminConsole.setEsNodeDetailList(esNodeDetailList);
		
		/*clusterStats.getNodesStats();
		getTransportClient().admin().cluster().prepareNodesInfo("");
		getTransportClient().admin().cluster().prepareNodesStats();
		*/
		
		return esAdminConsole;
		
	}
	
	public static void reportClusterIndicesHealth()
	{
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		try
		{
			List<String> indicesStatusChanges = new ArrayList<String>();
			HashMap<String, Integer> indicesOldStatus = ESIndexMeta.getIndicesStatus();
			String indexPattern = ElasticSearchConstants.DEFAULT_INDEX_PREFIX + "*";
			indexPattern = getIndexModified(indexPattern);
			ClusterHealthResponse healths = getTransportClient().admin().cluster().prepareHealth(indexPattern).get();
			ClusterHealthStatus clusterHealth = healths.getStatus();
			LOGGER.log(Level.INFO,"Elastic search cluster health:"+clusterHealth.name());
			for(ClusterIndexHealth health:healths.getIndices().values())
			{
				String indexName =  health.getIndex();
				ClusterHealthStatus status = health.getStatus();
				Integer indexStatus = new Integer(status.value());
				String indexOriginalName = getIndexOriginal(indexName);
				Integer indexOldStatus = indicesOldStatus.get(indexOriginalName);
				LOGGER.log(Level.INFO,"Elastic search Index health - Indexname:"+indexName+" Newstatus:"+indexStatus+" Oldstatus:"+indexOldStatus);
				if(!indexStatus.equals(indexOldStatus))
				{
					String indexStatusChange =  indexName + ":" + indexStatus + ":" + indexOldStatus; 
					indicesStatusChanges.add(indexStatusChange);
					ESIndexMeta.updateIndexStatus(indexOriginalName, indexStatus);
				}
			}
			
			String message = null;
					
			if(indicesStatusChanges.size() > 0)
			{
				//Mail to our admin team
				message = "Hi Team, <br>";  // No I18N
				message += "Elastic search Cluster health: " + clusterHealth.name() + " <br>"; // No I18N
				message += "There are changes in the following Indices health. <br> "; // No I18N
				for(String indexStatusChange:indicesStatusChanges)
				{
					String[] statusArr = indexStatusChange.split(":");
					String indexName = statusArr[0];
					String newStatus = statusArr[1];
					String oldStatus = statusArr[2];
					String newStatusStr = ClusterHealthStatus.fromValue(new Byte(newStatus)).name();
					String oldStatusStr = ClusterHealthStatus.fromValue(new Byte(oldStatus)).name();
					String indexMessage = "Index name: "+indexName+" New status: "+newStatusStr+" Old status: "+oldStatusStr+" <br>";  // No I18N
					message += indexMessage;
				}
				message += "Kindly monitor the changes and make the neccessary update. <br> "; // No I18N
				message += "Thanks. <br> "; // No I18N
			}
			else if(clusterHealth.equals(ClusterHealthStatus.RED))
			{
				//Mail to our admin team
				message = "Hi Team, <br>";  // No I18N
				message += "Elastic search Cluster health: " + clusterHealth.name() + " <br>"; // No I18N
				message += "Kindly monitor the changes and make the neccessary update. <br> "; // No I18N
				message += "Thanks. <br> "; // No I18N
			}
			if(message != null)
			{
				String fromAddress = ElasticSearchIndexConstants.ES_MAIL_FROM_ADDRESS;
				String toAddress = ElasticSearchIndexConstants.ES_MAIL_TO_ADDRESS;
				String subject = "Elastic search Cluster status - "+CLUSTER_NAME;
				if(!IS_DEV_MODE)
				{
					ZABUtil.sendEmail(message, fromAddress, toAddress, subject);
				}					
			}
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
		ZABUtil.setDBSpace(existingDBSpace);
	}
	
	
	
	public static void deleteVariationData(Long experimentId, Long variationId)
	{
		try
		{
			String portalName = IAMUtil.getCurrentServiceOrg().getDomains().get(0).getDomain();
			String indexName = ElasticSearchUtil.getIndexByPortal(portalName); 
			String[] type = new String[]{ElasticSearchConstants.VISITOR_RAW_TYPE,ElasticSearchConstants.GOAL_RAW_TYPE,ElasticSearchConstants.HEATMAP_RAW_TYPE,ElasticSearchConstants.SCROLLMAP_RAW_TYPE};
			BoolQueryBuilder boolBuilder = QueryBuilders.boolQuery();
			boolBuilder.must().add(QueryBuilders.matchQuery(ElasticSearchConstants.PORTAL, portalName));
			boolBuilder.must().add(QueryBuilders.matchQuery(ElasticSearchConstants.EXPERIMENTID, experimentId));
			boolBuilder.must().add(QueryBuilders.matchQuery(ElasticSearchConstants.VARIATIONID, variationId));
			deleteData(indexName, boolBuilder, type);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in ES deleteVariation",ex);
		}
	}
	
	public static void deleteGoalData( Long goalId)
	{
		try
		{
			String portalName = IAMUtil.getCurrentServiceOrg().getDomains().get(0).getDomain();
			String indexName = ElasticSearchUtil.getIndexByPortal(portalName); 
			String[] type = new String[]{ElasticSearchConstants.GOAL_RAW_TYPE, ElasticSearchConstants.VISITOR_RAW_TYPE};
			BoolQueryBuilder boolBuilder = QueryBuilders.boolQuery();
			boolBuilder.must().add(QueryBuilders.matchQuery(ElasticSearchConstants.PORTAL, portalName));
			boolBuilder.must().add(QueryBuilders.matchQuery(ElasticSearchConstants.GOALID, goalId));
			deleteData(indexName, boolBuilder, type);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in ES deleteVariation",ex);
		}
	}
	
	
	public static void deleteExperimentGoalData(Long experimetnId ,  Long goalId )
	{
		try
		{
			String portalName = IAMUtil.getCurrentServiceOrg().getDomains().get(0).getDomain();
			String indexName = ElasticSearchUtil.getIndexByPortal(portalName); 
			String[] type = new String[]{ElasticSearchConstants.GOAL_RAW_TYPE};
			BoolQueryBuilder boolBuilder = QueryBuilders.boolQuery();
			boolBuilder.must().add(QueryBuilders.matchQuery(ElasticSearchConstants.PORTAL, portalName));
			boolBuilder.must().add(QueryBuilders.matchQuery(ElasticSearchConstants.GOALID, goalId));
			boolBuilder.must().add(QueryBuilders.matchQuery(ElasticSearchConstants.EXPERIMENTID, experimetnId));
			deleteData(indexName, boolBuilder, type);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in ES deleteVariation",ex);
		}
	}
	
	public static void deleteExperimentData(Long experimentId)
	{
		
			String portalName = IAMUtil.getCurrentServiceOrg().getDomains().get(0).getDomain();
			deleteExperimentData(experimentId, portalName);
	}
	
	
	public static void deleteExperimentData(Long experimentId, String portalName)
	{
		try
		{
			String indexName = ElasticSearchUtil.getIndexByPortal(portalName); 
			String[] type = new String[]{};
			BoolQueryBuilder boolBuilder = QueryBuilders.boolQuery();
			boolBuilder.must().add(QueryBuilders.matchQuery(ElasticSearchConstants.PORTAL, portalName));
			boolBuilder.must().add(QueryBuilders.matchQuery(ElasticSearchConstants.EXPERIMENTID, experimentId));
			deleteData(indexName, boolBuilder, type);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in ES deleteVariation",ex);
		}
	}
	
	public static void deleteProjectData(Long projectId)
	{
		
		String portalName = IAMUtil.getCurrentServiceOrg().getDomains().get(0).getDomain();
		deleteProjectData(projectId, portalName);
	}
	
	
	public static void deleteProjectData(Long projectId, String portalName)
	{
		try
		{
			String indexName = ElasticSearchUtil.getIndexByPortal(portalName); 
			String[] type = new String[]{};
			BoolQueryBuilder boolBuilder = QueryBuilders.boolQuery();
			boolBuilder.must().add(QueryBuilders.matchQuery(ElasticSearchConstants.PORTAL, portalName));
			boolBuilder.must().add(QueryBuilders.matchQuery(ElasticSearchConstants.PROJECTID, projectId));
			deleteData(indexName, boolBuilder, type);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in ES deleteProject",ex);
		}
	}
	
	public static void deleteEventData(Long eventId)
	{
		try
		{
			String portalName = IAMUtil.getCurrentServiceOrg().getDomains().get(0).getDomain();
			String indexName = ElasticSearchUtil.getIndexByPortal(portalName); 
			String[] type = new String[]{};
			BoolQueryBuilder boolBuilder = QueryBuilders.boolQuery();
			boolBuilder.must().add(QueryBuilders.matchQuery(ElasticSearchConstants.PORTAL, portalName));
			boolBuilder.must().add(QueryBuilders.matchQuery(ElasticSearchConstants.EVENTID, eventId));
			deleteData(indexName, boolBuilder, type);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in ES deleteProject",ex);
		}
	}
	
	
	public static void deletePortalData(String portalName)
	{
		try
		{
			String indexName = ElasticSearchUtil.getIndexByPortal(portalName); 
			if(StringUtils.isNotEmpty(indexName))
			{
				String[] type = new String[]{};
				BoolQueryBuilder boolBuilder = QueryBuilders.boolQuery();
				boolBuilder.must().add(QueryBuilders.matchQuery(ElasticSearchConstants.PORTAL, portalName));
				deleteData(indexName, boolBuilder, type);
			}
			LOGGER.log(Level.INFO, "successfully deleted data - "+ portalName);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.INFO, " exception while deleting data - "+ portalName);
			LOGGER.log(Level.SEVERE, "Exception occurred in ES deleteVariation",ex);
		}
	} 
	
	public static String getCurrentUserTimezone() {
		String timezone = ESQuickFilterConstants.DEFAULT_TIME_ZONE;
		if(IAMUtil.getCurrentUser()!=null && StringUtils.isNotEmpty(IAMUtil.getCurrentUser().getTimezone()))
		{
			timezone = IAMUtil.getCurrentUser().getTimezone();
		}
		return timezone;
	}
	
	public static Integer getFrom(Integer pageNumber, Integer size) {
		if(pageNumber == null) {
			return 0;
		} else {
			return (pageNumber - 1) * size;
		}
	}
}
