//$Id$
package com.zoho.abtest.elastic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Operation;
import com.adventnet.ds.query.Operation.operationType;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.Range;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.ds.query.SelectQueryImpl;
import com.adventnet.ds.query.SortColumn;
import com.adventnet.ds.query.Table;
import com.adventnet.ds.query.UpdateQuery;
import com.adventnet.ds.query.UpdateQueryImpl;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.ES_INDEX_META;
import com.zoho.abtest.ES_INDEX_PORTAL_MAPPING;
import com.zoho.abtest.common.ZABModel;

public class ESIndexMeta extends ZABModel
{
	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = Logger.getLogger(ESIndexMeta.class.getName());
	
	private Long esIndexMetaId;
	private String indexName;
	private Integer activePortalCount;
	private Integer indexStatus;
	
	public Integer getIndexStatus() {
		return indexStatus;
	}
	public void setIndexStatus(Integer indexStatus) {
		this.indexStatus = indexStatus;
	}
	public Long getEsIndexMetaId() {
		return esIndexMetaId;
	}
	public void setEsIndexMetaId(Long esIndexMetaId) {
		this.esIndexMetaId = esIndexMetaId;
	}
	public String getIndexName() {
		return indexName;
	}
	public void setIndexName(String indexName) {
		this.indexName = indexName;
	}
	public Integer getActivePortalCount() {
		return activePortalCount;
	}
	public void setActivePortalCount(Integer activePortalCount) {
		this.activePortalCount = activePortalCount;
	}
	
	public static ESIndexMeta createESIndexMeta(HashMap<String, String> hs) throws Exception
	{
		ESIndexMeta indexMeta = null;
		try
		{
			DataObject dataObj = ZABModel.createRow(ElasticSearchIndexConstants.ES_INDEX_META_CONSTANTS, ES_INDEX_META.TABLE, hs);
			Row row = dataObj.getFirstRow(ES_INDEX_META.TABLE);
			indexMeta = getESIndexMetaFromRow(row);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			throw ex;
		}
		return indexMeta;
	}
	
	public static void createESIndexMeta(ArrayList<HashMap<String, String>> hsList) throws Exception
	{
		try
		{
			ZABModel.createRow(ElasticSearchIndexConstants.ES_INDEX_META_CONSTANTS, ES_INDEX_META.TABLE, hsList);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			throw ex;
		}
	}
	
	public static ESIndexMeta getMostAvailableIndex() throws Exception
	{
		ESIndexMeta indexMeta = null;
		try
		{
			SortColumn sortCol = new SortColumn(ES_INDEX_META.TABLE,ES_INDEX_META.ACTIVE_PORTAL_COUNT, Boolean.TRUE);
			DataObject dataObj = ZABModel.getRow(ES_INDEX_META.TABLE, null, sortCol, 1);
			if(!dataObj.isEmpty())
			{
				Row row = dataObj.getFirstRow(ES_INDEX_META.TABLE);
				indexMeta = getESIndexMetaFromRow(row);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			throw ex;
		}
		return indexMeta;
	}
	
	public static boolean isESIndexMetaExists() throws Exception
	{
		boolean recordExists = false;
		DataObject dataObj = ZABModel.getRow(ES_INDEX_META.TABLE, null);
		if(!dataObj.isEmpty())
		{
			recordExists = true;
		}
		return recordExists;
	}
	
	public static void updateIndexAvailability(Long indexId) throws Exception
	{
		try
		{
			Criteria criteria = new Criteria(new Column(ES_INDEX_META.TABLE, ES_INDEX_META.ES_INDEX_META_ID), indexId, QueryConstants.EQUAL);
			UpdateQuery updateQuery = new UpdateQueryImpl(ES_INDEX_META.TABLE);
			Column operation = Column.createOperation(operationType.ADD, Column.getColumn(ES_INDEX_META.TABLE, ES_INDEX_META.ACTIVE_PORTAL_COUNT), new Integer(1));
			updateQuery.setUpdateColumn(ES_INDEX_META.ACTIVE_PORTAL_COUNT, operation);
			updateQuery.setCriteria(criteria);
			ZABModel.updateRow(updateQuery);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			throw ex;
		}
	}
	
	public static void reduceIndexPortalValue(Long indexId) throws Exception
	{
		try
		{
			Criteria criteria = new Criteria(new Column(ES_INDEX_META.TABLE, ES_INDEX_META.ES_INDEX_META_ID), indexId, QueryConstants.EQUAL);
			UpdateQuery updateQuery = new UpdateQueryImpl(ES_INDEX_META.TABLE);
			Column operation = Column.createOperation(operationType.SUBTRACT, Column.getColumn(ES_INDEX_META.TABLE, ES_INDEX_META.ACTIVE_PORTAL_COUNT), new Integer(1));
			updateQuery.setUpdateColumn(ES_INDEX_META.ACTIVE_PORTAL_COUNT, operation);
			updateQuery.setCriteria(criteria);
			ZABModel.updateRow(updateQuery);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			throw ex;
		}
	}
	
	public static void updateIndexStatus(String indexName, Integer newStatus) throws Exception
	{
		try
		{
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(ElasticSearchIndexConstants.INDEX_STATUS, newStatus.toString());
			Criteria criteria = new Criteria(new Column(ES_INDEX_META.TABLE, ES_INDEX_META.INDEX_NAME), indexName, QueryConstants.EQUAL);
			ZABModel.updateRow(ElasticSearchIndexConstants.ES_INDEX_META_CONSTANTS, ES_INDEX_META.TABLE, hs, criteria, null);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			throw ex;
		}
	}
	
	public static HashMap<String, Integer> getIndicesStatus() throws Exception
	{
		HashMap<String, Integer> hs = new HashMap<String, Integer>();
		try
		{
			DataObject dataObj = ZABModel.getRow(ES_INDEX_META.TABLE, null);
			Iterator<?> iterator = dataObj.getRows(ES_INDEX_META.TABLE);
			while(iterator.hasNext())
			{
				Row row = (Row)iterator.next();
				String indexName = (String)row.get(ES_INDEX_META.INDEX_NAME);
				Integer indexStatus = (Integer)row.get(ES_INDEX_META.INDEX_STATUS);
				hs.put(indexName, indexStatus);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			throw ex;
		}
		return hs;
	}
	
	public static ESIndexMeta getESIndexMetaFromRow(Row row)
	{
		ESIndexMeta indexMeta = new ESIndexMeta();
		indexMeta.setEsIndexMetaId((Long)row.get(ES_INDEX_META.ES_INDEX_META_ID));
		indexMeta.setIndexName((String)row.get(ES_INDEX_META.INDEX_NAME));
		indexMeta.setActivePortalCount((Integer)row.get(ES_INDEX_META.ACTIVE_PORTAL_COUNT));
		indexMeta.setIndexStatus((Integer)row.get(ES_INDEX_META.INDEX_STATUS));
		return indexMeta;
	}
}
