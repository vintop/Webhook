//$Id$
package com.zoho.abtest.elastic.adminconsole;

import java.util.List;
import java.util.logging.Logger;

public class ESNodeDetails 
{
	private static final Logger LOGGER = Logger.getLogger(ESNodeDetails.class.getName());
	
	private String nodeId;
	private String nodeName;
	private String nodeAddrs;
	private String nodeHost;
	private Integer nodePort;
	private Boolean isdataNode;
	private Boolean ismasterNode;
	
	private NodeJvmStats nodeJvmStats;
	private NodeOsStats nodeOsStats;
	private NodeProcessStats nodeProcessStats;
	private NodeFSStats nodeFSStats;
	private NodeIndexStats nodeIndicesStats;
	private List<NodeThreadPoolStats> nodeThreadPoolStatsList;
	
	public NodeJvmStats getNodeJvmStats() {
		return nodeJvmStats;
	}
	public void setNodeJvmStats(NodeJvmStats nodeJvmStats) {
		this.nodeJvmStats = nodeJvmStats;
	}
	public NodeOsStats getNodeOsStats() {
		return nodeOsStats;
	}
	public void setNodeOsStats(NodeOsStats nodeOsStats) {
		this.nodeOsStats = nodeOsStats;
	}
	public NodeProcessStats getNodeProcessStats() {
		return nodeProcessStats;
	}
	public void setNodeProcessStats(NodeProcessStats nodeProcessStats) {
		this.nodeProcessStats = nodeProcessStats;
	}
	public NodeFSStats getNodeFSStats() {
		return nodeFSStats;
	}
	public void setNodeFSStats(NodeFSStats nodeFSStats) {
		this.nodeFSStats = nodeFSStats;
	}
	public NodeIndexStats getNodeIndicesStats() {
		return nodeIndicesStats;
	}
	public void setNodeIndicesStats(NodeIndexStats nodeIndicesStats) {
		this.nodeIndicesStats = nodeIndicesStats;
	}
	public List<NodeThreadPoolStats> getNodeThreadPoolStatsList() {
		return nodeThreadPoolStatsList;
	}
	public void setNodeThreadPoolStatsList(
			List<NodeThreadPoolStats> nodeThreadPoolStatsList) {
		this.nodeThreadPoolStatsList = nodeThreadPoolStatsList;
	}
	public String getNodeId() {
		return nodeId;
	}
	public void setNodeId(String nodeId) {
		this.nodeId = nodeId;
	}
	public String getNodeName() {
		return nodeName;
	}
	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}
	public String getNodeAddrs() {
		return nodeAddrs;
	}
	public void setNodeAddrs(String nodeAddrs) {
		this.nodeAddrs = nodeAddrs;
	}
	public String getNodeHost() {
		return nodeHost;
	}
	public void setNodeHost(String nodeHost) {
		this.nodeHost = nodeHost;
	}
	public Integer getNodePort() {
		return nodePort;
	}
	public void setNodePort(Integer nodePort) {
		this.nodePort = nodePort;
	}
	public Boolean getIsdataNode() {
		return isdataNode;
	}
	public void setIsdataNode(Boolean isdataNode) {
		this.isdataNode = isdataNode;
	}
	public Boolean getIsmasterNode() {
		return ismasterNode;
	}
	public void setIsmasterNode(Boolean ismasterNode) {
		this.ismasterNode = ismasterNode;
	}
}
