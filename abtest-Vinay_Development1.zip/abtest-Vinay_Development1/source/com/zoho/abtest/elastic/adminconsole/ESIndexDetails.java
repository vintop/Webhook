//$Id$
package com.zoho.abtest.elastic.adminconsole;

import java.util.logging.Logger;

public class ESIndexDetails 
{
	private static final Logger LOGGER = Logger.getLogger(ESIndexDetails.class.getName());
	
	private String indexName;
	private String indexHealthStatus;
	private Integer numberOfShards;
	private Integer numberOfActiveShards;
	private Integer numberOfReplicas;
	private Long memoryInBytes;
	private Long indexDocsCount;
	
	public String getIndexName() {
		return indexName;
	}
	public void setIndexName(String indexName) {
		this.indexName = indexName;
	}
	public String getIndexHealthStatus() {
		return indexHealthStatus;
	}
	public void setIndexHealthStatus(String indexHealthStatus) {
		this.indexHealthStatus = indexHealthStatus;
	}
	public Integer getNumberOfShards() {
		return numberOfShards;
	}
	public void setNumberOfShards(Integer numberOfShards) {
		this.numberOfShards = numberOfShards;
	}
	public Integer getNumberOfActiveShards() {
		return numberOfActiveShards;
	}
	public void setNumberOfActiveShards(Integer numberOfActiveShards) {
		this.numberOfActiveShards = numberOfActiveShards;
	}
	public Integer getNumberOfReplicas() {
		return numberOfReplicas;
	}
	public void setNumberOfReplicas(Integer numberOfReplicas) {
		this.numberOfReplicas = numberOfReplicas;
	}
	public Long getIndexDocsCount() {
		return indexDocsCount;
	}
	public void setIndexDocsCount(Long indexDocsCount) {
		this.indexDocsCount = indexDocsCount;
	}
	public Long getMemoryInBytes() {
		return memoryInBytes;
	}
	public void setMemoryInBytes(Long memoryInBytes) {
		this.memoryInBytes = memoryInBytes;
	}
}
