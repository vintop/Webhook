//$Id$
package com.zoho.abtest.elastic.adminconsole;

import java.util.logging.Logger;

public class ESClusterDetails 
{
	private static final Logger LOGGER = Logger.getLogger(ESClusterDetails.class.getName());
	
	private String clusterName;
	private String clusterStatus;
	private Integer totalNodes;
	private Integer totalIndices;
	private Long totalDocuments;
	private Integer dataNodes;
	private Integer activeShards;
	private Integer activePrimaryShards;
	private Integer delayedUnassignedShards;
	private Integer initializingShards;
	private Integer unassignedShards;
	private Integer relocatingShards;
	
	public String getClusterName() {
		return clusterName;
	}
	public void setClusterName(String clusterName) {
		this.clusterName = clusterName;
	}
	public String getClusterStatus() {
		return clusterStatus;
	}
	public void setClusterStatus(String clusterStatus) {
		this.clusterStatus = clusterStatus;
	}
	public Integer getTotalNodes() {
		return totalNodes;
	}
	public void setTotalNodes(Integer totalNodes) {
		this.totalNodes = totalNodes;
	}
	public Integer getTotalIndices() {
		return totalIndices;
	}
	public void setTotalIndices(Integer totalIndices) {
		this.totalIndices = totalIndices;
	}
	public Long getTotalDocuments() {
		return totalDocuments;
	}
	public void setTotalDocuments(Long totalDocuments) {
		this.totalDocuments = totalDocuments;
	}
	public Integer getDataNodes() {
		return dataNodes;
	}
	public void setDataNodes(Integer dataNodes) {
		this.dataNodes = dataNodes;
	}
	public Integer getActiveShards() {
		return activeShards;
	}
	public void setActiveShards(Integer activeShards) {
		this.activeShards = activeShards;
	}
	public Integer getActivePrimaryShards() {
		return activePrimaryShards;
	}
	public void setActivePrimaryShards(Integer activePrimaryShards) {
		this.activePrimaryShards = activePrimaryShards;
	}
	public Integer getDelayedUnassignedShards() {
		return delayedUnassignedShards;
	}
	public void setDelayedUnassignedShards(Integer delayedUnassignedShards) {
		this.delayedUnassignedShards = delayedUnassignedShards;
	}
	public Integer getInitializingShards() {
		return initializingShards;
	}
	public void setInitializingShards(Integer initializingShards) {
		this.initializingShards = initializingShards;
	}
	public Integer getUnassignedShards() {
		return unassignedShards;
	}
	public void setUnassignedShards(Integer unassignedShards) {
		this.unassignedShards = unassignedShards;
	}
	public Integer getRelocatingShards() {
		return relocatingShards;
	}
	public void setRelocatingShards(Integer relocatingShards) {
		this.relocatingShards = relocatingShards;
	}
	
}
