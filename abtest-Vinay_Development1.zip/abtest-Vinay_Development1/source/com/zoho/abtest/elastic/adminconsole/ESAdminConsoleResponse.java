//$Id$
package com.zoho.abtest.elastic.adminconsole;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;
import com.zoho.abtest.elastic.ElasticSearchIndexConstants;

public class ESAdminConsoleResponse 
{
	private static final Logger LOGGER = Logger.getLogger(ESAdminConsoleResponse.class.getName());
	
	public static String jsonResponse(HttpServletRequest request,ESAdminConsole esAdminConsole) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(esAdminConsole);			
			JSONObject json = ZABResponse.updateMetaInfo(request, ElasticSearchIndexConstants.ES_CLUSTER_DETAILS_API_MODULE, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		return returnBuffer.toString();
	}
	
	public static JSONArray getJSONArray(ESAdminConsole esAdminConsole) throws Exception {
		JSONArray array = new JSONArray();
		JSONObject jsonObj = new JSONObject();
		if(esAdminConsole != null)
		{
			jsonObj.put("esClusterDetail", getClusterDetailObj(esAdminConsole.getEsClusterDetail()));
			jsonObj.put("esIndexDetailList", getIndexDetails(esAdminConsole.getEsIndexDetailList()));
			jsonObj.put("esNodeDetailList", getNodeDetails(esAdminConsole.getEsNodeDetailList()));
		}
		jsonObj.put(ZABConstants.SUCCESS, Boolean.TRUE);
		array.put(jsonObj);
		return array;
	}
	
	public static JSONObject getClusterDetailObj(ESClusterDetails esClusterDetail) throws Exception
	{
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("clusterName", esClusterDetail.getClusterName());
		jsonObj.put("clusterStatus", esClusterDetail.getClusterStatus());
		jsonObj.put("totalNodes", esClusterDetail.getTotalNodes());
		jsonObj.put("totalIndices", esClusterDetail.getTotalIndices());
		jsonObj.put("totalDocuments", esClusterDetail.getTotalDocuments());
		jsonObj.put("dataNodes", esClusterDetail.getDataNodes());
		jsonObj.put("activeShards", esClusterDetail.getActiveShards());
		jsonObj.put("activePrimaryShards", esClusterDetail.getActivePrimaryShards());
		jsonObj.put("delayedUnassignedShards", esClusterDetail.getDelayedUnassignedShards());
		jsonObj.put("initializingShards", esClusterDetail.getInitializingShards());
		jsonObj.put("unassignedShards", esClusterDetail.getUnassignedShards());
		jsonObj.put("relocatingShards", esClusterDetail.getRelocatingShards());
		return jsonObj;
	}
	
	public static JSONArray getIndexDetails(List<ESIndexDetails> esIndexDetailList) throws Exception
	{
		JSONArray jsonArr = new JSONArray();
		for(ESIndexDetails esIndexDetail:esIndexDetailList)
		{
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("indexName", esIndexDetail.getIndexName());
			jsonObj.put("indexHealthStatus", esIndexDetail.getIndexHealthStatus());
			jsonObj.put("numberOfShards", esIndexDetail.getNumberOfShards());
			jsonObj.put("numberOfActiveShards", esIndexDetail.getNumberOfActiveShards());
			jsonObj.put("numberOfReplicas", esIndexDetail.getNumberOfReplicas());
			jsonObj.put("memoryInBytes", esIndexDetail.getMemoryInBytes());
			jsonObj.put("indexDocsCount", esIndexDetail.getIndexDocsCount());
			jsonArr.put(jsonObj);
		}
		return jsonArr;
	}
	
	public static JSONArray getNodeDetails(List<ESNodeDetails> esNodeDetailList) throws Exception
	{
		JSONArray jsonArr = new JSONArray();
		for(ESNodeDetails esNodeDetail:esNodeDetailList)
		{
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("nodeId", esNodeDetail.getNodeId());
			jsonObj.put("nodeName", esNodeDetail.getNodeName());
			jsonObj.put("nodeAddrs", esNodeDetail.getNodeAddrs());
			jsonObj.put("nodeHost", esNodeDetail.getNodeHost());
			jsonObj.put("nodePort", esNodeDetail.getNodePort());
			jsonObj.put("isdataNode", esNodeDetail.getIsdataNode());
			jsonObj.put("ismasterNode", esNodeDetail.getIsmasterNode());
			
			jsonObj.put("nodeJvmStats", getNodeJvmStats(esNodeDetail.getNodeJvmStats()));
			jsonObj.put("nodeOsStats", getNodeOsStats(esNodeDetail.getNodeOsStats()));
			jsonObj.put("nodeProcessStats", getNodeProcessStats(esNodeDetail.getNodeProcessStats()));
			jsonObj.put("nodeFSStats", getNodeFSStats(esNodeDetail.getNodeFSStats()));
			jsonObj.put("nodeIndicesStats", getNodeIndexStats(esNodeDetail.getNodeIndicesStats()));
			jsonObj.put("nodeThreadPoolStatsList", getNodeThreadPoolStats(esNodeDetail.getNodeThreadPoolStatsList()));
			
			jsonArr.put(jsonObj);
		}
		return jsonArr;
	}
	
	public static JSONObject getNodeJvmStats(NodeJvmStats nodeJvmStats) throws Exception
	{
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("heapCommitted", nodeJvmStats.getHeapCommitted());
		jsonObj.put("heapUsed", nodeJvmStats.getHeapUsed());
		jsonObj.put("heapMax", nodeJvmStats.getHeapMax());
		jsonObj.put("heapNonUsed", nodeJvmStats.getHeapNonUsed());
		jsonObj.put("heapNonCommitted", nodeJvmStats.getHeapNonCommitted());
		jsonObj.put("upTime", nodeJvmStats.getUpTime());
		jsonObj.put("threadCount", nodeJvmStats.getThreadCount());
		jsonObj.put("threadPeakCount", nodeJvmStats.getThreadPeakCount());
		return jsonObj;
	}
	
	public static JSONObject getNodeOsStats(NodeOsStats nodeOsStats) throws Exception
	{
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("cpuPercent", nodeOsStats.getCpuPercent());
		jsonObj.put("loadAverage", nodeOsStats.getLoadAverage());
		jsonObj.put("memTotal", nodeOsStats.getMemTotal());
		jsonObj.put("memUsed", nodeOsStats.getMemUsed());
		jsonObj.put("memFree", nodeOsStats.getMemFree());
		jsonObj.put("memFreePercent", nodeOsStats.getMemFreePercent());
		jsonObj.put("swapTotal", nodeOsStats.getSwapTotal());
		jsonObj.put("swapUsed", nodeOsStats.getSwapUsed());
		jsonObj.put("swapFree", nodeOsStats.getSwapFree());
		return jsonObj;
	}
	
	public static JSONObject getNodeProcessStats(NodeProcessStats nodeProcessStats) throws Exception
	{
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("processCpuPercent", nodeProcessStats.getProcessCpuPercent());
		jsonObj.put("cpuTotalTime", nodeProcessStats.getCpuTotalTime());
		jsonObj.put("maxFileDescriptor", nodeProcessStats.getMaxFileDescriptor());
		jsonObj.put("openFileDescriptor", nodeProcessStats.getOpenFileDescriptor());
		jsonObj.put("totalVirtualMemory", nodeProcessStats.getTotalVirtualMemory());
		return jsonObj;
	}
	
	public static JSONObject getNodeFSStats(NodeFSStats nodeFSStats) throws Exception
	{
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("path", nodeFSStats.getPath());
		jsonObj.put("mount", nodeFSStats.getMount());
		jsonObj.put("fsTotalMemory", nodeFSStats.getFsTotalMemory());
		jsonObj.put("fsFreeMemory", nodeFSStats.getFsFreeMemory());
		jsonObj.put("fsAvailableMemory", nodeFSStats.getFsAvailableMemory());
		jsonObj.put("type", nodeFSStats.getType());
		jsonObj.put("spins", nodeFSStats.getSpins());
		return jsonObj;
	}
	
	public static JSONObject getNodeIndexStats(NodeIndexStats nodeIndexStats) throws Exception
	{
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("nodeIndexDocCount", nodeIndexStats.getNodeIndexDocCount());
		jsonObj.put("docDelCount", nodeIndexStats.getDocDelCount());
		jsonObj.put("flushTotal", nodeIndexStats.getFlushTotal());
		jsonObj.put("getCount", nodeIndexStats.getGetCount());
		jsonObj.put("getExistsCount", nodeIndexStats.getGetExistsCount());
		jsonObj.put("getMissingCount", nodeIndexStats.getGetMissingCount());
		jsonObj.put("storeSize", nodeIndexStats.getStoreSize());
		jsonObj.put("searchQueryCount", nodeIndexStats.getSearchQueryCount());
		jsonObj.put("searchFetchCount", nodeIndexStats.getSearchFetchCount());
		jsonObj.put("indexCount", nodeIndexStats.getIndexCount());
		jsonObj.put("indexFailedCount", nodeIndexStats.getIndexFailedCount());
		return jsonObj;
	}
	
	public static JSONArray getNodeThreadPoolStats(List<NodeThreadPoolStats> nodeThreadPoolStatsList) throws Exception
	{
		JSONArray jsonArr = new JSONArray();
		for(NodeThreadPoolStats nodeThreadPoolStats:nodeThreadPoolStatsList)
		{
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("statsName", nodeThreadPoolStats.getStatsName());
			jsonObj.put("totalCount", nodeThreadPoolStats.getTotalCount());
			jsonObj.put("activeCount", nodeThreadPoolStats.getActiveCount());
			jsonObj.put("completedCount", nodeThreadPoolStats.getCompletedCount());
			jsonObj.put("queueCount", nodeThreadPoolStats.getQueueCount());
			jsonObj.put("rejectedCount", nodeThreadPoolStats.getRejectedCount());
			jsonArr.put(jsonObj);
		}
		return jsonArr;
	}
}
