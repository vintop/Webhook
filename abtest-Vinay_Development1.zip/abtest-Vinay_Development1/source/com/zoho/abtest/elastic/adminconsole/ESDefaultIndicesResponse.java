//$Id$
package com.zoho.abtest.elastic.adminconsole;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;
import com.zoho.abtest.elastic.ElasticSearchIndexConstants;

public class ESDefaultIndicesResponse 
{
	private static final Logger LOGGER = Logger.getLogger(ESDefaultIndicesResponse.class.getName());
	
	public static String jsonResponse(HttpServletRequest request) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray();			
			JSONObject json = ZABResponse.updateMetaInfo(request, ElasticSearchIndexConstants.ES_POPULATE_INDICES_API_MODULE, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		return returnBuffer.toString();
	}
	
	public static JSONArray getJSONArray() throws Exception {
		JSONArray array = new JSONArray();
		JSONObject jsonObj = new JSONObject();
		jsonObj.put(ZABConstants.SUCCESS, Boolean.TRUE);
		array.put(jsonObj);
		return array;
	}
}
