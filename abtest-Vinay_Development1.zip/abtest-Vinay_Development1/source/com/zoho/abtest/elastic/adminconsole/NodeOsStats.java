//$Id$
package com.zoho.abtest.elastic.adminconsole;

public class NodeOsStats 
{
	private Short cpuPercent;
	private Double loadAverage;
	private Long memTotal;
	private Long memUsed;
	private Long memFree;
	private Short memFreePercent;
	private Long swapTotal;
	private Long swapUsed;
	private Long swapFree;
	
	public Short getCpuPercent() {
		return cpuPercent;
	}
	public void setCpuPercent(Short cpuPercent) {
		this.cpuPercent = cpuPercent;
	}
	public Double getLoadAverage() {
		return loadAverage;
	}
	public void setLoadAverage(Double loadAverage) {
		this.loadAverage = loadAverage;
	}
	public Long getMemTotal() {
		return memTotal;
	}
	public void setMemTotal(Long memTotal) {
		this.memTotal = memTotal;
	}
	public Long getMemUsed() {
		return memUsed;
	}
	public void setMemUsed(Long memUsed) {
		this.memUsed = memUsed;
	}
	public Long getMemFree() {
		return memFree;
	}
	public void setMemFree(Long memFree) {
		this.memFree = memFree;
	}
	public Short getMemFreePercent() {
		return memFreePercent;
	}
	public void setMemFreePercent(Short memFreePercent) {
		this.memFreePercent = memFreePercent;
	}
	public Long getSwapTotal() {
		return swapTotal;
	}
	public void setSwapTotal(Long swapTotal) {
		this.swapTotal = swapTotal;
	}
	public Long getSwapUsed() {
		return swapUsed;
	}
	public void setSwapUsed(Long swapUsed) {
		this.swapUsed = swapUsed;
	}
	public Long getSwapFree() {
		return swapFree;
	}
	public void setSwapFree(Long swapFree) {
		this.swapFree = swapFree;
	}
}
