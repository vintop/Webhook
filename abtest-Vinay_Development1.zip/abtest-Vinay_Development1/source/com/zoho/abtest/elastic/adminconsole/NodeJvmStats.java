//$Id$
package com.zoho.abtest.elastic.adminconsole;

public class NodeJvmStats 
{
	private Long heapCommitted;
	private Long heapUsed;
	private Long heapMax;
	private Long heapNonUsed;
	private Long heapNonCommitted;
	private String upTime;
	private Integer threadCount;
	private Integer threadPeakCount;
	
	public Long getHeapCommitted() {
		return heapCommitted;
	}
	public void setHeapCommitted(Long heapCommitted) {
		this.heapCommitted = heapCommitted;
	}
	public Long getHeapUsed() {
		return heapUsed;
	}
	public void setHeapUsed(Long heapUsed) {
		this.heapUsed = heapUsed;
	}
	public Long getHeapMax() {
		return heapMax;
	}
	public void setHeapMax(Long heapMax) {
		this.heapMax = heapMax;
	}
	public Long getHeapNonUsed() {
		return heapNonUsed;
	}
	public void setHeapNonUsed(Long heapNonUsed) {
		this.heapNonUsed = heapNonUsed;
	}
	public Long getHeapNonCommitted() {
		return heapNonCommitted;
	}
	public void setHeapNonCommitted(Long heapNonCommitted) {
		this.heapNonCommitted = heapNonCommitted;
	}
	public String getUpTime() {
		return upTime;
	}
	public void setUpTime(String upTime) {
		this.upTime = upTime;
	}
	public Integer getThreadCount() {
		return threadCount;
	}
	public void setThreadCount(Integer threadCount) {
		this.threadCount = threadCount;
	}
	public Integer getThreadPeakCount() {
		return threadPeakCount;
	}
	public void setThreadPeakCount(Integer threadPeakCount) {
		this.threadPeakCount = threadPeakCount;
	}
}
