//$Id$
package com.zoho.abtest.elastic.adminconsole;

public class NodeProcessStats
{
	private Short processCpuPercent; 
	private String cpuTotalTime;
	private Long maxFileDescriptor;
	private Long openFileDescriptor;
	private Long totalVirtualMemory;
	
	public Short getProcessCpuPercent() {
		return processCpuPercent;
	}
	public void setProcessCpuPercent(Short processCpuPercent) {
		this.processCpuPercent = processCpuPercent;
	}
	public String getCpuTotalTime() {
		return cpuTotalTime;
	}
	public void setCpuTotalTime(String cpuTotalTime) {
		this.cpuTotalTime = cpuTotalTime;
	}
	public Long getMaxFileDescriptor() {
		return maxFileDescriptor;
	}
	public void setMaxFileDescriptor(Long maxFileDescriptor) {
		this.maxFileDescriptor = maxFileDescriptor;
	}
	public Long getOpenFileDescriptor() {
		return openFileDescriptor;
	}
	public void setOpenFileDescriptor(Long openFileDescriptor) {
		this.openFileDescriptor = openFileDescriptor;
	}
	public Long getTotalVirtualMemory() {
		return totalVirtualMemory;
	}
	public void setTotalVirtualMemory(Long totalVirtualMemory) {
		this.totalVirtualMemory = totalVirtualMemory;
	}
}
