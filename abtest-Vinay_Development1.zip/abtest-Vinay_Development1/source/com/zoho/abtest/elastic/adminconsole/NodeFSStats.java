//$Id$
package com.zoho.abtest.elastic.adminconsole;

public class NodeFSStats 
{
	private String path;
	private String mount;
	private Long fsTotalMemory;
	private Long fsFreeMemory;
	private Long fsAvailableMemory;
	private String type;
	private Boolean spins;
	
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public String getMount() {
		return mount;
	}
	public void setMount(String mount) {
		this.mount = mount;
	}
	public Long getFsTotalMemory() {
		return fsTotalMemory;
	}
	public void setFsTotalMemory(Long fsTotalMemory) {
		this.fsTotalMemory = fsTotalMemory;
	}
	public Long getFsFreeMemory() {
		return fsFreeMemory;
	}
	public void setFsFreeMemory(Long fsFreeMemory) {
		this.fsFreeMemory = fsFreeMemory;
	}
	public Long getFsAvailableMemory() {
		return fsAvailableMemory;
	}
	public void setFsAvailableMemory(Long fsAvailableMemory) {
		this.fsAvailableMemory = fsAvailableMemory;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Boolean getSpins() {
		return spins;
	}
	public void setSpins(Boolean spins) {
		this.spins = spins;
	}
}
