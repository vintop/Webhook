//$Id$
package com.zoho.abtest.elastic.adminconsole;

import java.util.List;
import java.util.logging.Logger;

public class ESAdminConsole 
{
	private static final Logger LOGGER = Logger.getLogger(ESAdminConsole.class.getName());
	
	private ESClusterDetails esClusterDetail;
	private List<ESIndexDetails> esIndexDetailList;
	private List<ESNodeDetails> esNodeDetailList;
	
	public List<ESNodeDetails> getEsNodeDetailList() {
		return esNodeDetailList;
	}
	public void setEsNodeDetailList(List<ESNodeDetails> esNodeDetailList) {
		this.esNodeDetailList = esNodeDetailList;
	}
	public ESClusterDetails getEsClusterDetail() {
		return esClusterDetail;
	}
	public void setEsClusterDetail(ESClusterDetails esClusterDetail) {
		this.esClusterDetail = esClusterDetail;
	}
	public List<ESIndexDetails> getEsIndexDetailList() {
		return esIndexDetailList;
	}
	public void setEsIndexDetailList(List<ESIndexDetails> esIndexDetailList) {
		this.esIndexDetailList = esIndexDetailList;
	}
	
	
	
}
