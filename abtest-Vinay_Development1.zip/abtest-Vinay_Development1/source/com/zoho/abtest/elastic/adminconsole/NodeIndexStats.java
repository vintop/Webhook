//$Id$
package com.zoho.abtest.elastic.adminconsole;

public class NodeIndexStats 
{
	private Long nodeIndexDocCount;
	private Long docDelCount;
	private Long flushTotal;
	private Long getCount;
	private Long getExistsCount;
	private Long getMissingCount;
	private Long storeSize;
	private Long searchQueryCount;
	private Long searchFetchCount;
	private Long indexCount;
	private Long indexFailedCount;
	
	public Long getNodeIndexDocCount() {
		return nodeIndexDocCount;
	}
	public void setNodeIndexDocCount(Long nodeIndexDocCount) {
		this.nodeIndexDocCount = nodeIndexDocCount;
	}
	public Long getDocDelCount() {
		return docDelCount;
	}
	public void setDocDelCount(Long docDelCount) {
		this.docDelCount = docDelCount;
	}
	public Long getFlushTotal() {
		return flushTotal;
	}
	public void setFlushTotal(Long flushTotal) {
		this.flushTotal = flushTotal;
	}
	public Long getGetCount() {
		return getCount;
	}
	public void setGetCount(Long getCount) {
		this.getCount = getCount;
	}
	public Long getGetExistsCount() {
		return getExistsCount;
	}
	public void setGetExistsCount(Long getExistsCount) {
		this.getExistsCount = getExistsCount;
	}
	public Long getGetMissingCount() {
		return getMissingCount;
	}
	public void setGetMissingCount(Long getMissingCount) {
		this.getMissingCount = getMissingCount;
	}
	public Long getStoreSize() {
		return storeSize;
	}
	public void setStoreSize(Long storeSize) {
		this.storeSize = storeSize;
	}
	public Long getSearchQueryCount() {
		return searchQueryCount;
	}
	public void setSearchQueryCount(Long searchQueryCount) {
		this.searchQueryCount = searchQueryCount;
	}
	public Long getSearchFetchCount() {
		return searchFetchCount;
	}
	public void setSearchFetchCount(Long searchFetchCount) {
		this.searchFetchCount = searchFetchCount;
	}
	public Long getIndexCount() {
		return indexCount;
	}
	public void setIndexCount(Long indexCount) {
		this.indexCount = indexCount;
	}
	public Long getIndexFailedCount() {
		return indexFailedCount;
	}
	public void setIndexFailedCount(Long indexFailedCount) {
		this.indexFailedCount = indexFailedCount;
	}
	
}
