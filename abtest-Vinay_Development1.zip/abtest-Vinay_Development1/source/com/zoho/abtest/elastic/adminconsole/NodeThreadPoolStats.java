//$Id$
package com.zoho.abtest.elastic.adminconsole;

public class NodeThreadPoolStats 
{
	private String statsName;
	private Integer totalCount;
	private Integer activeCount;
	private Long completedCount;
	private Integer queueCount;
	private Long rejectedCount;
	
	public String getStatsName() {
		return statsName;
	}
	public void setStatsName(String statsName) {
		this.statsName = statsName;
	}
	public Integer getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}
	public Integer getActiveCount() {
		return activeCount;
	}
	public void setActiveCount(Integer activeCount) {
		this.activeCount = activeCount;
	}
	public Long getCompletedCount() {
		return completedCount;
	}
	public void setCompletedCount(Long completedCount) {
		this.completedCount = completedCount;
	}
	public Integer getQueueCount() {
		return queueCount;
	}
	public void setQueueCount(Integer queueCount) {
		this.queueCount = queueCount;
	}
	public Long getRejectedCount() {
		return rejectedCount;
	}
	public void setRejectedCount(Long rejectedCount) {
		this.rejectedCount = rejectedCount;
	}
}
