//$Id$
package com.zoho.abtest.elastic;

import static com.zoho.abtest.funnel.report.FlexibleQueryConstants.PAINLESS;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;
import org.apache.lucene.search.join.ScoreMode;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.MatchQueryBuilder;
import org.elasticsearch.index.query.NestedQueryBuilder;
import org.elasticsearch.index.query.PrefixQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.index.query.RegexpQueryBuilder;
import org.elasticsearch.index.query.TermQueryBuilder;
import org.elasticsearch.index.query.TermsQueryBuilder;
import org.elasticsearch.script.Script;
import org.elasticsearch.script.ScriptType;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.cardinality.CardinalityAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.cardinality.InternalCardinality;
import org.elasticsearch.search.aggregations.metrics.sum.InternalSum;
import org.elasticsearch.search.aggregations.metrics.sum.SumAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.valuecount.InternalValueCount;
import org.elasticsearch.search.aggregations.metrics.valuecount.ValueCountAggregationBuilder;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.adventnet.iam.IAMUtil;
import com.zoho.abtest.audience.AudienceAttributeConstants.AudienceAttributeMatchTypes;
import com.zoho.abtest.dynamicconf.DynamicConfigurationConstants;
import com.zoho.abtest.dynamicconf.DynamicConfigurationUtil;
import com.zoho.abtest.experiment.ABSplitExperiment;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.funnel.report.FlexibleQueryConstants;
import com.zoho.abtest.goal.GoalConstants;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.report.ReportArchieveDimensionConstants;
import com.zoho.abtest.report.ReportConstants;
import com.zoho.abtest.report.ReportRawDataConstants;
import com.zoho.abtest.report.ReportStatistics;
import com.zoho.abtest.revenue.RevenueReport;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.abtest.variation.Variation;
import com.zoho.abtest.variation.VariationConstants;


public class ElasticSearchStatistics 
{
	private static final Logger LOGGER = Logger.getLogger(ElasticSearchStatistics.class.getName());
	
	public static ArrayList<ReportStatistics> getReportInformation(HashMap<String,String> hs) throws Exception
	{
		ArrayList<ReportStatistics> reports = new ArrayList<ReportStatistics>();
		try{
			String experimentLinkNmae = hs.get(ExperimentConstants.EXPERIMENT_LINKNAME);
			Experiment exp  = Experiment.getExperimentByLinkname(experimentLinkNmae);
			if(exp == null){
				ReportStatistics report = new ReportStatistics();
				report.setSuccess(Boolean.FALSE);
				reports.add(report);
				return reports;
			}
			Long experimentId = exp.getExperimentId();

			//TODO - check if segment type matches with column name 
			String segmentType= hs.get(ReportConstants.SEGMENT_TYPE);
			
			String reportType = hs.get(ReportConstants.REPORT_TYPE);
			String dynamicAttrLinkName = hs.get(ReportConstants.DYNAMIC_ATTRIBUTE_LINK_NAME);
			String startTime = hs.get(ReportConstants.START_DATE);
			String  endTime = hs.get(ReportConstants.END_DATE);
			String multisegmentCriteria = hs.get(ReportConstants.MULTISEGMENT_CRITERIA);
			Long startTimeInMillis = null;
			if(startTime!=null&&!startTime.isEmpty()){
				 startTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(startTime, "yyyy-MM-dd");		// NO I18N
			}
			
			Long endTimeInMillis = null;
			if(endTime!=null&&!endTime.isEmpty()){
				endTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(endTime, "yyyy-MM-dd");		// NO I18N
				//Get the long value end date's last milli second
				endTimeInMillis =  ZABUtil.getNthDayDateInLong(endTimeInMillis, 1) - 1;
			}
			
			String[] valueArray = null;
			
			String values = hs.get(ReportConstants.VALUES);
			String baseLine = hs.get(ReportConstants.BASELINE);
			if(values != null)
			{
				JSONArray array  = new JSONArray(values);
				valueArray = new String[array.length()];
				
				for(int i=0;i<array.length();i++){
					valueArray[i] = array.getString(i);
				}
			}
			
			List<Long> variationIds = new ArrayList<Long>();
			String variations =  hs.get(ReportConstants.VARIATIONS);
			if(variations==null){
				variationIds = ABSplitExperiment.getVariationsOfExperiment(experimentId);
			}else{
				
				JSONArray varLinkNames = new JSONArray(variations);
				varLinkNames.put(baseLine);
				String[] varLinkNamesArray = new String[varLinkNames.length()];
				for(int i=0;i<varLinkNames.length();i++){
					varLinkNamesArray[i] = (String) varLinkNames.get(i);
				}
				variationIds = Variation.getVariationIdsFromLinkNames(varLinkNamesArray);
			}
			
			
			reports = goalWiseReport(reportType,segmentType,experimentId,valueArray,startTimeInMillis,endTimeInMillis,dynamicAttrLinkName,multisegmentCriteria,baseLine,variationIds);
			
			
		}catch(Exception ex ){
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
		return reports;
	
	}
	
	public static ArrayList<ReportStatistics> goalWiseReport(String reportType, String segmentType, Long expId, String[] segmentValueCodes, Long startTime, Long endTime,String dynamicAttrLinkName,String multisegmentCriteria, String baseLine,List<Long> variationIds ) throws Exception
	{
		
		ArrayList<ReportStatistics> resultReport = new ArrayList<ReportStatistics>();
		
		ArrayList<HashMap<String, String>> visitorMeta = null;
		ArrayList<HashMap<String, String>> goalMeta = null;
		HashMap<Long , RevenueReport> revenueMeta  = new HashMap<Long , RevenueReport>();
		try
		{
			String portalName =null;
			try{
				 portalName = IAMUtil.getCurrentServiceOrg().getDomains().get(0).getDomain();
			}catch(Exception e){
				portalName = ZABUtil.getPortaldomain();
				if(portalName == null){
					return null;
				}
			}
			String indexName = ElasticSearchUtil.getIndexByPortal(portalName);
			
			Long revenueGoalId =ABSplitExperiment.getRevenueGoalOfExperiment(expId);
			Long timeSpentGoalId =  ABSplitExperiment.getTimeSpentGoalOfExperiment(expId);
			
			visitorMeta = getVisitorReportInformation(indexName, portalName, reportType, segmentType, expId, startTime, endTime, dynamicAttrLinkName, segmentValueCodes,multisegmentCriteria);
			goalMeta = getGoalReportInformation(indexName, portalName,reportType, segmentType, expId, startTime, endTime, dynamicAttrLinkName, segmentValueCodes,multisegmentCriteria);
			
			if(revenueGoalId!=null){
				revenueMeta = getRevenueGoalReportInformation(indexName, portalName, reportType, segmentType, expId, startTime, endTime, dynamicAttrLinkName, segmentValueCodes, multisegmentCriteria, revenueGoalId,variationIds);
			
			}
			if(timeSpentGoalId!=null){
				visitorMeta = getTimeSpentMetaInformation(indexName, portalName, reportType, segmentType, expId, startTime, endTime, dynamicAttrLinkName, segmentValueCodes,multisegmentCriteria,visitorMeta);
			}
			resultReport = ReportStatistics.goalWiseReport(visitorMeta, goalMeta, expId , baseLine, revenueMeta, revenueGoalId,variationIds);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
		
		return resultReport;
	
	}
	
	public static ArrayList<ReportStatistics> getOverviewReport(String experimentLinkName) throws Exception
	{
		String reportType = ReportConstants.OVERVIEW;
		ArrayList<ReportStatistics> resultReport = new ArrayList<ReportStatistics>();
		
		ArrayList<HashMap<String, String>> visitorMeta = null;
		ArrayList<HashMap<String, String>> goalMeta = null;
		HashMap<Long , RevenueReport> revenueMeta  = new HashMap<Long , RevenueReport>();
		try
		{
			Long expId  = Experiment.getExperimentId(experimentLinkName);
			List<Long> variationIds = ABSplitExperiment.getVariationsOfExperiment(expId);
			String portalName =null;
			try{
				 portalName = IAMUtil.getCurrentServiceOrg().getDomains().get(0).getDomain();
			}catch(Exception e){
				portalName = ZABUtil.getPortaldomain();
				if(portalName == null){
					return null;
				}
			}
			
			String indexName = ElasticSearchUtil.getIndexByPortal(portalName);
			Long revenueGoalId =ABSplitExperiment.getRevenueGoalOfExperiment(expId);
			Long timeSpentGoalId =  ABSplitExperiment.getTimeSpentGoalOfExperiment(expId);
			
			visitorMeta = getVisitorReportInformation(indexName, portalName, reportType, null, expId, null, null, null, null,null);
			goalMeta = getGoalReportInformation(indexName, portalName,reportType, null, expId, null, null, null, null,null);
			if(revenueGoalId!=null){
				revenueMeta = getRevenueGoalReportInformation(indexName, portalName, reportType, null, expId, null, null, null, null, null, revenueGoalId,variationIds);
			
			}
			if(timeSpentGoalId!=null){
				visitorMeta = getTimeSpentMetaInformation(indexName, portalName, reportType, null, expId, null, null, null, null,null,visitorMeta);
				
			}
			resultReport = ReportStatistics.goalWiseReport(visitorMeta, goalMeta, expId , null, revenueMeta, revenueGoalId,variationIds);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
		
		return resultReport;
	
	}
	
	public static ArrayList<HashMap<String, String>> getVisitorReportInformation(String indexName, String portal, String reportType, String segmentType, Long expId, Long startTime, Long endTime, String dynamicAttrLinkName, String[] values, String multisegmentCriteria)
	{
		ArrayList<HashMap<String, String>> visitorReportDetails;
		QueryBuilder query =  null;
		AggregationBuilder aggregation = null;
		int size = 0 ;
		try
		{
			if(reportType.equals(ReportConstants.OVERVIEW))
			{
				query = generateSourceQueryJson(portal,expId);
			}
			else if(reportType.equals(ReportConstants.SUMMARY))
			{
				query = generateSourceQueryJson(portal,expId,startTime,endTime,false,null,false,null,null);
			}
			else if(reportType.equals(ReportConstants.SEGMENT))
			{
				query = generateSourceSegmentQueryJson(portal,expId, startTime, endTime, segmentType, dynamicAttrLinkName, values,false,null,null);
			}
			else if(reportType.equals(ReportConstants.MULTISEGMENT))
			{
				query = generateSourceMultiSegmentQueryJson(portal,expId, startTime, endTime, multisegmentCriteria,false,null,null,null);
			}
			
			aggregation  =   generateVistorAggregateJson();
			SearchResponse response = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.VISITOR_RAW_TYPE, size, query, aggregation);
			//LOGGER.log(Level.INFO, "Search response" + response.toString());
			visitorReportDetails = readVisitResponseData(response);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage());
			visitorReportDetails = new ArrayList<HashMap<String, String>>();
		}
		return visitorReportDetails;
	}
	
	public static Long getExperimentVisitorCount(String portal, Long expId)
	{
		
		Long totalVisitors = 0l;
		try
		{
			String indexName = ElasticSearchUtil.getIndexByPortal(portal);
			int size = 0 ;
			Long visitorCount = 0l; 
			Long uuidVisitorCount = 0l;
			
			List<AggregationBuilder> aggrList = new ArrayList<AggregationBuilder>();


			QueryBuilder query =  generateSourceQueryJson(portal,expId);
			
			AggregationBuilder aggregation = getVisitorCardinalityAggr();
			AggregationBuilder uuidAggregation = getUUIDVisitorCardinalityAggr();
			
			aggrList.add(aggregation);
			aggrList.add(uuidAggregation);
			
			SearchResponse response = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.VISITOR_RAW_TYPE, size, query, aggrList);
			Aggregations visitorAggrResponse = response.getAggregations();
			InternalCardinality cardinality = visitorAggrResponse.get("distinct_visitors");
			visitorCount = cardinality.getValue();
			InternalCardinality uuidCardinality = visitorAggrResponse.get("distinct_uuid_visitors");
			uuidVisitorCount = uuidCardinality.getValue();
			totalVisitors = visitorCount + uuidVisitorCount;
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage());
			totalVisitors = 0l;
		}
		return totalVisitors;
	}
	
	public static ArrayList<HashMap<String, String>> getGoalReportInformation(String index, String portal, String reportType, String segmentType, Long expId, Long startTime, Long endTime, String dynamicAttrLinkName, String[] values, String multisegmentCriteria)
	{
		ArrayList<HashMap<String, String>> goalReportDetails;
		QueryBuilder query =  null;
		AggregationBuilder aggregation = null;
		int size = 0 ;
		try
		{
			if(reportType.equals(ReportConstants.OVERVIEW))
			{
				query = generateSourceQueryJson(portal,expId);
			}
			else if(reportType.equals(ReportConstants.SUMMARY))
			{
				query = generateSourceQueryJson(portal,expId,startTime,endTime,false,null,false,null,null);
			}
			else if(reportType.equals(ReportConstants.SEGMENT))
			{
				query = generateSourceSegmentQueryJson(portal,expId, startTime, endTime, segmentType, dynamicAttrLinkName, values,false,null,null);
			}
			else if(reportType.equals(ReportConstants.MULTISEGMENT))
			{
				query = generateSourceMultiSegmentQueryJson(portal,expId, startTime, endTime, multisegmentCriteria,false,null,null,null);
			}
			
			aggregation  =   generateGoalAggregateJson();
			SearchResponse response = ElasticSearchUtil.getData(index, ElasticSearchConstants.GOAL_RAW_TYPE, size, query, aggregation);
			//LOGGER.log(Level.INFO, "Search response" + response.toString());
			goalReportDetails = readGoalResponseData(response);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			goalReportDetails = new ArrayList<HashMap<String, String>>();
		}
		return goalReportDetails;
	}
	
	public static HashMap<Long , RevenueReport> getRevenueGoalReportInformation(String index, String portal, String reportType, String segmentType, Long expId, Long startTime, Long endTime, String dynamicAttrLinkName, String[] values, String multisegmentCriteria, Long revenueGoalId,List<Long> variationIds)
	{
		HashMap<Long , RevenueReport> revenueMeta;
		QueryBuilder query =  null;
		AggregationBuilder aggregation = null;
		int size = 0 ;
		try
		{
			if(reportType.equals(ReportConstants.OVERVIEW))
			{
				query = generateSourceQueryJson(portal,expId,startTime,endTime,true,revenueGoalId,true,null,null);
			}
			else if(reportType.equals(ReportConstants.SUMMARY))
			{
				query = generateSourceQueryJson(portal,expId,startTime,endTime,true,revenueGoalId,false,null,null);
			}
			else if(reportType.equals(ReportConstants.SEGMENT))
			{
				query = generateSourceSegmentQueryJson(portal,expId, startTime, endTime, segmentType, dynamicAttrLinkName, values,true,revenueGoalId,null);
			}
			else if(reportType.equals(ReportConstants.MULTISEGMENT))
			{
				query = generateSourceMultiSegmentQueryJson(portal,expId, startTime, endTime, multisegmentCriteria,true,revenueGoalId,null,null);
			}
			
			aggregation  =   generateRevenueGoalAggregateJson();
			SearchResponse response = ElasticSearchUtil.getData(index, ElasticSearchConstants.GOAL_RAW_TYPE, size, query, aggregation);
			//LOGGER.log(Level.INFO, "Search response" + response.toString());
			revenueMeta = readRevenueGoalResponseData(response,variationIds);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			revenueMeta =  new HashMap<Long , RevenueReport> ();
		}
		return revenueMeta;
	}
	
	public static BoolQueryBuilder generateSourceMultiSegmentQueryJson(String portal, Long expId, Long startTime, Long endTime, String multisegmentCriteria, boolean isRevenueGoal, Long revenueGoalId, Long goalId, Boolean isheatmapenabled)
	{
		BoolQueryBuilder queryBuilder = null;
		try
		{
			queryBuilder = generateSourceQueryJson(portal,expId, startTime, endTime,isRevenueGoal,revenueGoalId,false,goalId,isheatmapenabled);
			
			BoolQueryBuilder multiSegmentQuery = generateMultiSegmentCriteria(multisegmentCriteria);
			
			queryBuilder.must().add(multiSegmentQuery);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
		return queryBuilder;
	}
	
	public static BoolQueryBuilder generateSourceSegmentQueryJson( String portal, Long expId, Long startTime, Long endTime, String segment,String dynamicAttributeLinkName,String[] values, boolean isRevenueGoal, Long revenueGoalId, Long goalId)
	{
		BoolQueryBuilder boolQueryBuilder = null;
		try
		{
			if(segment.equals(ElasticSearchConstants.URLPARAMETER) || segment.equals(ElasticSearchConstants.COOKIE) || segment.equals(ElasticSearchConstants.JSVARIABLE) || segment.equals(ElasticSearchConstants.CUSTOMDIMENSION))
			{
				segment = segment + "." + dynamicAttributeLinkName;
			}
			
			boolQueryBuilder = generateSourceQueryJson(portal,expId, startTime, endTime,isRevenueGoal,revenueGoalId,false,goalId,null);
			TermsQueryBuilder segmentTerms= QueryBuilders.termsQuery(segment, values);
			boolQueryBuilder.must().add(segmentTerms);
					
			/*queryJson = generateSourceQueryJson(portal,expId, startTime, endTime,isRevenueGoal,revenueGoalId,false,goalId);
			JSONObject boolJson = queryJson.getJSONObject("bool"); //No I18N
			JSONArray mustArray = boolJson.getJSONArray("must"); //No I18N
			JSONObject segmentJson = new JSONObject();
			JSONObject segmentTermsJson = new JSONObject();
			JSONArray valueArray = new JSONArray();
			for(String value:values)
			{
				valueArray.put(value);
			}
			segmentTermsJson.put(segment, valueArray);
			segmentJson.put("terms", segmentTermsJson);
			mustArray.put(segmentJson);*/
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
		return boolQueryBuilder;
	}
	

	public static BoolQueryBuilder generateSourceQueryJson( String portal, Long expId )
	{
		BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
		
		try
		{
			/*JSONObject filterJson = new JSONObject();
			JSONObject boolJson = new JSONObject();
			JSONArray mustJsonArr = new JSONArray();
			JSONObject match0Json = new JSONObject();
			match0Json.put(ElasticSearchConstants.PORTAL, portal);
			JSONObject mustJsonObj0 = new JSONObject();
			mustJsonObj0.put("match", match0Json);
			JSONObject matchJson = new JSONObject();
			matchJson.put(ElasticSearchConstants.EXPERIMENTID, expId);
			JSONObject mustJsonObj1 = new JSONObject();
			mustJsonObj1.put("match", matchJson);
			mustJsonArr.put(mustJsonObj0);
			mustJsonArr.put(mustJsonObj1);
			boolJson.put("must", mustJsonArr);
			filterJson.put("bool", boolJson);*/
			
			MatchQueryBuilder portalMatch = QueryBuilders.matchQuery(ElasticSearchConstants.PORTAL, portal);
			MatchQueryBuilder expMatch = QueryBuilders.matchQuery(ElasticSearchConstants.EXPERIMENTID, expId);
			List<QueryBuilder> conditionList = new ArrayList<QueryBuilder>();
			conditionList.add(portalMatch);
			conditionList.add(expMatch);
			boolQueryBuilder.must().addAll(conditionList);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
		return boolQueryBuilder;
	}
	

	public static BoolQueryBuilder generateSourceQueryJson( String portal, Long expId, Long startTime, Long endTime, boolean isRevenueGoal, Long revenueGoalId, boolean isOverviewReport, Long goalId, Boolean isHeatmapEnabled)
	{
		BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
		
		
		try
		{
			MatchQueryBuilder portalMatch = QueryBuilders.matchQuery(ElasticSearchConstants.PORTAL, portal);
			MatchQueryBuilder expMatch = QueryBuilders.matchQuery(ElasticSearchConstants.EXPERIMENTID, expId);
			List<QueryBuilder> conditionList = new ArrayList<QueryBuilder>();
			conditionList.add(portalMatch);
			conditionList.add(expMatch);
			//If goal based report
			if(goalId != null)
			{
				MatchQueryBuilder goalMatch = QueryBuilders.matchQuery(ElasticSearchConstants.GOALID, goalId);
				conditionList.add(goalMatch);
			}
			//If for Revenue goal calculation - Add revenue goal Id filter
			if(isRevenueGoal)
			{
				MatchQueryBuilder revenueMatch = QueryBuilders.matchQuery(ElasticSearchConstants.GOALID, revenueGoalId);
				conditionList.add(revenueMatch);
			}
			
			if(isHeatmapEnabled!=null && isHeatmapEnabled.equals(Boolean.TRUE)){
				MatchQueryBuilder isheatmapenabled = QueryBuilders.matchQuery(ElasticSearchConstants.IS_HEATMAP_ENABLED,Boolean.TRUE);
				conditionList.add(isheatmapenabled);
			}
			if(!isOverviewReport && startTime != null && endTime != null)
			{
				RangeQueryBuilder timeRange = QueryBuilders.rangeQuery("time").gte(startTime).lte(endTime); // No I18N
				conditionList.add(timeRange);
			}
			boolQueryBuilder.must().addAll(conditionList);
			
			/*
			JSONObject boolJson = new JSONObject();
			JSONArray mustJsonArr = new JSONArray();
			JSONObject match0Json = new JSONObject();
			match0Json.put(ElasticSearchConstants.PORTAL, portal);
			JSONObject mustJsonObj0 = new JSONObject();
			mustJsonObj0.put("match", match0Json);
			JSONObject matchJson = new JSONObject();
			matchJson.put(ElasticSearchConstants.EXPERIMENTID, expId);
			JSONObject mustJsonObj1 = new JSONObject();
			mustJsonObj1.put("match", matchJson);
			JSONObject rangeJson = new JSONObject();
			JSONObject timeJson = new JSONObject();
			timeJson.put("gte", startTime);
			timeJson.put("lte", endTime);
			rangeJson.put("time", timeJson);
			JSONObject mustJsonObj2 = new JSONObject();
			mustJsonObj2.put("range", rangeJson);
			
			JSONObject match3Json = new JSONObject();
			match3Json.put(ElasticSearchConstants.GOALID, revenueGoalId);
			JSONObject mustJsonObj3 = new JSONObject();
			mustJsonObj3.put("match", match3Json);
			
			mustJsonArr.put(mustJsonObj0);
			mustJsonArr.put(mustJsonObj1);
			
			//If goal based report
			if(goalId != null)
			{
				JSONObject goalmatchJson = new JSONObject();
				goalmatchJson.put(ElasticSearchConstants.GOALID, goalId);
				JSONObject goalmustJsonObj4 = new JSONObject();
				goalmustJsonObj4.put("match", goalmatchJson);
				mustJsonArr.put(goalmustJsonObj4);
			}
			
			//If for Revenue goal calculation - Add revenue goal Id filter
			if(isRevenueGoal)
			{
				mustJsonArr.put(mustJsonObj3);
			}
			if(!isOverviewReport)
			{
				mustJsonArr.put(mustJsonObj2);
			}
			
			boolJson.put("must", mustJsonArr);
			
			filterJson.put("bool", boolJson);
			*/
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
		return boolQueryBuilder;
	}
	
	public static BoolQueryBuilder generateMultiSegmentCriteria(String criteriaObjectStr)
	{
		BoolQueryBuilder boolQueryBuilderlevel1 = QueryBuilders.boolQuery();
		try
		{
			
			List<BoolQueryBuilder> conditionqueryList = new ArrayList<BoolQueryBuilder>();
			
			JSONObject rootJsonObject = new JSONObject(criteriaObjectStr);
			String rootOperator = rootJsonObject.getString("condition_type"); //No I18N

			JSONArray rootJsonArr = rootJsonObject.getJSONArray("conditions"); //No I18N
			int rootArrSize = rootJsonArr.length();
			
			for(int i=0;i<rootArrSize;i++)
			{
				
				List<BoolQueryBuilder> subConditionqueryList = new ArrayList<BoolQueryBuilder>();
				
				JSONObject subJsonObject = rootJsonArr.getJSONObject(i);
				String subOperator = subJsonObject.getString("condition_type"); //No I18N
				JSONArray subJsonArr = subJsonObject.getJSONArray("conditions"); //No I18N
				
				int subArrSize = subJsonArr.length();
				
				for(int j=0;j<subArrSize;j++)
				{
					
					JSONObject atomicCondition = subJsonArr.getJSONObject(j);
					String dimension = atomicCondition.getString("type");  //No I18N
					String operator = atomicCondition.getString("operator");  //No I18N
					
					boolean isLocation = false;
					
					if(dimension.equals("day_of_week")){	//No I18N
						dimension = ElasticSearchConstants.DAYOFWEEK;
					}else if(dimension.equals("hour_of_the_day")){	//No I18N
						dimension = ElasticSearchConstants.HOUROFDAY;
					}else if(dimension.equals("current_url")){	//No I18N
						dimension = ElasticSearchConstants.CURRENTURL;
					}else if(dimension.equals("referral_url")){	//No I18N
						dimension = ElasticSearchConstants.REFFERERURL;
					}else if(dimension.equals("source")){
						dimension = ElasticSearchConstants.TRAFFICSOURCE;
					}else if(dimension.equals("visitor_type")){
						dimension = ElasticSearchConstants.USERTYPE;
					}else if(dimension.equals("location")){
						isLocation = true;
					}else if(dimension.equals("query_parameter")){
						dimension = ElasticSearchConstants.URLPARAMETER;
					}

					//Array of string values
					JSONArray valueArr = atomicCondition.getJSONArray("values");  //No I18N
					String[] valueStrArr  = new String[valueArr.length()];
					for(int valueIdex=0;valueIdex<valueArr.length();valueIdex++)
					{
						String value = null;
						if(dimension.equals(ElasticSearchConstants.CURRENTURL) || dimension.equals(ElasticSearchConstants.REFFERERURL) || 
								dimension.equals(ElasticSearchConstants.URLPARAMETER) || dimension.equals(ElasticSearchConstants.COOKIE) || dimension.equals(ElasticSearchConstants.JSVARIABLE) || dimension.equals(ElasticSearchConstants.CUSTOMDIMENSION))
						{
							value = valueArr.getString(valueIdex);
							if(dimension.equals(ElasticSearchConstants.CURRENTURL)){
								if(operator.equals(AudienceAttributeMatchTypes.EQUALS.getTypeId().toString()) || operator.equals(AudienceAttributeMatchTypes.NOT_EQUALS.getTypeId().toString())){
									value = value.replace("www.", ""); // NO I18N
									if(value.charAt(value.length()-1) == '/'){
										value =  value.substring(0, value.length()-1);
									}
								}
							}
						}else if(FlexibleQueryConstants.FIELD_VALUE_SWAPS.containsKey(dimension)) {
							HashMap<String, String> valueSwaps = FlexibleQueryConstants.FIELD_VALUE_SWAPS.get(dimension);
							String val = valueArr.getString(valueIdex);
							if(valueSwaps.containsKey(val)) {								
								value = valueSwaps.get(val);
							} else {
								value = valueArr.getString(valueIdex).toUpperCase();
							}
						}
						else
						{
							value = valueArr.getString(valueIdex).toUpperCase();
						}
						valueStrArr[valueIdex] = value;
					}
					
					String dynamicAttributeLinkName = "";
					if(atomicCondition.has(ReportConstants.ATTRIBUTE_NAME))
					{
						dynamicAttributeLinkName = atomicCondition.getString(ReportConstants.ATTRIBUTE_NAME);  //No I18N
					}
					boolean isDynamicAttr = false;
					String dimensionNamePath = ""; 
					String dimensionValuePath = ""; 
					if(dimension.equals(ElasticSearchConstants.URLPARAMETER) || dimension.equals(ElasticSearchConstants.COOKIE) || dimension.equals(ElasticSearchConstants.JSVARIABLE) || dimension.equals(ElasticSearchConstants.CUSTOMDIMENSION))
					{
						isDynamicAttr = true;
						//due to change in property name in ES
						dimension = "n" + dimension; //No I18N
						//dimension = dimension+"."+dynamicAttributeLinkName;
						dimensionNamePath = dimension+"."+ElasticSearchConstants.NAME;
						dimensionValuePath = dimension+"."+ElasticSearchConstants.VALUE;
					}
					
					if(FlexibleQueryConstants.FIELD_KEY_SWAPS.containsKey(dimension)) {
						dimension = FlexibleQueryConstants.FIELD_KEY_SWAPS.get(dimension);
					}
					
					if(FlexibleQueryConstants.FIELD_VALUE_SWAPS.containsKey(dimension)) {
						HashMap<String, String> valueSwaps = FlexibleQueryConstants.FIELD_VALUE_SWAPS.get(dimension);
						for(int k=0; k<valueStrArr.length; k++) {
							String value = valueStrArr[k].toLowerCase();
							if(valueSwaps.containsKey(value)) {								
								valueStrArr[k] = valueSwaps.get(value);
							}
						}
					}
					
					BoolQueryBuilder boolQueryBuilder = innerConditionBuilder(
							operator, dimension, valueStrArr, valueArr,
							isDynamicAttr, isLocation,
							dynamicAttributeLinkName, dimensionNamePath,
							dimensionValuePath);
					
					subConditionqueryList.add(boolQueryBuilder);
				}
				
				BoolQueryBuilder boolQueryBuilderlevel2 = QueryBuilders.boolQuery();
				
				switch(subOperator)
				{
				case "1":  //No I18N
					//must
					boolQueryBuilderlevel2.must().addAll(subConditionqueryList);
					break;
				case "2":  //No I18N
					//should
					boolQueryBuilderlevel2.should().addAll(subConditionqueryList);
					break;
				}
				
				conditionqueryList.add(boolQueryBuilderlevel2);
				
			}
			
			switch(rootOperator)
			{
			case "1":  //No I18N
				//must
				boolQueryBuilderlevel1.must().addAll(conditionqueryList);
				break;
			case "2":  //No I18N
				//should
				boolQueryBuilderlevel1.should().addAll(conditionqueryList);
				break;
			}
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
		return boolQueryBuilderlevel1;
	}
	
	public static BoolQueryBuilder innerConditionBuilder(String operator,
			String dimension,
			String[] valueStrArr,
			JSONArray valueArr,
			Boolean isDynamicAttr, Boolean isLocation,
			String dynamicAttributeLinkName,
			String dimensionNamePath, String dimensionValuePath) throws JSONException {
		BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
		AudienceAttributeMatchTypes mtype = AudienceAttributeMatchTypes.getAudienceMatchTypeById(Integer.parseInt(operator));
		String wildCard = ".*"; //No I18N
		
		String regexvalue = "";
		
		Boolean isNested = dimension.contains(".");
		String path = isNested? dimension.substring(0, dimension.lastIndexOf(".")):"";
		
		switch(mtype)
		{
		case EQUALS:
			//EQUALS
			if(isDynamicAttr)
			{
				MatchQueryBuilder paramNameQuery = QueryBuilders.matchQuery(dimensionNamePath, dynamicAttributeLinkName);
				TermsQueryBuilder paramValueQuery = QueryBuilders.termsQuery(dimensionValuePath, valueStrArr);
				List<QueryBuilder> paramList = new ArrayList<QueryBuilder>();
				paramList.add(paramNameQuery);
				paramList.add(paramValueQuery);
				BoolQueryBuilder conditionQueries = QueryBuilders.boolQuery();
				conditionQueries.must().addAll(paramList);
				NestedQueryBuilder nestedQuery = QueryBuilders.nestedQuery(dimension, conditionQueries, ScoreMode.None);
				boolQueryBuilder.must(nestedQuery);
			}
			else if(isLocation)
			{
				List<BoolQueryBuilder> locationQueryList = constructLocationBoolQuery(valueStrArr);
				boolQueryBuilder.should().addAll(locationQueryList);
			}
			else if(dimension.equals(ElasticSearchConstants.DAYOFWEEK) || dimension.equals(ElasticSearchConstants.HOUROFDAY)) {
				String scriptSnippet = dimension
						.equals(ElasticSearchConstants.DAYOFWEEK) ? ElasticSearchConstants.FILTER_DAY_OF_WEEK_SCRIPT
						: ElasticSearchConstants.FILTER_HOUR_OF_DAY_SCRIPT;
				
				HashMap<String, Object> params = new HashMap<String, Object>();
				params.put(ESQuickFilterConstants.TIMEZONE, ElasticSearchUtil.getCurrentUserTimezone());
				params.put(ESQuickFilterConstants.VALUES, ZABUtil.convertJSONArrayToArrayList(String.class, valueArr));
				params.put(ESQuickFilterConstants.FIELD, ElasticSearchConstants.TIME);
				Script script = new Script(ScriptType.INLINE, PAINLESS, scriptSnippet, params);
				boolQueryBuilder.must(QueryBuilders.scriptQuery(script));
			}
			else
			{
				TermsQueryBuilder termsQuery1 = QueryBuilders.termsQuery(dimension, valueStrArr);
				if(isNested) {	
					BoolQueryBuilder conditionQueries = QueryBuilders.boolQuery();
					conditionQueries.must(termsQuery1);
					NestedQueryBuilder nestedQuery = QueryBuilders.nestedQuery(path, conditionQueries, ScoreMode.None);
					boolQueryBuilder.must(nestedQuery);
				} else {
					boolQueryBuilder.must(termsQuery1);
				}
			}
			
			break;
		case NOT_EQUALS:
			//NOT EQUALS
			if(isDynamicAttr)
			{
				MatchQueryBuilder paramNameQuery = QueryBuilders.matchQuery(dimensionNamePath, dynamicAttributeLinkName);
				TermsQueryBuilder paramValueQuery = QueryBuilders.termsQuery(dimensionValuePath, valueStrArr);
				BoolQueryBuilder conditionQueries = QueryBuilders.boolQuery();
				conditionQueries.must().add(paramNameQuery);
				conditionQueries.mustNot().add(paramValueQuery);
				NestedQueryBuilder nestedQuery = QueryBuilders.nestedQuery(dimension, conditionQueries, ScoreMode.None);
				boolQueryBuilder.must(nestedQuery);
			}
			else if(isLocation)
			{
				List<BoolQueryBuilder> locationQueryList = constructLocationBoolQuery(valueStrArr);
				boolQueryBuilder.mustNot().addAll(locationQueryList);
			}
			else if(dimension.equals(ElasticSearchConstants.DAYOFWEEK) || dimension.equals(ElasticSearchConstants.HOUROFDAY)) {
				String scriptSnippet = dimension
						.equals(ElasticSearchConstants.DAYOFWEEK) ? ElasticSearchConstants.FILTER_DAY_OF_WEEK_SCRIPT
						: ElasticSearchConstants.FILTER_HOUR_OF_DAY_SCRIPT;
				
				HashMap<String, Object> params = new HashMap<String, Object>();
				params.put(ESQuickFilterConstants.TIMEZONE, ElasticSearchUtil.getCurrentUserTimezone());
				params.put(ESQuickFilterConstants.VALUES, ZABUtil.convertJSONArrayToArrayList(String.class, valueArr));
				params.put(ESQuickFilterConstants.FIELD, ElasticSearchConstants.TIME);
				Script script = new Script(ScriptType.INLINE, PAINLESS, scriptSnippet, params);
				boolQueryBuilder.mustNot(QueryBuilders.scriptQuery(script));
			}
			else
			{
				TermsQueryBuilder termsQuery2 = QueryBuilders.termsQuery(dimension, valueStrArr);
				
				if(isNested) {	
					BoolQueryBuilder conditionQueries = QueryBuilders.boolQuery();
					conditionQueries.mustNot(termsQuery2);
					NestedQueryBuilder nestedQuery = QueryBuilders.nestedQuery(path, conditionQueries, ScoreMode.None);
					boolQueryBuilder.must(nestedQuery);
				} else {					
					boolQueryBuilder.mustNot(termsQuery2);
				}
			}
			
			break;
		case REGEX:
			//REGEX EQUALS
			regexvalue = valueArr.getString(0);
			if(isDynamicAttr)
			{
				MatchQueryBuilder paramNameQuery = QueryBuilders.matchQuery(dimensionNamePath, dynamicAttributeLinkName);
				RegexpQueryBuilder paramValueQuery = QueryBuilders.regexpQuery(dimensionValuePath, regexvalue);
				List<QueryBuilder> paramList = new ArrayList<QueryBuilder>();
				paramList.add(paramNameQuery);
				paramList.add(paramValueQuery);
				BoolQueryBuilder conditionQueries = QueryBuilders.boolQuery();
				conditionQueries.must().addAll(paramList);
				NestedQueryBuilder nestedQuery = QueryBuilders.nestedQuery(dimension, conditionQueries, ScoreMode.None);
				boolQueryBuilder.must(nestedQuery);
			}
			else
			{
				RegexpQueryBuilder regexpQuery1 = QueryBuilders.regexpQuery(dimension, regexvalue);
				if(isNested) {
					BoolQueryBuilder conditionQueries = QueryBuilders.boolQuery();
					conditionQueries.must(regexpQuery1);
					NestedQueryBuilder nestedQuery = QueryBuilders.nestedQuery(path, conditionQueries, ScoreMode.None);
					boolQueryBuilder.must(nestedQuery);
				} else {
					boolQueryBuilder.must(regexpQuery1);
				}
				
			}
			
			break;
		case CONTAINS:
			//CONTAINS
			regexvalue = wildCard+valueArr.getString(0)+wildCard;
			if(isDynamicAttr)
			{
				MatchQueryBuilder paramNameQuery = QueryBuilders.matchQuery(dimensionNamePath, dynamicAttributeLinkName);
				RegexpQueryBuilder paramValueQuery = QueryBuilders.regexpQuery(dimensionValuePath, regexvalue);
				List<QueryBuilder> paramList = new ArrayList<QueryBuilder>();
				paramList.add(paramNameQuery);
				paramList.add(paramValueQuery);
				BoolQueryBuilder conditionQueries = QueryBuilders.boolQuery();
				conditionQueries.must().addAll(paramList);
				NestedQueryBuilder nestedQuery = QueryBuilders.nestedQuery(dimension, conditionQueries, ScoreMode.None);
				boolQueryBuilder.must(nestedQuery);
			}
			else
			{
				RegexpQueryBuilder regexpQuery2 = QueryBuilders.regexpQuery(dimension, regexvalue);
				
				if(isNested) {
					BoolQueryBuilder conditionQueries = QueryBuilders.boolQuery();
					conditionQueries.must(regexpQuery2);
					NestedQueryBuilder nestedQuery = QueryBuilders.nestedQuery(path, conditionQueries, ScoreMode.None);
					boolQueryBuilder.must(nestedQuery);
				} else {
					boolQueryBuilder.must(regexpQuery2);
				}
			}
			
			break;
		case DOESNOT_CONTAINS:
			//DOES NOT CONTAINS
			regexvalue = wildCard+valueArr.getString(0)+wildCard;
			if(isDynamicAttr)
			{
				MatchQueryBuilder paramNameQuery = QueryBuilders.matchQuery(dimensionNamePath, dynamicAttributeLinkName);
				RegexpQueryBuilder paramValueQuery = QueryBuilders.regexpQuery(dimensionValuePath, regexvalue);
				BoolQueryBuilder conditionQueries = QueryBuilders.boolQuery();
				conditionQueries.must().add(paramNameQuery);
				conditionQueries.mustNot().add(paramValueQuery);
				NestedQueryBuilder nestedQuery = QueryBuilders.nestedQuery(dimension, conditionQueries, ScoreMode.None);
				boolQueryBuilder.must(nestedQuery);
			}
			else
			{
				RegexpQueryBuilder regexpQuery3 = QueryBuilders.regexpQuery(dimension, regexvalue);
				if(isNested) {
					BoolQueryBuilder conditionQueries = QueryBuilders.boolQuery();
					conditionQueries.mustNot(regexpQuery3);
					NestedQueryBuilder nestedQuery = QueryBuilders.nestedQuery(path, conditionQueries, ScoreMode.None);
					boolQueryBuilder.must(nestedQuery);
				} else {					
					boolQueryBuilder.mustNot(regexpQuery3);
				}
			}
			
			break;
		case STARTS_WITH:
			//STARTS WITH
			regexvalue =valueArr.getString(0);
			if(isDynamicAttr)
			{
				MatchQueryBuilder paramNameQuery = QueryBuilders.matchQuery(dimensionNamePath, dynamicAttributeLinkName);
				PrefixQueryBuilder paramValueQuery = QueryBuilders.prefixQuery(dimensionValuePath, regexvalue);
				List<QueryBuilder> paramList = new ArrayList<QueryBuilder>();
				paramList.add(paramNameQuery);
				paramList.add(paramValueQuery);
				BoolQueryBuilder conditionQueries = QueryBuilders.boolQuery();
				conditionQueries.must().addAll(paramList);
				NestedQueryBuilder nestedQuery = QueryBuilders.nestedQuery(dimension, conditionQueries, ScoreMode.None);
				boolQueryBuilder.must(nestedQuery);
			}
			else
			{
				PrefixQueryBuilder prefixQuery1 = QueryBuilders.prefixQuery(dimension, regexvalue);
				if(isNested) {
					BoolQueryBuilder conditionQueries = QueryBuilders.boolQuery();
					conditionQueries.must(prefixQuery1);
					NestedQueryBuilder nestedQuery = QueryBuilders.nestedQuery(path, conditionQueries, ScoreMode.None);
					boolQueryBuilder.must(nestedQuery);
				} else {
					boolQueryBuilder.must(prefixQuery1);
				}
			}
			
			break;
		case ENDS_WITH:
			//ENDS WITH
			regexvalue = wildCard+valueArr.getString(0);
			if(isDynamicAttr)
			{
				MatchQueryBuilder paramNameQuery = QueryBuilders.matchQuery(dimensionNamePath, dynamicAttributeLinkName);
				RegexpQueryBuilder paramValueQuery = QueryBuilders.regexpQuery(dimensionValuePath, regexvalue);
				List<QueryBuilder> paramList = new ArrayList<QueryBuilder>();
				paramList.add(paramNameQuery);
				paramList.add(paramValueQuery);
				BoolQueryBuilder conditionQueries = QueryBuilders.boolQuery();
				conditionQueries.must().addAll(paramList);
				NestedQueryBuilder nestedQuery = QueryBuilders.nestedQuery(dimension, conditionQueries, ScoreMode.None);
				boolQueryBuilder.must(nestedQuery);
			}
			else
			{
				RegexpQueryBuilder regexpQuery4 = QueryBuilders.regexpQuery(dimension, regexvalue);
				if(isNested) {
					BoolQueryBuilder conditionQueries = QueryBuilders.boolQuery();
					conditionQueries.must(regexpQuery4);
					NestedQueryBuilder nestedQuery = QueryBuilders.nestedQuery(path, conditionQueries, ScoreMode.None);
					boolQueryBuilder.must(nestedQuery);
				} else {
					boolQueryBuilder.must(regexpQuery4);					
				}
			}
			
			break;
		}
		return boolQueryBuilder;
	}
	
	public static List<BoolQueryBuilder> constructLocationBoolQuery(String[] valueStrArr)
	{
		List<BoolQueryBuilder> boolQueryList = new ArrayList<BoolQueryBuilder>();
		try
		{
			int arrLength = valueStrArr.length;
			for(int i=0;i<arrLength;i++)
			{
				String location = valueStrArr[i];
				BoolQueryBuilder boolQuery = QueryBuilders.boolQuery();
				List<TermQueryBuilder> termList = new ArrayList<TermQueryBuilder>(); 
				String[] cityArr = location.split(",");
				int valueIndex = 0;
				//Don't put case break;
				switch(cityArr.length)
				{
				case 3:
					String city = cityArr[valueIndex++];
					if(city!=null && !city.trim().isEmpty()) {						
						termList.add(QueryBuilders.termQuery(ElasticSearchConstants.CITY, city));
					}
				case 2:
					String state = cityArr[valueIndex++];
					if(state!=null && !state.trim().isEmpty()) {						
						termList.add(QueryBuilders.termQuery(ElasticSearchConstants.REGION, state));
					}
				case 1:
					String country = cityArr[valueIndex++];
					if(country!=null && !country.trim().isEmpty()) {								
						termList.add(QueryBuilders.termQuery(ElasticSearchConstants.COUNTRY, country));
					}
				}
				boolQuery.must().addAll(termList);
				boolQueryList.add(boolQuery);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			boolQueryList = new ArrayList<BoolQueryBuilder>();
		}
		return boolQueryList;
	}
	
	public static CardinalityAggregationBuilder getVisitorCardinalityAggr()
	{
		int precisionThreshold = DynamicConfigurationConstants.ES_CARDINALITY_THRESHOLD_VALUE;
		String thresholdStr = DynamicConfigurationUtil.getDynamicPropertyValueByName(DynamicConfigurationConstants.ES_CARDINALITY_THRESHOLD);
		if(StringUtils.isNotEmpty(thresholdStr))
		{
			precisionThreshold = Integer.parseInt(thresholdStr);
		}
		
		CardinalityAggregationBuilder cardinalityAggregation = AggregationBuilders.cardinality("distinct_visitors").  // No I18N
																field(ElasticSearchConstants.VISITORID).
																precisionThreshold(precisionThreshold);
		return cardinalityAggregation;
	}
	
	public static CardinalityAggregationBuilder getUUIDVisitorCardinalityAggr()
	{
		int precisionThreshold = DynamicConfigurationConstants.ES_CARDINALITY_THRESHOLD_VALUE;
		String thresholdStr = DynamicConfigurationUtil.getDynamicPropertyValueByName(DynamicConfigurationConstants.ES_CARDINALITY_THRESHOLD);
		if(StringUtils.isNotEmpty(thresholdStr))
		{
			precisionThreshold = Integer.parseInt(thresholdStr);
		}
		
		CardinalityAggregationBuilder cardinalityAggregation = AggregationBuilders.cardinality("distinct_uuid_visitors").  // No I18N
																field(ElasticSearchConstants.UUID).
																precisionThreshold(precisionThreshold);
		return cardinalityAggregation;
	}
	
	public static CardinalityAggregationBuilder getSRVisitorsCardinalityAggr()
	{
		int precisionThreshold = DynamicConfigurationConstants.ES_CARDINALITY_THRESHOLD_VALUE;
		String thresholdStr = DynamicConfigurationUtil.getDynamicPropertyValueByName(DynamicConfigurationConstants.ES_CARDINALITY_THRESHOLD);
		if(StringUtils.isNotEmpty(thresholdStr))
		{
			precisionThreshold = Integer.parseInt(thresholdStr);
		}
		
		CardinalityAggregationBuilder cardinalityAggregation = AggregationBuilders.cardinality("distinct_visitors").  // No I18N
																field(ElasticSearchConstants.SESSION_ID).
																precisionThreshold(precisionThreshold);
		return cardinalityAggregation;
	}
	
	public static TermsAggregationBuilder getPortalDataAggr() {
		TermsAggregationBuilder agg = AggregationBuilders.terms("portal_entries").field(ElasticSearchConstants.PORTAL);  // No I18N
		return agg;
	}
	
	public static CardinalityAggregationBuilder getFunnelSessionCardinalityAggr()
	{
		int precisionThreshold = DynamicConfigurationConstants.ES_CARDINALITY_THRESHOLD_VALUE;
		String thresholdStr = DynamicConfigurationUtil.getDynamicPropertyValueByName(DynamicConfigurationConstants.ES_CARDINALITY_THRESHOLD);
		if(StringUtils.isNotEmpty(thresholdStr))
		{
			precisionThreshold = Integer.parseInt(thresholdStr);
		}
		
		CardinalityAggregationBuilder cardinalityAggregation = AggregationBuilders.cardinality("distinct_sessions").  // No I18N
																field(ElasticSearchConstants.SESSION_ID).
																precisionThreshold(precisionThreshold);
		return cardinalityAggregation;
	}
	
	public static TermsAggregationBuilder generateVistorAggregateJson()
	{
		TermsAggregationBuilder finalAggr = null;
		try
		{
			
			CardinalityAggregationBuilder cardinalityAggregation = getVisitorCardinalityAggr();
			CardinalityAggregationBuilder uuidCardinalityAggregation = getUUIDVisitorCardinalityAggr();
			
			finalAggr = AggregationBuilders.terms("variations").  // No I18N
							field(ElasticSearchConstants.VARIATIONID).
							size(ElasticSearchConstants.VARIATION_MAX_COUNT).
								subAggregation(cardinalityAggregation).subAggregation(uuidCardinalityAggregation);
			
			/*JSONObject variationJson = new JSONObject();
			JSONObject termsJson = new JSONObject();
			termsJson.put("field", ElasticSearchConstants.VARIATIONID);
			termsJson.put("size", ElasticSearchConstants.VARIATION_MAX_COUNT);
			variationJson.put("terms", termsJson);
			JSONObject innerAggrJson = new JSONObject();
			JSONObject distinctVisitorJson = new JSONObject();
			JSONObject cardinalityJson = new JSONObject();
			cardinalityJson.put("field", ElasticSearchConstants.VISITORID);
			cardinalityJson.put("precision_threshold", precisionThreshold);
			distinctVisitorJson.put("cardinality", cardinalityJson);
			innerAggrJson.put("distinct_visitors", distinctVisitorJson);
			variationJson.put("aggs", innerAggrJson);
			aggrJson.put("variations", variationJson);*/
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
		return finalAggr;
	}
	
	public static TermsAggregationBuilder generateGoalAggregateJson()
	{
		TermsAggregationBuilder finalAggr = null;
		try
		{
			int precisionThreshold = DynamicConfigurationConstants.ES_CARDINALITY_THRESHOLD_VALUE;
			String thresholdStr = DynamicConfigurationUtil.getDynamicPropertyValueByName(DynamicConfigurationConstants.ES_CARDINALITY_THRESHOLD);
			if(StringUtils.isNotEmpty(thresholdStr))
			{
				precisionThreshold = Integer.parseInt(thresholdStr);
			}
			
			TermsAggregationBuilder goalAggr = AggregationBuilders.terms("goals").  // No I18N
													field(ElasticSearchConstants.GOALID).
													size(ElasticSearchConstants.GOAL_MAX_COUNT);
			
			CardinalityAggregationBuilder cardinalityAggregation = AggregationBuilders.cardinality("distinct_visitors").  // No I18N
																	field(ElasticSearchConstants.VISITORID).
																	precisionThreshold(precisionThreshold);
			
			CardinalityAggregationBuilder uuidCardinalityAggregation = getUUIDVisitorCardinalityAggr();
				
			finalAggr = AggregationBuilders.terms("variations").  // No I18N
							field(ElasticSearchConstants.VARIATIONID).
							size(ElasticSearchConstants.VARIATION_MAX_COUNT).
								subAggregation(goalAggr.subAggregation(cardinalityAggregation).subAggregation(uuidCardinalityAggregation));
			
			/*JSONObject variationJson = new JSONObject();
			JSONObject termsJson = new JSONObject();
			termsJson.put("field", ElasticSearchConstants.VARIATIONID);
			termsJson.put("size", ElasticSearchConstants.VARIATION_MAX_COUNT);
			variationJson.put("terms", termsJson);
			
			JSONObject innerAggrJson1 = new JSONObject();
			JSONObject goalsJson = new JSONObject();
			JSONObject gtermsJson = new JSONObject();
			gtermsJson.put("field", ElasticSearchConstants.GOALID);
			gtermsJson.put("size", ElasticSearchConstants.GOAL_MAX_COUNT);
			goalsJson.put("terms", gtermsJson);
			
			JSONObject innerAggrJson2 = new JSONObject();
			JSONObject distinctVisitorJson = new JSONObject();
			JSONObject cardinalityJson = new JSONObject();
			cardinalityJson.put("field", ElasticSearchConstants.VISITORID);
			cardinalityJson.put("precision_threshold",precisionThreshold);
			distinctVisitorJson.put("cardinality", cardinalityJson);
			innerAggrJson2.put("distinct_visitors", distinctVisitorJson);
			
			goalsJson.put("aggs", innerAggrJson2);
			innerAggrJson1.put("goals", goalsJson);
			variationJson.put("aggs", innerAggrJson1);
			aggrJson.put("variations", variationJson);*/
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
		return finalAggr;
	}
	
	public static TermsAggregationBuilder generateRevenueGoalAggregateJson()
	{
		TermsAggregationBuilder finalAggr = null;
		try
		{
			
			SumAggregationBuilder sumAggr = AggregationBuilders.sum("total_revenue").field(ElasticSearchConstants.REVENUE); // No I18N
			ValueCountAggregationBuilder valuecountAggr = AggregationBuilders.count("total_purchases").field(ElasticSearchConstants.VISITORID); // No I18N
			ValueCountAggregationBuilder valueUuidCountAggr = AggregationBuilders.count("uuid_total_purchases").field(ElasticSearchConstants.UUID); // No I18N

			
			finalAggr = AggregationBuilders.terms("variations").  // No I18N
							field(ElasticSearchConstants.VARIATIONID).
							size(ElasticSearchConstants.VARIATION_MAX_COUNT).
								subAggregation(sumAggr).subAggregation(valuecountAggr).subAggregation(valueUuidCountAggr);
			
			/*
			JSONObject variationJson = new JSONObject();
			JSONObject termsJson = new JSONObject();
			termsJson.put("field", ElasticSearchConstants.VARIATIONID);
			termsJson.put("size", ElasticSearchConstants.VARIATION_MAX_COUNT);
			variationJson.put("terms", termsJson);
			
			JSONObject innerAggrJson1 = new JSONObject();
			
			JSONObject totalRevenueJson = new JSONObject();
			JSONObject sumJson = new JSONObject();
			sumJson.put("field", ElasticSearchConstants.REVENUE);
			totalRevenueJson.put("sum", sumJson);
			innerAggrJson1.put("total_revenue", totalRevenueJson);
			
			JSONObject totalPurchasesJson = new JSONObject();
			JSONObject valueCountJson = new JSONObject();
			valueCountJson.put("field", ElasticSearchConstants.VISITORID);
			totalPurchasesJson.put("value_count", valueCountJson);
			innerAggrJson1.put("total_purchases", totalPurchasesJson);
			
			variationJson.put("aggs", innerAggrJson1);
			aggrJson.put("variations", variationJson);*/
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
		return finalAggr;
	}
	public static TermsAggregationBuilder generateTimeSpentAggregateJson()
	{
		
		TermsAggregationBuilder finalAggr = null;
		try
		{
			
			SumAggregationBuilder sumAggr = AggregationBuilders.sum("time_spent").field(ElasticSearchConstants.TIME_SPENT); // No I18N
			ValueCountAggregationBuilder valuecountAggr = AggregationBuilders.count("total_visitors").field(ElasticSearchConstants.VISITORID); // No I18N
			ValueCountAggregationBuilder uuidvaluecountAggr = AggregationBuilders.count("uuid_total_visitors").field(ElasticSearchConstants.UUID); // No I18N

			
			finalAggr = AggregationBuilders.terms("variations").  // No I18N
							field(ElasticSearchConstants.VARIATIONID).
							size(ElasticSearchConstants.VARIATION_MAX_COUNT).
								subAggregation(sumAggr).subAggregation(valuecountAggr).subAggregation(uuidvaluecountAggr);
			
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
		return finalAggr;
	}
	
	public static ArrayList<HashMap<String, String>> getTimeSpentMetaInformation(String indexName, String portal, String reportType, String segmentType, Long expId, Long startTime, Long endTime, String dynamicAttrLinkName, String[] values, String multisegmentCriteria,ArrayList<HashMap<String, String>> visitorMeta)
	{

		ArrayList<HashMap<String, String>> timeSpentDetails;
		QueryBuilder query =  null;
		AggregationBuilder aggregation = null;
		int size = 0 ;
		try
		{
			if(reportType.equals(ReportConstants.OVERVIEW))
			{
				query = generateSourceQueryJson(portal,expId);
			}
			else if(reportType.equals(ReportConstants.SUMMARY))
			{
				query = generateSourceQueryJson(portal,expId,startTime,endTime,false,null,false,null,null);
			}
			else if(reportType.equals(ReportConstants.SEGMENT))
			{
				query = generateSourceSegmentQueryJson(portal,expId, startTime, endTime, segmentType, dynamicAttrLinkName, values,false,null,null);
			}
			else if(reportType.equals(ReportConstants.MULTISEGMENT))
			{
				query = generateSourceMultiSegmentQueryJson(portal,expId, startTime, endTime, multisegmentCriteria,false,null,null,null);
			}
			
			aggregation  =   generateTimeSpentAggregateJson();
			SearchResponse response = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.VISITOR_RAW_TYPE, size, query, aggregation);
		
			timeSpentDetails = readTimeSpentResponseData(response,visitorMeta);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage());
			timeSpentDetails = new ArrayList<HashMap<String, String>>();
		}
		return timeSpentDetails;
	}
	
	public static ArrayList<HashMap<String, String>> readVisitResponseData(SearchResponse response)
	{
		ArrayList<HashMap<String, String>> visitorReportDetails = new ArrayList<HashMap<String, String>>();
		try
		{
			Aggregations aggrResponse = response.getAggregations();
			Terms terms = aggrResponse.get("variations");
			List<? extends Bucket> buckets = terms.getBuckets();
			for(Bucket bucket:buckets)
			{
				Long variationId = (Long)bucket.getKey();
				Long uniqueCount = 0l;
				Long uuidUniqueCount = 0l;
				Aggregations buckaggrResponse = bucket.getAggregations();
				InternalCardinality cardinality = buckaggrResponse.get("distinct_visitors");
				uniqueCount = cardinality.getValue();
				InternalCardinality uuidCardinality = buckaggrResponse.get("distinct_uuid_visitors");
				uuidUniqueCount = uuidCardinality.getValue();
				Long totalCount = uniqueCount + uuidUniqueCount;
				HashMap<String, String> hs = new HashMap<String,String>();
				hs.put(VariationConstants.VARIATION_ID, variationId.toString());
				hs.put(ReportArchieveDimensionConstants.UNIQUE_COUNT, totalCount.toString());
				visitorReportDetails.add(hs);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			visitorReportDetails = new ArrayList<HashMap<String, String>>();
		}
		return visitorReportDetails;
	}
	
	public static ArrayList<HashMap<String, String>> readGoalResponseData(SearchResponse response)
	{
		ArrayList<HashMap<String, String>> goalReportDetails = new ArrayList<HashMap<String, String>>();
		try
		{
			Aggregations aggrResponse = response.getAggregations();
			Terms terms = aggrResponse.get("variations");
			List<? extends Bucket> buckets = terms.getBuckets();
			for(Bucket bucket:buckets)
			{
				Long variationId = (Long)bucket.getKey();
				Aggregations buckaggrResponse = bucket.getAggregations();
				Terms goalterms = buckaggrResponse.get("goals");
				List<? extends Bucket> goalbuckets = goalterms.getBuckets();
				for(Bucket goalbucket:goalbuckets)
				{
					Long goalId = (Long)goalbucket.getKey();
					Long uniqueCount = 0l;
					Long uuidVisitorsCount = 0l;
					Aggregations goalaggrResponse = goalbucket.getAggregations();
					
					InternalCardinality cardinality = goalaggrResponse.get("distinct_visitors");
					uniqueCount = cardinality.getValue();
					
					InternalCardinality uuidCardinality = goalaggrResponse.get("distinct_uuid_visitors");
					uuidVisitorsCount = uuidCardinality.getValue();
					
					Long totalCount = uniqueCount + uuidVisitorsCount;
					
					HashMap<String, String> hs = new HashMap<String,String>();
					hs.put(VariationConstants.VARIATION_ID, variationId.toString());
					hs.put(GoalConstants.GOAL_ID, goalId.toString());
					hs.put(ReportArchieveDimensionConstants.UNIQUE_COUNT, totalCount.toString());
					goalReportDetails.add(hs);
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			goalReportDetails = new ArrayList<HashMap<String, String>>();
		}
		return goalReportDetails;
	}
	
	public static HashMap<Long , RevenueReport> readRevenueGoalResponseData(SearchResponse response,List<Long> variationIds)
	{
		HashMap<Long , RevenueReport> revenueMeta =  new HashMap<Long , RevenueReport> ();
		try
		{
			//Populating default meta for all variations
			for(int i = 0;i<variationIds.size();i++){
				Long varid = variationIds.get(i);
				
				RevenueReport report= new RevenueReport();
				report.setVisitors(0l);
				report.setRevenue(0d);
				report.setUniquePayingVisitors(0l);
				report.setTotalPurchases(0l);
				revenueMeta.put(varid, report);
			}
			
			Aggregations aggrResponse = response.getAggregations();
			Terms terms = aggrResponse.get("variations");
			List<? extends Bucket> buckets = terms.getBuckets();
			for(Bucket bucket:buckets)
			{
				Long variationId = (Long)bucket.getKey();
				Aggregations buckaggrResponse = bucket.getAggregations();
				
				Long uniqueCount = 0l;
				/*InternalCardinality cardinality = buckaggrResponse.get("distinct_visitors");
				uniqueCount = cardinality.getValue();*/
				
				Double totalRevenue = 0d;
				InternalSum sum = buckaggrResponse.get("total_revenue");
				totalRevenue = sum.getValue();
				
				Long totalCount = 0l;
				InternalValueCount valueCount = buckaggrResponse.get("total_purchases");
				totalCount = valueCount.getValue();
				
				InternalValueCount uuidTotalPurchases = buckaggrResponse.get("uuid_total_purchases");
				Long uuidTotalCount = uuidTotalPurchases.getValue();
				
				Long totalPurchases = totalCount + uuidTotalCount;
				
				RevenueReport revenueReport = revenueMeta.get(variationId);
				//revenueReport.setUniquePayingVisitors(uniqueCount);
				if(revenueReport != null)
				{
					revenueReport.setTotalPurchases(totalPurchases);
					revenueReport.setRevenue(totalRevenue/100);
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			revenueMeta =  new HashMap<Long , RevenueReport> ();
		}
		return revenueMeta;
	}
	
	public static ArrayList<HashMap<String, String>> readTimeSpentResponseData(SearchResponse response,ArrayList<HashMap<String, String>> visitorMeta)
	{
		 HashMap<String, String> tempHs = new HashMap<String,String>();
		try
		{
			
			Aggregations aggrResponse = response.getAggregations();
			Terms terms = aggrResponse.get("variations");
			List<? extends Bucket> buckets = terms.getBuckets();
			for(Bucket bucket:buckets)
			{
				Long variationId = (Long)bucket.getKey();
				Aggregations buckaggrResponse = bucket.getAggregations();
			
				Double totalTimeSpent = 0d;
				InternalSum sum = buckaggrResponse.get("time_spent");
				totalTimeSpent = sum.getValue();
				
				Long totalCount = 0l;
				InternalValueCount valueCount = buckaggrResponse.get("total_visitors");
				totalCount = valueCount.getValue();
				
				InternalValueCount uuidCount = buckaggrResponse.get("uuid_total_visitors");
				Long uuidTotalCount = uuidCount.getValue();
				
				Long totalVisitorsCount = totalCount + uuidTotalCount;
				tempHs.put(variationId.toString(), totalTimeSpent.longValue()+":"+totalVisitorsCount);
				
			}
			for(int i=0;i<visitorMeta.size();i++){
				HashMap<String, String> hs = visitorMeta.get(i);
				String variationId = hs.get(VariationConstants.VARIATION_ID);
				if(tempHs.containsKey(variationId)){
					String val = tempHs.get(variationId);
					StringTokenizer  str =  new StringTokenizer(val, ":");
					String timespent = str.nextToken();
					String totalvisitors = str.nextToken();
					hs.put(ReportRawDataConstants.TIME_SPENT, timespent);
					hs.put(ReportArchieveDimensionConstants.TOTAL_COUNT, totalvisitors);
					tempHs.remove(variationId);
				}
		
			}	
			if(tempHs.size()>0){
				Set<String> keySet = tempHs.keySet();
				Iterator<?> itr  = keySet.iterator();
				while(itr.hasNext()){
					String varId = (String) itr.next();
					String val = tempHs.get(varId);
					StringTokenizer  str =  new StringTokenizer(val, ":");
					String timespent = str.nextToken();
					String totalvisitors = str.nextToken();
					
					HashMap<String,String> newhs = new HashMap<String,String>();
					newhs.put(VariationConstants.VARIATION_ID, varId.toString());
					newhs.put(ReportArchieveDimensionConstants.UNIQUE_COUNT, "0");
					newhs.put(ReportArchieveDimensionConstants.TOTAL_COUNT, totalvisitors.toString());
					newhs.put(ReportRawDataConstants.TIME_SPENT, timespent);
					visitorMeta.add(newhs);
				}
				
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
		return visitorMeta;
	}
}
