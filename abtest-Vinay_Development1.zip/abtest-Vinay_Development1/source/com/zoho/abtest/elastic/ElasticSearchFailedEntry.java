//$Id$
package com.zoho.abtest.elastic;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.script.Script;
import org.elasticsearch.script.ScriptType;
import org.json.JSONArray;
import org.json.JSONObject;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.ES_FAILED_ENTRY;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.elastic.ElasticSearchIndexConstants.ESOpertaionType;
import com.zoho.abtest.report.ElasticSearchConstants;

public class ElasticSearchFailedEntry extends ZABModel
{
	
	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = Logger.getLogger(ElasticSearchFailedEntry.class.getName());
	
	private Long entryId;
	private String indexName;
	private String type;
	private String jsonString;
	private String docId;
	private Integer operationType;
	private String exceptionMsg;
	
	public Long getEntryId() {
		return entryId;
	}
	public void setEntryId(Long entryId) {
		this.entryId = entryId;
	}
	public String getIndexName() {
		return indexName;
	}
	public void setIndexName(String indexName) {
		this.indexName = indexName;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getJsonString() {
		return jsonString;
	}
	public void setJsonString(String jsonString) {
		this.jsonString = jsonString;
	}
	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public Integer getOperationType() {
		return operationType;
	}
	public void setOperationType(Integer operationType) {
		this.operationType = operationType;
	}
	public String getExceptionMsg() {
		return exceptionMsg;
	}
	public void setExceptionMsg(String exceptionMsg) {
		this.exceptionMsg = exceptionMsg;
	}
	
	public static void createElasticSearchFailedEntry(HashMap<String, String> hs) throws Exception
	{
		try
		{
			ZABModel.createRow(ElasticSearchIndexConstants.ES_FAILED_ENTRY_CONSTANTS, ES_FAILED_ENTRY.TABLE, hs);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
	}
	
	public static void processESFailedEntry()
	{
		try
		{
			Criteria criteria = new Criteria(new Column(ES_FAILED_ENTRY.TABLE, ES_FAILED_ENTRY.OPERATION_TYPE), new Integer[]{ESOpertaionType.CREATE.getOperationType(),ESOpertaionType.UPDATE.getOperationType()}, QueryConstants.IN);
			DataObject dataObj = ZABModel.getRow(ES_FAILED_ENTRY.TABLE, criteria);
			Iterator<?> iterator = dataObj.getRows(ES_FAILED_ENTRY.TABLE);
			while(iterator.hasNext())
			{
				Row row = (Row)iterator.next();
				String indexName = (String)row.get(ES_FAILED_ENTRY.INDEX_NAME);
				String type = (String)row.get(ES_FAILED_ENTRY.TYPE);
				String jsonString = (String)row.get(ES_FAILED_ENTRY.JSON_STRING); 
				String docId = (String)row.get(ES_FAILED_ENTRY.DOC_ID);
				Integer operationType = (Integer)row.get(ES_FAILED_ENTRY.OPERATION_TYPE);
				if(type != null && type.equals(ElasticSearchConstants.FUNNEL_RAW_TYPE))
				{
					Script updateScript = generateFunnelScript(jsonString);
					ElasticSearchUtil.upsertIndex(indexName, type, docId, jsonString, updateScript);
				}
				else if(type != null && (type.equals(ElasticSearchConstants.FORM_ANALYTICS_RAW_TYPE) || type.equals(ElasticSearchConstants.FORM_ANALYTICS_FIELDS_RAW_TYPE)))
				{
					ElasticSearchUtil.upsertIndex(indexName, type, docId, jsonString);
				}
				else
				{
					if(ESOpertaionType.CREATE.getOperationType().equals(operationType))
					{
						ElasticSearchUtil.createIndex(indexName, type, jsonString);
					}
					else if(ESOpertaionType.UPDATE.getOperationType().equals(operationType))
					{
						ElasticSearchUtil.updateIndex(indexName, type, docId, jsonString);
					}
				}
				Long entryId = (Long)row.get(ES_FAILED_ENTRY.ENTRY_ID);
				Criteria criteria1 = new Criteria(new Column(ES_FAILED_ENTRY.TABLE, ES_FAILED_ENTRY.ENTRY_ID), entryId, QueryConstants.EQUAL);
				ZABModel.deleteResource(criteria1);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
	}
	
	public static Script generateFunnelScript(String jsonString)
	{
		Script updateSript = null;
		try
		{
			JSONObject jsonObj = new JSONObject(jsonString);
			
			JSONArray stepsJSONArr = jsonObj.getJSONArray("steps"); // NO I18N
			JSONObject jsonStepObj = stepsJSONArr.getJSONObject(0);
			Long time = jsonStepObj.getLong(ElasticSearchConstants.TIME);
			Long stepId = jsonStepObj.getLong(ElasticSearchConstants.STEPID);
			String stepKey = jsonStepObj.getString(ElasticSearchConstants.STEPKEY);
			Map<String, Object> stepsJSONMap = new HashMap<String, Object>();
			stepsJSONMap.put(ElasticSearchConstants.TIME, time);
			stepsJSONMap.put(ElasticSearchConstants.STEPID, stepId);
			stepsJSONMap.put(ElasticSearchConstants.STEPKEY, stepKey);
			
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("step", stepsJSONMap);
			
			updateSript = new Script(ScriptType.INLINE, "painless", "ctx._source.steps.add(params.step)", params); //NO I18N
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred while generating funnel script",ex);
			updateSript = null;
		}
		return updateSript;
	}
	
	public static void processESFailedEntryInSecondary()
	{
		try
		{
			Criteria criteria = new Criteria(new Column(ES_FAILED_ENTRY.TABLE, ES_FAILED_ENTRY.OPERATION_TYPE), new Integer[]{ESOpertaionType.CREATE_BACKUP.getOperationType(),ESOpertaionType.UPDATE_BACKUP.getOperationType()}, QueryConstants.IN);
			DataObject dataObj = ZABModel.getRow(ES_FAILED_ENTRY.TABLE, criteria);
			Iterator<?> iterator = dataObj.getRows(ES_FAILED_ENTRY.TABLE);
			while(iterator.hasNext())
			{
				Row row = (Row)iterator.next();
				String indexName = (String)row.get(ES_FAILED_ENTRY.INDEX_NAME);
				String type = (String)row.get(ES_FAILED_ENTRY.TYPE);
				String jsonString = (String)row.get(ES_FAILED_ENTRY.JSON_STRING); 
				String docId = (String)row.get(ES_FAILED_ENTRY.DOC_ID);
				Integer operationType = (Integer)row.get(ES_FAILED_ENTRY.OPERATION_TYPE);
				if(type != null && type.equals(ElasticSearchConstants.FUNNEL_RAW_TYPE))
				{
					Script updateScript = generateFunnelScript(jsonString);
					UpdateRequest updateRequest = new UpdateRequest(indexName, type, docId);
					updateRequest.script(updateScript);
					updateRequest.upsert(jsonString);
					ElasticSearchUtil.upsertIndexInSecondary(indexName, type, docId, jsonString, updateScript,updateRequest);
				}
				else if(type != null && (type.equals(ElasticSearchConstants.FORM_ANALYTICS_RAW_TYPE) || type.equals(ElasticSearchConstants.FORM_ANALYTICS_FIELDS_RAW_TYPE)))
				{
					UpdateRequest updateRequest = new UpdateRequest(indexName, type, docId);
					updateRequest.doc(jsonString);
					updateRequest.upsert(jsonString);
					ElasticSearchUtil.upsertIndexInSecondary(indexName, type, docId, jsonString,updateRequest);
				}
				else
				{
					if(ESOpertaionType.CREATE_BACKUP.getOperationType().equals(operationType))
					{
						ElasticSearchUtil.createIndexInSecondary(indexName, type, jsonString, docId);
					}
					else if(ESOpertaionType.UPDATE_BACKUP.getOperationType().equals(operationType))
					{
						UpdateRequest updateRequest = new UpdateRequest();
						updateRequest.index(indexName);
						updateRequest.type(type);
						updateRequest.id(docId);
						updateRequest.doc(jsonString);
						ElasticSearchUtil.updateIndexInSecondary(indexName, type, docId, jsonString, updateRequest);
					}
				}
				Long entryId = (Long)row.get(ES_FAILED_ENTRY.ENTRY_ID);
				Criteria criteria1 = new Criteria(new Column(ES_FAILED_ENTRY.TABLE, ES_FAILED_ENTRY.ENTRY_ID), entryId, QueryConstants.EQUAL);
				ZABModel.deleteResource(criteria1);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
	}
	
	public static void deleteAllESFailedEntries()
	{
		try
		{
			ZABModel.deleteAllRows(ES_FAILED_ENTRY.TABLE);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
	}
	
}
