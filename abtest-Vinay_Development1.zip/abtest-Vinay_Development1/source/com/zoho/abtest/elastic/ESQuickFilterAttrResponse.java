//$Id$
package com.zoho.abtest.elastic;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.audience.AudienceAttributeConstants.AudienceAttributeMatchTypes;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;
import com.zoho.abtest.elastic.ESQuickFilterConstants.QuickFilterBoundValues;
import com.zoho.abtest.report.ElasticSearchConstants;

public class ESQuickFilterAttrResponse 
{
	private static final Logger LOGGER = Logger.getLogger(ESQuickFilterAttrResponse.class.getName());
	
	public static String jsonResponse(HttpServletRequest request,List<ESQuickFilterWrapper> qfAttributes) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(qfAttributes);			
			JSONObject json = ZABResponse.updateMetaInfo(request, ElasticSearchConstants.QUICKFILTER_ATTR_API_MODULE, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		return returnBuffer.toString();
	}
	public static JSONArray getJSONArray(List<ESQuickFilterWrapper> qfAttributes) throws JSONException {
		JSONArray array = new JSONArray();
		int size =qfAttributes.size();
		for (int i=0;i<size;i++) {
			ESQuickFilterWrapper wrap = qfAttributes.get(i);
			ESQuickFilterConstants.QuickFilterAttributes qfAttr = wrap.getAttribute();
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(ElasticSearchConstants.QF_ATTRIBUTE_DISPLAYNAME, qfAttr.getDisplayName());
			jsonObj.put(ElasticSearchConstants.QF_ATTRIBUTE_LINKNAME, qfAttr.getLinkName());
			jsonObj.put(ESQuickFilterConstants.SEGMENT_NAME, qfAttr.getSegmentName());
			jsonObj.put(ElasticSearchConstants.QF_ATTRIBUTE_TYPE, qfAttr.getUiType());
			
			if(!qfAttr.getMatchTypes().isEmpty()) {
				JSONArray mtypes = new JSONArray();
				for(AudienceAttributeMatchTypes matchType: qfAttr.getMatchTypes()) {
					JSONObject obj = new JSONObject();
					obj.put(ESQuickFilterConstants.ATTRIBUTE_MATCHTYPE_ID, matchType.getTypeId());
					obj.put(ESQuickFilterConstants.ATTRIBUTE_MATCHTYPE_NAME, matchType.getDisplayName());
					mtypes.put(obj);
				}
				jsonObj.put(ESQuickFilterConstants.QF_MATCH_TYPE, mtypes);
			}
			
			if(!qfAttr.getBoundValues().isEmpty()) {
				JSONArray bvalues = new JSONArray();
				for(QuickFilterBoundValues bounds: qfAttr.getBoundValues()) {
					JSONObject obj = new JSONObject();
					obj.put(ESQuickFilterConstants.QF_UNIT_KEY, bounds.getKey());
					obj.put(ESQuickFilterConstants.QF_UNIT_DISPLAY_NAME, bounds.getDisplayName());
					bvalues.put(obj);
				}
				jsonObj.put(ESQuickFilterConstants.QF_BOUND_UNITS, bvalues);
			}
			
			jsonObj.put(ElasticSearchConstants.QF_ATTRIBUTE_VALUES, ESQuickFilterResponse.getJSONArray(wrap.getVisitorData()));
			jsonObj.put(ZABConstants.SUCCESS, true);
			array.put(jsonObj);
		}
		return array;
	}
}
