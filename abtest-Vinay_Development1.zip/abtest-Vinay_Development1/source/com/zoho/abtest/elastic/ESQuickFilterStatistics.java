//$Id$
package com.zoho.abtest.elastic;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import com.adventnet.iam.IAMUtil;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.elastic.ESQuickFilterConstants.QuickFilterAttributes;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentType;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.report.ReportConstants;
import com.zoho.abtest.utility.ZABUtil;

public class ESQuickFilterStatistics extends ZABModel
{
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(ESQuickFilterStatistics.class.getName());
	
	private Object segmentValue;
	private Long visitorCount;
	
	private String diplayName;
	
	public String getDiplayName() {
		return diplayName;
	}

	public void setDiplayName(String diplayName) {
		this.diplayName = diplayName;
	}

	public Object getSegmentValue() {
		return segmentValue;
	}

	public void setSegmentValue(Object segmentValue) {
		this.segmentValue = segmentValue;
	}

	public Long getVisitorCount() {
		return visitorCount;
	}

	public void setVisitorCount(Long visitorCount) {
		this.visitorCount = visitorCount;
	}
	
	public static void sortByVisitorCount(List<ESQuickFilterStatistics> visitorReportDetails) {
		//Sorting descending based on visitor count
		Collections.sort(visitorReportDetails, new Comparator<ESQuickFilterStatistics>() {
			@Override
			public int compare(ESQuickFilterStatistics o1,
					ESQuickFilterStatistics o2) {
				int compareValue = 0;
				if(o2.getVisitorCount() != null && o1.getVisitorCount() != null)
				{
					compareValue = o2.getVisitorCount().compareTo(o1.getVisitorCount());
				}
				return compareValue;
			}
		});
	}
	
	public static List<ESQuickFilterStatistics> sortValues(List<ESQuickFilterStatistics> visitorReportDetails, String segmentName) {
		//CRUFT: Sorting and add fillers based on type.
		ESQuickFilterWrapper sortWrapper = new ESQuickFilterWrapper();
		sortWrapper.setAttribute(QuickFilterAttributes.getQuickFilterAttributeByLinkname(segmentName));
		sortWrapper.setVisitorData(new ArrayList<ESQuickFilterStatistics>(visitorReportDetails));
		sortWrapper.sortAndAddFillers();
		return sortWrapper.getVisitorData();
	}

	public static List<ESQuickFilterStatistics> getQuickFilterSegmentVisitorsdetails(HashMap<String,String> hs)
	{
		List<ESQuickFilterStatistics> visitorReportDetails = null;
		try
		{
			String experimentLinkName = hs.get(ExperimentConstants.EXPERIMENT_LINKNAME);
			Experiment expObj = Experiment.getExperimentByLinkname(experimentLinkName);
			if(expObj != null && expObj.getExperimentId() != null)
			{
				Long experimentId = expObj.getExperimentId();
				Integer expType = expObj.getExperimentType();
				String startTime = hs.get(ReportConstants.START_DATE);
				String  endTime = hs.get(ReportConstants.END_DATE);
				String  segmentName = hs.get(ReportConstants.SEGMENT_TYPE);
				Long startTimeInMillis = null;
				if(startTime!=null&&!startTime.isEmpty()){
					 startTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(startTime, "yyyy-MM-dd");		// NO I18N
				}
				
				Long endTimeInMillis = null;
				if(endTime!=null&&!endTime.isEmpty()){
					endTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(endTime, "yyyy-MM-dd");		// NO I18N
					//Get the long value end date's last milli second
					endTimeInMillis =  ZABUtil.getNthDayDateInLong(endTimeInMillis, 1) - 1;
				}
				
				//For nested quick filter like city by country 
				HashMap<String, String> qfNestedParentCond = new HashMap<String, String>();
				if(segmentName.equals(ElasticSearchConstants.CITY))
				{
					String qfParentName = hs.get(ReportConstants.QF_PARENT_NAME);
					String qfParentValue = hs.get(ReportConstants.QF_PARENT_VALUE);
					if(qfParentValue != null)
					{
						qfParentValue = qfParentValue.toUpperCase();
					}
					qfNestedParentCond.put(qfParentName, qfParentValue);
				}
				
				
				String portalName =null;
				try{
					 portalName = IAMUtil.getCurrentServiceOrg().getDomains().get(0).getDomain();
				}catch(Exception e){
					portalName = ZABUtil.getPortaldomain();
					if(portalName == null){
						return null;
					}
				}
				String indexName = ElasticSearchUtil.getIndexByPortal(portalName);
				
				if(expType.equals(ExperimentType.ABTEST.getTypeNumber())||
						expType.equals(ExperimentType.SPLITURL.getTypeNumber())||
						expType.equals(ExperimentType.HEATMAP.getTypeNumber())||
						expType.equals(ExperimentType.SESSION_RECORDING.getTypeNumber())||
						expType.equals(ExperimentType.FORMANALYTICS.getTypeNumber()))
				{
					visitorReportDetails = ESCommonQuickFilterStatistics.getQuickFilterSegmentVisitorCount(
							indexName, portalName, segmentName, experimentId,
							expType,
							startTimeInMillis, endTimeInMillis,
							qfNestedParentCond, hs);
				}
				else if(expType.equals(ExperimentType.FUNNEL.getTypeNumber()))
				{
					visitorReportDetails = ESFunnelQuickFilterStatistics.getQuickFilterSegmentFunnelVisitorCount(indexName, portalName, segmentName, experimentId, startTimeInMillis, endTimeInMillis, qfNestedParentCond);
				}
				visitorReportDetails = sortValues(visitorReportDetails, segmentName);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage());
			visitorReportDetails = new ArrayList<ESQuickFilterStatistics>();
		}
		return visitorReportDetails;
	}
	
	public static List<ESQuickFilterWrapper> getQuickFilterMultipleSegmentVisitorsdetails(HashMap<String,String> hs)
	{
		List<ESQuickFilterWrapper> visitorReportDetails = null;
		try
		{
			String experimentLinkName = hs.get(ExperimentConstants.EXPERIMENT_LINKNAME);
			Experiment expObj = Experiment.getExperimentByLinkname(experimentLinkName);
			if(expObj != null && expObj.getExperimentId() != null)
			{
				Long experimentId = expObj.getExperimentId();
				
				String experimentType = hs.get(ExperimentConstants.EXPERIMENT_TYPE);
				Integer expType = Integer.parseInt(experimentType);
				
				List<QuickFilterAttributes> quickFilterAttrs = ESQuickFilterConstants.QuickFilterAttributes.getQuickAttributes(expType);
				
				String startTime = hs.get(ReportConstants.START_DATE);
				String  endTime = hs.get(ReportConstants.END_DATE);
				Long startTimeInMillis = null;
				if(startTime!=null&&!startTime.isEmpty()){
					 startTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(startTime, "yyyy-MM-dd");		// NO I18N
				}
				
				Long endTimeInMillis = null;
				if(endTime!=null&&!endTime.isEmpty()){
					endTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(endTime, "yyyy-MM-dd");		// NO I18N
					//Get the long value end date's last milli second
					endTimeInMillis =  ZABUtil.getNthDayDateInLong(endTimeInMillis, 1) - 1;
				}
				
				String portalName =null;
				try{
					 portalName = IAMUtil.getCurrentServiceOrg().getDomains().get(0).getDomain();
				}catch(Exception e){
					portalName = ZABUtil.getPortaldomain();
					if(portalName == null){
						return null;
					}
				}
				String indexName = ElasticSearchUtil.getIndexByPortal(portalName);
				
				if(expType.equals(ExperimentType.ABTEST.getTypeNumber())||
						expType.equals(ExperimentType.SPLITURL.getTypeNumber())||
						expType.equals(ExperimentType.HEATMAP.getTypeNumber()) ||
						expType.equals(ExperimentType.SESSION_RECORDING.getTypeNumber()) ||
						expType.equals(ExperimentType.FORMANALYTICS.getTypeNumber()))
				{
					visitorReportDetails = ESCommonQuickFilterStatistics
							.getQuickFilterMultiSegmentVisitorCount(indexName,
									portalName, experimentId,
									expType,
									startTimeInMillis, endTimeInMillis, hs,
									quickFilterAttrs);
				}
				else if(expType.equals(ExperimentType.FUNNEL.getTypeNumber()))
				{
					visitorReportDetails = ESFunnelQuickFilterStatistics
							.getQuickFilterMultiSegmentFunnelVisitorCount(
									indexName, portalName, experimentId,
									startTimeInMillis, endTimeInMillis,
									quickFilterAttrs);
				}
				
				
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage());
			visitorReportDetails = new ArrayList<ESQuickFilterWrapper>();
		}
		return visitorReportDetails;
	}
	
}
