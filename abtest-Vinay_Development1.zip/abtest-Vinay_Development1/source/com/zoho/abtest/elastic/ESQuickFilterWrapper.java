//$Id$
package com.zoho.abtest.elastic;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.elastic.ESQuickFilterConstants.QuickFilterAttributes;

public class ESQuickFilterWrapper extends ZABModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private QuickFilterAttributes attribute;
	
	private ArrayList<ESQuickFilterStatistics> visitorData = new ArrayList<ESQuickFilterStatistics>();

	public QuickFilterAttributes getAttribute() {
		return attribute;
	}

	public void setAttribute(QuickFilterAttributes attribute) {
		this.attribute = attribute;
	}

	public ArrayList<ESQuickFilterStatistics> getVisitorData() {
		return visitorData;
	}

	public void setVisitorData(ArrayList<ESQuickFilterStatistics> visitorData) {
		this.visitorData = visitorData;
	}
	
	private void addFillers(List<String> fillers) {
		ESQuickFilterStatistics.sortByVisitorCount(this.visitorData);
		int length = fillers.size();
		for(int i=0; i<length; i++) {
			String value = fillers.get(i);
		Boolean isAvailableInList = this.visitorData.stream()
				.anyMatch((a) -> {
					return a.getSegmentValue().equals(value);
				});
			if(!isAvailableInList) {
				ESQuickFilterStatistics qfs = new ESQuickFilterStatistics();
				qfs.setSegmentValue(value);
				qfs.setVisitorCount(0l);
				qfs.setSuccess(Boolean.TRUE);
				this.visitorData.add(qfs);
			}
		}
	}
	
	public void sortAndAddFillers() {
		String segmentName = attribute.getLinkName();
		QuickFilterAttributes qat = QuickFilterAttributes.getQuickFilterAttributeByLinkname(segmentName);
		if (qat != null) {
			switch (qat) {
				case HOUROFDAY:
				case DAYOFWEEK:
				{
					//Add empty fillers for hour and day
					boolean isHOD = segmentName.equals(QuickFilterAttributes.HOUROFDAY.getLinkName());
					int limit = isHOD?23:6;
					ArrayList<ESQuickFilterStatistics> sortedList = new ArrayList<ESQuickFilterStatistics>();
					for(int i=0; i<=limit; i++) {
						final String tick = isHOD?i+"":ESQuickFilterConstants.DOW[i];
						ArrayList<ESQuickFilterStatistics> sts = this.visitorData
								.stream()
								.filter((vrd) -> vrd.getSegmentValue().equals(tick))
								.collect(Collectors.toCollection(ArrayList::new));
						if(sts.size() == 0) {
							ESQuickFilterStatistics qfs = new ESQuickFilterStatistics();
							qfs.setSegmentValue(tick);
							qfs.setVisitorCount(0l);
							qfs.setSuccess(Boolean.TRUE);
							sortedList.add(qfs);
						} else {
							sortedList.addAll(sts);
						}
					}
					this.visitorData = sortedList;
					break;
				}
				case DEVICE:
					addFillers(ESQuickFilterConstants.DEVICE_TYPE_POSSIBLE_VALS);
					break;
				case USERTYPE:
					addFillers(ESQuickFilterConstants.USER_TYPE_POSSIBLE_VALS);
					break;
				case TRAFFICSOURCE:
					addFillers(ESQuickFilterConstants.TRAFFIC_SOURCE_POSSIBLE_VALS);
					break;
				default:
					//Sorting descending based on visitor count
					ESQuickFilterStatistics.sortByVisitorCount(this.visitorData);
					break;
			}
		}
	}
}
