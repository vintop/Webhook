//$Id$

package com.zoho.abtest.forms;


import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.json.JSONArray;
import org.json.JSONException;
import com.opensymphony.xwork2.ActionSupport;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.utility.ZABUtil;

public class FormAction extends ActionSupport implements ServletResponseAware, ServletRequestAware{
	
	
	private static final Logger LOGGER = Logger.getLogger(FormAction.class.getName());

	private static final long serialVersionUID = 1L;

	private HttpServletRequest request;
	
	private HttpServletResponse response;
	
	private String linkname;
	
	public String getLinkname() {
		return linkname;
	}

	public void setLinkname(String linkname) {
		this.linkname = linkname;
	}

	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		request = arg0;
	}

	@Override
	public void setServletResponse(HttpServletResponse arg0) {
		response = arg0;
	}
	
	public String execute() throws IOException, JSONException {
		ArrayList<Form> forms = new ArrayList<Form>();
		//String project_link_name = request.getParameter(AudienceConstants.PROJECT_LINK_NAME);
		//String experiment_link_name = request.getParameter(AudienceConstants.EXPERIMENT_LINK_NAME);
		try {		
			switch(ZABAction.getHTTPMethod(request)) {
			case POST:				
				HashMap<String,String> hs = ZABAction.getRequestParser(request).parseForm(request);
				forms.addAll(Form.createFormDetails(hs));
				break;
			case GET:
				if(linkname!=null) {
					//forms.add(Form.getFormDetailsByLinkName(linkname));
				}else{
					forms.addAll(Form.getFormDetails());
				}
				break;
			case DELETE:
				if(linkname!=null) {					
					//forms.add(Form.deleteFormDetails(request));
				}
				break;
			case PUT:
				HashMap<String,String> hsPut = ZABAction.getRequestParser(request).parseForm(request);
					forms.addAll(Form.updateFormDetails(hsPut));

				break;
			}
		}catch(JSONException ex){	

			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getInvalidInputFormatException(FormConstants.API_MODULE));
			return null; 	
		}
		catch(Exception ex){
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), FormConstants.API_MODULE));
			return null; 	
		}		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getFormResponse(request, forms));		
	    return null;
	}
	
	public void getFormDetails(){
		try{
			String url=request.getParameter("experiment_url");
			JSONArray jsonarray=FormParseUrl.parseFormUrl(url);
			ZABAction.sendResponse(request, response, ZABAction.getResponseProvider(request).getFormResponse(request, jsonarray));
		}catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
	}

}
