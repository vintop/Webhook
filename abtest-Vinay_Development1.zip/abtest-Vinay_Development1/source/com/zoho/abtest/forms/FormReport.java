//$Id$
package com.zoho.abtest.forms;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONArray;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.heatmaps.HeatmapConstants;
import com.zoho.abtest.utility.ZABUtil;


public class FormReport extends ZABModel {
	
	private static final long serialVersionUID = 1L;

	private static final Logger LOGGER = Logger.getLogger(FormReport.class.getName());
	private Long experimentid;
	private Long formuniquevisitorcount;
	private Long formvisitorcount;
	private Double formstartercount;
	private Double formconversioncount;
	private Double formabandoncount;
    private Double formspenttime;
    private Double formcompletetime;
    private Long formsubmissioncount;
    private Double formlive;
    private Double formconversionrate;
    private Double formstarterrate;
    private Double formabandonrate;
    private Long time;
    private JSONArray jsonarray;
    
    public Long getFormuniquevisitorcount() {
		return formuniquevisitorcount;
	}

	public void setFormuniquevisitorcount(Long formuniquevisitorcount) {
		this.formuniquevisitorcount = formuniquevisitorcount;
	}

	public Double getFormconversionrate() {
		return formconversionrate;
	}

	public void setFormconversionrate(Double formconversionrate) {
		this.formconversionrate = formconversionrate;
	}

	public Double getFormabandonrate() {
		return formabandonrate;
	}

	public void setFormabandonrate(Double formabandonrate) {
		this.formabandonrate = formabandonrate;
	}

	public Double getFormlive() {
		return formlive;
	}

	public void setFormlive(Double formlive) {
		this.formlive = formlive;
	}

	public JSONArray getJsonarray() {
		return jsonarray;
	}

	public void setJsonarray(JSONArray jsonarray) {
		this.jsonarray = jsonarray;
	}

	public Long getExperimentid() {
		return experimentid;
	}

	public void setExperimentid(Long experimentid) {
		this.experimentid = experimentid;
	}

	public Long getFormvisitorcount() {
		return formvisitorcount;
	}
	
	public Long getFormsubmissioncount() {
		return formsubmissioncount;
	}

	public void setFormsubmissioncount(Long formsubmissioncount) {
		this.formsubmissioncount = formsubmissioncount;
	}

	public void setFormvisitorcount(Long formvisitorcount) {
		this.formvisitorcount = formvisitorcount;
	}

	public Double getFormstartercount() {
		return formstartercount;
	}

	public void setFormstartercount(Double formstartercount) {
		this.formstartercount = formstartercount;
	}

	public Double getFormconversioncount() {
		return formconversioncount;
	}

	public void setFormconversioncount(Double formconversioncount) {
		this.formconversioncount = formconversioncount;
	}

	public Double getFormspenttime() {
		return formspenttime;
	}

	public void setFormspenttime(Double formspenttime) {
		this.formspenttime = formspenttime;
	}

	public Double getFormcompletetime() {
		return formcompletetime;
	}

	public void setFormcompletetime(Double formcompletetime) {
		this.formcompletetime = formcompletetime;
	}

	public Long getTime() {
		return time;
	}

	public void setTime(Long time) {
		this.time = time;
	}
	
	public Double getFormstarterrate() {
		return formstarterrate;
	}

	public void setFormstarterrate(Double formstarterrate) {
		this.formstarterrate = formstarterrate;
	}
	
	public Double getFormabandoncount() {
		return formabandoncount;
	}

	public void setFormabandoncount(Double formabandoncount) {
		this.formabandoncount = formabandoncount;
	}

	public static FormReport getFormReportfromHashMap(HashMap<String,String> hs){
		FormReport fr=new FormReport();
		try{
		fr.setSuccess(Boolean.TRUE);
		fr.setFormuniquevisitorcount(Long.parseLong(hs.get(FormReportConstants.FORM_UNIQUE_VISITOR_COUNT)));
		fr.setFormsubmissioncount(Long.parseLong(hs.get(FormReportConstants.FORM_SUBMISSION_COUNT)));
		fr.setFormstartercount(Double.parseDouble(hs.get(FormReportConstants.FORM_STARTER_COUNT)));
		fr.setFormvisitorcount(Long.parseLong(hs.get(FormReportConstants.FORM_VISITOR_COUNT)));
		fr.setFormconversioncount(Double.parseDouble(hs.get(FormReportConstants.FORM_CONVERSION_COUNT)));
		fr.setFormabandoncount(Double.parseDouble(hs.get(FormReportConstants.FORM_ABANDON_COUNT)));
		fr.setFormspenttime(Double.parseDouble(hs.get(FormReportConstants.FORM_SPENT_TIME)));
		fr.setFormcompletetime(Double.parseDouble(hs.get(FormReportConstants.FORM_COMPLETE_TIME)));
		fr.setFormstarterrate(Double.parseDouble(hs.get(FormReportConstants.FORM_STARTER_RATE)));
		fr.setFormabandonrate(Double.parseDouble(hs.get(FormReportConstants.FORM_ABANDON_RATE)));
		fr.setFormconversionrate(Double.parseDouble(hs.get(FormReportConstants.FORM_CONVERSION_RATE)));
		}catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		return fr;
	}
	
	public static ArrayList<FormReport> createFormReport(HashMap<String,String> hs){
		
		ArrayList<FormReport> formreports = new ArrayList<FormReport>();
		HashMap<String,String> hashmap1=new HashMap<String,String>();

		FormReport formreport = new FormReport();
		try {
			String experimentLinkName = hs.get(ZABConstants.LINKNAME);
			Experiment exp  = Experiment.getExperimentByLinkname(experimentLinkName);
	
			if(exp == null){
				FormReport report = new FormReport();
				report.setSuccess(Boolean.FALSE);
				formreports.add(report);
				return formreports;
				//report.setResponseString();
			}
			Long experimentId = exp.getExperimentId();
		
			String startTime = null;
			String endTime = null;
			
			if(hs.containsKey(HeatmapConstants.START_DATE.toLowerCase())){
				startTime = hs.get(HeatmapConstants.START_DATE.toLowerCase());
			}else{
				startTime = exp.getActualStartTime().toString();
			}
			
			if(hs.containsKey(HeatmapConstants.END_DATE.toLowerCase())){
				endTime  = hs.get(HeatmapConstants.END_DATE.toLowerCase());
			}
			
			Long startTimeInMillis = null;
			if(startTime!=null&&!startTime.isEmpty()){
				 startTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(startTime, "yyyy-MM-dd");		// NO I18N
			}
			
			Long endTimeInMillis = null;
			if(endTime!=null&&!endTime.isEmpty()){
				endTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(endTime, "yyyy-MM-dd");		// NO I18N
				endTimeInMillis = ZABUtil.getNthDayDateInLong(endTimeInMillis, 1);
			}else{
				endTimeInMillis = ZABUtil.getCurrentTimeInMilliSeconds();
			}
			hs.put(FormReportConstants.START_DATE,startTimeInMillis.toString());
			hs.put(FormReportConstants.END_DATE,endTimeInMillis.toString());
			hs.put(ExperimentConstants.EXPERIMENT_ID,experimentId.toString());
			//   calculating form report
			formreport = ElasticFormReport.calculateFormReportUsingElasticsSearch(hs);
			formreport.setExperimentid(experimentId);
			formreports.add(formreport);
		}catch (Exception e) {
			
			formreport.setSuccess(Boolean.FALSE);
			formreport.setResponseString(e.getMessage());
			formreports.add(formreport);
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		return formreports;
	}	
	

}

//hashmap1=calculateFormReport(hs);
//DataObject dobj = createRow(FormReportConstants.FORM_REPORTS_TABLE, FORM_REPORTS.TABLE, hashmap1);
//al=calculateFormFieldReport(hs);
//for(int i=0;i<al.size();i++){
//	
//	createRow(FormReportConstants.FORM_FIELD_REPORTS_TABLE, FORM_FIELD_REPORTS.TABLE,(HashMap<String,String>)al.get(i));
//}
//Row row = dobj.getRow(FORM_REPORTS.TABLE);
//Long experimentId = (Long)row.get(FORM_REPORTS.EXPERIMENT_ID);
//formreport.setExperimentid(experimentId);