//$Id$
package com.zoho.abtest.forms;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONObject;

public class FormChartReport {
	
	private static final Logger LOGGER = Logger.getLogger(FormChartReport.class.getName());
	
	private static final long serialVersionUID = 1L;
	
	private Long formvisitorcount;
	private Double formstartercount;
	private Double formconversioncount;
	private Double formabandoncount;
	private Double formstarterrate;
	private Double formconversionrate;
	private Double formabandonrate;
	private Long time;
	
	public Double getFormstarterrate() {
		return formstarterrate;
	}

	public void setFormstarterrate(Double formstarterrate) {
		this.formstarterrate = formstarterrate;
	}

	public Double getFormconversionrate() {
		return formconversionrate;
	}

	public void setFormconversionrate(Double formconversionrate) {
		this.formconversionrate = formconversionrate;
	}

	public Double getFormabandonrate() {
		return formabandonrate;
	}

	public void setFormabandonrate(Double formabandonrate) {
		this.formabandonrate = formabandonrate;
	}

	public Double getFormabandoncount() {
		return formabandoncount;
	}

	public void setFormabandoncount(Double formabandoncount) {
		this.formabandoncount = formabandoncount;
	}

	public Long getTime() {
		return time;
	}

	public void setTime(Long time) {
		this.time = time;
	}

	public Long getFormvisitorcount() {
		return formvisitorcount;
	}

	public void setFormvisitorcount(Long formvisitorcount) {
		this.formvisitorcount = formvisitorcount;
	}

	public Double getFormstartercount() {
		return formstartercount;
	}

	public void setFormstartercount(Double formstartercount) {
		this.formstartercount = formstartercount;
	}

	public Double getFormconversioncount() {
		return formconversioncount;
	}

	public void setFormconversioncount(Double formconversioncount) {
		this.formconversioncount = formconversioncount;
	}

	public static JSONArray getJSONArray(ArrayList<FormChartReport> formChartReport) {
		
		JSONArray jsonarray=new JSONArray();
		try{
		for(int i=0;i<formChartReport.size();i++){
			JSONObject json=new JSONObject();
			FormChartReport f = formChartReport.get(i);
			json.put(FormReportConstants.FORM_STARTER_COUNT, f.getFormstartercount());
			json.put(FormReportConstants.FORM_CONVERSION_COUNT, f.getFormconversioncount());
			json.put(FormReportConstants.FORM_ABANDON_COUNT, f.getFormabandoncount());
			json.put(FormReportConstants.FORM_STARTER_RATE, f.getFormstarterrate());
			json.put(FormReportConstants.FORM_CONVERSION_RATE, f.getFormconversionrate());
			json.put(FormReportConstants.FORM_ABANDON_RATE, f.getFormabandonrate());
			json.put(FormReportConstants.TIME, f.getTime());
			jsonarray.put(json);
		}
		}catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		return jsonarray;
	}

}
