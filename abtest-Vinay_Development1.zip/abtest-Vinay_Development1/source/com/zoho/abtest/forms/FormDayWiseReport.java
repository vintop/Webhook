//$Id$
package com.zoho.abtest.forms;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.histogram.DateHistogramAggregationBuilder;
import org.elasticsearch.search.aggregations.bucket.histogram.DateHistogramInterval;
import org.elasticsearch.search.aggregations.bucket.histogram.InternalDateHistogram;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.metrics.sum.Sum;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;

import com.adventnet.iam.IAMUtil;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.elastic.ESQuickFilterConstants;
import com.zoho.abtest.elastic.ElasticSearchStatistics;
import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentStatus;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.report.ReportConstants;
import com.zoho.abtest.utility.ZABUtil;

public class FormDayWiseReport extends ZABModel{
	
	private static final Logger LOGGER = Logger.getLogger(FormDayWiseReport.class.getName());
	
	private static final long serialVersionUID = 1L;
	
	private Long experimentId;
	private ArrayList<FormChartReport> formChartReport;
	
	public Long getExperimentId() {
		return experimentId;
	}

	public void setExperimentId(Long experimentId) {
		this.experimentId = experimentId;
	}

	public ArrayList<FormChartReport> getFormChartReport() {
		return formChartReport;
	}

	public void setFormChartReport(ArrayList<FormChartReport> formChartReport) {
		this.formChartReport = formChartReport;
	}

	public static ArrayList<FormDayWiseReport> createDayWiseFormReport(HashMap<String, String> hs) {
		
		ArrayList<FormDayWiseReport> formreports = new ArrayList<FormDayWiseReport>();

		try {
			FormDayWiseReport report = null;
			String experimentLinkName = hs.get(ZABConstants.LINKNAME);
			Experiment exp  = Experiment.getExperimentByLinkname(experimentLinkName);
	
			if(exp == null){
				 report = new FormDayWiseReport();
				report.setSuccess(Boolean.FALSE);
				formreports.add(report);
				return formreports;
			}
			
			Long experimentId = exp.getExperimentId();
		
			String startTime = hs.get(ReportConstants.START_DATE);
			String  endTime = hs.get(ReportConstants.END_DATE);
			String reportType = hs.get(ReportConstants.REPORT_TYPE);
			String multisegmentCriteria = hs.get(ReportConstants.MULTISEGMENT_CRITERIA);
			
			Long startTimeInMillis = null;
			if(startTime!=null&&!startTime.isEmpty()){
				 startTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(startTime, "yyyy-MM-dd");		// NO I18N
			}
			
			Long endTimeInMillis = null;
			if(endTime!=null&&!endTime.isEmpty()){
				endTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(endTime, "yyyy-MM-dd");		// NO I18N
				endTimeInMillis = ZABUtil.getNthDayDateInLong(endTimeInMillis, 1);
			}else{
				endTimeInMillis = ZABUtil.getCurrentTimeInMilliSeconds();
			}
			ArrayList<FormChartReport> chartReports = getDataPointerReportDetails(reportType, experimentId, startTimeInMillis, endTimeInMillis, multisegmentCriteria);
			report = new FormDayWiseReport();
			report.setExperimentId(experimentId);
			report.setFormChartReport(chartReports);
			report.setSuccess(Boolean.TRUE);
			formreports.add(report);
		} catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		return formreports;
	}
		
	public static ArrayList<FormChartReport> getDataPointerReportDetails(String reportType, Long expId, Long startTime, Long endTime, String multisegmentCriteria) throws Exception {
						
			boolean isHourbased = false;

			Experiment experiment = Experiment.getExperimentById(expId);
			
			Long expActualStartTime = experiment.getActualStartTime();
			
			if(expActualStartTime != null && startTime < expActualStartTime)
			{
				startTime = expActualStartTime;
			}
			
			long hourEndTime = ZABUtil.getNthDayDateInLong(endTime, 1);
			
			Integer expStatus = experiment.getExperimentStatus();
			Long expActualEndTime = experiment.getActualEndTime();
			
			if(ExperimentStatus.PAUSED.getStatusCode().equals(expStatus) && hourEndTime > expActualEndTime)
			{
				endTime = expActualEndTime;
				hourEndTime = ZABUtil.getNthUserHourInLong(endTime, 1);
			}
			

			long reportDateInterval = ZABUtil.getInterval(startTime, hourEndTime, TimeUnit.DAYS);
			
			//check the data should be fetched as per hour or day
			//If 2 or less days fetch based on hours
			if(reportDateInterval < 23)
			{
				isHourbased = true;
			}
						
			String portalName =null;
			try{
				 portalName = IAMUtil.getCurrentServiceOrg().getDomains().get(0).getDomain();
			}catch(Exception e){
				portalName = ZABUtil.getPortaldomain();
				if(portalName == null){
					return null;
				}
			}
			String indexName = ElasticSearchUtil.getIndexByPortal(portalName);
			
			ArrayList<FormChartReport> formreports = getDatapointFormReportInformation(indexName, portalName, reportType, expId, startTime, endTime, multisegmentCriteria, isHourbased);
			return formreports;
		}

	public static ArrayList<FormChartReport> getDatapointFormReportInformation(String index, String portal, String reportType, Long expId, Long startTime, Long endTime, String multisegmentCriteria, boolean isHourbased) {
		
		ArrayList<FormChartReport> metaHs = null;
		QueryBuilder query =  null;
		AggregationBuilder aggregation = null;
		int timeIntervalInSec = 0;
		int size = 0 ;
		try
		{
			if(reportType.equals(ReportConstants.SUMMARY))
			{
				query = ElasticSearchStatistics.generateSourceQueryJson(portal,expId,startTime,endTime,false,null,false,null,null);
			}
			else if(reportType.equals(ReportConstants.MULTISEGMENT))
			{
				query = ElasticSearchStatistics.generateSourceMultiSegmentQueryJson(portal,expId, startTime, endTime, multisegmentCriteria,false,null,null,null);
			}
			if(isHourbased){
				Long timeGap = (endTime - startTime)/1000;
				timeIntervalInSec = Integer.parseInt(timeGap.toString())/24;
			}
			aggregation  =   generateDatapointFormAggregateJson(isHourbased , timeIntervalInSec);
			SearchResponse response = ElasticSearchUtil.getData(index, ElasticSearchConstants.FORM_ANALYTICS_RAW_TYPE, size, query, aggregation);
			metaHs = readDatapointFormResponseData(response);
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			metaHs = new ArrayList<FormChartReport>();
		}
		return metaHs;
	}
	
	public static DateHistogramAggregationBuilder generateDatapointFormAggregateJson(boolean isHourbased , int timeInterval)
	{
		DateHistogramAggregationBuilder dateAggr = null;
		try
		{
			DateHistogramInterval interval = isHourbased?DateHistogramInterval.seconds(timeInterval):DateHistogramInterval.DAY; 
			String userTimeZone = ElasticSearchUtil.getCurrentUserTimezone();
			
			dateAggr = AggregationBuilders.dateHistogram("form_reports").field(ElasticSearchConstants.TIME).dateHistogramInterval(interval); // No I18N
			if(StringUtils.isNotEmpty(userTimeZone))
			{	
				DateTimeZone dtz;
				try {
					dtz = DateTimeZone.forID(userTimeZone);
				} catch(IllegalArgumentException ex) {
					LOGGER.log(Level.SEVERE, ex.getMessage(),ex);					
					dtz = DateTimeZone.forID(ESQuickFilterConstants.DEFAULT_TIME_ZONE);
				}
				dateAggr.timeZone(dtz);
			}
			AggregationBuilder formVisitCount =AggregationBuilders.terms(FormReportConstants.FORM_VISITOR_COUNT).field(ElasticSearchConstants.EXPERIMENTID); 
			AggregationBuilder  formStarterCount=AggregationBuilders.sum(FormReportConstants.FORM_STARTER_COUNT).field(FormRawDataConstants.FORM_STARTER); 
			AggregationBuilder  formConversionCount=AggregationBuilders.sum(FormReportConstants.FORM_CONVERSION_COUNT).field(FormRawDataConstants.FORM_CONVERSION); 
		//	AggregationBuilder  formLiveCount=AggregationBuilders.sum(FormReportConstants.FORM_LIVE).field(FormRawDataConstants.FORM_LIVE);
			dateAggr.subAggregation(formVisitCount).subAggregation(formStarterCount).subAggregation(formConversionCount);//.subAggregation(formLiveCount);
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		return dateAggr;
	}
	
	public static  ArrayList<FormChartReport> readDatapointFormResponseData(SearchResponse response)
	{
		ArrayList<FormChartReport> metaHs = new  ArrayList<FormChartReport>();
		
		try
		{
			Aggregations aggrResponse = response.getAggregations();
			InternalDateHistogram formDetailsTerms = aggrResponse.get("form_reports");
			List<InternalDateHistogram.Bucket> formDetailBuckets = formDetailsTerms.getBuckets();
			for(InternalDateHistogram.Bucket formDetail:formDetailBuckets)
			{
					Long time = ((DateTime)formDetail.getKey()).getMillis();
					double abandonCount = 0, starterRate = 0, conversionRate = 0, abandonRate = 0;
					Terms genders = formDetail.getAggregations().get(FormReportConstants.FORM_VISITOR_COUNT);		
					Sum formStarterCount= formDetail.getAggregations().get(FormReportConstants.FORM_STARTER_COUNT);
					Sum formConversionCount= formDetail.getAggregations().get(FormReportConstants.FORM_CONVERSION_COUNT);
				//	Sum formLiveCount = formDetail.getAggregations().get(FormReportConstants.FORM_LIVE);
					long visitsCount = 0;
					FormChartReport meta = new FormChartReport();
					if(genders.getBuckets().size()==0){
						meta.setFormvisitorcount(0L);
					}else{
						meta.setFormvisitorcount((long)(genders.getBuckets().get(0).getDocCount()));
						visitsCount = (long)(genders.getBuckets().get(0).getDocCount());
					}
					abandonCount = formStarterCount.getValue() - formConversionCount.getValue(); //- formLiveCount.getValue();
					meta.setTime(time);
					meta.setFormstartercount(formStarterCount.getValue());
					meta.setFormconversioncount(formConversionCount.getValue());
					meta.setFormabandoncount(abandonCount);
					
					if(visitsCount > 0){
						double a = formStarterCount.getValue();
						double b = Double.parseDouble(Long.toString(visitsCount));
						starterRate = (a/b)*100;
					}

					if(formStarterCount.getValue()>0){
						double a=formConversionCount.getValue();
						double b=formStarterCount.getValue();
						conversionRate=(a/b)*100;
					}
					
					if(formStarterCount.getValue()>0){
						double a=(formStarterCount.getValue() - formConversionCount.getValue()); //- formLiveCount.getValue());
						double b=(formStarterCount.getValue());
						abandonRate=(a/b)*100;
					}
					meta.setFormstarterrate(starterRate);
					meta.setFormconversionrate(conversionRate);
					meta.setFormabandonrate(abandonRate);
					metaHs.add(meta);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		return metaHs;
	}
		
}
