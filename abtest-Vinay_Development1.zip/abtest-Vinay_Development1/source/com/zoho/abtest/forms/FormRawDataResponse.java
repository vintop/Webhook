//$Id$
package com.zoho.abtest.forms;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;


public class FormRawDataResponse {
	

	public static String jsonResponse(HttpServletRequest request,ArrayList<FormRawData> lst)
	{
		
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(lst);			
			JSONObject json = ZABResponse.updateMetaInfo(request, "formrawdata", array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){}
		return returnBuffer.toString();	}
	
	
	
	private static JSONObject getJSONObject(FormRawData ld) throws JSONException {
		JSONObject jsonObj = new JSONObject();
		jsonObj.put(FormRawDataConstants.EXPERIMENT_ID, ld.getExperimentid());
		jsonObj.put(FormRawDataConstants.VISIT_ID, ld.getVisitid());
		jsonObj.put(FormRawDataConstants.FORM_STARTER, ld.getFormstarter());
		jsonObj.put(FormRawDataConstants.FORM_CONVERSION, ld.getFormconversion());
		jsonObj.put(FormRawDataConstants.FORM_SPENT_TIME, ld.getFormspenttime());
		jsonObj.put(FormRawDataConstants.TIME, ld.getTime());
		jsonObj.put(ZABConstants.RESPONSE_STRING, ld.getResponseString());
		jsonObj.put(ZABConstants.STATUS_CODE, ld.getResponseCode());
		jsonObj.put(ZABConstants.SUCCESS, ld.getSuccess());
		return jsonObj;
	}
	
	public static JSONArray getJSONArray(ArrayList<FormRawData> lst) throws JSONException {
		JSONArray array = new JSONArray();
		int size =lst.size();
		for (int i=0;i<size;i++) {
			FormRawData ld=lst.get(i);
			if(ld!=null) {				
				array.put(getJSONObject(ld));
			}
		}
		return array;
	}

	
}
