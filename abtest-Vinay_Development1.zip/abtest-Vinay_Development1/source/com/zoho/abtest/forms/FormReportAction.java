//$Id$
package com.zoho.abtest.forms;


import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.json.JSONException;
import com.opensymphony.xwork2.ActionSupport;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.utility.ZABUtil;

public class FormReportAction extends ActionSupport implements ServletResponseAware, ServletRequestAware{
	
	/**
	 * 
	 */
	private static final Logger LOGGER = Logger.getLogger(FormReportAction.class.getName());

	private static final long serialVersionUID = 1L;

	private HttpServletRequest request;
	
	private HttpServletResponse response;
	
	private String linkname;
	
	public String getLinkname() {
		return linkname;
	}

	public void setLinkname(String linkname) {
		this.linkname = linkname;
		request.setAttribute(ZABConstants.LINKNAME,linkname);
	}

	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		request = arg0;
	}

	@Override
	public void setServletResponse(HttpServletResponse arg0) {
		response = arg0;
	}
	
	public String execute() throws IOException, JSONException {
		ArrayList<FormReport> formreports = new ArrayList<FormReport>();
		try {		
			switch(ZABAction.getHTTPMethod(request)) {
			
			case POST:	
				HashMap<String,String> hs = ZABAction.getRequestParser(request).parseFormReport(request);
				if(hs.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					FormReport report = new FormReport();
					report.setSuccess(Boolean.FALSE);
					report.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
					formreports.add(report);
					LOGGER.log(Level.SEVERE,hs.get(ZABConstants.RESPONSE_STRING));
				}else{
					hs.put(ZABConstants.LINKNAME,request.getAttribute(ZABConstants.LINKNAME).toString());
					formreports.addAll(FormReport.createFormReport(hs));
				}
				break;
			default:
				break;
			}
		} catch(JSONException ex){	
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getInvalidInputFormatException(FormReportConstants.API_MODULE));
			return null; 	
		}
		  catch(Exception ex){
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), FormReportConstants.API_MODULE));
			return null; 	
		}		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getFormReportResponse(request, formreports));		
	    return null;
	}
	
	public String getDayWiseReports() throws IOException, JSONException {
		
		ArrayList<FormDayWiseReport> formreports = new ArrayList<FormDayWiseReport>();
		try {		
			switch(ZABAction.getHTTPMethod(request)) {
			case POST:
				HashMap<String,String> hs = ZABAction.getRequestParser(request).parseFormReport(request);
				if(hs.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					FormDayWiseReport report = new FormDayWiseReport();
					report.setSuccess(Boolean.FALSE);
					report.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
					formreports.add(report);
					LOGGER.log(Level.SEVERE,hs.get(ZABConstants.RESPONSE_STRING));
				}else{
					hs.put(ZABConstants.LINKNAME,request.getAttribute(ZABConstants.LINKNAME).toString());
					formreports.addAll(FormDayWiseReport.createDayWiseFormReport(hs));
				}
				break;
			default:
				break;
			}
		}catch(JSONException ex){	

			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getInvalidInputFormatException(FormReportConstants.API_MODULE));
			return null; 	
		}
		catch(Exception ex){
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), FormReportConstants.API_MODULE));
			return null; 	
		}		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getFormDayWiseReportResponse(request, formreports));	
	 return null;
	}

}
