//$Id$
package com.zoho.abtest.forms;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONObject;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.FORM_DETAILS;
import com.zoho.abtest.FORM_FIELD_DETAILS;
import com.zoho.abtest.FORM_CUSTOM_EVENTS;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.customevent.CustomEvent;
import com.zoho.abtest.customevent.CustomEventConstants;
import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.forms.FormConstants.FormMatchType;


public class Form extends ZABModel {
	
	
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(Form.class.getName());
	
	private Long experimentId;
	private String formurl;
	private String formelementid;
	private String formelementname;
	private String formelementselector;
	private Integer formnooffields;
	private String formconversionurl;
	private Boolean formloaded;
	private Integer matchtype;
	private String customevent;
	private String customeventname;
	private String excludedUrls;
	private String includedUrls;
	private ArrayList<FormFieldDetails> formFieldDetails;
	
	
	public String getExcludedUrls() {
		return excludedUrls;
	}

	public void setExcludedUrls(String excludedUrls) {
		this.excludedUrls = excludedUrls;
	}

	public String getIncludedUrls() {
		return includedUrls;
	}

	public void setIncludedUrls(String includedUrls) {
		this.includedUrls = includedUrls;
	}

	public String getCustomeventname() {
		return customeventname;
	}
	
	public void setCustomeventname(String customeventname) {
		this.customeventname = customeventname;
	}
	
	public Boolean getFormloaded() {
		return formloaded;
	}
	public void setFormloaded(Boolean formloaded) {
		this.formloaded = formloaded;
	}
	public Integer getMatchtype() {
		return matchtype;
	}
	public void setMatchtype(Integer matchtype) {
		this.matchtype = matchtype;
	}
	public String getCustomevent() {
		return customevent;
	}
	public void setCustomevent(String customevent) {
		this.customevent = customevent;
	}
	public ArrayList<FormFieldDetails> getFormFieldDetails() {
		return formFieldDetails;
	}
	public void setFormFieldDetails(ArrayList<FormFieldDetails> formFieldDetails) {
		this.formFieldDetails = formFieldDetails;
	}
	public String getFormelementselector() {
		return formelementselector;
	}
	public void setFormelementselector(String formelementselector) {
		this.formelementselector = formelementselector;
	}
	public Long getExperimentId() {
		return experimentId;
	}
	public void setExperimentId(Long experimentId) {
		this.experimentId = experimentId;
	}
	public String getFormurl() {
		return formurl;
	}
	public void setFormurl(String formurl) {
		this.formurl = formurl;
	}
	public String getFormelementid() {
		return formelementid;
	}
	public void setFormelementid(String formelementid) {
		this.formelementid = formelementid;
	}
	public String getFormelementname() {
		return formelementname;
	}
	public void setFormelementname(String formelementname) {
		this.formelementname = formelementname;
	}
	public Integer getFormnooffields() {
		return formnooffields;
	}
	public void setFormnooffields(Integer formnooffields) {
		this.formnooffields = formnooffields;
	}
	public String getFormconversionurl() {
		return formconversionurl;
	}
	public void setFormconversionurl(String formconversionurl) {
		this.formconversionurl = formconversionurl;
	}
	
	public static Form getFormFromRow(Row row)
	{
		Form form=new Form();
		form.setSuccess(Boolean.TRUE);
		form.setExperimentId((Long)row.get(FORM_DETAILS.EXPERIMENT_ID));
		form.setFormurl((String)row.get(FORM_DETAILS.EXPERIMENT_URL));
		form.setFormelementid((String)row.get(FORM_DETAILS.FORM_ELEMENT_ID));
		form.setFormloaded((Boolean)row.get(FORM_DETAILS.IS_AUTO_LOADED));
		form.setFormelementname((String)row.get(FORM_DETAILS.FORM_ELEMENT_NAME));
		form.setFormnooffields((Integer)row.get(FORM_DETAILS.FORM_NO_OF_FIELDS));
		form.setFormconversionurl((String)row.get(FORM_DETAILS.FORM_CONVERSION_URL));
		form.setFormelementselector((String)row.get(FORM_DETAILS.FORM_ELEMENT_SELECTOR));
		form.setIncludedUrls((String)row.get(FORM_DETAILS.INCLUDE_URLS));
		form.setExcludedUrls((String)row.get(FORM_DETAILS.EXCLUDE_URLS));
		form.setMatchtype((Integer)row.get(FORM_DETAILS.MATCH_TYPE));
		return form;
	}
	
	public static FormFieldDetails getFormFieldDetailsFromRow(Row row){
		
		FormFieldDetails form=new FormFieldDetails();
		form.setFormfieldid((Long)row.get(FORM_FIELD_DETAILS.FORM_FIELD_ID));
		form.setFieldname((String)row.get(FORM_FIELD_DETAILS.FORM_FIELD_NAME));
		form.setFieldid((String)row.get(FORM_FIELD_DETAILS.FIELD_ID));
		form.setFieldtype((String)row.get(FORM_FIELD_DETAILS.FORM_FIELD_TYPE));
		form.setFieldalias((String)row.get(FORM_FIELD_DETAILS.FIELD_ALIAS));
		form.setIsenabled((Boolean)row.get(FORM_FIELD_DETAILS.IS_ENABLED));
		form.setFormfieldkey((String)row.get(FORM_FIELD_DETAILS.FORM_FIELD_KEY));
		return form;
	}
	
	public static ArrayList<Form> getFormFromDobj(DataObject dobj) throws DataAccessException
	{
		ArrayList<Form> form=new ArrayList<Form>();
		if(dobj.containsTable(FORM_DETAILS.TABLE)) {
			Iterator it = dobj.getRows(FORM_DETAILS.TABLE);
			while(it.hasNext()) {
				Row row = (Row)it.next();
				Form f = getFormFromRow(row);
				form.add(f);
			}
		}
		return form;
	}
	
	public static ArrayList<FormFieldDetails> getFormFieldFromDobj(DataObject dobj) throws DataAccessException{
		
		ArrayList<FormFieldDetails> form=new ArrayList<FormFieldDetails>();
		if(dobj.containsTable(FORM_FIELD_DETAILS.TABLE)) {
			Iterator it = dobj.getRows(FORM_FIELD_DETAILS.TABLE);
			while(it.hasNext()) {
				Row row = (Row)it.next();
				FormFieldDetails f = getFormFieldDetailsFromRow(row);
				form.add(f);
			}
		}
		return form;
	}
	
	public static ArrayList<Form> createFormDetails(HashMap<String,String> hs){
		
		ArrayList<Form> forms = new ArrayList<Form>();
		Form form= new Form();
		try {
			
			Experiment exp = Experiment.getExperimentById(Long.parseLong(hs.get(FormConstants.EXPERIMENT_ID)));
			
			if(!hs.containsKey(FormConstants.MATCH_TYPE)) {
				hs.put(FormConstants.MATCH_TYPE, FormConstants.FormMatchType.SIMPLE_MATCH.getMatchTypeId()+"");
			}
			
			//STORING FORM DETAILS IN FORM_DETAILS TABLE
			DataObject dobj = createRow(FormConstants.FORM_TABLE, FORM_DETAILS.TABLE, hs);
			Row row = dobj.getRow(FORM_DETAILS.TABLE);
			form = getFormFromRow(row);
			
			// Check match type->if match type is custom events match type then make an entry in form custom events table
			Integer MatchType = Integer.parseInt(hs.get(FormConstants.MATCH_TYPE));
			FormMatchType matchType = FormMatchType.getMatchTypeById(MatchType);
			if(matchType.equals(FormMatchType.CUSTOM_EVENT)) {
				Long customEventId=null;
				if(hs.containsKey(FormConstants.CUSTOM_EVENT_ID)) {
					try {
						customEventId = Long.parseLong(hs.get(FormConstants.CUSTOM_EVENT_ID));
					} catch (Exception e) {
						LOGGER.log(Level.SEVERE, "Exception occured:", e);
					}
				}
				if(customEventId==null){
				String customEventLinkname = hs.get(FormConstants.CUSTOM_EVENT_LINK_NAME);
				CustomEvent ce = CustomEvent.getCustomEventByLinkname(customEventLinkname, exp.getProjectId());
				if(ce == null) {
					throw new ZABException(ZABAction.getMessage(ZABConstants.ErrorMessages.RESOURCE_NOT_FOUND.getErrorString(), new String[]{ZABAction.getMessage(CustomEventConstants.API_MODULE)}));
				}
				customEventId = ce.getCustomEventId();
				form.setCustomevent(ce.getCustomEventLinkName());
				form.setCustomeventname(ce.getCustomEventName());
				}
				Row row1 = new Row(FORM_CUSTOM_EVENTS.TABLE);
				row1.set(FORM_CUSTOM_EVENTS.EVENT_ID, customEventId);
				row1.set(FORM_CUSTOM_EVENTS.EXPERIMENT_ID, hs.get(FormConstants.EXPERIMENT_ID));
				ZABModel.createResource(row1);
			}
			// STORING FORM FIELD DETAILS IN FORM_FIELD_DETAILS TABLE 
			if(hs.containsKey(FormConstants.FORM_FIELDS)){
				JSONArray formfields = new JSONArray(hs.get(FormConstants.FORM_FIELDS));
				ArrayList<HashMap<String,String>> arrayHash = ZABAction.parseJSON(formfields);

				ArrayList<FormFieldDetails> formFields=new ArrayList<FormFieldDetails>();
				for(int i=0;i<arrayHash.size();i++){ 
					
					FormFieldDetails form1=new FormFieldDetails();
					HashMap<String,String> hs1 = arrayHash.get(i);
					String key = generateUniqueId(FORM_FIELD_DETAILS.TABLE, FORM_FIELD_DETAILS.FORM_FIELD_KEY);
					
					hs1.put(FormConstants.EXPERIMENT_ID,hs.get(FormConstants.EXPERIMENT_ID).toString());
					hs1.put(FormConstants.FORM_FIELD_KEY,key);
					
					DataObject dobj1 = createRow(FormConstants.FORM_FIELD_DETAILS_TABLE, FORM_FIELD_DETAILS.TABLE, hs1);
					Row row1 = dobj1.getRow(FORM_FIELD_DETAILS.TABLE);
					
					form1=getFormFieldDetailsFromRow(row1);
					formFields.add(form1);
				}
				form.setFormFieldDetails(formFields);
			}
			forms.add(form);
		} catch (Exception e) {
			form.setSuccess(Boolean.FALSE);
			form.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			forms.add(form);
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		return forms;
	}
	
	public static ArrayList<Form> getFormDetails(){
		
		ArrayList<Form> forms = new ArrayList<Form>();
		Form form = new Form();
		try {
			Criteria c = null;
			DataObject dobj = ZABModel.getRow(FORM_DETAILS.TABLE, c);
			forms = getFormFromDobj(dobj);
		}
		catch (Exception e) {
			form = new Form();
			form.setSuccess(Boolean.FALSE);
			form.setResponseString(e.getMessage());
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
			forms.add(form);
		}
		return forms;
	}
	
	public static ArrayList<FormFieldDetails> getFormFieldDetails(Criteria c){
		
		ArrayList<FormFieldDetails> forms = new ArrayList<FormFieldDetails>();
		FormFieldDetails form = new FormFieldDetails();
		try {
			DataObject dobj = ZABModel.getRow(FORM_FIELD_DETAILS.TABLE, c);
			forms = getFormFieldFromDobj(dobj);
		}
		catch (Exception e) {
			form = new FormFieldDetails();
			form.setSuccess(Boolean.FALSE);
			form.setResponseString(e.getMessage());
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
			forms.add(form);
		}
		return forms;
	}
	
	public static JSONObject getJsonObject(Form f) {
		
		JSONObject json = null;
		try{
				json =new JSONObject();
				json.put(FormConstants.FORM_ELEMENT_ID,f.getFormelementid());
				json.put(FormConstants.FORM_ELEMENT_NAME,f.getFormelementname());
				json.put(FormConstants.FORM_ELEMENT_SELECTOR,f.getFormelementselector());
				json.put(FormConstants.FORM_NO_OF_FIELDS,f.getFormnooffields());
				json.put(FormConstants.EXPERIMENT_URL,f.getFormurl());
				json.put(FormConstants.MATCH_TYPE,f.getMatchtype());
				json.put(FormConstants.FORM_LOADED, f.getFormloaded());
				json.put(FormConstants.FORM_CONVERSION_URL,f.getFormconversionurl());
				json.put(FormConstants.CUSTOM_EVENT_LINK_NAME, f.getCustomevent());
				json.put(FormConstants.CUSTOM_EVENT_NAME, f.getCustomeventname());
				json.put(FormConstants.INCLUDE_URLS, f.getIncludedUrls());
				json.put(FormConstants.EXCLUDE_URLS, f.getExcludedUrls());
				json.put(FormConstants.FORM_FIELDS,FormFieldDetails.getJSONArray(f.getFormFieldDetails()));
			
		}catch(Exception e){
				LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		return json;
	}
	
	public static ArrayList<Form> updateFormDetails(HashMap<String, String> hs) {
		
		try{
			Criteria c = new Criteria(new Column(FORM_DETAILS.TABLE, FORM_DETAILS.EXPERIMENT_ID), hs.get(ExperimentConstants.EXPERIMENT_ID), QueryConstants.EQUAL);
			updateRow(FormConstants.FORM_TABLE, FORM_DETAILS.TABLE, hs, c, ExperimentConstants.API_RESOURCE);
			Integer MatchType = Integer.parseInt(hs.get(FormConstants.MATCH_TYPE));
			FormMatchType matchType = FormMatchType.getMatchTypeById(MatchType);
			Experiment exp = Experiment.getExperimentById(Long.parseLong(hs.get(FormConstants.EXPERIMENT_ID)));
			if(matchType.equals(FormMatchType.CUSTOM_EVENT)) {
				
				Long customEventId = null;
				String customEventLinkname = hs.get(FormConstants.CUSTOM_EVENT_LINK_NAME);
				CustomEvent ce = CustomEvent.getCustomEventByLinkname(customEventLinkname, exp.getProjectId());
				if(ce == null) {
					throw new ZABException(ZABAction.getMessage(ZABConstants.ErrorMessages.RESOURCE_NOT_FOUND.getErrorString(), new String[]{ZABAction.getMessage(CustomEventConstants.API_MODULE)}));
				}
				customEventId = ce.getCustomEventId();
				
				Criteria cri = new Criteria(new Column(FORM_CUSTOM_EVENTS.TABLE,FORM_DETAILS.EXPERIMENT_ID), hs.get(ExperimentConstants.EXPERIMENT_ID), QueryConstants.EQUAL);
				DataObject dobj = ZABModel.getRow(FORM_CUSTOM_EVENTS.TABLE, cri);
				if(dobj.containsTable(FORM_CUSTOM_EVENTS.TABLE)) {
					Row oldRow = dobj.getFirstRow(FORM_CUSTOM_EVENTS.TABLE);
					Long eventId = (Long)oldRow.get(FORM_CUSTOM_EVENTS.EVENT_ID);
					if(!eventId.equals(ce.getCustomEventId())) {
						oldRow.set(FORM_CUSTOM_EVENTS.EVENT_ID, ce.getCustomEventId());
						dobj.updateRow(oldRow);
						updateDataObject(dobj);
					}
				} else {
					Row row1 = new Row(FORM_CUSTOM_EVENTS.TABLE);
					row1.set(FORM_CUSTOM_EVENTS.EVENT_ID, customEventId);
					row1.set(FORM_CUSTOM_EVENTS.EXPERIMENT_ID, hs.get(FormConstants.EXPERIMENT_ID));
					ZABModel.createResource(row1);
				}
			}
			JSONArray formfields = new JSONArray(hs.get(FormConstants.FORM_FIELDS));
			int size = formfields.length();
			for(int i=0;i<size;i++){ 
				    
				JSONObject jsonobject = formfields.getJSONObject(i);
				HashMap<String,String> hs1=new HashMap<String,String>();
				hs1.put(FormConstants.EXPERIMENT_ID,hs.get(FormConstants.EXPERIMENT_ID).toString());
				hs1.put(FormConstants.FORM_FIELD_TYPE,jsonobject.getString(FormConstants.FORM_FIELD_TYPE));
				hs1.put(FormConstants.FORM_FIELD_NAME,jsonobject.getString(FormConstants.FORM_FIELD_NAME));
				hs1.put(FormConstants.FIELD_ID,jsonobject.getString(FormConstants.FIELD_ID));
				hs1.put(FormConstants.FIELD_ALIAS, jsonobject.getString(FormConstants.FIELD_ALIAS));
				hs1.put(FormConstants.IS_ENABLED, Boolean.toString(jsonobject.getBoolean(FormConstants.IS_ENABLED)));
				hs1.put(FormConstants.FORM_FIELD_KEY,jsonobject.getString(FormConstants.FORM_FIELD_KEY));
				Criteria c1=new Criteria(new Column(FORM_FIELD_DETAILS.TABLE,FORM_FIELD_DETAILS.FORM_FIELD_KEY),hs1.get(FormConstants.FORM_FIELD_KEY),QueryConstants.EQUAL);
				updateRow(FormConstants.FORM_FIELD_DETAILS_TABLE, FORM_FIELD_DETAILS.TABLE, hs1,c1,ExperimentConstants.API_RESOURCE);
			}
		}catch(Exception e){
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}
		return null;
	}
}
