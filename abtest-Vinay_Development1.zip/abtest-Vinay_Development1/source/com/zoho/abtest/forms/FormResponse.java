//$Id$
package com.zoho.abtest.forms;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;
import com.zoho.abtest.experiment.ExperimentConstants;


public class FormResponse {
	
	 private static final Logger LOGGER = Logger.getLogger(FormResponse.class.getName());

	public static String jsonResponse(HttpServletRequest request,ArrayList<Form> lst)
	{
		
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(lst);			
			JSONObject json = ZABResponse.updateMetaInfo(request, "forms", array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
		}
		return returnBuffer.toString();	
	}
	
	public static String jsonResponse(HttpServletRequest request,JSONArray array)
	{
		
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONObject json = ZABResponse.updateMetaInfo(request, "forms", array); //No I18N
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);

		}
		return returnBuffer.toString();	
	}
	
	
	
	private static JSONObject getJSONObject(Form ld) throws JSONException {
		JSONObject jsonObj = new JSONObject();
		jsonObj.put(ExperimentConstants.EXPERIMENT_ID, ld.getExperimentId());
		jsonObj.put(ExperimentConstants.EXPERIMENT_URL, ld.getFormurl());
		jsonObj.put(FormConstants.FORM_ELEMENT_ID, ld.getFormelementid());
		jsonObj.put(FormConstants.FORM_ELEMENT_NAME, ld.getFormelementname());
		jsonObj.put(FormConstants.FORM_ELEMENT_SELECTOR,ld.getFormelementselector());
		jsonObj.put(FormConstants.FORM_NO_OF_FIELDS, ld.getFormnooffields());
		jsonObj.put(FormConstants.FORM_CONVERSION_URL, ld.getFormconversionurl());
		jsonObj.put(FormConstants.FORM_FIELDS,ld.getFormFieldDetails());
		jsonObj.put(ZABConstants.RESPONSE_STRING, ld.getResponseString());
		jsonObj.put(ZABConstants.STATUS_CODE, ld.getResponseCode());
		jsonObj.put(ZABConstants.SUCCESS, ld.getSuccess());
		return jsonObj;
	}
	
	public static JSONArray getJSONArray(ArrayList<Form> lst) throws JSONException {
		
		JSONArray array = new JSONArray();
		int size =lst.size();
		for (int i=0;i<size;i++) {
			Form ld=lst.get(i);
			if(ld!=null) {				
				array.put(getJSONObject(ld));
			}
		}
		return array;
	}

}
