//$Id$
package com.zoho.abtest.forms;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.MatchQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.aggregations.metrics.cardinality.Cardinality;
import org.elasticsearch.search.aggregations.metrics.cardinality.CardinalityAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.sum.Sum;
import org.json.JSONArray;
import org.json.JSONObject;
import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.iam.IAMUtil;
import com.zoho.abtest.FORM_FIELD_DETAILS;
import com.zoho.abtest.dynamicconf.DynamicConfigurationConstants;
import com.zoho.abtest.dynamicconf.DynamicConfigurationUtil;
import com.zoho.abtest.elastic.ElasticSearchStatistics;
import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.portal.PortalConstants;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.report.ReportConstants;
import com.zoho.abtest.utility.ZABUtil;

// this class is used to calculate reports for form analytics using elastic search
//here we construct query and apply required aggregations for form analytics
public class ElasticFormReport {

	private static final Logger LOGGER = Logger.getLogger(ElasticFormReport.class.getName());

	public static  FormReport calculateFormReportUsingElasticsSearch(HashMap<String, String> hs)  {
		
		HashMap<String,String> formResponse=new HashMap<String,String>();
		FormReport fr = new FormReport();
		try{
			LOGGER.log(Level.INFO,"!!! Entered calculateFormReportUsingElasticsSearch");

		String portalName = IAMUtil.getCurrentServiceOrg().getDomains().get(0).getDomain();
		String indexName = ElasticSearchUtil.getIndexByPortal(portalName);
		hs.put(PortalConstants.PORTALNAME,portalName);
		Long experimentId=Long.parseLong(hs.get(ExperimentConstants.EXPERIMENT_ID));
		Long startDate=Long.parseLong(hs.get(FormReportConstants.START_DATE));
		Long endDate=Long.parseLong(hs.get(FormReportConstants.END_DATE));
		// calculating form visit, starter,conversion,live,spent time
		LOGGER.log(Level.INFO,"!!! Applying query for form reports for Portal:"+ portalName);
		
		QueryBuilder query =  generateSourceQueryJson(portalName,hs.get(ReportConstants.REPORT_TYPE),experimentId,startDate,endDate,hs.get(ReportConstants.MULTISEGMENT_CRITERIA),0);
		List<AggregationBuilder> aggregation = generateFormAggregationJson();
		
		SearchResponse response = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.FORM_ANALYTICS_RAW_TYPE, 0, query, aggregation);
		formResponse=readFormResponseData(response);
		
		query = null;
		aggregation = null;
		
		query =   generateSourceQueryJson(portalName,hs.get(ReportConstants.REPORT_TYPE),experimentId,startDate,endDate,hs.get(ReportConstants.MULTISEGMENT_CRITERIA),1);
		aggregation = generateFormAggregation1Json();
		
		response = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.FORM_ANALYTICS_RAW_TYPE, 0, query, aggregation);
		readFormResponseData1(response,formResponse);
		
		query = null;
		aggregation = null;
		
		query = generateSourceQueryJson(portalName,hs.get(ReportConstants.REPORT_TYPE),experimentId,startDate,endDate,hs.get(ReportConstants.MULTISEGMENT_CRITERIA),3);
		AggregationBuilder cardinalityAggregation = getVisitsCount();
		
		response = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.FORM_ANALYTICS_RAW_TYPE, 0, query, cardinalityAggregation);
		readSubmissionCountResponse(response, formResponse);
		
		LOGGER.log(Level.INFO,"!!! After Applying query Form Report Response" + formResponse.toString());

		ArrayList<HashMap<String,String>> al = calculateFormFieldReport(hs,experimentId,indexName,formResponse);
		fr = FormReport.getFormReportfromHashMap(formResponse);
		
		JSONArray jsonArray = getFormFieldsJSONArray(al);
		fr.setJsonarray(jsonArray);
		
		}catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		return fr;
	}
	
	

	public static ArrayList<HashMap<String,String>> calculateFormFieldReport(HashMap<String,String> hs,Long experimentId,String indexName,HashMap<String,String> formResponse) {
		
		ArrayList<HashMap<String,String>> al=new ArrayList<HashMap<String,String>>();
		try{
			LOGGER.log(Level.INFO,"!!! Entered calculateFormFieldReport Method");

			Long startDate=Long.parseLong(hs.get(FormReportConstants.START_DATE));
			Long endDate=Long.parseLong(hs.get(FormReportConstants.END_DATE));
			
			Criteria c=new Criteria(new Column(FORM_FIELD_DETAILS.TABLE,FORM_FIELD_DETAILS.EXPERIMENT_ID),experimentId,QueryConstants.EQUAL);
			ArrayList<FormFieldDetails> f=Form.getFormFieldDetails(c);  //to get form field id for the experiment
			List<AggregationBuilder> aggregation = generateFormFieldAggregationJson();
			List<AggregationBuilder> hesitationAggregation = generateHesitationTimeAggregationJson();
			
			HashMap<String,String> dropOffFields = new HashMap<String,String>();
			QueryBuilder query1 =   generateSourceQueryJson(hs.get(PortalConstants.PORTALNAME),hs.get(ReportConstants.REPORT_TYPE),experimentId,startDate,endDate,hs.get(ReportConstants.MULTISEGMENT_CRITERIA),2);
			List<AggregationBuilder> aggregation1 = generateFormAggregation2Json();
			SearchResponse response1 = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.FORM_ANALYTICS_RAW_TYPE, 0, query1, aggregation1);
			readFormResponseData2(response1, dropOffFields);
			LOGGER.log(Level.INFO,"!!! dropOffFields"+ dropOffFields.toString());
			Iterator it=f.iterator();
			while(it.hasNext()){
			
				FormFieldDetails f1 = (FormFieldDetails)it.next();
				Long formFieldId = f1.getFormfieldid();
				Boolean bool = f1.getIsenabled();
				if(!bool) {
					continue;
				}
				QueryBuilder query =  generateSourceQueryJson2(hs.get(PortalConstants.PORTALNAME),hs.get(ReportConstants.REPORT_TYPE),experimentId,startDate,endDate,hs.get(ReportConstants.MULTISEGMENT_CRITERIA),formFieldId,0);
				QueryBuilder query2 =  generateSourceQueryJson2(hs.get(PortalConstants.PORTALNAME),hs.get(ReportConstants.REPORT_TYPE),experimentId,startDate,endDate,hs.get(ReportConstants.MULTISEGMENT_CRITERIA),formFieldId,1);
				SearchResponse response = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.FORM_ANALYTICS_FIELDS_RAW_TYPE, 0, query, aggregation);
				HashMap<String,String> formFieldResponse=readFormFieldResponseData(response,formResponse);
				response = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.FORM_ANALYTICS_FIELDS_RAW_TYPE, 0, query2, hesitationAggregation);
				readHesitationAndCompletionResponseData(response,formFieldResponse,formResponse);
				formFieldResponse.put(FormRawDataConstants.FORM_FIELD_ID,Long.toString(formFieldId));
				if(!f1.getFieldalias().isEmpty()){
					formFieldResponse.put(FormConstants.FIELD_ALIAS, f1.getFieldalias());
				}
				if(dropOffFields.containsKey(f1.getFormfieldkey())) {
					formFieldResponse.put(FormReportConstants.FORM_FIELD_DROPOFF_COUNT, dropOffFields.get(f1.getFormfieldkey()));
				} else {
					formFieldResponse.put(FormReportConstants.FORM_FIELD_DROPOFF_COUNT,0+"");
				}
				al.add(formFieldResponse);
			}
			
		}catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
	return al;
	}


	public static HashMap<String,String> readFormResponseData(SearchResponse response) {
		
		double conversionRate = 0, abandonRate = 0, starterRate = 0, abandonCount = 0;
		
		Terms genders = response.getAggregations().get(FormReportConstants.FORM_VISITOR_COUNT);		
		Cardinality formUniqueVisitorCount=response.getAggregations().get(FormReportConstants.FORM_UNIQUE_VISITOR_COUNT);
		Sum formStarterCount= response.getAggregations().get(FormReportConstants.FORM_STARTER_COUNT);
		Sum formConversionCount= response.getAggregations().get(FormReportConstants.FORM_CONVERSION_COUNT);
		Sum formSpentTimeCount= response.getAggregations().get(FormReportConstants.FORM_SPENT_TIME);
		
		HashMap<String,String> hs=new HashMap<String,String>();
		
		if(genders.getBuckets().size()==0){
			hs.put(FormReportConstants.FORM_VISITOR_COUNT,0+"");
		}else{
			hs.put(FormReportConstants.FORM_VISITOR_COUNT,Long.toString(genders.getBuckets().get(0).getDocCount()));
		}
		
		hs.put(FormReportConstants.FORM_STARTER_COUNT,Double.toString(formStarterCount.getValue()));
		hs.put(FormReportConstants.FORM_CONVERSION_COUNT,Double.toString(formConversionCount.getValue()));
		abandonCount = formStarterCount.getValue()-formConversionCount.getValue();//-formLive.getValue();
		hs.put(FormReportConstants.FORM_ABANDON_COUNT,Double.toString(abandonCount));
		
		//check for formStarterCount whether it is > 0
		if(formStarterCount.getValue()>0){
			Double formSpentTime=formSpentTimeCount.getValue()/formStarterCount.getValue();
			hs.put(FormReportConstants.FORM_SPENT_TIME,Double.toString(formSpentTime));
		}else{
			hs.put(FormReportConstants.FORM_SPENT_TIME,0+"");
		}
		
		hs.put(FormReportConstants.FORM_UNIQUE_VISITOR_COUNT,Long.toString(formUniqueVisitorCount.getValue()));
		
		if(Double.parseDouble((hs.get(FormReportConstants.FORM_VISITOR_COUNT)))>0){
			double a = formStarterCount.getValue();
			double b = Double.parseDouble((hs.get(FormReportConstants.FORM_VISITOR_COUNT)));
			starterRate = (a/b)*100;
		}

		if(formStarterCount.getValue()>0){
			double a=formConversionCount.getValue();
			double b=formStarterCount.getValue();
			conversionRate=(a/b)*100;
		}
		
		if(formStarterCount.getValue()>0){
			double a=(formStarterCount.getValue()-formConversionCount.getValue()); //-formLive.getValue());
			double b=(formStarterCount.getValue());
			abandonRate=(a/b)*100;
		}
		hs.put(FormReportConstants.FORM_STARTER_RATE, Double.toString(starterRate));
		hs.put(FormReportConstants.FORM_ABANDON_RATE,Double.toString(abandonRate));
		hs.put(FormReportConstants.FORM_CONVERSION_RATE,Double.toString(conversionRate));
		return hs;	
	}
	
	
public static HashMap<String,String> readFormFieldResponseData(SearchResponse response, HashMap<String,String> formResponse) {
		
		
		Sum formFieldVisitCount= response.getAggregations().get(FormReportConstants.FORM_FIELD_VISIT_COUNT);
		Sum formFieldStarterCount= response.getAggregations().get(FormReportConstants.FORM_FIELD_STARTER_COUNT);
		Sum formFieldRefocusCount= response.getAggregations().get(FormReportConstants.FORM_FIELD_REFOCUS_COUNT);
		Sum formFieldCorrectionCount= response.getAggregations().get(FormReportConstants.FORM_FIELD_CORRECTION_COUNT);
		
		HashMap<String,String> hs=new HashMap<String,String>();
		hs.put(FormReportConstants.FORM_FIELD_VISIT_COUNT,Double.toString(formFieldVisitCount.getValue()));
		hs.put(FormReportConstants.FORM_FIELD_STARTER_COUNT,Double.toString(formFieldStarterCount.getValue()));
		hs.put(FormReportConstants.FORM_FIELD_REFOCUS_COUNT,Double.toString(formFieldRefocusCount.getValue()));
		hs.put(FormReportConstants.FORM_FIELD_CORRECTION_COUNT,Double.toString(formFieldCorrectionCount.getValue()));

		return hs;
	}


	public static void readFormResponseData1(SearchResponse response,HashMap<String, String> formResponse) {
		Sum formSpentTimeCount= response.getAggregations().get(FormReportConstants.FORM_SPENT_TIME);
		if(Double.parseDouble(formResponse.get(FormReportConstants.FORM_CONVERSION_COUNT))>0){
			Double avgCompletionTime=formSpentTimeCount.getValue()/Double.parseDouble(formResponse.get(FormReportConstants.FORM_CONVERSION_COUNT));
			formResponse.put(FormReportConstants.FORM_COMPLETE_TIME,Double.toString(avgCompletionTime));
		}else{
			formResponse.put(FormReportConstants.FORM_COMPLETE_TIME,0+"");
		}
	}

	
	public static void readFormResponseData2(SearchResponse response, HashMap<String, String> formFieldResponse) {
		Terms lastActiveaggr = response.getAggregations().get(FormReportConstants.LASTACTIVE);	
		List<? extends Bucket> lastActive = lastActiveaggr.getBuckets();
		for(Bucket bucket : lastActive)
		{
			String fieldKey = (String)bucket.getKey();
			String count = Long.toString(bucket.getDocCount());
			formFieldResponse.put(fieldKey, count);
		}
	}

	public static void readHesitationAndCompletionResponseData(SearchResponse response, HashMap<String, String> formFieldResponse, HashMap<String,String> formResponse){
		
		
		Sum formFieldCompletionTime= response.getAggregations().get(FormReportConstants.FORM_FIELD_COMPLETION_TIME);
		Sum formFieldHesitationTime= response.getAggregations().get(FormReportConstants.FORM_FIELD_HESITATION_TIME);
		Double formFieldStarterCount = Double.parseDouble(formFieldResponse.get(FormReportConstants.FORM_FIELD_STARTER_COUNT));
		double hesitationPercentage = 0;
		if(formFieldStarterCount>0){
			Double avgCompletionTime=formFieldCompletionTime.getValue()/formFieldStarterCount;
			Double avgHesitationTime=formFieldHesitationTime.getValue()/formFieldStarterCount;
			if(avgCompletionTime>0){
				hesitationPercentage  = (avgHesitationTime/avgCompletionTime)*100;
			}
			formFieldResponse.put(FormReportConstants.FORM_FIELD_COMPLETION_TIME,Double.toString(avgCompletionTime));
			formFieldResponse.put(FormReportConstants.FORM_FIELD_HESITATION_TIME,Double.toString(avgHesitationTime));
			formFieldResponse.put(FormReportConstants.HESITATION_PERCENTAGE,Double.toString(hesitationPercentage));
		}
		else{
			formFieldResponse.put(FormReportConstants.FORM_FIELD_COMPLETION_TIME,0+"");
			formFieldResponse.put(FormReportConstants.FORM_FIELD_HESITATION_TIME,0+"");
			formFieldResponse.put(FormReportConstants.HESITATION_PERCENTAGE,0+"");	
		}
		
		Double formStarterCount = Double.parseDouble(formResponse.get(FormReportConstants.FORM_STARTER_COUNT));
		double blankPercentage = 0, filledPercentage = 0, filledCount = 0, blankCount = 0;
		
		Sum filledRate= response.getAggregations().get(FormReportConstants.FILLED_RATE); //filled count
		Sum formFieldBlankRate= response.getAggregations().get(FormReportConstants.FORM_FIELD_BLANK_COUNT); //blank count
		
		if(formStarterCount > 0){
			filledCount = filledRate.getValue(); 
			blankCount = formStarterCount - filledCount;
			filledPercentage = (filledCount/formStarterCount)*100;
			blankPercentage = (blankCount/formStarterCount)*100;
		}
		
		formFieldResponse.put(FormReportConstants.FORM_FIELD_BLANK_COUNT,Double.toString(blankCount));
		formFieldResponse.put(FormReportConstants.FILLED_RATE, Double.toString(filledCount));
		formFieldResponse.put(FormReportConstants.BLANK_PERCENTAGE, Double.toString(blankPercentage));
		formFieldResponse.put(FormReportConstants.FILLED_PERCENTAGE, Double.toString(filledPercentage));
	}

	public static List<AggregationBuilder> generateFormAggregationJson() {
		
		List<AggregationBuilder>  ab=new ArrayList<AggregationBuilder>();
		AggregationBuilder formUniqueVisitorCount=getVisitorCardinalityAggr();  //unique visitor count
		AggregationBuilder formVisitCount =AggregationBuilders.terms(FormReportConstants.FORM_VISITOR_COUNT).field(ElasticSearchConstants.EXPERIMENTID).size(ElasticSearchConstants.INTEGER_MAX_COUNT); 
		AggregationBuilder  formStarterCount=AggregationBuilders.sum(FormReportConstants.FORM_STARTER_COUNT).field(FormRawDataConstants.FORM_STARTER); 
		AggregationBuilder  formConversionCount=AggregationBuilders.sum(FormReportConstants.FORM_CONVERSION_COUNT).field(FormRawDataConstants.FORM_CONVERSION); 
		AggregationBuilder  formSpentTimeCount=AggregationBuilders.sum(FormReportConstants.FORM_SPENT_TIME).field(FormRawDataConstants.FORM_SPENT_TIME);

		ab.add(formUniqueVisitorCount);
		ab.add(formVisitCount);
		ab.add(formStarterCount);
		ab.add(formConversionCount);
		ab.add(formSpentTimeCount);

		return ab;
	}
	

	public static List<AggregationBuilder> generateFormAggregation1Json() {
		List<AggregationBuilder>  ab=new ArrayList<AggregationBuilder>();
		AggregationBuilder  formSpentTimeCount=AggregationBuilders.sum(FormReportConstants.FORM_SPENT_TIME).field(FormRawDataConstants.FORM_SPENT_TIME);
		ab.add(formSpentTimeCount);
		return ab;
	}
	
	public static List<AggregationBuilder> generateFormAggregation2Json() {
		List<AggregationBuilder>  ab = new ArrayList<AggregationBuilder>();
		AggregationBuilder  lastActive = AggregationBuilders.terms(FormReportConstants.LASTACTIVE).field(FormReportConstants.LASTACTIVE).size(ElasticSearchConstants.INTEGER_MAX_COUNT);
		ab.add(lastActive);
		return ab;
	}
	
	public static List<AggregationBuilder> generateFormFieldAggregationJson() {
		
		List<AggregationBuilder>  ab=new ArrayList<AggregationBuilder>();
		AggregationBuilder formFieldVisitCount =AggregationBuilders.sum(FormReportConstants.FORM_FIELD_VISIT_COUNT).field(FormRawDataConstants.FORM_FIELD_VISIT); 
		AggregationBuilder  formFieldStarterCount=AggregationBuilders.sum(FormReportConstants.FORM_FIELD_STARTER_COUNT).field(FormRawDataConstants.FORM_FIELD_STARTER); 
		AggregationBuilder  formFieldRefocusCount=AggregationBuilders.sum(FormReportConstants.FORM_FIELD_REFOCUS_COUNT).field(FormRawDataConstants.FORM_FIELD_REFOCUS); 
		AggregationBuilder  formFieldCorrectionCount=AggregationBuilders.sum(FormReportConstants.FORM_FIELD_CORRECTION_COUNT).field(FormRawDataConstants.FORM_FIELD_CORRECTION);
		
		ab.add(formFieldVisitCount);
		ab.add(formFieldStarterCount);
		ab.add(formFieldRefocusCount);
		ab.add(formFieldCorrectionCount);
		
		return ab;
	}
	
	public static List<AggregationBuilder> generateHesitationTimeAggregationJson() {
	
		List<AggregationBuilder>  ab=new ArrayList<AggregationBuilder>();
	
		AggregationBuilder  formFieldCompletionTime=AggregationBuilders.sum(FormReportConstants.FORM_FIELD_COMPLETION_TIME).field(FormRawDataConstants.FORM_FIELD_COMPLETION_TIME);
		AggregationBuilder  formFieldHesitationTime=AggregationBuilders.sum(FormReportConstants.FORM_FIELD_HESITATION_TIME).field(FormRawDataConstants.FORM_FIELD_HESITATION_TIME);
		AggregationBuilder  filledRate=AggregationBuilders.sum(FormReportConstants.FILLED_RATE).field(FormRawDataConstants.FILLED_RATE);
		AggregationBuilder  formFieldBlankRate=AggregationBuilders.sum(FormReportConstants.FORM_FIELD_BLANK_COUNT).field(FormRawDataConstants.FORM_FIELD_BLANKRATE);
		
		ab.add(formFieldCompletionTime);
		ab.add(formFieldHesitationTime);
		ab.add(filledRate);
		ab.add(formFieldBlankRate);
	
		return ab;
	}

	public static BoolQueryBuilder generateSourceQueryJson(String portal, String reportType, Long expId, Long startTime, Long endTime, String multisegmentCriteria, int type)
	{
		BoolQueryBuilder boolQuery =  null;
		try
		{
			if(reportType.equals(ReportConstants.SUMMARY))
			{
				boolQuery = ElasticSearchStatistics.generateSourceQueryJson(portal,expId,startTime,endTime,false,null,false,null,null);
			}
			else if(reportType.equals(ReportConstants.MULTISEGMENT))
			{
				boolQuery = ElasticSearchStatistics.generateSourceMultiSegmentQueryJson(portal,expId, startTime, endTime, multisegmentCriteria, false, null, null,null);
			}

			if(type == 1){
				MatchQueryBuilder expMatch1 = QueryBuilders.matchQuery(FormRawDataConstants.FORM_CONVERSION,1);
				boolQuery.must().add(expMatch1);
			} else if(type == 2) {
				MatchQueryBuilder expMatch1 = QueryBuilders.matchQuery(FormRawDataConstants.FORM_CONVERSION,0);
				boolQuery.must().add(expMatch1);
			} else if(type == 3) {
				RangeQueryBuilder expMatch1 = QueryBuilders.rangeQuery(FormRawDataConstants.FORM_SUBMISSION).gte(1);
				boolQuery.must().add(expMatch1);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		return boolQuery;
	}
	
	public static BoolQueryBuilder generateSourceQueryJson2(String portal, String reportType, Long expId, Long startTime, Long endTime, String multisegmentCriteria,Long formFieldId,int type)
	{
		BoolQueryBuilder boolQuery =  null;
		try
		{
			if(reportType.equals(ReportConstants.SUMMARY))
			{
				boolQuery = ElasticSearchStatistics.generateSourceQueryJson(portal,expId,startTime,endTime,false,null,false,null,null);
			}
			else if(reportType.equals(ReportConstants.MULTISEGMENT))
			{
				boolQuery = ElasticSearchStatistics.generateSourceMultiSegmentQueryJson(portal,expId, startTime, endTime, multisegmentCriteria, false, null, null,null);
			}
			if(type == 1){
				MatchQueryBuilder expMatch = QueryBuilders.matchQuery(FormRawDataConstants.FORM_FIELD_STARTER,1);
				boolQuery.must().add(expMatch);
			}
			MatchQueryBuilder expMatch1 = QueryBuilders.matchQuery(FormReportConstants.FORM_FIELD_ID,formFieldId);
			boolQuery.must().add(expMatch1);

		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		return boolQuery;
	}
	
	public static CardinalityAggregationBuilder getVisitorCardinalityAggr(){
		
		int precisionThreshold = DynamicConfigurationConstants.ES_CARDINALITY_THRESHOLD_VALUE;
		String thresholdStr = DynamicConfigurationUtil.getDynamicPropertyValueByName(DynamicConfigurationConstants.ES_CARDINALITY_THRESHOLD);
		if(StringUtils.isNotEmpty(thresholdStr)){
			precisionThreshold = Integer.parseInt(thresholdStr);
		}
		
		CardinalityAggregationBuilder cardinalityAggregation = AggregationBuilders.cardinality(FormReportConstants.FORM_UNIQUE_VISITOR_COUNT).  
																field(ElasticSearchConstants.UUID).
																precisionThreshold(precisionThreshold);
		return cardinalityAggregation;
	}
	
	public static void setFormAnalyticsExperimentDetailsFromES(FormAnalyticsExperiment experiment) {
		// TODO Auto-generated method stub
		try{
			
			Long experimentId = experiment.getExperimentId();		
			experiment = getFormAnalyticsExperimentCardDetails(experimentId,experiment);
	
		}catch(Exception ex) {
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
	}

public static List<AggregationBuilder> generateMetaDataAggregation() {
	
	List<AggregationBuilder>  ab=new ArrayList<AggregationBuilder>();
	AggregationBuilder formVisitCount =AggregationBuilders.terms(FormReportConstants.FORM_VISITOR_COUNT).field(ElasticSearchConstants.EXPERIMENTID).size(ElasticSearchConstants.INTEGER_MAX_COUNT); 
	AggregationBuilder  formStarterCount=AggregationBuilders.sum(FormReportConstants.FORM_STARTER_COUNT).field(FormRawDataConstants.FORM_STARTER); 
	AggregationBuilder  formConversionCount=AggregationBuilders.sum(FormReportConstants.FORM_CONVERSION_COUNT).field(FormRawDataConstants.FORM_CONVERSION); 
	ab.add(formVisitCount);
	ab.add(formStarterCount);
	ab.add(formConversionCount);
	return ab;
}
public static void readMetaDataFromResponse(SearchResponse response, FormAnalyticsExperiment experiment){
	
	double conversionRate = 0;
	Terms genders = response.getAggregations().get(FormReportConstants.FORM_VISITOR_COUNT);		
	Sum formStarterCount= response.getAggregations().get(FormReportConstants.FORM_STARTER_COUNT);
	Sum formConversionCount= response.getAggregations().get(FormReportConstants.FORM_CONVERSION_COUNT);
	if(genders.getBuckets().size()==0){
		experiment.setVisitsCount(0L);
	}else{
		experiment.setVisitsCount(genders.getBuckets().get(0).getDocCount());
	}
	experiment.setStartersCount(formStarterCount.getValue());
	if(formStarterCount.getValue()>0){
		double a = formConversionCount.getValue();
		double b = formStarterCount.getValue();
		conversionRate=(a/b)*100;
	}
	experiment.setConversionRate((double)Math.round((double)conversionRate*100)/ 100);
}

	public static FormAnalyticsExperiment getFormAnalyticsExperimentCardDetails(Long experimentId, FormAnalyticsExperiment experiment) {
		
		BoolQueryBuilder filterJson =  null;
		List<AggregationBuilder> aggrsJson = null;

		try{
			String portal = ZABUtil.getPortaldomain();
			String index = ElasticSearchUtil.getIndexByPortal(portal);
			filterJson =  generateSourceQueryJson(portal, ReportConstants.SUMMARY, experimentId, null, null, null,0);
			aggrsJson = generateMetaDataAggregation();
			SearchResponse response = ElasticSearchUtil.getData(index, ElasticSearchConstants.FORM_ANALYTICS_RAW_TYPE, 0, filterJson, aggrsJson);
			readMetaDataFromResponse(response,experiment);
		}catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		return experiment;
	}
	
	public static JSONArray getFormFieldsJSONArray(ArrayList<HashMap<String,String>> fieldsArray) {
		
		JSONArray jsonArray = new JSONArray();
		try {
			for(int i = 0; i < fieldsArray.size(); i++) {
				HashMap<String,String> hs = fieldsArray.get(i);
				JSONObject jObject = new JSONObject();
				jObject.put(FormReportConstants.FORM_FIELD_ID, Long.parseLong(hs.get(FormReportConstants.FORM_FIELD_ID)));
				jObject.put(FormReportConstants.FORM_FIELD_VISIT_COUNT, Double.parseDouble(hs.get(FormReportConstants.FORM_FIELD_VISIT_COUNT)));
				jObject.put(FormReportConstants.FORM_FIELD_REFOCUS_COUNT, Double.parseDouble(hs.get(FormReportConstants.FORM_FIELD_REFOCUS_COUNT)));
				jObject.put(FormReportConstants.FORM_FIELD_STARTER_COUNT, Double.parseDouble(hs.get(FormReportConstants.FORM_FIELD_STARTER_COUNT)));
				jObject.put(FormReportConstants.FORM_FIELD_CORRECTION_COUNT,Double.parseDouble(hs.get(FormReportConstants.FORM_FIELD_CORRECTION_COUNT)));
				
				jObject.put(FormReportConstants.HESITATION_PERCENTAGE, Double.parseDouble(hs.get(FormReportConstants.HESITATION_PERCENTAGE)));
				jObject.put(FormReportConstants.FORM_FIELD_HESITATION_TIME, Double.parseDouble(hs.get(FormReportConstants.FORM_FIELD_HESITATION_TIME)));
				jObject.put(FormReportConstants.FORM_FIELD_COMPLETION_TIME, Double.parseDouble(hs.get(FormReportConstants.FORM_FIELD_COMPLETION_TIME)));
				
				jObject.put(FormReportConstants.BLANK_PERCENTAGE, Double.parseDouble(hs.get(FormReportConstants.BLANK_PERCENTAGE)));
				jObject.put(FormReportConstants.FORM_FIELD_BLANK_COUNT, Double.parseDouble(hs.get(FormReportConstants.FORM_FIELD_BLANK_COUNT)));

				jObject.put(FormReportConstants.FILLED_PERCENTAGE, Double.parseDouble(hs.get(FormReportConstants.FILLED_PERCENTAGE)));
				jObject.put(FormReportConstants.FILLED_RATE, Double.parseDouble(hs.get(FormReportConstants.FILLED_RATE)));
				
				jObject.put(FormReportConstants.FORM_FIELD_DROPOFF_COUNT, Double.parseDouble(hs.get(FormReportConstants.FORM_FIELD_DROPOFF_COUNT)));

				jObject.put(FormConstants.FIELD_ALIAS, hs.get(FormConstants.FIELD_ALIAS));
				jsonArray.put(jObject);
				
			}

		} catch(Exception e) {
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		return jsonArray;
		
	}
	
	public static CardinalityAggregationBuilder getVisitsCount(){
		
		int precisionThreshold = DynamicConfigurationConstants.ES_CARDINALITY_THRESHOLD_VALUE;
		String thresholdStr = DynamicConfigurationUtil.getDynamicPropertyValueByName(DynamicConfigurationConstants.ES_CARDINALITY_THRESHOLD);
		if(StringUtils.isNotEmpty(thresholdStr)){
			precisionThreshold = Integer.parseInt(thresholdStr);
		}
		
		CardinalityAggregationBuilder cardinalityAggregation = AggregationBuilders.cardinality(FormReportConstants.FORM_VISITOR_COUNT).  
																field(ElasticSearchConstants.UVID).
																precisionThreshold(precisionThreshold);
		return cardinalityAggregation;
	}
	
	public static void readSubmissionCountResponse(SearchResponse response, HashMap<String, String> formFieldResponse) {
		
		Cardinality formSubmissionCount = response.getAggregations().get(FormReportConstants.FORM_VISITOR_COUNT);
		formFieldResponse.put(FormReportConstants.FORM_SUBMISSION_COUNT,Long.toString(formSubmissionCount.getValue()));
	}
	
	
	
}
