//$Id$
package com.zoho.abtest.forms;



import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.json.JSONArray;

import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.listener.IPRestrictionData;
import com.zoho.abtest.listener.ZABListener;
import com.zoho.abtest.report.ReportRawDataConstants;
import com.zoho.abtest.report.VisitorRawDataWrapper;
import com.zoho.mqueue.consumer.MessageListener;

public class VisitorFormRawDataListener extends ZABListener implements MessageListener<String, String>{
	
	private static final Logger LOGGER = Logger.getLogger(VisitorFormRawDataListener.class.getName());

	@Override
	public IPRestrictionData getIPRestrictionData(Object message)
			throws ZABException {
		VisitorRawDataWrapper wrapper = (VisitorRawDataWrapper)message;
			HashMap<String, String> hs = wrapper.getFormData();
			String portal = hs.get(ReportRawDataConstants.PORTAL);
			JSONArray json;
			String experimentKey = null;
			try{
				json= new JSONArray(hs.get(ReportRawDataConstants.EXPERIMENT_KEY));
				experimentKey = json.getString(0);
			}catch(Exception e){
				LOGGER.log(Level.SEVERE, e.getMessage(),e);
			}
			
			setDBSpace(portal);
			Long projectId = Experiment.getProjectIdByExperimentKey(experimentKey);
			LOGGER.log(Level.INFO, "Getting IP Address from visitor raw data:"+experimentKey+", "+projectId+", ****");
			return new IPRestrictionData(portal, projectId, wrapper.getIpAddress());
	}

	@Override
	public void consumeMessage(Object object) throws Exception {
		try{
			if(object!=null) {
				VisitorRawDataWrapper wrapper = (VisitorRawDataWrapper)object;
				VisitorFormRawDataHandler.addFormAnalyticsData(wrapper);
			}	
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			throw new Exception(e);
		}
	}

}
