//$Id$
package com.zoho.abtest.forms;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.FORM_DETAILS;
import com.zoho.abtest.FORM_FIELD_DETAILS;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.report.ElasticSearchConstants.FormFieldRawDataType;
import com.zoho.abtest.report.ElasticSearchConstants.FormRawDataType;
import com.zoho.abtest.report.ReportRawDataConstants;
import com.zoho.abtest.report.VisitorRawDataHandler;
import com.zoho.abtest.report.VisitorRawDataWrapper;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUtil;

public class VisitorFormRawDataHandler extends ZABModel {
	
	private static final Logger LOGGER = Logger.getLogger(VisitorFormRawDataHandler.class.getName());
	private static final long serialVersionUID = 1L;

	public static void addFormAnalyticsData(VisitorRawDataWrapper wrapper){	
		
		try{
		String dbSpaceId = null;
		Long zsoid = ZABServiceOrgUtil.getZSOIDFromDomain(wrapper.getFormData().get(ReportRawDataConstants.PORTAL));
		if(zsoid != null)
		{
			dbSpaceId = zsoid.toString();
		}
		else{
			
			LOGGER.log(Level.SEVERE,"Invalid portal provided :" +wrapper.getFormData().get(ReportRawDataConstants.PORTAL));
			LOGGER.log(Level.SEVERE,wrapper.getFormData().toString());
		}
		ZABUtil.setDBSpace(dbSpaceId);
		LOGGER.log(Level.INFO,"!!! Form Raw Data Received: {}" + wrapper.getFormData().toString());
		addFormDataToElasticSearch(wrapper);
		}catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
			LOGGER.log(Level.SEVERE,e.getMessage(),wrapper.getFormData().toString());
		}
	}

	public static void addFormDataToElasticSearch(VisitorRawDataWrapper wrapper) {
		
	try{
			LOGGER.log(Level.INFO,"!!! Entered addFormDataToElasticSearch Method");

			String portal=wrapper.getFormData().get(ReportRawDataConstants.PORTAL);

			String index = ElasticSearchUtil.getIndexByPortal(portal);
			String type = ElasticSearchConstants.FORM_ANALYTICS_RAW_TYPE;
			String fieldType=ElasticSearchConstants.FORM_ANALYTICS_FIELDS_RAW_TYPE;
			
			ArrayList<HashMap<String, String>> formanalyticspoints = wrapper.getFormanalyticspoints();			
			for (HashMap<String,String> hp : formanalyticspoints) { 
				
				HashMap<String, String> userAgenths = wrapper.getUserAgenths();
				Experiment exp = Experiment.getExperimentByKey(hp.get(FormRawDataConstants.EXPERIMENT_KEY));
				Long experimentId = exp.getExperimentId();

				hp.put(FormRawDataConstants.EXPERIMENT_ID, experimentId.toString());
				
				String experiment_id = experimentId.toString();
				String visit_id = userAgenths.get(ReportRawDataConstants.UVID);
				String id = experiment_id+visit_id;
				
				JSONObject rawdata = buildFormAnalyticsDetailsForElasticSearch(hp);
				rawdata.put(ElasticSearchConstants.PORTAL, portal);
				rawdata.put(ElasticSearchConstants.ZSOID, ZABServiceOrgUtil.getZSOIDFromDomain(wrapper.getFormData().get(ReportRawDataConstants.PORTAL)));
				int request = Integer.parseInt(hp.get(FormRawDataConstants.REQUEST));
				if(request == 0){
					AddUserAgentInToRawData(rawdata,userAgenths,wrapper.getIpAddress(),wrapper);
					initializeFormDetails(rawdata);
				}
				if(rawdata.has(FormReportConstants.LASTACTIVE)){
					ArrayList<FormFieldDetails> fields = null;
					Boolean isFormLoadedCond = isFormLoaded(experimentId);
					String formFieldName = rawdata.getString(FormReportConstants.LASTACTIVE);
					String formFieldKey = null;
					if(isFormLoadedCond == false){
						fields = getFormFieldDetailsFromFieldAlias(experimentId,formFieldName);
						if(fields.size()<=0){
							Row row = insertRowInFormFieldDetails(experimentId,formFieldName,null,null,null);
							formFieldKey = (String)row.get(FORM_FIELD_DETAILS.FORM_FIELD_KEY);
						} else {
							FormFieldDetails ffd = fields.get(0);
							formFieldKey = ffd.getFormfieldkey();
						}
						rawdata.put(FormReportConstants.LASTACTIVE, formFieldKey);
					}
				}
				LOGGER.log(Level.INFO,"!!! formAnalytics Point" + rawdata.toString());

				LOGGER.log(Level.INFO,"!!! Before Upserting Form data in elastic Search");

				ElasticSearchUtil.upsertIndex(index, type, id, rawdata.toString());
				
				LOGGER.log(Level.INFO,"!!! After Upserting Form data in elastic Search");

				updateFormFields(hp,index,fieldType,wrapper);
			}
		}	catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
	}
	
	public static void updateFormFields(HashMap<String,String> hp,String index,String fieldType,VisitorRawDataWrapper wrapper){
		try{
			
			LOGGER.log(Level.INFO,"!!! Entered updateFormFields Method");

			Long experimentId=Long.parseLong(hp.get(FormRawDataConstants.EXPERIMENT_ID));
			String visit_id=wrapper.getUserAgenths().get(ReportRawDataConstants.UVID);
			int request=Integer.parseInt(hp.get(FormRawDataConstants.REQUEST));
			
			Criteria c=new Criteria(new Column(FORM_FIELD_DETAILS.TABLE,FORM_FIELD_DETAILS.EXPERIMENT_ID),experimentId,QueryConstants.EQUAL);
			DataObject dobj = null;
			Boolean isFormLoadedCond = isFormLoaded(experimentId); 
			String formFieldId;
			if(request == 0){
				
				LOGGER.log(Level.INFO,"!!! Request =" + request + "FormAutoLoaded" + isFormLoadedCond);

				if(isFormLoadedCond == false){
					
					JSONArray formfields = new JSONArray(hp.get(FormConstants.FORM_FIELDS));
					LOGGER.log(Level.INFO,"!!! formFields" + hp.get(FormConstants.FORM_FIELDS));
					insertFieldDetailsInFormFieldDetailsTable(formfields, experimentId);
				}
				dobj = getRow(FORM_FIELD_DETAILS.TABLE,c);
				ArrayList<Long> arraylist=FormRawData.getFormFieldDetails(dobj);
				for(int i = 0; i < arraylist.size(); i++){ 
					formFieldId=arraylist.get(i).toString();
					JSONObject rawdata = new JSONObject();
					rawdata.put(ElasticSearchConstants.PORTAL, wrapper.getFormData().get(ReportRawDataConstants.PORTAL));
					rawdata.put(ElasticSearchConstants.ZSOID, ZABServiceOrgUtil.getZSOIDFromDomain(wrapper.getFormData().get(ReportRawDataConstants.PORTAL)));
					rawdata.put(ElasticSearchConstants.EXPERIMENTID,experimentId);
					rawdata.put(FormRawDataConstants.FORM_FIELD_ID,arraylist.get(i));
					rawdata.put(FormRawDataConstants.TIME,wrapper.getTime());
					initializeFormFieldDetails(rawdata);
					AddUserAgentInToRawData(rawdata,wrapper.getUserAgenths(),wrapper.getIpAddress(),wrapper);
					String id=visit_id+experimentId+formFieldId;
					ElasticSearchUtil.upsertIndex(index,fieldType,id,rawdata.toString());
				}
			}
			else{
				JSONArray formfields = new JSONArray(hp.get(FormConstants.FORM_FIELDS));
				LOGGER.log(Level.INFO,"!!! formFields" + hp.get(FormConstants.FORM_FIELDS));
				if(isFormLoadedCond == false){
					insertFieldDetailsInFormFieldDetailsTable(formfields, experimentId);
				}
				dobj = getRow(FORM_FIELD_DETAILS.TABLE,c);
				ArrayList<FormFieldDetails> arraylist = Form.getFormFieldFromDobj(dobj);

				Long form_field_id = null;
				for(int i = 0; i < formfields.length(); i++) {
					
					if(isFormLoadedCond == false){
						
						if(formfields.getJSONObject(i).has(FormConstants.FORM_FIELD_NAME1)){
							String formFieldName = formfields.getJSONObject(i).getString(FormConstants.FORM_FIELD_NAME1);
							ArrayList<FormFieldDetails> fields = getFormFieldDetailsFromFieldAlias(experimentId,formFieldName);
							FormFieldDetails ffd = fields.get(0);
							form_field_id = ffd.getFormfieldid();
						}
					}
					JSONObject rawdata = buildFormFieldDetailsForElasticSearch(getJsonFromJson(formfields.getJSONObject(i),arraylist,isFormLoadedCond,form_field_id));
					AddUserAgentInToRawData(rawdata,wrapper.getUserAgenths(),wrapper.getIpAddress(),wrapper);
					rawdata.put(ElasticSearchConstants.PORTAL, wrapper.getFormData().get(ReportRawDataConstants.PORTAL));
					rawdata.put(ElasticSearchConstants.ZSOID, ZABServiceOrgUtil.getZSOIDFromDomain(wrapper.getFormData().get(ReportRawDataConstants.PORTAL)));
					rawdata.put(ElasticSearchConstants.EXPERIMENTID,experimentId);
					rawdata.put(FormRawDataConstants.TIME,wrapper.getTime());
					formFieldId=String.valueOf(rawdata.getLong(FormRawDataConstants.FORM_FIELD_ID));
					String id=visit_id+experimentId+formFieldId;
					//check for Blank Fields:-
					checkBlankFieldsAndFilledFields(rawdata);
					LOGGER.log(Level.INFO,"!!! Before Upserting Form Field data in elastic Search"+ rawdata);

					ElasticSearchUtil.upsertIndex(index,fieldType,id,rawdata.toString());
					
					LOGGER.log(Level.INFO,"!!! After Upserting Form Field data in elastic Search");

				}
			}
		}catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
	}
	
	public static JSONObject AddUserAgentInToRawData(JSONObject rawdata,HashMap<String,String> userAgenths,String ipaddress,VisitorRawDataWrapper wrapper) throws Exception{
		
		LOGGER.log(Level.INFO,"!!! AddUserAgentInToRawData");

		String browser = userAgenths.get(ReportRawDataConstants.BROWSER_VALUE).toUpperCase();
		String device = userAgenths.get(ReportRawDataConstants.DEVICE_VALUE).toUpperCase();
		String os = userAgenths.get(ReportRawDataConstants.OS_VALUE).toUpperCase();
		String trafficsource = userAgenths.get(ReportRawDataConstants.TRAFFICSOURCE_VALUE).toUpperCase();
		String refurl = userAgenths.get(ReportRawDataConstants.REFFERERURL_VALUE);
		String currenturl = userAgenths.get(ReportRawDataConstants.CURRENTURL_VALUE);
		String language = ZABUtil.getLanguageFromCode(userAgenths.get(ReportRawDataConstants.LANGUAGE_VALUE).toUpperCase());
		String urlParamStr = userAgenths.get(ReportRawDataConstants.URLPARAMETER_VALUE);
		JSONArray urlParamArr = VisitorRawDataHandler.parseUrlparamValues(urlParamStr);
		String country = null;
		String city = null;
		String region = null;
		String userType = null;
		
		Boolean isNewVisitor = Boolean.parseBoolean(wrapper.getFormData().get(ReportRawDataConstants.IS_NEW_VISITOR));
		userType = isNewVisitor?"NEW":"RETURNING"; //No I18N
		
		//Get country details from IP Address
		JSONObject ipDetailsJson = ZABUtil.getIpAddressDetails(ipaddress);
		//Used hyphen since the api returns hyphen if ip is invalid kinda scenarios
		country = ipDetailsJson.has("COUNTRY_NAME") ? ipDetailsJson.get("COUNTRY_NAME").toString() : "-"; //NO I18N
		if(StringUtils.isEmpty(country) || country.equals("-"))
		{
			country = ReportRawDataConstants.UNKNOWN_VALUE;
		}
		country = country.toUpperCase();
		//Get city details
		city = ipDetailsJson.has("CITY") ? ipDetailsJson.get("CITY").toString() : "-"; //NO I18N
		if(StringUtils.isEmpty(city) || city.equals("-"))
		{
			city = ReportRawDataConstants.UNKNOWN_VALUE;
		}
		city = city.toUpperCase();
		//Get region details
		region = ipDetailsJson.has("REGION") ? ipDetailsJson.get("REGION").toString() : "-"; //NO I18N
		if(StringUtils.isEmpty(region) || region.equals("-"))
		{
			region = ReportRawDataConstants.UNKNOWN_VALUE;
		}
		region = region.toUpperCase();
		
		rawdata.put(ElasticSearchConstants.UVID, userAgenths.get(ReportRawDataConstants.UVID));
		rawdata.put(ElasticSearchConstants.UUID,userAgenths.get(ReportRawDataConstants.UUID));
		rawdata.put(ElasticSearchConstants.DEVICE, device);
		rawdata.put(ElasticSearchConstants.COUNTRY, country); 
		rawdata.put(ElasticSearchConstants.CITY, city);
		rawdata.put(ElasticSearchConstants.REGION, region); 
		rawdata.put(ElasticSearchConstants.OS, os);
		rawdata.put(ElasticSearchConstants.BROWSER, browser);
		rawdata.put(ElasticSearchConstants.USERTYPE, userType);
		rawdata.put(ElasticSearchConstants.LANGUAGE, language);
		rawdata.put(ElasticSearchConstants.CURRENTURL,currenturl);
		rawdata.put(ElasticSearchConstants.REFFERERURL, refurl);
		rawdata.put(ElasticSearchConstants.TRAFFICSOURCE, trafficsource);
		rawdata.put(ElasticSearchConstants.DAYOFWEEK, ZABUtil.getDayOfWeek(wrapper.getTime()));  
		rawdata.put(ElasticSearchConstants.HOUROFDAY, ZABUtil.getHourOfDay(wrapper.getTime()));
		rawdata.put(ElasticSearchConstants.NURLPARAMETER,urlParamArr );
		rawdata.put(FormRawDataConstants.TIME,wrapper.getTime());
		return rawdata;
	}
		
	public static void initializeFormDetails(JSONObject rawdata) {
		
		try{
			rawdata.put(FormRawDataConstants.FORM_STARTER,0);
			rawdata.put(FormRawDataConstants.FORM_CONVERSION,0);
			rawdata.put(FormRawDataConstants.FORM_SUBMISSION,0);
		//	rawdata.put(FormRawDataConstants.FORM_LIVE,1);
			rawdata.put(FormRawDataConstants.FORM_SPENT_TIME, 0);
		}catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
	}

	
	
	
	public static void initializeFormFieldDetails(JSONObject rawdata) {
		
		try{
			rawdata.put(FormRawDataConstants.FORM_FIELD_VISIT, 0);
			rawdata.put(FormRawDataConstants.FORM_FIELD_STARTER,0);
			rawdata.put(FormRawDataConstants.FORM_FIELD_REFOCUS,0);
			rawdata.put(FormRawDataConstants.FORM_FIELD_CORRECTION,0);
			rawdata.put(FormRawDataConstants.FORM_FIELD_BLANKRATE,0);
			//rawdata.put(FormRawDataConstants.FORM_FIELD_DROPOFF, 0);
			rawdata.put(FormRawDataConstants.FORM_FIELD_HESITATION_TIME, 0);
			rawdata.put(FormRawDataConstants.FORM_FIELD_COMPLETION_TIME, 0);
			rawdata.put(FormRawDataConstants.FILLED_RATE, 0);
		}catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
	}

	private static JSONObject getJsonFromJson(JSONObject jsonObject,ArrayList<FormFieldDetails> arrayList,Boolean formLoaded,Long form_field_id) {
		
		JSONObject json=new JSONObject();
		try{
			if(formLoaded==true){
				if(jsonObject.has(FormRawDataConstants.FORM_FIELD_ID)){
					Long formFieldId=getFormFieldIdFromArrayList(arrayList,jsonObject.getString(FormRawDataConstants.FORM_FIELD_ID));
					json.put(FormRawDataConstants.FORM_FIELD_ID,formFieldId);
				}
			} else {
				json.put(FormRawDataConstants.FORM_FIELD_ID,form_field_id);
			}
		if(jsonObject.has(FormRawDataConstants.FORM_FIELD_VISIT)){
			json.put(FormRawDataConstants.FORM_FIELD_VISIT,Integer.parseInt(jsonObject.getString(FormRawDataConstants.FORM_FIELD_VISIT)));
		}
		if(jsonObject.has(FormRawDataConstants.FORM_FIELD_STARTER)){
			json.put(FormRawDataConstants.FORM_FIELD_STARTER,Integer.parseInt(jsonObject.getString(FormRawDataConstants.FORM_FIELD_STARTER)));
		}
		if(jsonObject.has(FormRawDataConstants.FORM_FIELD_REFOCUS)){
			json.put(FormRawDataConstants.FORM_FIELD_REFOCUS,Integer.parseInt(jsonObject.getString(FormRawDataConstants.FORM_FIELD_REFOCUS)));
		}
		if(jsonObject.has(FormRawDataConstants.FORM_FIELD_CORRECTION)){
			json.put(FormRawDataConstants.FORM_FIELD_CORRECTION,Integer.parseInt(jsonObject.getString(FormRawDataConstants.FORM_FIELD_CORRECTION)));
		}
		if(jsonObject.has(FormRawDataConstants.FILLED_RATE)){
			json.put(FormRawDataConstants.FILLED_RATE,Integer.parseInt(jsonObject.getString(FormRawDataConstants.FILLED_RATE)));
		}
		if(jsonObject.has(FormRawDataConstants.FORM_FIELD_BLANKRATE)){
			json.put(FormRawDataConstants.FORM_FIELD_BLANKRATE,Integer.parseInt(jsonObject.getString(FormRawDataConstants.FORM_FIELD_BLANKRATE)));
		}
//		if(jsonObject.has(FormRawDataConstants.FORM_FIELD_DROPOFF)){
//			json.put(FormRawDataConstants.FORM_FIELD_DROPOFF,Integer.parseInt(jsonObject.getString(FormRawDataConstants.FORM_FIELD_DROPOFF)));
//		}
		if(jsonObject.has(FormRawDataConstants.FORM_FIELD_COMPLETION_TIME)){
			json.put(FormRawDataConstants.FORM_FIELD_COMPLETION_TIME,Long.parseLong(jsonObject.getString(FormRawDataConstants.FORM_FIELD_COMPLETION_TIME)));
		}
		if(jsonObject.has(FormRawDataConstants.FORM_FIELD_HESITATION_TIME)){
			json.put(FormRawDataConstants.FORM_FIELD_HESITATION_TIME,Long.parseLong(jsonObject.getString(FormRawDataConstants.FORM_FIELD_HESITATION_TIME)));
		}
		
		}catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		return json;
		
	}

	public static Long getFormFieldIdFromArrayList(ArrayList<FormFieldDetails> arrayList,String formFieldKey) {
		
		Long formFieldId=0L;
		for(int i=0;i<arrayList.size();i++){
			FormFieldDetails f=arrayList.get(i);
			if(f.getFormfieldkey().equals(formFieldKey)){
				formFieldId=f.getFormfieldid();
				break;
			}
		}
		return formFieldId;
	}

	public static JSONObject  buildFormFieldDetailsForElasticSearch(JSONObject json) throws JSONException{
		
		FormFieldRawDataType[] formFieldRawDataTypes=FormFieldRawDataType.values();
		JSONObject resultJson = new JSONObject();
		for(FormFieldRawDataType formfieldrawDataType:formFieldRawDataTypes){
			String fieldName = formfieldrawDataType.getFieldName();
			if(json.has(fieldName)){
				resultJson.put(fieldName, json.get(fieldName));
			}
		}

		return resultJson;
	}
	
	public static JSONObject buildFormAnalyticsDetailsForElasticSearch(HashMap<String,String> hp) throws JSONException{
		
		JSONObject json=getJsonFromHashMap(hp);
		FormRawDataType[] formrawDataTypes = FormRawDataType.values();
		JSONObject resultJson = new JSONObject();
		
		for(FormRawDataType formrawDataType:formrawDataTypes){
			String fieldName = formrawDataType.getFieldName();
			if(json.has(fieldName)){
				resultJson.put(fieldName, json.get(fieldName));
			}
		}
		return resultJson;
	}

	public static JSONObject getJsonFromHashMap(HashMap<String,String> hp) {
		
		JSONObject json=new JSONObject();
		try{
		if(hp.containsKey(FormRawDataConstants.EXPERIMENT_ID)){
			json.put(ElasticSearchConstants.EXPERIMENTID,Long.parseLong(hp.get(FormRawDataConstants.EXPERIMENT_ID)));
		}
		if(hp.containsKey(FormReportConstants.LASTACTIVE)){
			json.put(FormReportConstants.LASTACTIVE,hp.get(FormReportConstants.LASTACTIVE));
		}
		if(hp.containsKey(FormRawDataConstants.FORM_STARTER)){
			json.put(FormRawDataConstants.FORM_STARTER,Integer.parseInt(hp.get(FormRawDataConstants.FORM_STARTER)));
		}
		if(hp.containsKey(FormRawDataConstants.FORM_CONVERSION)){
			json.put(FormRawDataConstants.FORM_CONVERSION,Integer.parseInt(hp.get(FormRawDataConstants.FORM_CONVERSION)));
		}
		if(hp.containsKey(FormRawDataConstants.FORM_SUBMISSION)){
			json.put(FormRawDataConstants.FORM_SUBMISSION,Integer.parseInt(hp.get(FormRawDataConstants.FORM_SUBMISSION)));
		}
//		if(hp.containsKey(FormRawDataConstants.FORM_LIVE)){
//			json.put(FormRawDataConstants.FORM_LIVE,Integer.parseInt(hp.get(FormRawDataConstants.FORM_LIVE)));
//		}
		if(hp.containsKey(FormRawDataConstants.FORM_SPENT_TIME)){
			json.put(FormRawDataConstants.FORM_SPENT_TIME,Long.parseLong(hp.get(FormRawDataConstants.FORM_SPENT_TIME)));
		}
		
		}catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		return json;
	}
	
	public static Boolean isFormLoaded(Long experimentId){
		
		Boolean cond = null;
		try{
			Criteria c=new Criteria(new Column(FORM_DETAILS.TABLE,FORM_DETAILS.EXPERIMENT_ID),experimentId,QueryConstants.EQUAL);
			DataObject dobj = getRow(FORM_DETAILS.TABLE, c);
			ArrayList<Form> form = Form.getFormFromDobj(dobj);
			cond = form.get(0).getFormloaded();
		 
		} catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		return cond; 
	}
	
	public static ArrayList<FormFieldDetails> getFormFieldDetailsFromFieldAlias(Long experimentId, String fieldName){
		
		ArrayList<FormFieldDetails> fields = null;
		try{
			Criteria c1 = new Criteria(new Column(FORM_FIELD_DETAILS.TABLE,FORM_FIELD_DETAILS.FIELD_ALIAS),fieldName,QueryConstants.EQUAL);
			Criteria c2 = new Criteria(new Column(FORM_FIELD_DETAILS.TABLE,FORM_FIELD_DETAILS.EXPERIMENT_ID),experimentId,QueryConstants.EQUAL);
			Criteria c3 = c1.and(c2);
			DataObject dobj3 = getRow(FORM_FIELD_DETAILS.TABLE,c3);
			fields = Form.getFormFieldFromDobj(dobj3);
			
		}catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		return fields;
	}
	
	public static Row insertRowInFormFieldDetails(Long experimentId, String formFieldName, String formFieldType,String formFieldId,String fieldName){
		
		Row row = null;
		try{
		
			HashMap<String,String> hs1 = new HashMap<String,String>();
			String key = generateUniqueId(FORM_FIELD_DETAILS.TABLE, FORM_FIELD_DETAILS.FORM_FIELD_KEY);
			hs1.put(FormConstants.EXPERIMENT_ID,experimentId.toString());
			hs1.put(FormConstants.FORM_FIELD_KEY,key);
			hs1.put(FormConstants.FIELD_ID, formFieldId);
			hs1.put(FormConstants.FORM_FIELD_NAME,fieldName);
			hs1.put(FormConstants.FORM_FIELD_TYPE, formFieldType);
			hs1.put(FormConstants.FIELD_ALIAS, formFieldName);
			DataObject dobj = createRow(FormConstants.FORM_FIELD_DETAILS_TABLE, FORM_FIELD_DETAILS.TABLE, hs1);
			row = dobj.getRow(FORM_FIELD_DETAILS.TABLE);
			
		} catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		return row;
	}
	
	public static void insertFieldDetailsInFormFieldDetailsTable(JSONArray formfields, Long experimentId) {
		
		ArrayList<FormFieldDetails> fields = null;
		
		try{
			for(int i = 0; i < formfields.length(); i++) {
				
				if(formfields.getJSONObject(i).has(FormConstants.FORM_FIELD_NAME1)){
					String formFieldName = null, formFieldType = null, formFieldId = null, fieldName = null;
					if(formfields.getJSONObject(i).has(FormConstants.FORM_FIELD_NAME1)) {
						formFieldName =formfields.getJSONObject(i).getString(FormConstants.FORM_FIELD_NAME1);
					}
					if(formfields.getJSONObject(i).has(FormConstants.FIELD_TYPE)) {
						formFieldType = formfields.getJSONObject(i).getString(FormConstants.FIELD_TYPE);
					}
					if(formfields.getJSONObject(i).has(FormConstants.ID)) {
						formFieldId =  formfields.getJSONObject(i).getString(FormConstants.ID);
					}
					if(formfields.getJSONObject(i).has(FormConstants.NAME)) {
						fieldName = formfields.getJSONObject(i).getString(FormConstants.NAME);
					}
					fields = getFormFieldDetailsFromFieldAlias(experimentId,formFieldName);
					if(fields.size()<=0){
					  insertRowInFormFieldDetails(experimentId,formFieldName,formFieldType,formFieldId,fieldName);
					} else {
						Criteria c1 = new Criteria(new Column(FORM_FIELD_DETAILS.TABLE,FORM_FIELD_DETAILS.FIELD_ALIAS),formFieldName,QueryConstants.EQUAL);
						Criteria c2 = new Criteria(new Column(FORM_FIELD_DETAILS.TABLE,FORM_FIELD_DETAILS.EXPERIMENT_ID),experimentId,QueryConstants.EQUAL);
						Criteria c3 = c1.and(c2);
						DataObject dobj3 = getRow(FORM_FIELD_DETAILS.TABLE,c3);						
						if(dobj3.containsTable(FORM_FIELD_DETAILS.TABLE)) {
							Row oldRow = dobj3.getFirstRow(FORM_FIELD_DETAILS.TABLE);
							if(formFieldId != null) {
								oldRow.set(FORM_FIELD_DETAILS.FIELD_ID,formFieldId);
							}
							if(fieldName != null) {
								oldRow.set(FORM_FIELD_DETAILS.FORM_FIELD_NAME, fieldName);
							}
							if(formFieldType != null) {
								oldRow.set(FORM_FIELD_DETAILS.FORM_FIELD_TYPE, formFieldType);
							}
							dobj3.updateRow(oldRow);
							updateDataObject(dobj3);
						}
						continue;
					}
				}
			}
		} catch(Exception e) {
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
	}
	
	public static void checkBlankFieldsAndFilledFields(JSONObject rawdata) {
		
		LOGGER.log(Level.INFO,"!!! Entered checkBlankFieldsAndFilledFields Function");
		try{
			if(rawdata.has(FormRawDataConstants.FORM_FIELD_BLANKRATE) && rawdata.getInt(FormRawDataConstants.FORM_FIELD_BLANKRATE) == 1) {
				rawdata.put(FormRawDataConstants.FILLED_RATE, 0);
			}
				if(rawdata.has(FormRawDataConstants.FILLED_RATE) && rawdata.getInt(FormRawDataConstants.FILLED_RATE) == 1 ){
				rawdata.put(FormRawDataConstants.FORM_FIELD_BLANKRATE, 0);
			}
		} catch(Exception e) {
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
	}

}

