//$Id$
package com.zoho.abtest.forms;


public class FormReportConstants {
	
	public static final String API_MODULE = "formreports"; //No I18N
	public static final String DAY_WISE_REPORT = "day_wise_report"; //No I18N
	public static final String EXPERIMENT_ID="experiment_id";    //No I18N
	public static final String START_DATE="start_date";    //No I18N
	public static final String END_DATE="end_date";    //No I18N
	//form metrics
	public static final String FORM_UNIQUE_VISITOR_COUNT="form_unique_visitor_count"; //No I18N
    public static final String FORM_VISITOR_COUNT="form_visits_count"; //No I18N
    public static final String FORM_STARTER_COUNT="form_starter_count";   //No I18N
    public static final String FORM_ABANDON_COUNT="form_abandon_count";   //No I18N
    public static final String FORM_CONVERSION_COUNT="form_conversion_count"; //No I18N
    public static final String FORM_SUBMISSION_COUNT="form_submission_count"; //No I18N
    public static final String FORM_SPENT_TIME="form_spent_time"; //No I18N
    public static final String FORM_COMPLETE_TIME="form_complete_time"; //No I18N
    public static final String LASTACTIVE = "last_active"; //No I18N

    public static final String FORM_LIVE="form_live"; //No I18N
    public static final String TIME="time"; //No I18N
    public static final String FORM_STARTER_RATE="form_starter_rate"; //No I18N
    public static final String FORM_CONVERSION_RATE="form_conversion_rate"; //No I18N
    public static final String FORM_ABANDON_RATE="form_abandon_rate"; //No I18N
    //form field metrics
    public static final String FORM_FIELD_ID="form_field_id";   //No I18N
    public static final String FORM_FIELD_VISIT_COUNT="form_field_visit_count";   //No I18N
    public static final String FORM_FIELD_STARTER_COUNT="form_field_starter_count";   //No I18N
    public static final String FORM_FIELD_REFOCUS_COUNT="form_field_refocus_count";   //No I18N
    public static final String FORM_FIELD_CORRECTION_COUNT="form_field_correction_count";   //No I18N
    public static final String FORM_FIELD_COMPLETION_TIME="form_field_completion_time";   //No I18N
    public static final String FORM_FIELD_HESITATION_TIME="form_field_hesitation_time";   //No I18N
    public static final String FORM_FIELD_BLANK_COUNT="form_field_blankrate_count";   //No I18N
    public static final String FORM_FIELD_DROPOFF_COUNT="form_field_dropoff_count";   //No I18N
    public static final String HESITATION_PERCENTAGE =  "hesitation_percentage"; //No I18N
    public static final String FILLED_RATE="filled_rate";   //No I18N
    public static final String FILLED_PERCENTAGE =  "filled_percentage"; //No I18N
    public static final String BLANK_PERCENTAGE =  "blank_percentage"; //No I18N

 }
