//$Id$
package com.zoho.abtest.forms;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Iterator;

import javax.transaction.Transaction;
import javax.transaction.TransactionManager;

import org.json.JSONObject;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.iam.IAMUtil;
import com.adventnet.iam.ServiceOrg;
import com.adventnet.persistence.DataAccess;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.persistence.WritableDataObject;
import com.amazonaws.services.applicationdiscovery.model.ResourceNotFoundException;
import com.zoho.abtest.EVENTS;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.FORM_CUSTOM_EVENTS;
import com.zoho.abtest.FORM_DETAILS;
import com.zoho.abtest.FORM_FIELD_DETAILS;
import com.zoho.abtest.PROJECT;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.eventactivity.EventActivityConstants;
import com.zoho.abtest.eventactivity.EventActivityConstants.Module;
import com.zoho.abtest.eventactivity.EventActivityWrapper;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentType;
import com.zoho.abtest.forms.FormConstants.FormMatchType;
import com.zoho.abtest.listener.ZABNotifier;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.project.ProjectTreeEventConstants;
import com.zoho.abtest.project.ProjectTreeEventConstants.OperationType;
import com.zoho.abtest.project.ProjectTreeEventWrapper;
import com.zoho.abtest.utility.ZABUtil;


public class FormAnalyticsExperiment extends Experiment {
	
	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = Logger.getLogger(FormAnalyticsExperiment.class.getName());

	private String experimentUrl;
	
	private Long visitsCount;
	
	private Double startersCount;
	
	private Double conversionRate;
	
	

	public Double getConversionRate() {
		return conversionRate;
	}

	public void setConversionRate(Double conversionRate) {
		this.conversionRate = conversionRate;
	}

	public Long getVisitsCount() {
		return visitsCount;
	}

	public void setVisitsCount(Long visitsCount) {
		this.visitsCount = visitsCount;
	}

	public Double getStartersCount() {
		return startersCount;
	}

	public void setStartersCount(Double startersCount) {
		this.startersCount = startersCount;
	}

	private transient ArrayList<Form> form = new ArrayList<Form>();
	 
	public ArrayList<Form> getForm() {
		return form;
	}
	
	public void setForm(ArrayList<Form> form) {
		this.form = form;
	}
	
	public String getExperimentUrl() {
		return experimentUrl;
	}
	
	public void setExperimentUrl(String experimentUrl) {
		this.experimentUrl = experimentUrl;
	}
	 
	public FormAnalyticsExperiment(){
		
	}
	 
	public FormAnalyticsExperiment(Experiment experiment){
		
		setExperimentId(experiment.getExperimentId());
		setProjectId(experiment.getProjectId());
		setExperimentName(experiment.getExperimentName());
		setCreateBy(experiment.getCreateBy());
		setCreatedByName(experiment.getCreatedByName());
		setExperimentKey(experiment.getExperimentKey());
		setExperimentLinkname(experiment.getExperimentLinkname());
		setExperimentType(experiment.getExperimentType());
		setExperimentStatus(experiment.getExperimentStatus());
		setDuration(experiment.getDuration());
		setStartDate(experiment.getStartDate());
		setEndDate(experiment.getEndDate());
		setActualStartTime(experiment.getActualStartTime());
		setActualEndTime(experiment.getActualEndTime());
		setCreatedTime(experiment.getCreatedTime());
		setModifiedTime(experiment.getModifiedTime());
		setIsActive(experiment.getIsActive());
		setMakePublic(experiment.getMakePublic());
		setShareUrl(experiment.getShareUrl());
		setProjectLinkname(experiment.getProjectLinkname());
		setSmallThumbnailUrl(experiment.getSmallThumbnailUrl());
		setLargeThumbnailUrl(experiment.getLargeThumbnailUrl());
	}
	

	 public static FormAnalyticsExperiment getFormAnalyticsExperimentFromRow(Row formanalyticsRow, FormAnalyticsExperiment experiment) {
		  experiment.setExperimentUrl((String)formanalyticsRow.get(FORM_DETAILS.EXPERIMENT_URL));
		  experiment.setSuccess(Boolean.TRUE);
		  return experiment;
	}
	
	 public static FormAnalyticsExperiment getFormAnalyticsExperimentFromRow(Row expRow, Row formanalyticsRow) {
		 FormAnalyticsExperiment experiment = new FormAnalyticsExperiment();
		 getExperimentFromRow(expRow, experiment);
		 experiment.setExperimentUrl((String)formanalyticsRow.get(FORM_DETAILS.EXPERIMENT_URL));
		 experiment.setSuccess(Boolean.TRUE);
		 return experiment;
	 }
		 
	public static  FormAnalyticsExperiment getFormAnalyticsExperimentDetails(String expLinkname){
		FormAnalyticsExperiment exp = null;
		try {
			
			Criteria c = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_LINK_NAME), expLinkname, QueryConstants.EQUAL);
			Join join = new Join(EXPERIMENT.TABLE, FORM_DETAILS.TABLE, new String[]{EXPERIMENT.EXPERIMENT_ID}, new String[]{FORM_DETAILS.EXPERIMENT_ID}, Join.INNER_JOIN);
			DataObject dataObj = ZABModel.getRow(EXPERIMENT.TABLE, c, join);
			Row formanalyticsRow = dataObj.getFirstRow(FORM_DETAILS.TABLE);
			Row expRow = dataObj.getFirstRow(EXPERIMENT.TABLE);
			exp = getFormAnalyticsExperimentFromRow(expRow, formanalyticsRow);
		}
		catch(Exception ex) {
			
			exp = new FormAnalyticsExperiment();
			exp.setSuccess(Boolean.FALSE);
		}
		return exp;
	 }
	
	
	
	public static Row getFormAnalyticsExperimentRow(Long expId) throws Exception{
		 
		 Criteria c = new Criteria(new Column(FORM_DETAILS.TABLE, FORM_DETAILS.EXPERIMENT_ID), expId, QueryConstants.EQUAL);
		 DataObject dataObj = ZABModel.getRow(FORM_DETAILS.TABLE, c);
		 Row formanalyticsRow = dataObj.getFirstRow(FORM_DETAILS.TABLE);
		 return formanalyticsRow;
	 }

	 public static FormAnalyticsExperiment updateFormAnalyticsExperiment(HashMap<String, String> hs) {
		  
		  TransactionManager mgr = null;
		  Boolean alreadyInTransaction = false;
		  FormAnalyticsExperiment formAnalyticsExperiment = null;
		  Long experimentId = null;
		  try {
			   
				String linkname = hs.get(ZABConstants.LINKNAME);
				Experiment experiment = Experiment.getExperimentByLinkname(linkname);
				if(experiment==null) {
					throw new ResourceNotFoundException(ZABAction.getMessage(ExperimentConstants.API_RESOURCE_INITIAL));
				}
				//Logging event activity purpose
//				FormAnalyticsExperiment oldFormExp = null;
//				HashMap<String,String> oldValues = null;
				experimentId = experiment.getExperimentId();
				
				experiment = Experiment.updateExperiment(hs);
				
				 mgr = DataAccess.getTransactionManager();
				 Transaction trans = mgr.getTransaction();
				 alreadyInTransaction = (trans!=null);
				 if(!alreadyInTransaction) {
					 mgr.begin();
				 }
				  	
				if(hs.containsKey(FormConstants.API_MODULE)) {
					JSONObject json=new JSONObject(hs.get(FormConstants.API_MODULE));
					HashMap<String, String> map = ZABAction.parseJSON(json);
					map.put(FormConstants.EXPERIMENT_ID,experiment.getExperimentId().toString());
					if(hs.containsKey(ExperimentConstants.EXPERIMENT_URL)){
						map.put(ExperimentConstants.EXPERIMENT_URL, hs.get(ExperimentConstants.EXPERIMENT_URL));
					}
					if(hs.containsKey(ExperimentConstants.INCLUDE_URLS)) {
						map.put(ExperimentConstants.INCLUDE_URLS, hs.get(ExperimentConstants.INCLUDE_URLS));
					}
					if(hs.containsKey(ExperimentConstants.EXCLUDE_URLS)) {
						map.put(ExperimentConstants.EXCLUDE_URLS, hs.get(ExperimentConstants.EXCLUDE_URLS));
					}
//					oldFormExp = FormAnalyticsExperiment.getFormAnalyticsExperiment(linkname);
//					oldValues = generateHashMapFromFormAnalyticsExperimentObj(oldFormExp,hs);
					Form.updateFormDetails(map);
				}
				
				
				if(!experiment.getSuccess()){
					formAnalyticsExperiment = new FormAnalyticsExperiment();
					formAnalyticsExperiment.setSuccess(Boolean.FALSE);
					formAnalyticsExperiment.setResponseString(experiment.getResponseString());
					return formAnalyticsExperiment;
				}
				
				formAnalyticsExperiment = new FormAnalyticsExperiment(experiment);
				formAnalyticsExperiment.setSuccess(Boolean.TRUE);
				formAnalyticsExperiment.setResponseString(experiment.getResponseString());
				Row latestFormAnalyticsRow =getFormAnalyticsExperimentRow(experimentId);
				getFormAnalyticsExperimentFromRow(latestFormAnalyticsRow, formAnalyticsExperiment);

				 if(!alreadyInTransaction) {
					 mgr.commit();
				 }
		
		   
		   //Notify event
				
				ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
				wrapper.setChangeSets(hs);
				wrapper.setModel(formAnalyticsExperiment);
				wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
				wrapper.setType(OperationType.UPDATE);
				Long zsoid;
				ServiceOrg currentServiceOrg = IAMUtil.getCurrentServiceOrg();
				if(currentServiceOrg != null)
				{
					zsoid = currentServiceOrg.getZSOID();
					wrapper.setZsoid(zsoid.toString());
				}
				else if(ZABUtil.getDBSpace() != null)
				{
					wrapper.setZsoid(ZABUtil.getDBSpace());
				}
				ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);
		 
		   
//		 Event Activity Log
//		 HashMap<String, String> updatedValues = new HashMap<String, String>();
//		 updatedValues.putAll(hs);
//		 updatedValues.put(EventActivityConstants.EXPERIMENT_ID, experimentId.toString());
//		 if(ZABUtil.getCurrentUser() != null)
//		 {
//		    updatedValues.put(EventActivityConstants.USER_ID, ZABUtil.getCurrentUser().getUserId().toString());
//		 }
//		 updatedValues.put(EventActivityConstants.TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
//		 EventActivityWrapper activityWrapper = new EventActivityWrapper();
//		 activityWrapper.setModule(Module.EXPERIMENT);
//		 activityWrapper.setOperationType(com.zoho.abtest.eventactivity.EventActivityConstants.OperationType.UPDATE);
//		 activityWrapper.setDbSpace(ZABUtil.getCurrentUserDbSpace());
//		 activityWrapper.setUpdatedValues(updatedValues);
//		 activityWrapper.setOldValues(oldValues);
//
//		 ZABNotifier.notifyListeners(EventActivityConstants.EVENT_MODULE_NAME, activityWrapper);
		  }catch (Exception e) {
		   
			  formAnalyticsExperiment = new FormAnalyticsExperiment();
			  formAnalyticsExperiment.setSuccess(Boolean.FALSE);
			  formAnalyticsExperiment.setResponseString(e.getMessage());
			  if(e instanceof ResourceNotFoundException) {
				  formAnalyticsExperiment.setResponseCode(((ResourceNotFoundException) e).getErrorCode());
			  }
			  LOGGER.log(Level.SEVERE,"Exception Occurred",e);
			  try {
				  if(mgr!=null && !alreadyInTransaction) {
					  mgr.rollback();
				  }
			  }catch (Exception e1) {
		    	 LOGGER.log(Level.SEVERE,"Exception Occurred",e1);
			  }
		   }
		  return formAnalyticsExperiment;
		 }
	 
	 public static FormAnalyticsExperiment getFormAnalyticsExperimentFromRow(Row fRow) {
			
		 	FormAnalyticsExperiment experiment = new FormAnalyticsExperiment();
			experiment.setExperimentId((Long)fRow.get(FORM_DETAILS.EXPERIMENT_ID));
			experiment.setExperimentUrl((String)fRow.get(FORM_DETAILS.EXPERIMENT_URL));
			experiment.setSuccess(Boolean.TRUE);
			return experiment;
		}
	
	 public static FormAnalyticsExperiment getFormAnalyticsExperiment(String linkname) {
		 
		 FormAnalyticsExperiment exp = null;
			try
			{
				Criteria c = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_LINK_NAME), linkname, QueryConstants.EQUAL);
				Join join = new Join(EXPERIMENT.TABLE, FORM_DETAILS.TABLE, new String[]{EXPERIMENT.EXPERIMENT_ID}, new String[]{FORM_DETAILS.EXPERIMENT_ID}, Join.INNER_JOIN);
				DataObject dataObj = ZABModel.getRow(EXPERIMENT.TABLE, c, join);
				Row expRow = dataObj.getFirstRow(EXPERIMENT.TABLE);	
				if(expRow!=null){
					
					Row fRow = dataObj.getFirstRow(FORM_DETAILS.TABLE);
					exp = getFormAnalyticsExperimentFromRow(fRow);
				}
			}
			catch(Exception ex)
			{
				exp = new FormAnalyticsExperiment();
				exp.setSuccess(Boolean.FALSE);
			}
			return exp;
	}

	public static HashMap<String,String> generateHashMapFromFormAnalyticsExperimentObj(FormAnalyticsExperiment exp, HashMap<String,String> hs) {
			HashMap<String,String> oldValues = new HashMap<String,String>();
			try
			{

				for(String attributeName:EventActivityConstants.FORM_ANALYTICS_EXPERIMENT_ATTR_TO_TRACE)
				{
					if(hs.containsKey(attributeName))
					{
						switch(attributeName)
						{
						case ExperimentConstants.EXPERIMENT_URL:
							oldValues.put(ExperimentConstants.EXPERIMENT_URL, exp.getExperimentUrl());
							break;
						}
					}
				}
				oldValues.put(ExperimentConstants.EVENT_EXPERIMENT_TYPE, ExperimentType.FORMANALYTICS.getTypeNumber().toString());
			}
			catch(Exception ex)
			{
				LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			}
			return oldValues;
		}
		
	 
	 
	 public static FormAnalyticsExperiment getFormAnalyticsExperimentByLinkName(String expLinkname)
	 {
	  FormAnalyticsExperiment exp = null;
	  try
	  {
	   Criteria c = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_LINK_NAME), expLinkname, QueryConstants.EQUAL);
	   Join join = new Join(EXPERIMENT.TABLE, FORM_DETAILS.TABLE, new String[]{EXPERIMENT.EXPERIMENT_ID}, new String[]{FORM_DETAILS.EXPERIMENT_ID}, Join.INNER_JOIN);
	   Join join1=new Join(EXPERIMENT.TABLE,PROJECT.TABLE,new String[]{EXPERIMENT.PROJECT_ID},new String[]{PROJECT.PROJECT_ID},Join.INNER_JOIN);
	   Join join2 = new Join(EXPERIMENT.TABLE,FORM_FIELD_DETAILS.TABLE, new String[]{EXPERIMENT.EXPERIMENT_ID}, new String[]{FORM_FIELD_DETAILS.EXPERIMENT_ID}, Join.LEFT_JOIN);
	   Join join3 = new Join(EXPERIMENT.TABLE,FORM_CUSTOM_EVENTS.TABLE, new String[]{EXPERIMENT.EXPERIMENT_ID}, new String[]{FORM_CUSTOM_EVENTS.EXPERIMENT_ID}, Join.LEFT_JOIN);
	   DataObject dataObj = ZABModel.getRow(EXPERIMENT.TABLE, c, new Join[]{join,join1,join2,join3});
	   if(dataObj.containsTable(EXPERIMENT.TABLE)){
		   Row expRow = dataObj.getFirstRow(EXPERIMENT.TABLE); 
		   if(expRow!=null){
			   Experiment experiment = getExperimentFromRow(expRow);
				Row faRow = dataObj.getFirstRow(FORM_DETAILS.TABLE);
				exp = getFormAnalyticsExperimentFromRow(faRow,dataObj,experiment);
				exp.setProjectLinkname(Project.getProjectLinkname(dataObj, experiment.getProjectId()));
				exp.setExperimentUrl((String)faRow.get(FORM_DETAILS.EXPERIMENT_URL));
		   }
	   }
	  }
	  catch(Exception ex)
	  {
	   exp = new FormAnalyticsExperiment();
	   exp.setSuccess(Boolean.FALSE);
	  }
	  return exp;
	 }
	 
	 public static FormAnalyticsExperiment getFormAnalyticsExperimentFromRow(Row formanalyticsrow,DataObject dobj,Experiment exp) {
		  
		 FormAnalyticsExperiment experiment = new FormAnalyticsExperiment(exp);
		 ArrayList<Form> form=new ArrayList<Form>();
		 try{
		 Form f=Form.getFormFromRow(formanalyticsrow);
		 Integer MatchType=(Integer)formanalyticsrow.get(FORM_DETAILS.MATCH_TYPE);
		 FormMatchType matchType = FormMatchType.getMatchTypeById(MatchType);
		 if(matchType.equals(FormMatchType.CUSTOM_EVENT)){
			 setCustomEventLinkName(dobj,f);
		 }
		 f.setFormFieldDetails(Form.getFormFieldFromDobj(dobj));
		 form.add(f);
		 experiment.setForm(form);
		 experiment.setExperimentId((Long)formanalyticsrow.get(FORM_DETAILS.EXPERIMENT_ID));
		  experiment.setExperimentUrl((String)formanalyticsrow.get(FORM_DETAILS.EXPERIMENT_URL));
		  experiment.setSuccess(Boolean.TRUE);
		 }catch(Exception e){
			 LOGGER.log(Level.SEVERE,e.getMessage(),e);
		 }
		  return experiment;
	}
	 
	 public static void setCustomEventLinkName(DataObject dobj, Form f) throws DataAccessException {
		 
		 try{
		 if(dobj.containsTable(FORM_CUSTOM_EVENTS.TABLE)){
				Row row=dobj.getFirstRow(FORM_CUSTOM_EVENTS.TABLE);
				Long eventId=(Long)row.get(FORM_CUSTOM_EVENTS.EVENT_ID);
				Criteria c = new Criteria(new Column(EVENTS.TABLE, EVENTS.EVENT_ID),eventId,QueryConstants.EQUAL);
				Row r = ZABModel.getFirstRow(EVENTS.TABLE, c);
				String eventlinkname=(String)r.get(EVENTS.EVENT_LINKNAME);
				String eventname = (String)r.get(EVENTS.EVENT_NAME);
				f.setCustomevent(eventlinkname);
				f.setCustomeventname(eventname);
			}
		 }catch(Exception e){
			 LOGGER.log(Level.SEVERE,e.getMessage(),e);
		 }
	 }
		 
	 public static Experiment createFormAnalyticsExperiment(HashMap<String, String> hs) {
		
		
		FormAnalyticsExperiment formAnalyticsexp=null;
		TransactionManager mgr = DataAccess.getTransactionManager();
		try {
				mgr.begin();
				
				//Create Experiment
				Experiment experiment = Experiment.createExperiment(hs);
				Long experimentId = experiment.getExperimentId();
				if(experiment.getSuccess().equals(Boolean.TRUE) && experimentId  != null) {
					
					formAnalyticsexp = new FormAnalyticsExperiment(experiment);
					
					if(hs.containsKey(FormConstants.API_MODULE)){
						
						JSONObject json=new JSONObject(hs.get(FormConstants.API_MODULE));
						HashMap<String, String> map = ZABAction.parseJSON(json);
						map.put(FormConstants.EXPERIMENT_ID,experimentId.toString());
						map.put(FormConstants.EXPERIMENT_URL,hs.get(ExperimentConstants.EXPERIMENT_URL));
						map.put(ExperimentConstants.INCLUDE_URLS, hs.get(ExperimentConstants.INCLUDE_URLS));
						map.put(ExperimentConstants.EXCLUDE_URLS, hs.get(ExperimentConstants.EXCLUDE_URLS));
						ArrayList<Form> form=Form.createFormDetails(map);
						formAnalyticsexp.setForm(form);
						formAnalyticsexp.setExperimentUrl(hs.get(ExperimentConstants.EXPERIMENT_URL));
						formAnalyticsexp.setSuccess(Boolean.TRUE);
					}else{
						
						mgr.rollback();
						LOGGER.log(Level.SEVERE,"Exception Occurred while creating experiment. Hence rolledback changes.");
						formAnalyticsexp = new FormAnalyticsExperiment();
						formAnalyticsexp.setSuccess(Boolean.FALSE);
						formAnalyticsexp.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
					}

					mgr.commit();
				
					//Trigger event 
					
					ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
					wrapper.setModel(formAnalyticsexp);
					wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
					wrapper.setChangeSets(hs);
					wrapper.setType(OperationType.CREATE);
					Long zsoid;
					ServiceOrg currentServiceOrg = IAMUtil.getCurrentServiceOrg();
					if(currentServiceOrg != null)
					{
						zsoid = currentServiceOrg.getZSOID();
						wrapper.setZsoid(zsoid.toString());
					}
					ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);
					
				
					//Event Activity Log				
					HashMap<String, String> updatedValues = new HashMap<String, String>();
					updatedValues.put(EventActivityConstants.EXPERIMENT_ID, experimentId.toString());
					updatedValues.put(EventActivityConstants.USER_ID, ZABUtil.getCurrentUser().getUserId().toString());
					updatedValues.put(EventActivityConstants.TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
					EventActivityWrapper activityWrapper = new EventActivityWrapper();
					activityWrapper.setModule(Module.EXPERIMENT);
					activityWrapper.setOperationType(com.zoho.abtest.eventactivity.EventActivityConstants.OperationType.CREATE);
					activityWrapper.setDbSpace(ZABUtil.getCurrentUserDbSpace());
					activityWrapper.setUpdatedValues(updatedValues);
					ZABNotifier.notifyListeners(EventActivityConstants.EVENT_MODULE_NAME, activityWrapper);
				}
				else{
				
					mgr.rollback();
					LOGGER.log(Level.SEVERE,"Exception Occurred while creating experiment. Hence rolledback changes.");
					formAnalyticsexp = new FormAnalyticsExperiment();
					formAnalyticsexp.setSuccess(Boolean.FALSE);
					formAnalyticsexp.setResponseString(experiment!=null? experiment.getResponseString():ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
				}
		} catch (Exception e) {
			
				try {
					mgr.rollback();
				} catch (Exception e1) {
				LOGGER.log(Level.SEVERE,"Exception Occurred",e1);
				}
			formAnalyticsexp = new FormAnalyticsExperiment();
			formAnalyticsexp.setSuccess(Boolean.FALSE);
			formAnalyticsexp.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return formAnalyticsexp;

	}
	
	public static FormAnalyticsExperiment duplicateFormAnalyticsExperiment(String linkname){
		
		FormAnalyticsExperiment faExperiment = null;
		TransactionManager mgr = DataAccess.getTransactionManager();
		try {		
			Criteria c = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_LINK_NAME), linkname, QueryConstants.EQUAL);
			DataObject dobj = getPersonality(ExperimentConstants.EXPERIMENT_DETAIL_PERSONALITY, c);
			if(dobj.containsTable(EXPERIMENT.TABLE)) {
				
				mgr.begin();
				
				Experiment experiment = Experiment.duplicateExperiment(dobj);
				
				if(experiment != null && experiment.getExperimentId() != null)
				{
					Row faRow = dobj.getRow(FORM_DETAILS.TABLE);
 
					faExperiment = new FormAnalyticsExperiment(experiment);
					
					//Add Form Analytics Experiment row
					addDuplicateFormDetails(dobj,faRow, faExperiment);
					getFormAnalyticsExperimentFromRow(faRow,faExperiment);
					
				}
				
				//Done have to trigger event to update javascript here as the status of this experiment will be in draft

				mgr.commit();
				
			} else {
				
				faExperiment = new FormAnalyticsExperiment();
				faExperiment.setSuccess(Boolean.FALSE);
				faExperiment.setResponseString(ZABAction.getMessage(ZABConstants.ErrorMessages.RESOURCE_NOT_FOUND.getErrorString(),new String[]{ExperimentConstants.API_MODULE}));
				return faExperiment;
			}
			
			ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
			ServiceOrg currentServiceOrg = IAMUtil.getCurrentServiceOrg();
			if(currentServiceOrg != null)
			{
				wrapper.setZsoid(currentServiceOrg.getZSOID()+"");
			}
			wrapper.setModel(faExperiment);
			wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
			wrapper.setType(OperationType.CREATE);
			ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);
			
		} catch (Exception e) {
			
			try
			{
				mgr.rollback();
			}
			catch(Exception e1)
			{
				LOGGER.log(Level.SEVERE,"Exception Occurred",e1);
			}
			
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
			faExperiment = new FormAnalyticsExperiment();
			faExperiment.setSuccess(Boolean.FALSE);
			faExperiment.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
		}

		return faExperiment;
	}
	
	public static FormAnalyticsExperiment addDuplicateFormDetails(DataObject dobj, Row row, FormAnalyticsExperiment experiment) throws DataAccessException {
		
		try{
			DataObject wdobj = new WritableDataObject();
			Row newERow = new Row(FORM_DETAILS.TABLE);
			newERow.set(FORM_DETAILS.EXPERIMENT_ID, experiment.getExperimentId());
			newERow.set(FORM_DETAILS.EXPERIMENT_URL, (String)row.get(FORM_DETAILS.EXPERIMENT_URL));
			newERow.set(FORM_DETAILS.FORM_ELEMENT_ID, (String)row.get(FORM_DETAILS.FORM_ELEMENT_ID));
			newERow.set(FORM_DETAILS.FORM_ELEMENT_NAME,  (String)row.get(FORM_DETAILS.FORM_ELEMENT_NAME));
			newERow.set(FORM_DETAILS.FORM_ELEMENT_SELECTOR, (String)row.get(FORM_DETAILS.FORM_ELEMENT_SELECTOR));
			newERow.set(FORM_DETAILS.FORM_NO_OF_FIELDS, (Integer)row.get(FORM_DETAILS.FORM_NO_OF_FIELDS));
			newERow.set(FORM_DETAILS.MATCH_TYPE, (Integer)row.get(FORM_DETAILS.MATCH_TYPE));
			newERow.set(FORM_DETAILS.INCLUDE_URLS, (String)row.get(FORM_DETAILS.INCLUDE_URLS));
			newERow.set(FORM_DETAILS.EXCLUDE_URLS, (String)row.get(FORM_DETAILS.EXCLUDE_URLS));
			newERow.set(FORM_DETAILS.IS_AUTO_LOADED, (Boolean)row.get(FORM_DETAILS.IS_AUTO_LOADED));
			newERow.set(FORM_DETAILS.FORM_CONVERSION_URL, (String)row.get(FORM_DETAILS.FORM_CONVERSION_URL));
			wdobj.addRow(newERow);
			updateDataObject(wdobj);
			if(row.get(FORM_DETAILS.MATCH_TYPE)!=null) {			
				Integer matchType = (Integer)row.get(FORM_DETAILS.MATCH_TYPE);
				if(matchType.equals(FormMatchType.CUSTOM_EVENT.getMatchTypeId())) {			
					Long oldExperimentId = (Long)row.get(FORM_DETAILS.EXPERIMENT_ID);
					Criteria c = new Criteria(new Column(FORM_CUSTOM_EVENTS.TABLE, FORM_CUSTOM_EVENTS.EXPERIMENT_ID), oldExperimentId, QueryConstants.EQUAL);
					Row customRow = dobj.getRow(FORM_CUSTOM_EVENTS.TABLE, c);
					Long eventId = (Long) customRow.get(FORM_CUSTOM_EVENTS.EVENT_ID);
					DataObject customDataObject = new WritableDataObject();
					Row newCustomRow = new Row(FORM_CUSTOM_EVENTS.TABLE);
					newCustomRow.set(FORM_CUSTOM_EVENTS.EVENT_ID, eventId);
					newCustomRow.set(FORM_CUSTOM_EVENTS.EXPERIMENT_ID, experiment.getExperimentId());
					customDataObject.addRow(newCustomRow);
					updateDataObject(customDataObject);
				}
			}
			duplicateFormFieldDetails(dobj, experiment);
		} catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		return experiment;
	}
	
	public static ArrayList<HashMap<String, String>> duplicateFormFieldDetails(DataObject dobj, FormAnalyticsExperiment experiment) {
		
		ArrayList<HashMap<String, String>> arrayList = new ArrayList<HashMap<String, String>>();
		try{
			Iterator it = dobj.getRows(FORM_FIELD_DETAILS.TABLE);
			while(it.hasNext()){
				Row row = (Row)it.next();
				DataObject wdobj = new WritableDataObject();
				Row newERow = new Row(FORM_FIELD_DETAILS.TABLE);
				newERow.set(FORM_FIELD_DETAILS.EXPERIMENT_ID, experiment.getExperimentId());
				newERow.set(FORM_FIELD_DETAILS.FORM_FIELD_NAME, (String)row.get(FORM_FIELD_DETAILS.FORM_FIELD_NAME));
				newERow.set(FORM_FIELD_DETAILS.FORM_FIELD_TYPE, (String)row.get(FORM_FIELD_DETAILS.FORM_FIELD_TYPE));
				newERow.set(FORM_FIELD_DETAILS.FIELD_ID, (String)row.get(FORM_FIELD_DETAILS.FIELD_ID));
				newERow.set(FORM_FIELD_DETAILS.FIELD_ALIAS, (String)row.get(FORM_FIELD_DETAILS.FIELD_ALIAS));
				newERow.set(FORM_FIELD_DETAILS.IS_ENABLED, (Boolean)row.get(FORM_FIELD_DETAILS.IS_ENABLED));
				newERow.set(FORM_FIELD_DETAILS.FORM_FIELD_KEY, generateUniqueId(FORM_FIELD_DETAILS.TABLE, FORM_FIELD_DETAILS.FORM_FIELD_KEY));
				wdobj.addRow(newERow);
				updateDataObject(wdobj);
			}
		}catch(Exception e){
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}
		return arrayList;
	}
	
	
	
	public static FormAnalyticsExperiment getExperimentMetaData(String linkName) throws Exception{
		
		FormAnalyticsExperiment exp = null;

		Criteria c = new Criteria(new Column(EXPERIMENT.TABLE,EXPERIMENT.EXPERIMENT_LINK_NAME),linkName,QueryConstants.EQUAL);
		Join join1=new Join(EXPERIMENT.TABLE,PROJECT.TABLE,new String[]{EXPERIMENT.PROJECT_ID},new String[]{PROJECT.PROJECT_ID},Join.INNER_JOIN);
		Join join2 = new Join(EXPERIMENT.TABLE, FORM_DETAILS.TABLE, new String[]{EXPERIMENT.EXPERIMENT_ID}, new String[]{FORM_DETAILS.EXPERIMENT_ID}, Join.LEFT_JOIN);
		
		DataObject dataObj = ZABModel.getRow(EXPERIMENT.TABLE, c, new Join[]{join1,join2});
		Row expRow = dataObj.getFirstRow(EXPERIMENT.TABLE); 
		if(expRow!=null){
			exp=new FormAnalyticsExperiment();
			Experiment experiment = getExperimentFromRow(expRow);
			Row faRow = dataObj.getFirstRow(FORM_DETAILS.TABLE);
		    exp = getFormAnalyticsExperimentFromRow(faRow,dataObj,experiment);
			exp.setProjectLinkname(Project.getProjectLinkname(dataObj, exp.getProjectId()));
			ElasticFormReport.setFormAnalyticsExperimentDetailsFromES(exp);

		}
		return exp;
	}



}

