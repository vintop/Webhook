//$Id$
package com.zoho.abtest.forms;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;

import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABRequest;
import com.zoho.abtest.forms.FormConstants;

public class FormRequest extends ZABRequest{

	@Override
	public void updateFromRequest(HashMap<String, String> map,HttpServletRequest request) {
		
	}

	@Override
	public void specificValidation(HashMap<String, String> map,HttpServletRequest request) throws IOException, JSONException {

	}

}