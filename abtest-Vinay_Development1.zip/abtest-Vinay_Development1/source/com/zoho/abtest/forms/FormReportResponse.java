//$Id$
package com.zoho.abtest.forms;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;


public class FormReportResponse {
	
	
	public static String jsonResponse(HttpServletRequest request,ArrayList<FormReport> lst)
	{
		
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(lst);			
			JSONObject json = ZABResponse.updateMetaInfo(request, "formreports", array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){}
		return returnBuffer.toString();	
	}
	
	
	
	private static JSONObject getJSONObject(FormReport ld) throws JSONException {
		JSONObject jsonObj = new JSONObject();
	//	jsonObj.put(FormReportConstants.EXPERIMENT_ID, ld.getExperimentid());
	//	jsonObj.put(FormReportConstants.FORM_COMPLETE_TIME, ld.getFormcompletetime());
		jsonObj.put(FormReportConstants.FORM_SUBMISSION_COUNT, ld.getFormsubmissioncount());
		jsonObj.put(FormReportConstants.FORM_CONVERSION_COUNT, ld.getFormconversioncount());
		jsonObj.put(FormReportConstants.FORM_ABANDON_COUNT, ld.getFormabandoncount());
		jsonObj.put(FormReportConstants.FORM_SPENT_TIME, ld.getFormspenttime());
		jsonObj.put(FormReportConstants.FORM_COMPLETE_TIME, ld.getFormcompletetime());
		jsonObj.put(FormReportConstants.FORM_UNIQUE_VISITOR_COUNT,ld.getFormuniquevisitorcount());
		jsonObj.put(FormReportConstants.FORM_VISITOR_COUNT, ld.getFormvisitorcount());
		jsonObj.put(FormReportConstants.FORM_STARTER_COUNT, ld.getFormstartercount());
		jsonObj.put(FormReportConstants.FORM_CONVERSION_RATE,ld.getFormconversionrate());
		jsonObj.put(FormReportConstants.FORM_ABANDON_RATE, ld.getFormabandonrate());
		jsonObj.put(FormReportConstants.FORM_STARTER_RATE, ld.getFormstarterrate());
	//	jsonObj.put(FormReportConstants.FORM_LIVE,ld.getFormlive());
		jsonObj.put(FormConstants.EXPERIMENT_ID, ld.getExperimentid());
		
		jsonObj.put(FormConstants.FORM_FIELDS,ld.getJsonarray());
		//jsonObj.put(FormReportConstants.TIME, ld.getTime());
		jsonObj.put(ZABConstants.RESPONSE_STRING, ld.getResponseString());
		jsonObj.put(ZABConstants.STATUS_CODE, ld.getResponseCode());
		jsonObj.put(ZABConstants.SUCCESS, ld.getSuccess());
		return jsonObj;
	}
	
	public static JSONArray getJSONArray(ArrayList<FormReport> lst) throws JSONException {
		JSONArray array = new JSONArray();
		int size =lst.size();
		for (int i=0;i<size;i++) {
			FormReport ld=lst.get(i);
			if(ld!=null) {				
				array.put(getJSONObject(ld));
			}
		}
		return array;
	}


}
