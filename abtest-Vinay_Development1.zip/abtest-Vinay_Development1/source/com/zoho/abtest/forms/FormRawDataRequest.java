//$Id$
package com.zoho.abtest.forms;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;

import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABRequest;
import com.zoho.abtest.report.ReportRawDataConstants;
import com.zoho.abtest.utility.ZABUtil;

public class FormRawDataRequest extends ZABRequest {

	@Override
	public void updateFromRequest(HashMap<String, String> map,
			HttpServletRequest request) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void specificValidation(HashMap<String, String> map,
			HttpServletRequest request) throws IOException, JSONException {
		// TODO Auto-generated method stub
		
	}
	
	
	public ArrayList<HashMap<String,String>> parseFormAnalyticsJSONFromUrlParam(HttpServletRequest request, String moduleName, Boolean isExperimentData) throws JSONException, IOException
	{
		String inputJson = request.getParameter("raw");

		String string = inputJson;
	
		ArrayList<HashMap<String,String>> mapArray = null;
		
		switch(moduleName)
		{ 
		
			case ReportRawDataConstants.API_MODULE_FORMANALYTICSEXP_RAW_SH :
				mapArray = new ArrayList<HashMap<String,String>>(); 

				HashMap<String,String> map = ZABAction.parseJSON(ZABAction.parseModuleInputObject(string,moduleName));
				mapArray.add(map);
			break;

			case ReportRawDataConstants.API_MODULE_FORMANALYTICS_RAW_SH :
				
					mapArray = ZABAction.parseJSON(ZABAction.parseModuleInputArray(string,moduleName));
				break;
			case ReportRawDataConstants.API_MODULE_USERAGENT_RAW_SH :
				
					mapArray = new ArrayList<HashMap<String,String>>(); 
					HashMap<String,String> map1 = ZABAction.parseJSON(ZABAction.parseModuleInputObject(string,moduleName));
					validateUserAgentRawdata(map1);
					mapArray.add(map1);
				break;
			default : 
				break;
		}
		
		return mapArray;
	}

}
