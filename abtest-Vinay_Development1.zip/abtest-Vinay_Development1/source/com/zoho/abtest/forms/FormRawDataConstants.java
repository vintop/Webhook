//$Id$
package com.zoho.abtest.forms;


public class FormRawDataConstants {
	
	public static final String API_MODULE = "formrawdata"; //No I18N
	public static final String API_FORM_FIELD_MODULE = "formfieldrawdata"; //No I18N

	public static final String VISIT_ID="visit_id";    //No I18N
	public static final String EXPERIMENT_ID="experiment_id";    //No I18N
	public static final String EXPERIMENT_KEY="experiment_key";    //No I18N
	public static final String FORM_STARTER="form_starter";   //No I18N
    public static final String FORM_CONVERSION="form_conversion"; //No I18N
    public static final String FORM_SUBMISSION="form_submission"; //No I18N
    public static final String FORM_LIVE="form_live";  //No I18N
    public static final String FORM_SPENT_TIME="form_spent_time"; //No I18N
    public static final String FORM_LEVEL_CHANGE="form_level_change"; //No I18N
    public static final String TIME="time"; //No I18N
    public static final String REQUEST="request"; //No I18N
    
	public static final String FORM_FIELD_ID="form_field_id";   //No I18N
	public static final String FILLED_RATE="filled_rate";   //No I18N	
	public static final String FORM_FIELD_VISIT="form_field_visit";   //No I18N
	public static final String FORM_FIELD_STARTER="form_field_starter";   //No I18N
	public static final String FORM_FIELD_REFOCUS="form_field_refocus";   //No I18N
	public static final String FORM_FIELD_CORRECTION="form_field_correction";   //No I18N
	public static final String FORM_FIELD_DROPOFF="form_field_dropoff";   //No I18N
	public static final String FORM_FIELD_BLANKRATE="form_field_blankrate";   //No I18N
	public static final String FORM_FIELD_COMPLETION_TIME="form_field_completion_time";   //No I18N
	public static final String FORM_FIELD_HESITATION_TIME="form_field_hesitation_time";   //No I18N

}
