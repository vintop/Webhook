//$Id$
package com.zoho.abtest.forms;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;  
import org.jsoup.select.Elements;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.utility.ScriptChecker;
import com.zoho.abtest.utility.ZABUtil;

public class FormParseUrl extends ZABModel{

	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(FormParseUrl.class.getName());
	public static JSONArray parseFormUrl(String url){
		
		URL obj;
		InputStream input = null;
		HttpURLConnection con = null;
		JSONArray jsonarray=new JSONArray();
		
		ArrayList<String> fieldTypes=new ArrayList<String>();
		fieldTypes.add("input"); //No I18N
		fieldTypes.add("select"); //No I18N
		fieldTypes.add("password"); //No I18N
		fieldTypes.add("textarea"); //No I18N
		
	try {
	
		obj = new URL(url);
			
		con = (HttpURLConnection) obj.openConnection();
		con.setRequestMethod("GET");   //No I18N
		con.setConnectTimeout(5000);
		
		String userAgent = ZABUtil.getCurrentRequest().getHeader("User-Agent"); 
		
		if(userAgent != null) {
			con.setRequestProperty("User-Agent",userAgent); //No I18N
		}
		
		input= con.getInputStream();
			
		Document doc = Jsoup.parse(input, "UTF-8", url); //No I18N
		Elements forms=doc.getElementsByTag("form"); //No I18N
			
		for(Element element:forms){
				
			ArrayList<String> array=new ArrayList<String>();
	        JSONArray jsonarray1=new JSONArray();	
	        JSONObject jsonobject=new JSONObject();
			                	
			String formelementid=element.attr("id");  //No I18N
			String formelementname=element.attr("name");  //No I18N
			            	
			jsonobject.put(FormConstants.FORM_ELEMENT_ID,formelementid );
			jsonobject.put(FormConstants.FORM_ELEMENT_NAME,formelementname);
			jsonobject.put(FormConstants.FORM_ELEMENT_SELECTOR,element.cssSelector());
		                
		    Iterator it=fieldTypes.iterator();
		        
		     while(it.hasNext()){
		        	getFields(element,(String)it.next(),jsonarray1,array);
		        }
		                
		        jsonobject.put(FormConstants.FORM_FIELDS,jsonarray1);
		        long nooffields=array.stream().distinct().count();
		        jsonobject.put(FormConstants.FORM_NO_OF_FIELDS,Long.toString(nooffields));
		        jsonobject.put(FormConstants.FORM_URL,url);
		        jsonobject.put(ZABConstants.SUCCESS,Boolean.TRUE);
		        jsonarray.put(jsonobject);
			}
         } catch (IOException e) {
   			  	LOGGER.log(Level.SEVERE,e.getMessage(),e);
   			} catch (JSONException e) {
   				LOGGER.log(Level.SEVERE,e.getMessage(),e);
   		}finally {
   				try {				
   						if(input!=null) {
   							try {						
   								input.close();
   							} catch (Exception e2) {
   								LOGGER.log(Level.SEVERE,e2.toString(),e2);
   							}
   						}
   						if(con!=null) {
   							try {
   								con.disconnect();
   							} catch (Exception e2) {
   								LOGGER.log(Level.SEVERE,e2.toString(),e2);
   							}
   						}
   					} catch (Exception e2) {
   						LOGGER.log(Level.SEVERE,e2.toString(),e2);
   					}
   			}
		return jsonarray;
										
	}
	
	public static Boolean compareUrls(String url,String conversionurl){
		
		URL url1,url2;
		Boolean domainmatch=false;
		try{
		url1=new URL(url);
		url2=new URL(conversionurl);
		String host1 = url1.getHost();
		String host2=url2.getHost();
		if(host1.equals(host2)){
			domainmatch=true;
		}
		else{
			domainmatch=false;
		}
		}catch(IOException e){
 			  LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		return domainmatch;
	}
	
	//parameters element: form element , type: fieldType to be tracked jsonarray1:array containing the fields tracked 
	public static void getFields(Element element,String type,JSONArray jsonarray1,ArrayList<String> array){
		
		try{
			
			Elements inputElements = element.getElementsByTag(type);  
			for (Element inputElement : inputElements) {
         	
				JSONObject jsonobject1=new JSONObject();
				String name = inputElement.attr("name");  //No I18N
				String id=inputElement.attr("id");  //No I18N
				String fieldType = inputElement.attr("type");//No I18N

				if(array.contains(id) || array.contains(name) && (fieldType.equals("radio") || fieldType.equals("checkbox"))){
					continue;
				}
				
				if(fieldType.equals("submit") || fieldType.equals("button") || fieldType.equals("hidden") || fieldType.equals("image") || fieldType.equals("reset")){
					continue;
				}

				if(!name.isEmpty()){
		             array.add(name);
				}else if(!id.isEmpty()){
		             array.add(id);
				}
				
				if(!name.isEmpty()){
            	 jsonobject1.put(FormConstants.FIELD_ALIAS,name);
				}else{
            	 jsonobject1.put(FormConstants.FIELD_ALIAS,id);
				}
				
				jsonobject1.put(FormConstants.FORM_FIELD_NAME,name);
				jsonobject1.put(FormConstants.FIELD_ID,id);
				jsonobject1.put(FormConstants.IS_ENABLED,true);
             
				if(fieldType.isEmpty() && type == "input"){
					fieldType="text"; //No I18N
				}
				if(!fieldType.isEmpty()){
					jsonobject1.put(FormConstants.FORM_FIELD_TYPE,fieldType);
				}
				else{
					jsonobject1.put(FormConstants.FORM_FIELD_TYPE,type);
				}
				
				jsonarray1.put(jsonobject1);
			}  
		}catch(Exception e){
			
		}

	}

}
//Elements labelElements= element.getElementsByTag("label"); //No I18N

//String labelText="";

//for(Element labelElement : labelElements){
//	String labelId=labelElement.attr("for"); //No I18N
//	if(labelId.equals(id)&&!id.isEmpty()&&!labelId.isEmpty()){
//		labelText=labelElement.text();
//		break;
//	}
//}
//if(!labelText.isEmpty()){
//jsonobject1.put(FormConstants.FIELD_ALIAS,labelText);
//}else
