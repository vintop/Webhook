//$Id$
package com.zoho.abtest.forms;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABModel;


public class FormFieldDetails extends ZABModel{
	
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(FormFieldDetails.class.getName());

	private String fieldid;
	private String formfieldkey;
	private Long formfieldid;
	private String fieldname;
	private String fieldtype;
	private String fieldalias;
	private Boolean isenabled;
	
	public String getFieldalias() {
		return fieldalias;
	}
	public void setFieldalias(String fieldalias) {
		this.fieldalias = fieldalias;
	}
	public Boolean getIsenabled() {
		return isenabled;
	}
	public void setIsenabled(Boolean isenabled) {
		this.isenabled = isenabled;
	}
	public String getFieldtype() {
		return fieldtype;
	}
	public void setFieldtype(String fieldtype) {
		this.fieldtype = fieldtype;
	}
	public String getFieldid() {
		return fieldid;
	}
	public void setFieldid(String fieldid) {
		this.fieldid = fieldid;
	}
	public String getFormfieldkey() {
		return formfieldkey;
	}
	public void setFormfieldkey(String formfieldkey) {
		this.formfieldkey = formfieldkey;
	}
	public Long getFormfieldid() {
		return formfieldid;
	}
	public void setFormfieldid(Long formfieldid) {
		this.formfieldid = formfieldid;
	}
	public String getFieldname() {
		return fieldname;
	}
	public void setFieldname(String fieldname) {
		this.fieldname = fieldname;
	}
	public static JSONArray getJSONArray(ArrayList<FormFieldDetails> formFieldDetails) {
		
		JSONArray jsonarray=new JSONArray();
		try{
		for(int i=0;i<formFieldDetails.size();i++){
			JSONObject json=new JSONObject();
			FormFieldDetails f=formFieldDetails.get(i);
			json.put(FormConstants.FORM_FIELD_ID,f.getFormfieldid());
			json.put(FormConstants.FORM_FIELD_KEY,f.getFormfieldkey());
			json.put(FormConstants.FORM_FIELD_NAME,f.getFieldname());
			json.put(FormConstants.FIELD_ID,f.getFieldid());
			json.put(FormConstants.FIELD_ALIAS, f.getFieldalias());
			json.put(FormConstants.IS_ENABLED, f.getIsenabled());
			json.put(FormConstants.FORM_FIELD_TYPE,f.getFieldtype());
			jsonarray.put(json);
		}
		}catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		return jsonarray;
	}
	
}
