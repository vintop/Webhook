//$Id$
package com.zoho.abtest.forms;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import com.zoho.abtest.FORM_DETAILS;
import com.zoho.abtest.FORM_FIELD_DETAILS;
import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.ZABConstants;

public class FormConstants {
	
	public static final String API_MODULE = "form_details"; //No I18N
	public static final String API_RESOURCE = "resource.audience"; //NO I18N
	// form data for FORM_TABLE
	public static final String EXPERIMENT_ID="experiment_id";    //No I18N
	public static final String EXPERIMENT_KEY="experiment_key";    //No I18N
	public static final String EXPERIMENT_URL="experiment_url";    //No I18N
	public static final String FORM_URL="experiment_url";   //No I18N
    public static final String FORM_ELEMENT_ID="form_id"; //No I18N
    public static final String FORM_ELEMENT_NAME="form_name"; //No I18N
    public static final String FORM_ELEMENT_SELECTOR="form_selector"; //No I18N
    public static final String FORM_NO_OF_FIELDS="field_count";  //No I18N
    public static final String MATCH_TYPE="match_type"; //No I18N
	public static final String FORM_CONVERSION_URL="form_conversion_url"; //No I18N
    //form fields  data for FORM_FIELD_DETAILS_TABLE 
	public static final String FORM_FIELDS="form_fields"; //No I18N
    public static final String FORM_FIELD_ID="form_field_id";    //No I18N
    public static final String FORM_FIELD_TYPE="field_type";   //No I18N
    public static final String FORM_FIELD_NAME="field_name"; //No I18N
    public static final String FORM_FIELD_NAME1="form_field_name"; //No I18N
    public static final String FIELD_ID="field_id"; //No I18N
    public static final String FORM_FIELD_KEY="form_field_key"; //No I18N
    public static final String FIELD_ALIAS="field_alias"; //No I18N
    public static final String IS_ENABLED="is_enabled"; //No I18N
    public static final String FORM_LOADED="form_loaded"; //No I18N
    public static final String FIELD_TYPE= "f_t"; //No I18N
    public static final String ID = "id"; //No I18N
    public static final String NAME = "n"; //No I18N
    public static final String DOMAIN_MATCH ="domain_match";	//No I18N
	public static final String CUSTOM_EVENT_LINK_NAME="custom_event_linkname"; //No I18N 
	public static final String CUSTOM_EVENT_NAME="custom_event_name"; //No I18N 
	public static final String CUSTOM_EVENT_ID="custom_event_id"; //No I18N
	public final static String EXCLUDE_URLS = "exclude_urls"; //NO I18N
	public final static String INCLUDE_URLS = "include_urls"; //NO I18N

   
    public final static List<Constants> FORM_FIELD_DETAILS_TABLE;
    public final static List<Constants> FORM_TABLE;

	public enum FormMatchType {
		
		SIMPLE_MATCH(1),
		EXACT_MATCH(2),
		PATTERN_MATCH(3),
		REGEX_MATCH(4),
		CONTAINS_MATCH(5),
		STARTS_WITH(6),
		ENDS_WITH(7),
		CUSTOM_EVENT(8);
		
		private Integer matchTypeId;
		
		private FormMatchType(Integer matchTypeId) {
			this.matchTypeId = matchTypeId;
		}

		public Integer getMatchTypeId() {
			return matchTypeId;
		}
		
		public static FormMatchType getMatchTypeById(Integer matchTypeId) {
			if(matchTypeId!=null) {
				for(FormMatchType mtype: FormMatchType.values()) {
					if(matchTypeId.equals(mtype.getMatchTypeId())) {
						return mtype;
					}
				}
			}
			return null;
	   }
	}
   	
    static{
   		ArrayList<Constants> list = new ArrayList<Constants>();
   		list.add(new Constants(EXPERIMENT_ID,FORM_FIELD_DETAILS.EXPERIMENT_ID,ZABConstants.LONG,Boolean.FALSE));
   		list.add(new Constants(FORM_FIELD_NAME,FORM_FIELD_DETAILS.FORM_FIELD_NAME,ZABConstants.STRING,Boolean.TRUE));
   		list.add(new Constants(FORM_FIELD_TYPE,FORM_FIELD_DETAILS.FORM_FIELD_TYPE,ZABConstants.STRING,Boolean.TRUE));
   		list.add(new Constants(FIELD_ID,FORM_FIELD_DETAILS.FIELD_ID,ZABConstants.STRING,Boolean.TRUE));
   		list.add(new Constants(FORM_FIELD_KEY,FORM_FIELD_DETAILS.FORM_FIELD_KEY,ZABConstants.STRING,Boolean.TRUE));
   		list.add(new Constants(FORM_FIELD_ID,FORM_FIELD_DETAILS.FORM_FIELD_ID,ZABConstants.LONG,Boolean.FALSE));
   		list.add(new Constants(FIELD_ALIAS,FORM_FIELD_DETAILS.FIELD_ALIAS,ZABConstants.STRING,Boolean.TRUE));
   		list.add(new Constants(IS_ENABLED,FORM_FIELD_DETAILS.IS_ENABLED,ZABConstants.BOOLEAN,Boolean.TRUE));
   		FORM_FIELD_DETAILS_TABLE = (List<Constants>) Collections.unmodifiableList(list);
   	}

    static{
		ArrayList<Constants> list = new ArrayList<Constants>();
		list.add(new Constants(EXPERIMENT_ID,FORM_DETAILS.EXPERIMENT_ID,ZABConstants.LONG,Boolean.FALSE));
		list.add(new Constants(EXPERIMENT_URL,FORM_DETAILS.EXPERIMENT_URL,ZABConstants.STRING,Boolean.FALSE));
		list.add(new Constants(FORM_ELEMENT_ID,FORM_DETAILS.FORM_ELEMENT_ID,ZABConstants.STRING,Boolean.TRUE));
		list.add(new Constants(FORM_ELEMENT_NAME,FORM_DETAILS.FORM_ELEMENT_NAME,ZABConstants.STRING,Boolean.TRUE));
		list.add(new Constants(FORM_NO_OF_FIELDS,FORM_DETAILS.FORM_NO_OF_FIELDS,ZABConstants.INTEGER,Boolean.TRUE));
		list.add(new Constants(FORM_ELEMENT_SELECTOR,FORM_DETAILS.FORM_ELEMENT_SELECTOR,ZABConstants.STRING,Boolean.TRUE));
		list.add(new Constants(MATCH_TYPE,FORM_DETAILS.MATCH_TYPE,ZABConstants.INTEGER,Boolean.TRUE));
		list.add(new Constants(FORM_LOADED,FORM_DETAILS.IS_AUTO_LOADED,ZABConstants.BOOLEAN,Boolean.TRUE));
		list.add(new Constants(FORM_CONVERSION_URL,FORM_DETAILS.FORM_CONVERSION_URL,ZABConstants.STRING,Boolean.TRUE));
		list.add(new Constants(EXCLUDE_URLS,FORM_DETAILS.EXCLUDE_URLS,ZABConstants.STRING,Boolean.TRUE,Boolean.TRUE));
		list.add(new Constants(INCLUDE_URLS,FORM_DETAILS.INCLUDE_URLS,ZABConstants.STRING,Boolean.TRUE,Boolean.TRUE));
        FORM_TABLE = (List<Constants>) Collections.unmodifiableList(list);
	}	
	

}
