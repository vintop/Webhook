
//$Id$
package com.zoho.abtest.forms;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.logging.Logger;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.FORM_FIELD_DETAILS;
import com.zoho.abtest.common.ZABModel;

public class FormRawData extends ZABModel {
	
	

	private static final long serialVersionUID = 1L;

	private static final Logger LOGGER = Logger.getLogger(FormRawData.class.getName());
	private String visitid;
	private Long experimentid;
	private int formstarter;
	private int formconversion;
	private Long formspenttime;
	private Long formlive;
	private Long formsubmission;
	private Long formfieldid;
	private Long time;

	public Long getFormlive() {
		return formlive;
	}
	public void setFormlive(Long formlive) {
		this.formlive = formlive;
	}
	public Long getFormsubmission() {
		return formsubmission;
	}
	public void setFormsubmission(Long formsubmission) {
		this.formsubmission = formsubmission;
	}
	public Long getFormfieldid() {
		return formfieldid;
	}
	public void setFormfieldid(Long formfieldid) {
		this.formfieldid = formfieldid;
	}
	public String getVisitid() {
		return visitid;
	}
	public void setVisitid(String visitid) {
		this.visitid = visitid;
	}
	public Long getExperimentid() {
		return experimentid;
	}
	public void setExperimentid(Long experimentid) {
		this.experimentid = experimentid;
	}
	public Long getTime() {
		return time;
	}
	public void setTime(Long time) {
		this.time = time;
	}
	public int getFormstarter() {
		return formstarter;
	}
	public void setFormstarter(int formstarter) {
		this.formstarter = formstarter;
	}
	public int getFormconversion() {
		return formconversion;
	}
	public void setFormconversion(int formconversion) {
		this.formconversion = formconversion;
	}
	public Long getFormspenttime() {
		return formspenttime;
	}
	public void setFormspenttime(Long formspenttime) {
		this.formspenttime = formspenttime;
	}

	
	public static ArrayList<Long> getFormFieldDetails(DataObject dobj) throws DataAccessException {

		ArrayList<Long> arraylist=new ArrayList<Long>();
		if(dobj.containsTable(FORM_FIELD_DETAILS.TABLE)){
			Iterator it=dobj.getRows(FORM_FIELD_DETAILS.TABLE);
			while(it.hasNext()){
				Row row = (Row)it.next();
				Long experimentId=(Long)row.get(FORM_FIELD_DETAILS.FORM_FIELD_ID);
				arraylist.add(experimentId);
			}
		}
		return arraylist;
	}
	
	public static Long getFormFieldIdFromArrayList(ArrayList<FormFieldDetails> arrayList,String formFieldKey) {
		Long formFieldId=0L;
		for(int i=0;i<arrayList.size();i++){
			FormFieldDetails f=arrayList.get(i);
			if(f.getFormfieldkey().equals(formFieldKey)){
				formFieldId=f.getFormfieldid();
				break;
			}
		}
		return formFieldId;
	}
	
	

}
