//$Id$
package com.zoho.abtest.funnel;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.json.JSONException;

import com.opensymphony.xwork2.ActionSupport;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.experiment.ExperimentHandler;
import com.zoho.abtest.utility.ZABUtil;

public class FunnelStepAction  extends ActionSupport implements ServletResponseAware, ServletRequestAware {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private HttpServletRequest request;
	
	private HttpServletResponse response;
	
	private String linkname;
	
	private static final Logger LOGGER = Logger.getLogger(FunnelStepAction.class.getName());
	
	public String getLinkname() {
		return linkname;
	}

	public void setLinkname(String linkname) {
		this.linkname = linkname;
	}

	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		request = arg0;
	}

	@Override
	public void setServletResponse(HttpServletResponse arg0) {
		response = arg0;
	}
	
	public String execute() throws Exception {
		
		ArrayList<FunnelStep> steps = new ArrayList<FunnelStep>();
		try {			
			switch(ZABAction.getHTTPMethod(request)) {
			case POST:	
				HashMap<String,String> hs = ZABAction.getRequestParser(request).parseFunnelSteps(request);
				if(hs.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					FunnelStep funnelStep = new FunnelStep();
					funnelStep.setSuccess(Boolean.FALSE);
					funnelStep.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
					steps.add(funnelStep);
				}else{
					steps.add(FunnelStep.createFunnelStep(hs));
				}
				break;
			case GET:
				String experimentLinkname = (String)request.getParameter(FunnelAnalysisConstants.EXPERIMENT_LINKNAME);
				steps.addAll(FunnelStep.getFunnelStepForExperiment(experimentLinkname));
				break;
			case DELETE:
				steps.add(FunnelStep.deleteFunnelStep(linkname));
				break;
			case PUT:
				HashMap<String,String> hsPut = ZABAction.getRequestParser(request).parseFunnelSteps(request);
				if(hsPut.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hsPut.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					FunnelStep funnelStep = new FunnelStep();
					funnelStep.setSuccess(Boolean.FALSE);
					funnelStep.setResponseString(hsPut.get(ZABConstants.RESPONSE_STRING));
					steps.add(funnelStep);
				}else{
					steps.add(FunnelStep.updateFunnelStep(hsPut));
				}
				break;
			}
		}catch(JSONException ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getInvalidInputFormatException(FunnelAnalysisConstants.STEP_API_MODULE_NAME_PLURAL));
			return null; 	
		}
		catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), FunnelAnalysisConstants.STEP_API_MODULE_NAME_PLURAL));
			return null; 	
		}		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getFunnelStepResponse(request, steps));		
	    return null;
		
		
	}

}
