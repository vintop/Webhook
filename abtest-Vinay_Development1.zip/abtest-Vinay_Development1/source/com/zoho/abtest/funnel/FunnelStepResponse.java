//$Id$
package com.zoho.abtest.funnel;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;
import com.zoho.abtest.experiment.ExperimentResponse;

public class FunnelStepResponse {
	
	private static final Logger LOGGER = Logger.getLogger(ExperimentResponse.class.getName());
	
	public String jsonResponse(HttpServletRequest request,ArrayList<FunnelStep> lst) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(lst);			
			JSONObject json = ZABResponse.updateMetaInfo(request, FunnelAnalysisConstants.STEP_API_MODULE_NAME_PLURAL, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){
			
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			
		}
		return returnBuffer.toString();
	}
	
	public static JSONArray getJSONArray(ArrayList<FunnelStep> lst) throws JSONException {
		JSONArray array = new JSONArray();
		if(lst!=null) {			
			int size =lst.size();
			for (int i=0;i<size;i++) {
				FunnelStep step=lst.get(i);
				JSONObject stepObj = new JSONObject();
				stepObj.put(FunnelAnalysisConstants.DISPLAY_NAME, step.getDisplayName());
				stepObj.put(ZABConstants.SUCCESS, step.getSuccess());
				stepObj.put(ZABConstants.RESPONSE_STRING, step.getResponseString());
				stepObj.put(FunnelAnalysisConstants.STEP_KEY, step.getStepKey());
				stepObj.put(FunnelAnalysisConstants.STEP_ORDER, step.getStepOrder());
				stepObj.put(ZABConstants.LINKNAME, step.getLinkname());
				stepObj.put(FunnelAnalysisConstants.EXPERIMENT_LINKNAME, step.getExperimentLinkname());
				stepObj.put(FunnelAnalysisConstants.CUSTOM_EVENT_LN, step.getCustomEventLinkname());
				stepObj.put(FunnelAnalysisConstants.MATCH_TYPE, step.getStepMatchType());
				stepObj.put(FunnelAnalysisConstants.VALUE, step.getStepValue());
				array.put(stepObj);
			}
		}
		return array;
	}
}
