//$Id$
package com.zoho.abtest.funnel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.function.ToLongFunction;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.LongStream;

import javax.transaction.Transaction;
import javax.transaction.TransactionManager;

import org.json.JSONArray;
import org.json.JSONObject;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.SortColumn;
import com.adventnet.iam.IAMUtil;
import com.adventnet.iam.ServiceOrg;
import com.adventnet.persistence.DataAccess;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.FUNNEL_ANALYSIS;
import com.zoho.abtest.FUNNEL_STEPS;
import com.zoho.abtest.FUNNEL_STEP_VISITS;
import com.zoho.abtest.PROJECT;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABColumn;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.eventactivity.EventActivityConstants;
import com.zoho.abtest.eventactivity.EventActivityConstants.Module;
import com.zoho.abtest.eventactivity.EventActivityWrapper;
import com.zoho.abtest.exception.ResourceNotFoundException;
import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.experiment.ABSplitExperiment;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentStatus;
import com.zoho.abtest.funnel.report.FunnelFlexible;
import com.zoho.abtest.license.PortalLicenseMapping;
import com.zoho.abtest.listener.ZABNotifier;
import com.zoho.abtest.project.ProjectTreeEventConstants;
import com.zoho.abtest.project.ProjectTreeEventConstants.OperationType;
import com.zoho.abtest.project.ProjectTreeEventWrapper;
import com.zoho.abtest.utility.ZABUtil;

public class FunnelAnalysis extends Experiment {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = Logger.getLogger(FunnelAnalysis.class.getName());
	
	@ZABColumn(name=FUNNEL_ANALYSIS.SESSION_TIME)
	private Long sessionTime;
	
	private Integer stepCount;
	
	private transient ArrayList<FunnelStep> steps = new ArrayList<FunnelStep>();
	
	private Long visitorCount;
	
	private Float conversionRate;
	
	public Float getConversionRate() {
		return conversionRate;
	}

	public void setConversionRate(Float conversionRate) {
		this.conversionRate = conversionRate;
	}

	public Long getVisitorCount() {
		return visitorCount;
	}

	public void setVisitorCount(Long visitorCount) {
		this.visitorCount = visitorCount;
	}

	public Integer getStepCount() {
		return stepCount;
	}

	public void setStepCount(Integer stepCount) {
		this.stepCount = stepCount;
	}

	public ArrayList<FunnelStep> getSteps() {
		return steps;
	}

	public void setSteps(ArrayList<FunnelStep> steps) {
		this.steps = steps;
	}

	public Long getSessionTime() {
		return sessionTime;
	}

	public void setSessionTime(Long sessionTime) {
		this.sessionTime = sessionTime;
	}

	public FunnelAnalysis() {
		
	}
	
	public FunnelAnalysis(Experiment experiment) {
		copyValues(experiment);
	}
	
	public static FunnelAnalysis getFunnelAnalysisWithSteps(String linkname) {
		Criteria c = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_LINK_NAME), linkname, QueryConstants.EQUAL);
		return getFunnelAnalysisWithSteps(c);
	}
	
	public static FunnelAnalysis getFunnelAnalysisWithSteps(Long experimentId) {
		Criteria c = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
		return getFunnelAnalysisWithSteps(c);
	}
	
	public static FunnelAnalysis getFunnelAnalysisWithSteps(Criteria c) {
		FunnelAnalysis funnelAnalysis = null;
		try {			
			Join join1=new Join(EXPERIMENT.TABLE,FUNNEL_ANALYSIS.TABLE,new String[]{EXPERIMENT.EXPERIMENT_ID},new String[]{FUNNEL_ANALYSIS.EXPERIMENT_ID},Join.INNER_JOIN);
			Join join2=new Join(EXPERIMENT.TABLE,PROJECT.TABLE,new String[]{EXPERIMENT.PROJECT_ID},new String[]{PROJECT.PROJECT_ID},Join.INNER_JOIN);
			SortColumn sort = new SortColumn(new Column(FUNNEL_STEPS.TABLE, FUNNEL_STEPS.STEP_ORDER), Boolean.TRUE);
			DataObject dobj = getRow(EXPERIMENT.TABLE, c, new Join[]{join1, join2});
			if(dobj.containsTable(EXPERIMENT.TABLE)) {
				Row experimentRow = dobj.getFirstRow(EXPERIMENT.TABLE);
				Experiment experiment = getExperimentFromRow(experimentRow);
				funnelAnalysis = new FunnelAnalysis(experiment);
				funnelAnalysis.setSuccess(Boolean.TRUE);
				
				Row projectRow = dobj.getFirstRow(PROJECT.TABLE);
				funnelAnalysis.setProjectLinkname((String)projectRow.get(PROJECT.PROJECT_LINK_NAME));
				
				Row fnRow = dobj.getFirstRow(FUNNEL_ANALYSIS.TABLE);
				funnelAnalysis.setSessionTime((Long) fnRow.get(FUNNEL_ANALYSIS.SESSION_TIME));
				
				Criteria c1 = new Criteria(new Column(FUNNEL_STEPS.TABLE, FUNNEL_STEPS.EXPERIMENT_ID), experiment.getExperimentId(), QueryConstants.EQUAL);
				funnelAnalysis.setSteps(FunnelStep.getFunnelByCriteria(c1, sort));
			}
			
		} catch (Exception e) {
			funnelAnalysis = new FunnelAnalysis();
			funnelAnalysis.setSuccess(Boolean.FALSE);
			funnelAnalysis.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return funnelAnalysis;
	}

	public static FunnelAnalysis createFunnelAnalysis(HashMap<String,String> hs) {
		FunnelAnalysis funnelAnalysis = null;
		TransactionManager mgr = DataAccess.getTransactionManager();
		try {
			mgr.begin();
			
			//Create Experiment
			Experiment experiment = createExperiment(hs);
			
			String projectLinkname = hs.get(ExperimentConstants.PROJECT_LINKNAME);
			if(experiment  != null && experiment.getSuccess().equals(Boolean.TRUE)) {
				Long experimentId = experiment.getExperimentId();

				hs.put(ExperimentConstants.EXPERIMENT_ID, experimentId.toString());
				addDefaultValueIfNotAvailable(hs, FunnelAnalysisConstants.SESSION_TIME, FunnelAnalysisConstants.DEFAULT_SESSION_TIME);

				//Create details
				DataObject dobj = createRow(FunnelAnalysisConstants.FUNNEL_ANALYSIS_TABLE, FUNNEL_ANALYSIS.TABLE, hs);
				
				Row funnelRow = dobj.getFirstRow(FUNNEL_ANALYSIS.TABLE);
				
				funnelAnalysis = (FunnelAnalysis)getModelFromRow(funnelRow, FunnelAnalysis.class);
				funnelAnalysis.copyValues(experiment);
				funnelAnalysis.setProjectLinkname(projectLinkname);
				
				if(hs.containsKey(FunnelAnalysisConstants.STEPS)) {
					String steps = hs.get(FunnelAnalysisConstants.STEPS);
					JSONArray stepsArray = new JSONArray(steps);
					for(int i=0; i<stepsArray.length(); i++) {
						JSONObject stepObj = stepsArray.getJSONObject(i);
						HashMap<String, String> map = ZABAction.parseJSON(stepObj);
						map.put(FunnelAnalysisConstants.EXPERIMENT_ID,  experimentId.toString());
						map.put(FunnelAnalysisConstants.EXPERIMENT_LINKNAME,experiment.getExperimentLinkname());
						FunnelStepRequest.validate(map, "POST"); //NO I18N
						if(map.containsKey(ZABConstants.SUCCESS) &&
								!ZABUtil.parseBoolean(map.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
							throw new ZABException("Error while creating funnel steps"); //NO I18N
						} else {
							FunnelStep.createFunnelStep(map);
						}
					}
				} else {
					HashMap<String, String> map = new HashMap<String, String>();
					map.put(FunnelAnalysisConstants.DISPLAY_NAME, FunnelAnalysisConstants.STEP_1);
					map.put(FunnelAnalysisConstants.STEP_ORDER, "1");
					map.put(FunnelAnalysisConstants.EXPERIMENT_ID,  experimentId.toString());
					map.put(FunnelAnalysisConstants.EXPERIMENT_LINKNAME,experiment.getExperimentLinkname());
					FunnelStep.createFunnelStep(map);
				}

				mgr.commit();
				funnelAnalysis.setSuccess(Boolean.TRUE);
				//Event Activity Log
				HashMap<String, String> updatedValues = new HashMap<String, String>();
				updatedValues.put(EventActivityConstants.EXPERIMENT_ID, experimentId.toString());
				updatedValues.put(EventActivityConstants.USER_ID, ZABUtil.getCurrentUser().getUserId().toString());
				updatedValues.put(EventActivityConstants.TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
				EventActivityWrapper activityWrapper = new EventActivityWrapper();
				activityWrapper.setModule(Module.EXPERIMENT);
				activityWrapper.setOperationType(com.zoho.abtest.eventactivity.EventActivityConstants.OperationType.CREATE);
				activityWrapper.setDbSpace(ZABUtil.getCurrentUserDbSpace());
				activityWrapper.setUpdatedValues(updatedValues);
				ZABNotifier.notifyListeners(EventActivityConstants.EVENT_MODULE_NAME, activityWrapper);

				//Trigger event 
				ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
				wrapper.setModel(funnelAnalysis);
				wrapper.setChangeSets(hs);
				wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
				wrapper.setType(OperationType.CREATE);
				Long zsoid;
				ServiceOrg currentServiceOrg = IAMUtil.getCurrentServiceOrg();
				if(currentServiceOrg != null)
				{
					zsoid = currentServiceOrg.getZSOID();
					wrapper.setZsoid(zsoid.toString());
				}
				ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);
				
			}
			else
			{
				mgr.rollback();
				LOGGER.log(Level.SEVERE,"Exception Occurred while creating experiment. Hence rolledback changes.");
				funnelAnalysis = new FunnelAnalysis();
				funnelAnalysis.setSuccess(Boolean.FALSE);
				funnelAnalysis.setResponseString(experiment!=null? experiment.getResponseString() : ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			}

		} catch (Exception e) {
			try {
				mgr.rollback();
			} catch (Exception e1) {
				LOGGER.log(Level.SEVERE,"Exception Occurred",e1);
			}
			funnelAnalysis = new FunnelAnalysis();
			funnelAnalysis.setSuccess(Boolean.FALSE);
			funnelAnalysis.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return funnelAnalysis;
	}
	
	public static Long getVisitCount(String experimentLinkname) throws Exception {
		Long visitCount = 0l;
		Criteria c1 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_LINK_NAME), experimentLinkname, QueryConstants.EQUAL);
		Join join1 = new Join(EXPERIMENT.TABLE,FUNNEL_STEPS.TABLE,new String[]{EXPERIMENT.EXPERIMENT_ID},new String[]{FUNNEL_STEPS.EXPERIMENT_ID},Join.INNER_JOIN);
		Join join2 = new Join(FUNNEL_STEPS.TABLE,FUNNEL_STEP_VISITS.TABLE,new String[]{FUNNEL_STEPS.STEP_ID},new String[]{FUNNEL_STEPS.STEP_ID},Join.INNER_JOIN);
		SortColumn sort = new SortColumn(new Column(FUNNEL_STEPS.TABLE, FUNNEL_STEPS.STEP_ORDER), Boolean.TRUE);
		DataObject dobj = getRow(EXPERIMENT.TABLE, c1, sort, new Join[]{join1, join2});
		if(dobj.containsTable(FUNNEL_STEP_VISITS.TABLE)) {
			Row row = dobj.getFirstRow(FUNNEL_STEP_VISITS.TABLE);
			visitCount = (Long)row.get(FUNNEL_STEP_VISITS.VISIT_COUNT);
		}
		return visitCount;
	}
	
	public static FunnelAnalysis getFunnelAnalysisMeta(String experimentLinkname) {
		FunnelAnalysis funnelAnalysis = null;
		try {			
			funnelAnalysis = new FunnelAnalysis();
			funnelAnalysis.setExperimentLinkname(experimentLinkname);
			
			Integer stepCount = 0;
			Criteria c1 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_LINK_NAME), experimentLinkname, QueryConstants.EQUAL);
			Join join1 = new Join(EXPERIMENT.TABLE,FUNNEL_STEPS.TABLE,new String[]{EXPERIMENT.EXPERIMENT_ID},new String[]{FUNNEL_STEPS.EXPERIMENT_ID},Join.INNER_JOIN);
//			Join join2 = new Join(FUNNEL_STEPS.TABLE,FUNNEL_STEP_VISITS.TABLE,new String[]{FUNNEL_STEPS.STEP_ID},new String[]{FUNNEL_STEPS.STEP_ID},Join.LEFT_JOIN);
			SortColumn sort = new SortColumn(new Column(FUNNEL_STEPS.TABLE, FUNNEL_STEPS.STEP_ORDER), Boolean.TRUE);
			DataObject dobj = getRow(EXPERIMENT.TABLE, c1, sort, new Join[]{join1});
			
			if(dobj.containsTable(FUNNEL_STEPS.TABLE)) {
				ArrayList<Long> order = new ArrayList<Long>();
				Iterator it = dobj.getRows(FUNNEL_STEPS.TABLE);
				
				Integer experimentStatus = (Integer) dobj.getFirstRow(EXPERIMENT.TABLE).get(EXPERIMENT.EXPERIMENT_STATUS);
				Boolean mayHaveReport = (!experimentStatus.equals(ExperimentStatus.DRAFT.getStatusCode()));
				
				
				while(it.hasNext()) {
					Row row = (Row)it.next();
					Long stepId = (Long)row.get(FUNNEL_STEPS.STEP_ID);
					if(stepCount == 0 && mayHaveReport) {						
						//Setting conversion rate
						funnelAnalysis.setVisitorCount(FunnelFlexible.getTotalSession(stepId));
					}
					order.add(stepId);
					stepCount++;
				}
				
				if(funnelAnalysis.getVisitorCount()!=null && funnelAnalysis.getVisitorCount() > 0 && mayHaveReport) {
					String experimentKey = (String)dobj.getFirstRow(EXPERIMENT.TABLE).get(EXPERIMENT.EXPERIMENT_KEY);
					Long totalConversion = FunnelFlexible.getTotalConverstion(experimentKey, funnelAnalysis.getVisitorCount(), order);
					Float cpercent = (totalConversion.floatValue() / funnelAnalysis.getVisitorCount().floatValue())*100;
					//Setting conversion rate
					funnelAnalysis.setConversionRate(cpercent.floatValue());
					
				}
				
			}
			
			funnelAnalysis.setSuccess(Boolean.TRUE);
			//Setting conversion rate
			funnelAnalysis.setStepCount(stepCount);
		} catch (ZABException e) {
			funnelAnalysis = new FunnelAnalysis();
			funnelAnalysis.setSuccess(Boolean.FALSE);
			funnelAnalysis.setResponseString(e.getMessage());
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		catch (Exception e) {
			funnelAnalysis = new FunnelAnalysis();
			funnelAnalysis.setSuccess(Boolean.FALSE);
			funnelAnalysis.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		return funnelAnalysis;
	}
	
	public static FunnelAnalysis updateFunnelAnalysis(HashMap<String,String> hs) {
		Boolean alreadyInTransaction = false;
		TransactionManager mgr = DataAccess.getTransactionManager();
		FunnelAnalysis funnelAnalysis = null;
		try {
			Transaction trans = mgr.getTransaction();
			alreadyInTransaction = (trans!=null);
			if(!alreadyInTransaction) {				
				mgr.begin();
			}
			Integer statusUpdated = hs.containsKey(ExperimentConstants.EXPERIMENT_STATUS)?Integer.parseInt(hs.get(ExperimentConstants.EXPERIMENT_STATUS)):null;
			String linkname = hs.get(ZABConstants.LINKNAME);
			Experiment experiment = Experiment.getExperimentByLinkname(linkname);
			if(experiment==null) {
				throw new ResourceNotFoundException(ZABAction.getMessage(ExperimentConstants.API_RESOURCE_INITIAL));
			}
			Long experimentId = experiment.getExperimentId();
			if(statusUpdated!=null && statusUpdated.equals(ExperimentStatus.RUNNING.getStatusCode())) {
				
				ArrayList<FunnelStep> steps =  FunnelStep.getFunnelStepForExperiment(experimentId);
				if(steps.size() < 2) {
					throw new ZABException(ZABAction.getMessage(FunnelAnalysisConstants.FUNNEL_LOW_STEP_ERROR));
				}
			}
			
			
			if(hs.containsKey(FunnelAnalysisConstants.STEPS)) {
				String steps = hs.get(FunnelAnalysisConstants.STEPS);
				funnelAnalysis = new FunnelAnalysis(experiment);
				JSONArray stepsArray = new JSONArray(steps);
				int size = stepsArray.length();
				for(int i=0; i<size; i++) {
					JSONObject stepObj = stepsArray.getJSONObject(i);
					HashMap<String, String> map = ZABAction.parseJSON(stepObj);
					map.put(FunnelAnalysisConstants.EXPERIMENT_ID,  experimentId.toString());
					map.put(FunnelAnalysisConstants.EXPERIMENT_LINKNAME,linkname);
					FunnelStepRequest.validate(map, map.containsKey(ZABConstants.LINKNAME)?"PUT":"POST"); //NO I18N
					if(map.containsKey(ZABConstants.SUCCESS) &&
							!ZABUtil.parseBoolean(map.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
						throw new ZABException(map.get(ZABConstants.RESPONSE_STRING));
					} else {
						FunnelStep step = FunnelStep.upsertFunnelStep(map);
						if(!step.getSuccess()) {
							throw new ZABException(step.getResponseString());
						} else {
							funnelAnalysis.getSteps().add(step);
						}
					}
				}
				if(size > 0) {					
					LongStream ls = funnelAnalysis.getSteps().stream().mapToLong((FunnelStep arg0) -> {
							Long stepId = arg0.getStepId();
							if(stepId == null) {
								try {
									stepId = FunnelStep.getStepIdForLinkname(arg0.getLinkname());
								} catch (Exception e) {
									LOGGER.log(Level.SEVERE,"Exception Occurred",e);
									stepId = 0l;
								}
							}
							return stepId;
					});
					FunnelStep.deleteOthers(ls.toArray(), experimentId);
				}
				
			}
			
			Boolean triggerEvent = false;
			
			if(hs.containsKey(FunnelAnalysisConstants.STEPS) && hs.containsKey(ZABConstants.LINKNAME) && hs.size() == 2) {
				funnelAnalysis.setSuccess(true);
				triggerEvent = true;
			} else {
				experiment = updateExperiment(hs);
				
				if(experiment  != null && experiment.getSuccess().equals(Boolean.TRUE)) {
					funnelAnalysis = new FunnelAnalysis(experiment);
					if(hs.containsKey(FunnelAnalysisConstants.SESSION_TIME)) {
						funnelAnalysis.setSessionTime(Long.parseLong(hs.get(FunnelAnalysisConstants.SESSION_TIME)));
						Criteria c = new Criteria(new Column(FUNNEL_ANALYSIS.TABLE, FUNNEL_ANALYSIS.EXPERIMENT_ID), experiment.getExperimentId(), QueryConstants.EQUAL);
						updateRow(FunnelAnalysisConstants.FUNNEL_ANALYSIS_TABLE, FUNNEL_ANALYSIS.TABLE, hs, c, ZABAction.getMessage(ExperimentConstants.API_RESOURCE));
					}
					if(!alreadyInTransaction) {				
						mgr.commit();
					}
					funnelAnalysis.setSuccess(true);
					triggerEvent = true;
					
				} else {
					try {
						if(!alreadyInTransaction) {
							mgr.rollback();
						}
					} catch (Exception e1) {
						LOGGER.log(Level.SEVERE,"Exception Occurred",e1);
					}
					funnelAnalysis = new FunnelAnalysis();
					funnelAnalysis.setSuccess(Boolean.FALSE);
					funnelAnalysis.setResponseString(experiment!=null?experiment.getResponseString():ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
					triggerEvent = false;
				}
			}
			
			if(triggerEvent) {
				//TODO: Event activity
				
				//Trigger event 
				ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
				wrapper.setChangeSets(hs);
				wrapper.setModel(funnelAnalysis);
				wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
				wrapper.setType(OperationType.UPDATE);
				Long zsoid;
				ServiceOrg currentServiceOrg = IAMUtil.getCurrentServiceOrg();
				if(currentServiceOrg != null)
				{
					zsoid = currentServiceOrg.getZSOID();
					wrapper.setZsoid(zsoid.toString());
				}
				else if(ZABUtil.getDBSpace() != null)
				{
					wrapper.setZsoid(ZABUtil.getDBSpace());
				}
				ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);
			}
			
		} catch(ResourceNotFoundException | ZABException e) {
			try {
				if(!alreadyInTransaction) {
					mgr.rollback();
				}
			} catch (Exception e1) {
				LOGGER.log(Level.SEVERE,"Exception Occurred",e1);
			}
			funnelAnalysis = new FunnelAnalysis();
			funnelAnalysis.setSuccess(Boolean.FALSE);
			funnelAnalysis.setResponseString(e.getMessage());
			if(e instanceof ResourceNotFoundException) {				
				funnelAnalysis.setResponseCode(((ResourceNotFoundException) e).getErrorCode());
			}
		} catch(Exception e) {
			try {
				if(!alreadyInTransaction) {
					mgr.rollback();
				}
			} catch (Exception e1) {
				LOGGER.log(Level.SEVERE,"Exception Occurred",e1);
			}
			funnelAnalysis = new FunnelAnalysis();
			funnelAnalysis.setSuccess(Boolean.FALSE);
			funnelAnalysis.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
		}
		
		 return funnelAnalysis;
		
	}
	
	
	public static FunnelAnalysis duplicateExperiment(String linkname) {

		FunnelAnalysis funnelAnalysis = null;
		TransactionManager mgr = DataAccess.getTransactionManager();
		try {		
			Criteria c = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_LINK_NAME), linkname, QueryConstants.EQUAL);
			DataObject dobj = getPersonality(ExperimentConstants.EXPERIMENT_DETAIL_PERSONALITY, c);
			if(dobj.containsTable(EXPERIMENT.TABLE)) {
				
				mgr.begin();
				
				Experiment experiment = Experiment.duplicateExperiment(dobj);
				
				if(experiment != null && experiment.getExperimentId() != null)
				{
					Row funnelRow = dobj.getRow(FUNNEL_ANALYSIS.TABLE);
					funnelAnalysis = new FunnelAnalysis(experiment);
					
					Row dfrow = new Row(FUNNEL_ANALYSIS.TABLE);
					dfrow.set(FUNNEL_ANALYSIS.EXPERIMENT_ID, experiment.getExperimentId());
					dfrow.set(FUNNEL_ANALYSIS.SESSION_TIME, (Long)funnelRow.get(FUNNEL_ANALYSIS.SESSION_TIME));
					createResource(dfrow);
					
					Iterator stepsIterator = dobj.getRows(FUNNEL_STEPS.TABLE);
					ArrayList<Row> fsRows = new ArrayList<Row>();
					while(stepsIterator.hasNext()) {
						Row vrow = (Row)stepsIterator.next();
						fsRows.add(vrow);
					}
					
					//Sorting the row for preserving order
					
					Comparator<Row> comparator = (Row o1, Row o2) -> (Integer)o1.get(FUNNEL_STEPS.STEP_ORDER) > (Integer)o2.get(FUNNEL_STEPS.STEP_ORDER)?1:-1;
					
					Collections.sort(fsRows, comparator);

					int vrsize = fsRows.size();
					for(int k=0; k<vrsize; k++) {
						Row vrow = fsRows.get(k);
						FunnelStep.duplicateRow(vrow, experiment.getExperimentId(), dobj);
					}
					
					funnelAnalysis.setStepCount(vrsize);
					funnelAnalysis.setSuccess(Boolean.TRUE);
					
				}
				//Done have to trigger event to update javascript here as the status of this experiment will be in draft

				mgr.commit();
				
			} else {
				funnelAnalysis = new FunnelAnalysis();
				funnelAnalysis.setSuccess(Boolean.FALSE);
				funnelAnalysis.setResponseString(ZABAction.getMessage(ZABConstants.ErrorMessages.RESOURCE_NOT_FOUND.getErrorString(),new String[]{ExperimentConstants.API_MODULE}));
				return funnelAnalysis;
			}
			
			ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
			ServiceOrg currentServiceOrg = IAMUtil.getCurrentServiceOrg();
			if(currentServiceOrg != null)
			{
				wrapper.setZsoid(currentServiceOrg.getZSOID()+"");
			}
			wrapper.setModel(funnelAnalysis);
			wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
			wrapper.setType(OperationType.CREATE);
			ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);
		} catch (Exception e) {
			try
			{
				mgr.rollback();
			}
			catch(Exception e1)
			{
				LOGGER.log(Level.SEVERE,"Exception Occurred",e1);
			}
			LOGGER.log(Level.SEVERE,"Exception Occurred",e);
			funnelAnalysis = new FunnelAnalysis();
			funnelAnalysis.setSuccess(Boolean.FALSE);
			funnelAnalysis.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
		}

		return funnelAnalysis;
	
	}
	
}
