//$Id$
package com.zoho.abtest.funnel;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.transaction.TransactionManager;

import org.json.JSONArray;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.DataSet;
import com.adventnet.ds.query.GroupByClause;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.Operation;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.ds.query.SelectQueryImpl;
import com.adventnet.ds.query.SortColumn;
import com.adventnet.ds.query.Table;
import com.adventnet.ds.query.UpdateQuery;
import com.adventnet.ds.query.UpdateQueryImpl;
import com.adventnet.mfw.bean.BeanUtil;
import com.adventnet.persistence.DataAccess;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.EVENTS;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.FUNNEL_STEPS;
import com.zoho.abtest.FUNNEL_STEP_EVENTS;
import com.zoho.abtest.PROJECT;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABColumn;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.customevent.CustomEvent;
import com.zoho.abtest.customevent.CustomEventConstants;
import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.funnel.FunnelAnalysisConstants.FunnelMatchType;
import com.zoho.abtest.utility.ZABUserBean;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.logs.apache.commons.lang3.StringEscapeUtils;

public class FunnelStep extends ZABModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final Logger LOGGER = Logger.getLogger(FunnelStep.class.getName());
	
	@ZABColumn(name=FUNNEL_STEPS.STEP_NAME)
	private String displayName;
	
	@ZABColumn(name=FUNNEL_STEPS.EXPERIMENT_ID)
	private Long experimentId;
	
	@ZABColumn(name=FUNNEL_STEPS.STEP_LINKNAME)
	private String linkname;
	
	@ZABColumn(name=FUNNEL_STEPS.STEP_ORDER)
	private Integer stepOrder;
	
	@ZABColumn(name=FUNNEL_STEPS.STEP_KEY)
	private String stepKey;
	
	@ZABColumn(name=FUNNEL_STEPS.STEP_LINKNAME)
	private String stepLinkname;
	
	@ZABColumn(name=FUNNEL_STEPS.STEP_ID)
	private Long stepId;
	
//	@ZABColumn(name=FUNNEL_STEPS.STEP_URLS)
//	private JSONArray stepUrls;
	
	@ZABColumn(name=FUNNEL_STEPS.STEP_MATCH_TYPE)
	private Integer stepMatchType;
	
	@ZABColumn(name=FUNNEL_STEPS.STEP_VALUE)
	private String stepValue;
	
	private String experimentLinkname;
	
	private String customEventLinkname;

	public String getCustomEventLinkname() {
		return customEventLinkname;
	}

	public void setCustomEventLinkname(String customEventLinkname) {
		this.customEventLinkname = customEventLinkname;
	}

	public Integer getStepMatchType() {
		return stepMatchType;
	}

	public void setStepMatchType(Integer stepMatchType) {
		this.stepMatchType = stepMatchType;
	}

	public String getStepValue() {
		return stepValue;
	}

	public void setStepValue(String stepValue) {
		this.stepValue = stepValue;
	}

	public String getStepLinkname() {
		return stepLinkname;
	}

	public void setStepLinkname(String stepLinkname) {
		this.stepLinkname = stepLinkname;
	}

	public String getExperimentLinkname() {
		return experimentLinkname;
	}

	public void setExperimentLinkname(String experimentLinkname) {
		this.experimentLinkname = experimentLinkname;
	}

//	public JSONArray getStepUrls() {
//		return stepUrls;
//	}
//
//	public void setStepUrls(JSONArray stepUrls) {
//		this.stepUrls = stepUrls;
//	}

	public Long getStepId() {
		return stepId;
	}

	public void setStepId(Long stepId) {
		this.stepId = stepId;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public Long getExperimentId() {
		return experimentId;
	}

	public void setExperimentId(Long experimentId) {
		this.experimentId = experimentId;
	}

	public String getLinkname() {
		return linkname;
	}

	public void setLinkname(String linkname) {
		this.linkname = linkname;
	}

	public Integer getStepOrder() {
		return stepOrder;
	}

	public void setStepOrder(Integer stepOrder) {
		this.stepOrder = stepOrder;
	}

	public String getStepKey() {
		return stepKey;
	}

	public void setStepKey(String stepKey) {
		this.stepKey = stepKey;
	}
	
	public static Long getStepIdForLinkname(String linkname) throws Exception {
		Long id = null;
		Criteria c = new Criteria(new Column(FUNNEL_STEPS.TABLE, FUNNEL_STEPS.STEP_LINKNAME), linkname, QueryConstants.EQUAL);
		DataObject dobj = getRow(FUNNEL_STEPS.TABLE, c);
		if(dobj.containsTable(FUNNEL_STEPS.TABLE)) {
			id = (Long)dobj.getFirstRow(FUNNEL_STEPS.TABLE).get(FUNNEL_STEPS.STEP_ID);
		}
		return id;
	}
	
	public static ArrayList<FunnelStep> getFunnelByCriteria(Criteria c) {
		return getFunnelByCriteria(c, null);
	}
	
	public static ArrayList<FunnelStep> getFunnelByCriteria(Criteria c, SortColumn sort) {
		ArrayList<FunnelStep> funnelSteps = new ArrayList<FunnelStep>();
		try {			
			Join join1=new Join(FUNNEL_STEPS.TABLE,FUNNEL_STEP_EVENTS.TABLE,new String[]{FUNNEL_STEPS.STEP_ID},new String[]{FUNNEL_STEP_EVENTS.STEP_ID},Join.LEFT_JOIN);
			Join join2=new Join(FUNNEL_STEP_EVENTS.TABLE,EVENTS.TABLE,new String[]{FUNNEL_STEP_EVENTS.EVENT_ID},new String[]{EVENTS.EVENT_ID},Join.LEFT_JOIN);
			DataObject dobj = getRow(FUNNEL_STEPS.TABLE, c, sort, new Join[]{join1, join2});
			Iterator it = dobj.getRows(FUNNEL_STEPS.TABLE);
			funnelSteps = getModelsFromDobj(dobj, FUNNEL_STEPS.TABLE, FunnelStep.class, true, (DataObject dobj1, Row row, ZABModel model) -> {
				FunnelStep step = (FunnelStep)model;
				if(step.getStepMatchType().equals(FunnelMatchType.URLLESS.getMatchTypeId())) {
					Long stepId = step.getStepId();
					Criteria c1 = new Criteria(new Column(FUNNEL_STEP_EVENTS.TABLE, FUNNEL_STEP_EVENTS.STEP_ID), stepId, QueryConstants.EQUAL);
					 try {
						Row fse = dobj1.getRow(FUNNEL_STEP_EVENTS.TABLE, c1);
						Long eventId = (Long)fse.get(FUNNEL_STEP_EVENTS.EVENT_ID);
						Criteria c2 = new Criteria(new Column(EVENTS.TABLE, EVENTS.EVENT_ID), eventId, QueryConstants.EQUAL);
						Row er = dobj1.getRow(EVENTS.TABLE, c2);
						
						step.setCustomEventLinkname((String) er.get(EVENTS.EVENT_LINKNAME));
						
					} catch (Exception e) {
						e.printStackTrace();
					}
					
				}
				
				
			});
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Exception occured:", e);
			FunnelStep funnelStep = new FunnelStep();
			funnelStep.setSuccess(Boolean.FALSE);
			funnelStep.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			funnelSteps.add(funnelStep);
		}
		return funnelSteps;
	}
	
	public static FunnelStep getFunnelStepByKey(String key) {
		FunnelStep funnelStep = null;
		Criteria c = new Criteria(new Column(FUNNEL_STEPS.TABLE, FUNNEL_STEPS.STEP_KEY), key, QueryConstants.EQUAL);
		ArrayList<FunnelStep> funnelSteps = getFunnelByCriteria(c);
		if(funnelSteps.size() > 0 && funnelSteps.get(0).getSuccess()) {
			funnelStep = funnelSteps.get(0);
		}
		return funnelStep;
	}
	
	public static ArrayList<FunnelStep> getFunnelStepForExperiment(Long experimentId) {
		Criteria c = new Criteria(new Column(FUNNEL_STEPS.TABLE, FUNNEL_STEPS.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
		return getFunnelByCriteria(c);
	}
	
	public static ArrayList<FunnelStep> getFunnelStepForExperiment(String experimentLinkname) {
		Long experimentId = Experiment.getExperimentId(experimentLinkname);
		if(experimentId == null) {
			FunnelStep step = new FunnelStep();
			step.setSuccess(Boolean.FALSE);
			step.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_WITHLNAME_NOTEXISTS, new String[] {ZABAction.getMessage(ExperimentConstants.API_RESOURCE_INITIAL), experimentLinkname}));
			return new ArrayList<FunnelStep>(Arrays.asList(step));
		}
		return getFunnelStepForExperiment(experimentId);
	}
	
	private static void adjustStepOrderOnDeletion(String stepLinkname) throws Exception {
		Criteria c = new Criteria(new Column(FUNNEL_STEPS.TABLE, FUNNEL_STEPS.STEP_LINKNAME), stepLinkname, QueryConstants.EQUAL);
		DataObject dobj = getRow(FUNNEL_STEPS.TABLE, c);
		if(dobj.containsTable(FUNNEL_STEPS.TABLE)) {
			Row row = dobj.getFirstRow(FUNNEL_STEPS.TABLE);
			Integer stepOrder = (Integer) row.get(FUNNEL_STEPS.STEP_ORDER);
			UpdateQuery uq = new UpdateQueryImpl(FUNNEL_STEPS.TABLE);
			Criteria c1 = new Criteria(new Column(FUNNEL_STEPS.TABLE, FUNNEL_STEPS.STEP_ORDER), stepOrder, QueryConstants.GREATER_THAN);
			Column decrementStepOrder = Column.createOperation(Operation.operationType.SUBTRACT, new Column(FUNNEL_STEPS.TABLE, FUNNEL_STEPS.STEP_ORDER), 1);
			uq.setCriteria(c1);
			uq.setUpdateColumn(FUNNEL_STEPS.STEP_ORDER, decrementStepOrder);
			updateResource(uq);
		} else {
			throw new ZABException(ZABAction.getMessage(ZABConstants.RESOURCE_WITHLNAME_NOTEXISTS,new String[]{FunnelAnalysisConstants.STEP_API_RESOURCE_NAME_INITIAL, stepLinkname}));
		}
	}
	
	public static Integer getStepCount(Long experimentId) throws Exception {
		final ArrayList<Integer> countBuffer = new ArrayList<Integer>();
		Criteria c = new Criteria(new Column(FUNNEL_STEPS.TABLE, FUNNEL_STEPS.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
		GroupByClause gc = new GroupByClause(Arrays.asList(new Column(FUNNEL_STEPS.TABLE, FUNNEL_STEPS.EXPERIMENT_ID)));
		SelectQuery selectQuery = new SelectQueryImpl(new Table(FUNNEL_STEPS.TABLE));
		Column count = new Column(FUNNEL_STEPS.TABLE, FUNNEL_STEPS.STEP_ID).count();
		selectQuery.addSelectColumn(count);
		selectQuery.setCriteria(c);
		selectQuery.setGroupByClause(gc);
		count.setColumnAlias("STEP_COUNT");
		ZABUserBean bean= (ZABUserBean)BeanUtil.lookup(ZABUserBean.BEAN_NAME, ZABUtil.getCurrentUserDbSpace());
		
		bean.executeQuery(selectQuery, (DataSet ds) -> {
				if(ds.next()) {
					Integer scount = (Integer) ds.getValue("STEP_COUNT"); //NO I18N
					countBuffer.add(scount);
				}
		});
		return countBuffer.size() > 0?countBuffer.get(0):0;
	}
	
	public static Integer getStepCount(String linkname) throws Exception {
		Long experimentId = Experiment.getExperimentId(linkname);
		if(experimentId==null) {
			throw new ZABException(ZABAction.getMessage(
									ZABConstants.RESOURCE_WITHLNAME_NOTEXISTS,
									new String[] {ZABAction.getMessage(ExperimentConstants.API_RESOURCE_INITIAL),linkname }));
		}
		return getStepCount(experimentId);
	}
	
	public static FunnelStep createFunnelStep(HashMap<String, String> hs) {
		FunnelStep funnelStep = null;
		try {
			Long experimentId = null;
			Experiment exp = null;
			if(hs.containsKey(FunnelAnalysisConstants.EXPERIMENT_ID)) {
				experimentId = Long.parseLong(hs.get(FunnelAnalysisConstants.EXPERIMENT_ID));
				exp = Experiment.getExperimentById(experimentId);
				experimentId = exp == null ?null:exp.getExperimentId();
			} else if(hs.containsKey(FunnelAnalysisConstants.EXPERIMENT_LINKNAME)) {
				String linkname = hs.get(FunnelAnalysisConstants.EXPERIMENT_LINKNAME);
				exp = Experiment.getExperimentByLinkname(linkname);
				experimentId = exp == null ?null:exp.getExperimentId();
			}
			if(experimentId == null) {
				throw new ZABException(ZABAction.getMessage(ExperimentConstants.EXPERIMENT_NOT_EXISTS));
			}
			String linkname = generateLinkName(FUNNEL_STEPS.TABLE, FUNNEL_STEPS.STEP_LINKNAME, null, null, hs.get(FunnelAnalysisConstants.DISPLAY_NAME));
			String key = generateUniqueId(FUNNEL_STEPS.TABLE, FUNNEL_STEPS.STEP_KEY);
			Integer stepCount = getStepCount(experimentId);
			
			hs.put(FunnelAnalysisConstants.STEP_ORDER, (stepCount + 1) +"");
			hs.put(ZABConstants.LINKNAME, linkname);
			hs.put(FunnelAnalysisConstants.EXPERIMENT_ID, experimentId+"");
			hs.put(FunnelAnalysisConstants.STEP_KEY, key);
			if(!hs.containsKey(FunnelAnalysisConstants.MATCH_TYPE)) {
				hs.put(FunnelAnalysisConstants.MATCH_TYPE, FunnelAnalysisConstants.FunnelMatchType.SIMPLE_MATCH
						.getMatchTypeId()+"");
			}
			
			if(hs.get(FunnelAnalysisConstants.VALUE)!=null && !hs.get(FunnelAnalysisConstants.VALUE).trim().isEmpty()) {
				hs.put(FunnelAnalysisConstants.VALUE, StringEscapeUtils.unescapeJava(hs.get(FunnelAnalysisConstants.VALUE)));
			}
			
			DataObject dobj = createRow(FunnelAnalysisConstants.FUNNEL_STEPS_TABLE, FUNNEL_STEPS.TABLE, hs);
			funnelStep = getFirstModelFromDobj(dobj, FUNNEL_STEPS.TABLE, FunnelStep.class);
			
			Integer stepMatchType = Integer.parseInt(hs.get(FunnelAnalysisConstants.MATCH_TYPE));
			FunnelMatchType matchType = FunnelMatchType.getMatchTypeById(stepMatchType);
			if(matchType.equals(FunnelMatchType.URLLESS)) {
				
				Long customEventId = null;
				
				if(hs.containsKey(FunnelAnalysisConstants.CUSTOM_EVENT_ID)) {
					try {
						customEventId = Long.parseLong(hs.get(FunnelAnalysisConstants.CUSTOM_EVENT_ID));
					} catch (Exception e) {
						LOGGER.log(Level.SEVERE, "Exception occured:", e);
					}
				}
				
				String customEventLinkname = hs.get(FunnelAnalysisConstants.CUSTOM_EVENT_LN);
				if(customEventId == null && customEventLinkname!=null) {					
					CustomEvent ce = CustomEvent.getCustomEventByLinkname(customEventLinkname, exp.getProjectId());
					if(ce == null) {
//						throw new ZABException(ZABAction.getMessage(ZABConstants.ErrorMessages.RESOURCE_NOT_FOUND.getErrorString(), new String[]{ZABAction.getMessage(CustomEventConstants.API_MODULE)}));
						HashMap<String, String> customEventMap = new HashMap<String, String>();
						customEventMap.put(CustomEventConstants.PROJECT_ID, exp.getProjectId().toString());
						customEventMap.put(CustomEventConstants.EVENT_NAME, customEventLinkname);
						ce = CustomEvent.createCustomEvent(customEventMap);
					}
					customEventId = ce.getCustomEventId();
					funnelStep.setCustomEventLinkname(ce.getCustomEventLinkName());
				}
				
				
				Row row = new Row(FUNNEL_STEP_EVENTS.TABLE);
				row.set(FUNNEL_STEP_EVENTS.EVENT_ID, customEventId);
				row.set(FUNNEL_STEP_EVENTS.STEP_ID, funnelStep.getStepId());
				ZABModel.createResource(row);
				
			}
			
			funnelStep.setSuccess(Boolean.TRUE);
			//TODO: Event activity log
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Exception occured:", e);
			funnelStep = new FunnelStep();
			funnelStep.setSuccess(Boolean.FALSE);
			funnelStep.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
		}
		return funnelStep;
	}
	
	public static FunnelStep deleteFunnelStep(String linkname) {
		FunnelStep funnelStep = null;
		TransactionManager mgr = DataAccess.getTransactionManager();
		try {	
			mgr.begin();
			Criteria c = new Criteria(new Column(FUNNEL_STEPS.TABLE, FUNNEL_STEPS.STEP_LINKNAME), linkname, QueryConstants.EQUAL);
			adjustStepOrderOnDeletion(linkname);
			deleteResource(c);
			funnelStep = new FunnelStep();
			funnelStep.setLinkname(linkname);
			funnelStep.setSuccess(Boolean.TRUE);
			mgr.commit();
		} catch(ZABException e) {
			try {
				mgr.rollback();
			} catch (Exception e1) {
				LOGGER.log(Level.SEVERE,"Exception Occurred",e1);
			}
			funnelStep = new FunnelStep();
			funnelStep.setLinkname(linkname);
			funnelStep.setSuccess(Boolean.FALSE);
			funnelStep.setResponseString(e.getMessage());
		} catch (Exception e) {
			try {
				mgr.rollback();
			} catch (Exception e1) {
				LOGGER.log(Level.SEVERE,"Exception Occurred",e1);
			}
			funnelStep = new FunnelStep();
			funnelStep.setSuccess(Boolean.FALSE);
			funnelStep.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
		}
		return funnelStep;
	}
	
	public static FunnelStep upsertFunnelStep(HashMap<String, String> hs) {
		FunnelStep funnelStep = null;
		try {
			if(hs.containsKey(ZABConstants.LINKNAME)) {
				funnelStep = updateFunnelStep(hs);
			} else {
				funnelStep = createFunnelStep(hs);
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Exception occured:", e);
			funnelStep = new FunnelStep();
			funnelStep.setSuccess(Boolean.FALSE);
			funnelStep.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
		}
		return funnelStep;
	}
	
	public static FunnelStep duplicateRow(Row row, Long experimentId, DataObject dobj) throws Exception {
		HashMap<String, String> hs = new HashMap<String, String>();
		hs.put(FunnelAnalysisConstants.EXPERIMENT_ID, experimentId+"");
		if(row.get(FUNNEL_STEPS.STEP_MATCH_TYPE)!=null) {			
			Integer matchType = (Integer)row.get(FUNNEL_STEPS.STEP_MATCH_TYPE);
			hs.put(FunnelAnalysisConstants.MATCH_TYPE, matchType+"");
			if(matchType.equals(FunnelMatchType.URLLESS.getMatchTypeId())) {			
				Long oldStepId = (Long)row.get(FUNNEL_STEPS.STEP_ID);
				Criteria c = new Criteria(new Column(FUNNEL_STEP_EVENTS.TABLE, FUNNEL_STEP_EVENTS.STEP_ID), oldStepId, QueryConstants.EQUAL);
				Row stepRow = dobj.getRow(FUNNEL_STEP_EVENTS.TABLE, c);
				Long eventId = (Long) stepRow.get(FUNNEL_STEP_EVENTS.EVENT_ID);
				hs.put(FunnelAnalysisConstants.CUSTOM_EVENT_ID, eventId+"");
			}
		}
		hs.put(FunnelAnalysisConstants.DISPLAY_NAME, (String)row.get(FUNNEL_STEPS.STEP_NAME));
		hs.put(FunnelAnalysisConstants.VALUE, (String)row.get(FUNNEL_STEPS.STEP_VALUE));
		if(row.get(FUNNEL_STEPS.STEP_ORDER)!=null) {			
			hs.put(FunnelAnalysisConstants.STEP_ORDER, (Integer)row.get(FUNNEL_STEPS.STEP_ORDER)+"");
		}
		
		FunnelStep dupstep = createFunnelStep(hs);
		
		return dupstep;
	}
	
	public static void deleteOthers(long[] stepIds, Long experimentId) throws Exception {
		Criteria c1 = new Criteria(new Column(FUNNEL_STEPS.TABLE, FUNNEL_STEPS.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
		Criteria c2 = new Criteria(new Column(FUNNEL_STEPS.TABLE, FUNNEL_STEPS.STEP_ID), stepIds, QueryConstants.NOT_IN);
		deleteResource(c1.and(c2));
	}
	
	public void setValuesFromHashMap(HashMap<String, String> hs) {
		if(hs.containsKey(FunnelAnalysisConstants.STEP_KEY)){ this.setStepKey(hs.get(FunnelAnalysisConstants.STEP_KEY)); }
		if(hs.containsKey(FunnelAnalysisConstants.STEP_ORDER)){ this.setStepOrder(Integer.parseInt(hs.get(FunnelAnalysisConstants.STEP_ORDER))); }
		if(hs.containsKey(FunnelAnalysisConstants.EXPERIMENT_LINKNAME)){ this.setExperimentLinkname(hs.get(FunnelAnalysisConstants.EXPERIMENT_LINKNAME)); }
		if(hs.containsKey(ZABConstants.LINKNAME)){ this.setLinkname(hs.get(ZABConstants.LINKNAME)); }
		if(hs.containsKey(FunnelAnalysisConstants.MATCH_TYPE)){ this.setStepMatchType(Integer.parseInt(hs.get(FunnelAnalysisConstants.MATCH_TYPE))); }
		if(hs.containsKey(FunnelAnalysisConstants.VALUE)){ this.setStepValue(hs.get(FunnelAnalysisConstants.VALUE)); }
	}
	
	public static FunnelStep updateFunnelStep(HashMap<String, String> hs) {
		FunnelStep funnelStep = null;
		try {
			String linkname = hs.get(ZABConstants.LINKNAME);
			
			Criteria c = new Criteria(new Column(FUNNEL_STEPS.TABLE, FUNNEL_STEPS.STEP_LINKNAME), linkname, QueryConstants.EQUAL);
			
			ArrayList<FunnelStep> funnelSteps = getFunnelByCriteria(c);
			FunnelStep oldFunnelStep = null;
			if(!funnelSteps.isEmpty() && funnelSteps.get(0).getSuccess()) {
				oldFunnelStep = funnelSteps.get(0);
			} else {
				throw new ZABException(ZABAction.getMessage(ZABConstants.ErrorMessages.RESOURCE_NOT_FOUND.getErrorString(), new String[]{ZABAction.getMessage(FunnelAnalysisConstants.STEP_API_RESOURCE_NAME_INITIAL)}));
			}
			
			funnelStep = new FunnelStep();
			updateRow(FunnelAnalysisConstants.FUNNEL_STEPS_TABLE, FUNNEL_STEPS.TABLE, hs, c, FunnelAnalysisConstants.STEP_API_RESOURCE_NAME_INITIAL);
			
			funnelStep.setValuesFromHashMap(hs);
			
			Integer nmt = null;
			if(hs.containsKey(FunnelAnalysisConstants.MATCH_TYPE)) {
				nmt = Integer.parseInt(hs.get(FunnelAnalysisConstants.MATCH_TYPE));
				if(!nmt.equals(oldFunnelStep.getStepMatchType()) 
						&& oldFunnelStep.getStepMatchType().equals(FunnelMatchType.URLLESS.getMatchTypeId())) {
					Criteria c1 = new Criteria(new Column(FUNNEL_STEP_EVENTS.TABLE, FUNNEL_STEP_EVENTS.STEP_ID), oldFunnelStep.getStepId(), QueryConstants.EQUAL);
					deleteResource(c1);
				}
			}
			
			Integer stepMatchType = nmt != null ? nmt:oldFunnelStep.getStepMatchType();
			FunnelMatchType matchType = FunnelMatchType.getMatchTypeById(stepMatchType);
			
			
			if(matchType.equals(FunnelMatchType.URLLESS) && hs.containsKey(FunnelAnalysisConstants.CUSTOM_EVENT_LN)) {
				String customEventLinkname = hs.get(FunnelAnalysisConstants.CUSTOM_EVENT_LN);
				CustomEvent ce = CustomEvent.getCustomEventByLinkname(
						customEventLinkname, Experiment
								.getProjectIdByExperimentId(oldFunnelStep
										.getExperimentId()));
				if(ce == null) {
					throw new ZABException(ZABAction.getMessage(ZABConstants.ErrorMessages.RESOURCE_NOT_FOUND.getErrorString(), new String[]{ZABAction.getMessage(CustomEventConstants.API_MODULE)}));
				}
				
				Long customEventId = ce.getCustomEventId();
				
				Criteria c1 = new Criteria(new Column(FUNNEL_STEP_EVENTS.TABLE, FUNNEL_STEP_EVENTS.STEP_ID), oldFunnelStep.getStepId(), QueryConstants.EQUAL);
				
				DataObject dobj = getRow(FUNNEL_STEP_EVENTS.TABLE, c1);
				if(dobj.containsTable(FUNNEL_STEP_EVENTS.TABLE)) {
					Row oldRow = dobj.getFirstRow(FUNNEL_STEP_EVENTS.TABLE);
					Long eventId = (Long)oldRow.get(FUNNEL_STEP_EVENTS.EVENT_ID);
					
					if(!eventId.equals(ce.getCustomEventId())) {
						oldRow.set(FUNNEL_STEP_EVENTS.EVENT_ID, ce.getCustomEventId());
						dobj.updateRow(oldRow);
						updateDataObject(dobj);
					}
					
				} else {					
					Row row = new Row(FUNNEL_STEP_EVENTS.TABLE);
					row.set(FUNNEL_STEP_EVENTS.EVENT_ID, customEventId);
					row.set(FUNNEL_STEP_EVENTS.STEP_ID, oldFunnelStep.getStepId());
					ZABModel.createResource(row);
				}
				
				
				
				funnelStep.setCustomEventLinkname(ce.getCustomEventLinkName());
			}
			
			
			funnelStep.setSuccess(Boolean.TRUE);
			funnelStep.setLinkname(linkname);
			//TODO: Event activity log
		} catch (ZABException e) {
			LOGGER.log(Level.SEVERE, "Exception occured:", e);
			funnelStep = new FunnelStep();
			funnelStep.setSuccess(Boolean.FALSE);
			funnelStep.setResponseString(e.getMessage());
		}
		catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Exception occured:", e);
			funnelStep = new FunnelStep();
			funnelStep.setSuccess(Boolean.FALSE);
			funnelStep.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
		}
		return funnelStep;
	}
	
	public static Long getProjectIdForStep(String linkname) {
		Long projectId = null;
		try {			
			Criteria c = new Criteria(new Column(FUNNEL_STEPS.TABLE, FUNNEL_STEPS.STEP_LINKNAME), linkname, QueryConstants.EQUAL);
			Join join1=new Join(FUNNEL_STEPS.TABLE,EXPERIMENT.TABLE,new String[]{FUNNEL_STEPS.EXPERIMENT_ID},new String[]{EXPERIMENT.EXPERIMENT_ID},Join.INNER_JOIN);
			Join join2=new Join(EXPERIMENT.TABLE,PROJECT.TABLE,new String[]{EXPERIMENT.PROJECT_ID},new String[]{PROJECT.PROJECT_ID},Join.INNER_JOIN);
			DataObject dobj = getRow(FUNNEL_STEPS.TABLE, c, new Join[] {join1, join2});
			if(dobj.containsTable(PROJECT.TABLE)) {
				projectId = (Long) dobj.getFirstRow(PROJECT.TABLE).get(PROJECT.PROJECT_ID);
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Exception occured:", e);
		}
		return projectId;
	}
	
	public static JSONArray getPathAsJSONArray(ArrayList<Long> ids) {
		JSONArray paths = new JSONArray();
		ids.forEach(id -> paths.put(id));
		return paths;
	}
	
	public static ArrayList<Long> formStepIdPath(String stepLinkname) throws Exception {
		Criteria c = new Criteria(new Column(FUNNEL_STEPS.TABLE, FUNNEL_STEPS.STEP_LINKNAME), stepLinkname, QueryConstants.EQUAL);
		DataObject dobj = getRow(FUNNEL_STEPS.TABLE, c);
		Row row = dobj.getFirstRow(FUNNEL_STEPS.TABLE);
		if(row != null) {
			Integer order = (Integer) row.get(FUNNEL_STEPS.STEP_ORDER);
			Long experimentId = (Long) row.get(FUNNEL_STEPS.EXPERIMENT_ID);
			Long stepId = (Long) row.get(FUNNEL_STEPS.STEP_ID);
			Criteria c1 = new Criteria(new Column(FUNNEL_STEPS.TABLE, FUNNEL_STEPS.STEP_ORDER), order, QueryConstants.LESS_THAN);
			Criteria c2 = new Criteria(new Column(FUNNEL_STEPS.TABLE, FUNNEL_STEPS.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
			SortColumn sort = new SortColumn(new Column(FUNNEL_STEPS.TABLE, FUNNEL_STEPS.STEP_ORDER), Boolean.TRUE);
			DataObject dobj1 = getRow(FUNNEL_STEPS.TABLE, c1.and(c2), sort, null);
			if(dobj1.containsTable(FUNNEL_STEPS.TABLE)) {
				ArrayList<Long> array = new ArrayList<Long>();
				Iterator it = dobj1.getRows(FUNNEL_STEPS.TABLE);
				while(it.hasNext()) {
					Row row1 = (Row)it.next();
					Long descendentStepId = (Long) row1.get(FUNNEL_STEPS.STEP_ID);
					array.add(descendentStepId);
				}
				array.add(stepId);
				return array;
			}
		}
		return null;
	}
	
}
