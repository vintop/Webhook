//$Id$
package com.zoho.abtest.funnel;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;

import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABRequest;
import com.zoho.abtest.funnel.FunnelAnalysisConstants.FunnelMatchType;
import com.zoho.abtest.goal.GoalConstants;

public class FunnelStepRequest extends ZABRequest{

	@Override
	public void updateFromRequest(HashMap<String, String> map,
			HttpServletRequest request) {
		String experimentLinkname = request.getParameter(FunnelAnalysisConstants.EXPERIMENT_LINKNAME);
		if(experimentLinkname!=null) {
			map.put(FunnelAnalysisConstants.EXPERIMENT_LINKNAME, experimentLinkname);
		}
		
		String linkname = (String) request.getAttribute(ZABConstants.LINKNAME);
		if(linkname!=null) {
			map.put(ZABConstants.LINKNAME, linkname);
		}
	}
	
	public static void validate(HashMap<String, String> map, String httpMethod) {
		if(httpMethod.equals("GET")) {
			if(isNullOrEmpty(map, FunnelAnalysisConstants.EXPERIMENT_LINKNAME)) {
				ZABRequest.updateError(map, ZABAction.getAppropriateMessage(ZABConstants.ErrorMessages.MANDATORY_FIELD_MISSING.getErrorString(), new ArrayList<String>(Arrays.asList(FunnelAnalysisConstants.EXPERIMENT_LINKNAME))));
				return;
			}
		}
		
		if(httpMethod.equals("POST")) {	
			ArrayList<String> fields = new ArrayList<String>();
			if(!map.containsKey(FunnelAnalysisConstants.DISPLAY_NAME) || map.get(FunnelAnalysisConstants.DISPLAY_NAME).isEmpty()) {
				fields.add(FunnelAnalysisConstants.DISPLAY_NAME);
			}
			
			if(!map.containsKey(FunnelAnalysisConstants.EXPERIMENT_LINKNAME) || map.get(FunnelAnalysisConstants.EXPERIMENT_LINKNAME).isEmpty()) {
				fields.add(FunnelAnalysisConstants.EXPERIMENT_LINKNAME);
			}
			
//			if(!map.containsKey(FunnelAnalysisConstants.STEP_ORDER) || map.get(FunnelAnalysisConstants.STEP_ORDER).isEmpty()) {
//				fields.add(FunnelAnalysisConstants.STEP_ORDER);
//			}
			
			boolean checkForValue = true;
			if(isNullOrEmpty(map, FunnelAnalysisConstants.MATCH_TYPE)) {
				fields.add(FunnelAnalysisConstants.MATCH_TYPE);
			} else {
				try {
					Integer matchType = Integer.parseInt(map.get(FunnelAnalysisConstants.MATCH_TYPE));
					FunnelMatchType funnelMatchType = FunnelMatchType.getMatchTypeById(matchType);
					if(funnelMatchType == null) {
						ZABRequest.updateError(map, ZABAction.getMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{GoalConstants.GOAL_TYPE}));
						return;
					}
					
					if(funnelMatchType.equals(FunnelMatchType.URLLESS)) {
						checkForValue = false;
						if(isNullOrEmpty(map, FunnelAnalysisConstants.CUSTOM_EVENT_LN)) {
							fields.add(FunnelAnalysisConstants.CUSTOM_EVENT_LN);
						}
					}
					
				} catch (NumberFormatException e) {
					ZABRequest.updateError(map, ZABAction.getMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{GoalConstants.GOAL_TYPE}));
					return;
				}
			}
			
			if(isNullOrEmpty(map, FunnelAnalysisConstants.VALUE) && checkForValue) {
				fields.add(FunnelAnalysisConstants.VALUE);
			}
			
//			if(!map.containsKey(FunnelAnalysisConstants.STEP_URLS) || map.get(FunnelAnalysisConstants.STEP_URLS).isEmpty()) {
//				fields.add(FunnelAnalysisConstants.STEP_URLS);
//			} else {
//				String urlStr = map.get(FunnelAnalysisConstants.STEP_URLS);
//				try {					
//					JSONArray urlObj = new JSONArray(urlStr);
//					if(urlObj.length() == 0) {
//						fields.add(FunnelAnalysisConstants.STEP_URLS);
//					} else {
//						for(int i = 0; i < urlObj.length(); i++) {
//							JSONObject url = urlObj.getJSONObject(i);
//							if(!url.has(FunnelAnalysisConstants.MATCH_TYPE) || url.getString(FunnelAnalysisConstants.MATCH_TYPE).isEmpty()) {
//								fields.add(FunnelAnalysisConstants.STEP_URLS+"."+FunnelAnalysisConstants.MATCH_TYPE);
//								break;
//							} else {
//								Integer matchType = url.getInt(FunnelAnalysisConstants.MATCH_TYPE);
//								FunnelMatchType mt = FunnelMatchType.getMatchTypeById(matchType);
//								if(mt == null) {
//									ZABRequest.updateError(map, ZABAction.getMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{FunnelAnalysisConstants.STEP_URLS+"."+FunnelAnalysisConstants.MATCH_TYPE}));
//									return;
//								} else if(!mt.equals(FunnelMatchType.URLLESS)) {									
////									if(!url.has(FunnelAnalysisConstants.VALUE)) {
////										fields.add(FunnelAnalysisConstants.STEP_URLS+"."+FunnelAnalysisConstants.VALUE);
////										break;
////									}
//								}
//							}
//							
//						}
//					}
//				} catch (Exception e) {
//					ZABRequest.updateError(map, ZABAction.getMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{FunnelAnalysisConstants.STEP_URLS}));
//					return;
//				}
//			}
			if(fields.size() > 0) {
				ZABRequest.updateError(map, ZABAction.getAppropriateMessage(ZABConstants.ErrorMessages.MANDATORY_FIELD_MISSING.getErrorString(),fields));
			}
		}
		
		
		if(httpMethod.equals("PUT")) {
			ArrayList<String> fields = new ArrayList<String>();
			
			if(!isNullOrEmpty(map, FunnelAnalysisConstants.MATCH_TYPE)) {				
				try {
					Integer matchType = Integer.parseInt(map.get(FunnelAnalysisConstants.MATCH_TYPE));
					FunnelMatchType funnelMatchType = FunnelMatchType.getMatchTypeById(matchType);
					if(funnelMatchType == null) {
						ZABRequest.updateError(map, ZABAction.getMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{GoalConstants.GOAL_TYPE}));
						return;
					}
					
					if(funnelMatchType.equals(FunnelMatchType.URLLESS)) {
						if(isNullOrEmpty(map, FunnelAnalysisConstants.CUSTOM_EVENT_LN)) {
							fields.add(FunnelAnalysisConstants.CUSTOM_EVENT_LN);
							ZABRequest.updateError(map, ZABAction.getAppropriateMessage(ZABConstants.ErrorMessages.MANDATORY_FIELD_MISSING.getErrorString(),fields));
							return;
						}
					} else {
						if(isNullOrEmpty(map, FunnelAnalysisConstants.VALUE)) {
							fields.add(FunnelAnalysisConstants.VALUE);
							ZABRequest.updateError(map, ZABAction.getAppropriateMessage(ZABConstants.ErrorMessages.MANDATORY_FIELD_MISSING.getErrorString(),fields));
							return;
						}
					}
				} catch (NumberFormatException e) {
					ZABRequest.updateError(map, ZABAction.getMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{GoalConstants.GOAL_TYPE}));
					return;
				}
			}
			
//			if(map.containsKey(FunnelAnalysisConstants.STEP_URLS)) {
//				String urlStr = map.get(FunnelAnalysisConstants.STEP_URLS);
//				try {					
//					JSONArray urlObj = new JSONArray(urlStr);
//					if(urlObj.length() == 0) {
//						fields.add(FunnelAnalysisConstants.STEP_URLS);
//					} else {
//						for(int i = 0; i < urlObj.length(); i++) {
//							JSONObject url = urlObj.getJSONObject(i);
//							if(!url.has(FunnelAnalysisConstants.MATCH_TYPE) || url.getString(FunnelAnalysisConstants.MATCH_TYPE).isEmpty()) {
//								fields.add(FunnelAnalysisConstants.STEP_URLS+"."+FunnelAnalysisConstants.MATCH_TYPE);
//								break;
//							} else {
//								Integer matchType = url.getInt(FunnelAnalysisConstants.MATCH_TYPE);
//								FunnelMatchType mt = FunnelMatchType.getMatchTypeById(matchType);
//								if(mt == null) {
//									ZABRequest.updateError(map, ZABAction.getMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{FunnelAnalysisConstants.STEP_URLS+"."+FunnelAnalysisConstants.MATCH_TYPE}));
//									return;
//								} else if(!mt.equals(FunnelMatchType.URLLESS)) {									
//									if(!url.has(FunnelAnalysisConstants.VALUE)) {
//										fields.add(FunnelAnalysisConstants.STEP_URLS+"."+FunnelAnalysisConstants.VALUE);
//										break;
//									}
//								}
//							}
//							
//						}
//					}
//				} catch (Exception e) {
//					ZABRequest.updateError(map, ZABAction.getMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{FunnelAnalysisConstants.STEP_URLS}));
//					return;
//				}
//			}
		}
		
	}

	@Override
	public void specificValidation(HashMap<String, String> map,
			HttpServletRequest request) throws IOException, JSONException {
		String httpMethod = request.getMethod();
		validate(map, httpMethod);
	}

}
