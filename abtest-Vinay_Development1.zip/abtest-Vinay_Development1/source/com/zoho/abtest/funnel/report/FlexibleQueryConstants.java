//$Id$
package com.zoho.abtest.funnel.report;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import com.zoho.abtest.audience.AudienceAttributeConstants.AudienceAttributeMatchTypes;
import com.zoho.abtest.report.ElasticSearchConstants;


public class FlexibleQueryConstants {
	
	public static final String SCRIPT = "script"; //NO I18N
	
	public static final String MATCH = "match";//NO I18N
	
	public static final String MUST = "must";//NO I18N
	
	public static final String QUERY = "query";//NO I18N
	
	public static final String LANG = "lang";//NO I18N
	
	public static final String PAINLESS = "painless";//NO I18N
	
	public static final String ORDER = "order";//NO I18N
	
	public static final String DIMENSION = "dimension";//NO I18N
	
	public static final String DIMENSION_VALUE = "dimension_value";//NO I18N
	
	public static final String START_TIME = "start_time";//NO I18N
	
	public static final String END_TIME = "end_time";//NO I18N
	
	public static final String GREATER_THAN_EQUALS = "gte";//NO I18N
	
	public static final String LESS_THAN_EQUALS = "lte";//NO I18N
	
	public static final String RANGE = "range";//NO I18N
	
	public static final String BOOL = "bool";//NO I18N
	
	public static final String ON_FLAG = "on_flag"; //NO I18N
	
	public static final String OFF_FLAG = "off_flag"; //NO I18N
	
	public static final String PARAMS = "params";//NO I18N
	
	public static final String NESTED = "nested";//NO I18N
	
	public static final String PATH = "path";//NO I18N
	
	public static final String INLINE = "inline";//NO I18N
	
	public static final String TERM = "term";//NO I18N
	
	public static final String FILTER = "filter";//NO I18N
	
	public static final String AGGS = "aggs";//NO I18N
	
	public static final String AVG = "avg";//NO I18N
	
	public static final String SIZE = "size";//NO I18N
	
	public static final String AVERAGE_TIME_ON_STEP = "average_time_on_step";//NO I18N
	
	public static final String FIRSTSTEP = "firststep";//NO I18N
	
	public static final String ATTR_VALUES = "attr_values";//NO I18N
	
	public static final String VALUES = "values";//NO I18N
	
	public static final String FIELD_TYPE = "field_type";//NO I18N
	
	public static final String ATTR_KEY = "attr_key";//NO I18N
	
	public static final String ATTR_NAME = "attr_name";//NO I18N
	
	public static final String MATCH_TYPE = "match_type";//NO I18N
	
	public static final String INTERVAL_TYPE = "interval_type";//NO I18N
	
	//CRUFT
	public static final HashMap<String, String> FIELD_KEY_SWAPS;
	static {
		FIELD_KEY_SWAPS = new HashMap<String, String>();
		FIELD_KEY_SWAPS.put("current_url", ElasticSearchConstants.CURRENTURL);
		FIELD_KEY_SWAPS.put("referral_url", ElasticSearchConstants.REFFERERURL);
		FIELD_KEY_SWAPS.put("source", ElasticSearchConstants.TRAFFICSOURCE);
		FIELD_KEY_SWAPS.put("query_parameter", "n"+ElasticSearchConstants.URLPARAMETER);
		FIELD_KEY_SWAPS.put(ElasticSearchConstants.COOKIE, "n"+ElasticSearchConstants.COOKIE);
		FIELD_KEY_SWAPS.put(ElasticSearchConstants.JSVARIABLE, "n"+ElasticSearchConstants.JSVARIABLE);
		FIELD_KEY_SWAPS.put(ElasticSearchConstants.CUSTOMDIMENSION, "n"+ElasticSearchConstants.CUSTOMDIMENSION);
		FIELD_KEY_SWAPS.put("day_of_week", ElasticSearchConstants.DAYOFWEEK);
		FIELD_KEY_SWAPS.put("hour_of_the_day", ElasticSearchConstants.HOUROFDAY);
		FIELD_KEY_SWAPS.put("visitor_type", ElasticSearchConstants.USERTYPE);
	}
	//CRUFT
	public static final HashMap<String, HashMap<String, String>>  FIELD_VALUE_SWAPS;
	static {
		FIELD_VALUE_SWAPS = new HashMap<String, HashMap<String, String>>();
		
		HashMap<String, String> sourceValueSwaps = new HashMap<String, String>();
		sourceValueSwaps.put("direct visitors", "DIRECT");
		sourceValueSwaps.put("referral traffic", "REFERRAL");
		sourceValueSwaps.put("social traffic", "SOCIAL");
		sourceValueSwaps.put("organic search", "SEARCH");
		sourceValueSwaps.put("paid search", "PAID");
		
		FIELD_VALUE_SWAPS.put(ElasticSearchConstants.TRAFFICSOURCE, sourceValueSwaps);
	}
	
	static {	
		HashMap<String, String> dayofweekValueSwaps = new HashMap<String, String>();
		dayofweekValueSwaps.put("sunday", "1");
		dayofweekValueSwaps.put("monday", "2");
		dayofweekValueSwaps.put("tuesday", "3");
		dayofweekValueSwaps.put("wednesday", "4");
		dayofweekValueSwaps.put("thursday", "5");
		dayofweekValueSwaps.put("friday", "6");
		dayofweekValueSwaps.put("saturday", "7");
		
		FIELD_VALUE_SWAPS.put(ElasticSearchConstants.DAYOFWEEK, dayofweekValueSwaps);
	}

	public static final List<String> FUNNEL_NESTED_FIELDS = Arrays.asList(
			ElasticSearchConstants.FUSERTYPE,
			ElasticSearchConstants.CURRENTURL,
			ElasticSearchConstants.REFFERERURL,
			ElasticSearchConstants.TRAFFICSOURCE);
	
	public static final List<String> FUNNEL_NESTED_FIELDS_DYN = Arrays.asList(
			"n"+ElasticSearchConstants.URLPARAMETER, //NO I18N
			"n"+ElasticSearchConstants.COOKIE, //NO I18N
			"n"+ElasticSearchConstants.JSVARIABLE, //NO I18N
			"n"+ElasticSearchConstants.CUSTOMDIMENSION); //NO I18N
	
	
	public static final String ELASTIC_GCLID_AGG_SCRIPT = "if(doc['steps.nurlparameter.name'].value == params.key) { " //NO I18N
																+ "return doc['steps.nurlparameter.value'].value; } " //NO I18N
															+ "return null;"; //NO I18N
	
	
	public static final String ELASTIC_NODIM_QUERY_SCRIPT = "int counter = 0;" //NO I18N
			+ "params._source['steps'].sort((x, y) -> {return (x.time - y.time) > 0 ? 1:-1});" //NO I18N
			+ "params._source['steps'].removeIf(item -> (item.time < params.start_time || item.time > params.end_time));" //NO I18N
			+ "for(int i; i<params._source.steps.length; i++) {" //NO I18N
					+ "if(params._source.steps[i].stepid == params.order[counter]) {" //NO I18N
						+ "counter++;" //NO I18N
						 + "if(counter == params.order.length) {" //NO I18N
							+ "return true; " //NO I18N
						+ "} " //NO I18N
					+ "} " //NO I18N
				+ "} " //NO I18N
			+ "return false;"; //NO I18N
	
	
	/**
	 * Script for nested query in quick filter
	 * =======================================
	 * Params
	 * ~~~~~~~
	 * start_time
	 * end_time
	 * step_id
	 * dimension
	 * dimension_value
	 * timezone
	 */
	public static final String ELASTIC_QUICKF_NESTED_SCRIPT = 
					"int counter = 0;"+ //NO I18N
					"params._source['steps'].sort((x, y) -> {return (x.time - y.time) > 0 ? 1:-1});"+ //NO I18N
					"params._source['steps'].removeIf(item -> (item.time < params.start_time || item.time > params.end_time));"+ //NO I18N
					"for(int i; i<params._source.steps.length; i++) {"+ //NO I18N
					"    if(params._source.steps[i].stepid == params.step_id) {"+ //NO I18N
					"        if(params.dimension == 'hour_of_the_day') {"+ //NO I18N
					"            return params.dimension_value == LocalDateTime.ofInstant(Instant.ofEpochMilli(params._source.steps[i].time), TimeZone.getTimeZone(params.timezone).toZoneId()).getHour().toString();"+ //NO I18N
					"        } else if(params.dimension == 'day_of_week') {"+ //NO I18N
					"            return params.dimension_value == LocalDateTime.ofInstant(Instant.ofEpochMilli(params._source.steps[i].time), TimeZone.getTimeZone(params.timezone).toZoneId()).getDayOfWeek().toString();"+ //NO I18N
					"        } else {"+ //NO I18N
					"            return params._source.steps[i][params.dimension] == params.dimension_value;"+ //NO I18N
					"        }"+ //NO I18N
					"    }"+ //NO I18N
					"}"+ //NO I18N
					"return false;"; //NO I18N
	
	public static final String ELASTIC_NODIM_QUERY_SCRIPT_INVERTABLE = "int counter = 0;" //NO I18N
																	 + "List steps = new ArrayList(params._source['steps']); " //NO I18N
																	 + "steps.sort((x, y) -> {return (x.time - y.time) > 0 ? 1:-1}); " //NO I18N
																	 + "steps.removeIf(item -> (item.time < params.start_time || item.time > params.end_time)); " //NO I18N
																	 + "for(int i; i<steps.length; i++) {" //NO I18N
																		 + "if(steps[i].stepid == params.order[counter]) {" //NO I18N
																		 + "counter++; " //NO I18N
																		 + "if(counter == params.order.length) {return params.on_flag; } " //NO I18N
																		 + "} " //NO I18N
																	 + "} " //NO I18N
																	 + "return params.off_flag;"; //NO I18N 
			
					
			
			
//			"int counter = 0;" //NO I18N
//			+ "params._source['steps'].sort((x, y) -> {return (x.time - y.time) > 0 ? 1:-1});" //NO I18N
//			+ "params._source['steps'].removeIf(item -> (item.time < params.start_time || item.time > params.end_time));" //NO I18N
//			+ "for(int i; i<params._source.steps.length; i++) {" //NO I18N
//					+ "if(params._source.steps[i].stepid == params.order[counter]) {" //NO I18N
//						+ "counter++;" //NO I18N
//						 + "if(counter == params.order.length) {" //NO I18N
//							+ "return params.on_flag; " //NO I18N
//						+ "} " //NO I18N
//					+ "} " //NO I18N
//				+ "} " //NO I18N
//			+ "return params.off_flag;"; //NO I18N
	
	public static final String ELASTIC_TC_QUERY_SCRIPT = "int counter = 0;" //NO I18N
			+ "params._source['steps'].sort((x, y) -> {return (x.time - y.time) > 0 ? 1:-1});" //NO I18N
			+ "for(int i; i<params._source.steps.length; i++) {" //NO I18N
					+ "if(params._source.steps[i].stepid == params.order[counter]) {" //NO I18N
						+ "counter++;" //NO I18N
						 + "if(counter == params.order.length) {" //NO I18N
							+ "return true; " //NO I18N
						+ "} " //NO I18N
					+ "} " //NO I18N
				+ "} " //NO I18N
			+ "return false;"; //NO I18N
	
	public static final String ELASTIC_STEP_VISIT_COUNT = "params._source['steps']" //NO I18N
															+ ".removeIf(item -> (item.time < params.start_time || item.time > params.end_time));" //NO I18N
															+ " for(int i; i<params._source.steps.length; i++) {" //NO I18N
																+ "if(params._source.steps[i].stepid == params.stepid) {" //NO I18N
																	+ "return true; " //NO I18N
																+ "} " //NO I18N
															+ "} return false;"; //NO I18N
	
	
	public static final String ELASTIC_STEP_AVERAGE_TIME = "int counter = 0;" //NO I18N
			+ " long starttime = 0;" //NO I18N
			+ " params._source['steps'].sort((x, y) -> {return (x.time - y.time) > 0 ? 1:-1});" //NO I18N
			+ " params._source['steps'].removeIf(item -> (item.time < params.start_time || item.time > params.end_time)); " //NO I18N
			+ "for(int i; i<params._source.steps.length; i++) {" //NO I18N
				+ "if(params._source.steps[i].stepid == params.order[counter]) {" //NO I18N
					+ "counter++; if(counter == 1) {" //NO I18N
						+ "starttime = params._source.steps[i].time;" //NO I18N
				+ " } else if(counter == params.order.length && starttime!=0) {" //NO I18N
						+ "return params._source.steps[i].time - starttime; " //NO I18N
				+ "}" //NO I18N
			+ " } " //NO I18N
			+ "} return 0;"; //NO I18N
	
	
	/**
	 * Used to apply filters by dayofweek and hourofday
	 * Params:
	 * start_time
	 * end_time
	 * firststep
	 * interval_type
	 * values
	 * timezone
	 */
	public static final String DAY_HOUR_OF_WEEK_SCRIPT = 
			 "List steps = new ArrayList(params._source['steps']);"										 //NO I18N
			+"steps.sort((x, y) -> {return (x.time - y.time) > 0 ? 1:-1});"								 //NO I18N
			+"steps.removeIf(item -> (item.time < params.start_time || item.time > params.end_time));"	 //NO I18N
			+"  for(int i = 0; i<steps.length; i++) {"													 //NO I18N
			+"      if(steps[i].stepid == params.firststep) {"											 //NO I18N
			+"          if(params.interval_type == 'H') {"												 //NO I18N
			+"            return params.values.contains(LocalDateTime.ofInstant(Instant.ofEpochMilli(steps[i].time)," //NO I18N
													+" TimeZone.getTimeZone(params.timezone).toZoneId()).getHour().toString());"			 //NO I18N
			+"          } else {"																		 //NO I18N
			+"            return params.values.contains(LocalDateTime.ofInstant(Instant.ofEpochMilli(steps[i].time)," //NO I18N
													+ " TimeZone.getTimeZone(params.timezone).toZoneId()).getDayOfWeek().toString());"    //NO I18N
			+"          }"																				 //NO I18N
			+"     }" 																					 //NO I18N
			+" }" 																						 //NO I18N
			+"return false;"; 																			 //NO I18N
	
	
	
	/**
	 * Params:
	 * start_time
	 * end_time
	 * order
	 * field_type
	 * attr_key
	 * attr_name
	 * attr_values - []
	 */
	public static final String ELASTIC_SEARCH_DEEP_FILTER_QP = 
			"int counter = 0;" //NO I18N
			+ "params._source['steps'].sort((x, y) -> {return (x.time - y.time) > 0 ? 1:-1});" //NO I18N
			+ "params._source['steps'].removeIf(item -> (item.time < params.start_time || item.time > params.end_time));" //NO I18N
			+ "for(int i; i<params._source.steps.length; i++) {" //NO I18N
					+ "if(params._source.steps[i].stepid == params.order[counter]) {" //NO I18N
							+"      def value,flag = false;" 																	//NO I18N
							+" 		if(counter > 0) {"   //No I18N
							+ "			flag = true;"   //No I18N
							+ "		} else {"   //No I18N
							+"          if(params.field_type == 'DA') {" 												//NO I18N
							+"            for(int q = 0; q < params._source.steps[i][params.attr_key].length; q++) {" 					//NO I18N
							+"              if(params._source.steps[i][params.attr_key][q].name == params.attr_name) {" 									//NO I18N
							+"                 value = params._source.steps[i][params.attr_key][q].value;" 												//NO I18N
							+"              }" 																			//NO I18N
							+"            }" 																			//NO I18N
							+"          } else {" 																		//NO I18N
							+"              value = params._source.steps[i][params.attr_key];" 										//NO I18N
							+"          }" 																				//NO I18N
							+"  		   if(value!=null && params.match_type == "+AudienceAttributeMatchTypes.EQUALS.getTypeId()+") {" 												//NO I18N
							+"  			   flag =  (params.attr_values == value);" 								//NO I18N
							+"  		   }"
							+ "			}" 																			//NO I18N
							+"			   if(flag) {" //No I18N
							+ "					counter++;" //No I18N
							+ "			   }"	
							+"     	}" 
							+ "if(counter == params.order.length) {" //NO I18N
								+ "return true" //No I18N
							+ "} " //NO I18N
					+ "} " //NO I18N
			+ "return false;"; //NO I18N
	
	/**
	 * Used to apply filters on dimension which resides inside nested steps
	 * Params:
	 * 
	 * start_time
	 * end_time
	 * firststep
	 * match_type
	 * attr_values
	 * attr_key
	 */
	public static final String ELASTIC_SEARCH_DEEP_FILTER = 
		"List steps = new ArrayList(params._source['steps']);" //NO I18N
		+"steps.sort((x, y) -> {return (x.time - y.time) > 0 ? 1:-1});" //NO I18N
		+"   steps.removeIf(item -> (item.time < params.start_time || item.time > params.end_time));" //NO I18N
		+"   for(int i = 0; i<steps.length; i++) {" 												//NO I18N
		+"     if(steps[i].stepid == params.firststep) {" 											//NO I18N
		+"          def value;" 																	//NO I18N
		+"          if(params.field_type == 'DA') {" 												//NO I18N
		+"            for(int q = 0; q < steps[i][params.attr_key].length; q++) {" 					//NO I18N
		+"              if(steps[i][params.attr_key][q].name == params.attr_name) {" 									//NO I18N
		+"                 value = steps[i][params.attr_key][q].value;" 												//NO I18N
		+"              }" 																			//NO I18N
		+"            }" 																			//NO I18N
		+"          } else {" 																		//NO I18N
		+"              value = steps[i][params.attr_key];" 										//NO I18N
		+"          }" 																				//NO I18N
		+"  		   if(params.match_type == "+AudienceAttributeMatchTypes.EQUALS.getTypeId()+") {" 												//NO I18N
		+"  			   return params.attr_values.contains(value);" 								//NO I18N
		+"  		   } else if(params.match_type == "+AudienceAttributeMatchTypes.NOT_EQUALS.getTypeId()+") {" 										//NO I18N
		+"  			   return !params.attr_values.contains(value);" 							//NO I18N
		+"  		   } else if(params.match_type == "+AudienceAttributeMatchTypes.REGEX.getTypeId()+") {" 										//NO I18N
							//Since dynamic regex are not supported
		+"  			   return true;" 															//NO I18N
		+"  		   } else if(params.match_type == "+AudienceAttributeMatchTypes.CONTAINS.getTypeId()+") {" 										//NO I18N
		+"  			   for(int k = 0; k < params.attr_values.length; k++) {" 					//NO I18N
		+"  				   if(params.attr_values[k].contains(value)) {" 						//NO I18N
		+"  					   return true;" 													//NO I18N
		+"  					   }" 																//NO I18N
		+"  			   }" 																		//NO I18N
		+"  		   } else if(params.match_type == "+AudienceAttributeMatchTypes.DOESNOT_CONTAINS.getTypeId()+") {" 										//NO I18N
		+"  			   for(int k = 0; k < params.attr_values.length; k++) {" 					//NO I18N
		+"  				   if(!params.attr_values[k].contains(value)) {" 						//NO I18N
		+"  					   return true;" 													//NO I18N
		+"  				   }" 																	//NO I18N
		+"  			   }" 																		//NO I18N
		+"  		   } else if(params.match_type == "+AudienceAttributeMatchTypes.STARTS_WITH.getTypeId()+") {" 										//NO I18N
		+"  			   for(int k = 0; k < params.attr_values.length; k++) {" 					//NO I18N
		+"  				   if(params.attr_values[k].startsWith(value)) {" 						//NO I18N
		+"  					   return true;" 													//NO I18N
		+"  					   }" 																//NO I18N
		+"  			   }" 																		//NO I18N
		+"  		   } else if(params.match_type == "+AudienceAttributeMatchTypes.ENDS_WITH.getTypeId()+") {" 										//NO I18N
		+"  			   for(int k = 0; k < params.attr_values.length; k++) {" 					//NO I18N
		+"  				   if(params.attr_values[k].endsWith(steps[i][params.attr_key])) {" 	//NO I18N
		+"  					   return true;" 													//NO I18N
		+"  				    }" 																	//NO I18N
		+"  			   }" 																		//NO I18N
		+"  		   }" 																			//NO I18N
		+"     	}" 																					//NO I18N
		+"     }" 																					//NO I18N
		+"return false;"; 																			//NO I18N
	
		
}
