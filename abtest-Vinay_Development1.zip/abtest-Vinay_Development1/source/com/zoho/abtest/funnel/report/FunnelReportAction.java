//$Id$
package com.zoho.abtest.funnel.report;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.json.JSONException;

import com.opensymphony.xwork2.ActionSupport;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.report.CumulativeReportConstants;
import com.zoho.abtest.report.ReportStatistics;
import com.zoho.abtest.utility.ZABUtil;

public class FunnelReportAction  extends ActionSupport implements ServletResponseAware, ServletRequestAware{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private HttpServletRequest request;
	private HttpServletResponse response;
	
	private String experimentLinkName;
	
	public String getExperimentLinkName() {
		return experimentLinkName;
	}

	public void setExperimentLinkName(String experimentLinkName) {
		this.experimentLinkName = experimentLinkName;
	}

	private static final Logger LOGGER = Logger.getLogger(FunnelReportAction.class.getName()); 
	
	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		request = arg0; 
	}

	@Override
	public void setServletResponse(HttpServletResponse arg0) {
		response = arg0;
	}
	
	public String getFunnelReport() throws IOException, JSONException {
		
		HashMap<String,String> hs;
		ArrayList<FunnelReport> funnelReports = new ArrayList<FunnelReport>();
		try {			
		
			switch(ZABAction.getHTTPMethod(request)) {
			case POST:	
				hs = ZABAction.getRequestParser(request).parseFunnelReportData(request);
				if(hs.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					FunnelReport report = new FunnelReport();
					report.setSuccess(Boolean.FALSE);
					report.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
					funnelReports.add(report);
					LOGGER.log(Level.SEVERE,hs.get(ZABConstants.RESPONSE_STRING));
				}else{
//					FunnelFlexibleTimeline.getFunnelFlexibleTimeline(hs);
					String reportSource = request.getParameter("rs");
					if(reportSource == null || reportSource.equals("2")) {
						funnelReports.addAll(FunnelFlexible.getFunnelReport(hs));
					} else {						
						funnelReports.addAll(FunnelReport.getFunnelReports(hs));
					}
				}
				break;
			}
		} catch(Exception ex){
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), FunnelReportConstants.API_MODULE));
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
			return null; 	
		}		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getFunnelReportResponse(request, funnelReports));		
		return null;
		
	}
	
	public String getTimeLineFunnelReport() throws Exception {
		HashMap<String,String> hs;
		ArrayList<FunnelTimelineReport> funnelReports = new ArrayList<FunnelTimelineReport>();
		try {			
		
			switch(ZABAction.getHTTPMethod(request)) {
			case POST:	
				hs = ZABAction.getRequestParser(request).parseFunnelTimelineData(request);
				if(hs.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					FunnelTimelineReport report = new FunnelTimelineReport();
					report.setSuccess(Boolean.FALSE);
					report.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
					funnelReports.add(report);
					LOGGER.log(Level.SEVERE,hs.get(ZABConstants.RESPONSE_STRING));
				}else{
					funnelReports.addAll(FunnelFlexibleTimeline.getFunnelFlexibleTimeline(hs));
				}
				break;
			}
		} catch(Exception ex){
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), FunnelReportConstants.API_MODULE));
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
			return null; 	
		}		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getFunnelReportTimelineResponse(request, funnelReports));		
		return null;
		
	}

}
