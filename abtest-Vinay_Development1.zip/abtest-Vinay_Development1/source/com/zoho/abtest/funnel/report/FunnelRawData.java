//$Id$
package com.zoho.abtest.funnel.report;

import static com.zoho.abtest.funnel.report.FunnelRawDataHelper.getOSCode;
import static com.zoho.abtest.funnel.report.FunnelRawDataHelper.updateDynamicAttributeJSON;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.script.Script;
import org.elasticsearch.script.ScriptService;
import org.elasticsearch.script.ScriptType;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.adventnet.persistence.Row;
import com.zoho.abtest.dimension.DimensionConstants;
import com.zoho.abtest.dimension.DimensionConstants.DynamicAttributeType;
import com.zoho.abtest.dimension.DynamicAttributes;
import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.funnel.FunnelStep;
import com.zoho.abtest.funnel.report.FunnelReportConstants.FUNNNEL_RAW_TABLE;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.report.ReportRawDataConstants;
import com.zoho.abtest.report.VisitorRawDataHandler;
import com.zoho.abtest.report.VisitorRawDataWrapper;
import com.zoho.abtest.utility.ZABUtil;

/**
 * @author david-3671
 *
 */
public class FunnelRawData {
	
	private String dbSpace;
		
	private Long funnelRawDataId;
	
	private Long time;
	
	private Long experimentId;
	
	private Long stepId;
	
	private Integer browserCode;
	
	private Integer deviceCode;
	
	private Integer countryCode;
	
	private Integer languageCode;
	
	private Integer osCode;
	
	private Integer dayOfTheWeek;
	
	private Integer hourOfTheDay;
	
	private JSONObject queryParameter;
	
	private JSONObject cookie;
	
	private JSONObject jsVariable;
	
	private JSONObject customAttribute;
	
	private Long count;
	
	private Long sessionId;
	
	private String sessionKey;
	
	private String experimentKey;
	
	private String stepKey;
	
	private Row noDimRow;
	
	private JSONObject elasticFunnelDoc;
	
	private Boolean isReturningVisit;
	
	private Script updateScript;
	
	

	public Script getUpdateScript() {
		return updateScript;
	}

	public void setUpdateScript(Script updateScript) {
		this.updateScript = updateScript;
	}

	/**
	 * This constructor is used to extract data from ResultSet 
	 * which comes as a result of Query FunnelReportRawQueries.getCumulativeAllDimAggQuery
	 * @param res
	 * @throws SQLException 
	 */
	public FunnelRawData(ResultSet res, String countColumnName) throws SQLException {
		
		this.setExperimentId(res.getLong(FUNNNEL_RAW_TABLE.EXPERIMENT_ID));
		this.setStepId(res.getLong(FUNNNEL_RAW_TABLE.STEP_ID));
		this.setBrowserCode(res.getInt(FUNNNEL_RAW_TABLE.BROWSER_CODE));
		this.setDeviceCode(res.getInt(FUNNNEL_RAW_TABLE.BROWSER_CODE));
		this.setCountryCode(res.getInt(FUNNNEL_RAW_TABLE.COUNTRY_CODE));
		this.setLanguageCode(res.getInt(FUNNNEL_RAW_TABLE.LANGUAGE_CODE));
		this.setOsCode(res.getInt(FUNNNEL_RAW_TABLE.OS_CODE));
		this.setDayOfTheWeek(res.getInt(FUNNNEL_RAW_TABLE.DAYOFWEEK_CODE));
		this.setHourOfTheDay(res.getInt(FUNNNEL_RAW_TABLE.HOUROFDAY_CODE));
		this.setSessionId(res.getLong(FUNNNEL_RAW_TABLE.SESSION_ID));
		this.setQueryParameter((JSONObject) res.getObject(FUNNNEL_RAW_TABLE.URLPARAM_JSON));
		this.setCookie((JSONObject) res.getObject(FUNNNEL_RAW_TABLE.COOKIE_JSON));
		this.setJsVariable((JSONObject) res.getObject(FUNNNEL_RAW_TABLE.JS_VARIABLE_JSON));
		this.setCustomAttribute((JSONObject) res.getObject(FUNNNEL_RAW_TABLE.CUSTOM_DIMENSION_JSON));
		this.setCount(res.getLong(countColumnName));
		
	}


	/**
	 * @param wrapper
	 * @throws Exception
	 * Observes all data emitted via wrapper
	 */
	public FunnelRawData(VisitorRawDataWrapper wrapper) throws Exception {
		
		this.setDbSpace(ZABUtil.getDBSpace());
		HashMap<String, String> userAgents = wrapper.getUserAgenths();
		HashMap<String, String> funnelData = wrapper.getFunnelData();
		this.setTime(wrapper.getTime());
		
		//Setting experimentID and stepID
		
		String stepKey = funnelData.get(FunnelReportConstants.STEP_KEY);
		String experimentKey = funnelData.get(FunnelReportConstants.EXPERIMENT_KEY);
		
		this.setStepKey(stepKey);
		this.setExperimentKey(experimentKey);
		
		FunnelStep step = FunnelStep.getFunnelStepByKey(stepKey);
		if(step!=null && step.getSuccess()) {
			this.setStepId(step.getStepId());
			this.setExperimentId(step.getExperimentId());
		} else {
			throw new ZABException("Unable to form raw data as step for stepkey is not found. Step key:"+stepKey);
		}
		
		//Generating FunnelRawId
		this.setFunnelRawDataId(FunnelRawDataHelper.genFunnelRawDataId());
		
		//Setting dimension values
		
		JSONObject cookieJson = new JSONObject();
		JSONObject urlParamJson = new JSONObject();
		JSONObject jsVariableJson = new JSONObject();
		JSONObject customDimensionJson = new JSONObject();
		
		HashMap<String,DynamicAttributes> dynamicAttriHs =  DynamicAttributes.getDynamicAttributesOfExperiment(this.getExperimentId().toString());

		updateDynamicAttributeJSON(funnelData, dynamicAttriHs, "EXPERIMENT_ID", urlParamJson, cookieJson, jsVariableJson, customDimensionJson);

		String sessionKey = funnelData.get(FunnelReportConstants.UVID);
		
		
		this.setSessionKey(sessionKey);
		
		Long sessionId = FunnelRawDataHelper.getSessionId(sessionKey);
		if(sessionId == null) {
			sessionId = FunnelRawDataHelper.generateSessionId(sessionKey, this.getExperimentId());
		}
		
		this.setIsReturningVisit(funnelData.containsKey(ReportRawDataConstants.FUNNEL_RETURNING_STEPVISIT) &&
					Boolean.parseBoolean(funnelData.get(ReportRawDataConstants.FUNNEL_RETURNING_STEPVISIT)));
		
		
		this.setSessionId(sessionId);
		
		this.setBrowserCode(FunnelRawDataHelper.getBrowserCode(userAgents.get(ReportRawDataConstants.BROWSER_VALUE)));
		
		this.setDeviceCode(FunnelRawDataHelper.getDeviceCode(userAgents.get(ReportRawDataConstants.DEVICE_VALUE)));
		
		//HashMap<String, String> countryHash = FunnelRawDataHelper.getCountryNameHash(wrapper.getIpAddress());
		
		//this.setCountryCode(FunnelRawDataHelper.getCountryCode(countryHash));
		
		this.setLanguageCode(FunnelRawDataHelper.getLanguageCode(userAgents.get(ReportRawDataConstants.LANGUAGE_VALUE)));
		
		this.setOsCode(getOSCode(userAgents.get(ReportRawDataConstants.OS_VALUE)));
		
		this.setHourOfTheDay(ZABUtil.getHourOfDay(wrapper.getTime()));
		
		this.setDayOfTheWeek(ZABUtil.getDayOfWeek(wrapper.getTime()));
		
		this.setCookie(cookieJson);
		
		this.setQueryParameter(urlParamJson);
		
		this.setJsVariable(jsVariableJson);
		
		this.setCustomAttribute(customDimensionJson);
		
		String country = null;
		String city = null;
		String region = null;
		//Get country details from IP Address
		JSONObject ipDetailsJson = ZABUtil.getIpAddressDetails(wrapper.getIpAddress());
		country = ipDetailsJson.has("COUNTRY_NAME") ? ipDetailsJson.get("COUNTRY_NAME").toString() : "-"; //NO I18N
		if(StringUtils.isEmpty(country) || country.equals("-"))
		{
			country = ReportRawDataConstants.UNKNOWN_VALUE;
		}
		country = country.toUpperCase();
		//Get city details
		city = ipDetailsJson.has("CITY") ? ipDetailsJson.get("CITY").toString() : "-"; //NO I18N
		if(StringUtils.isEmpty(city) || city.equals("-"))
		{
			city = ReportRawDataConstants.UNKNOWN_VALUE;
		}
		city = city.toUpperCase();
		//Get region details
		region = ipDetailsJson.has("REGION") ? ipDetailsJson.get("REGION").toString() : "-"; //NO I18N
		if(StringUtils.isEmpty(region) || region.equals("-"))
		{
			region = ReportRawDataConstants.UNKNOWN_VALUE;
		}
		region = region.toUpperCase();
				
		this.buildElasticDocument(wrapper, dynamicAttriHs, country, city, region);
	}
	
	public void buildElasticDocument(
			VisitorRawDataWrapper wrapper,
			HashMap<String, DynamicAttributes> dynamicAttriHs, String country, String city, String region) throws JSONException {
		
		JSONObject resultJson = new JSONObject();
		
		HashMap<String, String> userAgenths = wrapper.getUserAgenths();
		HashMap<String, String> inpuths = wrapper.getFunnelData();
		
		String browser = userAgenths.get(ReportRawDataConstants.BROWSER_VALUE).toUpperCase();
		String device = userAgenths.get(ReportRawDataConstants.DEVICE_VALUE).toUpperCase();
		String language = ZABUtil.getLanguageFromCode(userAgenths.get(ReportRawDataConstants.LANGUAGE_VALUE).toUpperCase());
		String os = userAgenths.get(ReportRawDataConstants.OS_VALUE).toUpperCase();
		String trafficSource = userAgenths.get(ReportRawDataConstants.TRAFFICSOURCE_VALUE).toUpperCase();
		String referurl = userAgenths.get(ReportRawDataConstants.REFFERERURL_VALUE);
		String currenturl = userAgenths.get(ReportRawDataConstants.CURRENTURL_VALUE);
		String urlParamStr = userAgenths.get(ReportRawDataConstants.URLPARAMETER_VALUE);
		String userType = null;
		Boolean isNewVisitor = Boolean.parseBoolean(inpuths.get(ReportRawDataConstants.IS_NEW_VISITOR));
		userType = isNewVisitor?"NEW":"RETURNING"; //No I18N
	
		
		
		JSONArray urlParamArr = VisitorRawDataHandler.parseUrlparamValues(urlParamStr);
		JSONArray cookieArr = new JSONArray();
		JSONArray jsVariableArr = new JSONArray();
		JSONArray customDimensionArr = new JSONArray();
		country = country.toUpperCase();
		
		if(inpuths.containsKey(ReportRawDataConstants.DYNAMICATTRIBUTES)){
		      JSONArray dynamicAttributeAray = new JSONArray(inpuths.get(ReportRawDataConstants.DYNAMICATTRIBUTES));
		      Integer cookieCode =DynamicAttributeType.COOKIE.getAttributeTypeCode();
		      Integer jsVariableCode =DynamicAttributeType.JSVARIABLE.getAttributeTypeCode();
		      Integer customDimensionCode =DynamicAttributeType.CUSTOMDIMENSION.getAttributeTypeCode();

		       
		       for(int i=0;i<dynamicAttributeAray.length();i++){
		    	   JSONObject dynamicAttribute = (JSONObject)dynamicAttributeAray.get(i);
		    	   String attributeLinkName =(String) dynamicAttribute.get(ReportRawDataConstants.ATTRIBUTE_LINK_NAME);
		    	   if(dynamicAttriHs.containsKey(attributeLinkName)){
		    		   Integer attributeType =(Integer) dynamicAttribute.get(ReportRawDataConstants.ATTRIBUTE_TYPE);
			    	   String attributeValue =(String) dynamicAttribute.get(ReportRawDataConstants.ATTRIBUTE_VALUE);
			    	   JSONObject daObject = new JSONObject();
			    	   daObject.put(ElasticSearchConstants.NAME, attributeLinkName);
			    	   daObject.put(ElasticSearchConstants.VALUE, attributeValue);
			    	  if(attributeType.equals(cookieCode)){
			    		   cookieArr.put(daObject);
			    	   }else if(attributeType.equals(jsVariableCode)){
			    		   jsVariableArr.put(daObject);
			    	   }else if(attributeType.equals(customDimensionCode)){
			    		   customDimensionArr.put(daObject);
			    	   }
			    	   
			    	   dynamicAttriHs.remove(attributeLinkName);
		    	   }
		    	   
		       }
		       // DYNAMIC ATTRIBUTES WHICK ARE NOT SENT IN REQUEST ARE FILLED WITH 'UNKNOWN'
		       
		       Set<String> keySet = dynamicAttriHs.keySet();
		       Iterator<String> keysItr = keySet.iterator();
		       while(keysItr.hasNext()){
		    	  String attributeLinkName  =  keysItr.next();
		    	  DynamicAttributes da = dynamicAttriHs.get(attributeLinkName);
		    	  Integer attributeType = da.getAttributeType();	
		    	  String attributeValue = ReportRawDataConstants.UNKNOWN_VALUE;
		    	  JSONObject daObject = new JSONObject();
		    	  daObject.put(ElasticSearchConstants.NAME, attributeLinkName);
		    	  daObject.put(ElasticSearchConstants.VALUE, attributeValue);
		    	 if(attributeType.equals(cookieCode)){
		    		   cookieArr.put(daObject);
		    	   }else if(attributeType.equals(jsVariableCode)){
		    		   jsVariableArr.put(daObject);
		    	   }else if(attributeType.equals(customDimensionCode)){
		    		   customDimensionArr.put(daObject);
		    	   }
			    	 
		       }
		    }
		
		
		
		resultJson.put(ElasticSearchConstants.EXPERIMENTID, this.getExperimentId());
		resultJson.put(ElasticSearchConstants.EXPERIMENTKEY, this.getExperimentKey());
		resultJson.put(ElasticSearchConstants.FIRST_VISIT_TIME, this.getTime());
		resultJson.put(ElasticSearchConstants.SESSION_ID, this.getSessionKey());
		resultJson.put(ElasticSearchConstants.BROWSER, browser);
		resultJson.put(ElasticSearchConstants.DEVICE, device);
		resultJson.put(ElasticSearchConstants.COUNTRY, country); 
		resultJson.put(ElasticSearchConstants.CITY, city);
		resultJson.put(ElasticSearchConstants.REGION, region);
		resultJson.put(ElasticSearchConstants.LANGUAGE, language);
		resultJson.put(ElasticSearchConstants.OS, os);
		resultJson.put(ElasticSearchConstants.DAYOFWEEK, this.getDayOfTheWeek());  
		resultJson.put(ElasticSearchConstants.HOUROFDAY, this.getHourOfTheDay()); 

		
		JSONObject stepsJSON = new JSONObject();
		stepsJSON.put(ElasticSearchConstants.TIME, this.getTime());
		stepsJSON.put(ElasticSearchConstants.STEPID, this.getStepId());
		stepsJSON.put(ElasticSearchConstants.STEPKEY, this.getStepKey());
		stepsJSON.put(ElasticSearchConstants.NCOOKIE, cookieArr);
		stepsJSON.put(ElasticSearchConstants.NURLPARAMETER,urlParamArr );
		stepsJSON.put(ElasticSearchConstants.NJSVARIABLE, jsVariableArr);
		stepsJSON.put(ElasticSearchConstants.NCUSTOMDIMENSION, customDimensionArr);
		stepsJSON.put(ElasticSearchConstants.TRAFFICSOURCE, trafficSource);
		stepsJSON.put(ElasticSearchConstants.REFFERERURL, referurl);
		stepsJSON.put(ElasticSearchConstants.CURRENTURL, currenturl);
		stepsJSON.put(ElasticSearchConstants.FUSERTYPE, userType);

		resultJson.put(ElasticSearchConstants.STEPS, new JSONArray().put(stepsJSON));
		
		
		Map<String, Object> stepsJSONMap = ZABUtil.convertJSONtoMap(stepsJSON);
		stepsJSONMap.put(ElasticSearchConstants.NCOOKIE, ZABUtil.convertJSONArrtoMap(cookieArr));
		stepsJSONMap.put(ElasticSearchConstants.NURLPARAMETER,ZABUtil.convertJSONArrtoMap(urlParamArr ));
		stepsJSONMap.put(ElasticSearchConstants.NJSVARIABLE, ZABUtil.convertJSONArrtoMap(jsVariableArr));
		stepsJSONMap.put(ElasticSearchConstants.NCUSTOMDIMENSION, ZABUtil.convertJSONArrtoMap(customDimensionArr));
		
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("step", stepsJSONMap);
		
		Script updateSript = new Script(ScriptType.INLINE, "painless", "ctx._source.steps.add(params.step)", params); //NO I18N
		
		this.setUpdateScript(updateSript);
		this.setElasticFunnelDoc(resultJson);
	}

	public String getSessionKey() {
		return sessionKey;
	}

	public void setSessionKey(String sessionKey) {
		this.sessionKey = sessionKey;
	}

	public String getExperimentKey() {
		return experimentKey;
	}

	public void setExperimentKey(String experimentKey) {
		this.experimentKey = experimentKey;
	}

	public String getStepKey() {
		return stepKey;
	}

	public void setStepKey(String stepKey) {
		this.stepKey = stepKey;
	}

	public Long getSessionId() {
		return sessionId;
	}

	public void setSessionId(Long sessionId) {
		this.sessionId = sessionId;
	}

	public JSONObject getElasticFunnelDoc() {
		return elasticFunnelDoc;
	}

	public void setElasticFunnelDoc(JSONObject elasticFunnelDoc) {
		this.elasticFunnelDoc = elasticFunnelDoc;
	}
	
	

	public Long getCount() {
		return count;
	}

	public void setCount(Long count) {
		this.count = count;
	}

	public String getDbSpace() {
		return dbSpace;
	}

	public Row getNoDimRow() {
		return noDimRow;
	}

	public void setNoDimRow(Row noDimRow) {
		this.noDimRow = noDimRow;
	}

	public void setDbSpace(String dbSpace) {
		this.dbSpace = dbSpace;
	}



	public Long getTime() {
		return time;
	}

	public void setTime(Long time) {
		this.time = time;
	}
	
	public Integer getDayOfTheWeek() {
		return dayOfTheWeek;
	}

	public Integer getHourOfTheDay() {
		return hourOfTheDay;
	}

	public void setHourOfTheDay(Integer hourOfTheDay) {
		this.hourOfTheDay = hourOfTheDay;
	}

	public void setDayOfTheWeek(Integer dayOfTheWeek) {
		this.dayOfTheWeek = dayOfTheWeek;
	}

	public Long getFunnelRawDataId() {
		return funnelRawDataId;
	}

	public void setFunnelRawDataId(Long visitorRawDataId) {
		this.funnelRawDataId = visitorRawDataId;
	}

	public Integer getDeviceCode() {
		return deviceCode;
	}

	public void setDeviceCode(Integer deviceCode) {
		this.deviceCode = deviceCode;
	}

	public Long getExperimentId() {
		return experimentId;
	}

	public void setExperimentId(Long experimentId) {
		this.experimentId = experimentId;
	}

	public Long getStepId() {
		return stepId;
	}

	public void setStepId(Long stepId) {
		this.stepId = stepId;
	}

	public Integer getBrowserCode() {
		return browserCode;
	}

	public void setBrowserCode(Integer browserCode) {
		this.browserCode = browserCode;
	}

	public Integer getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(Integer countryCode) {
		this.countryCode = countryCode;
	}

	public Integer getLanguageCode() {
		return languageCode;
	}

	public void setLanguageCode(Integer languageCode) {
		this.languageCode = languageCode;
	}

	public Integer getOsCode() {
		return osCode;
	}

	public void setOsCode(Integer osCode) {
		this.osCode = osCode;
	}

	public JSONObject getQueryParameter() {
		return queryParameter;
	}

	public void setQueryParameter(JSONObject queryParameter) {
		this.queryParameter = queryParameter;
	}

	public JSONObject getCookie() {
		return cookie;
	}

	public void setCookie(JSONObject cookie) {
		this.cookie = cookie;
	}

	public JSONObject getJsVariable() {
		return jsVariable;
	}

	public void setJsVariable(JSONObject jsVariable) {
		this.jsVariable = jsVariable;
	}

	public JSONObject getCustomAttribute() {
		return customAttribute;
	}

	public void setCustomAttribute(JSONObject customAttribute) {
		this.customAttribute = customAttribute;
	}

	public Boolean getIsReturningVisit() {
		return isReturningVisit;
	}

	public void setIsReturningVisit(Boolean isReturningVisit) {
		this.isReturningVisit = isReturningVisit;
	}
	
//	public Criteria getCriteriaWithBasicDimension() {
//		Criteria c1 = new Criteria(new Column(FUNNEL_DATA_RAW_HOUR.TABLE, FUNNEL_DATA_RAW_HOUR.EXPERIMENT_ID), this.getExperimentId() , QueryConstants.EQUAL);
//		Criteria c2 = new Criteria(new Column(FUNNEL_DATA_RAW_HOUR.TABLE, FUNNEL_DATA_RAW_HOUR.STEP_ID), this.getStepId() , QueryConstants.EQUAL);
//		Criteria c3 = new Criteria(new Column(FUNNEL_DATA_RAW_HOUR.TABLE, FUNNEL_DATA_RAW_HOUR.BROWSER_CODE), this.getBrowserCode() , QueryConstants.EQUAL);
//		Criteria c4 = new Criteria(new Column(FUNNEL_DATA_RAW_HOUR.TABLE, FUNNEL_DATA_RAW_HOUR.DEVICE_CODE), this.getDeviceCode() , QueryConstants.EQUAL);
//		Criteria c5 = new Criteria(new Column(FUNNEL_DATA_RAW_HOUR.TABLE, FUNNEL_DATA_RAW_HOUR.COUNTRY_CODE), this.getCountryCode() , QueryConstants.EQUAL);
//		Criteria c6 = new Criteria(new Column(FUNNEL_DATA_RAW_HOUR.TABLE, FUNNEL_DATA_RAW_HOUR.LANGUAGE_CODE), this.getLanguageCode() , QueryConstants.EQUAL);
//		Criteria c7 = new Criteria(new Column(FUNNEL_DATA_RAW_HOUR.TABLE, FUNNEL_DATA_RAW_HOUR.OS_CODE), this.getOsCode() , QueryConstants.EQUAL);
//		Criteria c8 = new Criteria(new Column(FUNNEL_DATA_RAW_HOUR.TABLE, FUNNEL_DATA_RAW_HOUR.DAY_OF_WEEK), this.getDayOfTheWeek() , QueryConstants.EQUAL);
//		Criteria c9 = new Criteria(new Column(FUNNEL_DATA_RAW_HOUR.TABLE, FUNNEL_DATA_RAW_HOUR.HOUR_OF_DAY), this.getHourOfTheDay() , QueryConstants.EQUAL);
//		
//		return c1.and(c2).and(c3).and(c4).and(c5).and(c6).and(c7).and(c8).and(c9);
//	}
}
