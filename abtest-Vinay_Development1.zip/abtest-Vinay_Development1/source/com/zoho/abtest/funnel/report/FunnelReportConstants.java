//$Id$
package com.zoho.abtest.funnel.report;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import com.zoho.abtest.BROWSER_DETAIL;
import com.zoho.abtest.COUNTRY_DETAIL;
import com.zoho.abtest.DEVICE_DETAIL;
import com.zoho.abtest.DYNAMIC_ATTRIBUTE_VALUES;
import com.zoho.abtest.FUNNEL_DATA_RAW_IDGEN;
import com.zoho.abtest.LANGUAGE_DETAIL;
import com.zoho.abtest.OS_DETAIL;
import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.report.ReportConstants;
import com.zoho.abtest.report.ReportRawDataConstants;
import com.zoho.abtest.utility.ZABUtil;

/**
 * @author david-3671
 *
 */
public class FunnelReportConstants {

	//Client report API Constants
	public static final String API_MODULE = "funnelreport"; //NO I18N
	
	public static final String API_MODULE_TL = "funneltimeline"; //NO I18N
	
	public static final String START_DATE = "start_date"; //NO I18N
	
	public static final String END_DATE = "end_date"; //NO I18N
	
	public static final String TIME = "time"; //NO I18N
	
	public static final String METRIC_VALUE = "metric_value"; //NO I18N
	
	public static final String FUN_REPORT_DATE_FORMAT = "yyyy-MM-dd"; //NO I18N
	
	public static final String EXPERIMENT_LINKNAME = "experiment_linkname"; //NO I18N
	
	public static final String METRIC_TYPE = "metric_type"; //NO I18N
	
	public static final String FROM_STEP_LINKNAME = "from_step_linkname"; //NO I18N
	
	public static final String TO_STEP_LINKNAME = "to_step_linkname"; //NO I18N
	
	public static final String EXPERIMENT_LINKNAME_PARAM = "experimentLinkName"; //NO I18N
	
	public static final String MULTISEGMENT_CRITERIA = "multisegment_criteria"; //NO I18N
	
	public static final String CONDITIONS = "conditions"; //NO I18N
	
	public static final String TYPE = "type"; //NO I18N
	
	public static final String OPERATOR = "operator"; //NO I18N
	
	public static final String VALUES = "values"; //NO I18N
	
	public static final String CONDITION_TYPE = "condition_type"; //NO I18N
	
	public static final String ATTRIBUTENAME = ReportConstants.ATTRIBUTE_NAME;
	
	public static final String EXPERIMENT_ID = "experiment_id"; //NO I18N
	
	public static final String STEP_ID = "step_id"; //NO I18N
	
	public static final String STEP_LINKNAME = "step_linkname"; //NO I18N
	
	public static final String VISITOR_COUNT = "visitor_count"; //NO I18N
	
	public static final String CONVERSIONS = "conversions"; //NO I18N
	
	public static final String CONVERSIONS_RATE = "conversions_rate"; //NO I18N
	
	public static final String DROP_RATE = "drop_rate"; //NO I18N
	
	public static final String DROP_COUNT = "drop_count"; //NO I18N
	
	//SHORTHAND NOTATIONS
	public static final String EXPERIMENT_KEY = ReportRawDataConstants.EXPERIMENT_KEY;
	
	public static final String STEP_KEY = "c"; //NO I18N
	
	public static final String PORTAL = ReportRawDataConstants.PORTAL;
	
	public static final String UVID = ReportRawDataConstants.UVID; //NO I18N
	
	//SHORTHAND NOTATIONS
	public static final String API_MODULE_FUNNEL_RAW_SH = "frd"; //No I18N
	
	public static final String API_MODULE_USERAGENT_RAW_SH = "urd"; //No I18N
	
	public static final String FUNNEL_RAW_NOTIFIER_NAME = "FunnelRawDataListener"; //No I18N
	
	public static final String FUNNEL_DATA_RAW = "FUNNEL_DATA_RAW"; //NO I18N
	
	public static final String FUNNEL_DATA_RAW_ID = "FUNNEL_DATA_RAW_ID"; //NO I18N
	
	public static final String AVERAGE_TIME_SPENT = "average_time_spent"; //NO I18N
	
	public static final String OVERALL_AVERAGE_TIME_SPENT = "overall_average_time_spent"; //NO I18N
	
	public static final List<Constants> FUNNEL_DATA_RAW_IDGEN_CONSTANTS;
	
	public static enum ConditionTypes {
		AND(1),
		OR(2);
		
		private Integer typeCode;
		
		public Integer getTypeCode() {
			return this.typeCode;
		}
		
		private ConditionTypes(Integer typeCode) {
			this.typeCode = typeCode;
		}
		
		public static ConditionTypes getConditionTypeByNumber(Integer number) {
			for(ConditionTypes status: ConditionTypes.values()) {
				if(number!=null && status.getTypeCode().equals(number)) {
					return status;
				}
			}
			return null;
		}
	}
	
	public static enum OperatorTypes {
		EQUALS(1),
		NOT_EQUALS(2),
		REGEX(3),
		CONTAINS(4),
		NOT_CONTAINS(5),
		STARTS_WITH(6),
		ENDS_WITH(7);
		
		private Integer typeId;
		
		private OperatorTypes(Integer typeId) {
			this.typeId = typeId;
		}
		
		public Integer getTypeId() {
			return this.typeId;
		}
		
		public static OperatorTypes getMatchTypeByNumber(Integer number) {
			for(OperatorTypes status: OperatorTypes.values()) {
				if(number!=null && status.getTypeId().equals(number)) {
					return status;
				}
			}
			return null;
		}
	}
	
	public static enum DimensionCodeValueTableDetails {
		BROWSER(ReportConstants.BROWSER, BROWSER_DETAIL.TABLE, BROWSER_DETAIL.BROWSER_CODE, BROWSER_DETAIL.BROWSER_VALUE),
		DEVICE(ReportConstants.DEVICE, DEVICE_DETAIL.TABLE, DEVICE_DETAIL.DEVICE_CODE, DEVICE_DETAIL.DEVICE_VALUE),
		COUNTRY(ReportConstants.COUNTRY, COUNTRY_DETAIL.TABLE, COUNTRY_DETAIL.COUNTRY_CODE, COUNTRY_DETAIL.COUNTRY_DISPLAY_NAME),
		LANGUAGE(ReportConstants.LANGUAGE, LANGUAGE_DETAIL.TABLE, LANGUAGE_DETAIL.LANGUAGE_CODE, LANGUAGE_DETAIL.LANGUAGE_DISPLAY_NAME),
		OS(ReportConstants.OS, OS_DETAIL.TABLE, OS_DETAIL.OS_CODE, OS_DETAIL.OS_VALUE),
		DYN_ATTRS(
				Arrays.asList(ReportConstants.URLPARAMETER, ReportConstants.COOKIE, ReportConstants.JSVARIABLE, ReportConstants.CUSTOMDIMENSION),
				DYNAMIC_ATTRIBUTE_VALUES.TABLE, DYNAMIC_ATTRIBUTE_VALUES.CODE, DYNAMIC_ATTRIBUTE_VALUES.VALUE);
		
		private String codeKey;
		private List<String> codeKeyList;
		private String tableName;
		private String codeColumnName;
		private String valueColumnName;
		
		
		
		public String getCodeKey() {
			return codeKey;
		}

		public List<String> getCodeKeyList() {
			return codeKeyList;
		}

		public String getTableName() {
			return tableName;
		}

		public String getCodeColumnName() {
			return codeColumnName;
		}

		public String getValueColumnName() {
			return valueColumnName;
		}

		private DimensionCodeValueTableDetails(String codeKey, String tableName, String codeColumnName, String valueColumnName) {
			this.codeKey = codeKey;
			this.tableName = tableName;
			this.codeColumnName = codeColumnName;
			this.valueColumnName = valueColumnName;
		}
		
		private DimensionCodeValueTableDetails(List<String> codeKeys, String tableName, String codeColumnName, String valueColumnName) {
			this.codeKeyList = codeKeys;
			this.tableName = tableName;
			this.codeColumnName = codeColumnName;
			this.valueColumnName = valueColumnName;
		}
		
		public static DimensionCodeValueTableDetails getDetailsByCodeKey(String key) {
			for(DimensionCodeValueTableDetails dcvtd: DimensionCodeValueTableDetails.values()) {
				if(dcvtd!=null) {
					if(dcvtd.getCodeKey()!=null && dcvtd.getCodeKey().equals(key)) {						
						return dcvtd;
					} else if(dcvtd.getCodeKeyList()!=null && dcvtd.getCodeKeyList().contains(key)) {
						return dcvtd;
					}
				}
			}
			return null;
		}
		
	}
	
	static{
		List<Constants> visitorDataRawIdGenConstants = new ArrayList<Constants>();
		visitorDataRawIdGenConstants.add(new Constants(FUNNEL_DATA_RAW_ID,FUNNEL_DATA_RAW_IDGEN.FUNNEL_DATA_RAW_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		FUNNEL_DATA_RAW_IDGEN_CONSTANTS = Collections.unmodifiableList(visitorDataRawIdGenConstants);
	}
	
	public static class FUNNNEL_RAW_TABLE {
		
		public static String getActiveRawTable(String dbspaceId) throws Exception {
			FunnelRawTableDetails funnelRawTableDetails = FunnelRawTableDetails.getActiveRawTable();
			if(funnelRawTableDetails == null) {
				return generateRawTableName(dbspaceId);
			}
			return funnelRawTableDetails.getRawTableName();
		}
		
		public static String generateRawTableName(String dbspaceId) {
			String currentDate = ZABUtil.getCurrentDate();
			return generateRawTableName(dbspaceId, currentDate);
		}
		
		public static String generateRawTableName(String dbspaceId, String currentDate) {
			return FunnelReportConstants.FUNNEL_DATA_RAW + ZABConstants.UNDERSCORE + currentDate + ZABConstants.UNDERSCORE + dbspaceId;
		}
		
		public static final String FUNNEL_DATA_RAW_ID = "FUNNEL_DATA_RAW_ID"; //NO I18N
		
		public static final String EXPERIMENT_ID = "EXPERIMENT_ID"; //NO I18N
		
		public static final String STEP_ID = "STEP_ID"; //NO I18N
		
		public static final String BROWSER_CODE = "BROWSER_CODE"; //NO I18N
		
		public static final String DEVICE_CODE = "DEVICE_CODE"; //NO I18N
		
		public static final String COUNTRY_CODE = "COUNTRY_CODE"; //NO I18N
		
		public static final String LANGUAGE_CODE = "LANGUAGE_CODE"; //NO I18N
		
		public static final String OS_CODE = "OS_CODE"; //NO I18N
		
		public static final String DAYOFWEEK_CODE = "DAYOFWEEK_CODE"; //NO I18N
		
		public static final String HOUROFDAY_CODE = "HOUROFDAY_CODE"; //NO I18N
		
		public static final String COOKIE_JSON = "COOKIE_JSON"; //NO I18N
		
		public static final String URLPARAM_JSON = "URLPARAM_JSON"; //NO I18N
		
		public static final String JS_VARIABLE_JSON = "JS_VARIABLE_JSON"; //NO I18N
		
		public static final String CUSTOM_DIMENSION_JSON = "CUSTOM_DIMENSION_JSON"; //NO I18N
		
		public static final String SESSION_ID = "SESSION_ID"; //NO I18N
		
		public static final String TIME = "TIME"; //NO I18N
		
	}
	
	public static class FUNNEL_REPORT_HOUR_DYNS {
		
		public static final String TABLE = "FUNNEL_REPORT_HOUR_DYNS"; //NO I18N
		
		public static final String FUNNEL_REPORT_HOUR_ID = "FUNNEL_REPORT_HOUR_ID"; //NO I18N
		
		public static final String DYN_ATTR_QP = "DYN_ATTR_QP"; //NO I18N
		
		public static final String DYN_ATTR_COOKIE = "DYN_ATTR_COOKIE"; //NO I18N
		
		public static final String DYN_ATTR_JSVAR = "DYN_ATTR_JSVAR"; //NO I18N
		
		public static final String DYN_ATTR_CUSTOM = "DYN_ATTR_CUSTOM"; //NO I18N
		
		public static final String CONVERSIONS = "CONVERSIONS"; //NO I18N
		
	}
}
