//$Id$
package com.zoho.abtest.funnel.report;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;

import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABConstants.ErrorMessages;
import com.zoho.abtest.common.ZABRequest;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.utility.ZABUtil;

public class FunnelReportRequest  extends ZABRequest{

	@Override
	public void updateFromRequest(HashMap<String, String> map,
			HttpServletRequest request) {
		String experimentLinkName  = (String)request.getAttribute(FunnelReportConstants.EXPERIMENT_LINKNAME_PARAM);
		experimentLinkName = experimentLinkName == null ? (String) request
				.getAttribute(ExperimentConstants.EXPERIMENT_LINKNAME)
				: experimentLinkName;
				
		if(experimentLinkName!=null) 
		{
			map.put(FunnelReportConstants.EXPERIMENT_LINKNAME,experimentLinkName);
		}
		
	}

	@Override
	public void specificValidation(HashMap<String, String> map,
			HttpServletRequest request) throws IOException, JSONException {
		String httpMethod = ZABAction.getHTTPMethod(request).toString();
		if(httpMethod.equalsIgnoreCase("POST")){
			ArrayList<String> fields = new ArrayList<String>();
			
			Long startDateInMillis = null;
			
			Long endDateInMillis = null;
			
			if(!map.containsKey(FunnelReportConstants.EXPERIMENT_LINKNAME)) {
				fields.add(FunnelReportConstants.EXPERIMENT_LINKNAME);
			}
			
			if (!map.containsKey(FunnelReportConstants.START_DATE)) {
				fields.add(FunnelReportConstants.START_DATE);
			} else {
				try {					
					startDateInMillis = ZABUtil.getTimeInLongFromDateFormStr(map.get(FunnelReportConstants.START_DATE), FunnelReportConstants.FUN_REPORT_DATE_FORMAT);		// NO I18N
				} catch (ParseException e) {
					ZABRequest.updateError(map, ZABAction.getMessage(ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{FunnelReportConstants.START_DATE}));
				}
			}
			
			if (!map.containsKey(FunnelReportConstants.END_DATE)) {
				fields.add(FunnelReportConstants.END_DATE);
			} else {
				try {					
					endDateInMillis = ZABUtil.getTimeInLongFromDateFormStr(map.get(FunnelReportConstants.END_DATE), FunnelReportConstants.FUN_REPORT_DATE_FORMAT);		// NO I18N
				} catch (ParseException e) {
					//Throw message saying invalid date format
					ZABRequest.updateError(map, ZABAction.getMessage(ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{FunnelReportConstants.END_DATE}));
					return;
				}
			}
			
			
			
			if(startDateInMillis!=null && endDateInMillis!=null) {
				String startDateLabel = ZABAction.getMessage("start_date");
				String endDateLabel = ZABAction.getMessage("end_date");
				
				if(startDateInMillis > endDateInMillis) {
					ZABRequest.updateError(map, ZABAction.getMessage(ExperimentConstants.STARTDATE_LESS_ENDDATE_ERROR, new String[]{startDateLabel, endDateLabel}));
					return;
				}
			}
			
			
			if(fields.size() > 0)
		    {
		    	ZABRequest.updateError(map, ZABAction.getAppropriateMessage(ZABConstants.ErrorMessages.MANDATORY_FIELD_MISSING.getErrorString(),fields));
		    }
			
		}
		
	}

}
