//$Id$
package com.zoho.abtest.funnel.report;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.script.Script;
import org.elasticsearch.script.ScriptType;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.filters.Filters;
import org.elasticsearch.search.aggregations.bucket.filters.FiltersAggregationBuilder;
import org.elasticsearch.search.aggregations.bucket.filters.FiltersAggregator.KeyedFilter;
import org.json.JSONException;

import com.adventnet.iam.IAMUtil;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentStatus;
import com.zoho.abtest.funnel.FunnelAnalysis;
import com.zoho.abtest.funnel.FunnelStep;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.report.ReportConstants;
import com.zoho.abtest.utility.ZABUtil;

public class FunnelFlexibleTimeline {

	private static final Logger LOGGER = Logger.getLogger(FunnelFlexibleTimeline.class.getName());	
	
	private static final Long HOUR_INTERVAL_IN_MILLIS = 3600000l;
	
	private static final Long DAY_INTERVAL_IN_MILLIS = 86400000l;
	
	private static BoolQueryBuilder formQueryForDataPoint(String experimentKey,
			Long startTime, Long timelineStartTime, Long timelineEndtime,
			ArrayList<Long> order) throws JSONException {
		
		BoolQueryBuilder builder = null;

		if(!startTime.equals(timelineStartTime)) {
			
			HashMap<String, Object> params1 = new HashMap<String, Object>();
			params1.put(FlexibleQueryConstants.START_TIME, startTime);
			params1.put(FlexibleQueryConstants.END_TIME, timelineStartTime);
			params1.put(FlexibleQueryConstants.ORDER, order.toArray(new Long[order.size()]));
			params1.put(FlexibleQueryConstants.ON_FLAG, false);
			params1.put(FlexibleQueryConstants.OFF_FLAG, true);
			
			Script script1 = new Script(
					ScriptType.INLINE,
					FlexibleQueryConstants.PAINLESS,
					FlexibleQueryConstants.ELASTIC_NODIM_QUERY_SCRIPT_INVERTABLE,
					params1);
			
			HashMap<String, Object> params2 = new HashMap<String, Object>();
			params2.put(FlexibleQueryConstants.START_TIME, startTime);
			params2.put(FlexibleQueryConstants.END_TIME, timelineEndtime);
			params2.put("step_id", order.get(order.size()-1));
			params2.put(FlexibleQueryConstants.ORDER, order);
			params2.put(FlexibleQueryConstants.ON_FLAG, true);
			params2.put(FlexibleQueryConstants.OFF_FLAG, false);
			
			
			Script script2 = new Script(
					ScriptType.INLINE,
					FlexibleQueryConstants.PAINLESS,
					FlexibleQueryConstants.ELASTIC_NODIM_QUERY_SCRIPT_INVERTABLE,
					params2);
			
			builder =  QueryBuilders
								.boolQuery()
									.filter(QueryBuilders
										.boolQuery()
											.must(QueryBuilders
													.termQuery(ElasticSearchConstants.EXPERIMENTKEY, experimentKey))
											.must(QueryBuilders
													.scriptQuery(script1)))
									.must(QueryBuilders
											.scriptQuery(script2));
		} else {
			
			HashMap<String, Object> params2 = new HashMap<String, Object>();
			params2.put(FlexibleQueryConstants.START_TIME, timelineStartTime);
			params2.put(FlexibleQueryConstants.END_TIME, timelineEndtime);
			params2.put(FlexibleQueryConstants.ORDER, order.toArray(new Long[order.size()]));
			params2.put(FlexibleQueryConstants.ON_FLAG, true);
			params2.put(FlexibleQueryConstants.OFF_FLAG, false);
			
			
			Script script2 = new Script(
					ScriptType.INLINE,
					FlexibleQueryConstants.PAINLESS,
					FlexibleQueryConstants.ELASTIC_NODIM_QUERY_SCRIPT_INVERTABLE,
					params2);
			
			builder = QueryBuilders
						.boolQuery()
							.filter(QueryBuilders
									.boolQuery()
									.must(QueryBuilders.termQuery(ElasticSearchConstants.EXPERIMENTKEY,
																				experimentKey))
									.must(QueryBuilders.scriptQuery(script2)));
		}
		
		return builder;
	}
	
	public static ArrayList<FunnelTimelineReport> getFunnelFlexibleTimeline(
			HashMap<String, String> hs)  {

		ArrayList<FunnelTimelineReport> timeLineReports = new ArrayList<FunnelTimelineReport>();
		try {
			String experimentLinkNmae = hs.get(FunnelReportConstants.EXPERIMENT_LINKNAME);
			String fromStepLinkname = hs.get(FunnelReportConstants.FROM_STEP_LINKNAME);
			String toStepLinkname = hs.get(FunnelReportConstants.TO_STEP_LINKNAME);
			
			
			FunnelAnalysis exp = FunnelAnalysis.getFunnelAnalysisWithSteps(experimentLinkNmae);
			if (exp == null) {
				FunnelTimelineReport report = new FunnelTimelineReport();
				report.setSuccess(Boolean.FALSE);
				report.setResponseString(ZABAction.getMessage(ExperimentConstants.EXPERIMENT_NOT_EXISTS));
				timeLineReports.add(report);
				return timeLineReports;
			}
			
			String startTime = hs.get(ReportConstants.START_DATE);
			String endTime = hs.get(ReportConstants.END_DATE);
			Long startTimeInMillis = null;

			if (startTime != null && !startTime.isEmpty()) {
				startTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(startTime,
						"yyyy-MM-dd"); // NO I18N
			}

			Long endTimeInMillis = null;
			if (endTime != null && !endTime.isEmpty()) {
				endTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(endTime,
						"yyyy-MM-dd"); // NO I18N
			}

			long currentTime = ZABUtil.getCurrentTimeInMilliSeconds();

			Long expActualStartTime = exp.getActualStartTime();
			if (expActualStartTime != null
					&& startTimeInMillis < expActualStartTime) {
				startTimeInMillis = expActualStartTime;
			}

			long hourEndTime = ZABUtil.getNthDayDateInLong(endTimeInMillis, 1);

			Integer expStatus = exp.getExperimentStatus();
			Long expActualEndTime = exp.getActualEndTime();
			
			if (ExperimentStatus.PAUSED.getStatusCode().equals(expStatus)
					&& hourEndTime > expActualEndTime) {
				endTimeInMillis = expActualEndTime;
				hourEndTime = ZABUtil.getNthUserHourInLong(endTimeInMillis, 1);
			}

			long reportDateInterval = ZABUtil.getInterval(startTimeInMillis,
					endTimeInMillis, TimeUnit.DAYS);

			// check the data should be fetched as per hour or day
			// If 2 or less days fetch based on hours
			String portalName =null;
			try{
				portalName = IAMUtil.getCurrentServiceOrg().getDomains().get(0).getDomain();
			}catch(Exception e){
				portalName = ZABUtil.getPortaldomain();
				if(portalName == null){
					throw new Exception();
				}
			}
			
			String indexName = ElasticSearchUtil.getIndexByPortal(portalName);
			reportDateInterval = (reportDateInterval == 0) ? 1:reportDateInterval;
			
			long interval = (reportDateInterval < 23) ? (reportDateInterval * HOUR_INTERVAL_IN_MILLIS): DAY_INTERVAL_IN_MILLIS;
			long hourStartTime = ZABUtil.getNthUserHourInLong(startTimeInMillis, 0);
			long timelineStartTime = hourStartTime;
			
			ArrayList<Long> toPath = FunnelStep.formStepIdPath(toStepLinkname);
			ArrayList<Long> fromPath = new ArrayList<Long>(toPath);
			fromPath.remove(fromPath.size()-1);
			
			
			FunnelTimelineReport ftlinit = new FunnelTimelineReport();
			ftlinit.setTime(timelineStartTime);
			ftlinit.setConversionCount(0l);
			ftlinit.setSessionsCount(0l);
			ftlinit.computeDependentMetricValues(0l);
			ftlinit.setSuccess(Boolean.TRUE);
			timeLineReports.add(ftlinit);
			
			long totalSessions = 0l;
			long totalConversions = 0l;
			
			QueryBuilder filter = null;
			
			
			ArrayList<AggregationBuilder> filterAggs = new ArrayList<AggregationBuilder>();
			
			ArrayList<String> timeMachine = new ArrayList<String>();
			
			while (timelineStartTime < hourEndTime && timelineStartTime < currentTime) {
				long timelineEndTime = timelineStartTime + interval;
				
				if(hs.containsKey(FunnelReportConstants.MULTISEGMENT_CRITERIA)) {				
					filter = FunnelFlexible.generateMultiSegmentCriteria(hs.get(FunnelReportConstants.MULTISEGMENT_CRITERIA), startTimeInMillis, timelineEndTime, exp);
				}
				
				BoolQueryBuilder queryToStepSession = formQueryForDataPoint(exp.getExperimentKey(),
						hourStartTime, timelineStartTime, timelineEndTime, toPath);
				FunnelFlexible.addFilterToQuery(queryToStepSession, filter);
				
				
				
				
				BoolQueryBuilder queryFromStepSession = formQueryForDataPoint(exp.getExperimentKey(),
							hourStartTime, timelineStartTime, timelineEndTime, fromPath);
				FunnelFlexible.addFilterToQuery(queryFromStepSession, filter);
				
				Long timeInChart = interval>=DAY_INTERVAL_IN_MILLIS? timelineStartTime: timelineEndTime;
				
				FiltersAggregationBuilder builder = AggregationBuilders
											         .filters(timeInChart+"",
											            new KeyedFilter("from_sessions", queryFromStepSession), //NO I18N
											            new KeyedFilter("to_sessions", queryToStepSession)); //NO I18N
				
				
				filterAggs.add(builder);
				timeMachine.add(timeInChart+"");
				timelineStartTime = timelineEndTime;
			}
			
			SearchResponse sr = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.FUNNEL_RAW_TYPE, 0, QueryBuilders.matchAllQuery(), filterAggs);
			
			for(String time: timeMachine) {
				Filters agg = sr.getAggregations().get(time);
				Long fromSteptotalSession = null,
					 toSteptotalSession = null;
				for (Filters.Bucket entry : agg.getBuckets()) {
				    String key = entry.getKeyAsString();            // bucket key
				    long docCount = entry.getDocCount();            // Doc count
				    if(key.equals("from_sessions")) {
				    	fromSteptotalSession = docCount;
				    } else if(key.equals("to_sessions")) {
				    	toSteptotalSession = docCount;
				    }
				}
				
				Long chartTime = Long.parseLong(time);
				
				totalSessions = totalSessions + fromSteptotalSession;
				totalConversions = totalConversions + toSteptotalSession;
				
				FunnelTimelineReport cumReport = new FunnelTimelineReport();
				cumReport.setSessionsCount(totalSessions);
				cumReport.setConversionCount(totalConversions);
				cumReport.computeDependentMetricValues(cumReport.getSessionsCount());
				
				FunnelTimelineReport report = new FunnelTimelineReport();
				report.setTime(chartTime);
				report.setConversionCount(toSteptotalSession);
				report.setSessionsCount(fromSteptotalSession);
				report.computeDependentMetricValues(report.getSessionsCount());
				
				report.setConversionRate(cumReport.getConversionRate());
				report.setDropRate(cumReport.getDropRate());
				
				report.setSuccess(Boolean.TRUE);
				timeLineReports.add(report);
			}
			
		}
		catch (ZABException e) {
			LOGGER.log(Level.SEVERE, "Exception occured", e);
			FunnelTimelineReport report = new FunnelTimelineReport();
			report.setSuccess(Boolean.FALSE);
			report.setResponseString(e.getMessage());
			timeLineReports.add(report);
		}
		catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Exception occured", e);
			FunnelTimelineReport report = new FunnelTimelineReport();
			report.setSuccess(Boolean.FALSE);
			report.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			timeLineReports.add(report);
		}
		
		return timeLineReports;

	}
	
}
