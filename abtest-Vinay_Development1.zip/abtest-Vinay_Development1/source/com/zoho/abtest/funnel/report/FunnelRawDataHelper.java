//$Id$
package com.zoho.abtest.funnel.report;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.persistence.WritableDataObject;
import com.zoho.abtest.BROWSER_DETAIL;
import com.zoho.abtest.COUNTRY_DETAIL;
import com.zoho.abtest.CURRENTURL_DETAIL;
import com.zoho.abtest.DEVICE_DETAIL;
import com.zoho.abtest.DYNAMIC_ATTRIBUTE_VALUES;
import com.zoho.abtest.FUNNEL_DATA_RAW_IDGEN;
import com.zoho.abtest.FUNNEL_SESSION_DETAILS;
import com.zoho.abtest.LANGUAGE_DETAIL;
import com.zoho.abtest.OS_DETAIL;
import com.zoho.abtest.REFFERERURL_DETAIL;
import com.zoho.abtest.TRAFFICSOURCE_DETAIL;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.dimension.Dimension;
import com.zoho.abtest.dimension.DimensionConstants;
import com.zoho.abtest.dimension.DimensionConstants.DynamicAttributeType;
import com.zoho.abtest.dimension.DynamicAttributes;
import com.zoho.abtest.report.ReportConstants;
import com.zoho.abtest.report.ReportRawDataConstants;
import com.zoho.abtest.utility.ZABUtil;

/**
 * @author david-3671
 *
 */
public class FunnelRawDataHelper {
	
	private static final Logger LOGGER = Logger.getLogger(FunnelRawDataHelper.class.getName());
	
	public static Long genFunnelRawDataId() {
		Long visitorDataRawId = null;
		try {
			DataObject dobj = ZABModel.createRow(FunnelReportConstants.FUNNEL_DATA_RAW_IDGEN_CONSTANTS, FUNNEL_DATA_RAW_IDGEN.TABLE, new HashMap<String, String>());
			if(dobj.containsTable(FUNNEL_DATA_RAW_IDGEN.TABLE)) {
				visitorDataRawId = (Long)dobj.getFirstRow(FUNNEL_DATA_RAW_IDGEN.TABLE).get(FUNNEL_DATA_RAW_IDGEN.FUNNEL_DATA_RAW_ID);
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Exception occured:", e);
		}
		return visitorDataRawId;
	}
	
	public static Long getSessionId(String uvid) throws Exception {
		Long sessionId = null;
		Criteria c = new Criteria(new Column(FUNNEL_SESSION_DETAILS.TABLE, FUNNEL_SESSION_DETAILS.SESSION_KEY), uvid, QueryConstants.EQUAL);
		DataObject dobj = ZABModel.getRow(FUNNEL_SESSION_DETAILS.TABLE, c);
		if(dobj.containsTable(FUNNEL_SESSION_DETAILS.TABLE)) {
			Row row = dobj.getFirstRow(FUNNEL_SESSION_DETAILS.TABLE);
			sessionId = (Long) row.get(FUNNEL_SESSION_DETAILS.FUNNEL_SESSION_ID);
		}
		return sessionId;
	}
	
	public static Long generateSessionId(String uvid, Long experimentId) throws Exception {
		Long sessionId = null;
		Row row = new Row(FUNNEL_SESSION_DETAILS.TABLE);
		row.set(FUNNEL_SESSION_DETAILS.SESSION_KEY, uvid);
		row.set(FUNNEL_SESSION_DETAILS.EXPERIMENT_ID, experimentId);
		DataObject dobj = new WritableDataObject();
		dobj.addRow(row);
		ZABModel.updateDataObject(dobj);			
		sessionId = (Long) row.get(FUNNEL_SESSION_DETAILS.FUNNEL_SESSION_ID);
		return sessionId;
	}
	
	/*
	public static String getColumnNameFromConditionType(String dimension,Long dynamicAttributeId)
	{
		String columnName = null;
		
		switch(dimension)
		{
		case ReportConstants.BROWSER:
			columnName = FUNNEL_DATA_RAW_HOUR.BROWSER_CODE;
			break;
		case ReportConstants.DEVICE:
			columnName = FUNNEL_DATA_RAW_HOUR.DEVICE_CODE;
			break;
		case ReportConstants.COUNTRY:
			columnName = FUNNEL_DATA_RAW_HOUR.COUNTRY_CODE;
			break;
		case ReportConstants.LANGUAGE: 
			columnName = FUNNEL_DATA_RAW_HOUR.LANGUAGE_CODE;
			break;
		case ReportConstants.OS: 
			columnName = FUNNEL_DATA_RAW_HOUR.OS_CODE;
			break;
		case ReportConstants.DAYOFWEEK:
			columnName = FUNNEL_DATA_RAW_HOUR.DAY_OF_WEEK;
			break;
		case ReportConstants.HOUROFDAY: 
			columnName = FUNNEL_DATA_RAW_HOUR.HOUR_OF_DAY;
			break;
		case ReportConstants.URLPARAMETER:
			columnName = FUNNEL_REPORT_HOUR_DYNS.DYN_ATTR_QP;
			columnName = "("+columnName + "->>'" + dynamicAttributeId + "')::INTEGER "; //No I18N
			break;
		case ReportConstants.COOKIE: 
			columnName = FUNNEL_REPORT_HOUR_DYNS.DYN_ATTR_COOKIE;
			columnName = "("+columnName + "->>'" + dynamicAttributeId + "')::INTEGER "; //No I18N
			break;
		case ReportConstants.JSVARIABLE: 
			columnName = FUNNEL_REPORT_HOUR_DYNS.DYN_ATTR_JSVAR;
			columnName = "("+columnName + "->>'" + dynamicAttributeId + "')::INTEGER "; //No I18N
			break;
		case ReportConstants.CUSTOMDIMENSION: 
			columnName = FUNNEL_REPORT_HOUR_DYNS.DYN_ATTR_CUSTOM;
			columnName = "("+columnName + "->>'" + dynamicAttributeId + "')::INTEGER "; //No I18N
			break;
			
		}
		return columnName;
	}*/
	
	public HashMap<String,String> getCodeValueTableDetails(String dimension)
	{
		HashMap<String,String> hs = new HashMap<String,String>();
		String tableName = null;
		String codeColumnName = null;
		String valueColumnName = null;
		switch(dimension)
		{
		case ReportConstants.BROWSER:
			tableName = BROWSER_DETAIL.TABLE;
			codeColumnName = BROWSER_DETAIL.BROWSER_CODE;
			valueColumnName = BROWSER_DETAIL.BROWSER_VALUE;
			break;
		case ReportConstants.DEVICE:
			tableName = DEVICE_DETAIL.TABLE;
			codeColumnName = DEVICE_DETAIL.DEVICE_CODE;
			valueColumnName = DEVICE_DETAIL.DEVICE_VALUE;
			break;
		case ReportConstants.COUNTRY:
			tableName = COUNTRY_DETAIL.TABLE;
			codeColumnName = COUNTRY_DETAIL.COUNTRY_CODE;
			valueColumnName = COUNTRY_DETAIL.COUNTRY_DISPLAY_NAME;
			break;
		case ReportConstants.LANGUAGE:
			tableName = LANGUAGE_DETAIL.TABLE;
			codeColumnName = LANGUAGE_DETAIL.LANGUAGE_CODE;
			valueColumnName = LANGUAGE_DETAIL.LANGUAGE_DISPLAY_NAME;
			break;
		case ReportConstants.OS:
			tableName = OS_DETAIL.TABLE;
			codeColumnName = OS_DETAIL.OS_CODE;
			valueColumnName = OS_DETAIL.OS_VALUE;
			break;
		case ReportConstants.TRAFFICSOURCE:
			tableName = TRAFFICSOURCE_DETAIL.TABLE;
			codeColumnName = TRAFFICSOURCE_DETAIL.TRAFFICSOURCE_CODE;
			valueColumnName = TRAFFICSOURCE_DETAIL.TRAFFICSOURCE_VALUE;
			break;
		case ReportConstants.REFFERERURL: 
			tableName = REFFERERURL_DETAIL.TABLE;
			codeColumnName = REFFERERURL_DETAIL.REFFERERURL_CODE;
			valueColumnName = REFFERERURL_DETAIL.REFFERERURL_VALUE;
			break;
		case ReportConstants.CURRENTURL:
			tableName = CURRENTURL_DETAIL.TABLE;
			codeColumnName = CURRENTURL_DETAIL.CURRENTURL_CODE;
			valueColumnName = CURRENTURL_DETAIL.CURRENTURL_VALUE;
			break;
		case ReportConstants.URLPARAMETER:
		case ReportConstants.COOKIE:
		case ReportConstants.JSVARIABLE:
		case ReportConstants.CUSTOMDIMENSION:
			tableName = DYNAMIC_ATTRIBUTE_VALUES.TABLE;
			codeColumnName = DYNAMIC_ATTRIBUTE_VALUES.CODE;
			valueColumnName = DYNAMIC_ATTRIBUTE_VALUES.VALUE;
			break;
		}
		hs.put("tableName", tableName);
		hs.put("codeColumnName", codeColumnName);
		hs.put("valueColumnName", valueColumnName);
		return hs;
	}
	
	public static Integer getBrowserCode(String browserValue) throws Exception {
		HashMap<String,String> browserHs = new HashMap<String,String>(); 
		browserHs.put(DimensionConstants.BROWSER_VALUE, browserValue.toUpperCase()); 
		return Dimension.getCommonDimensionCodeByValue(
				BROWSER_DETAIL.TABLE, BROWSER_DETAIL.BROWSER_CODE,
				DimensionConstants.BROWSER_CODE, BROWSER_DETAIL.BROWSER_VALUE,
				DimensionConstants.BROWSER_VALUE, browserHs,
				DimensionConstants.BROWSER_DETAIL_CONSTANTS);
	}
	
	public static Integer getDeviceCode(String deviceValue) throws Exception {
		HashMap<String,String> deviceHs = new HashMap<String,String>(); 
		deviceHs.put(DimensionConstants.DEVICE_VALUE, deviceValue.toUpperCase()); 
		return Dimension.getCommonDimensionCodeByValue(
				DEVICE_DETAIL.TABLE, DEVICE_DETAIL.DEVICE_CODE,
				DimensionConstants.DEVICE_CODE, DEVICE_DETAIL.DEVICE_VALUE,
				DimensionConstants.DEVICE_VALUE, deviceHs,
				DimensionConstants.DEVICE_DETAIL_CONSTANTS);
	}
	
	public static HashMap<String, String> getCountryNameHash(String ipAddress) throws JSONException {
		JSONObject ipDetailsJson = ZABUtil.getIpAddressDetails(ipAddress);
		String countryValue = ipDetailsJson.has("COUNTRY_CODE") ? ipDetailsJson.get("COUNTRY_CODE").toString() : "-"; //NO I18N
		String countryName = ipDetailsJson.has("COUNTRY_NAME") ? ipDetailsJson.get("COUNTRY_NAME").toString() : "-"; //NO I18N
		if(countryValue.equals("-"))
		{
			countryValue = ReportRawDataConstants.UNKNOWN_COUNTRY_CODE;
			countryName = ReportRawDataConstants.UNKNOWN_VALUE;
		}
		HashMap<String,String> countryHs = new HashMap<String,String>();
		countryHs.put(DimensionConstants.COUNTRY_VALUE, countryValue.toUpperCase()); 
		countryHs.put(DimensionConstants.COUNTRY_DISPLAY_NAME, countryName.toUpperCase());
		return countryHs;
	}
	
	public static Integer getCountryCode(HashMap<String,String> countryHs) throws Exception {

		return Dimension.getCommonDimensionCodeByValue(COUNTRY_DETAIL.TABLE,
				COUNTRY_DETAIL.COUNTRY_CODE, DimensionConstants.COUNTRY_CODE,
				COUNTRY_DETAIL.COUNTRY_VALUE, DimensionConstants.COUNTRY_VALUE,
				countryHs, DimensionConstants.COUNTRY_DETAIL_CONSTANTS);
	}
	
	public static Integer getLanguageCode(String languageValue) throws Exception {
		HashMap<String,String> languageHs = new HashMap<String,String>(); 
		languageHs.put(DimensionConstants.LANGUAGE_VALUE, languageValue.toUpperCase()); 
		String languageDisplayName = ZABUtil.getLanguageFromCode(languageValue.toUpperCase());
		languageHs.put(DimensionConstants.LANGUAGE_DISPLAY_NAME, languageDisplayName); 
		return Dimension.getCommonDimensionCodeByValue(LANGUAGE_DETAIL.TABLE,
				LANGUAGE_DETAIL.LANGUAGE_CODE,
				DimensionConstants.LANGUAGE_CODE,
				LANGUAGE_DETAIL.LANGUAGE_VALUE,
				DimensionConstants.LANGUAGE_VALUE, languageHs,
				DimensionConstants.LANGUAGE_DETAIL_CONSTANTS);
	}
	
	public static Integer getOSCode(String osValue) throws Exception {
		HashMap<String,String> osHs = new HashMap<String,String>(); 
		osHs.put(DimensionConstants.OS_VALUE, osValue.toUpperCase()); 
		return Dimension.getCommonDimensionCodeByValue(OS_DETAIL.TABLE,
				OS_DETAIL.OS_CODE, DimensionConstants.OS_CODE,
				OS_DETAIL.OS_VALUE, DimensionConstants.OS_VALUE, osHs,
				DimensionConstants.OS_DETAIL_CONSTANTS);
	}
	
	public static void updateDynamicAttributeJSON(
			HashMap<String, String> funnelData,
			HashMap<String, DynamicAttributes> dynamicAttriHs,
			String experimentIdKey, JSONObject urlParamJson,
			JSONObject cookieJson, JSONObject jsVariableJson,
			JSONObject customDimensionJson) throws JSONException {
		if(funnelData.containsKey(ReportRawDataConstants.DYNAMICATTRIBUTES)){
			JSONArray dynamicAttributeAray = new JSONArray(funnelData.get(ReportRawDataConstants.DYNAMICATTRIBUTES));
			Integer urlParamCode = DynamicAttributeType.URLPARAMETER.getAttributeTypeCode();
			Integer cookieCode = DynamicAttributeType.COOKIE.getAttributeTypeCode();
			Integer jsVariableCode = DynamicAttributeType.JSVARIABLE.getAttributeTypeCode();
			Integer customDimensionCode = DynamicAttributeType.CUSTOMDIMENSION.getAttributeTypeCode();

		       for(int i=0;i<dynamicAttributeAray.length();i++){
		    	   JSONObject dynamicAttribute = (JSONObject)dynamicAttributeAray.get(i);
		    	   String attributeLinkName =(String) dynamicAttribute.get(ReportRawDataConstants.ATTRIBUTE_LINK_NAME);
		    	   if(dynamicAttriHs.containsKey(attributeLinkName)){
		    		   Integer attributeType =(Integer) dynamicAttribute.get(ReportRawDataConstants.ATTRIBUTE_TYPE);
			    	   String attributeValue =(String) dynamicAttribute.get(ReportRawDataConstants.ATTRIBUTE_VALUE);
			    	   String attributeId =  dynamicAttriHs.get(attributeLinkName).getDynamicAttributeId().toString();
			    	   Integer code  = Dimension.getDynamicAttributeCodeByValue(Long.parseLong(attributeId),attributeValue);
			    	   if(attributeType.equals(urlParamCode)){
			    		   urlParamJson.put(attributeId, code);
			    	   }else if(attributeType.equals(cookieCode)){
			    		   cookieJson.put(attributeId, code);
			    		   
			    	   }else if(attributeType.equals(jsVariableCode)){
			    		   jsVariableJson.put(attributeId, code);
			    	   }else if(attributeType.equals(customDimensionCode)){
			    		   customDimensionJson.put(attributeId, code);
			    	   }
			    	   
			    	   dynamicAttriHs.remove(attributeLinkName);
		    	   }
		    	   
		       }
		       // DYNAMIC ATTRIBUTES WHICK ARE NOT SENT IN REQUEST ARE FILLED WITH 'UNKNOWN'
		       
		       Set<String> keySet = dynamicAttriHs.keySet();
		       Iterator<String> keysItr = keySet.iterator();
		       while(keysItr.hasNext()){
		    	  String attributeLinkName  =  keysItr.next();
		    	  DynamicAttributes da = dynamicAttriHs.get(attributeLinkName);
		    	  Integer attributeType = da.getAttributeType();	
		    	  String attributeId = da.getDynamicAttributeId().toString();	
				Integer code = Dimension.getDynamicAttributeCodeByValue(
						da.getDynamicAttributeId(),
						ReportRawDataConstants.UNKNOWN_VALUE);
		    	  if(attributeType.equals(urlParamCode)){
		    		   urlParamJson.put(attributeId, code);
		    	   }else if(attributeType.equals(cookieCode)){
		    		   cookieJson.put(attributeId, code);
		    		   
		    	   }else if(attributeType.equals(jsVariableCode)){
		    		   jsVariableJson.put(attributeId, code);
		    	   }else if(attributeType.equals(customDimensionCode)){
		    		   customDimensionJson.put(attributeId, code);
		    	   }
			    	 
		       }
		    }
		
	}
}
