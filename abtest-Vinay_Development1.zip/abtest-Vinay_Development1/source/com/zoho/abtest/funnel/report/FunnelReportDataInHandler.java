//$Id$
package com.zoho.abtest.funnel.report;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.elasticsearch.script.Script;
import org.json.JSONObject;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Operation;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.UpdateQuery;
import com.adventnet.ds.query.UpdateQueryImpl;
import com.adventnet.mfw.bean.BeanUtil;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Persistence;
import com.adventnet.persistence.Row;
import com.adventnet.persistence.WritableDataObject;
import com.zoho.abtest.FUNNEL_RAW_DATA_NODIM;
import com.zoho.abtest.FUNNEL_STEPS;
import com.zoho.abtest.FUNNEL_STEP_VISITS;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.report.ReportRawDataConstants;
import com.zoho.abtest.report.VisitorRawDataWrapper;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUtil;

public class FunnelReportDataInHandler {
	
	private static final Logger LOGGER = Logger.getLogger(FunnelReportDataInHandler.class.getName());
	

	/*
	 * Story function
	 * 
	 * */
	
	
	public static void addFunnelRawData(VisitorRawDataWrapper wrapper) {
		try {
			
			setDBSpace(wrapper.getFunnelData().get(ReportRawDataConstants.PORTAL));
			
			FunnelRawData funnelRawData = new FunnelRawData(wrapper);
			/*
			FunnelReportBean frb = (FunnelReportBean) BeanUtil.lookup("ZABFunnelBean",ZABUtil.getCurrentUserDbSpace());
			//Postgres
			frb.addFunnelRawData(funnelRawData);
			addFunnelRawNoDims(funnelRawData);
			addFunnelStepVisit(funnelRawData);
			*/
			//Elastic
			JSONObject funnelDoc = funnelRawData.getElasticFunnelDoc();
			Script updateScript = funnelRawData.getUpdateScript();
			FunnelFlexible.upsertVisitorRawDataToElasticSearch(funnelDoc,
					updateScript,
					wrapper.getFunnelData().get(ReportRawDataConstants.PORTAL),
					funnelRawData.getSessionKey());
			
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Exception occured wile adding Funnel Raw Data:", e);
		}
	}
	
	public static void addFunnelStepVisit(FunnelRawData funnelRawData) throws DataAccessException {
		//TODO: Rethink returning visitor logic
		if(!funnelRawData.getIsReturningVisit()) {
			Criteria c1 = new Criteria(new Column(FUNNEL_STEP_VISITS.TABLE,
					FUNNEL_STEP_VISITS.EXPERIMENT_ID),
					funnelRawData.getExperimentId(), QueryConstants.EQUAL);
			Criteria c2 = new Criteria(new Column(FUNNEL_STEP_VISITS.TABLE,
					FUNNEL_STEP_VISITS.STEP_ID),
					funnelRawData.getStepId(), QueryConstants.EQUAL);
			UpdateQuery uq = new UpdateQueryImpl(FUNNEL_STEP_VISITS.TABLE);
			Column incrementVisit = Column.createOperation(Operation.operationType.ADD, new Column(FUNNEL_STEP_VISITS.TABLE, FUNNEL_STEP_VISITS.VISIT_COUNT), 1);
			uq.setCriteria(c1.and(c2));
			uq.setUpdateColumn(FUNNEL_STEP_VISITS.VISIT_COUNT, incrementVisit);
			Persistence per= ZABUtil.getPersistenceBean(); 
	    	int updatedCount = per.update(uq);
	    	if(updatedCount == 0) {
	    		DataObject dobj = new WritableDataObject();
	    		Row row = new Row(FUNNEL_STEP_VISITS.TABLE);
	    		row.set(FUNNEL_STEP_VISITS.EXPERIMENT_ID, funnelRawData.getExperimentId());
	    		row.set(FUNNEL_STEP_VISITS.STEP_ID, funnelRawData.getStepId());
	    		row.set(FUNNEL_STEP_VISITS.VISIT_COUNT, 1);
	    		dobj.addRow(row);
	    		per.add(dobj);
	    	}
		}
	}
	
	public static void addFunnelRawNoDims(FunnelRawData funnelRawData) throws Exception {
		Row row = new Row(FUNNEL_RAW_DATA_NODIM.TABLE);
		row.set(FUNNEL_RAW_DATA_NODIM.EXPERIMENT_ID, funnelRawData.getExperimentId());
		row.set(FUNNEL_RAW_DATA_NODIM.STEP_ID, funnelRawData.getStepId());
		row.set(FUNNEL_RAW_DATA_NODIM.SESSION_ID, funnelRawData.getSessionId());
		row.set(FUNNEL_RAW_DATA_NODIM.TIME, funnelRawData.getTime());
		ZABModel.createResource(row);
	}
	
	/*
	 * Helper functions
	 * */
	
	private static String setDBSpace(String portalName) {
		String dbSpaceId = null;
		Long zsoid = ZABServiceOrgUtil.getZSOIDFromDomain(portalName);
		if(zsoid != null)
		{
			dbSpaceId = zsoid.toString();
		}
		else
		{
			LOGGER.log(Level.SEVERE,"Invalid portal provided :" + portalName);
		}
		ZABUtil.setDBSpace(dbSpaceId);
		return dbSpaceId;
	}
	
	private static void closeIt(Connection connection) {
		try
		{
			if(connection != null)
			{
				connection.close();
			}
		}
		catch(SQLException ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occured: ",ex);
		}
	}
	
	private static void closeIt(ResultSet res) {
		try {
			if(res!=null) {
				res.close();
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Exception occured: ",e);
		}
	}
	
	private static void closeIt(PreparedStatement stmt) {
		if (stmt != null)
		{
			try {
				stmt.close();
			} catch (SQLException e) {
				LOGGER.log(Level.SEVERE, "Exception occured: ",e);
			}
		}
	}
	
	private static void closeIt(Connection connection, ResultSet res, PreparedStatement stmt) {
		closeIt(connection);
		closeIt(res);
		closeIt(stmt);
	}
	
	
	/**
	 * @param wrapper
	 */
	/*public static void addFunnelRawData(VisitorRawDataWrapper wrapper) {
		try {
			
			setDBSpace(wrapper.getFunnelData().get(ReportRawDataConstants.PORTAL));
			
			FunnelRawData funnelRawData = new FunnelRawData(wrapper);
			
			FunnelReportBean frb = (FunnelReportBean) BeanUtil.lookup("ZABUserBean",ZABUtil.getCurrentUserDbSpace());
			//Postgres
			frb.addFunnelRawData(funnelRawData);
			//Elastic
			JSONObject funnelDoc = funnelRawData.getElasticFunnelDoc();
			FunnelFlexible.addVisitorRawDataToElasticSearch(funnelDoc, wrapper.getFunnelData().get(ReportRawDataConstants.PORTAL));
			
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Exception occured wile adding Funnel Raw Data:", e);
		}
		
	}
	
	
	public static void archiveFunnelData(Long startHourInMs, Long endHourInMs, String dbspaceId) {
		
		ArchieveCumulativeTableMeta.updateArchieveCumulativeTableMetaDetails(FUNNEL_DATA_RAW_HOUR.TABLE, endHourInMs);
		
		String funnelRawTableName = FUNNNEL_RAW_TABLE.generateRawTableName(dbspaceId, ZABUtil.getNthDayDate(startHourInMs, 0));
		
		cumulateHourWithoutDimension(funnelRawTableName, startHourInMs, endHourInMs);
		
		cumulateHourWithAllDimension(funnelRawTableName, endHourInMs);
	}
	
	
	private static void cumulateHourWithoutDimension(String funnelRawTableName, Long startHourInMs, Long endHourInMs) {
		String cumulativeNoDataAggQuery = getCumulativeNoDimAggQuery(funnelRawTableName, FunnelReportRawQueries.VISITOR_COUNT_COLUMN_NAME);
		
		Connection connection = null;
		ResultSet res = null;
		PreparedStatement stmt= null;
		DataObject dobj = new WritableDataObject();
		try
		{
			RelationalAPI relationalApi = RelationalAPI.getInstance();
			connection = relationalApi.getConnection();
			stmt = connection.prepareStatement(cumulativeNoDataAggQuery);
			stmt.setLong(1, startHourInMs);
			stmt.setLong(2, endHourInMs);
			res = stmt.executeQuery();
			while(res.next()) {
				Long experimentId = res.getLong(FUNNEL_DATA_RAW_HOUR.EXPERIMENT_ID);
				Long stepId = res.getLong(FUNNEL_DATA_RAW_HOUR.STEP_ID);
				Long count = res.getLong("VISITOR_COUNT"); //NO I18N
				Row row = new Row(FUNNEL_DATA_NODIM_HOUR.TABLE);
				row.set(FUNNEL_DATA_NODIM_HOUR.EXPERIMENT_ID, experimentId);
				row.set(FUNNEL_DATA_NODIM_HOUR.STEP_ID, stepId);
				row.set(FUNNEL_DATA_NODIM_HOUR.TIME, endHourInMs);
				row.set(FUNNEL_DATA_NODIM_HOUR.VISITOR_COUNT, count);
				dobj.addRow(row);
			}

		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occured while cumulating without dimensions: ",ex);
		}
		finally
		{
			closeIt(connection, res, stmt);
		}

		//Updating data object through persistance bean after other connections are closed
		try
		{			
			ZABModel.updateDataObject(dobj);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occured while cumulating without dimensions: ",ex);
		}
	}
	
	private static void cumulateHourWithAllDimension(String funnelRawTableName, Long endHourInMs) {
		String cumulativeNoDataAggQuery = getCumulativeAllDimAggQuery(funnelRawTableName, FunnelReportRawQueries.VISITOR_COUNT_COLUMN_NAME);
		
		Connection connection = null;
		ResultSet res = null;
		PreparedStatement stmt= null;
		DataObject dobj = new WritableDataObject();
		ArrayList<FunnelRawData> funnelRawDatas = new ArrayList<FunnelRawData>();
		try
		{
			RelationalAPI relationalApi = RelationalAPI.getInstance();
			connection = relationalApi.getConnection();
			stmt = connection.prepareStatement(cumulativeNoDataAggQuery);
			res = stmt.executeQuery();
			
			while(res.next()) {
				FunnelRawData funnelRawData = new FunnelRawData(res, FunnelReportRawQueries.VISITOR_COUNT_COLUMN_NAME);
				Criteria c = funnelRawData.getCriteriaWithBasicDimension();
				Row alreadyInserted = null;
				if(!dobj.containsTable(FUNNEL_DATA_RAW_HOUR.TABLE) || (alreadyInserted = dobj.getRow(FUNNEL_DATA_RAW_HOUR.TABLE, c)) == null) {					
					Row row = new Row(FUNNEL_DATA_RAW_HOUR.TABLE);
					row.set(FUNNEL_DATA_RAW_HOUR.EXPERIMENT_ID, funnelRawData.getExperimentId());
					row.set(FUNNEL_DATA_RAW_HOUR.STEP_ID, funnelRawData.getStepId());
					row.set(FUNNEL_DATA_RAW_HOUR.BROWSER_CODE, funnelRawData.getBrowserCode());
					row.set(FUNNEL_DATA_RAW_HOUR.DEVICE_CODE, funnelRawData.getDeviceCode());
					row.set(FUNNEL_DATA_RAW_HOUR.COUNTRY_CODE, funnelRawData.getCountryCode());
					row.set(FUNNEL_DATA_RAW_HOUR.LANGUAGE_CODE, funnelRawData.getLanguageCode());
					row.set(FUNNEL_DATA_RAW_HOUR.OS_CODE, funnelRawData.getOsCode());
					row.set(FUNNEL_DATA_RAW_HOUR.DAY_OF_WEEK, funnelRawData.getDayOfTheWeek());
					row.set(FUNNEL_DATA_RAW_HOUR.HOUR_OF_DAY, funnelRawData.getHourOfTheDay());
					funnelRawData.setNoDimRow(row);
					dobj.addRow(row);
				} else {
					funnelRawData.setNoDimRow(alreadyInserted);
				}
				
				funnelRawDatas.add(funnelRawData);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occured: ",ex);
		}
		finally
		{
			closeIt(connection, res, stmt);
		}
		
		//Updating data object through persistance bean after other connections are closed
		try
		{			
			ZABModel.updateDataObject(dobj);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occured while cumulating without dimensions: ",ex);
		}
		//Getting connection again and inserting data to aggregate table
		try
		{			
			int size = funnelRawDatas.size();
			RelationalAPI relationalApi = RelationalAPI.getInstance();
			connection = relationalApi.getConnection();
			for(int i=0; i<size; i++) {
				try {
					stmt = connection.prepareStatement(FUNNEL_HOUR_DYNS_INSERT_QUERY);
					FunnelRawData funnelRawData = funnelRawDatas.get(i);
					Long funnelReportHourId = (Long)funnelRawData.getNoDimRow().get(FUNNEL_DATA_RAW_HOUR.FUNNEL_DATA_RAW_HOUR_ID);
					stmt.setLong(1, funnelReportHourId);
					stmt.setObject(2, funnelRawData.getCookie());
					stmt.setObject(3, funnelRawData.getCustomAttribute());
					stmt.setObject(4, funnelRawData.getJsVariable());
					stmt.setObject(5, funnelRawData.getQueryParameter());
					stmt.setObject(6, funnelRawData.getCount());
					stmt.execute();
				} catch (Exception e) {
					LOGGER.log(Level.SEVERE, "Exception occured while cumulating with dimensions: ",e);
				} finally {
					closeIt(stmt);
				}
			}
			
		}catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occured while cumulating with dimensions: ",ex);
		} finally {
			closeIt(connection);
		}
	}*/
}
