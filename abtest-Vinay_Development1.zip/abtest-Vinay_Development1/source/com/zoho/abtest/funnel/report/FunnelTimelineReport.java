//$Id$
package com.zoho.abtest.funnel.report;


public class FunnelTimelineReport extends FunnelReport{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long time;

	public Long getTime() {
		return time;
	}

	public void setTime(Long time) {
		this.time = time;
	}

}
