//$Id$
package com.zoho.abtest.funnel.report;

import static com.zoho.abtest.funnel.report.FunnelReportRawQueries.getFunnelRawDataInsertQuery;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.postgresql.util.PGobject;

import com.adventnet.db.api.RelationalAPI;
import com.adventnet.mfw.bean.BeanUtil;
import com.zoho.abtest.DYNAMIC_ATTRIBUTE_VALUES;
import com.zoho.abtest.funnel.report.FunnelReportConstants.DimensionCodeValueTableDetails;
import com.zoho.abtest.user.ZABUserConstants;
import com.zoho.abtest.utility.ZABTableCreationBean;

/**
 * @author david-3671
 *
 */
public class FunnelReportBeanImpl implements FunnelReportBean {

	/**
	 * 
	 */
	private static final Logger LOGGER = Logger.getLogger(FunnelReportBeanImpl.class.getName());
	
	private PGobject getPGObject(JSONObject json) throws SQLException {
		PGobject projectJSON = new PGobject();
		projectJSON.setType("jsonb"); // No I18N
		projectJSON.setValue(json.toString());
		return projectJSON;
	}
	
	@Override
	public void addFunnelRawData(FunnelRawData rawData) throws Exception {
		
		Connection connection = null;
		PreparedStatement insertstmt = null;
		String dbspaceId = null;
		boolean isTableNotFound = false;
		try
		{
			String insertSql = getFunnelRawDataInsertQuery(dbspaceId);
			
			RelationalAPI relationalApi = RelationalAPI.getInstance();
			connection = relationalApi.getConnection();
			dbspaceId = rawData.getDbSpace();
			
			insertstmt = connection.prepareStatement(insertSql);
			
			insertstmt.setLong(1, rawData.getFunnelRawDataId());
			insertstmt.setLong(2, rawData.getExperimentId());
			insertstmt.setLong(3, rawData.getStepId());
			insertstmt.setInt(4, rawData.getBrowserCode());
			insertstmt.setInt(5, rawData.getDeviceCode());
			insertstmt.setInt(6, rawData.getCountryCode());
			insertstmt.setInt(7,rawData.getLanguageCode());
			insertstmt.setInt(8, rawData.getOsCode());
			insertstmt.setInt(9, rawData.getDayOfTheWeek());
			insertstmt.setInt(10, rawData.getHourOfTheDay());
			insertstmt.setObject(11, getPGObject(rawData.getCookie()));
			insertstmt.setObject(12, getPGObject(rawData.getQueryParameter()));
			insertstmt.setObject(13, getPGObject(rawData.getJsVariable()));
			insertstmt.setObject(14, getPGObject(rawData.getCustomAttribute()));
			insertstmt.setObject(15, rawData.getSessionId());
			insertstmt.setLong(16, rawData.getTime());
			insertstmt.executeUpdate();
			
		}
		catch (SQLException ex) {
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			if(ZABUserConstants.TABLE_NOT_FOUND_CODE.equalsIgnoreCase(ex.getSQLState()))
			{
				isTableNotFound = true;
			}
			else
			{
				throw ex;
			}
		} catch (Exception ex) {
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			throw ex;
		} finally {
			try {
				if (insertstmt != null) {
					insertstmt.close();
				}
				if (connection != null) {
					connection.close();
				}
				
				if(isTableNotFound)
				{
					try
					{
						ZABTableCreationBean userAction = (ZABTableCreationBean)BeanUtil.lookup("ZABTableCreationBean",dbspaceId);
						userAction.createFunnelRawTable(dbspaceId);
					}
					catch(Exception ex1)
					{
						LOGGER.log(Level.SEVERE,"Exception occurred while creating daily raw table at first visit entry",ex1);
						throw ex1;
					}
					addFunnelRawData(rawData);
				}
			} catch (SQLException ex) {
				LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			}

		}
	
	}
	
	public List<Integer> getCodeValues(String dimension, String queryOperator, JSONArray values, Long dynamicAttributeId)
	{
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet resultSet = null;
		List<Integer> codeValues = new ArrayList<Integer>();
		Integer valuesLength = values.length();
		try
		{
			DimensionCodeValueTableDetails dimCodeTableDetails = DimensionCodeValueTableDetails.getDetailsByCodeKey(dimension);
			String tableName = dimCodeTableDetails.getTableName();
			String codeColumnName = dimCodeTableDetails.getCodeColumnName();
			String valueColumnName = dimCodeTableDetails.getValueColumnName();
			
			String query = "SELECT "+codeColumnName+" AS CODE FROM "+tableName+" WHERE "; //No I18N
			
			if(tableName.equals(DYNAMIC_ATTRIBUTE_VALUES.TABLE))
			{
				query = query + " DYNAMIC_ATTRIBUTE_ID = ? AND "; //No I18N
			}
				
			query = query + valueColumnName + " " + queryOperator + " " +"("+StringUtils.join(Collections.nCopies(valuesLength, "?"), ",")+")";
			
			RelationalAPI relationalApi = RelationalAPI.getInstance();
			connection = relationalApi.getConnection();
			pstmt = connection.prepareStatement(query);
			int index = 1;
			
			if(tableName.equals(DYNAMIC_ATTRIBUTE_VALUES.TABLE))
			{
				pstmt.setLong(index++, dynamicAttributeId);
			}
			for(int i=0; i<valuesLength; i++) {				
				pstmt.setString(index++, values.getString(i));
			}
			
			resultSet = pstmt.executeQuery();
			
			while(resultSet.next())
			{
				codeValues.add(resultSet.getInt("CODE")); //No I18N
			}
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			codeValues = new ArrayList<Integer>();
		}
		finally
		{
			try
			{
				if(resultSet != null)
				{
					resultSet.close();
				}
				if(pstmt != null)
				{
					pstmt.close();
				}
				if(connection != null)
				{
					connection.close();
				}
			}
			catch(Exception ex)
			{
				LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			}
		}
		return codeValues;
	}
	
	public List<Integer> getCodeValues(String dimension, String queryOperator, String value, Long dynamicAttributeId)
	{
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet resultSet = null;
		List<Integer> codeValues = new ArrayList<Integer>();
		try
		{
			DimensionCodeValueTableDetails dimCodeTableDetails = DimensionCodeValueTableDetails.getDetailsByCodeKey(dimension);
			String tableName = dimCodeTableDetails.getTableName();
			String codeColumnName = dimCodeTableDetails.getCodeColumnName();
			String valueColumnName = dimCodeTableDetails.getValueColumnName();
			
			String query = "SELECT "+codeColumnName+" AS CODE FROM "+tableName+" WHERE "; //No I18N
			
			if(tableName.equals(DYNAMIC_ATTRIBUTE_VALUES.TABLE))
			{
				query = query + " DYNAMIC_ATTRIBUTE_ID = ? AND "; //No I18N
			}
				
			query = query + valueColumnName + " " + queryOperator + " ?";
			
			RelationalAPI relationalApi = RelationalAPI.getInstance();
			connection = relationalApi.getConnection();
			pstmt = connection.prepareStatement(query);
			int index = 1;
			
			if(tableName.equals(DYNAMIC_ATTRIBUTE_VALUES.TABLE))
			{
				pstmt.setLong(index++, dynamicAttributeId);
			}
			pstmt.setString(index++, value);
			
			resultSet = pstmt.executeQuery();
			
			while(resultSet.next())
			{
				codeValues.add(resultSet.getInt("CODE")); //No I18N
			}
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			codeValues = new ArrayList<Integer>();
		}
		finally
		{
			try
			{
				if(resultSet != null)
				{
					resultSet.close();
				}
				if(pstmt != null)
				{
					pstmt.close();
				}
				if(connection != null)
				{
					connection.close();
				}
			}
			catch(Exception ex)
			{
				LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			}
		}
		return codeValues;
	}

	@Override
	public Long getSessionCountForStepNoDims(Long experimentId, Long stepId,
			Long startDate, Long endDate,
			String pathPattern, ArrayList<Long> previousStepIds) {
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet resultSet = null;
		Long count = 0l;
		try
		{
			
			String query = FunnelReportRawQueries.getFunnelReportNoDimsQuery(previousStepIds.size()+1);
			
			RelationalAPI relationalApi = RelationalAPI.getInstance();
			connection = relationalApi.getConnection();
			pstmt = connection.prepareStatement(query);
			int index = 1;
			pstmt.setLong(index++, startDate);
			pstmt.setLong(index++, endDate);
			pstmt.setLong(index++, experimentId);
			for(int i = 0; i < previousStepIds.size(); i++) {
				pstmt.setLong(index++, previousStepIds.get(i));
			}
			pstmt.setLong(index++, stepId);
			pstmt.setString(index, pathPattern);
			
			resultSet = pstmt.executeQuery();
			
			if(resultSet.next())
			{
				count = resultSet.getLong("COUNT"); //NO I18N
			}
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		finally
		{
			try
			{
				if(resultSet != null)
				{
					resultSet.close();
				}
				if(pstmt != null)
				{
					pstmt.close();
				}
				if(connection != null)
				{
					connection.close();
				}
			}
			catch(Exception ex)
			{
				LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			}
		}
		
		return count;
	}

}
