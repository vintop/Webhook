//$Id$
package com.zoho.abtest.funnel.report;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.DataSet;
import com.adventnet.ds.query.GroupByClause;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.ds.query.SelectQueryImpl;
import com.adventnet.ds.query.Table;
import com.adventnet.mfw.bean.BeanUtil;
import com.zoho.abtest.ABSPLITEXPERIMENT;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.FUNNEL_RAW_DATA_NODIM;
import com.zoho.abtest.common.MatchType;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.dimension.DynamicAttributes;
import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.experiment.ABSplitExperiment;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.funnel.FunnelAnalysis;
import com.zoho.abtest.funnel.report.FunnelReportConstants.ConditionTypes;
import com.zoho.abtest.funnel.report.FunnelReportConstants.DimensionCodeValueTableDetails;
import com.zoho.abtest.funnel.report.FunnelReportConstants.OperatorTypes;
import com.zoho.abtest.report.ElasticSearchConstants.FunnelRawDataType.FunnelStep;
import com.zoho.abtest.utility.DataSetWrapper;
import com.zoho.abtest.utility.ZABUserBean;
import com.zoho.abtest.utility.ZABUtil;

public class FunnelReport extends ZABModel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long experimentId;
	
	private Long stepId;
	
	private String experimentLinkname;
	
	private String stepLinkname;
	
	private Long sessionsCount;
	
	private Long conversionCount;
	
	private Long dropCount;
	
	private Float conversionRate;
	
	private Float dropRate;
	
	private Double averageTimeSpentForStep = null;
	
	private Double overallAverageTime = null;

	public Float getConversionRate() {
		return conversionRate;
	}

	public void setConversionRate(Float conversionRate) {
		this.conversionRate = conversionRate;
	}

	public Float getDropRate() {
		return dropRate;
	}

	public void setDropRate(Float dropRate) {
		this.dropRate = dropRate;
	}

	public Long getSessionsCount() {
		return sessionsCount;
	}

	public void setSessionsCount(Long sessionsCount) {
		this.sessionsCount = sessionsCount;
	}

	public Long getExperimentId() {
		return experimentId;
	}

	public void setExperimentId(Long experimentId) {
		this.experimentId = experimentId;
	}

	public Long getStepId() {
		return stepId;
	}

	public void setStepId(Long stepId) {
		this.stepId = stepId;
	}

	public String getExperimentLinkname() {
		return experimentLinkname;
	}

	public void setExperimentLinkname(String experimentLinkname) {
		this.experimentLinkname = experimentLinkname;
	}

	public String getStepLinkname() {
		return stepLinkname;
	}

	public void setStepLinkname(String stepLinkname) {
		this.stepLinkname = stepLinkname;
	}

	public Long getConversionCount() {
		return conversionCount;
	}

	public void setConversionCount(Long conversionCount) {
		this.conversionCount = conversionCount;
	}

	public Long getDropCount() {
		return dropCount;
	}

	public void setDropCount(Long dropCount) {
		this.dropCount = dropCount;
	}
	
	public Double getAverageTimeSpentForStep() {
		return averageTimeSpentForStep;
	}

	public void setAverageTimeSpentForStep(Double averageTimeSpentForStep) {
		this.averageTimeSpentForStep = averageTimeSpentForStep;
	}

	public Double getOverallAverageTime() {
		return overallAverageTime;
	}

	public void setOverallAverageTime(Double overallAverageTime) {
		this.overallAverageTime = overallAverageTime;
	}

	public static Long getTotalSessionsofStepNoDims(Long experimentId, Long stepId, Long startDate, Long endDate) throws Exception {
		Long totalCount = 0l;
		Criteria c1 = new Criteria(new Column(FUNNEL_RAW_DATA_NODIM.TABLE, FUNNEL_RAW_DATA_NODIM.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
		Criteria c2 = new Criteria(new Column(FUNNEL_RAW_DATA_NODIM.TABLE, FUNNEL_RAW_DATA_NODIM.STEP_ID), stepId, QueryConstants.EQUAL);
		
		Criteria c3 = new Criteria(new Column(FUNNEL_RAW_DATA_NODIM.TABLE, FUNNEL_RAW_DATA_NODIM.TIME), new Long[]{startDate, endDate}, QueryConstants.BETWEEN);
		
		SelectQuery query = new SelectQueryImpl(new Table(FUNNEL_RAW_DATA_NODIM.TABLE));
		query.addSelectColumn(new Column(FUNNEL_RAW_DATA_NODIM.TABLE, FUNNEL_RAW_DATA_NODIM.EXPERIMENT_ID));
		query.addSelectColumn(new Column(FUNNEL_RAW_DATA_NODIM.TABLE, FUNNEL_RAW_DATA_NODIM.STEP_ID));
		Column column = new Column(FUNNEL_RAW_DATA_NODIM.TABLE, FUNNEL_RAW_DATA_NODIM.SESSION_ID).distinct().count();
		column.setColumnAlias("SESSION_COUNT");
		query.addSelectColumn(column);
		query.setCriteria(c1.and(c2).and(c3));
		GroupByClause gc = new GroupByClause(Arrays.asList(new Column(
				FUNNEL_RAW_DATA_NODIM.TABLE,
				FUNNEL_RAW_DATA_NODIM.EXPERIMENT_ID), new Column(
				FUNNEL_RAW_DATA_NODIM.TABLE, FUNNEL_RAW_DATA_NODIM.STEP_ID)));
		query.setGroupByClause(gc);
		
		final ArrayList<Long> valueBuffer = new ArrayList<Long>();
		
		ZABUserBean bean= (ZABUserBean)BeanUtil.lookup(ZABUserBean.BEAN_NAME, ZABUtil.getCurrentUserDbSpace());
		bean.executeQuery(query, new DataSetWrapper() {
			@Override
			public void execute(DataSet ds) throws Exception {
				if(ds.next()) {		
					valueBuffer.add(new Long((Integer)ds.getValue("SESSION_COUNT"))); //NO I18N
				}
			}
		});
		
		if(valueBuffer.size() > 0) {
			totalCount = valueBuffer.get(0);
		}
		return totalCount;
	}
	
	public void computeDependentMetricValues(Long totalVisits) {
		//Conversion rate
		if((this.getSessionsCount()!=null && this.getSessionsCount() > 0)) {	
			   Long conversionCount = this.getConversionCount()!=null?this.getConversionCount():0l;
			   if(conversionCount == 0) {
//				   this.setConversionRate(0f);
				   this.setDropCount(this.getSessionsCount());
				   this.setDropRate(100f);
			   } else {				   
//				   Float conversionPercent = (this.getConversionCount().floatValue() / this.getSessionsCount().floatValue())*100;
//				   this.setConversionRate(conversionPercent);
				   Long dropCount = this.getSessionsCount() - this.getConversionCount();
				   this.setDropCount(dropCount);
				   Float dropPercent = (this.getDropCount().floatValue() / this.getSessionsCount().floatValue())*100;
				   this.setDropRate(dropPercent);
			   }
			   
		} else {
			this.setConversionRate(0f);
			this.setDropCount(0l);
			this.setDropRate(0f);
		}
		
		if(totalVisits!=null && totalVisits > 0) {
			if(this.getConversionCount() == 0) {
				this.setConversionRate(0f);
			} else {				
				Float conversionPercent = (this.getConversionCount().floatValue() / totalVisits)*100;
				this.setConversionRate(conversionPercent);
			}
		}
	}
	
	public static ArrayList<FunnelReport> getFunnelReportWithoutDims(Long startTimeInMillis, Long endTimeInMillis,final String experimentLinkname) throws Exception {
		Long experimentId = Experiment.getExperimentId(experimentLinkname);
		FunnelAnalysis analysis = FunnelAnalysis.getFunnelAnalysisWithSteps(experimentLinkname);
		if(experimentId == null) {
			throw new ZABException(ZABAction.getMessage(ZABAction.getMessage(ZABConstants.RESOURCE_WITHLNAME_NOTEXISTS, new String[] {ZABAction.getMessage(ExperimentConstants.API_RESOURCE_INITIAL), experimentLinkname})));
		}
		
		int size = analysis.getSteps().size();
		
		ArrayList<FunnelReport> funnelReports = new ArrayList<FunnelReport>();
		FunnelReportBean frb = (FunnelReportBean) BeanUtil.lookup("ZABFunnelBean",ZABUtil.getCurrentUserDbSpace());
		String pathPattern = "%";
		ArrayList<Long> previousStepIds = new ArrayList<Long>();
		Long totalVisits = 0l;
		for(int i = 0; i < size; i++) {
			if(i == 0) {
				//Compute total session
				Long totalSession = getTotalSessionsofStepNoDims(experimentId, analysis.getSteps().get(i).getStepId(), startTimeInMillis, endTimeInMillis);
				pathPattern = pathPattern + analysis.getSteps().get(i).getStepId() + "%";
				FunnelReport report = new FunnelReport();
				report.setSessionsCount(totalSession);
				totalVisits = totalSession;
				report.setExperimentId(experimentId);
				report.setStepId(analysis.getSteps().get(i).getStepId());
				report.setStepLinkname(analysis.getSteps().get(i).getStepLinkname());
				report.setExperimentLinkname(experimentLinkname);
				report.setSuccess(Boolean.TRUE);
				funnelReports.add(report);
				previousStepIds.add(analysis.getSteps().get(i).getStepId());
			} else {
				pathPattern = pathPattern + analysis.getSteps().get(i).getStepId() +  "%" ;
				FunnelReport report = new FunnelReport();
				Long totalSession = frb.getSessionCountForStepNoDims(experimentId,
						analysis.getSteps().get(i).getStepId(),
						startTimeInMillis, endTimeInMillis, 
						pathPattern, previousStepIds);
				
				FunnelReport previousStepReport = funnelReports.get(i-1);
				previousStepReport.setConversionCount(totalSession);
				previousStepReport.computeDependentMetricValues(totalVisits);
				
				report.setSessionsCount(totalSession);
				report.setExperimentId(experimentId);
				report.setStepId(analysis.getSteps().get(i).getStepId());
				report.setStepLinkname(analysis.getSteps().get(i).getStepLinkname());
				report.setExperimentLinkname(experimentLinkname);
				report.setSuccess(Boolean.TRUE);
				funnelReports.add(report);
				previousStepIds.add(analysis.getSteps().get(i).getStepId());
			}
		}
	
		return funnelReports;
	}
	
	/*public static ArrayList<FunnelReport> getFunnelReportWithoutDims(Long startTimeInMillis, Long endTimeInMillis,final String experimentLinkname) throws Exception {
		
		Long experimentId = Experiment.getExperimentId(experimentLinkname);
		if(experimentId == null) {
			throw new ZABException(ZABAction.getMessage(ZABAction.getMessage(ZABConstants.RESOURCE_WITHLNAME_NOTEXISTS, new String[] {ZABAction.getMessage(ExperimentConstants.API_RESOURCE_INITIAL), experimentLinkname})));
		}
		
		final ArrayList<FunnelReport> funnelReports = new ArrayList<FunnelReport>();
		Criteria c1 = new Criteria(new Column(FUNNEL_DATA_NODIM_HOUR.TABLE, FUNNEL_DATA_NODIM_HOUR.TIME), new Long[]{startTimeInMillis, endTimeInMillis}, QueryConstants.BETWEEN);
		Criteria c2 = new Criteria(new Column(FUNNEL_DATA_NODIM_HOUR.TABLE, FUNNEL_DATA_NODIM_HOUR.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
		
		
		SelectQuery selectQuery = new SelectQueryImpl(new Table(FUNNEL_DATA_NODIM_HOUR.TABLE));
		selectQuery.setCriteria(c1.and(c2));
		Column sum = new Column(FUNNEL_DATA_NODIM_HOUR.TABLE, FUNNEL_DATA_NODIM_HOUR.VISITOR_COUNT).summation();
		Column expId = new Column(FUNNEL_DATA_NODIM_HOUR.TABLE, FUNNEL_DATA_NODIM_HOUR.EXPERIMENT_ID);
		Column stepId = new Column(FUNNEL_DATA_NODIM_HOUR.TABLE, FUNNEL_DATA_NODIM_HOUR.STEP_ID);
		sum.setColumnAlias(FunnelReportConstants.VISITOR_COUNT);
		selectQuery.addSelectColumn(sum);
		selectQuery.addSelectColumn(expId);
		selectQuery.addSelectColumn(stepId);
		GroupByClause gc = new GroupByClause(Arrays.asList(new Column(FUNNEL_DATA_NODIM_HOUR.TABLE, FUNNEL_DATA_NODIM_HOUR.EXPERIMENT_ID),
				new Column(FUNNEL_DATA_NODIM_HOUR.TABLE, FUNNEL_DATA_NODIM_HOUR.STEP_ID)));
		selectQuery.setGroupByClause(gc);
		
		ZABUserBean bean= (ZABUserBean)BeanUtil.lookup(ZABUserBean.BEAN_NAME, ZABUtil.getCurrentUserDbSpace());
		bean.executeQuery(selectQuery, new DataSetWrapper() {
			@Override
			public void execute(DataSet ds) throws Exception {
				while(ds.next()) {
					//TODO: Need to set step linkname
					Long experimentId = (Long)ds.getValue(FUNNEL_DATA_NODIM_HOUR.EXPERIMENT_ID);
					Long stepId = (Long)ds.getValue(FUNNEL_DATA_NODIM_HOUR.STEP_ID);
					Long count = (Long)ds.getValue(FunnelReportConstants.VISITOR_COUNT);
					FunnelReport funnelReport = new FunnelReport();
					funnelReport.setConversionCount(count);
					funnelReport.setExperimentId(experimentId);
					funnelReport.setExperimentLinkname(experimentLinkname);
					funnelReport.setStepId(stepId);
					funnelReport.setSuccess(Boolean.TRUE);
					funnelReports.add(funnelReport);
				}
			}
		});
		return funnelReports;
	}*/
	
	public static String buildCriteriaForSegment(String multiSegmentCriteria) throws Exception {
		String rootConditionStr = "";
		
		ArrayList<Integer> valueList = new ArrayList<Integer>();
		
		JSONObject json = new JSONObject(multiSegmentCriteria);
		
		JSONArray conditions = new JSONArray(json.getString(FunnelReportConstants.CONDITIONS));
		Integer conditionType =  json.getInt(FunnelReportConstants.CONDITION_TYPE);
		
		
		ArrayList<String> rootConditionsList = new ArrayList<String>();
		ConditionTypes ctype = ConditionTypes.getConditionTypeByNumber(conditionType);
		String rootOperation = ctype.toString();
		
		int conditionLength = conditions.length();
		for(int i = 0; i < conditionLength; i++) {
			JSONObject eachCondition = conditions.getJSONObject(i);
			Integer innerconditionType =  eachCondition.getInt(FunnelReportConstants.CONDITION_TYPE);
			
			ConditionTypes innerctype = ConditionTypes.getConditionTypeByNumber(innerconditionType);
			String subOperation = innerctype.toString();
			ArrayList<String> conditionsList = new ArrayList<String>();
			String conditionStr = "";
			
			JSONArray innerconditions = eachCondition.getJSONArray(FunnelReportConstants.CONDITIONS);
			
			int innerConditionLength = innerconditions.length();
			ArrayList<String> conditionList = new ArrayList<String>();
			for(int j = 0; j < innerConditionLength; j++) {
				JSONObject econd = innerconditions.getJSONObject(j);
				String type = econd.getString(FunnelReportConstants.TYPE);
				JSONArray values = econd.getJSONArray(FunnelReportConstants.VALUES);
				
				Integer operator = econd.getInt(FunnelReportConstants.OPERATOR);
				OperatorTypes opType = OperatorTypes.getMatchTypeByNumber(operator);
				
				//TODO Applicable for Dynamic attributes - consider sending the linkname and not name
				String dynamicAttributeLinkName = null;  
				
				if(econd.has(FunnelReportConstants.ATTRIBUTENAME))
				{
					dynamicAttributeLinkName = econd.getString(FunnelReportConstants.ATTRIBUTENAME);
				}
				
				Long dynamicAttributeId = null;
				if(dynamicAttributeLinkName != null && !dynamicAttributeLinkName.isEmpty())
				{
					dynamicAttributeId = DynamicAttributes.getDynamicAttributesIdByLinkName(dynamicAttributeLinkName);
				}
				//TODO:
				String sqlColumnName = "TODO";//NO I18N
				//FunnelRawDataHelper.getColumnNameFromConditionType(type,dynamicAttributeId);
				FunnelReportBean funnelBean = (FunnelReportBean)BeanUtil.lookup("ZABFunnelBean", ZABUtil.getCurrentUserDbSpace());
				List<Integer> codeValues = new ArrayList<Integer>();
				String queryOperator = "";
				switch(opType) {
					case EQUALS:
						//IN 
						//IN
						queryOperator = "IN"; //NO I18N
						codeValues = funnelBean.getCodeValues(type, "IN", values, dynamicAttributeId); //NO I18N
						break;
					case NOT_EQUALS:
						//NOT IN
						//NOT IN
						queryOperator = "NOT IN"; //NO I18N
						codeValues = funnelBean.getCodeValues(type, "NOT IN", values, dynamicAttributeId); //NO I18N
						break;
					case CONTAINS:
					{
						//IN
						//LIKE
						queryOperator = "IN"; //NO I18N
						String value = "%"+values.getString(0)+"%";
						codeValues = funnelBean.getCodeValues(type, "LIKE", value, dynamicAttributeId); //NO I18N
						break;
					}
					case NOT_CONTAINS:
					{
						//NOT IN
						//LIKE
						queryOperator = "NOT IN"; //NO I18N
						String value = "%"+values.getString(0)+"%";
						codeValues = funnelBean.getCodeValues(type, "LIKE", value, dynamicAttributeId); //NO I18N
						break;
					}
					case STARTS_WITH:
					{
						//NOT IN
						//LIKE
						queryOperator = "IN"; //NO I18N
						String value = values.getString(0)+"%";
						codeValues = funnelBean.getCodeValues(type, "LIKE", value, dynamicAttributeId); //NO I18N
						break;
					}
					case ENDS_WITH:
					{
						//NOT IN
						//LIKE
						queryOperator = "IN"; //NO I18N
						String value = "%"+values.getString(0);
						codeValues = funnelBean.getCodeValues(type, "LIKE", value, dynamicAttributeId); //NO I18N
						break;
					}
					case REGEX:
						//IN
						//~
						queryOperator = "IN"; //NO I18N
						codeValues = funnelBean.getCodeValues(type, "~", values.getString(0), dynamicAttributeId);
						break;
				}
				valueList.addAll(codeValues);
				
				int valueSize = codeValues.size();
				String codeParams = StringUtils.join(Collections.nCopies(valueSize, "?"), ",");
				
				String dynamicCodeParams;
				if(valueSize>0)
				{
					dynamicCodeParams = "(" + codeParams + ")";
				}
				else
				{
					//TODO have to verify this - if the values not present 
					dynamicCodeParams = "(-1)";
				}
				
				String queryCriteria = "(" + sqlColumnName + queryOperator + dynamicCodeParams + ")";
				
				conditionList.add(queryCriteria);
			}
			conditionStr =  StringUtils.join(conditionsList, subOperation);
			
			rootConditionsList.add("("+conditionStr+")");
			
		}
		rootConditionStr = StringUtils.join(rootConditionsList, rootOperation);
		return rootConditionStr;
	}
	
	public static ArrayList<FunnelReport> getFunnelReportWithDimensionFilter(
			Long startTimeInMillis, Long endTimeInMillis,
			String experimentLinkname, String multiSegmentCriteria)
			throws JSONException {
		
		
		
		return null;
	}
	
	public static ArrayList<FunnelReport> getMockFunnelReportWithoutDims(Long startTimeInMillis, Long endTimeInMillis,final String experimentLinkname) throws Exception {
		Long experimentId = Experiment.getExperimentId(experimentLinkname);
		FunnelAnalysis analysis = FunnelAnalysis.getFunnelAnalysisWithSteps(experimentLinkname);
		if(experimentId == null) {
			throw new ZABException(ZABAction.getMessage(ZABAction.getMessage(ZABConstants.RESOURCE_WITHLNAME_NOTEXISTS, new String[] {ZABAction.getMessage(ExperimentConstants.API_RESOURCE_INITIAL), experimentLinkname})));
		}
		
		int size = analysis.getSteps().size();
		
		ArrayList<FunnelReport> funnelReports = new ArrayList<FunnelReport>();
		String pathPattern = "";
		ArrayList<Long> previousStepIds = new ArrayList<Long>();
		for(int i = 0; i < size; i++) {
			if(i == 0) {
				//Compute total session
				Long totalSession = 1000l;
				pathPattern = analysis.getSteps().get(i).getStepId() + "";
				FunnelReport report = new FunnelReport();
				report.setSessionsCount(totalSession);
				report.setExperimentId(experimentId);
				report.setStepId(analysis.getSteps().get(i).getStepId());
				report.setStepLinkname(analysis.getSteps().get(i).getStepLinkname());
				report.setExperimentLinkname(experimentLinkname);
				report.setSuccess(Boolean.TRUE);
				funnelReports.add(report);
				previousStepIds.add(analysis.getSteps().get(i).getStepId());
			} else {
				pathPattern = pathPattern + "," + analysis.getSteps().get(i).getStepId();
				FunnelReport report = new FunnelReport();
				Long totalSession = (1000l/(i+1));
				funnelReports.get(i-1).setConversionCount(totalSession);
				report.setSessionsCount(totalSession);
				report.setExperimentId(experimentId);
				report.setStepId(analysis.getSteps().get(i).getStepId());
				report.setStepLinkname(analysis.getSteps().get(i).getStepLinkname());
				report.setExperimentLinkname(experimentLinkname);
				report.setSuccess(Boolean.TRUE);
				funnelReports.add(report);
				previousStepIds.add(analysis.getSteps().get(i).getStepId());
			}
		}
	
		return funnelReports;
	}
	
	public static ArrayList<FunnelReport> getMockFunnelReports(HashMap<String, String> hs) {
		ArrayList<FunnelReport> funnelReports = new ArrayList<FunnelReport>();
		try {
			
			String startDate = hs.get(FunnelReportConstants.START_DATE);
			String endDate = hs.get(FunnelReportConstants.END_DATE);
			String experimentLinkname = hs.get(FunnelReportConstants.EXPERIMENT_LINKNAME);
			
			Long startTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(startDate, FunnelReportConstants.FUN_REPORT_DATE_FORMAT);
			Long endTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(endDate, FunnelReportConstants.FUN_REPORT_DATE_FORMAT);
			funnelReports = getMockFunnelReportWithoutDims(startTimeInMillis, endTimeInMillis, experimentLinkname);
		} catch (Exception e) {
			FunnelReport funnelReport = new FunnelReport();
			funnelReport.setSuccess(Boolean.FALSE);
			funnelReport.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			funnelReports.add(funnelReport);
		}
		return funnelReports;
	}
	
	public static ArrayList<FunnelReport> getFunnelReports(HashMap<String, String> hs) {
		
		ArrayList<FunnelReport> funnelReports = new ArrayList<FunnelReport>();
		try {
			
			String startDate = hs.get(FunnelReportConstants.START_DATE);
			String endDate = hs.get(FunnelReportConstants.END_DATE);
			String experimentLinkname = hs.get(FunnelReportConstants.EXPERIMENT_LINKNAME);
			
			Long startTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(startDate, FunnelReportConstants.FUN_REPORT_DATE_FORMAT);
			Long endTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(endDate, FunnelReportConstants.FUN_REPORT_DATE_FORMAT);
			endTimeInMillis = ZABUtil.getNthDayDateInLong(endTimeInMillis, 1) - 1;
			
			if(hs.containsKey(FunnelReportConstants.MULTISEGMENT_CRITERIA)) {
				//Without segment
				getFunnelReportWithDimensionFilter(startTimeInMillis,
						endTimeInMillis, experimentLinkname,
						hs.get(FunnelReportConstants.MULTISEGMENT_CRITERIA));
			} else {				
				//Without segment
				funnelReports = getFunnelReportWithoutDims(startTimeInMillis, endTimeInMillis, experimentLinkname);
			}
			
		} catch (Exception e) {
			FunnelReport funnelReport = new FunnelReport();
			funnelReport.setSuccess(Boolean.FALSE);
			funnelReport.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			funnelReports.add(funnelReport);
		}
		return funnelReports;
	}
	
}
