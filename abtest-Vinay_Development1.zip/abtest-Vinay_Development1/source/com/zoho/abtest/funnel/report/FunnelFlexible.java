//$Id$
package com.zoho.abtest.funnel.report;

import static com.zoho.abtest.funnel.report.FlexibleQueryConstants.AVERAGE_TIME_ON_STEP;
import static com.zoho.abtest.funnel.report.FlexibleQueryConstants.ELASTIC_NODIM_QUERY_SCRIPT_INVERTABLE;
import static com.zoho.abtest.funnel.report.FlexibleQueryConstants.ELASTIC_SEARCH_DEEP_FILTER;
import static com.zoho.abtest.funnel.report.FlexibleQueryConstants.ELASTIC_STEP_AVERAGE_TIME;
import static com.zoho.abtest.funnel.report.FlexibleQueryConstants.ELASTIC_STEP_VISIT_COUNT;
import static com.zoho.abtest.funnel.report.FlexibleQueryConstants.ELASTIC_TC_QUERY_SCRIPT;
import static com.zoho.abtest.funnel.report.FlexibleQueryConstants.END_TIME;
import static com.zoho.abtest.funnel.report.FlexibleQueryConstants.OFF_FLAG;
import static com.zoho.abtest.funnel.report.FlexibleQueryConstants.ON_FLAG;
import static com.zoho.abtest.funnel.report.FlexibleQueryConstants.ORDER;
import static com.zoho.abtest.funnel.report.FlexibleQueryConstants.PAINLESS;
import static com.zoho.abtest.funnel.report.FlexibleQueryConstants.START_TIME;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;
import org.apache.lucene.search.join.ScoreMode;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.NestedQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.script.Script;
import org.elasticsearch.script.ScriptType;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.filter.Filter;
import org.elasticsearch.search.aggregations.bucket.nested.Nested;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.aggregations.metrics.avg.Avg;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.adventnet.iam.IAMUtil;
import com.zoho.abtest.audience.AudienceAttributeConstants.AudienceAttributeMatchTypes;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.elastic.ESQuickFilterConstants;
import com.zoho.abtest.elastic.ElasticSearchStatistics;
import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.funnel.FunnelAnalysis;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.report.ReportConstants;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUtil;


/**
 * @author david-3671
 * Util class handling elastic search operations of Funnel
 */
public class FunnelFlexible {
	
	private static final Logger LOGGER = Logger.getLogger(FunnelFlexible.class.getName());
	
	
	
	public static void upsertVisitorRawDataToElasticSearch(JSONObject jsonObject, Script updateScript, String portal, String id) throws NumberFormatException, Exception {
		
			LOGGER.log(Level.INFO,"Elastic search funnel rawdata push started");
			Long zsoid = ZABServiceOrgUtil.getZSOIDFromDomain(portal);
			if(zsoid == null)
			{
				LOGGER.log(Level.SEVERE,"Invalid portal provided :"+portal);
			}
			String index = ElasticSearchUtil.getIndexByPortal(portal);
			String type = ElasticSearchConstants.FUNNEL_RAW_TYPE;
			jsonObject.put(ElasticSearchConstants.PORTAL, portal);
			jsonObject.put(ElasticSearchConstants.ZSOID, zsoid);
			try {
				ElasticSearchUtil.upsertIndex(index, type, id,jsonObject.toString(), updateScript, 5);
			} catch (Exception e) {
				LOGGER.log(Level.SEVERE, e.getMessage(),e);
			}
			LOGGER.log(Level.INFO,"Elastic search funnel rawdata push completed");
	}
	
	public static ArrayList<String> getAllVisitorswithQPKey(String queryParamKey, String multiSegmentCriteria, Long startDateInMillis, Long endDateInMillis, String experimentLinkName) throws Exception {
		
		
		FunnelAnalysis analysis = FunnelAnalysis.getFunnelAnalysisWithSteps(experimentLinkName);
		
		Long firstStepId = analysis.getSteps().get(0).getStepId();
		
		//Query
		BoolQueryBuilder builder = formFunnelQueryForTotalSessions(startDateInMillis,
				endDateInMillis,
				analysis.getExperimentKey(), firstStepId);

		return getValuesWithQPKey(queryParamKey, multiSegmentCriteria, builder, startDateInMillis, endDateInMillis, analysis);
	}
	
	private static ArrayList<String> getValuesWithQPKey(String queryParamKey, String multiSegmentCriteria, BoolQueryBuilder builder,  Long startDateInMillis, Long endDateInMillis, FunnelAnalysis analysis) throws Exception {
				
		String portalName = null;
		ArrayList<String> gclids = new ArrayList<String>();
		try{
			portalName = IAMUtil.getCurrentServiceOrg().getDomains().get(0).getDomain();
		}catch(Exception e){
			portalName =  ZABUtil.getPortaldomain();
			if(portalName == null){
				throw new Exception();
			}
		}
		
		Long firstStepId = analysis.getSteps().get(0).getStepId();
		
		String indexName = ElasticSearchUtil.getIndexByPortal(portalName);
		//Segmentation
		if(multiSegmentCriteria!=null) {
			QueryBuilder filterBuilder = generateMultiSegmentCriteria(multiSegmentCriteria, startDateInMillis, endDateInMillis, analysis);
			addFilterToQuery(builder, filterBuilder);
		}
		
		//Aggregations for getting gclids
		QueryBuilder query = QueryBuilders
				.boolQuery()
				.must(QueryBuilders.termQuery("steps.stepid", firstStepId)) //NO I18N
				.must(QueryBuilders.rangeQuery("steps.time") //NO I18N
						.gte(startDateInMillis).lte(endDateInMillis));
		
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("key", queryParamKey);
		
		Script script = new Script(ScriptType.INLINE, PAINLESS,
				FlexibleQueryConstants.ELASTIC_GCLID_AGG_SCRIPT, params);
		
		
		AggregationBuilder aggs = AggregationBuilders.nested("level1", "steps").subAggregation( //NO I18N
				AggregationBuilders.filter("filter", query).subAggregation( //NO I18N
						AggregationBuilders.nested("level2", //NO I18N
								"steps.nurlparameter").subAggregation(AggregationBuilders.terms("gclid").script(script).size(Integer.MAX_VALUE)))); //NO I18N
		
		SearchResponse sr = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.FUNNEL_RAW_TYPE, 0, builder, aggs);
		
		Nested level1 = sr.getAggregations().get("level1"); //NO I18N
		Filter filterAgg = level1.getAggregations().get("filter"); //NO I18N
		
		Nested level2 = filterAgg.getAggregations().get("level2"); //NO I18N
		Terms termAgg = level2.getAggregations().get("gclid"); //NO I18N
		
		for (Bucket entry : termAgg.getBuckets()) {
			String k = (String)entry.getKey();
			gclids.add(k);
		}
		
		return gclids;
	}
	
	public static ArrayList<String> getConvertedWithQPKey(String queryParamKey, String multiSegmentCriteria, Long startDateInMillis, Long endDateInMillis, String experimentLinkName) throws Exception {
		
		FunnelAnalysis analysis = FunnelAnalysis.getFunnelAnalysisWithSteps(experimentLinkName);
		
		Long[] order = analysis.getSteps().stream().map(s -> s.getStepId()).toArray(Long[]::new);
		
		//Query
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put(ORDER, order);
		Script script = new Script(ScriptType.INLINE, PAINLESS, ELASTIC_TC_QUERY_SCRIPT, params);
		
		BoolQueryBuilder builder = QueryBuilders
									.boolQuery()
									.filter(QueryBuilders.boolQuery().must(
											QueryBuilders.termQuery(
													ElasticSearchConstants.EXPERIMENTKEY,
													analysis.getExperimentKey())))
									.must(QueryBuilders.scriptQuery(script));


		return getValuesWithQPKey(queryParamKey, multiSegmentCriteria, builder, startDateInMillis, endDateInMillis, analysis);
	}
	
	public static QueryBuilder generateMultiSegmentCriteria(String criteriaObjectStr, Long startDateInMillis, Long endDateInMillis, FunnelAnalysis analysis) throws Exception
	{
		QueryBuilder builder = null;
		try
		{
			
			JSONObject rootJsonObject = new JSONObject(criteriaObjectStr);
			String rootOperator = rootJsonObject.getString("condition_type"); //No I18N
			
			JSONArray rootJsonArr = rootJsonObject.getJSONArray("conditions"); //No I18N
			int rootArrSize = rootJsonArr.length();
			
			List<QueryBuilder> outerConditions = new ArrayList<QueryBuilder>();
			
			
			for(int i=0;i<rootArrSize;i++)
			{
				JSONObject subJsonObject = rootJsonArr.getJSONObject(i);
				String subOperator = subJsonObject.getString("condition_type"); //No I18N
				JSONArray subJsonArr = subJsonObject.getJSONArray("conditions"); //No I18N
				
				int subArrSize = subJsonArr.length();
				
				List<QueryBuilder> innerConditions = new ArrayList<QueryBuilder>();
				
				for(int j=0;j<subArrSize;j++)
				{
					JSONObject atomicCondition = subJsonArr.getJSONObject(j);
					String dimension = atomicCondition.getString("type");  //No I18N
					Integer operator = Integer.parseInt(atomicCondition.getString("operator"));  //No I18N
					//Array of string values
					JSONArray valueArr = atomicCondition.getJSONArray("values");  //No I18N
					
					String dynamicAttributeLinkName = "";
					if(atomicCondition.has(ReportConstants.ATTRIBUTE_NAME))
					{
						dynamicAttributeLinkName = atomicCondition.getString(ReportConstants.ATTRIBUTE_NAME);  //No I18N
					}
					
//					if(dimension.equals(ElasticSearchConstants.URLPARAMETER) || dimension.equals(ElasticSearchConstants.COOKIE) || dimension.equals(ElasticSearchConstants.JSVARIABLE) || dimension.equals(ElasticSearchConstants.CUSTOMDIMENSION))
//					{
						//dimension = dynamicAttributeLinkName; //NO I18N
//					}
					
					if(FlexibleQueryConstants.FIELD_KEY_SWAPS.containsKey(dimension)) {
						dimension = FlexibleQueryConstants.FIELD_KEY_SWAPS.get(dimension);
					}
					
					if(dimension.equals(ElasticSearchConstants.USERTYPE)) {
						dimension = ElasticSearchConstants.FUSERTYPE;
					}
					
					if(dimension.equals(ElasticSearchConstants.BROWSER) || 
						dimension.equals(ElasticSearchConstants.DEVICE) ||
						dimension.equals(ElasticSearchConstants.LANGUAGE) ||
						dimension.equals(ElasticSearchConstants.FUSERTYPE) ||
						dimension.equals(ElasticSearchConstants.USERTYPE) ||
						dimension.equals(ElasticSearchConstants.OS)) {
						for(int k=0; k<valueArr.length(); k++) {
							valueArr.put(k, valueArr.getString(k).toUpperCase());
						}
					}
					
					
					if(FlexibleQueryConstants.FIELD_VALUE_SWAPS.containsKey(dimension)) {
						HashMap<String, String> valueSwaps = FlexibleQueryConstants.FIELD_VALUE_SWAPS.get(dimension);
						for(int k=0; k<valueArr.length(); k++) {
							String value = valueArr.getString(k);
							if(valueSwaps.containsKey(value)) {								
								valueArr.put(k, valueSwaps.get(value));
							}
						}
					}
					
					String wildCard = ".*"; //No I18N
					
					String regexvalue = "";
					if (FlexibleQueryConstants.FUNNEL_NESTED_FIELDS.contains(dimension)
						|| FlexibleQueryConstants.FUNNEL_NESTED_FIELDS_DYN.contains(dimension)) {
							if(operator.equals(AudienceAttributeMatchTypes.REGEX.getTypeId())) {
								throw new ZABException("Regex patterns are not supported for "+dimension); //NO I18N
							} else {
								HashMap<String, Object> params = new HashMap<String, Object>();
								params.put(START_TIME, startDateInMillis);
								params.put(END_TIME, endDateInMillis);
								params.put(FlexibleQueryConstants.FIRSTSTEP, analysis.getSteps().get(0).getStepId());
								params.put(FlexibleQueryConstants.ATTR_KEY, dimension);
								params.put(FlexibleQueryConstants.MATCH_TYPE, operator);
								params.put(FlexibleQueryConstants.ATTR_VALUES, ZABUtil.convertJSONArrayToArrayList(String.class, valueArr));
								params.put(FlexibleQueryConstants.FIELD_TYPE, "NDA");
								
								if(FlexibleQueryConstants.FUNNEL_NESTED_FIELDS_DYN.contains(dimension)) {								
									params.put(FlexibleQueryConstants.ATTR_NAME, dynamicAttributeLinkName);
									params.put(FlexibleQueryConstants.FIELD_TYPE, "DA");
								}
								
								Script script = new Script(ScriptType.INLINE, PAINLESS, ELASTIC_SEARCH_DEEP_FILTER, params);
								innerConditions.add(QueryBuilders.boolQuery().must(QueryBuilders.scriptQuery(script)));
							}
					} else if(dimension.equals(ReportConstants.SEGMENT_LOCATION)) {
						BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
						String[] valArr = ZABUtil.convertJSONArrayToArrayList(String.class, valueArr).toArray(new String[valueArr.length()]);
						List<BoolQueryBuilder> locationQueryList = ElasticSearchStatistics.constructLocationBoolQuery(valArr);
						if(operator.equals(AudienceAttributeMatchTypes.EQUALS.getTypeId())) {							
							boolQueryBuilder.should().addAll(locationQueryList);
							innerConditions.add(boolQueryBuilder);
						} else if(operator.equals(AudienceAttributeMatchTypes.NOT_EQUALS.getTypeId())) {
							boolQueryBuilder.mustNot().addAll(locationQueryList);
							innerConditions.add(boolQueryBuilder);
						}
					} else if(dimension.equals(ElasticSearchConstants.DAYOFWEEK) || dimension.equals(ElasticSearchConstants.HOUROFDAY)) {
						
						BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
						
						String timezone = ESQuickFilterConstants.DEFAULT_TIME_ZONE;
						String intervalType = dimension.equals(ElasticSearchConstants.HOUROFDAY)?"H":"D"; //NO I18N
						
						HashMap<String, Object> params = new HashMap<String, Object>();
						params.put(START_TIME, startDateInMillis);
						params.put(END_TIME, endDateInMillis);
						params.put(FlexibleQueryConstants.FIRSTSTEP, analysis.getSteps().get(0).getStepId());
						if(IAMUtil.getCurrentUser()!=null && StringUtils.isNotEmpty(IAMUtil.getCurrentUser().getTimezone()))
						{
							timezone = IAMUtil.getCurrentUser().getTimezone();
						}
						params.put(ESQuickFilterConstants.TIMEZONE, timezone);
						
						params.put(FlexibleQueryConstants.INTERVAL_TYPE, intervalType);
						params.put(FlexibleQueryConstants.VALUES, ZABUtil.convertJSONArrayToArrayList(String.class, valueArr));
						
						Script script = new Script(ScriptType.INLINE, PAINLESS, FlexibleQueryConstants.DAY_HOUR_OF_WEEK_SCRIPT, params);
						
						if(operator.equals(AudienceAttributeMatchTypes.EQUALS.getTypeId())) {	
							boolQueryBuilder.should(QueryBuilders.scriptQuery(script));
							innerConditions.add(boolQueryBuilder);
						} else if(operator.equals(AudienceAttributeMatchTypes.NOT_EQUALS.getTypeId())) {
							boolQueryBuilder.mustNot(QueryBuilders.scriptQuery(script));
							innerConditions.add(boolQueryBuilder);
						}
					} else {
						AudienceAttributeMatchTypes mtype = AudienceAttributeMatchTypes.getAudienceMatchTypeById(operator);
						switch(mtype)
						{
						case EQUALS:
							//EQUALS
							innerConditions.add(QueryBuilders.boolQuery().must(
									QueryBuilders.termsQuery(dimension, ZABUtil
											.convertJSONArrayToArrayList(
													String.class, valueArr))));
							break;
						case NOT_EQUALS:
							//NOT EQUALS
							innerConditions.add(QueryBuilders.boolQuery().mustNot(
									QueryBuilders.termsQuery(dimension, ZABUtil
											.convertJSONArrayToArrayList(
													String.class, valueArr))));
							break;
						case REGEX:
							//REGEX EQUALS
							regexvalue = valueArr.getString(0);
							innerConditions.add(QueryBuilders.boolQuery().must(QueryBuilders.regexpQuery(dimension, regexvalue)));
							
							break;
						case CONTAINS:
							//CONTAINS
							regexvalue = wildCard+valueArr.getString(0)+wildCard;
							innerConditions.add(QueryBuilders.boolQuery().must(QueryBuilders.regexpQuery(dimension, regexvalue)));
							break;
						case DOESNOT_CONTAINS:
							//DOES NOT CONTAINS
							regexvalue = wildCard+valueArr.getString(0)+wildCard;
							innerConditions.add(QueryBuilders.boolQuery().mustNot(QueryBuilders.regexpQuery(dimension, regexvalue)));
							break;
						case STARTS_WITH:
							//STARTS WITH
							regexvalue =valueArr.getString(0);
							innerConditions.add(QueryBuilders.boolQuery().must(QueryBuilders.prefixQuery(dimension, regexvalue)));
							break;
						case ENDS_WITH:
							//ENDS WITH
							regexvalue = wildCard+valueArr.getString(0);
							innerConditions.add(QueryBuilders.boolQuery().must(QueryBuilders.regexpQuery(dimension, regexvalue)));
							break;
						}
					}
					
					
				}
				
				switch(subOperator)
				{
					case "1":  //No I18N
					{
						BoolQueryBuilder build =  QueryBuilders.boolQuery();
						build.must().addAll(innerConditions);
						outerConditions.add(build);
						break;
					}
					case "2":  //No I18N
					{
						BoolQueryBuilder build =  QueryBuilders.boolQuery();
						build.should().addAll(innerConditions);
						outerConditions.add(build);
						break;
					}
				}
			}
			
			switch(rootOperator)
			{
				case "1":  //No I18N
				{
					BoolQueryBuilder build =  QueryBuilders.boolQuery();
					build.must().addAll(outerConditions);
					builder = build;
					break;
				}
				case "2":  //No I18N
				{
					BoolQueryBuilder build =  QueryBuilders.boolQuery();
					build.should().addAll(outerConditions);
					builder = build;
					break;
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			throw ex;
			
		}
		return builder;
	}
	
	
	
	/**
	 * @param startDateInMillis
	 * @param endDateInMillis
	 * @param stepId
	 * @return
	 * @throws JSONException
	 * 
	 * {
		  "query": {
		    "bool": {
		      "must": [
		        {
		          "match": {
		            "experimentid": "expkey"
		          }
		        },
		        {
		          "nested": {
		            "path": "steps",
		            "query": {
		              "bool": {
		                "must": [
		                  {
		                    "match": {
		                      "steps.stepid": "step1"
		                    }
		                  },
		                  {
		                    "range": {
		                      "steps.time": {
		                        "gte": 1,
		                        "lte": 3
		                      }
		                    }
		                  }
		                ]
		              }
		            }
		          }
		        }
		      ]
		    }
		  }
		}
	 */
	public static BoolQueryBuilder formFunnelQueryForTotalSessions(Long startDateInMillis, Long endDateInMillis, String experimentKey, Long stepId) throws JSONException {

		
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put(ElasticSearchConstants.STEPID, stepId);
		params.put(START_TIME, startDateInMillis);
		params.put(END_TIME, endDateInMillis);
		
		Script script = new Script(ScriptType.INLINE, PAINLESS, ELASTIC_STEP_VISIT_COUNT, params);
		
		BoolQueryBuilder builder = QueryBuilders.boolQuery().must(QueryBuilders.scriptQuery(script))
									   .filter(QueryBuilders
											   .boolQuery()
											   	.must(QueryBuilders.matchQuery(ElasticSearchConstants.EXPERIMENTKEY, experimentKey))
											   	.must(QueryBuilders.nestedQuery("steps", QueryBuilders //NO I18N
											   			.boolQuery()
											   				.must(QueryBuilders
											   						.matchQuery(ElasticSearchConstants.STEPS+ "."+ElasticSearchConstants.STEPID, stepId))
											   				.must(QueryBuilders
											   						.rangeQuery(ElasticSearchConstants.STEPS+ "."+ElasticSearchConstants.TIME)
												   						.gte(startDateInMillis)
												   						.lte(endDateInMillis)), ScoreMode.None)));
		
		return builder;
	}
	
	public static void deleteFunnelReportData(String experimentKey) throws Exception {
		String portalName = IAMUtil.getCurrentServiceOrg().getDomains().get(0).getDomain();
		String indexName = ElasticSearchUtil.getIndexByPortal(portalName);
		ElasticSearchUtil.deleteDocsByCriteria(indexName, ElasticSearchConstants.FUNNEL_RAW_TYPE, ElasticSearchConstants.EXPERIMENTKEY, experimentKey);
	}
	
	
	/**
	 * @param startDateInMillis
	 * @param endDateInMillis
	 * @param order
	 * @param experimentKey
	 * @return
	 * @throws JSONException
	 * 
	 * Sample JSONStructure
	 * 
	 * 
	 * {
		  "query": {
		    "must": {
		      "bool": {
		        "script": {
		          "script": {
		            "inline": "$SCRIPT",
		            "lang": "painless",
		            "params": {
		              "order": [
		                "step1",
		                "step2",
		                "step3"
		              ],
		              "start_time": 1,
		              "end_time": 3
		            }
		          }
		        },
		        filter:Refer@getFunnelFilterQueryWithoutDims
		      }
		    }
		  }
		}
	 * 
	 */
	
	private static BoolQueryBuilder formFunnelQueryWithoutDims(Long startDateInMillis, Long endDateInMillis, ArrayList<Long> order, String experimentKey) throws JSONException {
		return formFunnelQueryWithoutDims(startDateInMillis, endDateInMillis, order.toArray(new Long[order.size()]), experimentKey);
	}
	
	private static BoolQueryBuilder formFunnelQueryWithoutDims(Long startDateInMillis, Long endDateInMillis, Long[] order, String experimentKey) throws JSONException {
		
		HashMap<String, Object> hs = new HashMap<String, Object>();
		hs.put(ORDER, order);
		hs.put(START_TIME, startDateInMillis);
		hs.put(ON_FLAG, true);
		hs.put(OFF_FLAG, false);
		hs.put(END_TIME, endDateInMillis);
		
		Script script = new Script(ScriptType.INLINE, PAINLESS, ELASTIC_NODIM_QUERY_SCRIPT_INVERTABLE, hs);
		BoolQueryBuilder builder = QueryBuilders
									.boolQuery()
									.must(QueryBuilders.scriptQuery(script))
									.filter(QueryBuilders.boolQuery().must(
											QueryBuilders.termQuery(
													ElasticSearchConstants.EXPERIMENTKEY,
													experimentKey)));
		return builder;
	}
	
private static BoolQueryBuilder formFunnelQueryWithQPFilter(Long startDateInMillis, Long endDateInMillis, Long[] order, String experimentKey, String queryParamKey, String queryParamValue) throws JSONException {
		
		HashMap<String, Object> hs = new HashMap<String, Object>();
		hs.put(ORDER, order);
		hs.put(START_TIME, startDateInMillis);
		hs.put(ON_FLAG, true);
		hs.put(FlexibleQueryConstants.FIELD_TYPE, "DA");
		hs.put(FlexibleQueryConstants.ATTR_KEY, ElasticSearchConstants.NURLPARAMETER);
		hs.put(FlexibleQueryConstants.ATTR_NAME, queryParamKey);
		hs.put(FlexibleQueryConstants.ATTR_VALUES, queryParamValue);
		hs.put(FlexibleQueryConstants.MATCH_TYPE, AudienceAttributeMatchTypes.EQUALS.getTypeId());
		hs.put(OFF_FLAG, false);
		hs.put(END_TIME, endDateInMillis);
		
		Script script = new Script(ScriptType.INLINE, PAINLESS, FlexibleQueryConstants.ELASTIC_SEARCH_DEEP_FILTER_QP, hs);
		BoolQueryBuilder builder = QueryBuilders
									.boolQuery()
									.must(QueryBuilders.scriptQuery(script))
									.filter(QueryBuilders.boolQuery().must(
											QueryBuilders.termQuery(
													ElasticSearchConstants.EXPERIMENTKEY,
													experimentKey)));
		return builder;
	}
	
	/**
	 * @param startDateInMillis
	 * @param endDateInMillis
	 * @param order
	 * @param experimentKey
	 * @return
	 * @throws JSONException
	 * 
	 * Sample JSONStructure
	 * 
	 * 
	 * {
		  "query": {
		    "must": {
		      "bool": {
		        "script": {
		          "script": {
		            "inline": "$SCRIPT",
		            "lang": "painless",
		            "params": {
		              "order": [
		                "step1",
		                "step2",
		                "step3"
		              ]
		            }
		          }
		        },
		        filter:Refer@getFunnelFilterQueryWithoutDims
		      }
		    }
		  }
		}
	 * 
	 */
	public static QueryBuilder formFunnelQueryTotalConversion(ArrayList<Long> order, String experimentKey) throws JSONException {
		
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put(ORDER, order.toArray(new Long[order.size()]));
		Script script = new Script(ScriptType.INLINE, PAINLESS, ELASTIC_TC_QUERY_SCRIPT, params);
		
		QueryBuilder builder = QueryBuilders
									.boolQuery()
									.filter(QueryBuilders.boolQuery().must(
											QueryBuilders.termQuery(
													ElasticSearchConstants.EXPERIMENTKEY,
													experimentKey)))
									.must(QueryBuilders.scriptQuery(script));
		
		return builder;
	}
	
	
	public static AggregationBuilder getAverageAggregationQueryJSON(Long startDateInMillis, Long endDateInMillis, ArrayList<Long> order, String experimentKey) throws JSONException {
		
		HashMap<String, Object> hs = new HashMap<String, Object>();
		hs.put(START_TIME, startDateInMillis);
		hs.put(END_TIME, endDateInMillis);
		hs.put(ORDER, order.toArray(new Long[order.size()]));
		
		Script script = new Script(ScriptType.INLINE, PAINLESS, ELASTIC_STEP_AVERAGE_TIME, hs);
		
		AggregationBuilder aggs =  AggregationBuilders.avg(AVERAGE_TIME_ON_STEP).script(script);
		return aggs;
	}
	
	public static BoolQueryBuilder formAverageTimeQuery(Long startDateInMillis, Long endDateInMillis, ArrayList<Long> fullOrder, String experimentKey) throws JSONException {
		BoolQueryBuilder query = formFunnelQueryWithoutDims(startDateInMillis, endDateInMillis, fullOrder, experimentKey);
		return query;
	}
	
	public static void addFilterToQuery(BoolQueryBuilder query, QueryBuilder filter) {
		if(query!=null && filter!=null) {
			query.filter(filter);
		}
	}
	
	public static BoolQueryBuilder getGCLIDConversions(String criteriaObj, Long startDateInMillis, Long endDateInMillis, FunnelAnalysis anaylsis, String gclid) throws Exception {
		
		Long[] order = anaylsis.getSteps().stream().map(s -> s.getStepId()).toArray(Long[]::new);
		
		BoolQueryBuilder bool = formFunnelQueryWithQPFilter(startDateInMillis, endDateInMillis, order,  anaylsis.getExperimentKey(), "gclid", gclid); //No I18N
		if(criteriaObj!=null) {
			bool.must(generateMultiSegmentCriteria(criteriaObj, startDateInMillis, endDateInMillis, anaylsis));
		}
		
		BoolQueryBuilder builder = QueryBuilders.boolQuery()
									   .filter(QueryBuilders
											   .boolQuery()
											   	.must(QueryBuilders.nestedQuery("steps", QueryBuilders //NO I18N
											   			.boolQuery()
											   				.must(QueryBuilders
											   						.rangeQuery(ElasticSearchConstants.STEPS+ "."+ElasticSearchConstants.TIME)
												   						.gte(startDateInMillis)
												   						.lte(endDateInMillis)), ScoreMode.None)));
		
		bool.must(QueryBuilders.termQuery(ElasticSearchConstants.PORTAL, ZABUtil.getPortaldomain()));
		bool.must(builder);
		return bool;
	}
	
	
public static BoolQueryBuilder getGCLIDVisitors(String criteriaObj, Long startDateInMillis, Long endDateInMillis, FunnelAnalysis anaylsis) throws Exception {
		
		
		String portalName = IAMUtil.getCurrentServiceOrg().getDomains().get(0).getDomain();
		
		
		NestedQueryBuilder builder =  QueryBuilders.nestedQuery(
										ElasticSearchConstants.STEPS,
										QueryBuilders.boolQuery().must(QueryBuilders.termQuery(ElasticSearchConstants.STEPS + "."
												+ ElasticSearchConstants.STEPID, anaylsis.getSteps().get(0).getStepId())),
										ScoreMode.None);

		BoolQueryBuilder bool = QueryBuilders.boolQuery().must(builder);
		
		if(criteriaObj!=null) {
			bool.must(generateMultiSegmentCriteria(criteriaObj, startDateInMillis, endDateInMillis, anaylsis));
		}
		
		BoolQueryBuilder timeCri = QueryBuilders.boolQuery()
									   .filter(QueryBuilders
											   .boolQuery()
											   	.must(QueryBuilders.nestedQuery("steps", QueryBuilders //NO I18N
											   			.boolQuery()
											   				.must(QueryBuilders
											   						.rangeQuery(ElasticSearchConstants.STEPS+ "."+ElasticSearchConstants.TIME)
												   						.gte(startDateInMillis)
												   						.lte(endDateInMillis)), ScoreMode.None)));
		
		
		bool.must(QueryBuilders.termQuery(ElasticSearchConstants.EXPERIMENTKEY, anaylsis.getExperimentKey()));
		bool.must(QueryBuilders.termQuery(ElasticSearchConstants.PORTAL, portalName));
		bool.must(timeCri);
		return bool;
	}
	
	public static ArrayList<FunnelReport> getFunnelReportWithoutDims(FunnelAnalysis analysis, Long startDateInMillis, Long endDateInMillis, String experimentLinkname, QueryBuilder filterBuilder) throws Exception {
		
		ArrayList<FunnelReport> funnelReports = new ArrayList<FunnelReport>();
		String portalName =null;
		try{
			portalName = IAMUtil.getCurrentServiceOrg().getDomains().get(0).getDomain();
		}catch(Exception e){
			portalName =  ZABUtil.getPortaldomain();
			if(portalName == null){
				throw new Exception();
			}
		}
		
		String indexName = ElasticSearchUtil.getIndexByPortal(portalName);
		Long totalVisits = 0l;
		if(analysis!=null) {
			int size = analysis.getSteps().size();
			ArrayList<Long> path = new ArrayList<Long>();
			for(int i = 0; i < size; i++) {				
				if(i == 0) {
					//Compute total session
					Long stepId = analysis.getSteps().get(i).getStepId();
					BoolQueryBuilder builder = formFunnelQueryForTotalSessions(startDateInMillis,
							endDateInMillis,
							analysis.getExperimentKey(), stepId);
					
					//Filter
					addFilterToQuery(builder, filterBuilder);
					
					Long totalSession = ElasticSearchUtil.getCount(indexName, ElasticSearchConstants.FUNNEL_RAW_TYPE, builder);
					path.add(stepId);
					totalVisits = totalSession;
					FunnelReport report = new FunnelReport();
					report.setSessionsCount(totalSession);
					report.setSuccess(Boolean.TRUE);
					report.setExperimentId(analysis.getExperimentId());
					report.setStepLinkname(analysis.getSteps().get(i).getStepLinkname());
					report.setExperimentLinkname(experimentLinkname);
					report.setStepId(analysis.getSteps().get(i).getStepId());
					funnelReports.add(report);
				} else {
					path.add(analysis.getSteps().get(i).getStepId());
					FunnelReport report = new FunnelReport();
					BoolQueryBuilder builder = formFunnelQueryWithoutDims(startDateInMillis, endDateInMillis, path, analysis.getExperimentKey());
					addFilterToQuery(builder, filterBuilder);
					
					Long totalSession = ElasticSearchUtil.getCount(indexName, ElasticSearchConstants.FUNNEL_RAW_TYPE, builder);
					
					FunnelReport previousFunnelReport = funnelReports.get(i-1);
					
					ArrayList<Long> immediatePath = new ArrayList<Long>(
							Arrays.asList(previousFunnelReport.getStepId(),
									analysis.getSteps().get(i).getStepId()));
					
					BoolQueryBuilder avgbuilder = formAverageTimeQuery(startDateInMillis, endDateInMillis, path, analysis.getExperimentKey());
					
					//Filter
					addFilterToQuery(avgbuilder, filterBuilder);
					
					AggregationBuilder aggs = getAverageAggregationQueryJSON(startDateInMillis, endDateInMillis, immediatePath, analysis.getExperimentKey());
					
					SearchResponse sr = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.FUNNEL_RAW_TYPE, 0, avgbuilder, aggs);
					
					Avg avg = sr.getAggregations().get(AVERAGE_TIME_ON_STEP);
					Double averageTimeSpent =  avg.getValue();
					if(averageTimeSpent!=null) {
						previousFunnelReport.setAverageTimeSpentForStep(averageTimeSpent);
					}
					
					if(i == (size - 1)) {
						BoolQueryBuilder tavgbuilder = formAverageTimeQuery(startDateInMillis, endDateInMillis, path, analysis.getExperimentKey());
						
						//Filter
						addFilterToQuery(tavgbuilder, filterBuilder);
						
						AggregationBuilder taggs = getAverageAggregationQueryJSON(startDateInMillis, endDateInMillis, path, analysis.getExperimentKey());
						SearchResponse tsr = ElasticSearchUtil.getData(
								indexName,
								ElasticSearchConstants.FUNNEL_RAW_TYPE,
								0,
								tavgbuilder,
								taggs);
						
						Avg tavg = tsr.getAggregations().get(AVERAGE_TIME_ON_STEP);
						Double overallaverageTimeSpent =  tavg.getValue();
						if(averageTimeSpent!=null) {
							report.setOverallAverageTime(overallaverageTimeSpent);
						}
					}
					
					previousFunnelReport.setConversionCount(totalSession);
					previousFunnelReport.computeDependentMetricValues(totalVisits);
					report.setSessionsCount(totalSession);
					report.setExperimentId(analysis.getExperimentId());
					report.setStepLinkname(analysis.getSteps().get(i).getStepLinkname());
					report.setExperimentLinkname(experimentLinkname);
					report.setStepId(analysis.getSteps().get(i).getStepId());
					report.setSuccess(Boolean.TRUE);
					funnelReports.add(report);
				}
			}
		}
		
		return funnelReports;
	}
	
	public static Long getTotalConverstion(String experimentKey, Long visitorCount, ArrayList<Long> order) throws Exception {
		String portalName = IAMUtil.getCurrentServiceOrg().getDomains().get(0).getDomain();
		String indexName = ElasticSearchUtil.getIndexByPortal(portalName);
		QueryBuilder builder = formFunnelQueryTotalConversion(order, experimentKey);
		return ElasticSearchUtil.getCount(indexName, ElasticSearchConstants.FUNNEL_RAW_TYPE, builder);
	}
	
	
	
	/**
	 * @param stepId
	 * @return
	 * 
	 * {
		  "size":0,
		  "query": {
		     "nested": {
		          "path": "steps",
		          "query": {
		            "bool": {
		              "must": [
		                { "match": { "steps.stepid": 2000000000339 }}
		              ]
		            }
		          }
		     }
		  }
		}
	 * @throws JSONException 
	 */
	public static Long getTotalSession(Long stepId) throws Exception {
		String portalName = IAMUtil.getCurrentServiceOrg().getDomains().get(0).getDomain();
		String indexName = ElasticSearchUtil.getIndexByPortal(portalName);
		NestedQueryBuilder builder =  QueryBuilders.nestedQuery(
										ElasticSearchConstants.STEPS,
										QueryBuilders.boolQuery().must(QueryBuilders.termQuery(ElasticSearchConstants.STEPS + "."
												+ ElasticSearchConstants.STEPID, stepId)),
										ScoreMode.None);
		
		return ElasticSearchUtil.getCount(indexName, ElasticSearchConstants.FUNNEL_RAW_TYPE, builder);
	}
	
	public static ArrayList<FunnelReport> getFunnelReport(HashMap<String, String> hs) {
		ArrayList<FunnelReport> funnelReports = new ArrayList<FunnelReport>();
		
		try {
			String startDate = hs.get(FunnelReportConstants.START_DATE);
			String endDate = hs.get(FunnelReportConstants.END_DATE);
			String experimentLinkname = hs.get(FunnelReportConstants.EXPERIMENT_LINKNAME);
			
			Long startTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(startDate, FunnelReportConstants.FUN_REPORT_DATE_FORMAT);
			Long endTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(endDate, FunnelReportConstants.FUN_REPORT_DATE_FORMAT);
			endTimeInMillis = ZABUtil.getNthDayDateInLong(endTimeInMillis, 1) - 1;
			
			FunnelAnalysis analysis = FunnelAnalysis.getFunnelAnalysisWithSteps(experimentLinkname);
			
			QueryBuilder filterBuilder = null;
			if(hs.containsKey(FunnelReportConstants.MULTISEGMENT_CRITERIA)) {
				filterBuilder = generateMultiSegmentCriteria(hs.get(FunnelReportConstants.MULTISEGMENT_CRITERIA), startTimeInMillis, endTimeInMillis, analysis);
			}
			
			funnelReports = getFunnelReportWithoutDims(analysis, startTimeInMillis, endTimeInMillis, experimentLinkname, filterBuilder);
			
		} catch (ZABException e) {
			FunnelReport funnelReport = new FunnelReport();
			funnelReport.setSuccess(Boolean.FALSE);
			funnelReport.setResponseString(e.getMessage());
			funnelReports.add(funnelReport);
			LOGGER.log(Level.SEVERE, "Exception occured:", e);
		} 
		catch (Exception e) {
			FunnelReport funnelReport = new FunnelReport();
			funnelReport.setSuccess(Boolean.FALSE);
			funnelReport.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			funnelReports.add(funnelReport);
			LOGGER.log(Level.SEVERE, "Exception occured:", e);
		}
		
		return funnelReports;
	}
	
}
