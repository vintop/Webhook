//$Id$
package com.zoho.abtest.funnel.report;

import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.listener.IPRestrictionData;
import com.zoho.abtest.listener.ZABListener;
import com.zoho.abtest.report.ReportRawDataConstants;
import com.zoho.abtest.report.VisitorRawDataWrapper;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.mqueue.consumer.ConsumerRecord;
import com.zoho.mqueue.consumer.MessageListener;

/**
 * @author david-3671
 *
 */

public class FunnelRawDataListener extends ZABListener implements MessageListener<String, String>{
	
	private static final Logger LOGGER = Logger.getLogger(FunnelRawDataListener.class.getName());

	@Override
	public void consumeMessage(Object obj) throws Exception {
		try {			
			if(obj!=null) {
				VisitorRawDataWrapper wrapper = (VisitorRawDataWrapper)obj;
				FunnelReportDataInHandler.addFunnelRawData(wrapper);
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			throw new Exception(e);
		}
	}

	@Override
	public IPRestrictionData getIPRestrictionData(Object message)
			throws ZABException {
		VisitorRawDataWrapper wrapper = (VisitorRawDataWrapper)message;
		HashMap<String, String> funnelData = wrapper.getFunnelData();
		String portal = funnelData.get(ReportRawDataConstants.PORTAL);
		
		String experimentKey = funnelData.get(ReportRawDataConstants.EXPERIMENT_KEY);
		setDBSpace(portal);
		Long projectId = Experiment.getProjectIdByExperimentKey(experimentKey);
		LOGGER.log(Level.INFO, "Getting IP Address from visitor raw data:"+experimentKey+", "+projectId+", ****");
		return new IPRestrictionData(portal, projectId, wrapper.getIpAddress());
	}

}
