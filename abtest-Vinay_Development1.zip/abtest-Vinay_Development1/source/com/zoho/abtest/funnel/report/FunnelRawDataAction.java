//$Id$
package com.zoho.abtest.funnel.report;

import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;

import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.listener.ZABNotifier;
import com.zoho.abtest.report.VisitorRawDataWrapper;
import com.zoho.abtest.utility.ZABUtil;

/**
 * @author david-3671
 *
 */
public class FunnelRawDataAction extends ZABAction implements ServletResponseAware, ServletRequestAware {
	
	private static final Logger LOGGER = Logger.getLogger(FunnelRawDataAction.class.getName());
	
	private static final long serialVersionUID = 1L;

	private HttpServletRequest request;
	
	private HttpServletResponse response;
	
	@Override
	public void setServletRequest(HttpServletRequest request) {
		ZABUtil.setCurrentRequest(request);
		this.request = request;
	}

	@Override
	public void setServletResponse(HttpServletResponse response) {
		this.response = response;
	}
	
	
	public void pushFunnelRawData() {
		try
		{
			VisitorRawDataWrapper wrapper = new VisitorRawDataWrapper();
			HashMap<String, String> funnelData = ZABAction.getRequestParser(request).parseFunnelRawData(request, FunnelReportConstants.API_MODULE_FUNNEL_RAW_SH);
			wrapper.setFunnelData(funnelData);
			HashMap<String, String> userAgentHashmap = ZABAction.getRequestParser(request).parseFunnelRawData(request, FunnelReportConstants.API_MODULE_USERAGENT_RAW_SH);
			wrapper.setUserAgenths(userAgentHashmap);
			LOGGER.log(Level.INFO,"!!! Funnel Raw data Received: {0}",wrapper);
			ZABNotifier.notifyListeners(FunnelReportConstants.FUNNEL_RAW_NOTIFIER_NAME, wrapper);
		}catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
		}
		
	}


}
