//$Id$
package com.zoho.abtest.funnel.report;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;

public class FunnelReportTimelineResponse {
	
	private static final Logger LOGGER = Logger.getLogger(FunnelReportResponse.class.getName());
	
	public static String jsonResponse(HttpServletRequest request,ArrayList<FunnelTimelineReport> lst) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(lst);			
			JSONObject json = ZABResponse.updateMetaInfo(request, FunnelReportConstants.API_MODULE_TL, array);
			json.put(FunnelReportConstants.API_MODULE_TL , array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE, "Exception occured:", ex);
		}
		return returnBuffer.toString();
	}
	
	public static JSONArray getJSONArray(ArrayList<FunnelTimelineReport> lst) throws JSONException {
		JSONArray array = new JSONArray();
		int size = 0;
		if(lst!=null && ((size = lst.size()) > 0 )) {
			for(int i=0; i<size; i++) {
				FunnelTimelineReport report = lst.get(i);
				JSONObject object = new JSONObject();
				object.put(ZABConstants.SUCCESS,  report.getSuccess());
				object.put(ZABConstants.RESPONSE_STRING,  report.getResponseString());
				object.put(FunnelReportConstants.TIME,  report.getTime());
				object.put(FunnelReportConstants.VISITOR_COUNT,  report.getSessionsCount());
				object.put(FunnelReportConstants.CONVERSIONS,  report.getConversionCount());
				object.put(FunnelReportConstants.CONVERSIONS_RATE,  report.getConversionRate());
				object.put(FunnelReportConstants.DROP_COUNT,  report.getDropCount());
				object.put(FunnelReportConstants.DROP_RATE,  report.getDropRate());
				array.put(object);
			}
		}
		return array;
	}
}
