//$Id$
package com.zoho.abtest.funnel.report;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;

/**
 * @author david-3671
 *
 */
public interface FunnelReportBean {
	
	/**
	 * @param rawData
	 * @throws Exception
	 * Add raw data to funnel table
	 */
	public void addFunnelRawData(FunnelRawData rawData) throws Exception;
	
	public List<Integer> getCodeValues(String dimension, String queryOperator, JSONArray values, Long dynamicAttributeId);
	
	public List<Integer> getCodeValues(String dimension, String queryOperator, String value, Long dynamicAttributeId);
	
	public Long getSessionCountForStepNoDims(Long experimentId, Long stepId,
			Long startDate, Long endDate,
			String pathPattern, ArrayList<Long> previousStepIds);

}
