//$Id$
package com.zoho.abtest.funnel.report;



import java.util.Collections;

import org.apache.commons.lang3.StringUtils;

import com.zoho.abtest.FUNNEL_RAW_DATA_NODIM;
import com.zoho.abtest.funnel.report.FunnelReportConstants.FUNNEL_REPORT_HOUR_DYNS;
import com.zoho.abtest.funnel.report.FunnelReportConstants.FUNNNEL_RAW_TABLE;

/**
 * @author david-3671
 *
 */
public class FunnelReportRawQueries {

	
	private static final String COMMA = ","; //NO I18N   
	
	public static final String VISITOR_COUNT_COLUMN_NAME = "VISITOR_COUNT"; //NO I18N
	
//	public static final String FUNNEL_HOUR_DYNS_CREATE_QUERY = "CREATE TABLE "+ FUNNEL_REPORT_HOUR_DYNS.TABLE //NO I18N
//			+" ("
//			+ FUNNEL_REPORT_HOUR_DYNS.FUNNEL_REPORT_HOUR_ID + " BIGINT NOT NULL references " 
//					+ FUNNEL_DATA_RAW_HOUR.TABLE+"("+ FUNNEL_DATA_RAW_HOUR.FUNNEL_DATA_RAW_HOUR_ID+ ")  ON DELETE CASCADE" + COMMA
//			+ FUNNEL_REPORT_HOUR_DYNS.DYN_ATTR_COOKIE + " JSONB"+ COMMA
//			+ FUNNEL_REPORT_HOUR_DYNS.DYN_ATTR_CUSTOM + " JSONB"+ COMMA
//			+ FUNNEL_REPORT_HOUR_DYNS.DYN_ATTR_JSVAR + " JSONB"+ COMMA
//			+ FUNNEL_REPORT_HOUR_DYNS.DYN_ATTR_QP + " JSONB"+ COMMA
//			+ FUNNEL_REPORT_HOUR_DYNS.CONVERSIONS + " BIGINT NOT NULL"+ COMMA
//			+"PRIMARY KEY ("+FUNNEL_REPORT_HOUR_DYNS.FUNNEL_REPORT_HOUR_ID+")"
//			+ ");"; //NO I18N
	
	public static final String FUNNEL_HOUR_DYNS_INSERT_QUERY = "INSERT INTO "+ FUNNEL_REPORT_HOUR_DYNS.TABLE //NO I18N
																+" ("
																+ FUNNEL_REPORT_HOUR_DYNS.FUNNEL_REPORT_HOUR_ID + COMMA
																+ FUNNEL_REPORT_HOUR_DYNS.DYN_ATTR_COOKIE + COMMA
																+ FUNNEL_REPORT_HOUR_DYNS.DYN_ATTR_CUSTOM + COMMA
																+ FUNNEL_REPORT_HOUR_DYNS.DYN_ATTR_JSVAR + COMMA
																+ FUNNEL_REPORT_HOUR_DYNS.DYN_ATTR_QP + COMMA
																+ FUNNEL_REPORT_HOUR_DYNS.CONVERSIONS
																+") "
																+"values(?,?,?,?,?,?);"; //NO I18N
	

														   
	/**
	 * @param rawTableName
	 * @param startTimeinMillis
	 * @param endTimeInMillis
	 * @return
	 */
	public static String getCumulativeNoDimAggQuery(String rawTableName, String countColumnAliasName) {
		
		return "SELECT " 
				   + FUNNNEL_RAW_TABLE.EXPERIMENT_ID + COMMA
				   + FUNNNEL_RAW_TABLE.STEP_ID + COMMA
				   + "COUNT(*) AS "+countColumnAliasName
				   + " FROM " + rawTableName 
				   + " WHERE " + FUNNNEL_RAW_TABLE.TIME 
				   + " BETWEEN ? AND ? "
				   + "GROUP BY "
				   + FUNNNEL_RAW_TABLE.EXPERIMENT_ID + COMMA
				   + FUNNNEL_RAW_TABLE.STEP_ID +";";
	}
	
	public static String getCumulativeAllDimAggQuery(String rawTableName, String countColumnAliasName) {
		return "SELECT " 
				   + FUNNNEL_RAW_TABLE.EXPERIMENT_ID + COMMA
				   + FUNNNEL_RAW_TABLE.STEP_ID + COMMA
				   + FUNNNEL_RAW_TABLE.BROWSER_CODE + COMMA
				   + FUNNNEL_RAW_TABLE.DEVICE_CODE + COMMA
				   + FUNNNEL_RAW_TABLE.COUNTRY_CODE + COMMA
				   + FUNNNEL_RAW_TABLE.LANGUAGE_CODE + COMMA
				   + FUNNNEL_RAW_TABLE.OS_CODE + COMMA
				   + FUNNNEL_RAW_TABLE.DAYOFWEEK_CODE + COMMA
				   + FUNNNEL_RAW_TABLE.HOUROFDAY_CODE + COMMA
				   + FUNNNEL_RAW_TABLE.COOKIE_JSON + COMMA
				   + FUNNNEL_RAW_TABLE.URLPARAM_JSON + COMMA
				   + FUNNNEL_RAW_TABLE.JS_VARIABLE_JSON + COMMA
				   + FUNNNEL_RAW_TABLE.CUSTOM_DIMENSION_JSON + COMMA
				   + "COUNT(*) AS "+countColumnAliasName
				   + " FROM " + rawTableName 
				   + " WHERE " + FUNNNEL_RAW_TABLE.TIME 
				   + " BETWEEN ? AND ?"
				   + "GROUP BY "
				   + FUNNNEL_RAW_TABLE.EXPERIMENT_ID + COMMA
				   + FUNNNEL_RAW_TABLE.STEP_ID + COMMA
				   + FUNNNEL_RAW_TABLE.BROWSER_CODE + COMMA
				   + FUNNNEL_RAW_TABLE.DEVICE_CODE + COMMA
				   + FUNNNEL_RAW_TABLE.COUNTRY_CODE + COMMA
				   + FUNNNEL_RAW_TABLE.LANGUAGE_CODE + COMMA
				   + FUNNNEL_RAW_TABLE.OS_CODE + COMMA
				   + FUNNNEL_RAW_TABLE.DAYOFWEEK_CODE + COMMA
				   + FUNNNEL_RAW_TABLE.HOUROFDAY_CODE + COMMA
				   + FUNNNEL_RAW_TABLE.COOKIE_JSON + COMMA
				   + FUNNNEL_RAW_TABLE.URLPARAM_JSON + COMMA
				   + FUNNNEL_RAW_TABLE.JS_VARIABLE_JSON + COMMA
				   + FUNNNEL_RAW_TABLE.CUSTOM_DIMENSION_JSON + ";";
	}
	
	/**
	 * @param dbspaceId
	 * @return
	 * Forms query for inserting raw data
	 * @throws Exception 
	 */
	public static String getFunnelRawDataInsertQuery(String dbspaceId) throws Exception {
		
		String activeVisitorRawdataTable = FUNNNEL_RAW_TABLE.getActiveRawTable(dbspaceId);
		
		return  "INSERT INTO " + activeVisitorRawdataTable // NO I18N
				+ " (" // NO I18N
				+  FUNNNEL_RAW_TABLE.FUNNEL_DATA_RAW_ID + COMMA
				+  FUNNNEL_RAW_TABLE.EXPERIMENT_ID + COMMA
				+  FUNNNEL_RAW_TABLE.STEP_ID + COMMA
				+  FUNNNEL_RAW_TABLE.BROWSER_CODE + COMMA
				+  FUNNNEL_RAW_TABLE.DEVICE_CODE + COMMA
				+  FUNNNEL_RAW_TABLE.COUNTRY_CODE + COMMA
				+  FUNNNEL_RAW_TABLE.LANGUAGE_CODE + COMMA
				+  FUNNNEL_RAW_TABLE.OS_CODE + COMMA
				+  FUNNNEL_RAW_TABLE.DAYOFWEEK_CODE + COMMA
				+  FUNNNEL_RAW_TABLE.HOUROFDAY_CODE + COMMA
				+  FUNNNEL_RAW_TABLE.COOKIE_JSON + COMMA
				+  FUNNNEL_RAW_TABLE.URLPARAM_JSON + COMMA
				+  FUNNNEL_RAW_TABLE.JS_VARIABLE_JSON + COMMA
				+  FUNNNEL_RAW_TABLE.CUSTOM_DIMENSION_JSON + COMMA
				+  FUNNNEL_RAW_TABLE.SESSION_ID + COMMA
				+  FUNNNEL_RAW_TABLE.TIME// NO I18N
				+ ") " // NO I18N
				+ "values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);"; // NO I18N
	}
	
	/**
	 * @param dbspaceId
	 * @return
	 */
	public static String getFunnelRawDataCreateTableQuery(String activeVisitorRawdataTable) {
		return "CREATE TABLE "+activeVisitorRawdataTable
				+" ("
				+  FUNNNEL_RAW_TABLE.FUNNEL_DATA_RAW_ID + " BIGINT NOT NULL,"
				+  FUNNNEL_RAW_TABLE.EXPERIMENT_ID +" BIGINT NOT NULL references EXPERIMENT(EXPERIMENT_ID) ON DELETE CASCADE,"
				+  FUNNNEL_RAW_TABLE.STEP_ID +" BIGINT NOT NULL references FUNNEL_STEPS(STEP_ID) ON DELETE CASCADE,"
				+  FUNNNEL_RAW_TABLE.BROWSER_CODE +" INTEGER,"
				+  FUNNNEL_RAW_TABLE.DEVICE_CODE +" INTEGER,"
				+  FUNNNEL_RAW_TABLE.COUNTRY_CODE +" INTEGER,"
				+  FUNNNEL_RAW_TABLE.LANGUAGE_CODE +" INTEGER,"
				+  FUNNNEL_RAW_TABLE.OS_CODE +" INTEGER,"
				+  FUNNNEL_RAW_TABLE.DAYOFWEEK_CODE +" INTEGER,"
				+  FUNNNEL_RAW_TABLE.HOUROFDAY_CODE +" INTEGER,"
				+  FUNNNEL_RAW_TABLE.COOKIE_JSON +" JSONB,"
				+  FUNNNEL_RAW_TABLE.URLPARAM_JSON +" JSONB,"
				+  FUNNNEL_RAW_TABLE.JS_VARIABLE_JSON +" JSONB,"
				+  FUNNNEL_RAW_TABLE.CUSTOM_DIMENSION_JSON +" JSONB,"
				+  FUNNNEL_RAW_TABLE.TIME + " BIGINT,"
				+  FUNNNEL_RAW_TABLE.SESSION_ID + " BIGINT," // NO I18N
				+ "PRIMARY KEY ("+FUNNNEL_RAW_TABLE.FUNNEL_DATA_RAW_ID+")" // NO I18N
				+ ");"; //No I18N;
	}
	
	public static final String TOTAL_SESSION_WITHOUT_DIMS = "select count(" // NO I18N
												+ FUNNEL_RAW_DATA_NODIM.SESSION_ID
												+ ") from " // NO I18N
												+ FUNNEL_RAW_DATA_NODIM.TABLE
												+ " where "  // NO I18N
												+ FUNNEL_RAW_DATA_NODIM.EXPERIMENT_ID + " = ? and " // NO I18N
												+ FUNNEL_RAW_DATA_NODIM.STEP_ID + " = ? "
												+ " group by " // NO I18N
												+ FUNNEL_RAW_DATA_NODIM.SESSION_ID;
	
	/**
	 * @param stepCount
	 * Prepared statement param index
	 * 1 - Start Date,
	 * 2 - End Date,
	 * 3 - Experiment Id,
	 * 4..... - StepIds,
	 * n - Path pattern,
	 * Count alias - COUNT
	 * @return
	 */
	public static String getFunnelReportNoDimsQuery(Integer stepCount) {
		return  "select count(*) as COUNT from (" // NO I18N
					 + "select PATH, " // NO I18N
					 + FUNNEL_RAW_DATA_NODIM.SESSION_ID
					 + " from (" // NO I18N
							 + "SELECT " // NO I18N
							 + "string_agg(cast("+ FUNNEL_RAW_DATA_NODIM.STEP_ID + " as varchar), ',' order by " + FUNNEL_RAW_DATA_NODIM.TIME+ ") as PATH, " // NO I18N
							 + FUNNEL_RAW_DATA_NODIM.SESSION_ID
							 + " FROM " // NO I18N
							 + FUNNEL_RAW_DATA_NODIM.TABLE

							 + " where (" // NO I18N
							 + FUNNEL_RAW_DATA_NODIM.TIME
							 + " between ? and ?)" // NO I18N
							 + " and " // NO I18N
							 + "("+FUNNEL_RAW_DATA_NODIM.EXPERIMENT_ID+"=?)"
							 + " and " // NO I18N
							 + "("+ FUNNEL_RAW_DATA_NODIM.STEP_ID + " in (" + StringUtils.join(Collections.nCopies(stepCount, "?"), ",")
							 + "))" 
							 + " group by "+ FUNNEL_RAW_DATA_NODIM.SESSION_ID // NO I18N
					 + ") a where path like ?" // NO I18N
				 + ") b"; // NO I18N
	}

}
