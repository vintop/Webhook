//$Id$
package com.zoho.abtest.funnel.report;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.UpdateQuery;
import com.adventnet.ds.query.UpdateQueryImpl;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.persistence.WritableDataObject;
import com.zoho.abtest.FUNNEL_RAW_TABLE_META;
import com.zoho.abtest.common.ZABColumn;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.funnel.report.FunnelReportConstants.FUNNNEL_RAW_TABLE;
import com.zoho.abtest.utility.ZABUtil;

public class FunnelRawTableDetails extends ZABModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@ZABColumn(name=FUNNEL_RAW_TABLE_META.FUNNEL_RAW_TABLE_META_ID)
	private Long funnelRawTableDataId;
	
	@ZABColumn(name=FUNNEL_RAW_TABLE_META.TABLE_NAME)
	private String rawTableName;
	
	@ZABColumn(name=FUNNEL_RAW_TABLE_META.CREATED_DATE)
	private Long createdTime;
	
	@ZABColumn(name=FUNNEL_RAW_TABLE_META.IS_ACTIVE)
	private Boolean isActive;

	public Long getFunnelRawTableDataId() {
		return funnelRawTableDataId;
	}

	public void setFunnelRawTableDataId(Long funnelRawTableDataId) {
		this.funnelRawTableDataId = funnelRawTableDataId;
	}

	public String getRawTableName() {
		return rawTableName;
	}

	public void setRawTableName(String rawTableName) {
		this.rawTableName = rawTableName;
	}

	public Long getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Long createdTime) {
		this.createdTime = createdTime;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	
	public static FunnelRawTableDetails createFunnelRawTableMeta(String dbspaceId, Boolean isActive) throws Exception {
		
		String tableName = FUNNNEL_RAW_TABLE.generateRawTableName(dbspaceId);
		Long timeInMillis = ZABUtil.getCurrentTimeInMilliSeconds();
		if(isActive) {
			makeAllInActive();
		}
		DataObject dobj = new WritableDataObject();
		Row row = new Row(FUNNEL_RAW_TABLE_META.TABLE);
		row.set(FUNNEL_RAW_TABLE_META.TABLE_NAME, tableName);
		row.set(FUNNEL_RAW_TABLE_META.CREATED_DATE, timeInMillis);
		row.set(FUNNEL_RAW_TABLE_META.IS_ACTIVE, isActive);
		dobj.addRow(row);
		updateDataObject(dobj);
		
		return getModelFromRow(row, FunnelRawTableDetails.class);
		
	}
	
	public static void makeAllInActive() throws Exception {
		Criteria c = new Criteria(new Column(FUNNEL_RAW_TABLE_META.TABLE, FUNNEL_RAW_TABLE_META.IS_ACTIVE), Boolean.TRUE, QueryConstants.EQUAL);
		UpdateQuery query = new UpdateQueryImpl(FUNNEL_RAW_TABLE_META.TABLE);
		query.setCriteria(c);
		query.setUpdateColumn(FUNNEL_RAW_TABLE_META.IS_ACTIVE, Boolean.FALSE);
		updateRow(query);
	}
	
	public static FunnelRawTableDetails getActiveRawTable() throws Exception {
		FunnelRawTableDetails funnelRawTableDetails = null;
		Criteria c = new Criteria(new Column(FUNNEL_RAW_TABLE_META.TABLE, FUNNEL_RAW_TABLE_META.IS_ACTIVE), Boolean.TRUE, QueryConstants.EQUAL);
		DataObject dobj = getRow(FUNNEL_RAW_TABLE_META.TABLE, c);
		if(dobj.containsTable(FUNNEL_RAW_TABLE_META.TABLE)) {
			funnelRawTableDetails = getFirstModelFromDobj(dobj, FUNNEL_RAW_TABLE_META.TABLE, FunnelRawTableDetails.class);
		}
		return funnelRawTableDetails;
	}
}
