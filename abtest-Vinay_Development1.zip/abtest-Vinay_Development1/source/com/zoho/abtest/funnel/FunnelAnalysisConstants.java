//$Id$
package com.zoho.abtest.funnel;

import java.util.ArrayList;
import java.util.List;

import com.zoho.abtest.FUNNEL_ANALYSIS;
import com.zoho.abtest.FUNNEL_STEPS;
import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.MatchType;
import com.zoho.abtest.common.ZABConstants;

public class FunnelAnalysisConstants {
	
	public static final String STEP_API_MODULE_NAME = "step"; //NO I18N
	
	public static final String STEP_API_MODULE_NAME_PLURAL = "steps"; //NO I18N
	
	public static final String STEP_API_RESOURCE_NAME_INITIAL = "Step"; //NO I18N
	
	public static final String STEP_1 = "Step 1"; //NO I18N
	
	public static final String DISPLAY_NAME = "display_name"; //NO I18N
	
	public static final String SESSION_TIME = "session_time"; //NO I18N
	
	public static final String STEP_URLS = "step_urls"; //NO I18N
	
	public static final String MATCH_TYPE = "match_type"; //NO I18N
	
	public static final String CUSTOM_EVENT_LN = "custom_event_linkname"; //NO I18N
	
	public static final String CUSTOM_EVENT_ID = "custom_event_id"; //NO I18N
	
	public static final String VALUE = "value"; //NO I18N
	
	public static final String STEP_ORDER = "step_order"; //NO I18N
	
	public static final String STEP_KEY = "step_key"; //NO I18N
	
	public static final String EXPERIMENT_LINKNAME = "experiment_linkname"; //NO I18N
	
	public static final String EXPERIMENT_ID = "experiment_id"; //NO I18N
	
	public static final String STEP_COUNT = "step_count"; //NO I18N
	
	public static final String FUNNEL_CONVERSION_RATE = "funnel_conversion_rate"; //NO I18N
	
	//Default session time in milliseconds - 30 days
	public static final String DEFAULT_SESSION_TIME = "2592000000"; //NO I18N
	
	public final static List<Constants> FUNNEL_ANALYSIS_TABLE;
	
	public final static List<Constants> FUNNEL_STEPS_TABLE;
	
	public final static String STEPS = "steps"; //NO I18N
	
	public final static String FUNNEL_LOW_STEP_ERROR = "experiment.minimum.funnel.steps.count.error"; //NO I18N
	
	static {
		ArrayList<Constants> list = new ArrayList<Constants>();
		list.add(new Constants(DISPLAY_NAME, FUNNEL_STEPS.STEP_NAME, ZABConstants.STRING, Boolean.TRUE));
//		list.add(new Constants(STEP_URLS, FUNNEL_STEPS.STEP_URLS, ZABConstants.STRING, Boolean.TRUE));
		list.add(new Constants(STEP_ORDER, FUNNEL_STEPS.STEP_ORDER, ZABConstants.INTEGER, Boolean.TRUE));
		list.add(new Constants(MATCH_TYPE, FUNNEL_STEPS.STEP_MATCH_TYPE, ZABConstants.INTEGER, Boolean.TRUE));
		list.add(new Constants(VALUE, FUNNEL_STEPS.STEP_VALUE, ZABConstants.STRING, Boolean.TRUE));
		list.add(new Constants(EXPERIMENT_ID, FUNNEL_STEPS.EXPERIMENT_ID, ZABConstants.LONG, Boolean.FALSE));
		list.add(new Constants(ZABConstants.LINKNAME, FUNNEL_STEPS.STEP_LINKNAME, ZABConstants.STRING, Boolean.FALSE));
		list.add(new Constants(STEP_KEY, FUNNEL_STEPS.STEP_KEY, ZABConstants.STRING, Boolean.FALSE));
		FUNNEL_STEPS_TABLE = list;
	}
	
	static {
		ArrayList<Constants> list = new ArrayList<Constants>();
		list.add(new Constants(EXPERIMENT_ID, FUNNEL_ANALYSIS.EXPERIMENT_ID, ZABConstants.LONG, Boolean.TRUE));
		list.add(new Constants(SESSION_TIME, FUNNEL_ANALYSIS.SESSION_TIME, ZABConstants.LONG, Boolean.TRUE));
		FUNNEL_ANALYSIS_TABLE = list;
	}
	
	public enum FunnelMatchType {
		
		SIMPLE_MATCH(1),
		EXACT_MATCH(2),
		PATTERN_MATCH(3),
		REGEX_MATCH(4),
		CONTAINS_MATCH(5),
		STARTS_WITH(6),
		ENDS_WITH(7),
		URLLESS(8);
		
		private Integer matchTypeId;
		
		private FunnelMatchType(Integer matchTypeId) {
			this.matchTypeId = matchTypeId;
		}

		public Integer getMatchTypeId() {
			return matchTypeId;
		}
		
		public static FunnelMatchType getMatchTypeById(Integer matchTypeId) {
			if(matchTypeId!=null) {
				for(FunnelMatchType mtype: FunnelMatchType.values()) {
					if(matchTypeId.equals(mtype.getMatchTypeId())) {
						return mtype;
					}
				}
			}
			return null;
	   }
}
	
}
