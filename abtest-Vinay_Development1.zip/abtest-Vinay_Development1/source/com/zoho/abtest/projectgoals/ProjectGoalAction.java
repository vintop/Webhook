//$Id$
package com.zoho.abtest.projectgoals;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.json.JSONException;

import com.opensymphony.xwork2.ActionSupport;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.goal.Goal;
import com.zoho.abtest.goal.GoalConstants;
import com.zoho.abtest.goal.GoalReports;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.project.ProjectConstants;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.utility.ZABUtil;

public class ProjectGoalAction  extends ActionSupport implements ServletResponseAware, ServletRequestAware{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final Logger LOGGER = Logger.getLogger(ProjectGoalAction.class.getName());

	private HttpServletRequest request;

	private HttpServletResponse response;

	private String linkname;

	public String getLinkname() {
		return linkname;
	}

	public void setLinkname(String linkname) {
		this.linkname = linkname;
	}

	@Override
	public void setServletRequest(HttpServletRequest request) {
		this.request = request;
	}

	@Override
	public void setServletResponse(HttpServletResponse response) {
		this.response = response;
	}

	public String execute() throws IOException, JSONException  {

		ArrayList<Goal> projGoals = new ArrayList<Goal>();
		try {			
			switch(ZABAction.getHTTPMethod(request)) {
			case POST:	
			{
				HashMap<String,String> hs = ZABAction.getRequestParser(request).parseGoal(request);
				if(hs.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					ProjectGoal projgoal = new ProjectGoal();
					projgoal.setSuccess(Boolean.FALSE);
					projgoal.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
					projGoals.add(projgoal);
				}else{
					Goal newgoal = Goal.createGoal(hs,Boolean.TRUE);
					newgoal.setAvgTimeToAchieveGoal(0l);
					newgoal.setUniqueGoalAchievedCount(0l);
					newgoal.setUniqueVisitors(0l);
					projGoals.add(newgoal);
				}
			}
			break;
			case GET:
				String projectLinkName = request.getParameter(GoalConstants.PROJECT_QUERY_KEY);
				if(projectLinkName!=null && !projectLinkName.isEmpty()){
					projGoals.addAll(ProjectGoal.getProjectGoalsForProject(Project.getProjectId(projectLinkName)));
					
				}
				else{
					if(linkname!=null &&  !linkname.isEmpty()){
						projGoals.addAll(ProjectGoal.getProjectGoalsForGoal(linkname,null,null,null));
					}
					
				}
				break;
			case DELETE:
				if(linkname!=null) {						
				  projGoals.add( Goal.deleteGoal(linkname));
					
				}
				break;
			case PUT:
				HashMap<String,String> hs = ZABAction.getRequestParser(request).parseGoal(request);
				if(hs.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					ProjectGoal pgoal = new ProjectGoal();
					pgoal.setSuccess(Boolean.FALSE);
					pgoal.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
					projGoals.add(pgoal);
				}else{
					projGoals.add(Goal.updateGoal(hs, Boolean.TRUE));
				}
				break;
			}
		}catch(JSONException ex){	
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getInvalidInputFormatException(GoalConstants.API_MODULE_PLURAL));
			return null; 	
		} catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE),GoalConstants.API_MODULE_PLURAL));
			return null; 	
		}		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getGoalResponse(request, projGoals));		
		return null;	
	}
	public String goalReports() throws IOException, JSONException  {

		ArrayList<GoalReports> goalreports = new ArrayList<GoalReports>();
		try {			
			switch(ZABAction.getHTTPMethod(request)) {
			case POST:	
			{
				HashMap<String,String> hs = ZABAction.getRequestParser(request).parseReport(request);
				if(hs.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					GoalReports goals = new GoalReports();
					goals.setSuccess(Boolean.FALSE);
					goals.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
					goalreports.add(goals);
				}else{
					String detailRequired  = request.getParameter(GoalConstants.GOAL_REPORT_INFO);
					if(detailRequired!=null && !detailRequired.isEmpty()){
						switch(detailRequired){
						case ElasticSearchConstants.COUNTRY:
							goalreports.addAll(GoalReports.getCountryReportsForGoal(hs));
							break;
						case ElasticSearchConstants.DEVICE:
							goalreports.addAll(GoalReports.getDeviceReportsForGoal(hs));
							break;
						case ElasticSearchConstants.URL:
							goalreports.addAll(GoalReports.getUrlReportsForGoal(hs));
							break;
						}
					}else{
						goalreports.addAll(GoalReports.getGoalReportsForGoal(hs));
					}
				}
			}
			break;
			}
		}catch(JSONException ex){	
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getInvalidInputFormatException(GoalConstants.API_MODULE_PLURAL));
			return null; 	
		} catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), GoalConstants.API_MODULE_PLURAL));
			return null; 	
		}		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getGoalReportResponse(request, goalreports));		
		return null;	
	}
	
	
	

}
