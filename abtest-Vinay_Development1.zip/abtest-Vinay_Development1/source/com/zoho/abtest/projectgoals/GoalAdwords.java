//$Id$
package com.zoho.abtest.projectgoals;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.lucene.search.join.ScoreMode;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.NestedQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.AggregationBuilder;

import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.goal.GoalReports;
import com.zoho.abtest.integration.GoogleAdwords;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.utility.ZABUtil;

public class GoalAdwords {
	private static final Logger LOGGER = Logger.getLogger(GoalAdwords.class.getName());

	
	public static ArrayList<String>  getAllGoalVisitors(String multiSegmentCriteria, String startTimeInMillis, String endTimeInMillis, String goalLinkName, String indexName, String portal, String projectId){
		SearchResponse response = null;
		Long goalId = null;
		try{
			goalId = ProjectGoal.getGoalIdForGoal(goalLinkName);
			Long startTimeInMilliss = ZABUtil.getTimeInLongFromDateFormStr(startTimeInMillis, "yyyy-MM-dd");		// NO I18N
			Long endTimeInMilliss = ZABUtil.getTimeInLongFromDateFormStr(endTimeInMillis, "yyyy-MM-dd");		// NO I18N
			//Get the long value end date's last milli second
			endTimeInMilliss =  ZABUtil.getNthDayDateInLong(endTimeInMilliss, 1) - 1;
			QueryBuilder boolQuery = generateGclidQuery(portal,Long.parseLong(projectId),goalId,startTimeInMilliss,endTimeInMilliss,multiSegmentCriteria);
			List<AggregationBuilder> cardinalityAggregation = GoogleAdwords.generateGCLIDAggregation();
			response = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.VISITOR_RAW_TYPE, 0, boolQuery, cardinalityAggregation);

		}
		catch(Exception ex){
			LOGGER.log(Level.SEVERE, "!!!!!!!!! getAllFormsVisitors "+ex.getMessage(),ex);
		}
		return GoogleAdwords.readGCLIDresponse(response);
	}

	public static ArrayList<String>  getAllGoalConversions(String multiSegmentCriteria, String startTimeInMillis, String endTimeInMillis, String goalLinkName, String indexName, String portal, String projectId){
		SearchResponse response = null;
		Long goalId = null;
		try{
			goalId = ProjectGoal.getGoalIdForGoal(goalLinkName);
			Long startTimeInMilliss = ZABUtil.getTimeInLongFromDateFormStr(startTimeInMillis, "yyyy-MM-dd");		// NO I18N
			Long endTimeInMilliss = ZABUtil.getTimeInLongFromDateFormStr(endTimeInMillis, "yyyy-MM-dd");		// NO I18N
			endTimeInMilliss =  ZABUtil.getNthDayDateInLong(endTimeInMilliss, 1) - 1;
			QueryBuilder boolQuery = generateGclidQuery(portal,Long.parseLong(projectId),goalId,startTimeInMilliss,endTimeInMilliss,multiSegmentCriteria);
			List<AggregationBuilder> cardinalityAggregation = GoogleAdwords.generateGCLIDAggregation();
			response = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.GOAL_RAW_TYPE, 0, boolQuery, cardinalityAggregation);

		}
		catch(Exception ex){
			LOGGER.log(Level.SEVERE, "!!!!!!!!! getAllFormsVisitors "+ex.getMessage(),ex);
		}
		return GoogleAdwords.readGCLIDresponse(response);
	}

	public static BoolQueryBuilder generateGclidQuery(String portal,Long projectid,Long goalId, Long startTime, Long endTime, String multisegmentCriteria ){
		BoolQueryBuilder boolQuery =  GoalReports.queryBuilder(portal,projectid,goalId,startTime,endTime,multisegmentCriteria);
		List<QueryBuilder> paramList = new ArrayList<QueryBuilder>();
		paramList.add(QueryBuilders.matchQuery("nurlparameter.name", "gclid"));// No I18N
		BoolQueryBuilder conditionQueries = QueryBuilders.boolQuery();
		conditionQueries.must().addAll(paramList);
		NestedQueryBuilder nestedQuery = QueryBuilders.nestedQuery("nurlparameter", conditionQueries, ScoreMode.None);    //No I18N
		boolQuery.must(nestedQuery);
		return boolQuery;
	}
}
