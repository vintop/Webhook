//$Id$
package com.zoho.abtest.projectgoals;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.MatchQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.index.query.TermsQueryBuilder;
import org.elasticsearch.script.Script;
import org.elasticsearch.script.ScriptType;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.aggregations.metrics.cardinality.CardinalityAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.cardinality.InternalCardinality;
import org.elasticsearch.search.aggregations.metrics.tophits.TopHitsAggregationBuilder;
import org.elasticsearch.search.sort.SortOrder;

import com.adventnet.iam.IAMUtil;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.elastic.ESCommonQuickFilterStatistics;
import com.zoho.abtest.elastic.ESFunnelQuickFilterStatistics;
import com.zoho.abtest.elastic.ESQuickFilterConstants;
import com.zoho.abtest.elastic.ESQuickFilterStatistics;
import com.zoho.abtest.elastic.ESQuickFilterWrapper;
import com.zoho.abtest.elastic.ElasticSearchStatistics;
import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.elastic.ESQuickFilterConstants.QuickFilterAttributes;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentType;
import com.zoho.abtest.goal.Goal;
import com.zoho.abtest.goal.GoalConstants;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.report.ReportConstants;
import com.zoho.abtest.utility.ZABUtil;


public class GoalQuickFilterStatistics extends ESQuickFilterStatistics{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static final Logger LOGGER = Logger.getLogger(GoalQuickFilterStatistics.class.getName());
	
	public static List<ESQuickFilterStatistics> getQuickFilterSegmentVisitorCount(Long goalid,
			String indexName, String portal, String segmentName, Long startTime, Long endTime,HashMap<String, String> qfNestedParentCond,HashMap<String, String> additionalFilters)
	{
		List<ESQuickFilterStatistics> visitorReportDetails;
		QueryBuilder query =  null;
		AggregationBuilder aggregation = null;
		int size = 0 ;
		try
		{
			
			if(segmentName.equals(QuickFilterAttributes.TRAFFICSOURCE.getLinkName())){
				visitorReportDetails = calculateDetailsForSource(goalid,indexName, portal, segmentName,startTime, endTime,qfNestedParentCond, additionalFilters);
				return visitorReportDetails;
			}

			if(segmentName.equals(QuickFilterAttributes.USERTYPE.getLinkName())){
				visitorReportDetails = calculateDetailsForVisitorType(goalid,indexName, portal, segmentName,startTime, endTime,qfNestedParentCond, additionalFilters);
					return visitorReportDetails;
			}
			
			query = generateQuickFilterSourceQueryJson(portal, startTime, endTime, qfNestedParentCond, additionalFilters,goalid,null,null);
			aggregation  =   generateQuickFilterVistorAggregateJson(segmentName);
			SearchResponse response = null;
			response = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.VISITOR_RAW_TYPE, size, query, aggregation);
			visitorReportDetails = readQuickFilterVisitorResponseData(response);
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage());
			visitorReportDetails = new ArrayList<ESQuickFilterStatistics>();
		}
		return visitorReportDetails;
	}
	
	private static Boolean isABSplitLazyLoadSegments(String segmentName) {
		return segmentName.equals(QuickFilterAttributes.TRAFFICSOURCE.getLinkName()) || segmentName.equals(QuickFilterAttributes.USERTYPE.getLinkName());
	}
		
	public static List<ESQuickFilterWrapper> getQuickFilterMultiSegmentVisitorCount(Long goalid,String indexName, String portal ,
			Long startTime, Long endTime,HashMap<String, String> additionalFilters, List<QuickFilterAttributes> quickFilterAttrs)
	{
		List<ESQuickFilterWrapper> wrappers = new ArrayList<ESQuickFilterWrapper>();
		QueryBuilder query =  null;
		AggregationBuilder aggregation = null;
		int size = 0 ;
		try
		{

			query = generateQuickFilterSourceQueryJson(portal, startTime, endTime, null, additionalFilters, goalid, null, null);

			ArrayList<AggregationBuilder> builders = new ArrayList<AggregationBuilder>();
			for(QuickFilterAttributes attrs: quickFilterAttrs) {	
				if(!isABSplitLazyLoadSegments(attrs.getLinkName())) {					
					aggregation  =   generateQuickFilterVistorAggregateJson(attrs.getLinkName(), attrs.getLinkName());
					builders.add(aggregation);
				}
			}
			SearchResponse response = null;
			response = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.VISITOR_RAW_TYPE, size, query, builders);
			wrappers = readQuickFilterVisitorResponseData(response, quickFilterAttrs);

			try {
				LOGGER.log(Level.INFO, "UserType fetch start for multiquick segment");
				List<ESQuickFilterWrapper> userTypeWrapList = wrappers.stream().filter(
						(a) -> a.getAttribute()
						.getLinkName()
						.equals(QuickFilterAttributes.USERTYPE
								.getLinkName())).collect(Collectors.toList());

				List<ESQuickFilterStatistics> visitorTypeData = calculateDetailsForVisitorType(goalid , indexName, portal, QuickFilterAttributes.USERTYPE.getLinkName(),
						startTime, endTime,null, additionalFilters);

				if(userTypeWrapList.size() > 0 && visitorTypeData.size() > 0) {
					userTypeWrapList.get(0).setVisitorData(new ArrayList<ESQuickFilterStatistics>(visitorTypeData));
					userTypeWrapList.get(0).sortAndAddFillers();
				}

				LOGGER.log(Level.INFO, "UserType fetch end for multiquick segment");
			} catch (Exception e) {
				LOGGER.log(Level.SEVERE, e.getMessage());
			}

		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage());
			wrappers = new ArrayList<ESQuickFilterWrapper>();
		}
		return wrappers;
	}
			
			
	public static List<ESQuickFilterStatistics> calculateDetailsForSource(Long goalid , String indexName, String portal, String segmentName ,
			Long startTime, Long endTime,
			HashMap<String, String> qfNestedParentCond,
			HashMap<String, String> additionalFilters){
		List<ESQuickFilterStatistics> visitorReportDetails = new ArrayList<ESQuickFilterStatistics>();
		int size = 0 ;
		try{

			TopHitsAggregationBuilder tophitsaggr = AggregationBuilders.topHits("tophits").	// NO I18N
					fetchSource(segmentName, null).size(1).sort("time");	// NO I18N

			TermsAggregationBuilder termsaggr= AggregationBuilders.terms("visitorid").  // No I18N
					field("visitorid").	// NO I18N
					size(ElasticSearchConstants.VISITOR_MAX_COUNT)
					.subAggregation(tophitsaggr);
			
			TermsAggregationBuilder uuidTermsaggr= AggregationBuilders.terms("uuidVisitorId").  // No I18N
					field(ElasticSearchConstants.UUID).	
					size(ElasticSearchConstants.VISITOR_MAX_COUNT)
					.subAggregation(tophitsaggr);

			
			QueryBuilder query = generateQuickFilterSourceQueryJson(portal, startTime, endTime, qfNestedParentCond, additionalFilters,goalid,null,null);
			SearchResponse response = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.GOAL_RAW_TYPE, size, query, termsaggr);
			Aggregations aggrResponse = response.getAggregations();
			Terms terms = aggrResponse.get("visitorid");
			List<? extends Bucket> buckets = terms.getBuckets();

			HashMap<String,Long> sourceHs = new HashMap<String,Long>();
			ArrayList<Long> goalAchievedPersons = new ArrayList<Long>();
			ArrayList<String> goalAchievedPersonsString = new ArrayList<String>();
			for(Bucket bucket:buckets)
			{

				Long visitorid = (Long) bucket.getKey();
				Aggregations buckaggrResponse = bucket.getAggregations();
				org.elasticsearch.search.aggregations.metrics.tophits.InternalTopHits tophits = buckaggrResponse.get("tophits");	// NO I18N

				String source = (String) tophits.getHits().getAt(0).getSource().get("trafficsource");	// NO I18N
				if(sourceHs.containsKey(source)){
					Long oldCount = sourceHs.get(source);
					sourceHs.put(source, oldCount+1);
				}else{
					sourceHs.put(source, 1l);
				}
				goalAchievedPersons.add(visitorid);
			}
			
			response = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.GOAL_RAW_TYPE, size, query, uuidTermsaggr);

			aggrResponse = response.getAggregations();
			terms = aggrResponse.get("uuidVisitorId");
			buckets = terms.getBuckets();
			for(Bucket bucket:buckets)
			{

				String visitorid = (String) bucket.getKey();
				Aggregations buckaggrResponse = bucket.getAggregations();
				org.elasticsearch.search.aggregations.metrics.tophits.InternalTopHits tophits = buckaggrResponse.get("tophits");	// NO I18N

				String source = (String) tophits.getHits().getAt(0).getSource().get("trafficsource");	// NO I18N
				if(sourceHs.containsKey(source)){
					Long oldCount = sourceHs.get(source);
					sourceHs.put(source, oldCount+1);
				}else{
					sourceHs.put(source, 1l);
				}
				goalAchievedPersonsString.add(visitorid);
			}
			
			query = generateQuickFilterSourceQueryJson(portal, startTime, endTime, qfNestedParentCond, additionalFilters,goalid,goalAchievedPersons,null);
			response = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.VISITOR_RAW_TYPE, size, query, termsaggr);
			aggrResponse = response.getAggregations();
			terms = aggrResponse.get("visitorid");	// NO I18N
			buckets = terms.getBuckets();
			for(Bucket bucket:buckets)
			{
				//Long visitorid = (Long) bucket.getKey();
				Aggregations buckaggrResponse = bucket.getAggregations();
				org.elasticsearch.search.aggregations.metrics.tophits.InternalTopHits tophits = buckaggrResponse.get("tophits");	// NO I18N
				String source = (String) tophits.getHits().getAt(0).getSource().get("trafficsource");	// NO I18N
				if(sourceHs.containsKey(source)){
					Long oldval = (Long)sourceHs.get(source);
					sourceHs.put(source, 1+oldval);
				}else{
					sourceHs.put(source, 1l);
				}
				
			}
			
			query = generateQuickFilterSourceQueryJson(portal, startTime, endTime, qfNestedParentCond, additionalFilters,goalid,null,goalAchievedPersonsString);
			response = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.VISITOR_RAW_TYPE, size, query, uuidTermsaggr);
			aggrResponse = response.getAggregations();
			terms = aggrResponse.get("uuidVisitorId");	// NO I18N
			buckets = terms.getBuckets();
			for(Bucket bucket:buckets)
			{
				//Long visitorid = (Long) bucket.getKey();
				Aggregations buckaggrResponse = bucket.getAggregations();
				org.elasticsearch.search.aggregations.metrics.tophits.InternalTopHits tophits = buckaggrResponse.get("tophits");	// NO I18N
				String source = (String) tophits.getHits().getAt(0).getSource().get("trafficsource");	// NO I18N
				if(sourceHs.containsKey(source)){
					Long oldval = (Long)sourceHs.get(source);
					sourceHs.put(source, 1+oldval);
				}else{
					sourceHs.put(source, 1l);
				}
				
			}
			
			Set<String> keySet = sourceHs.keySet();
			Iterator<String> keyItr = keySet.iterator();
			while(keyItr.hasNext()){
				String key  = keyItr.next();
				Long value  =sourceHs.get(key);
				ESQuickFilterStatistics esq= new ESQuickFilterStatistics();
				esq.setSegmentValue(key);
				esq.setVisitorCount(value);
				esq.setSuccess(Boolean.TRUE);
				visitorReportDetails.add(esq);
			}

		}catch(Exception e){
			LOGGER.log(Level.SEVERE,"Exception occurred in processing source filter",e);
		}

		return visitorReportDetails;
	}
			
	public static List<ESQuickFilterStatistics> calculateDetailsForVisitorType(Long goalid , String indexName, String portal, String segmentName ,
			Long startTime, Long endTime,
			HashMap<String, String> qfNestedParentCond,
			HashMap<String, String> additionalFilters){
		List<ESQuickFilterStatistics> visitorReportDetails = new ArrayList<ESQuickFilterStatistics>();
		int size = 0 ;
		try{
			
			TopHitsAggregationBuilder tophitsaggr = AggregationBuilders.topHits("tophits").	// NO I18N
					fetchSource(segmentName, null).size(1).sort("time",SortOrder.DESC);	// NO I18N
			
			TermsAggregationBuilder termsaggr= AggregationBuilders.terms("visitorid").  // No I18N
					field("visitorid").	// NO I18N
					size(ElasticSearchConstants.VISITOR_MAX_COUNT)
					.subAggregation(tophitsaggr);
			
			TermsAggregationBuilder uuidTermsaggr= AggregationBuilders.terms("uuidVisitorId").  // No I18N
					field(ElasticSearchConstants.UUID).	
					size(ElasticSearchConstants.VISITOR_MAX_COUNT)
					.subAggregation(tophitsaggr);
					
		
			QueryBuilder query = generateQuickFilterSourceQueryJson(portal, startTime, endTime, qfNestedParentCond, additionalFilters,goalid,null,null);
			SearchResponse response = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.VISITOR_RAW_TYPE, size, query, termsaggr);
			Aggregations aggrResponse = response.getAggregations();
			Terms terms = aggrResponse.get("visitorid");
			List<? extends Bucket> buckets = terms.getBuckets();

			Long newCount = 0l;
			Long returningCount = 0l;
			for(Bucket bucket:buckets)
			{
				Aggregations buckaggrResponse = bucket.getAggregations();
				org.elasticsearch.search.aggregations.metrics.tophits.InternalTopHits tophits = buckaggrResponse.get("tophits");	// NO I18N
				String usertype = (String) tophits.getHits().getAt(0).getSource().get("usertype");	// NO I18N
				if(usertype.equals("NEW")){
					newCount++;
				}else{
					returningCount++;
				}
				
			}
			
			response = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.VISITOR_RAW_TYPE, size, query, uuidTermsaggr);
			aggrResponse = response.getAggregations();
			terms = aggrResponse.get("uuidVisitorId");
			buckets = terms.getBuckets();

			for(Bucket bucket:buckets)
			{
				Aggregations buckaggrResponse = bucket.getAggregations();
				org.elasticsearch.search.aggregations.metrics.tophits.InternalTopHits tophits = buckaggrResponse.get("tophits");	// NO I18N
				String usertype = (String) tophits.getHits().getAt(0).getSource().get("usertype");	// NO I18N
				if(usertype.equals("NEW")){
					newCount++;
				}else{
					returningCount++;
				}
				
			}
			
			ESQuickFilterStatistics newesq= new ESQuickFilterStatistics();
			newesq.setSegmentValue(ESQuickFilterConstants.NEW_VISITOR);
			newesq.setVisitorCount(newCount);
			newesq.setSuccess(Boolean.TRUE);
			visitorReportDetails.add(newesq);
			
			ESQuickFilterStatistics returnesq= new ESQuickFilterStatistics();
			returnesq.setSegmentValue(ESQuickFilterConstants.RETURNING_VISITOR);
			returnesq.setVisitorCount(returningCount);
			returnesq.setSuccess(Boolean.TRUE);
			visitorReportDetails.add(returnesq);
			

		}catch(Exception e){
			LOGGER.log(Level.SEVERE,"Exception occurred in processing visitor based filter ",e);
		}
		return visitorReportDetails;
	}
			
	public static BoolQueryBuilder generateQuickFilterSourceQueryJson( String portal , Long startTime, Long endTime,HashMap<String, String> qfNestedParentCond, HashMap<String, String> additionalFilters , Long goalId,ArrayList<Long> excludeVisitors, ArrayList<String> excludeUuidVisitors)
	{
		BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
		try
		{
			MatchQueryBuilder portalMatch = QueryBuilders.matchQuery(ElasticSearchConstants.PORTAL, portal);
			List<QueryBuilder> conditionList = new ArrayList<QueryBuilder>();
			conditionList.add(portalMatch);
			String experimentUrl = additionalFilters.get(ESQuickFilterConstants.EXPERIMENT_URL);
			String device = additionalFilters.get(ESQuickFilterConstants.QF_DEVICE);
			
			if(startTime != null)
			{
				RangeQueryBuilder timeRange = QueryBuilders.rangeQuery("time").gte(startTime).lte(endTime); // No I18N
				conditionList.add(timeRange);
			}
			if(qfNestedParentCond != null)
			{
				for(Map.Entry<String, String> condEntry :qfNestedParentCond.entrySet())
				{
					MatchQueryBuilder condMatch = QueryBuilders.matchQuery(condEntry.getKey(), condEntry.getValue());
					conditionList.add(condMatch);
				}
			}
			if(experimentUrl!=null) {
				MatchQueryBuilder condMatch = QueryBuilders.matchQuery(ElasticSearchConstants.CURRENTURL, experimentUrl);
				conditionList.add(condMatch);
			}
			
			if(device!=null) {
				MatchQueryBuilder condMatch = QueryBuilders.matchQuery(ElasticSearchConstants.DEVICE, device.toUpperCase());
				conditionList.add(condMatch);
			}
			if(goalId!=null) {
				MatchQueryBuilder condMatch = QueryBuilders.matchQuery(ElasticSearchConstants.GOALID, goalId);
				conditionList.add(condMatch);
			}
			if(excludeVisitors!=null){
				TermsQueryBuilder termsQuery = QueryBuilders.termsQuery("visitorid", excludeVisitors);	// NO I18N
				boolQueryBuilder.mustNot().add(termsQuery);
			}
			if(excludeUuidVisitors!=null){
				TermsQueryBuilder termsQuery = QueryBuilders.termsQuery("uuid", excludeUuidVisitors);	// NO I18N
				boolQueryBuilder.mustNot().add(termsQuery);
			}
			boolQueryBuilder.must().addAll(conditionList);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
		return boolQueryBuilder;
	} 
			
	public static TermsAggregationBuilder generateQuickFilterVistorAggregateJson(String segmentName )
	{
		return generateQuickFilterVistorAggregateJson(segmentName, "segment"); //NO I18N
	}
	
	public static TermsAggregationBuilder generateQuickFilterVistorAggregateJson(String segmentName, String customAggregationName )
	{
		TermsAggregationBuilder finalAggr = null;
		try
		{
			
			CardinalityAggregationBuilder cardinalityAggregation = ElasticSearchStatistics.getVisitorCardinalityAggr();
			CardinalityAggregationBuilder uuidCardinalityAggregation = ElasticSearchStatistics.getUUIDVisitorCardinalityAggr();

			
			if(segmentName.equals(QuickFilterAttributes.DAYOFWEEK.getLinkName()) || segmentName.equals(QuickFilterAttributes.HOUROFDAY.getLinkName()))
			{
				HashMap<String, Object> params = new HashMap<String, Object>();
				String timezone =  ElasticSearchUtil.getCurrentUserTimezone();
				
				params.put(ESQuickFilterConstants.TIMEZONE, timezone);
				params.put(ESQuickFilterConstants.FIELD, ElasticSearchConstants.TIME);
				String scriptCode = null;
				if(segmentName.equals(QuickFilterAttributes.DAYOFWEEK.getLinkName()))
				{
					scriptCode = ESQuickFilterConstants.DAY_OF_WEEK_SCRIPT;
				}
				else if(segmentName.equals(QuickFilterAttributes.HOUROFDAY.getLinkName()))
				{
					scriptCode = ESQuickFilterConstants.HOUR_OF_DAY_SCRIPT;
				}
				Script script = new Script(ScriptType.INLINE, ESQuickFilterConstants.PAINLESS_LANG, scriptCode, params);
				
				finalAggr = AggregationBuilders.terms(customAggregationName).
							script(script).   
								size(ElasticSearchConstants.SEGMENT_MAX_COUNT).
									subAggregation(cardinalityAggregation).subAggregation(uuidCardinalityAggregation);
			}
			else
			{
				finalAggr = AggregationBuilders.terms(customAggregationName).
						field(segmentName).
						size(ElasticSearchConstants.SEGMENT_MAX_COUNT).
							subAggregation(cardinalityAggregation).subAggregation(uuidCardinalityAggregation);
			}
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
		return finalAggr;
	}
	
	public static List<ESQuickFilterStatistics> readQuickFilterVisitorResponseData(SearchResponse response )
	{
		return readQuickFilterVisitorResponseData(response, "segment"); //NO I18N
	}
	
	public static List<ESQuickFilterStatistics> readQuickFilterVisitorResponseData(SearchResponse response, String customSegmentName )
	{
		List<ESQuickFilterStatistics> visitorReportDetails = new ArrayList<ESQuickFilterStatistics>();
		try
		{
		
			Aggregations aggrResponse = response.getAggregations();
			Terms terms = aggrResponse.get("segment");
			List<? extends Bucket> buckets = terms.getBuckets();
			String distinctVisitors  = "distinct_visitors"; //No I18N
			for(Bucket bucket:buckets)
			{
				String segmentValue = (String)bucket.getKey();
				Long uniqueCount = 0l;
				Aggregations buckaggrResponse = bucket.getAggregations();
				InternalCardinality cardinality = buckaggrResponse.get(distinctVisitors);
				InternalCardinality uuidCardinality = buckaggrResponse.get("distinct_uuid_visitors");
				uniqueCount = cardinality.getValue() + uuidCardinality.getValue();
				ESQuickFilterStatistics stat = new ESQuickFilterStatistics();
				stat.setSegmentValue(segmentValue);
				stat.setVisitorCount(uniqueCount);
				stat.setSuccess(true);
				visitorReportDetails.add(stat);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			visitorReportDetails = new ArrayList<ESQuickFilterStatistics>();
		}
		return visitorReportDetails;
	}
	

	public static List<ESQuickFilterWrapper> readQuickFilterVisitorResponseData(SearchResponse response, List<QuickFilterAttributes> attribs )
	{
		List<ESQuickFilterWrapper> visitorReportDetails = new ArrayList<ESQuickFilterWrapper>();
		try
		{
			Aggregations aggrResponse = response.getAggregations();
			String uniqueVisitorVariable = "distinct_visitors";//No I18N
			
			for(QuickFilterAttributes attrib: attribs) {
				
				ESQuickFilterWrapper wrapper = new ESQuickFilterWrapper();
				wrapper.setAttribute(attrib);
				if(!isABSplitLazyLoadSegments(attrib.getLinkName())) {
					Terms terms = aggrResponse.get(attrib.getLinkName());
					List<? extends Bucket> buckets = terms.getBuckets();
					for(Bucket bucket:buckets)
					{
						String segmentValue = (String)bucket.getKey();
						Long uniqueCount = 0l;
						Aggregations buckaggrResponse = bucket.getAggregations();
						InternalCardinality cardinality = buckaggrResponse.get(uniqueVisitorVariable);
						uniqueCount = cardinality.getValue();
						InternalCardinality uuidCardinality = buckaggrResponse.get("distinct_uuid_visitors");
						uniqueCount = uniqueCount + uuidCardinality.getValue();
						ESQuickFilterStatistics stat = new ESQuickFilterStatistics();
						stat.setSegmentValue(segmentValue);
						stat.setVisitorCount(uniqueCount);
						stat.setSuccess(true);
						wrapper.getVisitorData().add(stat);
					}
					wrapper.sortAndAddFillers();
				}
				visitorReportDetails.add(wrapper);
				
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			visitorReportDetails = new ArrayList<ESQuickFilterWrapper>();
		}
		return visitorReportDetails;
	}

	public static List<ESQuickFilterStatistics> getQuickFilterSegmentVisitorsdetails(HashMap<String,String> hs)
	{
		List<ESQuickFilterStatistics> visitorReportDetails = null;
		try
		{
			String goalLinkName = hs.get(ZABConstants.LINKNAME);
			Goal goalObj = Goal.getGoalByLinkname(goalLinkName);
			if(goalObj != null && goalObj.getGoalId() != null)
			{
				Long goalid = goalObj.getGoalId();
				String startTime = hs.get(ReportConstants.START_DATE);
				String  endTime = hs.get(ReportConstants.END_DATE);
				String  segmentName = hs.get(ReportConstants.SEGMENT_TYPE);
				Long startTimeInMillis = null;
				if(startTime!=null&&!startTime.isEmpty()){
					 startTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(startTime, "yyyy-MM-dd");		// NO I18N
				}
				
				Long endTimeInMillis = null;
				if(endTime!=null&&!endTime.isEmpty()){
					endTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(endTime, "yyyy-MM-dd");		// NO I18N
					//Get the long value end date's last milli second
					endTimeInMillis =  ZABUtil.getNthDayDateInLong(endTimeInMillis, 1) - 1;
				}
				
				//For nested quick filter like city by country 
				HashMap<String, String> qfNestedParentCond = new HashMap<String, String>();
				if(segmentName.equals(ElasticSearchConstants.CITY))
				{
				
					String qfParentName = hs.get(ReportConstants.QF_PARENT_NAME);
					String qfParentValue = hs.get(ReportConstants.QF_PARENT_VALUE);
					if(qfParentValue != null)
					{
						qfParentValue = qfParentValue.toUpperCase();
						
					}
					qfNestedParentCond.put(qfParentName, qfParentValue);
					
					//visitorReportDetails = dummycitydetails();
					//return visitorReportDetails;
				}
				String portalName = ZABUtil.getPortalName();
				if(portalName == null){
					return null;
				}
				String indexName = ElasticSearchUtil.getIndexByPortal(portalName);
				visitorReportDetails = getQuickFilterSegmentVisitorCount(goalid,
							indexName, portalName, segmentName,
							startTimeInMillis, endTimeInMillis,
							qfNestedParentCond, hs);
				visitorReportDetails = ESQuickFilterStatistics.sortValues(visitorReportDetails, segmentName);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage());
			visitorReportDetails = new ArrayList<ESQuickFilterStatistics>();
		}
		return visitorReportDetails;
	}
	
	public static List<ESQuickFilterWrapper> getQuickFilterMultipleSegmentVisitorsdetails(HashMap<String,String> hs)
	{
		List<ESQuickFilterWrapper> visitorReportDetails = null;
		try
		{
			String goalLinkName = hs.get(ZABConstants.LINKNAME);
			Goal goalObj = Goal.getGoalByLinkname(goalLinkName);
			if(goalObj != null && goalObj.getGoalId() != null)
			{
				Long goalid = goalObj.getGoalId();
				
				List<QuickFilterAttributes> quickFilterAttrs = ESQuickFilterConstants.QuickFilterAttributes.getQuickAttributes(ExperimentType.ABTEST.getTypeNumber());
				
				String startTime = hs.get(ReportConstants.START_DATE);
				String  endTime = hs.get(ReportConstants.END_DATE);
				Long startTimeInMillis = null;
				if(startTime!=null&&!startTime.isEmpty()){
					 startTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(startTime, "yyyy-MM-dd");		// NO I18N
				}
				
				Long endTimeInMillis = null;
				if(endTime!=null&&!endTime.isEmpty()){
					endTimeInMillis = ZABUtil.getTimeInLongFromDateFormStr(endTime, "yyyy-MM-dd");		// NO I18N
					//Get the long value end date's last milli second
					endTimeInMillis =  ZABUtil.getNthDayDateInLong(endTimeInMillis, 1) - 1;
				}
				
				String portalName = ZABUtil.getPortalName();
				if(portalName == null){
					return null;
				}
				String indexName = ElasticSearchUtil.getIndexByPortal(portalName);
				visitorReportDetails =  getQuickFilterMultiSegmentVisitorCount( goalid, indexName, portalName, startTimeInMillis, endTimeInMillis, hs, quickFilterAttrs);
				//visitorReportDetails = readdummyFilterVisitorResponseData();
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage());
			visitorReportDetails = new ArrayList<ESQuickFilterWrapper>();
		}
		return visitorReportDetails;
	}

	public static List<ESQuickFilterWrapper> readdummyFilterVisitorResponseData()
	{
		List<ESQuickFilterWrapper> visitorReportDetails = new ArrayList<ESQuickFilterWrapper>();
		try
		{
		
			ESQuickFilterWrapper wrapper = new ESQuickFilterWrapper();
			wrapper.setAttribute(QuickFilterAttributes.COUNTRY);
			ESQuickFilterStatistics countystat = new ESQuickFilterStatistics();
			countystat.setSegmentValue("India");// NO I18N
			countystat.setVisitorCount(34l);
			countystat.setSuccess(true);
			wrapper.getVisitorData().add(countystat);
			wrapper.sortAndAddFillers();
			visitorReportDetails.add(wrapper);
			
			wrapper = new ESQuickFilterWrapper();
			wrapper.setAttribute(QuickFilterAttributes.USERTYPE);
			ESQuickFilterStatistics usertypestat = new ESQuickFilterStatistics();
			usertypestat.setSegmentValue("NEW");// NO I18N
			usertypestat.setVisitorCount(4l);
			usertypestat.setSuccess(true);
			wrapper.getVisitorData().add(usertypestat);
			wrapper.sortAndAddFillers();
			visitorReportDetails.add(wrapper);
			
			wrapper = new ESQuickFilterWrapper();
			wrapper.setAttribute(QuickFilterAttributes.DEVICE);
			ESQuickFilterStatistics phonestat = new ESQuickFilterStatistics();
			phonestat.setSegmentValue("PHONE");// NO I18N
			phonestat.setVisitorCount(4l);
			phonestat.setSuccess(true);
			wrapper.getVisitorData().add(phonestat);
			wrapper.sortAndAddFillers();
			visitorReportDetails.add(wrapper);
			
			wrapper = new ESQuickFilterWrapper();
			wrapper.setAttribute(QuickFilterAttributes.OS);
			ESQuickFilterStatistics ossatat = new ESQuickFilterStatistics();
			ossatat.setSegmentValue("Mac");// NO I18N
			ossatat.setVisitorCount(49l);
			ossatat.setSuccess(true);
			wrapper.getVisitorData().add(ossatat);
			wrapper.sortAndAddFillers();
			visitorReportDetails.add(wrapper);
			
			wrapper = new ESQuickFilterWrapper();
			wrapper.setAttribute(QuickFilterAttributes.DAYOFWEEK);
			ESQuickFilterStatistics dayofweek = new ESQuickFilterStatistics();
			dayofweek.setSegmentValue("Monday");// NO I18N
			dayofweek.setVisitorCount(499l);
			dayofweek.setSuccess(true);
			wrapper.getVisitorData().add(dayofweek);
			wrapper.sortAndAddFillers();
			visitorReportDetails.add(wrapper);
			
			wrapper = new ESQuickFilterWrapper();
			wrapper.setAttribute(QuickFilterAttributes.HOUROFDAY);
			dayofweek = new ESQuickFilterStatistics();
			dayofweek.setSegmentValue("6");
			dayofweek.setVisitorCount(497l);
			dayofweek.setSuccess(true);
			wrapper.getVisitorData().add(dayofweek);
			wrapper.sortAndAddFillers();
			visitorReportDetails.add(wrapper);
			
			wrapper = new ESQuickFilterWrapper();
			wrapper.setAttribute(QuickFilterAttributes.TRAFFICSOURCE);
		
			visitorReportDetails.add(wrapper);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			visitorReportDetails = new ArrayList<ESQuickFilterWrapper>();
		}
		return visitorReportDetails;
	}
	
	public static List<ESQuickFilterStatistics> dummycitydetails()
	{
		List<ESQuickFilterStatistics> visitorReportDetails = new ArrayList<ESQuickFilterStatistics>();
		try
		{
			
			ESQuickFilterStatistics stat = new ESQuickFilterStatistics();
			stat.setSegmentValue("Chennai");	// NO I18N
			stat.setVisitorCount(23l);
			stat.setSuccess(true);
			visitorReportDetails.add(stat);
			
			stat = new ESQuickFilterStatistics();
			stat.setSegmentValue("Mumbai");// NO I18N
			stat.setVisitorCount(293l);
			stat.setSuccess(true);
			visitorReportDetails.add(stat);
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
			
		}
		return visitorReportDetails;
	}
	


}
