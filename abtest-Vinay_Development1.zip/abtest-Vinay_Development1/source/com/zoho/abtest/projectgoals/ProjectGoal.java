//$Id$
package com.zoho.abtest.projectgoals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.avg.AvgAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.avg.InternalAvg;
import org.elasticsearch.search.aggregations.metrics.cardinality.InternalCardinality;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.SortColumn;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.GOAL;
import com.zoho.abtest.PROJECT_GOAL;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.elastic.ElasticSearchStatistics;
import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.goal.Goal;
import com.zoho.abtest.goal.GoalConstants;
import com.zoho.abtest.goal.GoalReports;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.report.ReportArchieveDimensionConstants;
import com.zoho.abtest.utility.ZABUtil;

public class ProjectGoal extends Goal {

	private static final Logger LOGGER = Logger.getLogger(ProjectGoal.class.getName());
	
	
	public static HashMap<Long , String> getGoalVisitorsReport(Long projId , Long goalId ,Long startTime,Long endTime, String multisegmentCriteria){
		HashMap<Long , String> visitorInfo = new HashMap<Long,String>();
		try {
			
			String portalName = ZABUtil.getPortalName();
			String indexName = ElasticSearchUtil.getIndexByPortal(portalName);

			BoolQueryBuilder query = GoalReports.queryBuilder(portalName,projId,goalId,startTime,endTime,multisegmentCriteria);
			AvgAggregationBuilder avgAggr = AggregationBuilders.avg("avg_time").field(ElasticSearchConstants.TIME_SPENT); // No I18N
			
			TermsAggregationBuilder finalAggr = AggregationBuilders.terms("goalid").  // No I18N
					field(ElasticSearchConstants.GOALID).
					size(ElasticSearchConstants.GOAL_MAX_COUNT).
						subAggregation(ElasticSearchStatistics.getVisitorCardinalityAggr()).subAggregation(avgAggr).subAggregation(ElasticSearchStatistics.getUUIDVisitorCardinalityAggr()) ;

			SearchResponse response = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.VISITOR_RAW_TYPE, 0, query, finalAggr);
			visitorInfo.putAll(readGoalVisitorsResponse(response));

		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		return visitorInfo;	

	}
	private static HashMap<Long , String> readGoalVisitorsResponse(SearchResponse response) {
		HashMap<Long , String> visitorInfo = new HashMap<Long,String>();
		Aggregations aggrResponse = response.getAggregations();
		Terms terms  = aggrResponse.get("goalid");
		for (Bucket entry : terms.getBuckets()) {
			Long goalId  = Long.parseLong(entry.getKeyAsString());          
			Long totalVisitors = entry.getDocCount();        
			InternalCardinality cardinality = entry.getAggregations().get("distinct_visitors");	// NO I18N
			InternalCardinality uuidCardinality = entry.getAggregations().get("distinct_uuid_visitors");	// NO I18N
			InternalAvg avg = entry.getAggregations().get("avg_time");	// NO I18N
			Double avgTime  = avg.getValue();
			Long uniquevisitors = cardinality.getValue() + uuidCardinality.getValue();

			visitorInfo.put(goalId, totalVisitors+":"+uniquevisitors+":"+avgTime.longValue());

		}
		return visitorInfo;

	}

	public static HashMap<Long , HashMap<String,Long>> getGoalAchievedReport(Long projId ,Long goalId ,Long startTime,Long endtime,String multisegmentCriteria){
		HashMap<Long , HashMap<String,Long>> goalAchievedInfo = new HashMap<Long , HashMap<String,Long>>();
		try {
			String portalName = ZABUtil.getPortalName();
			String indexName = ElasticSearchUtil.getIndexByPortal(portalName);
			
			BoolQueryBuilder query = GoalReports.queryBuilder(portalName, projId, goalId ,startTime, endtime, multisegmentCriteria);
			AvgAggregationBuilder avgAggr = AggregationBuilders.avg("avg_time").field(ElasticSearchConstants.TIME_SPENT); // No I18N
			
			TermsAggregationBuilder finalAggr = AggregationBuilders.terms("goalid").  // No I18N
							field(ElasticSearchConstants.GOALID).
							size(ElasticSearchConstants.GOAL_MAX_COUNT).
								subAggregation(ElasticSearchStatistics.getVisitorCardinalityAggr()).subAggregation(avgAggr).subAggregation(ElasticSearchStatistics.getUUIDVisitorCardinalityAggr()) ;

		
			SearchResponse response = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.GOAL_RAW_TYPE, 0, query, finalAggr);
			goalAchievedInfo =  readGoalAchievedResponse(response);
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		return goalAchievedInfo;	

	}
	private static HashMap<Long , HashMap<String,Long>> readGoalAchievedResponse(SearchResponse response) {
		HashMap<Long , HashMap<String,Long>> goalAchievedInfo = new HashMap<Long , HashMap<String,Long>>();
		
		Aggregations aggrResponse = response.getAggregations();
		Terms terms = aggrResponse.get("goalid");
		List<? extends Bucket> buckets = terms.getBuckets();
		for(Bucket bucket:buckets)
		{
			Long goalid = (Long)bucket.getKey();
			Aggregations buckaggrResponse = bucket.getAggregations();
			InternalCardinality visitors = buckaggrResponse.get("distinct_visitors");
			InternalCardinality uuidVisitors = buckaggrResponse.get("distinct_uuid_visitors");
			Long visitorsCount = visitors.getValue();
			Long uuidVisitorsCount = uuidVisitors.getValue();
			Long totalCount = visitorsCount + uuidVisitorsCount;
			
			InternalAvg avg = buckaggrResponse.get("avg_time");
			Double avgTime  = avg.getValue();
			HashMap<String , Long> hs = new HashMap<String, Long>();
			hs.put(ReportArchieveDimensionConstants.UNIQUE_GOAL_ACHIEVED_COUNT, totalCount);
			hs.put(ReportArchieveDimensionConstants.TIME_SPENT, avgTime.longValue());
			
			goalAchievedInfo.put(goalid, hs);
			
		}
		return goalAchievedInfo;

	}
	
	public static void getJustTheProjectGoalRows(String projectLinkname, Consumer<Row> consumer) {
		try {
			Long projectId = Project.getProjectId(projectLinkname);
			Criteria c1 = new Criteria(new Column(GOAL.TABLE, GOAL.PROJECT_ID), projectId, QueryConstants.EQUAL);
			Criteria c2 = new Criteria(new Column(GOAL.TABLE,GOAL.IS_PROJECT_LEVEL),Boolean.TRUE,QueryConstants.EQUAL);
			DataObject dobj = getRow(GOAL.TABLE, c1.and(c2));
			Iterator<Row> it = dobj.getRows(GOAL.TABLE);
			it.forEachRemaining(row -> consumer.accept(row));
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
	}
	
	public static ArrayList<Goal> getProjectGoalsForProjectWithoutStats(Long projectId, Criteria additionalCri) {
		ArrayList<Goal> goals = new ArrayList<Goal>(); 
		try {
			Criteria c = null;
			Criteria c1 = new Criteria(new Column(GOAL.TABLE, GOAL.PROJECT_ID), projectId, QueryConstants.EQUAL);
			Criteria c2 = new Criteria(new Column(GOAL.TABLE,GOAL.IS_PROJECT_LEVEL),Boolean.TRUE,QueryConstants.EQUAL);
			c = c1.and(c2);
			
			if(additionalCri!=null) {
				c = c1.and(c2).and(additionalCri);
			}
			
			DataObject dobj = getPersonality(GoalConstants.EXPEIRMENT_GOAL_PERSONALITY_NAME, c);
			goals.addAll(getGoalFromDObj(dobj));
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		return goals;
	}

	public static ArrayList<Goal> getProjectGoalsForProject(Long projectId){

		ArrayList<Goal> reports = new ArrayList<Goal>();
		HashMap<Long , HashMap<String,Long>> goalsAcievedInfo = new HashMap<Long , HashMap<String,Long>>();
		HashMap<Long , String> visitorsInfo = new  HashMap<Long , String>();
		try {
			goalsAcievedInfo = getGoalAchievedReport(projectId, null , null, null, null);
			visitorsInfo = getGoalVisitorsReport(projectId, null , null, null, null);
			
			Criteria c = new Criteria(new Column(GOAL.TABLE,GOAL.PROJECT_ID),projectId,QueryConstants.EQUAL);
			Criteria c2 = new Criteria(new Column(GOAL.TABLE,GOAL.IS_PROJECT_LEVEL),Boolean.TRUE,QueryConstants.EQUAL);
		
			
			SortColumn sort = new SortColumn(new Column(GOAL.TABLE, GOAL.CREATED_TIME), Boolean.FALSE);
			

			DataObject dobj = ZABModel.getRow(GOAL.TABLE, c.and(c2),sort,null);
			Iterator<?> itr = dobj.getRows(GOAL.TABLE);
			while(itr.hasNext()){
				Row row = (Row)itr.next();
				Long goalid = (Long)row.get(GOAL.GOAL_ID);
			
				Goal goalreport= Goal.getGoalByGoalId(goalid);
			
				Long achievedCount = 0l;
				Long timetaken = 0l;
				if(goalsAcievedInfo.containsKey(goalid)){
					achievedCount = goalsAcievedInfo.get(goalid).get(ReportArchieveDimensionConstants.UNIQUE_GOAL_ACHIEVED_COUNT);
					timetaken = goalsAcievedInfo.get(goalid).get(ReportArchieveDimensionConstants.TIME_SPENT);
				}
				goalreport.setUniqueGoalAchievedCount(achievedCount);
				goalreport.setAvgTimeToAchieveGoal(timetaken);
				Long visitorsCount = 0l;
				Long timeSpentPage = 0l;
				if(visitorsInfo.containsKey(goalid)){
					String visitorinfo = visitorsInfo.get(goalid);
					String valArr[] = visitorinfo.split(":");
					visitorsCount = Long.parseLong(valArr[1]); 
					timeSpentPage = Long.parseLong(valArr[2]); 
				}
				goalreport.setUniqueVisitors(visitorsCount);
				goalreport.setAvgTimeSpentOnPage(timeSpentPage);
				if(achievedCount >  visitorsCount){
					goalreport.setUniqueGoalAchievedCount(visitorsCount);
				}
				goalreport.setSuccess(Boolean.TRUE);
				reports.add(goalreport);
				
			}
			
		} catch (Exception e) {

			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		return reports;
	}
	
	public static ArrayList<Goal> getProjectGoalsForGoal(String goalLinkName,Long startTime,Long endTime, String multisegmentCriteria){

		ArrayList<Goal> reports = new ArrayList<Goal>();
		HashMap<Long , HashMap<String,Long>> goalsAcievedInfo = new HashMap<Long , HashMap<String,Long>>();
		HashMap<Long , String> visitorsInfo = new  HashMap<Long , String>();
	
		try {
		
			Criteria c = new Criteria(new Column(GOAL.TABLE,GOAL.GOAL_LINK_NAME),goalLinkName,QueryConstants.EQUAL);
			Criteria c2 = new Criteria(new Column(GOAL.TABLE,GOAL.IS_PROJECT_LEVEL),Boolean.TRUE,QueryConstants.EQUAL);
			Join projectgoaljoin = new Join(GOAL.TABLE,PROJECT_GOAL.TABLE,new String[]{GOAL.GOAL_ID}, new String[]{PROJECT_GOAL.GOAL_ID},Join.LEFT_JOIN);
			DataObject dobj = ZABModel.getRow(GOAL.TABLE, c.and(c2),projectgoaljoin);
			if(dobj.containsTable(GOAL.TABLE))
			{
				Row row = dobj.getFirstRow(GOAL.TABLE);
				Long goalid = (Long)row.get(GOAL.GOAL_ID);
				Long projid = (Long)row.get(GOAL.PROJECT_ID);
				goalsAcievedInfo = getGoalAchievedReport(projid, goalid , startTime, endTime, multisegmentCriteria);
				visitorsInfo = getGoalVisitorsReport(projid, goalid , startTime, endTime, multisegmentCriteria);
				
				
				Goal goalreport=  Goal.getGoalByGoalId(goalid);
				Criteria projgoalCri = new Criteria(new Column(PROJECT_GOAL.TABLE,PROJECT_GOAL.GOAL_ID),goalid,QueryConstants.EQUAL);
				Row pgoalrow  = dobj.getRow(PROJECT_GOAL.TABLE, projgoalCri);
				if(pgoalrow!=null){
					String goalUrl  = (String)pgoalrow.get(PROJECT_GOAL.GOAL_URL);
					if(goalUrl!=null && !goalUrl.equals("*")){	// '*' is set as goal url for custom goals with no targetting
						goalreport.setGoalUrl(goalUrl);
					}
					goalreport.setIncludeUrl((String)pgoalrow.get(PROJECT_GOAL.INCLUDE_URLS));
					goalreport.setExcludeUrl((String)pgoalrow.get(PROJECT_GOAL.EXCLUDE_URLS));
					
				}

				Long achievedCount = 0l;
				Long avgtime = 0l;
				if(goalsAcievedInfo.containsKey(goalid)){
					achievedCount = goalsAcievedInfo.get(goalid).get(ReportArchieveDimensionConstants.UNIQUE_GOAL_ACHIEVED_COUNT);
					avgtime =  goalsAcievedInfo.get(goalid).get(ReportArchieveDimensionConstants.TIME_SPENT);
				
				}
				goalreport.setUniqueGoalAchievedCount(achievedCount);
				goalreport.setAvgTimeToAchieveGoal(avgtime);
				
				Long visitorsCount = 0l;
				Long timeSpentPage = 0l;
				if(visitorsInfo.containsKey(goalid)){
					String visitorinfo = visitorsInfo.get(goalid);
					String valArr[] = visitorinfo.split(":");
					visitorsCount = Long.parseLong(valArr[1]); 
					timeSpentPage = Long.parseLong(valArr[2]); 
				}
				if(achievedCount >  visitorsCount){
					goalreport.setUniqueGoalAchievedCount(visitorsCount);
				}
				goalreport.setUniqueVisitors(visitorsCount);
				goalreport.setAvgTimeSpentOnPage(timeSpentPage);
				goalreport.setSuccess(Boolean.TRUE);
				reports.add(goalreport);
			}
			
			
		} catch (Exception e) {

			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		return reports;
	}
	
}
