//$Id$
package com.zoho.abtest.projectgoals;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.json.JSONException;

import com.opensymphony.xwork2.ActionSupport;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.elastic.ESQuickFilterAction;
import com.zoho.abtest.elastic.ESQuickFilterStatistics;
import com.zoho.abtest.elastic.ESQuickFilterWrapper;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.report.CumulativeReportConstants;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.utility.ZABUtil;

public class ESGoalQuickFilterAction extends ActionSupport implements ServletResponseAware, ServletRequestAware
{
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(ESQuickFilterAction.class.getName());
	
	private HttpServletRequest request;
	private HttpServletResponse response;
	private String goalLinkName ;
	
	public void setServletRequest(HttpServletRequest arg0) {
		request = arg0;
	}

	public void setServletResponse(HttpServletResponse arg0) {
		response = arg0;
	}
	
	
	public String getGoalLinkName() {
		return goalLinkName;
	}

	public void setGoalLinkName(String goalLinkName) {
		this.goalLinkName = goalLinkName;
		request.setAttribute(ZABConstants.LINKNAME, goalLinkName);
	}
	
	public String getQuickFilterSegmentVisitorsdetails() throws IOException, JSONException
	{
		List<ESQuickFilterStatistics> visitorReports = new ArrayList<ESQuickFilterStatistics>();
		HashMap<String,String> hs;
		try {			
		
			switch(ZABAction.getHTTPMethod(request)) {
			case POST:	

				hs = ZABAction.getRequestParser(request).parseReport(request);

				if(hs.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					ESQuickFilterStatistics report = new ESQuickFilterStatistics();
					report.setSuccess(Boolean.FALSE);
					report.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
					visitorReports.add(report);
					LOGGER.log(Level.SEVERE,hs.get(ZABConstants.RESPONSE_STRING));
				}else{
					visitorReports.addAll(GoalQuickFilterStatistics.getQuickFilterSegmentVisitorsdetails(hs));
				}
				break;
			}
		} catch(Exception ex){
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), CumulativeReportConstants.API_MODULE));
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
			return null; 	
		}		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getQuickFilterSegmentVisitorResponse(request, visitorReports));		
	    
		return null;
	}

	public void getQuickFilterAttributes() throws IOException, JSONException
	{
		List<ESQuickFilterWrapper> qfAttributes = new ArrayList<ESQuickFilterWrapper>();
		HashMap<String,String> hs;
		try
		{
			switch(ZABAction.getHTTPMethod(request)) {
			case POST:
				hs = ZABAction.getRequestParser(request).parseESQuickFilterAttrReport(request);
				if(hs.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					ESQuickFilterWrapper report = new ESQuickFilterWrapper();
					report.setSuccess(Boolean.FALSE);
					report.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
					qfAttributes.add(report);
					LOGGER.log(Level.SEVERE,hs.get(ZABConstants.RESPONSE_STRING));
				}else{
					qfAttributes.addAll(GoalQuickFilterStatistics.getQuickFilterMultipleSegmentVisitorsdetails(hs));
				}
				
				break;
			}
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getQuickFilterAttrResponse(request, qfAttributes));
		}
		catch(Exception ex){
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ElasticSearchConstants.QUICKFILTER_ATTR_API_MODULE));
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
		}
	}

	
}
