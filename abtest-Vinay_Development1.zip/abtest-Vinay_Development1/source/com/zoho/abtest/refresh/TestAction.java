//$Id$
package com.zoho.abtest.refresh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.json.JSONException;
import org.json.JSONObject;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.UpdateQuery;
import com.adventnet.ds.query.UpdateQueryImpl;
import com.adventnet.persistence.DataAccess;
import com.opensymphony.xwork2.ActionSupport;
import com.zoho.abtest.OAUTH;
import com.zoho.abtest.OAUTH_SYS;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.report.CustomMapping;
import com.zoho.abtest.webhook.Webhook;


public class TestAction  extends ActionSupport implements ServletResponseAware, ServletRequestAware {
private static final Logger LOGGER = Logger.getLogger(TestAction.class.getName());
	
	private static final long serialVersionUID = 1L;
	private HttpServletRequest request;
	private String webhookname;




		public String getWebhookname() {
		return webhookname;
	}

	public void setWebhookname(String webhookname) {
		this.webhookname = webhookname;
	}

		private HttpServletResponse response;
		@Override
		public void setServletRequest(HttpServletRequest arg0) {
			request = arg0;
		}

		@Override
		public void setServletResponse(HttpServletResponse arg0) {
			response = arg0;
		}
		
	
	/**
	 * @param accessurl
	 * @param callbackurl
	 * @param code
	 * @return getting refresh token using code
	 */
	private static StringBuffer getRefreshToken(String authurl,String callbackurl,String code){
		StringBuffer response = new StringBuffer();
		String s=null;
		try {
			authurl = authurl+"&code="+code+"&redirect_uri="+callbackurl;//NO I18N
			URL obj = new URL(authurl);
			s=obj.getProtocol();
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("POST"); //NO I18N
	        con.setDoOutput(true);
			con.setConnectTimeout(3000);
			int responseCode = con.getResponseCode();
			
			BufferedReader in = new BufferedReader(
					new InputStreamReader(con.getInputStream()));
			String inputLine;
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
		} catch (Exception e) {
				e.printStackTrace();
		}
	return response;
	}
	
	public String execute() throws IOException, JSONException {
		LOGGER.log(Level.INFO, "test Action Start");
		String code=null;
		String str=null;
		String refreshtoken=null;
		String tokens=null;
		try {			
			switch(ZABAction.getHTTPMethod(request)) {
			case GET:	
			  String callbackurl=CustomMapping.getWebhook().get(webhookname).getCallBackUrl();
			  String authurl=CustomMapping.getWebhook().get(webhookname).getAuthorizationUrl();
			   code =request.getParameter("code");
			  tokens=getRefreshToken(authurl,callbackurl,code).toString();
			  JSONObject json=new JSONObject(tokens);
			  refreshtoken=json.get("refresh_token").toString();
     		 UpdateQuery u = new UpdateQueryImpl(OAUTH_SYS.TABLE);
			 Criteria c = new Criteria(new Column(OAUTH_SYS.TABLE, OAUTH_SYS.WEBHOOK_NAME),webhookname, QueryConstants.EQUAL);
 			 u.setCriteria(c);
			 u.setUpdateColumn(OAUTH_SYS.REFRESH_TOKEN,refreshtoken);
			 //update row
			 DataAccess.update(u);
			  str="success";//NO I18N
		        break;
}	
}
		catch (Exception ex) {			
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
                             }		
		return str;
	}



}







