//$Id$
package com.zoho.abtest.cache;

import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.zoho.abtest.BROWSER_DETAIL;
import com.zoho.abtest.COUNTRY_DETAIL;
import com.zoho.abtest.DEVICE_DETAIL;
import com.zoho.abtest.LANGUAGE_DETAIL;
import com.zoho.abtest.OS_DETAIL;
import com.zoho.abtest.TRAFFICSOURCE_DETAIL;

public class InMemoryCacheUtil
{
	private static final Logger LOGGER = Logger.getLogger(InMemoryCacheUtil.class.getName());
	
	private static final HashMap<String, Integer> BROWSERCACHE;
	private static final HashMap<String, Integer> DEVICECACHE;
	private static final HashMap<String, Integer> COUNTRYCACHE;
	private static final HashMap<String, Integer> LANGUAGECACHE;
	private static final HashMap<String, Integer> OSCACHE;
	private static final HashMap<String, Integer> TRAFFICSOURCECACHE;
	
	static
	{
		BROWSERCACHE = new HashMap<String, Integer>();
		DEVICECACHE = new HashMap<String, Integer>();
		COUNTRYCACHE = new HashMap<String, Integer>();
		LANGUAGECACHE = new HashMap<String, Integer>();
		OSCACHE = new HashMap<String, Integer>();
		TRAFFICSOURCECACHE = new HashMap<String, Integer>();
	}
	
	public static HashMap<String, Integer> getHashByTableName(String tableName)
	{
		HashMap<String, Integer> cache = null;
		switch(tableName)
		{
		case BROWSER_DETAIL.TABLE:
			cache = BROWSERCACHE;
			break;
		case DEVICE_DETAIL.TABLE:
			cache = DEVICECACHE;
			break;
		case COUNTRY_DETAIL.TABLE:
			cache = COUNTRYCACHE;
			break;
		case LANGUAGE_DETAIL.TABLE:
			cache = LANGUAGECACHE;
			break;
		case OS_DETAIL.TABLE:
			cache = OSCACHE;
			break;
		case TRAFFICSOURCE_DETAIL.TABLE:
			cache = TRAFFICSOURCECACHE;
			break;
		}
		return cache;
	}
	
	public static boolean isDataCached(String tableName)
	{
		boolean flag = false;
		switch(tableName)
		{
		case BROWSER_DETAIL.TABLE:
		case DEVICE_DETAIL.TABLE:
		case COUNTRY_DETAIL.TABLE:
		case LANGUAGE_DETAIL.TABLE:
		case OS_DETAIL.TABLE:
		case TRAFFICSOURCE_DETAIL.TABLE:
			flag = true;
			break;
		}
		return flag;
	}
	
	public static void pushIntoHash(String tableName, String key, Integer value) throws Exception
	{
		try
		{
			boolean isDataCached = InMemoryCacheUtil.isDataCached(tableName);
			
			if(isDataCached)
			{
				HashMap<String, Integer> cache = getHashByTableName(tableName);
				cache.put(key, value);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			throw ex;
		}
	}
	
	public static void pushIntoHash(String tableName, HashMap<String, Integer> hs) throws Exception
	{
		try
		{
			boolean isDataCached = InMemoryCacheUtil.isDataCached(tableName);
			
			if(isDataCached)
			{
				HashMap<String, Integer> cache = getHashByTableName(tableName);
				cache.putAll(hs);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			throw ex;
		}
	}
	
	public static Integer getFromHash(String tableName, String key)
	{
		Integer code = null;
		try
		{
			boolean isDataCached = InMemoryCacheUtil.isDataCached(tableName);
			if(isDataCached)
			{
				HashMap<String, Integer> cache = getHashByTableName(tableName);
				if(cache.containsKey(key))
				{
					code = cache.get(key);
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			code = null;
		}
		return code;
	}

}
