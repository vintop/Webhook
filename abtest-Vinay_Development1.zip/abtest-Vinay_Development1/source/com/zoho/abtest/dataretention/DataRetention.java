//$Id$
package com.zoho.abtest.dataretention;

import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.iam.ServiceOrg;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.LICENSE_DETAIL;
import com.zoho.abtest.PORTAL_LICENSE_MAPPING;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.license.LicenseConstants;
import com.zoho.abtest.license.PortalLicenseMapping;
import com.zoho.abtest.license.LicenseConstants.License;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.utility.ApplicationProperty;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUtil;

public class DataRetention 
{
	private static final Logger LOGGER = Logger.getLogger(DataRetention.class.getName());
	
	public static final int DATA_RETENTION_PERIOD = ApplicationProperty.getInteger("days.dataretention.period"); //No I18N
	public static final int DATA_RETENTION_TRIAL_PERIOD = ApplicationProperty.getInteger("days.dataretention.trial.period"); //No I18N
	/*
	public static void deleteExpiredData()
	{
		try
		{
			Long currentTime = ZABUtil.getCurrentTimeInMilliSeconds();
			Long expiryTime = ZABUtil.getNthServerDayInLong(currentTime, -DATA_RETENTION_PERIOD); //TODO
			QueryBuilder timeQuery = QueryBuilders.rangeQuery(ElasticSearchConstants.TIME).lte(expiryTime);
			QueryBuilder firstVisitTimeQuery = QueryBuilders.rangeQuery(ElasticSearchConstants.FIRST_VISIT_TIME).lte(expiryTime);
			BoolQueryBuilder query = QueryBuilders.boolQuery();
			query.should().add(timeQuery);
			query.should().add(firstVisitTimeQuery);
			ElasticSearchUtil.deleteData(query);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception while deleteExpiredData", ex);
		}
	}
	*/
	public static void cleanupTrialExpiredData()
	{
		try
		{
			ZABUtil.setDBSpace("sharedspace");	//No I18N
			Long currentTime = ZABUtil.getCurrentTimeInMilliSeconds();
			Long expiryTime = ZABUtil.getNthServerDayInLong(currentTime, -DATA_RETENTION_TRIAL_PERIOD); //TODO
			Criteria c1 = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.IS_APP_ACTIVE), Boolean.FALSE, QueryConstants.EQUAL);
			Criteria c2 = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.PAUSED_TIME), expiryTime, QueryConstants.LESS_EQUAL);
			Criteria c3 = new Criteria(new Column(LICENSE_DETAIL.TABLE, LICENSE_DETAIL.LICENSE_TYPE), License.TRIAL.getLicenseType(), QueryConstants.EQUAL);
			Criteria c4 = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.TRIALEXPIREDDATA_DELETED), Boolean.FALSE, QueryConstants.EQUAL);
			Join join1 = new Join(PORTAL_LICENSE_MAPPING.TABLE, LICENSE_DETAIL.TABLE, new String[]{PORTAL_LICENSE_MAPPING.LICENSE_DETAIL_ID}, new String[]{LICENSE_DETAIL.LICENSE_DETAIL_ID}, Join.INNER_JOIN);
			DataObject dataObj = ZABModel.getRow(PORTAL_LICENSE_MAPPING.TABLE, c1.and(c2).and(c3).and(c4), new Join[]{join1});
			Iterator<?> iterator = dataObj.getRows(PORTAL_LICENSE_MAPPING.TABLE);
			while(iterator.hasNext())
			{
				Row row = (Row)iterator.next();
				PortalLicenseMapping portalLicenseMappingObj =  PortalLicenseMapping.getPortalLicenseMappingFromRow(row);
				Long zsoid = portalLicenseMappingObj.getZsoid();
				try
				{
					LOGGER.log(Level.INFO, "Started cleanupTrialExpiredData for zsoid - "+zsoid);
					
					ServiceOrg sOrg = ZABServiceOrgUtil.getServiceOrg(zsoid);
					if(sOrg != null && sOrg.isEnabled())
					{
						//Delete data in elasticserach
						String domainName = sOrg.getDomains().get(0).getDomain();
						ElasticSearchUtil.deletePortalData(domainName);
						//Update flag
						Long portalLicenseMappingId = portalLicenseMappingObj.getPortalLicenseMappingId();
						HashMap<String, String> hs = new HashMap<String, String>();
						hs.put(LicenseConstants.TRIALEXPIREDDATA_DELETED, Boolean.TRUE.toString());
						PortalLicenseMapping.updatePortalLicense(portalLicenseMappingId, hs);
					}
					LOGGER.log(Level.INFO, "Completed cleanupTrialExpiredData for zsoid - "+zsoid);
				}
				catch(Exception ex)
				{
					LOGGER.log(Level.SEVERE, "Exception while cleanupTrialExpiredData for zsoid - {0}", new String[]{zsoid.toString()});
					LOGGER.log(Level.SEVERE, "Exception while cleanupTrialExpiredData", ex);
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception while deleteExpiredData", ex);
		}
	}
}
