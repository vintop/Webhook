//$Id$
package com.zoho.abtest.goal;

import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Operation;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.UpdateQuery;
import com.adventnet.ds.query.UpdateQueryImpl;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.GOAL_VISITS;
import com.zoho.abtest.REVENUE_VISITS;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.report.ReportArchieveDimensionConstants;
import com.zoho.abtest.variation.VariationConstants;
import com.zoho.abtest.variation.VariationVisits;

public class GoalVisits extends ZABModel {
	private static final Logger LOGGER = Logger.getLogger(VariationVisits.class.getName());
	
	

	public static void updateGoalVisits(HashMap<String, String> hs,boolean isNewVisitor,String revenue) throws Exception
	{
		try
		{
			Long variationId = Long.parseLong(hs.get(VariationConstants.VARIATION_ID));
			Long goalId = Long.parseLong(hs.get(GoalConstants.GOAL_ID));
			Criteria criteria1 = new Criteria(new Column(GOAL_VISITS.TABLE,GOAL_VISITS.VARIATION_ID), variationId, QueryConstants.EQUAL);
			Criteria criteria2 = new Criteria(new Column(GOAL_VISITS.TABLE,GOAL_VISITS.GOAL_ID), goalId, QueryConstants.EQUAL);
			
			
			DataObject dobj = ZABModel.getRow(GOAL_VISITS.TABLE, criteria1.and(criteria2));
			if(dobj.containsTable(GOAL_VISITS.TABLE)){
				Long newUniqueCount = Long.parseLong(hs.get(ReportArchieveDimensionConstants.UNIQUE_GOAL_ACHIEVED_COUNT));
				Long newTotalCount = Long.parseLong(hs.get(ReportArchieveDimensionConstants.TOTAL_GOAL_ACHIEVED_COUNT));
				UpdateQuery update = new UpdateQueryImpl(GOAL_VISITS.TABLE);
				if(isNewVisitor)
				{
					Column oper = Column.createOperation(Operation.operationType.ADD, Column.getColumn(GOAL_VISITS.TABLE, GOAL_VISITS.UNIQUE_GOAL_ACHIEVED_COUNT),newUniqueCount);
					update.setUpdateColumn(GOAL_VISITS.UNIQUE_GOAL_ACHIEVED_COUNT,oper);
				}
				Column oper1 = Column.createOperation(Operation.operationType.ADD, Column.getColumn(GOAL_VISITS.TABLE, GOAL_VISITS.TOTAL_GOAL_ACHIEVED_COUNT),newTotalCount);
				update.setUpdateColumn(GOAL_VISITS.TOTAL_GOAL_ACHIEVED_COUNT,oper1);
				update.setCriteria(criteria1.and(criteria2));
				ZABModel.updateResource(update);
			
			}else{
				dobj = ZABModel.createRow(GoalConstants.GOAL_VISITS_CONSTANTS, GOAL_VISITS.TABLE, hs);
			}
			if(revenue!=null && Long.parseLong(revenue)>0){
				Long mappingid =  (Long) dobj.getFirstValue(GOAL_VISITS.TABLE, GOAL_VISITS.GOAL_VISITS_ID);
				
				Criteria revCri = new Criteria(new Column(REVENUE_VISITS.TABLE,REVENUE_VISITS.REVENUE_VISITS_ID) ,mappingid,QueryConstants.EQUAL);
				DataObject revDobj = ZABModel.getRow(REVENUE_VISITS.TABLE,revCri);
				if(revDobj.containsTable(REVENUE_VISITS.TABLE)){
					UpdateQuery update = new UpdateQueryImpl(REVENUE_VISITS.TABLE);
				
					Column oper1 = Column.createOperation(Operation.operationType.ADD, Column.getColumn(REVENUE_VISITS.TABLE, REVENUE_VISITS.REVENUE),revenue);
					update.setUpdateColumn(REVENUE_VISITS.REVENUE,oper1);
					update.setCriteria(revCri);
					ZABModel.updateResource(update);
				
				}else{
					Row row = new Row(REVENUE_VISITS.TABLE);
					row.set(REVENUE_VISITS.REVENUE_VISITS_ID,mappingid);
					row.set(REVENUE_VISITS.REVENUE, revenue);
					ZABModel.createResource(row);
				}
				
			}
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			throw ex;
		}
	}
}
