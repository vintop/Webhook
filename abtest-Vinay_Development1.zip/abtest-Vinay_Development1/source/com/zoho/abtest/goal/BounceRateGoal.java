//$Id$
package com.zoho.abtest.goal;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import com.zoho.abtest.report.ReportArchieveDimensionConstants;
import com.zoho.abtest.report.ReportRawDataConstants;
import com.zoho.abtest.report.ReportStatistics;
import com.zoho.abtest.variation.VariationConstants;


public class BounceRateGoal extends Goal {/*
	
		private static final long serialVersionUID = 1L;
		
		private Long timeThreshold;

		public Long getTimeThreshold() {
			return timeThreshold;
		}

		public void setTimeThreshold(Long timeThreshold) {
			this.timeThreshold = timeThreshold;
		}

		public static ArrayList<HashMap<String, String>>  combineTotalVisitorsWithVisitormeta(ArrayList<HashMap<String, String>> visitorMeta , HashMap<Long, Long>  totalVisitorsHs){
			for(int i=0;i<visitorMeta.size();i++){
				HashMap<String, String> hs = visitorMeta.get(i);
				Long varId =  Long.parseLong(hs.get(VariationConstants.VARIATION_ID));
				if(totalVisitorsHs.containsKey(varId)){
					Long totalVisitorCount  = totalVisitorsHs.get(varId);			
					hs.put(ReportArchieveDimensionConstants.TOTAL_COUNT, totalVisitorCount.toString());
					totalVisitorsHs.remove(varId);
				}
			}
			if(totalVisitorsHs.size()>0){
				Set<Long> keySet = totalVisitorsHs.keySet();
				Iterator<?> itr  = keySet.iterator();
				while(itr.hasNext()){
					Long varId = (Long) itr.next();
					Long totalVisitorcount  = totalVisitorsHs.get(varId);
					HashMap<String,String> newhs = new HashMap<String,String>();
					newhs.put(VariationConstants.VARIATION_ID, varId.toString());
					newhs.put(ReportArchieveDimensionConstants.UNIQUE_COUNT, "0");
					newhs.put(ReportArchieveDimensionConstants.TOTAL_COUNT, totalVisitorcount.toString());
					visitorMeta.add(newhs);
				}
				
			}
			return visitorMeta;
		
		}
		public static ArrayList<HashMap<String, String>> combineBounceMetaWithVisitormeta(ArrayList<HashMap<String, String>> visitorMeta , HashMap<Long, Long>  timeSpentHs){
			for(int i=0;i<visitorMeta.size();i++){
				HashMap<String, String> hs = visitorMeta.get(i);
				Long varId =  Long.parseLong(hs.get(VariationConstants.VARIATION_ID));
				if(timeSpentHs.containsKey(varId)){
					Long timespent  = timeSpentHs.get(varId);			
					hs.put(ReportRawDataConstants.TIME_SPENT, timespent.toString());
					timeSpentHs.remove(varId);
				}
			}
			return visitorMeta;
		}
		public static ArrayList<HashMap<String, String>> negateBounceRateMeta(ArrayList<HashMap<String, String>> visitorMeta ,ArrayList<HashMap<String, String>> goalMeta,Long bounceRateGoalId ){
			
			HashMap<Long, HashMap<String, String>> visitorMasterMeta = new HashMap<Long, HashMap<String, String>>();
			for(int i=0;i<visitorMeta.size();i++){
				HashMap<String, String> hsRow  = visitorMeta.get(i);
				Long varId = Long.parseLong(hsRow.get(VariationConstants.VARIATION_ID));
				visitorMasterMeta.put(varId, hsRow);
			
			}
			
			for(int i=0;i<goalMeta.size();i++){
				HashMap<String , String> hsrow = goalMeta.get(i);
				String hsrowGoalId = hsrow.get(GoalConstants.GOAL_ID);
				if(hsrowGoalId.equals(bounceRateGoalId.toString())){
					Long varId = Long.parseLong(hsrow.get(VariationConstants.VARIATION_ID));
					Long oldGoalCount  = Long.parseLong(hsrow.get(ReportArchieveDimensionConstants.UNIQUE_COUNT));
					if(visitorMasterMeta.containsKey(varId)){
						HashMap<String , String> interhs = visitorMasterMeta.get(varId);
						Long visitorCount = Long.parseLong(interhs.get(ReportArchieveDimensionConstants.UNIQUE_COUNT));
						Long newGoalCount = visitorCount - oldGoalCount;
						hsrow.put(ReportArchieveDimensionConstants.UNIQUE_COUNT, newGoalCount.toString());
						
					}
					
				}
			}
			return goalMeta;
			
		}
*/}
