//$Id$
package com.zoho.abtest.goal;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;
import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.report.CumulativeReportConstants;
import com.zoho.abtest.report.ReportArchieveDimensionConstants;

public class GoalReportResponse  {
	public static String jsonResponse(HttpServletRequest request,ArrayList<GoalReports> lst) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(lst);			
			JSONObject json = ZABResponse.updateMetaInfo(request, CumulativeReportConstants.API_MODULE, array);
			
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){}
		return returnBuffer.toString();
	}

	public static JSONArray getJSONArray(ArrayList<GoalReports> lst) throws JSONException {
		JSONArray array = new JSONArray();
		int size =lst.size();
		for (int i=0;i<size;i++) {
			GoalReports ld=lst.get(i);
			JSONObject jsonObj = new JSONObject();
			
			jsonObj.put(CumulativeReportConstants.GOAL_LINK_NAME, ld.getGoalLinkName());
			jsonObj.put(ReportArchieveDimensionConstants.UNIQUE_VISITOR_COUNT, ld.getUniqueVisitors());
			jsonObj.put(ReportArchieveDimensionConstants.UNIQUE_GOAL_ACHIEVED_COUNT, ld.getUniqueGoalAchievedCount());
			jsonObj.put(ReportArchieveDimensionConstants.TIME_SPENT, ld.getAvgTimeToAchieveGoal());
			jsonObj.put(ReportArchieveDimensionConstants.TIME_SPENT_SECONDS, convertTimeSpentToReadableFormat(ld.getAvgTimeToAchieveGoal()));
			jsonObj.put(ReportArchieveDimensionConstants.TIME_SPENT_ON_PAGE, ld.getAvgTimeSpentOnPage());
			jsonObj.put(ReportArchieveDimensionConstants.TIME_SPENT_ON_PAGE_SECONDS, convertTimeSpentToReadableFormat(ld.getAvgTimeSpentOnPage()));
			
			jsonObj.put(ExperimentConstants.CREATED_TIME, ld.getCreatedTime());
			
			if(ld.getGoalConversionRate()!=null){
				jsonObj.put(CumulativeReportConstants.GOAL_CONVERSION_RATE,Math.round(ld.getGoalConversionRate()*10000.0)/100.0);
			}
			HashMap<String, HashMap<String, Object>> urldetails = ld.getUrlDetails();
			urldetails = sortByComparator(urldetails,Boolean.FALSE);
			Iterator<String> urlItr = urldetails.keySet().iterator();
			JSONArray urlarray = new JSONArray();
			while(urlItr.hasNext()){
				String url = urlItr.next();
				HashMap<String, Object> valuehs = urldetails.get(url);
				Long visitorcount = Long.parseLong(valuehs.get(ReportArchieveDimensionConstants.UNIQUE_VISITOR_COUNT).toString());
				Long goalcount  = Long.parseLong(valuehs.get(ReportArchieveDimensionConstants.UNIQUE_GOAL_ACHIEVED_COUNT).toString());
				Long timespent = Long.parseLong(valuehs.get(ReportArchieveDimensionConstants.TIME_SPENT).toString());
				Long timespentPage = Long.parseLong(valuehs.get(ReportArchieveDimensionConstants.TIME_SPENT_ON_PAGE).toString());
				JSONObject json = new JSONObject();
				json.put(GoalConstants.URL, url);
				
				json.put(ReportArchieveDimensionConstants.VISITOR_COUNT, visitorcount);
				json.put(ReportArchieveDimensionConstants.GOAL_COUNT, goalcount);
				json.put(ReportArchieveDimensionConstants.TIME_SPENT, timespent);
				json.put(ReportArchieveDimensionConstants.TIME_SPENT_SECONDS, convertTimeSpentToReadableFormat(timespent));
				json.put(ReportArchieveDimensionConstants.TIME_SPENT_ON_PAGE, timespentPage);
				json.put(ReportArchieveDimensionConstants.TIME_SPENT_ON_PAGE_SECONDS, convertTimeSpentToReadableFormat(timespentPage));
				Double convrate  = Double.parseDouble(valuehs.get(CumulativeReportConstants.UNIQUE_CNVERSION_RATE).toString());
				json.put(CumulativeReportConstants.CONVERSION_RATE, Math.round(convrate*10000.0)/100.0);
				
				urlarray.put(json);
			}
			jsonObj.put(GoalConstants.URL_DETAILS, urlarray);
			
			HashMap<String, HashMap<String, Object>> devicedetails = ld.getDeviceDetails();
			devicedetails = sortByComparator(devicedetails,Boolean.FALSE);
			Iterator<String> deviceItr = devicedetails.keySet().iterator();
			JSONArray devicearray = new JSONArray();
			while(deviceItr.hasNext()){
				String device = deviceItr.next();
				HashMap<String, Object> valuehs = devicedetails.get(device);
				Long visitorcount = Long.parseLong(valuehs.get(ReportArchieveDimensionConstants.UNIQUE_VISITOR_COUNT).toString());
				Long goalcount  = Long.parseLong(valuehs.get(ReportArchieveDimensionConstants.UNIQUE_GOAL_ACHIEVED_COUNT).toString());
				Long timespent = Long.parseLong(valuehs.get(ReportArchieveDimensionConstants.TIME_SPENT).toString());
				Long timespentPage = Long.parseLong(valuehs.get(ReportArchieveDimensionConstants.TIME_SPENT_ON_PAGE).toString());
				
				JSONObject json = new JSONObject();
				json.put(GoalConstants.DEVICE, device);
				json.put(ReportArchieveDimensionConstants.VISITOR_COUNT, visitorcount);
				json.put(ReportArchieveDimensionConstants.GOAL_COUNT, goalcount);
				json.put(ReportArchieveDimensionConstants.TIME_SPENT_SECONDS, convertTimeSpentToReadableFormat(timespent));
				json.put(ReportArchieveDimensionConstants.TIME_SPENT, timespent);
				json.put(ReportArchieveDimensionConstants.TIME_SPENT_ON_PAGE, timespentPage);
				json.put(ReportArchieveDimensionConstants.TIME_SPENT_ON_PAGE_SECONDS, convertTimeSpentToReadableFormat(timespentPage));
				Double convrate  = Double.parseDouble(valuehs.get(CumulativeReportConstants.UNIQUE_CNVERSION_RATE).toString());
				json.put(CumulativeReportConstants.CONVERSION_RATE, Math.round(convrate*10000.0)/100.0);
				
				
				devicearray.put(json);
			}
			jsonObj.put(GoalConstants.DEVICE_DETAILS, devicearray);
			
			HashMap<String, HashMap<String, Object>> countrydetails = ld.getCountryDetails();
			countrydetails = sortByComparator(countrydetails,Boolean.FALSE);
			Iterator<String> countryItr = countrydetails.keySet().iterator();
			JSONArray countryarray = new JSONArray();
			while(countryItr.hasNext()){
				String country = countryItr.next();
				HashMap<String, Object> valuehs = countrydetails.get(country);
				Long visitorcount = Long.parseLong(valuehs.get(ReportArchieveDimensionConstants.UNIQUE_VISITOR_COUNT).toString());
				Long goalcount  = Long.parseLong(valuehs.get(ReportArchieveDimensionConstants.UNIQUE_GOAL_ACHIEVED_COUNT).toString());
				Long timespent = Long.parseLong(valuehs.get(ReportArchieveDimensionConstants.TIME_SPENT).toString());
				Long timespentPage = Long.parseLong(valuehs.get(ReportArchieveDimensionConstants.TIME_SPENT_ON_PAGE).toString());
				
				JSONObject json = new JSONObject();
				json.put(GoalConstants.COUNTRY, country);
				json.put(ReportArchieveDimensionConstants.VISITOR_COUNT, visitorcount);
				json.put(ReportArchieveDimensionConstants.GOAL_COUNT, goalcount);
				json.put(ReportArchieveDimensionConstants.TIME_SPENT_SECONDS, convertTimeSpentToReadableFormat(timespent));
				json.put(ReportArchieveDimensionConstants.TIME_SPENT, timespent);
				json.put(ReportArchieveDimensionConstants.TIME_SPENT_ON_PAGE, timespentPage);
				json.put(ReportArchieveDimensionConstants.TIME_SPENT_ON_PAGE_SECONDS, convertTimeSpentToReadableFormat(timespentPage));
				Double convrate  = Double.parseDouble(valuehs.get(CumulativeReportConstants.UNIQUE_CNVERSION_RATE).toString());
				json.put(CumulativeReportConstants.CONVERSION_RATE, Math.round(convrate*10000.0)/100.0);
				
				countryarray.put(json);
			}
			jsonObj.put(GoalConstants.COUNTRY_DETAILS, countryarray);
				
			JSONArray visitorarray = new JSONArray();
			HashMap<Long, Long> visitsdetails = ld.getVisits();
			List<Long> keys = new ArrayList<Long>(visitsdetails.keySet());
			Collections.sort(keys);
			
			for(int j=0;j<keys.size();j++){
				Long time = (Long) keys.get(j);
				Long visits = visitsdetails.get(time);
				JSONArray innerarray = new JSONArray();
				innerarray.put(time);
				innerarray.put(visits);
				visitorarray.put(innerarray);
			}
			jsonObj.put(ReportArchieveDimensionConstants.VISITOR_COUNT, visitorarray);
			
			
			JSONArray conversionarray = new JSONArray();
			HashMap<Long, Long> conversiondetails = ld.getConversions();
			keys = new ArrayList<Long>(conversiondetails.keySet());
			Collections.sort(keys);
			for(int j=0;j<keys.size();j++){
		
				Long time = (Long) keys.get(j);
				Long conversions = conversiondetails.get(time);
				JSONArray innerarray = new JSONArray();
				innerarray.put(time);
				innerarray.put(conversions);
				
				conversionarray.put(innerarray);
			}
			jsonObj.put(ReportArchieveDimensionConstants.GOAL_COUNT, conversionarray);
			
			JSONArray convraterray = new JSONArray();
			HashMap<Long, Double> convratedetails = ld.getConversionRate();
			keys = new ArrayList<Long>(convratedetails.keySet());
			Collections.sort(keys);
			for(int j=0;j<keys.size();j++){
				Long time = (Long) keys.get(j);
				Double convrate = convratedetails.get(time);
				JSONArray innerarray = new JSONArray();
				innerarray.put(time);
				innerarray.put(Math.round(convrate*10000.0)/100.0);
			
				convraterray.put(innerarray);
			}
			jsonObj.put(ReportArchieveDimensionConstants.CONVERSION_RATE, convraterray);

			jsonObj.put(ZABConstants.SUCCESS, ld.getSuccess());
			jsonObj.put(ZABConstants.RESPONSE_STRING, ld.getResponseString());
			array.put(jsonObj);
		}
		return array;
	}

	
	
	public static String convertTimeSpentToReadableFormat(Long seconds){
		String time  = "";
		if(seconds == null){
			return time;
		}
		Long hours  = seconds/3600;
		if(hours>0){
			Long remainder = seconds%3600;
			Long mins  = remainder/60;
			time = hours+"h";	// NO I18N
			if(mins>0){
				time = time+" "+mins+"m";// NO I18N
			}
			
		}else{
			Long minutes = seconds/60;
			if(minutes>0){
				time =  minutes+"m ";// NO I18N
			}
			Long secs = seconds%60;
			time = time+secs+"s";// NO I18N
		}
		
		return time ;
	}
	  private static HashMap<String, HashMap<String, Object>> sortByComparator(HashMap<String, HashMap<String, Object>> unsortMap, final boolean order)
	    {

	        List<Entry<String, HashMap<String, Object>>> list = new LinkedList<Entry<String, HashMap<String, Object>>>(unsortMap.entrySet());

	        // Sorting the list based on values
	        Collections.sort(list, new Comparator<Entry<String, HashMap<String, Object>>>()
	        {
	            public int compare(Entry<String, HashMap<String, Object>> o1,
	                    Entry<String, HashMap<String, Object>> o2)
	                    
	            {
	            	HashMap<String, Object> o1hs = o1.getValue();
	            	HashMap<String, Object> o2hs = o2.getValue();
	            	Long o1value = Long.parseLong(  o1hs.get(ReportArchieveDimensionConstants.UNIQUE_GOAL_ACHIEVED_COUNT).toString());
	            	Long o2value =  Long.parseLong( o2hs.get(ReportArchieveDimensionConstants.UNIQUE_GOAL_ACHIEVED_COUNT).toString());
	            	if (order)
	                {
	                    return o1value.compareTo(o2value);
	                }
	                else
	                {
	                    return o2value.compareTo(o1value);

	                }
	            }
	        });

	        // Maintaining insertion order with the help of LinkedList
	        HashMap<String, HashMap<String, Object>> sortedMap = new LinkedHashMap<String, HashMap<String, Object>>();
	        for (Entry<String, HashMap<String, Object>> entry : list)
	        {
	            sortedMap.put(entry.getKey(), entry.getValue());
	        }

	        return sortedMap;
	    }

}
