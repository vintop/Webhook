//$Id$
package com.zoho.abtest.goal;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.ExistsQueryBuilder;
import org.elasticsearch.index.query.MatchQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.aggregations.metrics.avg.AvgAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.avg.InternalAvg;
import org.elasticsearch.search.aggregations.metrics.cardinality.InternalCardinality;
import org.elasticsearch.search.aggregations.metrics.min.InternalMin;
import org.elasticsearch.search.aggregations.metrics.min.MinAggregationBuilder;
import org.apache.commons.lang3.StringUtils;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.elastic.ElasticSearchStatistics;
import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.projectgoals.ProjectGoal;
import com.zoho.abtest.report.CumulativeReportConstants;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.report.ReportArchieveDimensionConstants;
import com.zoho.abtest.report.ReportConstants;
import com.zoho.abtest.report.ReportStatistics;
import com.zoho.abtest.utility.ZABUtil;

public class GoalReports extends Goal {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(GoalReports.class.getName());
	
	
	private Long goalId;
	private String goalLinkName;
	private String goalDisplayName;
	private Integer goalType;
	private Long uniqueVisitors;
	private Long uniqueGoalAchievedCount;
	private Long avgTimeToAchieveGoal;
	
	private LinkedHashMap<String,HashMap<String,Object>> deviceDetails = new LinkedHashMap<String,HashMap<String,Object>>();
	private LinkedHashMap<String,HashMap<String,Object>> urlDetails = new LinkedHashMap<String,HashMap<String,Object>>();
	private LinkedHashMap<String,HashMap<String,Object>> countryDetails = new LinkedHashMap<String,HashMap<String,Object>>();
	
	private HashMap<Long,Long> visits = new HashMap<Long,Long>();
	private HashMap<Long,Long> conversions = new HashMap<Long,Long>();
	private HashMap<Long,Double> conversionRate = new HashMap<Long,Double>();
	
	
	public HashMap<Long, Long> getVisits() {
		return visits;
	}
	public void setVisits(HashMap<Long, Long> visits) {
		this.visits = visits;
	}
	public HashMap<Long, Long> getConversions() {
		return conversions;
	}
	public void setConversions(HashMap<Long, Long> conversions) {
		this.conversions = conversions;
	}
	public HashMap<Long, Double> getConversionRate() {
		return conversionRate;
	}
	public void setConversionRate(HashMap<Long, Double> conversionRate) {
		this.conversionRate = conversionRate;
	}
	public HashMap<String, HashMap<String, Object>> getDeviceDetails() {
		return deviceDetails;
	}
	public void setDeviceDetails(
			LinkedHashMap<String, HashMap<String, Object>> deviceDetails) {
		this.deviceDetails = deviceDetails;
	}
	public HashMap<String, HashMap<String, Object>> getUrlDetails() {
		return urlDetails;
	}
	public void setUrlDetails(LinkedHashMap<String, HashMap<String, Object>> urlDetails) {
		this.urlDetails = urlDetails;
	}
	public HashMap<String, HashMap<String, Object>> getCountryDetails() {
		return countryDetails;
	}
	public void setCountryDetails(
			LinkedHashMap<String, HashMap<String, Object>> countryDetails) {
		this.countryDetails = countryDetails;
	}
	public String getGoalLinkName() {
		return goalLinkName;
	}
	public void setGoalLinkName(String goalLinkName) {
		this.goalLinkName = goalLinkName;
	}
	public String getGoalDisplayName() {
		return goalDisplayName;
	}
	public void setGoalDisplayName(String goalDisplayName) {
		this.goalDisplayName = goalDisplayName;
	}
	public Integer getGoalType() {
		return goalType;
	}
	public void setGoalType(Integer goalType) {
		this.goalType = goalType;
	}
	
	public Long getGoalId() {
		return goalId;
	}
	public void setGoalId(Long goalId) {
		this.goalId = goalId;
	}
	public Long getUniqueVisitors() {
		return uniqueVisitors;
	}
	public void setUniqueVisitors(Long uniqueVisitors) {
		this.uniqueVisitors = uniqueVisitors;
	}
	
	public Long getUniqueGoalAchievedCount() {
		return uniqueGoalAchievedCount;
	}
	public void setUniqueGoalAchievedCount(Long uniqueGoalAchievedCount) {
		this.uniqueGoalAchievedCount = uniqueGoalAchievedCount;
	}
	public Long getAvgTimeToAchieveGoal() {
		return avgTimeToAchieveGoal;
	}
	public void setAvgTimeToAchieveGoal(Long avgTimeToAchieveGoal) {
		this.avgTimeToAchieveGoal = avgTimeToAchieveGoal;
	}
	
	
	public static ArrayList<GoalReports> getGoalReportsForGoal(	HashMap<String,String> hs ){
		
		ArrayList<GoalReports> reports = new ArrayList<GoalReports>();
		GoalReports greport  = new GoalReports();
		Long startTime =null , endTime = null;
		String multiSegmentCriteria = null;
		try {
			String goalLinkName = hs.get(ZABConstants.LINKNAME);
			greport.setGoalLinkName(goalLinkName);
			Goal goal = Goal.getGoalByLinkname(goalLinkName);
			Long goalid = goal.getGoalId();
			Long projectId = goal.getProjectId();
			Long createdTime = goal.getCreatedTime();
			
			if(hs.containsKey(ReportConstants.MULTISEGMENT_CRITERIA)){
				multiSegmentCriteria = hs.get(ReportConstants.MULTISEGMENT_CRITERIA);
			}
			
			startTime = ZABUtil.getTimeInLongFromDateFormStr(hs.get(ReportConstants.START_DATE), "yyyy-MM-dd");		// NO I18N
			if(startTime < createdTime){
				startTime = createdTime;
			}
			
			endTime = ZABUtil.getTimeInLongFromDateFormStr(hs.get(ReportConstants.END_DATE), "yyyy-MM-dd");		// NO I18N
			//Get the long value end date's last milli second
			endTime =  ZABUtil.getNthDayDateInLong(endTime, 1) - 1;
			
			String portalName = ZABUtil.getPortalName();
			String indexName = ElasticSearchUtil.getIndexByPortal(portalName);
			
			Goal pgoal= ProjectGoal.getProjectGoalsForGoal(goalLinkName,startTime,endTime,multiSegmentCriteria).get(0);
			greport.setUniqueVisitors(pgoal.getUniqueVisitors());
			greport.setUniqueGoalAchievedCount(pgoal.getUniqueGoalAchievedCount());
			if(pgoal.getUniqueGoalAchievedCount() >  pgoal.getUniqueVisitors()){
				pgoal.setUniqueGoalAchievedCount(pgoal.getUniqueVisitors());
			}
			greport.setAvgTimeToAchieveGoal(pgoal.getAvgTimeToAchieveGoal());
			greport.setAvgTimeSpentOnPage(pgoal.getAvgTimeSpentOnPage());
			greport.setCreatedTime(pgoal.getCreatedTime());
			greport.setGoalConversionRate( ReportStatistics.getConversionRate(pgoal.getUniqueVisitors(), pgoal.getUniqueGoalAchievedCount().doubleValue()));
			
			LOGGER.log(Level.INFO, "CHART DATA POINT - START");
			
			endTime = ZABUtil.getTimeInLongFromDateFormStr(hs.get(ReportConstants.END_DATE), "yyyy-MM-dd");		// NO I18N
			ArrayList<Long> timePoints = new ArrayList<Long>();
			boolean isHourbased = false;
			long currentTime = ZABUtil.getCurrentTimeInMilliSeconds();
			long hourEndTime = ZABUtil.getNthDayDateInLong(endTime, 1);
			long reportDateInterval = ZABUtil.getInterval(ZABUtil.getNthDayDateInLong(startTime, 0), endTime, TimeUnit.DAYS);
			
			//check the data should be fetched as per hour or day
			//If 1 or less days fetch based on hours
			if(reportDateInterval < 1)
			{
				isHourbased = true;
			}
			if(isHourbased)
			{
				int hourIndex = 1;
				long hourStartTime = startTime;
				hourStartTime = ZABUtil.getNthUserHourInLong(startTime, 0);
				long time = hourStartTime;
				timePoints.add(time);
				while(time != hourEndTime)
				{
					time = ZABUtil.getNthUserHourInLong(hourStartTime, hourIndex);
					if(time>currentTime || time >= hourEndTime)
					{
						break;
					}
					timePoints.add(time);
					hourIndex++;
				}
			}
			else
			{
				int dayIndex = 1;
				long time = startTime;
				time = ZABUtil.getNthDayDateInLong(startTime, 0);
				timePoints.add(time);
				while(time < endTime)
				{
					time = ZABUtil.getNthDayDateInLong(startTime, dayIndex);
					timePoints.add(time);
					dayIndex++;
				}
			}
			HashMap<Long, Long> destTimePointHs = new HashMap<Long, Long>();
			ArrayList<Long> desttimePoints = timePoints;
			if(isHourbased && reportDateInterval > 1)
			{
				desttimePoints = new ArrayList<Long>();
				int size = timePoints.size();
				int i = 0;
				long timePointConversionLength = reportDateInterval+1;
				while(i<size)
				{
					int j=i;
					long destTimePoint = timePoints.get(i);
					desttimePoints.add(destTimePoint);
					while(j < (i+timePointConversionLength) && j<size)
					{
						long sourceTimePoint = timePoints.get(j);
						destTimePointHs.put(sourceTimePoint, destTimePoint);
						j++;
					}
					i=j;
				}
			}
			endTime = hourEndTime-1;
			BoolQueryBuilder query = queryBuilder(portalName,projectId,goalid,startTime,endTime,multiSegmentCriteria);
			List<AggregationBuilder> agg = getChartAggregation(isHourbased);
			
			SearchResponse response = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.VISITOR_RAW_TYPE, 0, query, agg);
			SearchResponse response2 = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.GOAL_RAW_TYPE, 0, query, agg);
			
			HashMap<Long, HashMap<String,Long>> chartdetails = readDatapointVisitResponseData(response,response2,isHourbased);
			if(isHourbased && reportDateInterval > 1)
			{
				chartdetails = convertVisitorHourEntriesToDestTimePoints(chartdetails,destTimePointHs);	
			}
			Collections.sort(desttimePoints);
			greport = calculateCumulativeCount(chartdetails,desttimePoints,greport);
			
			LOGGER.log(Level.INFO, "CHART DATA POINT - END");
         	greport.setSuccess(Boolean.TRUE);
			
		} catch (Exception e) {
			
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			greport.setSuccess(Boolean.FALSE);
		}
		reports.add(greport);
		return reports;
	}

	public static ArrayList<AggregationBuilder>  getGoalDetailedReportAggregationList(){
		ArrayList<AggregationBuilder> finalAggs = new ArrayList<AggregationBuilder> ();
		AvgAggregationBuilder avgAggr = AggregationBuilders.avg("avg_time").field(ElasticSearchConstants.TIME_SPENT); // No I18N
		
		TermsAggregationBuilder devicesAgg = AggregationBuilders.terms(ElasticSearchConstants.DEVICE). 
				field(ElasticSearchConstants.DEVICE).
				size(5).
					subAggregation(ElasticSearchStatistics.getVisitorCardinalityAggr()).subAggregation(avgAggr).subAggregation(ElasticSearchStatistics.getUUIDVisitorCardinalityAggr()) ;
		TermsAggregationBuilder urlterms = AggregationBuilders.terms(ElasticSearchConstants.CURRENTURL).
				field(ElasticSearchConstants.CURRENTURL).size(ElasticSearchConstants.URLS_MAX_COUNT).
				subAggregation(ElasticSearchStatistics.getVisitorCardinalityAggr()).subAggregation(avgAggr).subAggregation(ElasticSearchStatistics.getUUIDVisitorCardinalityAggr()) ; 
		TermsAggregationBuilder countryAggs = AggregationBuilders.terms(ElasticSearchConstants.COUNTRY).
				field(ElasticSearchConstants.COUNTRY).size(ElasticSearchConstants.URLS_MAX_COUNT).
				subAggregation(ElasticSearchStatistics.getVisitorCardinalityAggr()).subAggregation(avgAggr).subAggregation(ElasticSearchStatistics.getUUIDVisitorCardinalityAggr()) ; 
		
		finalAggs.add(devicesAgg);
		finalAggs.add(urlterms);
		finalAggs.add(countryAggs);
		
		return finalAggs;
		
	}
	
	
	public static BoolQueryBuilder queryBuilder(String portal,Long projectid,Long goalId, Long startTime, Long endTime, String multisegmentCriteria ){
		
		BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
		MatchQueryBuilder portalMatch = QueryBuilders.matchQuery(ElasticSearchConstants.PORTAL, portal);
		
		List<QueryBuilder> conditionList = new ArrayList<QueryBuilder>();
		conditionList.add(portalMatch);
		
		if(projectid!=null){
			MatchQueryBuilder projectMatch = QueryBuilders.matchQuery(ElasticSearchConstants.PROJECTID, projectid);
			conditionList.add(projectMatch);
			
		}
		
		if(goalId != null){
			MatchQueryBuilder eventMatch = QueryBuilders.matchQuery(ElasticSearchConstants.GOALID, goalId);
			conditionList.add(eventMatch);
		}

		if(startTime != null && endTime != null)
		{
			RangeQueryBuilder timeRange = QueryBuilders.rangeQuery("time").gte(startTime).lte(endTime); // No I18N
			conditionList.add(timeRange);
		}
		if(multisegmentCriteria!=null){
			BoolQueryBuilder multiSegmentQuery = ElasticSearchStatistics.generateMultiSegmentCriteria(multisegmentCriteria);
			conditionList.add(multiSegmentQuery);
		}
		
		boolQueryBuilder.must().addAll(conditionList);
		
		ExistsQueryBuilder existsQuery = QueryBuilders.existsQuery(ElasticSearchConstants.EXPERIMENTID);
		boolQueryBuilder.mustNot(existsQuery);
		
		return boolQueryBuilder;
	}
	
	
	public static List<AggregationBuilder> getChartAggregation(Boolean isHourbased){

		List<AggregationBuilder> finalAggr = new ArrayList<AggregationBuilder>();
		try
		{
			//TODO Timezone issue needs to be considered here
			String format = isHourbased?"yyyy-MM-dd HH":"yyyy-MM-dd"; // No I18N
			AggregationBuilder visitorAggr	= AggregationBuilders.terms("visitors").field(ElasticSearchConstants.VISITORID).size(ElasticSearchConstants.VISITOR_MAX_COUNT);  // No I18N
			AggregationBuilder uuidVisitorAggr	= AggregationBuilders.terms("uuid").field(ElasticSearchConstants.UUID).size(ElasticSearchConstants.VISITOR_MAX_COUNT);  // No I18N

			MinAggregationBuilder firstDateAggr	= AggregationBuilders.min("first_date").field(ElasticSearchConstants.TIME).format(format); // No I18N	
			finalAggr.add(visitorAggr.subAggregation(firstDateAggr));
			finalAggr.add(uuidVisitorAggr.subAggregation(firstDateAggr));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		return finalAggr;
	}

	public static HashMap<Long, HashMap<String,Long>> readDatapointVisitResponseData(SearchResponse visitorresponse,SearchResponse goalresponse, boolean isHourbased)
	{
		HashMap<Long, HashMap<String,Long>> returnhs = new HashMap<Long, HashMap<String,Long>>();
		try
		{

			HashMap<Long, Long> visitordateHs = new HashMap<Long,Long>();
			Aggregations buckaggrResponse = visitorresponse.getAggregations();
			Terms visitorTerms = buckaggrResponse.get("visitors");
			List<? extends Bucket> visitorBuckets = visitorTerms.getBuckets();
			for(Bucket visitorBucket:visitorBuckets)
			{
				Aggregations visitorbuckaggrResponse = visitorBucket.getAggregations();
				InternalMin minDate = visitorbuckaggrResponse.get("first_date");
				Long dateLong = (long) minDate.getValue();
				if(isHourbased)
				{
					dateLong = ZABUtil.getUserHourInLong(dateLong);
				}
				else
				{
					dateLong = ZABUtil.getUserDateInLong(dateLong);
				}
				long count = 0;
				if(visitordateHs.containsKey(dateLong))
				{
					count = visitordateHs.get(dateLong);
				}
				visitordateHs.put(dateLong, count+1);
			}
			
			Terms uuidVisitorTerms = buckaggrResponse.get("uuid");
			List<? extends Bucket> uuidVisitorBuckets = uuidVisitorTerms.getBuckets();
			for(Bucket visitorBucket:uuidVisitorBuckets)
			{
				Aggregations visitorbuckaggrResponse = visitorBucket.getAggregations();
				InternalMin minDate = visitorbuckaggrResponse.get("first_date");
				Long dateLong = (long) minDate.getValue();
				if(isHourbased)
				{
					dateLong = ZABUtil.getUserHourInLong(dateLong);
				}
				else
				{
					dateLong = ZABUtil.getUserDateInLong(dateLong);
				}
				long count = 0;
				if(visitordateHs.containsKey(dateLong))
				{
					count = visitordateHs.get(dateLong);
				}
				visitordateHs.put(dateLong, count+1);
			}
			
			HashMap<Long, Long> goaldateHs = new HashMap<Long,Long>();
			buckaggrResponse = goalresponse.getAggregations();
			Terms goalTerms = buckaggrResponse.get("visitors");
			List<? extends Bucket> goalBuckets = goalTerms.getBuckets();
			for(Bucket goalBucket:goalBuckets)
			{
				Aggregations goalbuckaggrResponse = goalBucket.getAggregations();
				InternalMin minDate = goalbuckaggrResponse.get("first_date");
				Long dateLong = (long) minDate.getValue();
				if(isHourbased)
				{
					dateLong = ZABUtil.getUserHourInLong(dateLong);
				}
				else
				{
					dateLong = ZABUtil.getUserDateInLong(dateLong);
				}
				long count = 0;
				if(goaldateHs.containsKey(dateLong))
				{
					count = goaldateHs.get(dateLong);
				}
				goaldateHs.put(dateLong, count+1);
			}
			
			Terms uuidGoalTerms = buckaggrResponse.get("uuid");
			List<? extends Bucket> uuidGoalBuckets = uuidGoalTerms.getBuckets();
			for(Bucket goalBucket:uuidGoalBuckets)
			{
				Aggregations goalbuckaggrResponse = goalBucket.getAggregations();
				InternalMin minDate = goalbuckaggrResponse.get("first_date");
				Long dateLong = (long) minDate.getValue();
				if(isHourbased)
				{
					dateLong = ZABUtil.getUserHourInLong(dateLong);
				}
				else
				{
					dateLong = ZABUtil.getUserDateInLong(dateLong);
				}
				long count = 0;
				if(goaldateHs.containsKey(dateLong))
				{
					count = goaldateHs.get(dateLong);
				}
				goaldateHs.put(dateLong, count+1);
			}

			
			Iterator<Long> keyitr = visitordateHs.keySet().iterator();
			while(keyitr.hasNext()){
				Long time = keyitr.next();
				Long visitorcount = visitordateHs.get(time);
				Long goalcount = 0l;
				if(goaldateHs.containsKey(time)){
					goalcount =  goaldateHs.get(time);
				}
				HashMap<String,Long> innerhs = new HashMap<String,Long>();
				innerhs.put(ReportArchieveDimensionConstants.VISITOR_COUNT, visitorcount);
				innerhs.put(ReportArchieveDimensionConstants.GOAL_COUNT, goalcount);
				returnhs.put(time, innerhs);
			}

		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			
		}
		return  returnhs;
	}
	
	
	public static  HashMap<Long, HashMap<String, Long>> convertVisitorHourEntriesToDestTimePoints( HashMap<Long, HashMap<String, Long>> chartdetails, HashMap<Long, Long> destTimePointHs)
	{
			HashMap<Long, HashMap<String, Long>> destTimeMap =  new HashMap<Long, HashMap<String, Long>>();
			for(Map.Entry<Long,HashMap<String, Long>> timeEntry:chartdetails.entrySet())
			{
				Long time = timeEntry.getKey();
				HashMap<String, Long> valueHs = timeEntry.getValue();
				Long visitorcount = valueHs.get(ReportArchieveDimensionConstants.VISITOR_COUNT);
				Long goalcount = valueHs.get(ReportArchieveDimensionConstants.GOAL_COUNT);
				Long destTime = destTimePointHs.get(time);
				if(destTimeMap.containsKey(destTime))
				{
					HashMap<String, Long> destValueHs = destTimeMap.get(destTime);
					destValueHs.put(ReportArchieveDimensionConstants.VISITOR_COUNT, destValueHs.get(ReportArchieveDimensionConstants.VISITOR_COUNT)+visitorcount);
					destValueHs.put(ReportArchieveDimensionConstants.GOAL_COUNT, destValueHs.get(ReportArchieveDimensionConstants.GOAL_COUNT)+goalcount);
					
				}
				else
				{
					HashMap<String, Long> destValueHs = new HashMap<String, Long>();
					destValueHs.put(ReportArchieveDimensionConstants.VISITOR_COUNT, visitorcount);
					destValueHs.put(ReportArchieveDimensionConstants.GOAL_COUNT, goalcount);
					destTimeMap.put(destTime, destValueHs);
				}
			}
		return destTimeMap;
	}

	
	public static GoalReports calculateCumulativeCount( HashMap<Long, HashMap<String, Long>> chartdetails, ArrayList<Long> timePoints,GoalReports goalreport)
	{	
			Long cumulativeVisitCount = 0l;
			Long cumulativeGoalCount = 0l;
			for(Long time:timePoints)
			{
				if(chartdetails.containsKey(time))
				{
					HashMap<String, Long> valueHs = chartdetails.get(time);
					cumulativeVisitCount = cumulativeVisitCount+ valueHs.get(ReportArchieveDimensionConstants.VISITOR_COUNT);
					cumulativeGoalCount = cumulativeGoalCount+ valueHs.get(ReportArchieveDimensionConstants.GOAL_COUNT);
					goalreport.getVisits().put(time, valueHs.get(ReportArchieveDimensionConstants.VISITOR_COUNT));
					goalreport.getConversions().put(time, valueHs.get(ReportArchieveDimensionConstants.GOAL_COUNT));
					Double convrate  = ReportStatistics.getConversionRate(cumulativeVisitCount, cumulativeGoalCount.doubleValue());
					goalreport.getConversionRate().put(time, convrate);
					
				}else{
					goalreport.getVisits().put(time, 0l);
					goalreport.getConversions().put(time, 0l);	
					Double convrate  = ReportStatistics.getConversionRate(cumulativeVisitCount, cumulativeGoalCount.doubleValue());
					goalreport.getConversionRate().put(time, convrate);
					
				}
			}
		return goalreport;
	}
	
	public static ArrayList<GoalReports> getUrlReportsForGoal(	HashMap<String,String> hs ){

		ArrayList<GoalReports> reports = new ArrayList<GoalReports>();
		GoalReports greport  = new GoalReports();
		Long startTime =null , endTime = null;
		String multiSegmentCriteria = null;
		try {
			String goalLinkName = hs.get(ZABConstants.LINKNAME);
			greport.setGoalLinkName(goalLinkName);
			Goal goal = Goal.getGoalByLinkname(goalLinkName);
			Long goalid = goal.getGoalId();
			Long projectId = goal.getProjectId();
			Long createdTime = goal.getCreatedTime();
			if(hs.containsKey(ReportConstants.MULTISEGMENT_CRITERIA)){
				multiSegmentCriteria = hs.get(ReportConstants.MULTISEGMENT_CRITERIA);
			}
			startTime = ZABUtil.getTimeInLongFromDateFormStr(hs.get(ReportConstants.START_DATE), "yyyy-MM-dd");		// NO I18N
			if(startTime < createdTime){
				startTime = createdTime;
			}
			
			endTime = ZABUtil.getTimeInLongFromDateFormStr(hs.get(ReportConstants.END_DATE), "yyyy-MM-dd");		// NO I18N
			//Get the long value end date's last milli second
			endTime =  ZABUtil.getNthDayDateInLong(endTime, 1) - 1;
			
			ArrayList<AggregationBuilder> finalAggs = getGoalUrlReportAggregation();
			String portalName = ZABUtil.getPortalName();
			String indexName = ElasticSearchUtil.getIndexByPortal(portalName);
			BoolQueryBuilder query = queryBuilder(portalName,projectId,goalid,startTime,endTime,multiSegmentCriteria);
			
			SearchResponse visitorResponse = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.VISITOR_RAW_TYPE, 0, query, finalAggs);
			SearchResponse goalResponse = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.GOAL_RAW_TYPE, 0, query, finalAggs);
			greport  = readUrlGoalResponse(visitorResponse,goalResponse);
         	greport.setSuccess(Boolean.TRUE);
			
		} catch (Exception e) {
			
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			greport.setSuccess(Boolean.FALSE);
		}
		reports.add(greport);
		return reports;
	}
	public static ArrayList<AggregationBuilder>  getGoalUrlReportAggregation(){
		ArrayList<AggregationBuilder> finalAggs = new ArrayList<AggregationBuilder> ();
		AvgAggregationBuilder avgAggr = AggregationBuilders.avg("avg_time").field(ElasticSearchConstants.TIME_SPENT); // No I18N
		
		TermsAggregationBuilder urlterms = AggregationBuilders.terms(ElasticSearchConstants.CURRENTURL).
				field(ElasticSearchConstants.CURRENTURL).size(ElasticSearchConstants.URLS_MAX_COUNT).
				subAggregation(ElasticSearchStatistics.getVisitorCardinalityAggr()).subAggregation(avgAggr).subAggregation(ElasticSearchStatistics.getUUIDVisitorCardinalityAggr()) ; 
	
		finalAggs.add(urlterms);
		
		return finalAggs;
		
	}
	public static GoalReports readUrlGoalResponse(SearchResponse visitorResponse,SearchResponse goalResponse){
		
		LinkedHashMap<String,HashMap<String,Object>> currenturlhs = new LinkedHashMap<String,HashMap<String,Object>>();
		Aggregations visitoraggrResponse = visitorResponse.getAggregations();
		
		Terms terms = visitoraggrResponse.get(ElasticSearchConstants.CURRENTURL);
		List<? extends Bucket> buckets = terms.getBuckets();
		for(Bucket bucket:buckets)
		{
			String currenturl = (String)bucket.getKey();
			Aggregations buckaggrResponse = bucket.getAggregations();
			InternalCardinality card = buckaggrResponse.get("distinct_visitors");
			InternalCardinality uuidVisitors = buckaggrResponse.get("distinct_uuid_visitors");
			InternalAvg avg = buckaggrResponse.get("avg_time");
			Double avgTime  = avg.getValue();
			
			HashMap<String , Object> hs = new HashMap<String, Object>();
			long vistorsCount = card.getValue();
			long uuidVisitorsCount = uuidVisitors.getValue();
			long totalVisitorsCount = vistorsCount + uuidVisitorsCount;
			hs.put(ReportArchieveDimensionConstants.UNIQUE_VISITOR_COUNT,totalVisitorsCount);
			hs.put(ReportArchieveDimensionConstants.UNIQUE_GOAL_ACHIEVED_COUNT, 0);
			hs.put(ReportArchieveDimensionConstants.TIME_SPENT, 0);
			hs.put(ReportArchieveDimensionConstants.TIME_SPENT_ON_PAGE, avgTime.longValue());
			hs.put(CumulativeReportConstants.UNIQUE_CNVERSION_RATE, 0);
			currenturlhs.put(currenturl, hs);
		}
		Aggregations goalsaggrResponse = goalResponse.getAggregations();	
		terms = goalsaggrResponse.get(ElasticSearchConstants.CURRENTURL);
		buckets = terms.getBuckets();
		for(Bucket bucket:buckets)
		{
			String currenturl = (String)bucket.getKey();
			if(currenturlhs.containsKey(currenturl)){
				Aggregations buckaggrResponse = bucket.getAggregations();
				InternalCardinality card = buckaggrResponse.get("distinct_visitors");
				InternalCardinality uuidVisitors = buckaggrResponse.get("distinct_uuid_visitors");

				InternalAvg avg = buckaggrResponse.get("avg_time");
				Double avgTime  = avg.getValue();
				HashMap<String , Object> hs = currenturlhs.get(currenturl);
				long visitorsCount = card.getValue();
				long uuidVisitorsCount = uuidVisitors.getValue();
				long totalVisitorsCount = visitorsCount + uuidVisitorsCount;
				
				hs.put(ReportArchieveDimensionConstants.UNIQUE_GOAL_ACHIEVED_COUNT, totalVisitorsCount);
				hs.put(ReportArchieveDimensionConstants.TIME_SPENT, avgTime.longValue());
				Long visitors = Long.parseLong(hs.get(ReportArchieveDimensionConstants.UNIQUE_VISITOR_COUNT).toString()) ;
				Long goals = card.getValue();
				Long uuidGoals = uuidVisitors.getValue();
				Long tatalUniqueGoals = goals + uuidGoals;
				if(tatalUniqueGoals > visitors){
					tatalUniqueGoals = visitors;
					hs.put(ReportArchieveDimensionConstants.UNIQUE_GOAL_ACHIEVED_COUNT, visitors);
				}
				hs.put(CumulativeReportConstants.UNIQUE_CNVERSION_RATE, ReportStatistics.getConversionRate(visitors, tatalUniqueGoals.doubleValue()));
				currenturlhs.put(currenturl, hs);
			}
			
		}
		GoalReports reports = new GoalReports();
		reports.setUrlDetails(currenturlhs);
		return reports;
	
	}
	public static ArrayList<GoalReports> getDeviceReportsForGoal(	HashMap<String,String> hs ){
		
		ArrayList<GoalReports> reports = new ArrayList<GoalReports>();
		GoalReports greport  = new GoalReports();
		Long startTime =null , endTime = null;
		String multiSegmentCriteria = null;
		try {
			String goalLinkName = hs.get(ZABConstants.LINKNAME);
			greport.setGoalLinkName(goalLinkName);
			Goal goal = Goal.getGoalByLinkname(goalLinkName);
			Long goalid = goal.getGoalId();
			Long projectId = goal.getProjectId();
			Long createdTime = goal.getCreatedTime();
			if(hs.containsKey(ReportConstants.MULTISEGMENT_CRITERIA)){
				multiSegmentCriteria = hs.get(ReportConstants.MULTISEGMENT_CRITERIA);
			}
			
			startTime = ZABUtil.getTimeInLongFromDateFormStr(hs.get(ReportConstants.START_DATE), "yyyy-MM-dd");		// NO I18N
			if(startTime < createdTime){
				startTime = createdTime;
			}
			
			endTime = ZABUtil.getTimeInLongFromDateFormStr(hs.get(ReportConstants.END_DATE), "yyyy-MM-dd");		// NO I18N
			//Get the long value end date's last milli second
			endTime =  ZABUtil.getNthDayDateInLong(endTime, 1) - 1;
			
			ArrayList<AggregationBuilder> finalAggs = getGoalDevicedReportAggregation();
			String portalName = ZABUtil.getPortalName();
			String indexName = ElasticSearchUtil.getIndexByPortal(portalName);
			BoolQueryBuilder query = queryBuilder(portalName,projectId,goalid,startTime,endTime,multiSegmentCriteria);	
			SearchResponse visitorResponse = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.VISITOR_RAW_TYPE, 0, query, finalAggs);
			SearchResponse goalResponse = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.GOAL_RAW_TYPE, 0, query, finalAggs);
			greport  = readDeviceGoalResponse(visitorResponse,goalResponse);
		
         	greport.setSuccess(Boolean.TRUE);
			
		} catch (Exception e) {
			
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			greport.setSuccess(Boolean.FALSE);
		}
		reports.add(greport);
		return reports;
	}
	public static GoalReports readDeviceGoalResponse(SearchResponse visitorResponse,SearchResponse goalResponse){
		
		LinkedHashMap<String,HashMap<String,Object>> deviceshs = new LinkedHashMap<String,HashMap<String,Object>>();
		LinkedHashMap<String,Object> desktopHs = new LinkedHashMap<String,Object>();
		desktopHs.put(ReportArchieveDimensionConstants.UNIQUE_VISITOR_COUNT,0);
		desktopHs.put(ReportArchieveDimensionConstants.UNIQUE_GOAL_ACHIEVED_COUNT, 0);
		desktopHs.put(ReportArchieveDimensionConstants.TIME_SPENT, 0);
		desktopHs.put(ReportArchieveDimensionConstants.TIME_SPENT_ON_PAGE, 0);
		desktopHs.put(CumulativeReportConstants.UNIQUE_CNVERSION_RATE, 0);
		LinkedHashMap<String,Object> tabletHs = new LinkedHashMap<String,Object>();
		tabletHs.put(ReportArchieveDimensionConstants.UNIQUE_VISITOR_COUNT,0);
		tabletHs.put(ReportArchieveDimensionConstants.UNIQUE_GOAL_ACHIEVED_COUNT, 0);
		tabletHs.put(ReportArchieveDimensionConstants.TIME_SPENT, 0);
		tabletHs.put(ReportArchieveDimensionConstants.TIME_SPENT_ON_PAGE, 0);
		tabletHs.put(CumulativeReportConstants.UNIQUE_CNVERSION_RATE, 0);
		LinkedHashMap<String,Object> mobileHs = new LinkedHashMap<String,Object>();
		mobileHs.put(ReportArchieveDimensionConstants.UNIQUE_VISITOR_COUNT,0);
		mobileHs.put(ReportArchieveDimensionConstants.UNIQUE_GOAL_ACHIEVED_COUNT, 0);
		mobileHs.put(ReportArchieveDimensionConstants.TIME_SPENT, 0);
		mobileHs.put(ReportArchieveDimensionConstants.TIME_SPENT_ON_PAGE, 0);
		mobileHs.put(CumulativeReportConstants.UNIQUE_CNVERSION_RATE, 0);
		deviceshs.put("Desktop", desktopHs);
		deviceshs.put("Tablet", tabletHs);
		deviceshs.put("Mobile", mobileHs);
		
		
		Aggregations visitoraggrResponse = visitorResponse.getAggregations();
		Terms terms = visitoraggrResponse.get(ElasticSearchConstants.DEVICE);
		List<? extends Bucket> buckets = terms.getBuckets();
		for(Bucket bucket:buckets)
		{
			String devicename = (String)bucket.getKey();
			Aggregations buckaggrResponse = bucket.getAggregations();
			InternalCardinality card = buckaggrResponse.get("distinct_visitors");
			InternalCardinality uuidVisitors = buckaggrResponse.get("distinct_uuid_visitors");

			InternalAvg avg = buckaggrResponse.get("avg_time");
			Double avgTime  = avg.getValue();
			HashMap<String , Object> hs = deviceshs.get(StringUtils.capitalize(devicename.toLowerCase()));
			if(hs == null){
				hs = new HashMap<String,Object>();
				hs.put(ReportArchieveDimensionConstants.UNIQUE_VISITOR_COUNT,0);
				hs.put(ReportArchieveDimensionConstants.UNIQUE_GOAL_ACHIEVED_COUNT, 0);
				hs.put(ReportArchieveDimensionConstants.TIME_SPENT, 0);
				hs.put(ReportArchieveDimensionConstants.TIME_SPENT_ON_PAGE, 0);
				hs.put(CumulativeReportConstants.UNIQUE_CNVERSION_RATE, 0);
				deviceshs.put(StringUtils.capitalize(devicename.toLowerCase()), hs);
			}
			long vistorsCount = card.getValue();
			long uuidVisitorsCount = uuidVisitors.getValue();
			long totalVisitorsCount = vistorsCount + uuidVisitorsCount;
			hs.put(ReportArchieveDimensionConstants.UNIQUE_VISITOR_COUNT,totalVisitorsCount);
			hs.put(ReportArchieveDimensionConstants.TIME_SPENT_ON_PAGE,avgTime.longValue());
			
		}
		
		Aggregations goalsaggrResponse = goalResponse.getAggregations();
		terms = goalsaggrResponse.get(ElasticSearchConstants.DEVICE);
		buckets = terms.getBuckets();
		for(Bucket bucket:buckets)
		{
			String devicename = (String)bucket.getKey();
			devicename = StringUtils.capitalize(devicename.toLowerCase());
			if(deviceshs.containsKey(devicename)){
				Aggregations buckaggrResponse = bucket.getAggregations();
				InternalCardinality card = buckaggrResponse.get("distinct_visitors");
				InternalCardinality uuidVisitors = buckaggrResponse.get("distinct_uuid_visitors");

				InternalAvg avg = buckaggrResponse.get("avg_time");
				Double avgTime  = avg.getValue();
				HashMap<String , Object> hs = deviceshs.get(devicename);
				long visitorsCount = card.getValue();
				long uuidVisitorsCount = uuidVisitors.getValue();
				long totalVisitorsCount = visitorsCount + uuidVisitorsCount;
				hs.put(ReportArchieveDimensionConstants.UNIQUE_GOAL_ACHIEVED_COUNT, totalVisitorsCount);
				hs.put(ReportArchieveDimensionConstants.TIME_SPENT, avgTime.longValue());
				Long visitors = Long.parseLong( hs.get(ReportArchieveDimensionConstants.UNIQUE_VISITOR_COUNT).toString()) ;
				Long goals = card.getValue();
				Long uuidGoals = uuidVisitors.getValue();
				Long tatalUniqueGoals = goals + uuidGoals;
				if(tatalUniqueGoals > visitors){
					tatalUniqueGoals = visitors;
					hs.put(ReportArchieveDimensionConstants.UNIQUE_GOAL_ACHIEVED_COUNT, visitors);
				}
				hs.put(CumulativeReportConstants.UNIQUE_CNVERSION_RATE, ReportStatistics.getConversionRate(visitors, tatalUniqueGoals.doubleValue()));
				deviceshs.put(devicename, hs);
			}
		
		}
		
		GoalReports reports = new GoalReports();
		reports.setDeviceDetails(deviceshs);
	
		return reports;
	
	}
	public static ArrayList<AggregationBuilder>  getGoalDevicedReportAggregation(){
		ArrayList<AggregationBuilder> finalAggs = new ArrayList<AggregationBuilder> ();
		AvgAggregationBuilder avgAggr = AggregationBuilders.avg("avg_time").field(ElasticSearchConstants.TIME_SPENT); // No I18N
		
		TermsAggregationBuilder devicesAgg = AggregationBuilders.terms(ElasticSearchConstants.DEVICE). 
				field(ElasticSearchConstants.DEVICE).
				size(5).
					subAggregation(ElasticSearchStatistics.getVisitorCardinalityAggr()).subAggregation(avgAggr).subAggregation(ElasticSearchStatistics.getUUIDVisitorCardinalityAggr()) ;
		
		finalAggs.add(devicesAgg);
	
		return finalAggs;
		
	}
	public static ArrayList<AggregationBuilder>  getGoalCountryReportAggregation(){
		ArrayList<AggregationBuilder> finalAggs = new ArrayList<AggregationBuilder> ();
		AvgAggregationBuilder avgAggr = AggregationBuilders.avg("avg_time").field(ElasticSearchConstants.TIME_SPENT); // No I18N
		
		TermsAggregationBuilder countryAggs = AggregationBuilders.terms(ElasticSearchConstants.COUNTRY).
				field(ElasticSearchConstants.COUNTRY).size(ElasticSearchConstants.URLS_MAX_COUNT).
				subAggregation(ElasticSearchStatistics.getVisitorCardinalityAggr()).subAggregation(avgAggr).subAggregation(ElasticSearchStatistics.getUUIDVisitorCardinalityAggr()) ; 
	
		finalAggs.add(countryAggs);
		return finalAggs;
		
	}
	
	
	public static GoalReports readCountryGoalResponse(SearchResponse visitorResponse,SearchResponse goalResponse){

		
		LinkedHashMap<String,HashMap<String,Object>> countryhs = new LinkedHashMap<String,HashMap<String,Object>>();
		Aggregations visitoraggrResponse = visitorResponse.getAggregations();
		Terms terms = visitoraggrResponse.get(ElasticSearchConstants.COUNTRY);
		List<? extends Bucket> buckets = terms.getBuckets();
		for(Bucket bucket:buckets)
		{
			String country = (String)bucket.getKey();
			Aggregations buckaggrResponse = bucket.getAggregations();
			InternalCardinality card = buckaggrResponse.get("distinct_visitors");
			InternalCardinality uuidVisitors = buckaggrResponse.get("distinct_uuid_visitors");

			InternalAvg avg = buckaggrResponse.get("avg_time");
			Double avgTime  = avg.getValue();
			
			HashMap<String , Object> hs = new HashMap<String, Object>();
			long vistorsCount = card.getValue();
			long uuidVisitorsCount = uuidVisitors.getValue();
			long totalVisitorsCount = vistorsCount + uuidVisitorsCount;
			hs.put(ReportArchieveDimensionConstants.UNIQUE_VISITOR_COUNT,totalVisitorsCount);
			hs.put(ReportArchieveDimensionConstants.UNIQUE_GOAL_ACHIEVED_COUNT, 0);
			hs.put(ReportArchieveDimensionConstants.TIME_SPENT, 0);
			hs.put(CumulativeReportConstants.UNIQUE_CNVERSION_RATE, 0);
			hs.put(ReportArchieveDimensionConstants.TIME_SPENT_ON_PAGE, avgTime.longValue());
			countryhs.put(country, hs);
		}
		
		Aggregations goalsaggrResponse = goalResponse.getAggregations();
		terms = goalsaggrResponse.get(ElasticSearchConstants.COUNTRY);
		buckets = terms.getBuckets();
		for(Bucket bucket:buckets)
		{
			String country = (String)bucket.getKey();
			if(countryhs.containsKey(country)){
				Aggregations buckaggrResponse = bucket.getAggregations();
				InternalCardinality card = buckaggrResponse.get("distinct_visitors");
				InternalCardinality uuidVisitors = buckaggrResponse.get("distinct_uuid_visitors");

				InternalAvg avg = buckaggrResponse.get("avg_time");
				Double avgTime  = avg.getValue();
				HashMap<String , Object> hs = countryhs.get(country);
				long visitorsCount = card.getValue();
				long uuidVisitorsCount = uuidVisitors.getValue();
				long totalVisitorsCount = visitorsCount + uuidVisitorsCount;
				hs.put(ReportArchieveDimensionConstants.UNIQUE_GOAL_ACHIEVED_COUNT, totalVisitorsCount);
				hs.put(ReportArchieveDimensionConstants.TIME_SPENT, avgTime.longValue());
				Long visitors = Long.parseLong( hs.get(ReportArchieveDimensionConstants.UNIQUE_VISITOR_COUNT).toString()) ;
				Long goals = card.getValue();
				Long uuidGoals = uuidVisitors.getValue();
				Long tatalUniqueGoals = goals + uuidGoals;
				if(tatalUniqueGoals > visitors){
					tatalUniqueGoals = visitors;
					hs.put(ReportArchieveDimensionConstants.UNIQUE_GOAL_ACHIEVED_COUNT, visitors);
				}
				hs.put(CumulativeReportConstants.UNIQUE_CNVERSION_RATE, ReportStatistics.getConversionRate(visitors, tatalUniqueGoals.doubleValue()));
				countryhs.put(country, hs);
			}
		}
		
		GoalReports reports = new GoalReports();
		reports.setCountryDetails(countryhs);
		return reports;
	
	}

	public static ArrayList<GoalReports> getCountryReportsForGoal(HashMap<String,String> hs ){
		
		ArrayList<GoalReports> reports = new ArrayList<GoalReports>();
		GoalReports greport  = new GoalReports();
		Long startTime =null , endTime = null;
		String multiSegmentCriteria = null;
		try {
		
			
			String goalLinkName = hs.get(ZABConstants.LINKNAME);
			greport.setGoalLinkName(goalLinkName);
			Goal goal = Goal.getGoalByLinkname(goalLinkName);
			Long goalid = goal.getGoalId();
			Long projectId = goal.getProjectId();
			Long createdTime = goal.getCreatedTime();
			
			
			if(hs.containsKey(ReportConstants.MULTISEGMENT_CRITERIA)){
				multiSegmentCriteria = hs.get(ReportConstants.MULTISEGMENT_CRITERIA);
			}
			
			startTime = ZABUtil.getTimeInLongFromDateFormStr(hs.get(ReportConstants.START_DATE), "yyyy-MM-dd");		// NO I18N
			if(startTime < createdTime){
				startTime = createdTime;
			}
			
			endTime = ZABUtil.getTimeInLongFromDateFormStr(hs.get(ReportConstants.END_DATE), "yyyy-MM-dd");		// NO I18N
			//Get the long value end date's last milli second
			endTime =  ZABUtil.getNthDayDateInLong(endTime, 1) - 1;
			
			ArrayList<AggregationBuilder> finalAggs = getGoalCountryReportAggregation();
			String portalName = ZABUtil.getPortalName();
			String indexName = ElasticSearchUtil.getIndexByPortal(portalName);
			BoolQueryBuilder query = queryBuilder(portalName,projectId,goalid,startTime,endTime,multiSegmentCriteria);
			
			SearchResponse visitorResponse = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.VISITOR_RAW_TYPE, 0, query, finalAggs);
			SearchResponse goalResponse = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.GOAL_RAW_TYPE, 0, query, finalAggs);
			greport  = readCountryGoalResponse(visitorResponse,goalResponse);
		
         	greport.setSuccess(Boolean.TRUE);
			
		} catch (Exception e) {
			
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			greport.setSuccess(Boolean.FALSE);
		}
		reports.add(greport);
		return reports;
	}
	
}
