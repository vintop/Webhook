//$Id$
package com.zoho.abtest.goal;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.MatchType;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABRequest;
import com.zoho.abtest.goal.GoalConstants.GoalStatus;
import com.zoho.abtest.goal.GoalConstants.GoalType;

public class GoalRequest extends ZABRequest{
	
	private static final Logger LOGGER = Logger.getLogger(GoalRequest.class.getName());
	
	@Override
	public void updateFromRequest(HashMap<String, String> map,
			HttpServletRequest request) {
		String linkName = (String)request.getAttribute(ZABConstants.LINKNAME);
		if(linkName!=null) {			
			map.put(ZABConstants.LINKNAME, linkName);
		}
		
	}
	
	private static Boolean validateUrlJSON(HashMap<String, String> map, ArrayList<String> fields, Boolean supportMultiCondition) {
		if(!map.containsKey(GoalConstants.URL)) {
			fields.add(GoalConstants.URL);
		} else {
			try {
				JSONArray array = new JSONArray(map.get(GoalConstants.URL));
				int size = array.length();
				if(size==0) {
					fields.add(GoalConstants.URL);
				} else {
					if(supportMultiCondition) {
						for(int i=0; i<size; i++) {
							JSONObject url = array.getJSONObject(0);
							if(!url.has(GoalConstants.VALUE)  || url.getString(GoalConstants.VALUE).trim().isEmpty()) {
								fields.add(GoalConstants.VALUE+" of "+GoalConstants.URL); //No I18N
							}
							
							if(!url.has(GoalConstants.MATCH_TYPE)) {
								fields.add(GoalConstants.MATCH_TYPE+" of "+GoalConstants.URL);//No I18N
							} else {
								Integer matchType = url.getInt(GoalConstants.MATCH_TYPE);
								MatchType type = MatchType.getMatchTypeById(matchType);
								if(type==null) {
									ZABRequest.updateError(map, ZABAction.getMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{GoalConstants.MATCH_TYPE+" of "+GoalConstants.URL})); //No I18N
								}
							}
							if(fields.size() > 0) {
								break;
							}
						}
					} else {
						JSONObject url = array.getJSONObject(0);
						if(!url.has(GoalConstants.VALUE) || url.getString(GoalConstants.VALUE).trim().isEmpty()) {
							fields.add(GoalConstants.VALUE+" of "+GoalConstants.URL); //No I18N
						}
						
						if(!url.has(GoalConstants.MATCH_TYPE)) {
							fields.add(GoalConstants.MATCH_TYPE+" of "+GoalConstants.URL);//No I18N
						}						
					}
				}
				
			} catch (JSONException | NumberFormatException e) {
				LOGGER.log(Level.SEVERE, e.getMessage(),e);
				ZABRequest.updateError(map, ZABAction.getMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{GoalConstants.URL}));
				return true;
			}
		}
		return false;
	}

	@Override
	public void specificValidation(HashMap<String, String> map,
			HttpServletRequest request) throws IOException, JSONException {
		//Mandatory name, type and things based on type, validate type number and match type mumber
		String httpMethod = ZABAction.getHTTPMethod(request).toString();
		ArrayList<String> fields = new ArrayList<String>();
		
		if(httpMethod.equalsIgnoreCase("POST")){
			if(!map.containsKey(GoalConstants.GOAL_NAME) || !map.containsKey(GoalConstants.GOAL_TYPE) || !map.containsKey(GoalConstants.PROJECT_LINKNAME)) {
				if(!map.containsKey(GoalConstants.GOAL_NAME)) {
					fields.add(GoalConstants.GOAL_NAME);
				}
				
				if(!map.containsKey(GoalConstants.GOAL_TYPE)) {
					fields.add(GoalConstants.GOAL_TYPE);
				}
				
				if(!map.containsKey(GoalConstants.PROJECT_LINKNAME)) {
					fields.add(GoalConstants.PROJECT_LINKNAME);
				}
				
				if(!map.containsKey(GoalConstants.EXPERIMENT_LINKNAME)) {
					fields.add(GoalConstants.EXPERIMENT_LINKNAME);
				}
				
			}
			
			if(map.containsKey(GoalConstants.GOAL_NAME) && map.get(GoalConstants.GOAL_NAME).trim().isEmpty()) {
				fields.add(GoalConstants.GOAL_NAME);
			}
			
			if(!fields.isEmpty()) {
				ZABRequest.updateError(map, ZABAction.getAppropriateMessage(ZABConstants.ErrorMessages.MANDATORY_FIELD_MISSING.getErrorString(),fields));
				return;
			}
		}
		
		if(httpMethod.equalsIgnoreCase("PUT")){
			if(!map.containsKey(ZABConstants.LINKNAME)) {
				if(!map.containsKey(ZABConstants.LINKNAME)){
					fields.add(ZABConstants.LINKNAME);
				}
			}
			
			if(map.containsKey(GoalConstants.GOAL_NAME) && map.get(GoalConstants.GOAL_NAME).trim().isEmpty()) {
				fields.add(GoalConstants.GOAL_NAME);
			}
			if(map.containsKey(GoalConstants.GOAL_STATUS)) {
				String goalstatus = map.get(GoalConstants.GOAL_STATUS);
				try {
					Integer goalStatusNum = Integer.parseInt(goalstatus);
					if(GoalStatus.getStatusByNumber(goalStatusNum)==null) {
						ZABRequest.updateError(map, ZABAction.getMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{GoalConstants.GOAL_STATUS}));
						return;
					}
				} catch (NumberFormatException e) {
					ZABRequest.updateError(map, ZABAction.getMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{GoalConstants.GOAL_STATUS}));
					return;
				}
			}
			
			if(!fields.isEmpty()) {
				ZABRequest.updateError(map, ZABAction.getAppropriateMessage(ZABConstants.ErrorMessages.MANDATORY_FIELD_MISSING.getErrorString(),fields));
				return;
			}
		}
		
		if(httpMethod.equalsIgnoreCase("POST") /*|| httpMethod.equalsIgnoreCase("PUT")*/) {
			if(!map.containsKey(GoalConstants.GOAL_TYPE)) {
				fields.add(GoalConstants.GOAL_TYPE);
			} else {
				try {
					Integer goalTypeNumber = Integer.parseInt(map.get(GoalConstants.GOAL_TYPE));
					validateByGoalType(goalTypeNumber, map, fields);
				} catch (NumberFormatException e ) {
					LOGGER.log(Level.SEVERE, e.getMessage(),e);
					ZABRequest.updateError(map, ZABAction.getMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{GoalConstants.GOAL_TYPE}));
					return;
				}
			}
			if(!fields.isEmpty()) {
				ZABRequest.updateError(map, ZABAction.getAppropriateMessage(ZABConstants.ErrorMessages.MANDATORY_FIELD_MISSING.getErrorString(),fields));
				return;
			}
		}
				
		
	}
	
	public static void validateByGoalType(Integer goalTypeNumber, HashMap<String, String> map, ArrayList<String> fields) {
		GoalType type = GoalType.getGoalTypeById(goalTypeNumber);
		if(type==null) {
			ZABRequest.updateError(map, ZABAction.getMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{GoalConstants.GOAL_TYPE}));
			return;
		}
		switch (type) {
			case CUSTOM_EVENT_GOAL:
				
				if(!map.containsKey(GoalConstants.CUSTOM_EVENT_LN) || map.get(GoalConstants.CUSTOM_EVENT_LN).trim().isEmpty()) {
					fields.add(GoalConstants.CUSTOM_EVENT_LN);
				}
				break;
			case ELEMENT_CLICK_GOAL:
				
				if(!map.containsKey(GoalConstants.ELEMENT_CSS_SELECTOR) || map.get(GoalConstants.ELEMENT_CSS_SELECTOR).trim().isEmpty()) {
					fields.add(GoalConstants.ELEMENT_CSS_SELECTOR);
				}
				break;
			case FORM_SUBMIT_GOAL:
				{
					
					if(validateUrlJSON(map, fields, false)) {return;}
				}
				break;
			case LINK_CLICK_GOAL:
				{
					
					if(validateUrlJSON(map, fields, false)) {return;}
				}
				break;
			case PAGE_VISIT_GOAL:
				{
					
					if(validateUrlJSON(map, fields, true)) {return;}
				}
				break;
			case TIME_SPENT_GOAL:
				{
					
					if(!map.containsKey(GoalConstants.TIME_THRESHOLD) || Long.parseLong(map.get(GoalConstants.TIME_THRESHOLD)) < 1) {
						fields.add(GoalConstants.TIME_THRESHOLD);
					}
				}
			break;
			default:
//				if(GoalConstants.DEFAULT_GOAL_TYPES.contains(type.getGoalTypeId())) {
//					if(httpMethod.equalsIgnoreCase("POST")) {
//						ZABRequest.updateError(map,  ZABAction.getMessage(GoalConstants.GOAL_CFAILURE_BY_TYPE, new String[]{type.getGoalTypeId()+""}));
//					} else if(httpMethod.equalsIgnoreCase("PUT")) {
//						ZABRequest.updateError(map,  ZABAction.getMessage(GoalConstants.GOAL_UFAILURE_BY_TYPE, new String[]{type.getGoalTypeId()+""}));
//					}
//				}
				break;
		}
		if(!fields.isEmpty()) {
			ZABRequest.updateError(map, ZABAction.getAppropriateMessage(ZABConstants.ErrorMessages.MANDATORY_FIELD_MISSING.getErrorString(),fields));
			return;
		}
	}

}
