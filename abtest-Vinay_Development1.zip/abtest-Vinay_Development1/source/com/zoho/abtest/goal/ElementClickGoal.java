//$Id$
package com.zoho.abtest.goal;

import org.apache.commons.lang3.StringEscapeUtils;

public class ElementClickGoal extends Goal{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String elementCssSelector;

	public String getElementCssSelector() {
		if(elementCssSelector!=null) {
			return StringEscapeUtils.unescapeHtml4(elementCssSelector);
		}
		return elementCssSelector;
	}

	public void setElementCssSelector(String elementCssSelector) {
		this.elementCssSelector = elementCssSelector;
	}
}
