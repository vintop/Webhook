//$Id$
package com.zoho.abtest.goal;

public class FormSubmitGoal extends Goal{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String submitUrl;
	
	private Integer matchType;

	public String getSubmitUrl() {
		return submitUrl;
	}

	public void setSubmitUrl(String submitUrl) {
		this.submitUrl = submitUrl;
	}

	public Integer getMatchType() {
		return matchType;
	}

	public void setMatchType(Integer matchType) {
		this.matchType = matchType;
	}
	
	
}
