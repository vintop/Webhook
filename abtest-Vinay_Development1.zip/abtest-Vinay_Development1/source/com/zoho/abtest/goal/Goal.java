//$Id$
package com.zoho.abtest.goal;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transaction;
import javax.transaction.TransactionManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.iam.IAMUtil;
import com.adventnet.persistence.DataAccess;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.persistence.WritableDataObject;
import com.zoho.abtest.APP_USER;
import com.zoho.abtest.PROJECT_GOAL;
import com.zoho.abtest.TIME_SPENT_GOAL;
import com.zoho.abtest.CUSTOM_EVENT_GOAL;
import com.zoho.abtest.ELEMENT_CLICK_GOAL;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.EXPERIMENT_GOAL;
import com.zoho.abtest.FORM_SUBMIT_GOAL;
import com.zoho.abtest.GOAL;
import com.zoho.abtest.LINK_CLICK_GOAL;
import com.zoho.abtest.PAGE_VISIT_GOAL;
import com.zoho.abtest.adminconsole.AdminConsole;
import com.zoho.abtest.adminconsole.AdminConsoleConstants;
import com.zoho.abtest.adminconsole.AdminConsoleConstants.AcOperationType;
import com.zoho.abtest.adminconsole.AdminConsoleWrapper;
import com.zoho.abtest.common.MatchType;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.customevent.CustomEvent;
import com.zoho.abtest.customevent.CustomEventConstants;
import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.eventactivity.EventActivityConstants;
import com.zoho.abtest.eventactivity.EventActivityWrapper;
import com.zoho.abtest.eventactivity.EventModuleDetail;
import com.zoho.abtest.eventactivity.EventActivityConstants.Module;
import com.zoho.abtest.exception.ResourceNotFoundException;
import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentStatus;
import com.zoho.abtest.goal.GoalConstants.GoalStatus;
import com.zoho.abtest.goal.GoalConstants.GoalType;
import com.zoho.abtest.license.PortalLicenseMapping;
import com.zoho.abtest.listener.ZABNotifier;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.project.ProjectConstants;
import com.zoho.abtest.project.ProjectTreeEventConstants;
import com.zoho.abtest.project.ProjectTreeEventWrapper;
import com.zoho.abtest.project.ProjectTreeEventConstants.OperationType;
import com.zoho.abtest.projectgoals.ProjectGoal;
import com.zoho.abtest.utility.ZABUtil;

public class Goal extends ZABModel{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = Logger.getLogger(Goal.class.getName());

	private Long goalId;
	
	private Long projectId;
	
	private String projectLinkname;
	
	private String goalName;
	
	private String goalLinkname;
	
	private String goalDescription;
	
	private Integer goalTypeTag;
	
	private Integer goalStatus;
	
	private Long actualEndTime;
	
	private Boolean isPrimaryGoal;
	
	private Long createdTime;
	
	private Long createdBy;
	
	private Boolean isProjectLevel;
	
	private String goalUrl;
	

	private String includeUrl;
	
	private String excludeUrl;
	
	private Long uniqueVisitors;
	private Long uniqueGoalAchievedCount;
	private Long avgTimeToAchieveGoal;
	private Double goalConversionRate;
	
	private Long avgTimeSpentOnPage;
	
	
	public Integer getGoalStatus() {
		return goalStatus;
	}

	public void setGoalStatus(Integer goalStatus) {
		this.goalStatus = goalStatus;
	}

	public Long getActualEndTime() {
		return actualEndTime;
	}

	public void setActualEndTime(Long actualEndTime) {
		this.actualEndTime = actualEndTime;
	}

	public Long getAvgTimeSpentOnPage() {
		return avgTimeSpentOnPage;
	}

	public void setAvgTimeSpentOnPage(Long avgTimeSpentOnPage) {
		this.avgTimeSpentOnPage = avgTimeSpentOnPage;
	}
	
	public Double getGoalConversionRate() {
		return goalConversionRate;
	}

	public void setGoalConversionRate(Double goalConversionRate) {
		this.goalConversionRate = goalConversionRate;
	}

	public String getGoalUrl() {
		return goalUrl;
	}

	public void setGoalUrl(String goalUrl) {
		this.goalUrl = goalUrl;
	}

	public String getIncludeUrl() {
		return includeUrl;
	}

	public void setIncludeUrl(String includeUrl) {
		this.includeUrl = includeUrl;
	}

	public String getExcludeUrl() {
		return excludeUrl;
	}

	public void setExcludeUrl(String excludeUrl) {
		this.excludeUrl = excludeUrl;
	}

	
	
	public Long getUniqueVisitors() {
		return uniqueVisitors;
	}

	public void setUniqueVisitors(Long uniqueVisitors) {
		this.uniqueVisitors = uniqueVisitors;
	}

	public Long getUniqueGoalAchievedCount() {
		return uniqueGoalAchievedCount;
	}

	public void setUniqueGoalAchievedCount(Long uniqueGoalAchievedCount) {
		this.uniqueGoalAchievedCount = uniqueGoalAchievedCount;
	}

	public Long getAvgTimeToAchieveGoal() {
		return avgTimeToAchieveGoal;
	}

	public void setAvgTimeToAchieveGoal(Long avgTimeToAchieveGoal) {
		this.avgTimeToAchieveGoal = avgTimeToAchieveGoal;

	}

	public Long getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Long createdTime) {
		this.createdTime = createdTime;
	}

	public Long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}

	public Boolean getIsProjectLevel() {
		return isProjectLevel;
	}

	public void setIsProjectLevel(Boolean isProjectLevel) {
		this.isProjectLevel = isProjectLevel;
	}

	public Boolean getIsPrimaryGoal() {
		return isPrimaryGoal;
	}

	public void setIsPrimaryGoal(Boolean isPrimaryGoal) {
		this.isPrimaryGoal = isPrimaryGoal;
	}

	private ArrayList<Experiment> experiments = new ArrayList<Experiment>();

	public ArrayList<Experiment> getExperiments() {
		return experiments;
	}

	public void setExperiments(ArrayList<Experiment> experiments) {
		this.experiments = experiments;
	}

	public String getGoalLinkname() {
		return goalLinkname;
	}

	public void setGoalLinkname(String goalLinkname) {
		this.goalLinkname = goalLinkname;
	}

	public Long getGoalId() {
		return goalId;
	}

	public void setGoalId(Long goalId) {
		this.goalId = goalId;
	}

	public Long getProjectId() {
		return projectId;
	}

	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}
	
	public String getProjectLinkname(){
		return projectLinkname;
	}
	
	public void setProjectLinkname(String projectLinkname){
		this.projectLinkname = projectLinkname;
	}
	
	public String getGoalName() {
		return goalName;
	}

	public void setGoalName(String goalName) {
		this.goalName = goalName;
	}

	public String getGoalDescription() {
		return goalDescription;
	}

	public void setGoalDescription(String goalDescription) {
		this.goalDescription = goalDescription;
	}

	public Integer getGoalTypeTag() {
		return goalTypeTag;
	}

	public void setGoalTypeTag(Integer goalTypeTag) {
		this.goalTypeTag = goalTypeTag;
	}

	public static Goal getGoalFromRow(Row row) {
		Goal goal = new Goal();
		goal.setBasicGoalData(row);
		return goal;
	}
	
	public Boolean isInvolvedRunningExperiments() {
		Boolean flag = false;
		Criteria c = new Criteria(new Column(EXPERIMENT_GOAL.TABLE, EXPERIMENT_GOAL.GOAL_ID), this.getGoalId(), QueryConstants.EQUAL);
		Criteria c2 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_STATUS), ExperimentStatus.RUNNING.getStatusCode(), QueryConstants.EQUAL);
		Join join1=new Join(EXPERIMENT_GOAL.TABLE,EXPERIMENT.TABLE,new String[]{EXPERIMENT_GOAL.EXPERIMENT_ID},new String[]{EXPERIMENT.EXPERIMENT_ID},Join.INNER_JOIN);
		try {
			DataObject dobj = getRow(EXPERIMENT_GOAL.TABLE, c.and(c2), join1);
			flag = dobj.containsTable(EXPERIMENT_GOAL.TABLE);
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Exception occured:", e);
		}
		return flag;
	}
	
	public void setBasicGoalData(Row row) {
		this.setGoalId((Long)row.get(GOAL.GOAL_ID));
		this.setGoalDescription((String)row.get(GOAL.GOAL_DESCRIPTION));
		this.setGoalName((String)row.get(GOAL.GOAL_NAME));
		this.setGoalTypeTag((Integer)row.get(GOAL.GOAL_TYPE_FLAG));
		this.setProjectId((Long)row.get(GOAL.PROJECT_ID));
		Project project = Project.getProjectByProjectId(this.projectId);
		this.setProjectLinkname(project.getProjectLinkName());		
		this.setIsProjectLevel((Boolean)row.get(GOAL.IS_PROJECT_LEVEL));		
		this.setGoalLinkname((String)row.get(GOAL.GOAL_LINK_NAME));
		this.setCreatedTime((Long)row.get(GOAL.CREATED_TIME));
		this.setGoalStatus((Integer)row.get(GOAL.GOAL_STATUS));
		this.setActualEndTime((Long)row.get(GOAL.ACTUAL_END_TIME));
		this.setSuccess(Boolean.TRUE);
	}
	
	public static boolean isExperimentGoal(Long goalId) {
		boolean flag = false;
		try {
			Criteria c = new Criteria(new Column(EXPERIMENT_GOAL.TABLE, EXPERIMENT_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
			flag = resourceExists(EXPERIMENT_GOAL.TABLE, c);
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		return flag;
	}
	
	public static Goal addDuplicateGoalRow(Long goalId) throws Exception {
		Criteria c1 = new Criteria(new Column(GOAL.TABLE, GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
		DataObject wdobj = new WritableDataObject();
		DataObject dobj = getPersonality(GoalConstants.GOAL_PERSONALITY_NAME, c1);
		Goal goal = null;
		if(dobj.containsTable(GOAL.TABLE)) {
			Iterator itRow = dobj.getRows(GOAL.TABLE);
			if(itRow.hasNext()) {
				Row row = (Row)itRow.next();
				Row dgrow = new Row(GOAL.TABLE);
				String displayName = (String)row.get(GOAL.GOAL_NAME);
				String linkname = generateLinkName(GOAL.TABLE, GOAL.GOAL_LINK_NAME, null, null, displayName);
				dgrow.set(GOAL.GOAL_NAME, displayName);
				dgrow.set(GOAL.GOAL_LINK_NAME, linkname);
				dgrow.set(GOAL.GOAL_TYPE_FLAG, (Integer)row.get(GOAL.GOAL_TYPE_FLAG));
				dgrow.set(GOAL.GOAL_DESCRIPTION, (String)row.get(GOAL.GOAL_DESCRIPTION));
				dgrow.set(GOAL.PROJECT_ID, (Long)row.get(GOAL.PROJECT_ID));
				createResource(dgrow);
				Long dgid = (Long)dgrow.get(GOAL.GOAL_ID);
				
				if(dobj.containsTable(PAGE_VISIT_GOAL.TABLE)) {
					Criteria c = new Criteria(new Column(PAGE_VISIT_GOAL.TABLE, PAGE_VISIT_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
					Iterator it = dobj.getRows(PAGE_VISIT_GOAL.TABLE, c);
					while(it.hasNext()) {
						Row grow = (Row)it.next();
						Row duprow = new Row(PAGE_VISIT_GOAL.TABLE);
						duprow.set(PAGE_VISIT_GOAL.PAGE_URL, (String)grow.get(PAGE_VISIT_GOAL.PAGE_URL));
						duprow.set(PAGE_VISIT_GOAL.MATCH_TYPE, (Integer)grow.get(PAGE_VISIT_GOAL.MATCH_TYPE));
						duprow.set(PAGE_VISIT_GOAL.GOAL_ID, dgid);							
						wdobj.addRow(duprow);
					}
				}
				if(dobj.containsTable(LINK_CLICK_GOAL.TABLE)) {
					Criteria c = new Criteria(new Column(LINK_CLICK_GOAL.TABLE, LINK_CLICK_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
					Row grow = dobj.getRow(LINK_CLICK_GOAL.TABLE, c);
					if(grow!=null) {					
						Row duprow = new Row(LINK_CLICK_GOAL.TABLE);
						duprow.set(LINK_CLICK_GOAL.LINK_URL, (String)grow.get(LINK_CLICK_GOAL.LINK_URL));
						duprow.set(LINK_CLICK_GOAL.MATCH_TYPE, (Integer)grow.get(LINK_CLICK_GOAL.MATCH_TYPE));
						duprow.set(LINK_CLICK_GOAL.GOAL_ID, dgid);							
						wdobj.addRow(duprow);
					}
				}
				if(dobj.containsTable(FORM_SUBMIT_GOAL.TABLE)) {
					Criteria c = new Criteria(new Column(FORM_SUBMIT_GOAL.TABLE, FORM_SUBMIT_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
					Row grow = dobj.getRow(FORM_SUBMIT_GOAL.TABLE, c);
					if(grow!=null) {					
						Row duprow = new Row(FORM_SUBMIT_GOAL.TABLE);
						duprow.set(FORM_SUBMIT_GOAL.SUBMIT_URL, (String)grow.get(FORM_SUBMIT_GOAL.SUBMIT_URL));
						duprow.set(FORM_SUBMIT_GOAL.MATCH_TYPE, (Integer)grow.get(FORM_SUBMIT_GOAL.MATCH_TYPE));
						duprow.set(FORM_SUBMIT_GOAL.GOAL_ID, dgid);							
						wdobj.addRow(duprow);
					}
				}
				if(dobj.containsTable(CUSTOM_EVENT_GOAL.TABLE)) {
					Criteria c = new Criteria(new Column(CUSTOM_EVENT_GOAL.TABLE, CUSTOM_EVENT_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
					Row grow = dobj.getRow(CUSTOM_EVENT_GOAL.TABLE, c);
					if(grow!=null) {
						Row duprow = new Row(CUSTOM_EVENT_GOAL.TABLE);
						duprow.set(CUSTOM_EVENT_GOAL.EVENT_ID, (Long)grow.get(CUSTOM_EVENT_GOAL.EVENT_ID));
						duprow.set(CUSTOM_EVENT_GOAL.GOAL_ID, dgid);				
						duprow.set(CUSTOM_EVENT_GOAL.CUSTOM_EVENT_NAME, grow.get(CUSTOM_EVENT_GOAL.CUSTOM_EVENT_NAME));						
						wdobj.addRow(duprow);
					}
				}
				if(dobj.containsTable(ELEMENT_CLICK_GOAL.TABLE)) {
					Criteria c = new Criteria(new Column(ELEMENT_CLICK_GOAL.TABLE, ELEMENT_CLICK_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
					Row grow = dobj.getRow(ELEMENT_CLICK_GOAL.TABLE, c);
					if(grow!=null) {
						Row duprow = new Row(ELEMENT_CLICK_GOAL.TABLE);
						duprow.set(ELEMENT_CLICK_GOAL.ELEMENT_CSS_SELECTOR, (String)grow.get(ELEMENT_CLICK_GOAL.ELEMENT_CSS_SELECTOR));
						duprow.set(ELEMENT_CLICK_GOAL.GOAL_ID, dgid);							
						wdobj.addRow(duprow);
					}
				}
				if(dobj.containsTable(TIME_SPENT_GOAL.TABLE)) {
					Criteria c = new Criteria(new Column(TIME_SPENT_GOAL.TABLE, TIME_SPENT_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
					Row grow = dobj.getRow(TIME_SPENT_GOAL.TABLE, c);
					if(grow!=null) {
						Row duprow = new Row(TIME_SPENT_GOAL.TABLE);
						duprow.set(TIME_SPENT_GOAL.TIME_THRESHOLD, (Long)grow.get(TIME_SPENT_GOAL.TIME_THRESHOLD));
						duprow.set(TIME_SPENT_GOAL.GOAL_ID, dgid);							
						wdobj.addRow(duprow);
					}
				}
				updateDataObject(wdobj);
				goal = getGoalFromRow(dgrow);
			}
		}
		return goal;
	}
	
	public static ArrayList<Goal> getGoalFromDObj(DataObject dobj) throws DataAccessException {
		ArrayList<Goal> goals = new ArrayList<Goal>();
		if(dobj.containsTable(GOAL.TABLE)) {
			Iterator itRow = dobj.getRows(GOAL.TABLE);
			while(itRow.hasNext()) {
				Row row = (Row)itRow.next();
				Long goalId = (Long)row.get(GOAL.GOAL_ID);
				Integer goalType = (Integer)row.get(GOAL.GOAL_TYPE_FLAG);
				if(goalType!=null &&( goalType.equals(GoalConstants.GoalType.ENGAGEMENT_GOAL.getGoalTypeId()) || goalType.equals(GoalConstants.GoalType.REVENUE_GOAL.getGoalTypeId()) )) {
					Goal goal = new Goal();
					goal.setBasicGoalData(row);
					goals.add(goal);
				}
				
				if(dobj.containsTable(PAGE_VISIT_GOAL.TABLE)) {
					Criteria c = new Criteria(new Column(PAGE_VISIT_GOAL.TABLE, PAGE_VISIT_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
					Iterator it = dobj.getRows(PAGE_VISIT_GOAL.TABLE, c);
					if(it.hasNext()) {
						PageVisitGoal pageVisitGoal = new PageVisitGoal();
						pageVisitGoal.setBasicGoalData(row);						
						while(it.hasNext()) {
							Row rw = (Row)it.next();
							PageVisitGoal goalUrl = new PageVisitGoal();
							goalUrl.setUrl((String)rw.get(PAGE_VISIT_GOAL.PAGE_URL));
							goalUrl.setMatchType((Integer)rw.get(PAGE_VISIT_GOAL.MATCH_TYPE));
							pageVisitGoal.getPageVisitUrls().add(goalUrl);
						}
						goals.add(pageVisitGoal);
						continue;
					}
				}
				if(dobj.containsTable(LINK_CLICK_GOAL.TABLE)) {
					Criteria c = new Criteria(new Column(LINK_CLICK_GOAL.TABLE, LINK_CLICK_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
					Row rw = dobj.getRow(LINK_CLICK_GOAL.TABLE, c);
					if(rw!=null) {					
						LinkClickGoal linkClickGoal = new LinkClickGoal();
						linkClickGoal.setBasicGoalData(row);
						linkClickGoal.setLinkUrl((String)rw.get(LINK_CLICK_GOAL.LINK_URL));
						linkClickGoal.setMatchType((Integer)rw.get(LINK_CLICK_GOAL.MATCH_TYPE));
						goals.add(linkClickGoal);
						continue;
					}
				}
				if(dobj.containsTable(FORM_SUBMIT_GOAL.TABLE)) {
					Criteria c = new Criteria(new Column(FORM_SUBMIT_GOAL.TABLE, FORM_SUBMIT_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
					Row rw = dobj.getRow(FORM_SUBMIT_GOAL.TABLE, c);
					if(rw!=null) {					
						FormSubmitGoal formSubmitGoal = new FormSubmitGoal();
						formSubmitGoal.setBasicGoalData(row);
						formSubmitGoal.setSubmitUrl((String)rw.get(FORM_SUBMIT_GOAL.SUBMIT_URL));
						formSubmitGoal.setMatchType((Integer)rw.get(FORM_SUBMIT_GOAL.MATCH_TYPE));
						goals.add(formSubmitGoal);
						continue;
					}
				}
				if(dobj.containsTable(CUSTOM_EVENT_GOAL.TABLE)) {
					Criteria c = new Criteria(new Column(CUSTOM_EVENT_GOAL.TABLE, CUSTOM_EVENT_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
					Row rw = dobj.getRow(CUSTOM_EVENT_GOAL.TABLE, c);
					if(rw!=null) {
						CustomEventGoal customEventGoal = new CustomEventGoal();
						customEventGoal.setBasicGoalData(row);
						Criteria c1 = new Criteria(new Column(CUSTOM_EVENT_GOAL.TABLE, CUSTOM_EVENT_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
						Row cerow = dobj.getRow(CUSTOM_EVENT_GOAL.TABLE, c1);
					
						Long eventId = (Long) cerow.get(CUSTOM_EVENT_GOAL.EVENT_ID);
						CustomEvent event = CustomEvent.getCustomEventById(eventId);
						
						customEventGoal.setEventId(event.getCustomEventId());
						customEventGoal.setEventLinkname(event.getCustomEventLinkName());
						customEventGoal.setEventName(event.getCustomEventName());
						goals.add(customEventGoal);
						continue;
					}
				}
				if(dobj.containsTable(ELEMENT_CLICK_GOAL.TABLE)) {
					Criteria c = new Criteria(new Column(ELEMENT_CLICK_GOAL.TABLE, ELEMENT_CLICK_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
					Row rw = dobj.getRow(ELEMENT_CLICK_GOAL.TABLE, c);
					if(rw!=null) {
						ElementClickGoal elementClickGoal = new ElementClickGoal();
						elementClickGoal.setBasicGoalData(row);
						elementClickGoal.setElementCssSelector((String)rw.get(ELEMENT_CLICK_GOAL.ELEMENT_CSS_SELECTOR));					
						goals.add(elementClickGoal);
						continue;
					}
				}
				if(dobj.containsTable(TIME_SPENT_GOAL.TABLE)) {
					Criteria c = new Criteria(new Column(TIME_SPENT_GOAL.TABLE, TIME_SPENT_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
					Row rw = dobj.getRow(TIME_SPENT_GOAL.TABLE, c);
					if(rw!=null) {
						TimeSpentGoal timespentgoal = new TimeSpentGoal();
						timespentgoal.setBasicGoalData(row);
						timespentgoal.setTimeThreshold((Long)rw.get(TIME_SPENT_GOAL.TIME_THRESHOLD));					
						goals.add(timespentgoal);
						continue;
					}
				}
			}
			}
		return goals;
	}
	
	private static void deleteSubGoal(String tableName, String columnName, Long goalId) throws Exception {
		Criteria c = new Criteria(new Column(tableName, columnName), goalId, QueryConstants.EQUAL);
		deleteResource(c);
	}
	
	public static void deleteOtherTypeGoals(Goal goal) throws Exception {
		if(!(goal instanceof PageVisitGoal)) {
			deleteSubGoal(PAGE_VISIT_GOAL.TABLE, PAGE_VISIT_GOAL.GOAL_ID, goal.getGoalId());
		} 
		if(!(goal instanceof CustomEventGoal)) {
			deleteSubGoal(CUSTOM_EVENT_GOAL.TABLE, CUSTOM_EVENT_GOAL.GOAL_ID, goal.getGoalId());
		}
		if(!(goal instanceof ElementClickGoal)) {
			deleteSubGoal(ELEMENT_CLICK_GOAL.TABLE, ELEMENT_CLICK_GOAL.GOAL_ID, goal.getGoalId());
		}
		if(!(goal instanceof FormSubmitGoal)) {
			deleteSubGoal(FORM_SUBMIT_GOAL.TABLE, FORM_SUBMIT_GOAL.GOAL_ID, goal.getGoalId());
		}
		if(!(goal instanceof LinkClickGoal)) {
			deleteSubGoal(LINK_CLICK_GOAL.TABLE, LINK_CLICK_GOAL.GOAL_ID, goal.getGoalId());
		}
		if(!(goal instanceof TimeSpentGoal)) {
			deleteSubGoal(TIME_SPENT_GOAL.TABLE, LINK_CLICK_GOAL.GOAL_ID, goal.getGoalId());
		}
	}
	
	private static void upsertRow(DataObject dobj, Row row) throws Exception{
		if(dobj.containsTable(row.getTableName())) {
			dobj.updateRow(row);
		} else {
			dobj.addRow(row);
		}
	}
	
	public static Goal updateGoal(HashMap<String, String> hs, Boolean validateGoalTypeHs) {
		Goal goal = new Goal();
		TransactionManager mgr = DataAccess.getTransactionManager();
		try {
			hs.remove(GoalConstants.GOAL_ACTUAL_END_TIME);
			HashMap<String, String> oldValues = null;
			mgr.begin();
			GoalType type = null;
			String linkname = hs.get(ZABConstants.LINKNAME);
			Boolean isprojectLevel= Boolean.FALSE;
			Criteria c = new Criteria(new Column(GOAL.TABLE, GOAL.GOAL_LINK_NAME), linkname, QueryConstants.EQUAL);
			Row goalRow = null;
			Long goalId = null;
			Long projectId = null;
			DataObject dob = getRow(GOAL.TABLE, c);			
			if(dob.containsTable(GOAL.TABLE)) {
				goalRow = dob.getFirstRow(GOAL.TABLE);
				goalId = (Long)goalRow.get(GOAL.GOAL_ID);
				projectId = (Long)goalRow.get(GOAL.PROJECT_ID);
				isprojectLevel = (Boolean)goalRow.get(GOAL.IS_PROJECT_LEVEL);
				Integer goalType = (Integer)goalRow.get(GOAL.GOAL_TYPE_FLAG);
				type = GoalType.getGoalTypeById(goalType);
				String oldName = (String)goalRow.get(GOAL.GOAL_NAME);
				if(validateGoalTypeHs){
					GoalRequest.validateByGoalType(goalType, hs, new ArrayList<String>());
					if(hs.containsKey(ZABConstants.SUCCESS) && !ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
						goal = new Goal();
						goal.setSuccess(Boolean.FALSE);
						goal.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
						return goal;
					}
				}
				if(isprojectLevel){
					Goal oldgoal = ProjectGoal.getProjectGoalsForGoal(linkname,null,null,null).get(0);
					oldValues = generateHashMapFromGoalObj(oldgoal , hs);
				}else{
					hs.remove(GoalConstants.GOAL_STATUS);
				}
				//Since there is no sharing or goals among experiments in project level
				//uniqueness is checked in project level
				//Is sharing goal is allowed in future, remove the below validation and make validation for project level
				if(hs.containsKey(GoalConstants.GOAL_NAME)) {
					String name = hs.get(GoalConstants.GOAL_NAME);
					Boolean isProjectLevel = (Boolean) goalRow.get(GOAL.IS_PROJECT_LEVEL);
					if(isProjectLevel){
						if(goalWithNameAlreadyExistsInProject(name, oldName, projectId)) {
							throw new ZABException(ZABAction.getMessage(GoalConstants.GOAL_NAME_EXISTS, new String[]{name}));
						}
					}else{
						Long experimentId = ExperimentGoal.getFirstExperimentIdForGoal(goalId);
						if(goalWithNameAlreadyExists(name, oldName, experimentId)) {
							throw new ZABException(ZABAction.getMessage(GoalConstants.GOAL_NAME_EXISTS, new String[]{name}));
						}
					}

				}
				
				if(hs.containsKey(GoalConstants.GOAL_STATUS)){
					String pausedcode = GoalStatus.PAUSED.getStatusCode().toString();
					String runningcode = GoalStatus.RUNNING.getStatusCode().toString();
					if(hs.get(GoalConstants.GOAL_STATUS).equals(pausedcode) && oldValues.get(GoalConstants.GOAL_STATUS).equals(runningcode)){
						hs.put(GoalConstants.GOAL_ACTUAL_END_TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
					}else if(hs.get(GoalConstants.GOAL_STATUS).equals(runningcode) && oldValues.get(GoalConstants.GOAL_STATUS).equals(pausedcode)){
						Boolean licenseStatus = PortalLicenseMapping.getLicenseStatus();
						if(!licenseStatus){
							throw new ZABException(ZABAction.getMessage(ExperimentConstants.LICENSE_EXPIRE_GOAL_PUBLISH_ERROR));
						}
					}

				}

			}

			updateRow(GoalConstants.GOAL_TABLE, GOAL.TABLE, hs, c, GoalConstants.API_MODULE);
			//TODO: Refactor below later
			dob = getRow(GOAL.TABLE, c);
			goalRow = dob.getFirstRow(GOAL.TABLE);
			if(validateGoalTypeHs)
			{
				switch(type)  {

				case PAGE_VISIT_GOAL:
				{
					//drop all and create new
					JSONArray urlArray = new JSONArray(hs.get(GoalConstants.URL));
					int size = urlArray.length();
					if(size > 0) {
						deleteSubGoal(PAGE_VISIT_GOAL.TABLE, PAGE_VISIT_GOAL.GOAL_ID, goalId);
						DataObject wdobj = new WritableDataObject();
						PageVisitGoal pvGoal = new PageVisitGoal();
						for(int i=0; i<size; i++) {
							JSONObject url = urlArray.getJSONObject(i);
							Row row = new Row(PAGE_VISIT_GOAL.TABLE);
							row.set(PAGE_VISIT_GOAL.GOAL_ID, goalId);
							row.set(PAGE_VISIT_GOAL.PAGE_URL, url.get(GoalConstants.VALUE));
							row.set(PAGE_VISIT_GOAL.MATCH_TYPE, url.get(GoalConstants.MATCH_TYPE));
							wdobj.addRow(row);
							PageVisitGoal purl = new PageVisitGoal();
							purl.setUrl(url.getString(GoalConstants.VALUE));
							purl.setMatchType(url.getInt(GoalConstants.MATCH_TYPE));
							pvGoal.getPageVisitUrls().add(purl);
						}
						updateDataObject(wdobj);
						pvGoal.setBasicGoalData(goalRow);
						goal = pvGoal;
					}

					break;
				}
				case CUSTOM_EVENT_GOAL:
				{

					//check if exists and update
					String eventLinkname = hs.get(GoalConstants.CUSTOM_EVENT_LN);
					Criteria c1 = new Criteria(new Column(CUSTOM_EVENT_GOAL.TABLE, CUSTOM_EVENT_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
					DataObject dobj =  getRow(CUSTOM_EVENT_GOAL.TABLE, c1);
					Row row = null;
					if(dobj.containsTable(CUSTOM_EVENT_GOAL.TABLE)) {
						row = dobj.getFirstRow(CUSTOM_EVENT_GOAL.TABLE);
					} else {
						row = new Row(CUSTOM_EVENT_GOAL.TABLE);
						dobj = new WritableDataObject();
					}

					CustomEvent ce = CustomEvent.getCustomEventByLinkname(eventLinkname, projectId);
					if(ce == null) {
						throw new ZABException(ZABAction.getMessage(ZABConstants.ErrorMessages.RESOURCE_NOT_FOUND.getErrorString(), new String[]{ZABAction.getMessage(CustomEventConstants.API_MODULE)}));	
					}

					row.set(CUSTOM_EVENT_GOAL.GOAL_ID, goalId);
					row.set(CUSTOM_EVENT_GOAL.EVENT_ID, ce.getCustomEventId());
					//				
					upsertRow(dobj, row);
					updateDataObject(dobj);
					CustomEventGoal ceGoal = new CustomEventGoal();
					ceGoal.setBasicGoalData(goalRow);
					ceGoal.setEventLinkname(eventLinkname);
					goal = ceGoal;

					break;
				}
				case ELEMENT_CLICK_GOAL:
				{

					//check if exists and update
					String cssSelector = hs.get(GoalConstants.ELEMENT_CSS_SELECTOR);
					Criteria c1 = new Criteria(new Column(ELEMENT_CLICK_GOAL.TABLE, ELEMENT_CLICK_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
					DataObject dobj =  getRow(ELEMENT_CLICK_GOAL.TABLE, c1);
					Row row = null;
					if(dobj.containsTable(ELEMENT_CLICK_GOAL.TABLE)) {
						row = dobj.getFirstRow(ELEMENT_CLICK_GOAL.TABLE);
					} else {
						row = new Row(ELEMENT_CLICK_GOAL.TABLE);
						dobj = new WritableDataObject();
					}
					row.set(ELEMENT_CLICK_GOAL.GOAL_ID, goalId);
					row.set(ELEMENT_CLICK_GOAL.ELEMENT_CSS_SELECTOR, cssSelector);
					//				dobj.updateRow(row);
					upsertRow(dobj, row);
					updateDataObject(dobj);
					ElementClickGoal ceGoal = new ElementClickGoal();
					ceGoal.setBasicGoalData(goalRow);
					ceGoal.setElementCssSelector(cssSelector);
					goal = ceGoal;

					break;
				}
				case FORM_SUBMIT_GOAL:
				{
					// check if exists and update
					JSONArray urlArray = new JSONArray(hs.get(GoalConstants.URL));
					int size = urlArray.length();
					if(size > 0) {
						JSONObject url = urlArray.getJSONObject(0);
						Criteria c1 = new Criteria(new Column(FORM_SUBMIT_GOAL.TABLE, FORM_SUBMIT_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
						DataObject wdobj =  getRow(FORM_SUBMIT_GOAL.TABLE, c1);
						Row row = null;
						if(wdobj.containsTable(FORM_SUBMIT_GOAL.TABLE)) {
							row = wdobj.getFirstRow(FORM_SUBMIT_GOAL.TABLE);
						} else {
							row = new Row(FORM_SUBMIT_GOAL.TABLE);
							wdobj = new WritableDataObject();
						}
						row.set(FORM_SUBMIT_GOAL.GOAL_ID, goalId);
						row.set(FORM_SUBMIT_GOAL.SUBMIT_URL, url.get(GoalConstants.VALUE));
						row.set(FORM_SUBMIT_GOAL.MATCH_TYPE, url.get(GoalConstants.MATCH_TYPE));
						//					wdobj.updateBlindly(row);
						upsertRow(wdobj, row);
						updateDataObject(wdobj);
						FormSubmitGoal leGoal = new FormSubmitGoal();
						leGoal.setBasicGoalData(goalRow);
						leGoal.setSubmitUrl(url.getString(GoalConstants.VALUE));
						leGoal.setMatchType(url.getInt(GoalConstants.MATCH_TYPE));
						goal = leGoal;
					}

					break;
				}
				case LINK_CLICK_GOAL:
				{	

					JSONArray urlArray = new JSONArray(hs.get(GoalConstants.URL));
					int size = urlArray.length();
					if(size > 0) {
						JSONObject url = urlArray.getJSONObject(0);
						Criteria c1 = new Criteria(new Column(LINK_CLICK_GOAL.TABLE, LINK_CLICK_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
						DataObject wdobj =  getRow(LINK_CLICK_GOAL.TABLE, c1);
						Row row = null;
						if(wdobj.containsTable(LINK_CLICK_GOAL.TABLE)) {
							row = wdobj.getFirstRow(LINK_CLICK_GOAL.TABLE);
						} else {
							row = new Row(LINK_CLICK_GOAL.TABLE);
							wdobj = new WritableDataObject();
						}
						row.set(LINK_CLICK_GOAL.GOAL_ID, goalId);
						row.set(LINK_CLICK_GOAL.LINK_URL, url.get(GoalConstants.VALUE));
						row.set(LINK_CLICK_GOAL.MATCH_TYPE, url.get(GoalConstants.MATCH_TYPE));
						//					wdobj.updateRow(row);
						upsertRow(wdobj, row);
						updateDataObject(wdobj);
						LinkClickGoal leGoal = new LinkClickGoal();
						leGoal.setBasicGoalData(goalRow);
						leGoal.setLinkUrl(url.getString(GoalConstants.VALUE));
						leGoal.setMatchType(url.getInt(GoalConstants.MATCH_TYPE));
						goal = leGoal;
					}

					break;
				}
				case TIME_SPENT_GOAL:

					//check if exists and update
					String timeThreshold = hs.get(GoalConstants.TIME_THRESHOLD);
					Criteria c1 = new Criteria(new Column(TIME_SPENT_GOAL.TABLE, TIME_SPENT_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
					DataObject dobj =  getRow(TIME_SPENT_GOAL.TABLE, c1);
					Row row = null;
					if(dobj.containsTable(TIME_SPENT_GOAL.TABLE)) {
						row = dobj.getFirstRow(TIME_SPENT_GOAL.TABLE);
					} else {
						row = new Row(TIME_SPENT_GOAL.TABLE);
						dobj = new WritableDataObject();
					}
					row.set(TIME_SPENT_GOAL.GOAL_ID, goalId);
					row.set(TIME_SPENT_GOAL.TIME_THRESHOLD, timeThreshold);
					//				dobj.updateRow(row);
					upsertRow(dobj, row);
					updateDataObject(dobj);
					TimeSpentGoal timeSpentGoal = new TimeSpentGoal();
					timeSpentGoal.setBasicGoalData(goalRow);
					timeSpentGoal.setTimeThreshold(Long.parseLong(timeThreshold));
					goal = timeSpentGoal;

					break;

				default:
					goal = new Goal();
					goal.setBasicGoalData(goalRow);
					break;
				}
				deleteOtherTypeGoals(goal);

				if(isprojectLevel){
					Criteria projgoalupdateCri = new Criteria(new Column(PROJECT_GOAL.TABLE,PROJECT_GOAL.GOAL_ID),goal.getGoalId(),QueryConstants.EQUAL);
					hs.put(GoalConstants.GOAL_ID, goal.getGoalId().toString());
					if(hs.containsKey(GoalConstants.INCLUDE_URLS)) { 
						String includeurls = hs.get(GoalConstants.INCLUDE_URLS);
						if(includeurls!=null && !includeurls.isEmpty()) {
							JSONArray includearray = new JSONArray(includeurls);
							if(includearray.length() > 0){
								hs.put(GoalConstants.GOAL_URL, null);
							}
						}
						
					}
					ZABModel.updateRow(GoalConstants.PROJECT_GOAL_TABLE, PROJECT_GOAL.TABLE, hs,projgoalupdateCri,GoalConstants.API_MODULE);
				}
			} else {
				goal = new Goal();
				goal.setBasicGoalData(goalRow);
				
		}
		
		mgr.commit();

		if(isprojectLevel){

			if(hs.containsKey(GoalConstants.GOAL_NAME) )
			{
				HashMap<String, String> eventModuleHs = new HashMap<String, String>();
				eventModuleHs.put(EventActivityConstants.MODULE_ELEMENT_NAME, hs.get(GoalConstants.GOAL_NAME));
				EventModuleDetail.updateEventModuleDetail(eventModuleHs, Module.PROJECT_GOAL.getValue(), goal.getGoalId());
			}
			HashMap<String, String> updatedValues = new HashMap<String, String>();
			updatedValues.putAll(hs);
			updatedValues.put(EventActivityConstants.USER_ID, ZABUtil.getCurrentUser().getUserId().toString());
			updatedValues.put(EventActivityConstants.TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
			updatedValues.put(GoalConstants.GOAL_NAME, goal.getGoalName());
			updatedValues.put(GoalConstants.GOAL_ID, goal.getGoalId().toString());
			EventActivityWrapper activityWrapper = new EventActivityWrapper();
			activityWrapper.setModule(Module.PROJECT_GOAL);
			activityWrapper.setOperationType(com.zoho.abtest.eventactivity.EventActivityConstants.OperationType.UPDATE);
			activityWrapper.setDbSpace(ZABUtil.getCurrentUserDbSpace());
			activityWrapper.setUpdatedValues(updatedValues);
			activityWrapper.setOldValues(oldValues);
			ZABNotifier.notifyListeners(EventActivityConstants.EVENT_MODULE_NAME, activityWrapper);


			HashMap<String, String> acHs = new HashMap<String, String>();
			acHs.put(AdminConsoleConstants.GOAL_ID, goalId.toString());
			acHs.put(AdminConsoleConstants.ZSOID, ZABUtil.getDBSpace());

			AdminConsoleWrapper acWrapper = new AdminConsoleWrapper();
			acWrapper.setValueHs(acHs);
			acWrapper.setOperationType(AcOperationType.PROJECT_GOAL_UPDATE);
			ZABNotifier.notifyListeners(
					AdminConsoleConstants.ADMIN_CONSOLE_MODULE_NAME,
					acWrapper);
		}
		//Notify event
		ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
		wrapper.setModel(goal);
		wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
		wrapper.setType(OperationType.UPDATE);
		ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);
		
	} catch(ZABException e) {
		LOGGER.log(Level.SEVERE, e.getMessage(),e);
		goal = new Goal();
		goal.setSuccess(Boolean.FALSE);
		goal.setResponseString(e.getMessage());
		try {
			mgr.rollback();
		} catch (Exception e1) {
			LOGGER.log(Level.SEVERE, e1.getMessage(),e1);
		}
	} catch(ResourceNotFoundException re) {
		LOGGER.log(Level.SEVERE, re.getMessage(),re);
		goal = new Goal();
		setModelWithRNFData(goal, re);
	} catch(Exception e) {

		LOGGER.log(Level.SEVERE, e.getMessage(),e);
		goal = new Goal();
		goal.setSuccess(Boolean.FALSE);
		goal.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
		try {
			mgr.rollback();
		} catch (Exception e1) {
			LOGGER.log(Level.SEVERE, e1.getMessage(),e1);
		}
	}
	return goal;
	}
	
	
	
	public static Boolean goalWithNameAlreadyExists(String displayName, Long experimentId, Criteria c3) throws Exception {
		Criteria c = new Criteria(new Column(GOAL.TABLE, GOAL.GOAL_NAME), displayName, QueryConstants.EQUAL);
		Criteria c2 = new Criteria(new Column(EXPERIMENT_GOAL.TABLE, EXPERIMENT_GOAL.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
		Join join1=new Join(GOAL.TABLE,EXPERIMENT_GOAL.TABLE,new String[]{GOAL.GOAL_ID},new String[]{EXPERIMENT_GOAL.GOAL_ID},Join.INNER_JOIN);
		DataObject dobj = getRow(GOAL.TABLE, c.and(c2).and(c3), join1);
		return dobj.containsTable(GOAL.TABLE);
	}
	
	public static Boolean goalWithNameAlreadyExists(String displayName, String oldName, Long experimentId) throws Exception {
		Criteria c = new Criteria(new Column(GOAL.TABLE, GOAL.GOAL_NAME), oldName, QueryConstants.NOT_EQUAL);
		return goalWithNameAlreadyExists(displayName, experimentId, c);
	}
	
	public static Boolean goalWithNameAlreadyExistsInProject(String displayName, Long projectid, Criteria c3) throws Exception {
		Criteria c = new Criteria(new Column(GOAL.TABLE, GOAL.GOAL_NAME), displayName, QueryConstants.EQUAL);
		Criteria c1 = new Criteria(new Column(GOAL.TABLE, GOAL.IS_PROJECT_LEVEL), Boolean.TRUE, QueryConstants.EQUAL);
		Criteria c2 = new Criteria(new Column(GOAL.TABLE, GOAL.PROJECT_ID), projectid, QueryConstants.EQUAL);
		DataObject dobj = getRow(GOAL.TABLE, c.and(c1).and(c2).and(c3));
		return dobj.containsTable(GOAL.TABLE);
	}
	
	public static Boolean goalWithNameAlreadyExistsInProject(String displayName, String oldName, Long projectid) throws Exception {
		Criteria c = new Criteria(new Column(GOAL.TABLE, GOAL.GOAL_NAME), oldName, QueryConstants.NOT_EQUAL);
		return goalWithNameAlreadyExistsInProject(displayName, projectid, c);
	}
	
	public static Goal createGoal(HashMap<String, String> hs,Boolean isProjectLevel) {
		
		Goal goal = new Goal();
		TransactionManager mgr = DataAccess.getTransactionManager();
		try {
			Transaction trans = mgr.getTransaction();
			Boolean alreadyInTransaction = (trans!=null);
			if(!alreadyInTransaction) {				
				mgr.begin();
			}
			String name = hs.get(GoalConstants.GOAL_NAME);
			Long projectId = null;
			Long experimentId = null;
			
			if(hs.containsKey(GoalConstants.PROJECT_LINKNAME)) {
				projectId = Project.getProjectId(hs.get(GoalConstants.PROJECT_LINKNAME));
			} else if(hs.containsKey(GoalConstants.PROJECT_ID)) {
				projectId = Long.parseLong(hs.get(GoalConstants.PROJECT_ID));
			}
			
		
			if(projectId==null) {
				throw new ZABException(ZABAction.getMessage(ZABConstants.ErrorMessages.RESOURCE_NOT_FOUND.getErrorString(), new String[]{ProjectConstants.API_MODULE}));
			}

			
			if(isProjectLevel){
				Boolean licenseStatus = PortalLicenseMapping.getLicenseStatus();
				if(!licenseStatus){
					throw new ZABException(ZABAction.getMessage(ExperimentConstants.LICENSE_EXPIRE_GOAL_PUBLISH_ERROR));
				}
				if(goalWithNameAlreadyExistsInProject(name, projectId, null)) {
					throw new ZABException(ZABAction.getMessage(GoalConstants.GOAL_NAME_EXISTS, new String[]{name}));
				}
				
				validateGoalUrlTargetting(hs);
				hs.put(GoalConstants.IS_PROJECT_LEVEL, Boolean.TRUE.toString());
				
			}else{
				if(hs.containsKey(GoalConstants.EXPERIMENT_LINKNAME)) {
					String elinkName = hs.get(GoalConstants.EXPERIMENT_LINKNAME);
					experimentId = Experiment.getExperimentId(elinkName);
				}
				if(experimentId==null) {
					throw new ZABException(ZABAction.getMessage(ExperimentConstants.EXPERIMENT_NOT_EXISTS));
				}
				
				//Since there is no sharing or goals among experiments in project level
				//uniqueness is checked in project level
				if(goalWithNameAlreadyExists(name, experimentId, null)) {
					throw new ZABException(ZABAction.getMessage(GoalConstants.GOAL_NAME_EXISTS, new String[]{name}));
				}
				hs.put(GoalConstants.IS_PROJECT_LEVEL, Boolean.FALSE.toString());
				
			}
			
			
			String linkName = generateLinkName(GOAL.TABLE, GOAL.GOAL_LINK_NAME, null, null, name);
			hs.put(ZABConstants.LINKNAME, linkName);
			hs.put(GoalConstants.PROJECT_ID, projectId+"");
			hs.put(ExperimentConstants.CREATED_TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
			hs.put(ExperimentConstants.CREATED_BY, ZABUtil.getCurrentUser().getUserId()+"");
			DataObject dobj = createRow(GoalConstants.GOAL_TABLE, GOAL.TABLE, hs);
			Row goalRow = dobj.getFirstRow(GOAL.TABLE);
			Long goalId = (Long)goalRow.get(GOAL.GOAL_ID);
//			ExperimentGoal.createExperimentGoalWithoutEventTrigger(experiment.getExperimentId(), goalId, hs.containsKey(GoalConstants.IS_PRIMARY)?Boolean.parseBoolean(hs.get(GoalConstants.IS_PRIMARY)):null);
			GoalType type = GoalType.getGoalTypeById(Integer.parseInt(hs.get(GoalConstants.GOAL_TYPE)));
			switch(type) {
				case PAGE_VISIT_GOAL:
				{
					JSONArray urlArray = new JSONArray(hs.get(GoalConstants.URL));
					int size = urlArray.length();
					if(size > 0) {
						DataObject wdobj = new WritableDataObject();
						PageVisitGoal pvGoal = new PageVisitGoal();
						for(int i=0; i<size; i++) {
							JSONObject url = urlArray.getJSONObject(i);
							Row row = new Row(PAGE_VISIT_GOAL.TABLE);
							row.set(PAGE_VISIT_GOAL.GOAL_ID, goalId);
							row.set(PAGE_VISIT_GOAL.PAGE_URL, url.get(GoalConstants.VALUE));
							row.set(PAGE_VISIT_GOAL.MATCH_TYPE, url.get(GoalConstants.MATCH_TYPE));
							wdobj.addRow(row);
							PageVisitGoal purl = new PageVisitGoal();
							purl.setUrl(url.getString(GoalConstants.VALUE));
							purl.setMatchType(url.getInt(GoalConstants.MATCH_TYPE));
							pvGoal.getPageVisitUrls().add(purl);
						}
						updateDataObject(wdobj);
						pvGoal.setBasicGoalData(goalRow);
						goal = pvGoal;
					}
					break;
				}
				case CUSTOM_EVENT_GOAL:
				{
					String customEventLinkName = hs.get(GoalConstants.CUSTOM_EVENT_LN);
					CustomEvent ce = CustomEvent.getCustomEventByLinkname(customEventLinkName, projectId);
					if(ce == null) {
						throw new ZABException(ZABAction.getMessage(ZABConstants.ErrorMessages.RESOURCE_NOT_FOUND.getErrorString(), new String[]{ZABAction.getMessage(CustomEventConstants.API_MODULE)}));
					}
					Row row = new Row(CUSTOM_EVENT_GOAL.TABLE);
					row.set(CUSTOM_EVENT_GOAL.GOAL_ID, goalId);
					Long eventId = ce.getCustomEventId();
					row.set(CUSTOM_EVENT_GOAL.EVENT_ID, eventId);
					row.set(CUSTOM_EVENT_GOAL.CUSTOM_EVENT_NAME, eventId+"");
					createResource(row);
					CustomEventGoal ceGoal = new CustomEventGoal();
					ceGoal.setEventId(eventId);
					ceGoal.setEventLinkname(ce.getCustomEventLinkName());
					ceGoal.setBasicGoalData(goalRow);
					goal = ceGoal;
					break;
				}
				case TIME_SPENT_GOAL:
				{
				
					String timeThreshold = hs.get(GoalConstants.TIME_THRESHOLD);
					Row row = new Row(TIME_SPENT_GOAL.TABLE);
					row.set(TIME_SPENT_GOAL.GOAL_ID, goalId);
					row.set(TIME_SPENT_GOAL.TIME_THRESHOLD, timeThreshold);
					createResource(row);
					TimeSpentGoal timeSpentGoal = new TimeSpentGoal();
					timeSpentGoal.setTimeThreshold(Long.parseLong(timeThreshold));
					timeSpentGoal.setBasicGoalData(goalRow);
					goal = timeSpentGoal;
					break;
				}
				
				case ELEMENT_CLICK_GOAL:
				{
					String cssSelector = hs.get(GoalConstants.ELEMENT_CSS_SELECTOR);
					Row row = new Row(ELEMENT_CLICK_GOAL.TABLE);
					row.set(ELEMENT_CLICK_GOAL.GOAL_ID, goalId);
					row.set(ELEMENT_CLICK_GOAL.ELEMENT_CSS_SELECTOR, cssSelector);
					createResource(row);
					ElementClickGoal ceGoal = new ElementClickGoal();
					ceGoal.setBasicGoalData(goalRow);
					ceGoal.setElementCssSelector(cssSelector);
					goal = ceGoal;
					break;
				}
				case FORM_SUBMIT_GOAL:
				{
					JSONArray urlArray = new JSONArray(hs.get(GoalConstants.URL));
					int size = urlArray.length();
					if(size > 0) {
						DataObject wdobj = new WritableDataObject();
						JSONObject url = urlArray.getJSONObject(0);
						Row row = new Row(FORM_SUBMIT_GOAL.TABLE);
						row.set(FORM_SUBMIT_GOAL.GOAL_ID, goalId);
						row.set(FORM_SUBMIT_GOAL.SUBMIT_URL, url.get(GoalConstants.VALUE));
						row.set(FORM_SUBMIT_GOAL.MATCH_TYPE, url.get(GoalConstants.MATCH_TYPE));
						wdobj.addRow(row);
						updateDataObject(wdobj);
						FormSubmitGoal leGoal = new FormSubmitGoal();
						leGoal.setBasicGoalData(goalRow);
						leGoal.setSubmitUrl(url.getString(GoalConstants.VALUE));
						leGoal.setMatchType(url.getInt(GoalConstants.MATCH_TYPE));
						goal = leGoal;
					}
					break;
				}
				case ENGAGEMENT_GOAL: 
				case REVENUE_GOAL: 
				{
					goal = new Goal();
					goal.setBasicGoalData(goalRow);
					break;
				}
				case LINK_CLICK_GOAL:
				{					
					JSONArray urlArray = new JSONArray(hs.get(GoalConstants.URL));
					int size = urlArray.length();
					if(size > 0) {
						DataObject wdobj = new WritableDataObject();
						JSONObject url = urlArray.getJSONObject(0);
						Row row = new Row(LINK_CLICK_GOAL.TABLE);
						row.set(LINK_CLICK_GOAL.GOAL_ID, goalId);
						row.set(LINK_CLICK_GOAL.LINK_URL, url.get(GoalConstants.VALUE));
						row.set(LINK_CLICK_GOAL.MATCH_TYPE, url.get(GoalConstants.MATCH_TYPE));
						wdobj.addRow(row);
						updateDataObject(wdobj);
						LinkClickGoal leGoal = new LinkClickGoal();
						leGoal.setBasicGoalData(goalRow);
						leGoal.setLinkUrl(url.getString(GoalConstants.VALUE));
						leGoal.setMatchType(url.getInt(GoalConstants.MATCH_TYPE));
						goal = leGoal;
					}
					break;
				}
					
			}
			
			if(isProjectLevel){
				Integer goaltype = Integer.parseInt(hs.get(GoalConstants.GOAL_TYPE));
				//if(!(goaltype.equals(GoalType.CUSTOM_EVENT_GOAL.getGoalTypeId()) )){
					hs.put(GoalConstants.GOAL_ID, goal.getGoalId().toString());
					ZABModel.createRow(GoalConstants.PROJECT_GOAL_TABLE, PROJECT_GOAL.TABLE, hs);
				//}
			}
			
			
			if(experimentId!=null) {
				Boolean isPrimaryGoal = (hs.containsKey(GoalConstants.IS_PRIMARY) && hs.get(GoalConstants.IS_PRIMARY).equals(Boolean.TRUE.toString()));
				ExperimentGoal eg = ExperimentGoal.createExperimentGoalWithoutEventTrigger(experimentId, goalId, isPrimaryGoal);
				goal.setIsPrimaryGoal(eg.getIsPrimary());
				

				if(!alreadyInTransaction) {
					mgr.commit();
				}
				
				//Event Activity Log
				HashMap<String, String> updatedValues = new HashMap<String, String>();
				updatedValues.put(EventActivityConstants.EXPERIMENT_ID, experimentId.toString());
				updatedValues.put(EventActivityConstants.USER_ID, ZABUtil.getCurrentUser().getUserId().toString());
				updatedValues.put(EventActivityConstants.TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
				updatedValues.put(GoalConstants.GOAL_ID, goalId.toString());
				EventActivityWrapper activityWrapper = new EventActivityWrapper();
				activityWrapper.setModule(Module.EXPERIMENT_GOAL);
				activityWrapper.setOperationType(com.zoho.abtest.eventactivity.EventActivityConstants.OperationType.CREATE);
				activityWrapper.setDbSpace(ZABUtil.getCurrentUserDbSpace());
				activityWrapper.setUpdatedValues(updatedValues);
				ZABNotifier.notifyListeners(EventActivityConstants.EVENT_MODULE_NAME, activityWrapper);
			}else{
				

				if(!alreadyInTransaction) {
					mgr.commit();
				}
				
				HashMap<String, String> updatedValues = new HashMap<String, String>();
				
				updatedValues.put(EventActivityConstants.USER_ID, ZABUtil.getCurrentUser().getUserId().toString());
				updatedValues.put(EventActivityConstants.TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
				updatedValues.put(GoalConstants.GOAL_ID, goalId.toString());
				EventActivityWrapper activityWrapper = new EventActivityWrapper();
				activityWrapper.setModule(Module.PROJECT_GOAL);
				activityWrapper.setOperationType(com.zoho.abtest.eventactivity.EventActivityConstants.OperationType.CREATE);
				activityWrapper.setDbSpace(ZABUtil.getCurrentUserDbSpace());
				activityWrapper.setUpdatedValues(updatedValues);
				ZABNotifier.notifyListeners(EventActivityConstants.EVENT_MODULE_NAME, activityWrapper);
				
				//Saving the project display name for the use of event activity
				HashMap<String, String> eventModuleHs = new HashMap<String, String>();
				eventModuleHs.put(EventActivityConstants.MODULE_TYPE, Module.PROJECT_GOAL.getValue().toString());
				eventModuleHs.put(EventActivityConstants.MODULE_ELEMENT_ID, goal.getGoalId().toString());
				eventModuleHs.put(EventActivityConstants.MODULE_ELEMENT_NAME, goal.getGoalName());
				EventModuleDetail.createEventModuleDetail(eventModuleHs);
				
				// Admin console record
				Long zuid = IAMUtil.getCurrentUser().getZUID();
				HashMap<String, String> acHs = new HashMap<String, String>();
				acHs.put(AdminConsoleConstants.GOAL_ID, goalId.toString());
				acHs.put(AdminConsoleConstants.GOAL_TYPE,
						hs.get(GoalConstants.GOAL_TYPE));
				acHs.put(AdminConsoleConstants.ZSOID, ZABUtil.getDBSpace());
				acHs.put(AdminConsoleConstants.PROJECT_ID, projectId.toString());
				acHs.put(AdminConsoleConstants.CREATED_ZUID, zuid.toString());
				acHs.put(AdminConsoleConstants.CREATED_TIME, goal
						.getCreatedTime().toString());

				AdminConsoleWrapper acWrapper = new AdminConsoleWrapper();
				acWrapper.setValueHs(acHs);
				acWrapper.setOperationType(AcOperationType.PROJECT_GOAL_CREATE);
				ZABNotifier.notifyListeners(
						AdminConsoleConstants.ADMIN_CONSOLE_MODULE_NAME,
						acWrapper);
			}
			
			//Notify event
			ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
			wrapper.setModel(goal);
			wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
			wrapper.setType(OperationType.CREATE);
			ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);
			
			
		} catch(ZABException e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			goal = new Goal();
			goal.setSuccess(Boolean.FALSE);
			goal.setResponseString(e.getMessage());
			try {
				mgr.rollback();
			} catch (Exception e1) {
				LOGGER.log(Level.SEVERE, e1.getMessage(),e1);
			}
		}
		catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			goal = new Goal();
			goal.setSuccess(Boolean.FALSE);
			goal.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			try {
				mgr.rollback();
			} catch (Exception e1) {
				LOGGER.log(Level.SEVERE, e1.getMessage(),e1);
			}
		}
		return goal;
	}
	
	public static Goal getGoalByGoalId(Long goalId) {
		Goal goal = null;
		try {
			Criteria c = new Criteria(new Column(GOAL.TABLE, GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
			DataObject dobj = getPersonality(GoalConstants.GOAL_PERSONALITY_NAME, c);
			ArrayList<Goal> goals = getGoalFromDObj(dobj);
			if(!goals.isEmpty()) {
				goal = goals.get(0);
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			goal = new Goal();
			goal.setSuccess(Boolean.FALSE);
			goal.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
		}
		return goal;
	}
	
	public static Long getGoalIdByLinkname(String linkname) throws Exception {
		Long goalId = null;
		Criteria c = new Criteria(new Column(GOAL.TABLE, GOAL.GOAL_LINK_NAME), linkname, QueryConstants.EQUAL);
		DataObject dobj2=getRow(GOAL.TABLE,c);
		if(dobj2.containsTable(GOAL.TABLE)) {
			Row row2=dobj2.getRow(GOAL.TABLE);
			goalId = (Long)row2.get(GOAL.GOAL_ID);
		}
		return goalId;
	}
	
	public static Goal getGoalByLinkname(String linkname) {
		Goal goal = null;
		try {
			Criteria c = new Criteria(new Column(GOAL.TABLE, GOAL.GOAL_LINK_NAME), linkname, QueryConstants.EQUAL);
			DataObject dobj = getPersonality(GoalConstants.GOAL_PERSONALITY_NAME, c);
			ArrayList<Goal> goals = getGoalFromDObj(dobj);
			if(!goals.isEmpty()) {
				goal = goals.get(0);
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			goal = new Goal();
			goal.setSuccess(Boolean.FALSE);
			goal.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
		}
		return goal;
	}
	
	public static ArrayList<Goal> getGoals() {
		ArrayList<Goal> goals = new ArrayList<Goal>();
		try {
			HttpServletRequest request = ZABUtil.getCurrentRequest();
			
			String experimentLinkname = request.getParameter(GoalConstants.EXPERIMENT_QUERY_KEY);
			if(experimentLinkname!=null) {
				Long experimentId = Experiment.getExperimentId(experimentLinkname);
				return getGoalByExperimentByExperimentId(experimentId);
			}
		
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			Goal goal = new Goal();
			goal.setSuccess(Boolean.FALSE);
			goal.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			goals.add(goal);
		}
		return goals;
	}
	
	public static ArrayList<Goal> getGoalByExperimentByExperimentId(Long experimentId) {
		ArrayList<Goal> goals = new ArrayList<Goal>();
		try {
			if(experimentId!=null) {				
				Criteria c = new Criteria(new Column(EXPERIMENT_GOAL.TABLE, EXPERIMENT_GOAL.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
				DataObject dobj = getPersonality(GoalConstants.EXPEIRMENT_GOAL_PERSONALITY_NAME, c);
				return getGoalFromDObj(dobj);
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			Goal goal = new Goal();
			goal.setSuccess(Boolean.FALSE);
			goal.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			goals.add(goal);
		}
		return goals;
	}
	
	
	public static Long getProjectIdFromGoalLinkname(String goalLinkName) {
		Long projectId = null;
		try 
		{
			Criteria c = new Criteria(new Column(GOAL.TABLE, GOAL.GOAL_LINK_NAME), goalLinkName, QueryConstants.EQUAL);
			DataObject dobj = getRow(GOAL.TABLE, c);
			projectId = (Long)dobj.getFirstValue(GOAL.TABLE, GOAL.PROJECT_ID);
		} 
		catch (Exception e) 
		{
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		return projectId;
	} 
	
	
	public static Long getGoalIdForGoal(String goalLinkname) {
		Long id = null;
		try {
			Criteria c = new Criteria(new Column(GOAL.TABLE, GOAL.GOAL_LINK_NAME), goalLinkname, QueryConstants.EQUAL);
			DataObject dobj = getRow(GOAL.TABLE, c);
			Iterator it=dobj.getRows(GOAL.TABLE);
			if(it.hasNext()) {
				Row row = (Row)it.next();
				id = (Long)row.get(GOAL.GOAL_ID);
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		return id;
	}
	

	
	public static Goal deleteGoal(String linkname) {
		Goal goal = null;
		try {
			Criteria c = new Criteria(new Column(GOAL.TABLE, GOAL.GOAL_LINK_NAME), linkname, QueryConstants.EQUAL);
			Join join1=new Join(GOAL.TABLE,EXPERIMENT_GOAL.TABLE,new String[]{GOAL.GOAL_ID},new String[]{EXPERIMENT_GOAL.GOAL_ID},Join.LEFT_JOIN);
			Boolean projectLevel = Boolean.TRUE;
			Long experimentId = null;
			
			DataObject dobj = getRow(GOAL.TABLE, c, new Join[]{join1});
			if(dobj.containsTable(GOAL.TABLE)) {
				Row row = dobj.getFirstRow(GOAL.TABLE);
				goal = getGoalFromRow(row);
				
				//Check if it is primary goal
				if(dobj.containsTable(EXPERIMENT_GOAL.TABLE)) {
					Row erow = dobj.getFirstRow(EXPERIMENT_GOAL.TABLE);
					Boolean isPrimary = (Boolean)erow.get(EXPERIMENT_GOAL.IS_PRIMARY_GOAL);
					experimentId = (Long)erow.get(EXPERIMENT_GOAL.EXPERIMENT_ID);
					if(isPrimary) {
						throw new ZABException(ZABAction.getMessage(GoalConstants.PRIMARY_GOAL_DELETION_ERROR));
					}
					projectLevel = Boolean.FALSE;
					HashMap<String, String> updatedValues = new HashMap<String, String>();
					updatedValues.put(EventActivityConstants.EXPERIMENT_ID, experimentId.toString());
					updatedValues.put(EventActivityConstants.USER_ID, ZABUtil.getCurrentUser().getUserId().toString());
					updatedValues.put(EventActivityConstants.TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
					updatedValues.put(GoalConstants.GOAL_NAME, goal.getGoalName());
					EventActivityWrapper activityWrapper = new EventActivityWrapper();
					activityWrapper.setModule(Module.EXPERIMENT_GOAL);
					activityWrapper.setOperationType(com.zoho.abtest.eventactivity.EventActivityConstants.OperationType.DELETE);
					activityWrapper.setDbSpace(ZABUtil.getCurrentUserDbSpace());
					activityWrapper.setUpdatedValues(updatedValues);
					ZABNotifier.notifyListeners(EventActivityConstants.EVENT_MODULE_NAME, activityWrapper);
					
				}
				
				deleteResource(row);
				if(projectLevel){
					//Delete goal data from ES
					ElasticSearchUtil.deleteGoalData(goal.getGoalId());
					
					HashMap<String, String> updatedValues = new HashMap<String, String>();
					updatedValues.put(EventActivityConstants.GOAL_ID,goal.getGoalId().toString());
					updatedValues.put(EventActivityConstants.USER_ID, ZABUtil.getCurrentUser().getUserId().toString());
					updatedValues.put(EventActivityConstants.TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
					updatedValues.put(GoalConstants.GOAL_NAME, goal.getGoalName());
					updatedValues.put(EventActivityConstants.PROJECT_ID,goal.getProjectId().toString());
					
					
					EventActivityWrapper activityWrapper = new EventActivityWrapper();
					activityWrapper.setModule(Module.PROJECT_GOAL);
					activityWrapper.setOperationType(com.zoho.abtest.eventactivity.EventActivityConstants.OperationType.DELETE);
					activityWrapper.setDbSpace(ZABUtil.getCurrentUserDbSpace());
					activityWrapper.setUpdatedValues(updatedValues);
					ZABNotifier.notifyListeners(EventActivityConstants.EVENT_MODULE_NAME, activityWrapper);
					
					// Admin console record
					HashMap<String, String> acHs = new HashMap<String, String>();
					acHs.put(AdminConsoleConstants.GOAL_ID, goal.getGoalId().toString());
					acHs.put(AdminConsoleConstants.ZSOID, ZABUtil.getDBSpace());
					AdminConsoleWrapper acWrapper = new AdminConsoleWrapper();
					acWrapper.setValueHs(acHs);
					acWrapper.setOperationType(AcOperationType.PROJECT_GOAL_DELETE);
					ZABNotifier.notifyListeners(AdminConsoleConstants.ADMIN_CONSOLE_MODULE_NAME,acWrapper);
				}else{
					if(experimentId!=null){
						ElasticSearchUtil.deleteExperimentGoalData(experimentId, goal.getGoalId());
					}
				}
			
				
			} else {
				throw new ResourceNotFoundException(GoalConstants.API_MODULE);
			}
			
			//Notify event
			ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
			wrapper.setModel(goal);
			wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
			wrapper.setType(OperationType.DELETE);
			ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);
			
			goal.setProjectLinkname(null);
		}catch(ZABException e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			goal = new Goal();
			goal.setSuccess(Boolean.FALSE);
			goal.setResponseString(e.getMessage());
		} catch(ResourceNotFoundException re) {
			LOGGER.log(Level.SEVERE, re.getMessage(),re);
			goal = new Goal();
			setModelWithRNFData(goal, re);
		}  catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			goal = new Goal();
			goal.setSuccess(Boolean.FALSE);
			goal.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
		}
		return goal;
	}
	
	
	public static void validateGoalUrlTargetting(HashMap<String, String> hs) throws ZABException{
		Integer goaltype = Integer.parseInt(hs.get(GoalConstants.GOAL_TYPE));
		if(!(goaltype.equals(GoalType.CUSTOM_EVENT_GOAL.getGoalTypeId())  )){
			ArrayList<String> fields = new ArrayList<String>();
			String goaltargeturl = hs.get(GoalConstants.GOAL_URL);
			String includeurls = hs.get(GoalConstants.INCLUDE_URLS);
			Boolean isgoalurlValid =Boolean.TRUE;
			Boolean isincludeurlValid =Boolean.TRUE;
			if(goaltargeturl==null || goaltargeturl.isEmpty()){
				isgoalurlValid = Boolean.FALSE;
			}else{
				if(!ZABUtil.validateUrl(goaltargeturl)) {
					throw new ZABException(ZABAction.getMessage(ZABConstants.INVALID_URL_MESSAGE));
				}
			}
			
			if(includeurls==null || includeurls.isEmpty()){
				isincludeurlValid= Boolean.FALSE;
			}else{
				if(includeurls.equals("[]")){
					isincludeurlValid= Boolean.FALSE;
				}else{
					String validity = validateIncludeUrlsJson(includeurls);
					if(validity!=null ){ // invalid
						throw new ZABException(validity);
						
					}
				}
				
			}
			if(isgoalurlValid.equals(Boolean.FALSE) && isincludeurlValid.equals(Boolean.FALSE) ){
				fields.add(GoalConstants.GOAL_URL);
				throw new ZABException(ZABAction.getAppropriateMessage(ZABConstants.ErrorMessages.MANDATORY_FIELD_MISSING.getErrorString(), fields));
		
			}
			
		}
	   
	}
	public static String  validateIncludeUrlsJson(String includeUrls){
		try {
			JSONArray array = new JSONArray(includeUrls);
			int size = array.length();
			if(size==0) {
				return ZABAction.getMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{GoalConstants.INCLUDE_URLS});
			} else {
				for(int i=0; i<size; i++) {
					JSONObject url = array.getJSONObject(i);
					if(!url.has(GoalConstants.VALUE)  || url.getString(GoalConstants.VALUE).trim().isEmpty()) {
						return ZABAction.getMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{GoalConstants.VALUE+" of "+GoalConstants.URL}); //NO I18N
					}

					Integer matchType = url.getInt(GoalConstants.MATCH_TYPE);
					MatchType type = MatchType.getMatchTypeById(matchType);
					if(type==null) {
						return ZABAction.getMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{GoalConstants.MATCH_TYPE+" of "+GoalConstants.URL});//NO I18N
					}
				}
			} 
			
		} catch (JSONException | NumberFormatException e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			return ZABAction.getMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{GoalConstants.INCLUDE_URLS});
		}
		return null;
	}
	public static HashMap<String,String> generateHashMapFromGoalObj(Goal goal, HashMap<String,String> hs) {
		HashMap<String,String> oldValues = new HashMap<String,String>();
		try
		{

			for(String attributeName:EventActivityConstants.PROJECT_GOAL_ATTR_TO_TRACE)
			{
				if(hs.containsKey(attributeName))
				{
					switch(attributeName)
					{
					case GoalConstants.GOAL_NAME:
						oldValues.put(GoalConstants.GOAL_NAME, goal.getGoalName());
						break;
						
					case GoalConstants.GOAL_URL:
						oldValues.put(GoalConstants.GOAL_URL, goal.getGoalUrl());
						break;
					
					case GoalConstants.INCLUDE_URLS:
					
						oldValues.put(GoalConstants.INCLUDE_URLS,goal.getIncludeUrl());
						break;
					case GoalConstants.EXCLUDE_URLS:
						oldValues.put(GoalConstants.EXCLUDE_URLS,goal.getExcludeUrl());
						break;
					case GoalConstants.GOAL_STATUS:
						oldValues.put(GoalConstants.GOAL_STATUS,goal.getGoalStatus().toString());
						break;
					}
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		return oldValues;
	}
	
	public static void migrateAcProjectGoalDetails() {	
		
		//Join join = new Join(GOAL.TABLE,PROJECT_GOAL.TABLE,new String[]{GOAL.GOAL_ID},new String[]{PROJECT_GOAL.GOAL_ID},Join.INNER_JOIN);
		Criteria c = new Criteria(new Column(GOAL.TABLE, GOAL.IS_PROJECT_LEVEL),true,QueryConstants.EQUAL);
		try {

			DataObject dobj = getRow(GOAL.TABLE,c);
			if(dobj.containsTable(GOAL.TABLE)) {
				Iterator itRow = dobj.getRows(GOAL.TABLE);
				while(itRow.hasNext()) {
					
					HashMap<String,String> hs = new HashMap<String,String>();

					

					Row row = (Row)itRow.next();
					Long projectId = (Long)row.get(GOAL.PROJECT_ID);
					hs.put(GoalConstants.GOAL_ID, ((Long)row.get(GOAL.GOAL_ID)).toString());
					hs.put(GoalConstants.GOAL_TYPE, ((Integer)row.get(GOAL.GOAL_TYPE_FLAG)).toString());
					hs.put(GoalConstants.PROJECT_ID, projectId.toString());
					hs.put(AdminConsoleConstants.ZSOID, ZABUtil.getDBSpace());
					Long userId = (Long)row.get(GOAL.CREATED_BY);
					
					Criteria c1 = new Criteria(new Column(APP_USER.TABLE,APP_USER.USER_ID),userId,QueryConstants.EQUAL);
					DataObject dobj1 = getRow(APP_USER.TABLE,c1);
					if(dobj1.containsTable(APP_USER.TABLE)) {
						Row row1 = dobj1.getFirstRow(APP_USER.TABLE);
						userId = (Long)row1.get(APP_USER.ZUID);
					}
					hs.put(AdminConsoleConstants.CREATED_ZUID, userId.toString());
					hs.put(ExperimentConstants.CREATED_TIME, ((Long)row.get(GOAL.CREATED_TIME)).toString());
					AdminConsole.createAcGoal(hs);
				}
				
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Exception occured:", e);
		}
			
		
	}

}
