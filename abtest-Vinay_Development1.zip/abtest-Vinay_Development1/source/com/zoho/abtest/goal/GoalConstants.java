//$Id$
package com.zoho.abtest.goal;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import com.zoho.abtest.EXPERIMENT_GOAL;
import com.zoho.abtest.GOAL;
import com.zoho.abtest.GOAL_VISITS;
import com.zoho.abtest.PROJECT_GOAL;
import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.report.ReportArchieveDimensionConstants;

public class GoalConstants {
	
	public static final String API_MODULE = "goal"; //No I18N
	
	public static final String API_MODULE_PLURAL = "goals"; //No I18N
	
	public static final String GOAL_PERSONALITY_NAME = "goalDetail"; //No I18N
	
	public static final String GOAL_REPORTS = "goalreports"; //No I18N
	
	public static final String PROJECT_GOALS = "projectgoal"; //No I18N
	
	public static final String PROJECT_GOALS_PLURAL = "projectgoals"; //No I18N
	
	public static final String EXPEIRMENT_GOAL_PERSONALITY_NAME = "experimentGoalDetail"; //No I18N
	
	public static final String MATCH_TYPE = "match_type"; //No I18N
	
	public static final String GOAL_NAME = "display_name"; //No I18N
	
	public static final String GOAL_LINK_NAME = "goal_link_name"; //No I18N
	
	public static final String GOAL_DESCRIPTION = "description"; //No I18N
	
	public static final String PROJECT_LINKNAME = "project_linkname"; //No I18N
	
	public static final String PROJECT_ID = "project_id"; //No I18N
	
	public static final String URL = "url"; //No I18N
	
	public static final String DEVICE = "device"; //No I18N
	
	public static final String COUNTRY = "country"; //No I18N
	
	public static final String VALUE = "value"; //No I18N
	
	public static final String GOAL_TYPE = "goal_type"; //No I18N
	
	public static final String GOAL_STATUS = "goal_status"; //No I18N
	
	public static final String GOAL_ACTUAL_START_TIME = "actual_start_time"; //No I18N
	
	public static final String GOAL_ACTUAL_END_TIME = "actual_end_time"; //No I18N
	
	public static final String CUSTOM_EVENT_NAME = "custom_event_name"; //No I18N

	public static final String TIME_THRESHOLD = "time_threshold"; //No I18N
	
	public static final String CUSTOM_EVENT_LN = "custom_event_linkname"; //No I18N
	
	public static final String ELEMENT_CSS_SELECTOR = "element_css_selector"; //No I18N
	
	public static final String VARIATION_ID = "variation_id"; //No I18N
	
	public static final String GOAL_ID = "goal_id"; //No I18N
	
	public static final String EXPERIMENT_ID = "experiment_id"; //No I18N
	
	public static final String EXPERIMENT_LINKNAME = "experiment_linkname"; //No I18N
	
	public static final String IS_PRIMARY = "is_primary"; //No I18N
	
	public static final String IS_PROJECT_LEVEL = "is_project_level"; //No I18N
	
	public static final String GOAL_ID_INITIAL = "GOAL_ID"; //No I18N
	
	public static final String GOAL_VISITS_ID= "goal_visits_id";	// NO I18N
	
	public static final String EXPERIMENT_QUERY_KEY= "experiment";	// NO I18N
	
	public static final String PROJECT_QUERY_KEY= "project";	// NO I18N
	
	public static final String GOAL_CFAILURE_BY_TYPE = "resource.goal.creation.failure.type";// NO I18N
	
	public static final String GOAL_UFAILURE_BY_TYPE = "resource.goal.updation.failure.type";// NO I18N
	
	public static final String GOAL_DFAILURE_BY_TYPE = "resource.goal.deletion.failure.type"; //NO I18N
	
	public static final String PRIMARY_GOAL_UPDATE_ERROR = "resource.goal.updation.elmandatory.type"; //NO I18N
	
	public static final String PRIMARY_GOAL_DELETION_ERROR = "resource.goal.deletion.primary.error"; //NO I18N
	
	public static final String GOAL_NOT_EXISTS = "goal.not.exists"; //NO I18N
	
	public static final String GOAL_NAME_EXISTS = "goal.name.exists"; //NO I18N
	
	public static final String ENGAGEMENT = "Engagement"; //NO I18N
	
	public static final String URL_DETAILS = "url_details"; //NO I18N 
	
	public static final String DEVICE_DETAILS = "device_details"; //NO I18N
	
	public static final String COUNTRY_DETAILS = "country_details"; //NO I18N
	
	public static final String GOAL_URL = "goal_url"; //No I18N
	
	public static final String INCLUDE_URLS = "include_urls"; //No I18N
	
	public static final String EXCLUDE_URLS = "exclude_urls"; //No I18N
	public static final String GOAL_REPORT_INFO = "info"; //No I18N
	

	public static enum GoalStatus {
		RUNNING(1),
		PAUSED(2);
		private Integer statusCode;
		public Integer getStatusCode() {
			return this.statusCode;
		}
		public static GoalStatus getStatusByNumber(Integer number) {
			for(GoalStatus status: GoalStatus.values()) {
				if(number!=null && status.getStatusCode().equals(number)) {
					return status;
				}
			}
			return null;
		}
		private GoalStatus(Integer statusCode) {
			this.statusCode = statusCode;
		}
		
	}
	
	
	public static enum GoalType {
		PAGE_VISIT_GOAL(1),
		LINK_CLICK_GOAL(2),
		FORM_SUBMIT_GOAL(3),
		ELEMENT_CLICK_GOAL(4),
		ENGAGEMENT_GOAL(5),
		CUSTOM_EVENT_GOAL(6),

		REVENUE_GOAL(7),
		TIME_SPENT_GOAL(8);
		
		private Integer goalTypeId;
		
		private GoalType(Integer goalTypeId) {
			this.goalTypeId = goalTypeId;
		}

		public Integer getGoalTypeId() {
			return goalTypeId;
		}
		
		public static GoalType getGoalTypeById(Integer goalTypeId) {
			if(goalTypeId!=null) {
				for(GoalType goal: GoalType.values()) {
					if(goalTypeId.equals(goal.getGoalTypeId())) {
						return goal;
					}
				}
			}
			return null;
		}
	}
	
	public final static Set<Integer> DEFAULT_GOAL_TYPES;
	static {
		Set<Integer> goalTypes = new LinkedHashSet<Integer>();
		goalTypes.add(GoalType.ENGAGEMENT_GOAL.getGoalTypeId());
		DEFAULT_GOAL_TYPES = Collections.unmodifiableSet(goalTypes);
	}
	
	public final static List<Constants> GOAL_TABLE;
	static {
		ArrayList<Constants> list = new ArrayList<Constants>();
		list.add(new Constants(ZABConstants.LINKNAME,GOAL.GOAL_LINK_NAME,ZABConstants.STRING,Boolean.FALSE));
		list.add(new Constants(GOAL_NAME,GOAL.GOAL_NAME,ZABConstants.STRING,Boolean.TRUE));
		list.add(new Constants(GOAL_DESCRIPTION,GOAL.GOAL_DESCRIPTION,ZABConstants.STRING,Boolean.TRUE));
		list.add(new Constants(PROJECT_ID,GOAL.PROJECT_ID,ZABConstants.LONG,Boolean.FALSE));
		list.add(new Constants(GOAL_TYPE,GOAL.GOAL_TYPE_FLAG,ZABConstants.INTEGER,Boolean.FALSE));
		list.add(new Constants(GOAL_STATUS,GOAL.GOAL_STATUS,ZABConstants.INTEGER,Boolean.FALSE));
		list.add(new Constants(GOAL_ACTUAL_END_TIME,GOAL.ACTUAL_END_TIME,ZABConstants.LONG,Boolean.TRUE));
		list.add(new Constants(IS_PROJECT_LEVEL,GOAL.IS_PROJECT_LEVEL,ZABConstants.BOOLEAN,Boolean.FALSE));
		list.add(new Constants(ExperimentConstants.CREATED_BY,GOAL.CREATED_BY,ZABConstants.LONG,Boolean.FALSE));
		list.add(new Constants(ExperimentConstants.CREATED_TIME,GOAL.CREATED_TIME,ZABConstants.LONG,Boolean.FALSE));
		GOAL_TABLE = (List<Constants>) Collections.unmodifiableList(list);
	}
	
	public final static List<Constants> EXPERIMENT_GOAL_TABLE;
	static {
		ArrayList<Constants> list = new ArrayList<Constants>();
		list.add(new Constants(GOAL_ID,EXPERIMENT_GOAL.GOAL_ID,ZABConstants.LONG,Boolean.TRUE));
		list.add(new Constants(EXPERIMENT_ID,EXPERIMENT_GOAL.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE));
		list.add(new Constants(IS_PRIMARY,EXPERIMENT_GOAL.IS_PRIMARY_GOAL,ZABConstants.BOOLEAN,Boolean.TRUE));
		EXPERIMENT_GOAL_TABLE = (List<Constants>) Collections.unmodifiableList(list);
	}
	
	public final static List<Constants> GOAL_VISITS_CONSTANTS;
	static
	{
		List<Constants> variationVisitsConstants = new ArrayList<Constants>();
		variationVisitsConstants.add(new Constants(GOAL_VISITS_ID,GOAL_VISITS.GOAL_VISITS_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		variationVisitsConstants.add(new Constants(EXPERIMENT_ID,GOAL_VISITS.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		variationVisitsConstants.add(new Constants(VARIATION_ID,GOAL_VISITS.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		variationVisitsConstants.add(new Constants(GOAL_ID,GOAL_VISITS.GOAL_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		variationVisitsConstants.add(new Constants(ReportArchieveDimensionConstants.UNIQUE_GOAL_ACHIEVED_COUNT,GOAL_VISITS.UNIQUE_GOAL_ACHIEVED_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		variationVisitsConstants.add(new Constants(ReportArchieveDimensionConstants.TOTAL_GOAL_ACHIEVED_COUNT,GOAL_VISITS.TOTAL_GOAL_ACHIEVED_COUNT,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		GOAL_VISITS_CONSTANTS = Collections.unmodifiableList(variationVisitsConstants);
		
	}
	
	public final static List<Constants> PROJECT_GOAL_TABLE;
	static {
		ArrayList<Constants> list = new ArrayList<Constants>();
	
		list.add(new Constants(GOAL_ID,PROJECT_GOAL.GOAL_ID,ZABConstants.LONG,Boolean.FALSE));
		list.add(new Constants(GOAL_URL,PROJECT_GOAL.GOAL_URL,ZABConstants.STRING,Boolean.TRUE));
		list.add(new Constants(EXCLUDE_URLS,PROJECT_GOAL.EXCLUDE_URLS,ZABConstants.STRING,Boolean.TRUE,Boolean.TRUE));
		list.add(new Constants(INCLUDE_URLS,PROJECT_GOAL.INCLUDE_URLS,ZABConstants.STRING,Boolean.TRUE,Boolean.TRUE));
		PROJECT_GOAL_TABLE = (List<Constants>) Collections.unmodifiableList(list);
	}
}
