//$Id$
package com.zoho.abtest.goal;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.UpdateQuery;
import com.adventnet.ds.query.UpdateQueryImpl;
import com.adventnet.iam.IAMUtil;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.persistence.WritableDataObject;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.EXPERIMENT_GOAL;
import com.zoho.abtest.GOAL;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.eventactivity.EventActivityConstants;
import com.zoho.abtest.eventactivity.EventActivityWrapper;
import com.zoho.abtest.eventactivity.EventActivityConstants.Module;
import com.zoho.abtest.exception.ResourceNotFoundException;
import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentStatus;
import com.zoho.abtest.listener.ZABNotifier;
import com.zoho.abtest.project.ProjectTreeEventConstants;
import com.zoho.abtest.project.ProjectTreeEventConstants.OperationType;
import com.zoho.abtest.project.ProjectTreeEventWrapper;
import com.zoho.abtest.utility.ZABUtil;

public class ExperimentGoal extends ZABModel{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = Logger.getLogger(ExperimentGoal.class.getName()); 

	private Long experimentGoalId;
	
	private Long experimentId;
	
	private Long goalId;
	
	private Goal goal;
	
	private Boolean isPrimary;
	
	public Boolean getIsPrimary() {
		return isPrimary;
	}

	public void setIsPrimary(Boolean isPrimary) {
		this.isPrimary = isPrimary;
	}

	public Long getExperimentGoalId() {
		return experimentGoalId;
	}

	public void setExperimentGoalId(Long experimentGoalId) {
		this.experimentGoalId = experimentGoalId;
	}

	public Long getExperimentId() {
		return experimentId;
	}

	public void setExperimentId(Long experimentId) {
		this.experimentId = experimentId;
	}

	public Long getGoalId() {
		return goalId;
	}

	public void setGoalId(Long goalId) {
		this.goalId = goalId;
	}

	public Goal getGoal() {
		return goal;
	}

	public void setGoal(Goal goal) {
		this.goal = goal;
	}
	
	
	
	public static Long getFirstExperimentIdForGoal(Long goalId) throws Exception {
		Long experimentId = null;
		Criteria c = new Criteria(new Column(EXPERIMENT_GOAL.TABLE, EXPERIMENT_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
		DataObject dobj = getRow(EXPERIMENT_GOAL.TABLE, c);
		if(dobj.containsTable(EXPERIMENT_GOAL.TABLE)) {
			experimentId = (Long) dobj.getFirstRow(EXPERIMENT_GOAL.TABLE).get(EXPERIMENT_GOAL.EXPERIMENT_ID);
		}
		return experimentId;
	}
	
	public static ExperimentGoal createExperimentGoal(Long experimentId, String goalLinkname, Boolean isPrimaryGoal) throws Exception {
		Long goalId = Goal.getGoalIdForGoal(goalLinkname);
		Criteria c1 = new Criteria(new Column(EXPERIMENT_GOAL.TABLE, EXPERIMENT_GOAL.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
		Criteria c2 = new Criteria(new Column(EXPERIMENT_GOAL.TABLE, EXPERIMENT_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
		if(experimentId == null) {			
			throw new ZABException(ZABAction.getMessage(ExperimentConstants.EXPERIMENT_NOT_EXISTS));
		}
		
		if(goalId == null) {			
			throw new ZABException(ZABAction.getMessage(GoalConstants.GOAL_NOT_EXISTS,new String[]{goalLinkname}));  
		}
		
		if(resourceExists(EXPERIMENT_GOAL.TABLE, c1.and(c2))) {
//			throw new ZABException("Goal "+goalLinkname+" already exists in experiment"); //No I18N
			ExperimentGoal egoal = new ExperimentGoal();
			egoal.setSuccess(Boolean.TRUE);
			return egoal;
		}
		
		return createExperimentGoalWithEventTrigger(experimentId, goalId, isPrimaryGoal);
	}
	
	public static void removePrimaryGoal(Long experimentId) throws Exception {
		UpdateQuery updateQuery = new UpdateQueryImpl(EXPERIMENT_GOAL.TABLE);
		updateQuery.setCriteria(new Criteria(new Column(EXPERIMENT_GOAL.TABLE,EXPERIMENT_GOAL.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL));
		updateQuery.setUpdateColumn(EXPERIMENT_GOAL.IS_PRIMARY_GOAL, Boolean.FALSE);
		updateResource(updateQuery);
	}
	
	public static ArrayList<Experiment> getExperimentsForGoal(Long goalId) {
		ArrayList<Experiment> experiments = new ArrayList<Experiment>();
		try {			
			Criteria c = new Criteria(new Column(EXPERIMENT_GOAL.TABLE, EXPERIMENT_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
			Join join1=new Join(EXPERIMENT_GOAL.TABLE,EXPERIMENT.TABLE,new String[]{EXPERIMENT_GOAL.EXPERIMENT_ID},new String[]{EXPERIMENT.EXPERIMENT_ID},Join.INNER_JOIN);
			DataObject dobj =getRow(EXPERIMENT_GOAL.TABLE, c, join1);
			if(dobj.containsTable(EXPERIMENT.TABLE)) {
				experiments = Experiment.getExperimentFromDobj(dobj);
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		return experiments;
	}
	
	
	
	public static ExperimentGoal removeExperimentGoal(String experimentLinkname,String goalLinkname) throws Exception {
		Experiment experiment = Experiment.getExperimentByLinkname(experimentLinkname);
		if(experiment == null) {			
			throw new ZABException(ZABAction.getMessage(ExperimentConstants.EXPERIMENT_NOT_EXISTS));
		}
		Long experimentId = experiment.getExperimentId();
		Long goalId = Goal.getGoalIdForGoal(goalLinkname);
		
		if(goalId == null) {			
			throw new ZABException(ZABAction.getMessage(GoalConstants.GOAL_NOT_EXISTS,new String[]{goalLinkname})); 
		}
		return removeExperimentGoal(experimentId, goalId);
		
	}
	
	public static ExperimentGoal removeExperimentGoal(Long experimentId, Long goalId) {
		ExperimentGoal egoal = null;
		try {
			Criteria c1 = new Criteria(new Column(EXPERIMENT_GOAL.TABLE, EXPERIMENT_GOAL.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
			Criteria c2 = new Criteria(new Column(EXPERIMENT_GOAL.TABLE, EXPERIMENT_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
			deleteRow(EXPERIMENT_GOAL.TABLE, c1.and(c2), GoalConstants.API_MODULE);
			egoal = new ExperimentGoal();
			egoal.setSuccess(Boolean.TRUE);
			egoal.setGoalId(goalId);
			egoal.setExperimentId(experimentId);
			ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
			wrapper.setModel(egoal);
			wrapper.setType(OperationType.DELETE);
			wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
			ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);
			
			//Event Activity Log
			HashMap<String, String> updatedValues = new HashMap<String, String>();
			updatedValues.put(EventActivityConstants.EXPERIMENT_ID, experimentId.toString());
			updatedValues.put(EventActivityConstants.USER_ID, ZABUtil.getCurrentUser().getUserId().toString());
			updatedValues.put(EventActivityConstants.TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
			updatedValues.put(GoalConstants.GOAL_ID, goalId.toString());
			EventActivityWrapper activityWrapper = new EventActivityWrapper();
			activityWrapper.setModule(Module.EXPERIMENT_GOAL);
			activityWrapper.setOperationType(com.zoho.abtest.eventactivity.EventActivityConstants.OperationType.DELETE);
			activityWrapper.setDbSpace(ZABUtil.getCurrentUserDbSpace());
			activityWrapper.setUpdatedValues(updatedValues);
			ZABNotifier.notifyListeners(EventActivityConstants.EVENT_MODULE_NAME, activityWrapper);
		} catch (ResourceNotFoundException e) {
			egoal = new ExperimentGoal();
			egoal.setSuccess(Boolean.FALSE);
			egoal.setResponseString(e.getMessage());
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			egoal = new ExperimentGoal();
			egoal.setSuccess(Boolean.FALSE);
			egoal.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
		}
		return egoal;
	}
	
	public static ExperimentGoal createExperimentGoalWithEventTrigger(Long experimentId, Long goalId, Boolean isPrimaryGoal) throws Exception {
		ExperimentGoal egoal = null;
		try {
			egoal = createExperimentGoalWithoutEventTrigger(experimentId, goalId, isPrimaryGoal);
			ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
			wrapper.setModel(egoal);
			wrapper.setType(OperationType.CREATE);
			wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
			ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);
			
			//Event Activity Log
			HashMap<String, String> updatedValues = new HashMap<String, String>();
			updatedValues.put(EventActivityConstants.EXPERIMENT_ID, experimentId.toString());
			updatedValues.put(EventActivityConstants.USER_ID, ZABUtil.getCurrentUser().getUserId().toString());
			updatedValues.put(EventActivityConstants.TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
			updatedValues.put(GoalConstants.GOAL_ID, goalId.toString());
			EventActivityWrapper activityWrapper = new EventActivityWrapper();
			activityWrapper.setModule(Module.EXPERIMENT_GOAL);
			activityWrapper.setOperationType(com.zoho.abtest.eventactivity.EventActivityConstants.OperationType.CREATE);
			activityWrapper.setDbSpace(ZABUtil.getCurrentUserDbSpace());
			activityWrapper.setUpdatedValues(updatedValues);
			ZABNotifier.notifyListeners(EventActivityConstants.EVENT_MODULE_NAME, activityWrapper);
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			egoal = new ExperimentGoal();
			egoal.setSuccess(Boolean.FALSE);
			egoal.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
		}
		return egoal;
	}
	
	public static void makeExperimentGoalPrimary(Long experimentId, String goalLinkname) throws ResourceNotFoundException, ZABException {
		HashMap<String, String> hs = new HashMap<String, String>();
		hs.put(GoalConstants.IS_PRIMARY, Boolean.TRUE+"");
		try {			
			Long goalId = Goal.getGoalIdForGoal(goalLinkname);
			if(goalId==null) {
				throw new ZABException(ZABAction.getMessage(GoalConstants.GOAL_NOT_EXISTS,new String[]{goalLinkname})); 
			}
			removePrimaryGoal(experimentId);
			Criteria c1 = new Criteria(new Column(EXPERIMENT_GOAL.TABLE, EXPERIMENT_GOAL.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
			Criteria c2 = new Criteria(new Column(EXPERIMENT_GOAL.TABLE, EXPERIMENT_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
			updateRow(GoalConstants.EXPERIMENT_GOAL_TABLE, EXPERIMENT_GOAL.TABLE, hs, c1.and(c2), GoalConstants.API_MODULE);
			
			ExperimentGoal egoal = new ExperimentGoal();
			egoal.setGoalId(goalId);
			egoal.setExperimentId(experimentId);
			egoal.setIsPrimary(Boolean.TRUE);
			
			ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
			wrapper.setModel(egoal);
			wrapper.setType(OperationType.UPDATE);
			wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
			ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);
			
			//Event Activity Log
			HashMap<String, String> updatedValues = new HashMap<String, String>();
			updatedValues.put(EventActivityConstants.EXPERIMENT_ID, experimentId.toString());
			updatedValues.put(EventActivityConstants.USER_ID, ZABUtil.getCurrentUser().getUserId().toString());
			updatedValues.put(EventActivityConstants.TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
			updatedValues.put(GoalConstants.GOAL_ID, goalId.toString());
			EventActivityWrapper activityWrapper = new EventActivityWrapper();
			activityWrapper.setModule(Module.EXPERIMENT_GOAL);
			activityWrapper.setOperationType(com.zoho.abtest.eventactivity.EventActivityConstants.OperationType.UPDATE);
			activityWrapper.setDbSpace(ZABUtil.getCurrentUserDbSpace());
			activityWrapper.setUpdatedValues(updatedValues);
			ZABNotifier.notifyListeners(EventActivityConstants.EVENT_MODULE_NAME, activityWrapper);
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			if(e instanceof ResourceNotFoundException) {
				throw new ResourceNotFoundException(ZABAction.getMessage(ExperimentConstants.GOAL_NOT_EXISTS_IN_EXPERIMENT));
			}
			if(e instanceof ZABException) {
				throw (ZABException)e;
			}
		}
	}
	
	public static String getPrimaryGoalLNameofExperiment(Long experimentId) {
		String linkname = null;
		try {			
			Criteria c1 = new Criteria(new Column(EXPERIMENT_GOAL.TABLE, EXPERIMENT_GOAL.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
			Criteria c2 = new Criteria(new Column(EXPERIMENT_GOAL.TABLE, EXPERIMENT_GOAL.IS_PRIMARY_GOAL), Boolean.TRUE, QueryConstants.EQUAL);
			Join join1=new Join(EXPERIMENT_GOAL.TABLE,GOAL.TABLE,new String[]{EXPERIMENT_GOAL.GOAL_ID},new String[]{GOAL.GOAL_ID},Join.INNER_JOIN);
			DataObject dobj = getRow(EXPERIMENT_GOAL.TABLE, c1.and(c2), join1);
			if(dobj.containsTable(GOAL.TABLE)) {
				Iterator it = dobj.getRows(GOAL.TABLE);
				while(it.hasNext()) {
					Row row = (Row)it.next();
					linkname = (String)row.get(GOAL.GOAL_LINK_NAME);
				}
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		return linkname;
	}
	
	public static Long getPrimaryGoalLIdofExperiment(Long experimentId) {
		Long id = null;
		try {			
			Criteria c1 = new Criteria(new Column(EXPERIMENT_GOAL.TABLE, EXPERIMENT_GOAL.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
			Criteria c2 = new Criteria(new Column(EXPERIMENT_GOAL.TABLE, EXPERIMENT_GOAL.IS_PRIMARY_GOAL), Boolean.TRUE, QueryConstants.EQUAL);
			Join join1=new Join(EXPERIMENT_GOAL.TABLE,GOAL.TABLE,new String[]{EXPERIMENT_GOAL.GOAL_ID},new String[]{GOAL.GOAL_ID},Join.INNER_JOIN);
			DataObject dobj = getRow(EXPERIMENT_GOAL.TABLE, c1.and(c2), join1);
			if(dobj.containsTable(GOAL.TABLE)) {
				Iterator it = dobj.getRows(GOAL.TABLE);
				while(it.hasNext()) {
					Row row = (Row)it.next();
					id = (Long)row.get(GOAL.GOAL_ID);
				}
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		return id;
	}
	
	
	public static ExperimentGoal createExperimentGoalWithoutEventTrigger(Long experimentId, Long goalId, Boolean isPrimaryGoal) throws Exception {
		ExperimentGoal egoal = null;
		HashMap<String, String> hs = new HashMap<String, String>();
		hs.put(GoalConstants.GOAL_ID, goalId+"");
		hs.put(GoalConstants.EXPERIMENT_ID, experimentId+"");
		if(isPrimaryGoal!=null && isPrimaryGoal) {
			//Remove other primary goals
			removePrimaryGoal(experimentId);
		} else {
			//Make first goal as primary goal
			Criteria c = new Criteria(new Column(EXPERIMENT_GOAL.TABLE, EXPERIMENT_GOAL.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
			isPrimaryGoal = !resourceExists(EXPERIMENT_GOAL.TABLE, c);
		}
		hs.put(GoalConstants.IS_PRIMARY, (isPrimaryGoal==null?Boolean.FALSE:isPrimaryGoal)+"");
		createRow(GoalConstants.EXPERIMENT_GOAL_TABLE, EXPERIMENT_GOAL.TABLE, hs);
		egoal = new ExperimentGoal();
		egoal.setSuccess(Boolean.TRUE);
		egoal.setIsPrimary(isPrimaryGoal);
		egoal.setGoalId(goalId);
		egoal.setExperimentGoalId(experimentId);
		return egoal;
	}
	
	public static boolean isGoalExistsForExperiment(Long experimentId) throws Exception
	{
		boolean isGoalExists = false;
		try
		{
			Criteria c = new Criteria(new Column(EXPERIMENT_GOAL.TABLE, EXPERIMENT_GOAL.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(EXPERIMENT_GOAL.TABLE, c);
			if(!dataObj.isEmpty())
			{
				isGoalExists = true;
			}
		}
		catch(Exception e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			throw e;
		}
		return isGoalExists;
	}
}
