//$Id$
package com.zoho.abtest.goal;

import java.util.ArrayList;





public class PageVisitGoal extends Goal{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String url;
	
	private Integer matchType;
	
	private ArrayList<PageVisitGoal> pageVisitUrls = new ArrayList<PageVisitGoal>();
	
	public String getUrl() {
		return url;
	}

	public void setUrl(String value) {
		this.url = value;
	}

	public Integer getMatchType() {
		return matchType;
	}

	public void setMatchType(Integer matchType) {
		this.matchType = matchType;
	}

	public ArrayList<PageVisitGoal> getPageVisitUrls() {
		return pageVisitUrls;
	}

	public void setPageVisitUrls(ArrayList<PageVisitGoal> pageVisitUrls) {
		this.pageVisitUrls = pageVisitUrls;
	}
}
