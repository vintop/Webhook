//$Id$
package com.zoho.abtest.goal;

public class CustomEventGoal extends Goal{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long eventId;
	
	private String eventLinkname;
	
	private String eventName;

	public Long getEventId() {
		return eventId;
	}

	public void setEventId(Long eventId) {
		this.eventId = eventId;
	}

	public String getEventLinkname() {
		return eventLinkname;
	}

	public void setEventLinkname(String eventLinkname) {
		this.eventLinkname = eventLinkname;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
}
