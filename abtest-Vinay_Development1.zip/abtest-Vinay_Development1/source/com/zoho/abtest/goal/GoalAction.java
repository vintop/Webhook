//$Id$
package com.zoho.abtest.goal;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.json.JSONException;

import com.opensymphony.xwork2.ActionSupport;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.job.CumulativeDayTablePopulation;
import com.zoho.abtest.project.ProjectConstants;
import com.zoho.abtest.report.ReportStatistics;
import com.zoho.abtest.utility.ZABUtil;

public class GoalAction extends ActionSupport implements ServletResponseAware, ServletRequestAware{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = Logger.getLogger(GoalAction.class.getName());

	private HttpServletRequest request;
	
	private HttpServletResponse response;
	
	private String linkname;
	
	public String getLinkname() {
		return linkname;
	}

	public void setLinkname(String linkname) {
		this.linkname = linkname;
	}

	@Override
	public void setServletRequest(HttpServletRequest request) {
		this.request = request;
	}

	@Override
	public void setServletResponse(HttpServletResponse response) {
		this.response = response;
	}
	
	public String execute() throws IOException, JSONException  {
		
		ArrayList<Goal> goals = new ArrayList<Goal>();
		try {			
			switch(ZABAction.getHTTPMethod(request)) {
				case POST:	
					{
						HashMap<String,String> hs = ZABAction.getRequestParser(request).parseGoal(request);
						if(hs.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
							Goal goal = new Goal();
							goal.setSuccess(Boolean.FALSE);
							goal.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
							goals.add(goal);
						}else{
							goals.add(Goal.createGoal(hs,Boolean.FALSE));
						}
					}
					break;
				case GET:
					if(linkname!=null) {
						Goal goal = Goal.getGoalByLinkname(linkname);
						if(goal!=null) {							
							goals.add(goal);
						}
					} else {						
						goals.addAll(Goal.getGoals());
					}
					break;
				case DELETE:
					if(linkname!=null) {						
						Goal goal = Goal.deleteGoal(linkname);
						if(goal!=null) {
							goals.add(goal);
						}
					}
					break;
				case PUT:
					HashMap<String,String> hs = ZABAction.getRequestParser(request).parseGoal(request);
					if(hs.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
						Goal goal = new Goal();
						goal.setSuccess(Boolean.FALSE);
						goal.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
						goals.add(goal);
					}else{
						goals.add(Goal.updateGoal(hs , Boolean.TRUE));
					}
					break;
			}
		}catch(JSONException ex){	
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getInvalidInputFormatException(GoalConstants.API_MODULE_PLURAL));
			return null; 	
		} catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), GoalConstants.API_MODULE_PLURAL));
			return null; 	
		}		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getGoalResponse(request, goals));		
	    return null;	
	}
	
	
}
