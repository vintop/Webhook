//$Id$
package com.zoho.abtest.goal;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.goal.GoalConstants.GoalType;
import com.zoho.abtest.report.ReportArchieveDimensionConstants;
import com.zoho.abtest.utility.ZABUtil;

public class GoalResponse {
	
	private static final Logger LOGGER = Logger.getLogger(GoalResponse.class.getName());
	

	public static String jsonResponse(HttpServletRequest request,ArrayList<Goal> lst) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			Boolean isprojectGoal = Boolean.FALSE;
			String responseModule = GoalConstants.API_MODULE_PLURAL;
			String requestUri =  request.getRequestURI();
			if(requestUri.contains("/projectgoals")){
				String requestUriArr[] = requestUri.split("/");
				 if(requestUriArr[6].equals("projectgoals")){
					 responseModule = GoalConstants.PROJECT_GOALS_PLURAL;
					 isprojectGoal = Boolean.TRUE;
				 }
			
			}
			JSONArray array = getJSONArray(lst , isprojectGoal);		
			
			JSONObject json = ZABResponse.updateMetaInfo(request, responseModule, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}

		return returnBuffer.toString();
	}
	
	public static JSONObject getJSONObject(Goal ld, Boolean isprojectGoal) throws JSONException {
		
		JSONObject goal = new JSONObject();
		goal.put(GoalConstants.GOAL_NAME, ld.getGoalName());
		goal.put(GoalConstants.GOAL_TYPE, ld.getGoalTypeTag());
		goal.put(GoalConstants.GOAL_DESCRIPTION, ld.getGoalDescription());
		goal.put(GoalConstants.PROJECT_ID, ld.getProjectId());
		goal.put(GoalConstants.PROJECT_LINKNAME, ld.getProjectLinkname());
		goal.put(GoalConstants.IS_PRIMARY, ld.getIsPrimaryGoal());
		goal.put(ZABConstants.LINKNAME, ld.getGoalLinkname());
		goal.put(ZABConstants.RESPONSE_STRING, ld.getResponseString());
		goal.put(ZABConstants.STATUS_CODE, ld.getResponseCode());
		goal.put(ZABConstants.SUCCESS, ld.getSuccess());
		goal.put(ExperimentConstants.CREATED_TIME, ld.getCreatedTime());
		
		if(isprojectGoal){
			goal.put(ExperimentConstants.ACTUAL_END_TIME, ld.getActualEndTime());
			goal.put(GoalConstants.GOAL_STATUS, ld.getGoalStatus());
			goal.put(ReportArchieveDimensionConstants.UNIQUE_VISITOR_COUNT, ld.getUniqueVisitors());
			goal.put(ReportArchieveDimensionConstants.UNIQUE_GOAL_ACHIEVED_COUNT, ld.getUniqueGoalAchievedCount());
			goal.put(ReportArchieveDimensionConstants.TIME_SPENT, ld.getAvgTimeToAchieveGoal());
			
			goal.put(ReportArchieveDimensionConstants.TIME_SPENT_SECONDS, GoalReportResponse.convertTimeSpentToReadableFormat(ld.getAvgTimeToAchieveGoal()));
			goal.put(GoalConstants.GOAL_URL, ld.getGoalUrl());
			if(ld.getIncludeUrl()!=null){
				goal.put(GoalConstants.INCLUDE_URLS, new JSONArray(ld.getIncludeUrl()));
			}
			if(ld.getExcludeUrl()!=null){
				goal.put(GoalConstants.EXCLUDE_URLS, new JSONArray( ld.getExcludeUrl()));
			}
		
			HashMap<String, String> formattedTimes = ZABUtil.getDateTimeAllFormatted(ld.getCreatedTime());
			String formattedDateOnly = formattedTimes.get(ZABConstants.DATE);
			goal.put(ExperimentConstants.CREATED_DATE, formattedDateOnly);
			
		}
		if(ld.getGoalTypeTag()!=null) {
			GoalType gtype = GoalType.getGoalTypeById(ld.getGoalTypeTag());
			try {
				switch (gtype) {
				case CUSTOM_EVENT_GOAL:
				{
					CustomEventGoal child = (CustomEventGoal)ld;
					goal.put(GoalConstants.CUSTOM_EVENT_LN, child.getEventLinkname());
					goal.put(GoalConstants.CUSTOM_EVENT_NAME, child.getEventName());
					break;
				}
				case TIME_SPENT_GOAL:
				{
					TimeSpentGoal child = (TimeSpentGoal)ld;
					goal.put(GoalConstants.TIME_THRESHOLD, child.getTimeThreshold());
					break;
				}
				case ELEMENT_CLICK_GOAL:
				{	
					ElementClickGoal child = (ElementClickGoal)ld;
					goal.put(GoalConstants.ELEMENT_CSS_SELECTOR, child.getElementCssSelector());
					break;
				}
				case LINK_CLICK_GOAL:
				{	
					LinkClickGoal child = (LinkClickGoal)ld;
					JSONArray urls = new JSONArray();
					JSONObject url = new JSONObject();
					url.put(GoalConstants.MATCH_TYPE, child.getMatchType());
					url.put(GoalConstants.VALUE, child.getLinkUrl());
					urls.put(url);
					goal.put(GoalConstants.URL, urls);
					break;
				}
//				case ENGAGEMENT_GOAL:
					//Do nothing
//					break;
				case FORM_SUBMIT_GOAL:
				{
					FormSubmitGoal child = (FormSubmitGoal)ld;
					JSONArray urls = new JSONArray();
					JSONObject url = new JSONObject();
					url.put(GoalConstants.MATCH_TYPE, child.getMatchType());
					url.put(GoalConstants.VALUE, child.getSubmitUrl());
					urls.put(url);
					goal.put(GoalConstants.URL, urls);
					break;
				}
				case PAGE_VISIT_GOAL:
				{
					PageVisitGoal child = (PageVisitGoal)ld;
					int size2 = child.getPageVisitUrls().size();
					JSONArray urls = new JSONArray();
					for(int j=0; j<size2; j++) {
						PageVisitGoal pvgoal = child.getPageVisitUrls().get(j);
						JSONObject url = new JSONObject();
						url.put(GoalConstants.MATCH_TYPE, pvgoal.getMatchType());
						url.put(GoalConstants.VALUE, pvgoal.getUrl());
						urls.put(url);
					}
					goal.put(GoalConstants.URL, urls);
					break;
				}
				default:
					break;
				}
			} catch (ClassCastException e) {}

			
		}
		return goal;
	}
	
	public static JSONArray getJSONArray(ArrayList<Goal> lst , Boolean isprojectGoal) throws JSONException {
		JSONArray array = new JSONArray();
		int size =lst.size();
		for (int i=0;i<size;i++) {
			Goal goal = lst.get(i);
			array.put(getJSONObject(goal, isprojectGoal));
		}
		return array;
	}
}
