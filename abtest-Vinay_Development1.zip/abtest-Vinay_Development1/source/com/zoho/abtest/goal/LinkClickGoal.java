//$Id$
package com.zoho.abtest.goal;

public class LinkClickGoal extends Goal{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String linkUrl;
	
	private Integer matchType;

	public String getLinkUrl() {
		return linkUrl;
	}

	public void setLinkUrl(String linkUrl) {
		this.linkUrl = linkUrl;
	}

	public Integer getMatchType() {
		return matchType;
	}

	public void setMatchType(Integer matchType) {
		this.matchType = matchType;
	}

}
