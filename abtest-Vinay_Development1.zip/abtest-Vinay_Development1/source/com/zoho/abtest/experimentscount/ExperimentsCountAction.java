//$Id$
package com.zoho.abtest.experimentscount;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.json.JSONException;

import com.opensymphony.xwork2.ActionSupport;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.customevent.CustomEvent;
import com.zoho.abtest.customevent.CustomEventAction;
import com.zoho.abtest.customevent.CustomEventConstants;
import com.zoho.abtest.project.ProjectConstants;

public class ExperimentsCountAction extends ActionSupport implements ServletResponseAware, ServletRequestAware {
	
private static final Logger LOGGER = Logger.getLogger(ExperimentsCountAction.class.getName());
	
	private static final long serialVersionUID = 1L;
	
	private HttpServletRequest request;
	
	private HttpServletResponse response;
	

	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		request = arg0;
	}

	@Override
	public void setServletResponse(HttpServletResponse arg0) {
		response = arg0;
	}

	public String execute() throws Exception {
		ArrayList<ExperimentsCount> experimentscount = new ArrayList<ExperimentsCount>();
		
		try {			
			switch(ZABAction.getHTTPMethod(request)) {
			
			case GET:
				
				String projectLinkname = request.getParameter(ProjectConstants.PROJECT_LINKNAME);
				if(projectLinkname!=null && !projectLinkname.isEmpty()){
					experimentscount.addAll(ExperimentsCount.fetchCount(projectLinkname));
				}
				else{
					ExperimentsCount exp = new ExperimentsCount();
					exp.setSuccess(Boolean.FALSE);
					exp.setResponseString("Invalid Project Linkname"); //NO I18N
					experimentscount.add(exp);
					LOGGER.log(Level.SEVERE,"Invalid Project Linkname");
				}
				
				break;
			}
			}
			 catch(Exception ex){
				ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ProjectConstants.EXPERIMENT_DETAILS));
				return null; 	
			}	
		
		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExperimentsCountresponse(request, experimentscount));	

		return null;
		
	}
	
}
