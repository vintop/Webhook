//$Id$
package com.zoho.abtest.experimentscount;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;
import com.zoho.abtest.project.ProjectConstants;

public class ExperimentsCountResponse {
	
	public static String jsonResponse(HttpServletRequest request,ArrayList<ExperimentsCount> lst) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(lst);			
			JSONObject json = ZABResponse.updateMetaInfo(request, ProjectConstants.EXPERIMENT_DETAILS, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){}
		return returnBuffer.toString();
	}
	
	private static JSONObject getJSONObject(ExperimentsCount ld) throws JSONException {
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("experiments_details", ExperimentsCount.getHashMapAsJson(ld.getExpDetails()));
		jsonObj.put(ZABConstants.SUCCESS, ld.getSuccess());
		jsonObj.put(ZABConstants.RESPONSE_STRING, ld.getResponseString());
		return jsonObj;
	}
	
	public static JSONArray getJSONArray(ArrayList<ExperimentsCount> lst) throws JSONException {
		JSONArray array = new JSONArray();
		int size =lst.size();
		for (int i=0;i<size;i++) {
			ExperimentsCount ld=lst.get(i);
			if(ld!=null) {				
				array.put(getJSONObject(ld));
			}
		}
		return array;
	}
}
