//$Id$
package com.zoho.abtest.experimentscount;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.json.JSONObject;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.DataSet;
import com.adventnet.ds.query.GroupByClause;
import com.adventnet.ds.query.GroupByColumn;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.ds.query.SelectQueryImpl;
import com.adventnet.ds.query.Table;
import com.adventnet.mfw.bean.BeanUtil;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.AC_EXPERIMENT;
import com.zoho.abtest.EVENTS;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.GOAL;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.experiment.ABSplitExperiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.goal.GoalConstants;
import com.zoho.abtest.heatmaps.HeatmapAction;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.project.ProjectConstants;
import com.zoho.abtest.utility.DataSetWrapper;
import com.zoho.abtest.utility.ZABUserBean;
import com.zoho.abtest.utility.ZABUtil;

public class ExperimentsCount extends ZABModel{
	
	private HashMap<String,String> expDetails;
	private static final Logger LOGGER = Logger.getLogger(ExperimentsCount.class.getName());
	
	
	public HashMap<String, String> getExpDetails() {
		return expDetails;
	}

	public void setExpDetails(HashMap<String, String> expDetails) {
		this.expDetails = expDetails;
	}



	public static ArrayList<ExperimentsCount> fetchCount(String project_linkname) {
		
		ArrayList<ExperimentsCount> expCount = new ArrayList<ExperimentsCount>();
		 
		ExperimentsCount exp = new ExperimentsCount();
		
		Long project_id = Project.getProjectId(project_linkname);
		
		if(project_id == null) {
			exp.setSuccess(Boolean.FALSE);
			exp.setResponseString(ProjectConstants.PROJECT_NOT_EXISTS);
			expCount.add(exp);
			LOGGER.log(Level.SEVERE,ProjectConstants.PROJECT_NOT_EXISTS);
		}
		else{
			HashMap<String,String> expHash = fetchExperimentsCount(project_id);
			expHash = fetchGoalsCount(project_id,expHash);
			exp.setExpDetails(expHash);
			exp.setSuccess(Boolean.TRUE);
			expCount.add(exp);
		}
		
		return expCount;
	}
	
	public static HashMap<String,String> fetchExperimentsCount(Long project_id) {
		
		HashMap<String,String> expHash1 = new HashMap<String,String>();
		
		for (ExperimentConstants.ExperimentType expType : ExperimentConstants.ExperimentType.values()) {
		    expHash1.put(expType.name().toLowerCase(), "0");
		}
		expHash1.put(GoalConstants.PROJECT_GOALS_PLURAL,"0");
		
		Table table = new Table(EXPERIMENT.TABLE);
		SelectQuery selectQuery = new SelectQueryImpl(table);
		
		Criteria c = null;
		Criteria c2 = null;
		Criteria c3 = null;
		c = new Criteria (new Column(EXPERIMENT.TABLE,EXPERIMENT.PROJECT_ID),project_id, QueryConstants.EQUAL);
		c2 = new Criteria(new Column(EXPERIMENT.TABLE,EXPERIMENT.IS_ACTIVE),Boolean.TRUE,QueryConstants.EQUAL);
		c3 = c.and(c2);

		
		selectQuery.setCriteria(c3);
		
		GroupByColumn g1 = new GroupByColumn(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_TYPE), false);
		List<GroupByColumn> glist = new ArrayList<GroupByColumn>();
		glist.add(g1);
		GroupByClause gClause = new GroupByClause(glist);
		selectQuery.setGroupByClause(gClause);
		
		
		selectQuery.addSelectColumn(Column.getColumn(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_TYPE));
		Column expCountCol = Column.getColumn(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_TYPE).count();
		expCountCol.setColumnAlias("EXPERIMENT_COUNT");
		selectQuery.addSelectColumn(expCountCol);
		
		try {
		ZABUserBean bean= (ZABUserBean)BeanUtil.lookup(ZABUserBean.BEAN_NAME, ZABUtil.getCurrentUserDbSpace());
		bean.executeQuery(selectQuery, new DataSetWrapper() {
			@Override
			public void execute(DataSet ds) throws Exception {
				while(ds.next()) {	
					Integer expType = (Integer)ds.getValue(EXPERIMENT.EXPERIMENT_TYPE);
					Integer expCount = (Integer)ds.getValue("EXPERIMENT_COUNT");
					expHash1.put(ExperimentConstants.ExperimentType.getExperimentTypeByNumber(expType).name().toLowerCase(), expCount.toString());
					}
			}
		});
		} catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		return expHash1;
	}
	

	public static JSONObject getHashMapAsJson(HashMap<String,String> hs) {
		
		JSONObject expJson = new JSONObject();
		
		
		try {
			Iterator it = hs.entrySet().iterator(); 
			while (it.hasNext()) {  
				Map.Entry pair = (Map.Entry)it.next();  
				expJson.put(pair.getKey().toString(), Integer.parseInt(pair.getValue().toString()));
				}
		} catch(Exception e) {
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		return expJson;
	}
	
	public static HashMap<String,String> fetchGoalsCount(Long project_id,HashMap<String,String> hs) {
		
		
		Criteria c = null;
		Criteria c2 = null;
		Criteria c3 = null;
		try{
			if(project_id!=null) {
				c = new Criteria(new Column(GOAL.TABLE,GOAL.PROJECT_ID),project_id,QueryConstants.EQUAL);
				c2 = new Criteria(new Column(GOAL.TABLE,GOAL.IS_PROJECT_LEVEL),Boolean.TRUE,QueryConstants.EQUAL);
				c3 = c.and(c2);
				
				Table table = new Table(GOAL.TABLE);
				SelectQuery selectQuery = new SelectQueryImpl(table);
				selectQuery.setCriteria(c3);
				
				Column expCountCol = Column.getColumn(GOAL.TABLE, GOAL.GOAL_ID).count();
				expCountCol.setColumnAlias("GOAL_COUNT");
				selectQuery.addSelectColumn(expCountCol);
				
				
				try {
					ZABUserBean bean= (ZABUserBean)BeanUtil.lookup(ZABUserBean.BEAN_NAME, ZABUtil.getCurrentUserDbSpace());
					bean.executeQuery(selectQuery, new DataSetWrapper() {
						@Override
						public void execute(DataSet ds) throws Exception {
							while(ds.next()) {	
								Integer goalCount = (Integer)ds.getValue("GOAL_COUNT"); //NO I18N
								hs.put(GoalConstants.PROJECT_GOALS_PLURAL, goalCount.toString());
								}
						}
					});
					} catch(Exception e){
						LOGGER.log(Level.SEVERE,e.getMessage(),e);
					}
				
			}
		}catch(Exception e){
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
		
			return hs;
		}
}
