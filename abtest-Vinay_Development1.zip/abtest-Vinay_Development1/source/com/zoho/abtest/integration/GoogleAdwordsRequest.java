//$Id$
package com.zoho.abtest.integration;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;

import com.zoho.abtest.common.ZABRequest;

public class GoogleAdwordsRequest extends ZABRequest {

	@Override
	public void updateFromRequest(HashMap<String, String> map,
			HttpServletRequest request) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void specificValidation(HashMap<String, String> map,
			HttpServletRequest request) throws IOException, JSONException {
		// TODO Auto-generated method stub
		
	}

	

}
