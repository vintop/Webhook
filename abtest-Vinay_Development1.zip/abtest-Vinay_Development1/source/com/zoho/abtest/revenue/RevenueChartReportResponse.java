//$Id$
package com.zoho.abtest.revenue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;
import com.zoho.abtest.report.CumulativeReportConstants;
import com.zoho.abtest.report.ReportArchieveDimensionConstants;

public class RevenueChartReportResponse {

	public static String jsonResponse(HttpServletRequest request,ArrayList<RevenueChartReport> lst) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(lst);			
			JSONObject json = ZABResponse.updateMetaInfo(request, RevenueConstants.API_MODULE, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){
			ex.toString();
		}
		return returnBuffer.toString();
	}

	public static JSONArray getJSONArray(ArrayList<RevenueChartReport> lst) throws JSONException {
		JSONArray array = new JSONArray();
		int size =lst.size();
		for (int i=0;i<size;i++) {
			RevenueChartReport ld=lst.get(i);
			JSONObject jsonObj = getJSONArray(ld);
			array.put(jsonObj);
		}
		return array;
	}
	public static JSONObject getJSONArray(RevenueChartReport ld) throws JSONException {

	
		JSONObject jsonObj = new JSONObject();
	
		JSONArray revenueArray = new JSONArray();
		HashMap<Long, Double> revenue=ld.getRevenue();
		Set<Long> revenueKeys = revenue.keySet();
		Iterator<Long> revenueeItr = revenueKeys.iterator();
		while(revenueeItr.hasNext()){
			Long key = revenueeItr.next();
			Double value  =  revenue.get(key);
			JSONObject json = new JSONObject ();
			json.put(ReportArchieveDimensionConstants.TIME, key);
			json.put(RevenueConstants.REVENUE, value);
			revenueArray.put(json);
			
		}
		jsonObj.put(RevenueConstants.REVENUE, revenueArray);

		JSONArray visitorsArray = new JSONArray();
		HashMap<Long, Long> visitors=ld.getVisitors();
		Set<Long> visitorsKeys = visitors.keySet();
		Iterator<Long> visitorsItr = visitorsKeys.iterator();
		while(visitorsItr.hasNext()){
			Long key = visitorsItr.next();
			Long value  =  visitors.get(key);
			JSONObject json = new JSONObject ();
			json.put(ReportArchieveDimensionConstants.TIME, key);
			json.put(ReportArchieveDimensionConstants.UNIQUE_VISITOR_COUNT, value);
			
			visitorsArray.put(json);
		}
		jsonObj.put(CumulativeReportConstants.VISITORS, visitorsArray);
		
		
		JSONArray revenuePerVisitorArray = new JSONArray();
		HashMap<Long, Double> revenuePerVisiotr=ld.getRevenuePerVisitor();
		Set<Long> revenuePerVisitorKeys = revenuePerVisiotr.keySet();
		Iterator<Long> revenueePerVisitorItr = revenuePerVisitorKeys.iterator();
		while(revenueePerVisitorItr.hasNext()){
			Long key = revenueePerVisitorItr.next();
			Double value  =  revenuePerVisiotr.get(key);
			JSONObject json = new JSONObject ();
			json.put(ReportArchieveDimensionConstants.TIME, key);
			json.put(RevenueConstants.REVENUE_PER_VISITOR, value);
			revenuePerVisitorArray.put(json);
			
		}
		jsonObj.put(RevenueConstants.REVENUE_PER_VISITOR, revenuePerVisitorArray);

		
		
		JSONArray revenuePerPayingVisitorArray = new JSONArray();
		HashMap<Long, Double> revenuePerPayingVisitor=ld.getRevenuePerPayingVisitor();
		Set<Long> revenuePerPayingVisitorKeys = revenuePerPayingVisitor.keySet();
		Iterator<Long> revenueePerPayingVisitorItr = revenuePerPayingVisitorKeys.iterator();
		while(revenueePerPayingVisitorItr.hasNext()){
			Long key = revenueePerPayingVisitorItr.next();
			Double value  =  revenuePerPayingVisitor.get(key);
			JSONObject json = new JSONObject ();
			json.put(ReportArchieveDimensionConstants.TIME, key);
			json.put(RevenueConstants.REVENUE_PER_PAYING_VISITOR, value);
			revenuePerPayingVisitorArray.put(json);
			
		}
		jsonObj.put(RevenueConstants.REVENUE_PER_PAYING_VISITOR, revenuePerPayingVisitorArray);

		
		
		JSONArray purchaseConversionRatesArray = new JSONArray();
		HashMap<Long, Double> pruchaseConversionRate=ld.getRevenuePerPurchase();
		Set<Long> pruchaseConversionRateKeys = pruchaseConversionRate.keySet();
		Iterator<Long> pruchaseConversionRateItr = pruchaseConversionRateKeys.iterator();
		while(pruchaseConversionRateItr.hasNext()){
			Long key = pruchaseConversionRateItr.next();
			Double value  =  pruchaseConversionRate.get(key);
			JSONObject json = new JSONObject ();
			json.put(ReportArchieveDimensionConstants.TIME, key);
			json.put(RevenueConstants.REVENUE_PER_PURCHASE, value);
			purchaseConversionRatesArray.put(json);
			
		}
		jsonObj.put(RevenueConstants.REVENUE_PER_PURCHASE, purchaseConversionRatesArray);

		
		JSONArray purchasesArray = new JSONArray();
		HashMap<Long, Long> purchases=ld.getPurchases();
		Set<Long> purchasesKeys = purchases.keySet();
		Iterator<Long> purchasesItr = purchasesKeys.iterator();
		while(purchasesItr.hasNext()){
			Long key = purchasesItr.next();
			Long value  =  purchases.get(key);
			JSONObject json = new JSONObject ();
			json.put(ReportArchieveDimensionConstants.TIME, key);
			json.put(RevenueConstants.PURCAHSES, value);
			purchasesArray.put(json);
			
		}
		jsonObj.put(RevenueConstants.PURCAHSES, purchasesArray);
		
		JSONArray payingVisitorsArray = new JSONArray();
		HashMap<Long, Long> payingVisitors=ld.getPayingVisitors();
		Set<Long> payingVisitorsKeys = payingVisitors.keySet();
		Iterator<Long> payingVisitorssItr = payingVisitorsKeys.iterator();
		while(payingVisitorssItr.hasNext()){
			Long key = payingVisitorssItr.next();
			Long value  =  payingVisitors.get(key);
			JSONObject json = new JSONObject ();
			json.put(ReportArchieveDimensionConstants.TIME, key);
			json.put(RevenueConstants.PAYING_VISITORS_COUNT, value);
			payingVisitorsArray.put(json);
			
		}
		jsonObj.put(RevenueConstants.PAYING_VISITORS_COUNT, payingVisitorsArray);


		jsonObj.put(ZABConstants.SUCCESS, ld.getSuccess());
		return jsonObj;
	
	}
	

}
