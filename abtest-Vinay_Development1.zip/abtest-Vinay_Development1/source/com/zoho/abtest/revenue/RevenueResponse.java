//$Id$
package com.zoho.abtest.revenue;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;
import com.zoho.abtest.report.ReportArchieveDimensionConstants;

public class RevenueResponse {

	private static final Logger LOGGER = Logger.getLogger(RevenueResponse.class.getName());

	public static String jsonResponse(HttpServletRequest request,ArrayList<RevenueReport> lst) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(lst);			
			JSONObject json = ZABResponse.updateMetaInfo(request, RevenueConstants.API_MODULE, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		return returnBuffer.toString();
	}

	public static JSONArray getJSONArray(ArrayList<RevenueReport> lst) throws JSONException {
		JSONArray array = new JSONArray();
		int size =lst.size();
		for (int i=0;i<size;i++) {
			RevenueReport ld=lst.get(i);
			
			array.put(singleRevenueResponse(ld));
		}
		return array;
	}
	public static JSONObject singleRevenueResponse(RevenueReport ld){
		
		JSONObject jsonObj = new JSONObject();

		try{
			jsonObj.put(ReportArchieveDimensionConstants.UNIQUE_VISITOR_COUNT, ld.getVisitors());
			jsonObj.put(RevenueConstants.REVENUE, ld.getRevenue());
			jsonObj.put(RevenueConstants.PAYING_VISITORS_COUNT, ld.getUniquePayingVisitors());
			jsonObj.put(RevenueConstants.PURCAHSES, ld.getTotalPurchases());
			
			//PRV RESPONSE
			
			if(ld.getRevenuePerVisitor()!=null){
				jsonObj.put(RevenueConstants.REVENUE_PER_VISITOR, Math.round(ld.getRevenuePerVisitor()*100.0)/100.0);
			}
			if(ld.getRevPerVisitorConfidence()!=null){
				jsonObj.put(RevenueConstants.REVENUE_PER_VISITOR_CONFIDENCE,Math.round(ld.getRevPerVisitorConfidence()*100.0)/100.0 );
			}
			if(ld.getRevPerVisitorImprovement() !=null){
				jsonObj.put(RevenueConstants.REVENUE_PER_VISITOR_IMPROVEMENT, Math.round(ld.getRevPerVisitorImprovement()*10000.0)/100.0);
			}
			if(ld.getRevPerVisitorSignificance()!=null){
			
				jsonObj.put(RevenueConstants.REVENUE_PER_VISITOR_SIGNIFICANCE,Math.round(ld.getRevPerVisitorSignificance()*10000.0)/100 );
			}
			
			jsonObj.put(RevenueConstants.REVENUE_PER_VISITOR_CONCLUSION, ld.getRevPerVisitorConclusion());
			jsonObj.put(RevenueConstants.REVENUE_PER_VISITOR_IS_WINNER, ld.getRevPerVisitorIsWinner());
			jsonObj.put(RevenueConstants.REVENUE_PER_VISITOR_IS_LOSER, ld.getRevPerVisitorIsLoser());
			jsonObj.put(RevenueConstants.REVENUE_PER_VISITOR_IS_INCONCLUSIVE, ld.getRevPerVisitorIsInconclusive());
			jsonObj.put(RevenueConstants.REVENUE_PER_VISITOR_DECISION, ld.getRevPerVisitorDecision());
			
			
			//RPPV RESPONSE
			
			if(ld.getRevenuePerPayingVisitor()!=null){
				jsonObj.put(RevenueConstants.REVENUE_PER_PAYING_VISITOR, Math.round(ld.getRevenuePerPayingVisitor()*100.0)/100.0);
			}
			if(ld.getRevPerPayingVisitorConfidence()!=null){
				jsonObj.put(RevenueConstants.REVENUE_PER_PAYING_VISITOR_CONFIDENCE,Math.round(ld.getRevPerPayingVisitorConfidence()*100.0)/100.0 );
			}
			if(ld.getRevPerPayingVisitorImprovement() !=null){
				jsonObj.put(RevenueConstants.REVENUE_PER_PAYING_VISITOR_IMPROVEMENT, Math.round(ld.getRevPerPayingVisitorImprovement()*10000.0)/100.0);
			}
			if(ld.getRevPerPayingVisitorSignificance()!=null){
				jsonObj.put(RevenueConstants.REVENUE_PER_PAYING_VISITOR_SIGNIFICANCE,Math.round(ld.getRevPerPayingVisitorSignificance()*10000.0)/100 );
			}
			
			jsonObj.put(RevenueConstants.REVENUE_PER_PAYING_VISITOR_CONCLUSION, ld.getRevPerPayingVisitorConclusion());
			jsonObj.put(RevenueConstants.REVENUE_PER_PAYING_VISITOR_IS_WINNER, ld.getRevPerPayingVisitorIsWinner());
			jsonObj.put(RevenueConstants.REVENUE_PER_PAYING_VISITOR_IS_LOSER, ld.getRevPerPayingVisitorIsLoser());
			jsonObj.put(RevenueConstants.REVENUE_PER_PAYING_VISITOR_IS_INCONCLUSIVE, ld.getRevPerPayingVisitorIsInconclusive());
			jsonObj.put(RevenueConstants.REVENUE_PER_PAYING_VISITOR_DECISION, ld.getRevPerPayingVisitorDecision());
			
			
			//RPP PERSPONSE
			if(ld.getRevenuePerPurchase()!=null){
				jsonObj.put(RevenueConstants.REVENUE_PER_PURCHASE, Math.round(ld.getRevenuePerPurchase()*100.0)/100.0);
			}
			if(ld.getRevPerPurchaseConfidence()!=null){
				jsonObj.put(RevenueConstants.REVENUE_PER_PURCHASE_CONFIDENCE,Math.round(ld.getRevPerPurchaseConfidence()*100.0)/100.0 );
			}
			if(ld.getRevPerPurchaseImprovement() !=null){
				jsonObj.put(RevenueConstants.REVENUE_PER_PURCHASE_IMPROVEMENT, Math.round(ld.getRevPerPurchaseImprovement()*10000.0)/100.0);
			}
			if(ld.getRevPerPurchaseSignificance()!=null){
				jsonObj.put(RevenueConstants.REVENUE_PER_PURCHASE_SIGNIFICANCE,Math.round(ld.getRevPerPurchaseSignificance()*10000.0)/100 );
			}
			
			jsonObj.put(RevenueConstants.REVENUE_PER_PURCHASE_CONCLUSION, ld.getRevPerPurchaseConclusion());
			jsonObj.put(RevenueConstants.REVENUE_PER_PURCHASE_IS_WINNER, ld.getRevPerPurchaseIsWinner());
			jsonObj.put(RevenueConstants.REVENUE_PER_PURCHASE_IS_LOSER, ld.getRevPerPurchaseIsLoser());
			jsonObj.put(RevenueConstants.REVENUE_PER_PURCHASE_IS_INCONCLUSIVE, ld.getRevPerPurchaseIsInconclusive());
			jsonObj.put(RevenueConstants.REVENUE_PER_PURCHASE_DECISION, ld.getRevPerPurchaseDecision());
			

			jsonObj.put(ZABConstants.SUCCESS, ld.getSuccess());
				
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		return jsonObj;
	}




}
