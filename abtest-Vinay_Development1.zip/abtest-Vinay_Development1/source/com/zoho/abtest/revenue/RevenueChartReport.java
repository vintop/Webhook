//$Id$
package com.zoho.abtest.revenue;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.NavigableSet;
import java.util.StringTokenizer;
import java.util.TreeSet;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.json.JSONArray;

import com.adventnet.mfw.bean.BeanUtil;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.report.ChartReport;
import com.zoho.abtest.report.ReportArchieveDimensionConstants;
import com.zoho.abtest.report.ReportConstants;
import com.zoho.abtest.report.ReportStatistics;
import com.zoho.abtest.utility.ZABChartBean;
import com.zoho.abtest.utility.ZABUserBean;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.abtest.variation.Variation;
public class RevenueChartReport extends ZABModel {


	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(ChartReport.class.getName());

	private HashMap<Long, Double> revenue = new HashMap<Long, Double>();
	private HashMap<Long, Long> visitors  =  new HashMap<Long,Long>();
	private HashMap<Long, Long> purchases = new HashMap<Long, Long>();
	private HashMap<Long, Long> payingVisitors = new HashMap<Long, Long>();

	private HashMap<Long, Double> revenuePerVisitor = new HashMap<Long, Double>();
	private HashMap<Long, Double> revenuePerPayingVisitor = new HashMap<Long, Double>();
	private HashMap<Long, Double> revenuePerPurchase = new HashMap<Long, Double>();

	public HashMap<Long, Long> getVisitors() {
		return visitors;
	}

	public void setVisitors(HashMap<Long, Long> visitors) {
		this.visitors = visitors;
	}

	public HashMap<Long, Double> getRevenue() {
		return revenue;
	}

	public void setRevenue(HashMap<Long, Double> revenue) {
		this.revenue = revenue;
	}

	public HashMap<Long, Double> getRevenuePerVisitor() {
		return revenuePerVisitor;
	}

	public void setRevenuePerVisitor(HashMap<Long, Double> revenuePerVisitor) {
		this.revenuePerVisitor = revenuePerVisitor;
	}

	public HashMap<Long, Double> getRevenuePerPayingVisitor() {
		return revenuePerPayingVisitor;
	}

	public void setRevenuePerPayingVisitor(
			HashMap<Long, Double> revenuePerPayingVisitor) {
		this.revenuePerPayingVisitor = revenuePerPayingVisitor;
	}

	public HashMap<Long, Long> getPurchases() {
		return purchases;
	}

	public void setPurchases(HashMap<Long, Long> purchases) {
		this.purchases = purchases;
	}

	public HashMap<Long, Long> getPayingVisitors() {
		return payingVisitors;
	}

	public void setPayingVisitors(HashMap<Long, Long> payingVisitors) {
		this.payingVisitors = payingVisitors;
	}

	public HashMap<Long, Double> getRevenuePerPurchase() {
		return revenuePerPurchase;
	}

	public void setRevenuePerPurchase(HashMap<Long, Double> revenuePerPurchase) {
		this.revenuePerPurchase = revenuePerPurchase;
	}

	
	public static HashMap<Long , RevenueChartReport> chartCalculations(HashMap<Long, HashMap<Long, HashMap<String, Long>>> visitorMeta ,HashMap<String,  HashMap<String, String>> revenuehs , Long expId ,ArrayList<Long> timeValues){

		HashMap<String,  HashMap<String, String>> reporths = new HashMap<String,  HashMap<String, String>> (); 
		HashMap<Long , RevenueChartReport> chartReports = new HashMap<Long , RevenueChartReport> ();
		ArrayList<Variation> variations  = new ArrayList<Variation>();
		variations =  Variation.getVariationsOfExperiment(expId);
		Collections.sort(timeValues);
		
		for(int i =0;i<variations.size();i++){
			Long varId = variations.get(i).getVariationId();
			for(int j=0;j<timeValues.size();j++){
				Long time  =  timeValues.get(j);
				String key = varId+":"+time;
				HashMap<String , String> hs = new HashMap<String, String>();
				hs.put(ReportArchieveDimensionConstants.UNIQUE_COUNT, "0");
				hs.put(RevenueConstants.REVENUE, "0");
				hs.put(RevenueConstants.PURCAHSES, "0");
				hs.put(RevenueConstants.PAYING_VISITORS_COUNT, "0");
				reporths.put(key, hs);
			}
		}

	
		for(Long varId:visitorMeta.keySet()){
			HashMap<Long, HashMap<String,Long>> timeHs = visitorMeta.get(varId);
			for(Long time:timeHs.keySet()){
				String key = varId+":"+time;
				HashMap<String, Long> hs = timeHs.get(time);
				Long uniqueCount =  hs.get(ReportArchieveDimensionConstants.UNIQUE_COUNT);
				reporths.get(key).put(ReportArchieveDimensionConstants.UNIQUE_COUNT, uniqueCount.toString());

			}
		}
		
		for(String revkey:	revenuehs.keySet()){
			HashMap<String, String> hs = revenuehs.get(revkey);
			String rev = hs.get(RevenueConstants.REVENUE);
			String purchases = hs.get(RevenueConstants.PURCAHSES);
			String payingVisitors = hs.get(RevenueConstants.PAYING_VISITORS_COUNT);
			
			String[] arr = revkey.split(":");
			Long time = Long.parseLong(arr[1]);
			time = findNearestTimeValue(timeValues, time);
			revkey = arr[0]+":"+time;
			reporths.get(revkey).put(RevenueConstants.REVENUE, rev);
			reporths.get(revkey).put(RevenueConstants.PURCAHSES, purchases);
			reporths.get(revkey).put(RevenueConstants.PAYING_VISITORS_COUNT, payingVisitors);
		}

		for(int i=0;i<variations.size();i++){

			RevenueChartReport revenueChart  = new RevenueChartReport();
			Long variationId = variations.get(i).getVariationId();
		

			for(int k=0;k<timeValues.size();k++){

				Long time  = timeValues.get(k);
				String key =  variationId+":"+time;
				HashMap<String,String> hs =  reporths.get(key);

				Long purchases  = Long.parseLong(hs.get(RevenueConstants.PURCAHSES));
				Double revenue  = Double.parseDouble(hs.get(RevenueConstants.REVENUE));
				Long uniqueVisitors  = Long.parseLong(hs.get(ReportArchieveDimensionConstants.UNIQUE_COUNT));
				Long payingVisitors  = Long.parseLong(hs.get(RevenueConstants.PAYING_VISITORS_COUNT));

				Double revenuePerVisitor  = ReportStatistics.getConversionRate(uniqueVisitors, revenue);
				Double revenuePerPayingVisitor  = ReportStatistics.getConversionRate(payingVisitors, revenue);
				Double revenuePerPurchase = ReportStatistics.getConversionRate(purchases, revenue);

				revenueChart.getRevenue().put(time, revenue);
				revenueChart.getVisitors().put(time, uniqueVisitors);
				revenueChart.getPurchases().put(time, purchases);
				revenueChart.getPayingVisitors().put(time, payingVisitors);


				revenueChart.getRevenuePerVisitor().put(time, revenuePerVisitor);
				revenueChart.getRevenuePerPayingVisitor().put(time, revenuePerPayingVisitor);
				revenueChart.getRevenuePerPurchase().put(time, revenuePerPurchase);
				revenueChart.setSuccess(Boolean.TRUE);

			}

			chartReports.put(variationId, revenueChart);

		}

		return chartReports;
	}

	public static HashMap<String, HashMap<String, String>> convertRevenueGoalHourEntriesToDay(HashMap<String, HashMap<String, String>> revenueMeta)
	{
		HashMap<String, HashMap<String, String>> returnvalue = new HashMap<String, HashMap<String, String>>();
		//Convert to day START
		for(Map.Entry<String, HashMap<String, String>> details:revenueMeta.entrySet())
		{
			String key = details.getKey();
			StringTokenizer str  = new StringTokenizer(key,":");
			String varId = str.nextToken();
			Long time  = new Long(str.nextToken());
			Long date = ZABUtil.getDateInLongFromTime(time);
			String dayKey =  varId+":"+date;
		
			HashMap<String, String> valueHs = revenueMeta.get(key);
			String purchases  = valueHs.get(RevenueConstants.PURCAHSES);
			String  revenue = valueHs.get(RevenueConstants.REVENUE);
			
			if(returnvalue.containsKey(dayKey)){

				HashMap<String, String> dayValueHs = returnvalue.get(dayKey);
				Long pur = Long.parseLong(purchases)+Long.parseLong(dayValueHs.get(RevenueConstants.PURCAHSES));
				Double rev = Double.parseDouble(revenue)+Long.parseLong(dayValueHs.get(RevenueConstants.REVENUE));
				dayValueHs.put(RevenueConstants.PURCAHSES ,pur.toString());
				dayValueHs.put(RevenueConstants.REVENUE, rev.toString());

			
			}else{

				HashMap<String, String> dayValueHs = new HashMap<String, String>();
				dayValueHs.put(RevenueConstants.PURCAHSES, purchases);
				dayValueHs.put(RevenueConstants.REVENUE, revenue);
				returnvalue.put(dayKey, dayValueHs);
			
			}
		}

		return returnvalue;

	}
	public static Long findNearestTimeValue(ArrayList<Long> timePoints, Long time){
		
		Long nearestTime = time;
		if(timePoints.contains(time)){
			return nearestTime;
		}else{
			Collections.sort(timePoints);
			NavigableSet<Long> ns= new TreeSet<>(timePoints);
			nearestTime =  ns.higher(time);
			if(nearestTime == null){
				nearestTime = timePoints.get(timePoints.size()-1);
			}
		}
		return nearestTime;
	}

}
