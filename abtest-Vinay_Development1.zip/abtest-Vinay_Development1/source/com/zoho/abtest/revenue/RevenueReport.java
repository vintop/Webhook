//$Id$
package com.zoho.abtest.revenue;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONObject;

import com.adventnet.mfw.bean.BeanUtil;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.experiment.ABSplitExperiment;
import com.zoho.abtest.report.CumulativeReportConstants;
import com.zoho.abtest.report.ReportArchieveDimensionConstants;
import com.zoho.abtest.report.ReportConstants;
import com.zoho.abtest.report.ReportStatistics;
import com.zoho.abtest.report.CumulativeReportConstants.DecisionType;
import com.zoho.abtest.utility.ZABRevenueBean;
import com.zoho.abtest.utility.ZABUserBean;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.abtest.variation.Variation;
import com.zoho.abtest.variation.VariationConstants;

public class RevenueReport extends ZABModel{
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(RevenueReport.class.getName());

	


	/*Revenue Per Visitor Calc*/
	private Double revenuePerVisitor;
	private Double revPerVisitorImprovement;
	private Double revPerVisitorSignificance;
	private Double revPerVisitorConfidence;
	private String revPerVisitorConclusion;
	private Boolean revPerVisitorIsWinner;
	private Boolean revPerVisitorIsLoser;
	private Boolean revPerVisitorIsInconclusive;
	private Integer revPerVisitorDecision;

	/*Revenue Per Paying Visitor Calc*/
	private Double revenuePerPayingVisitor;
	private Double revPerPayingVisitorImprovement;
	private Double revPerPayingVisitorSignificance;
	private Double revPerPayingVisitorConfidence;
	private String revPerPayingVisitorConclusion;
	private Boolean revPerPayingVisitorIsWinner;
	private Boolean revPerPayingVisitorIsLoser;
	private Boolean revPerPayingVisitorIsInconclusive;
	private Integer revPerPayingVisitorDecision;
	
	/*Revenue Per Purchase Calc*/
	private Double revenuePerPurchase;
	private Double revPerPurchaseImprovement;
	private Double revPerPurchaseSignificance;
	private Double revPerPurchaseConfidence;
	private String revPerPurchaseConclusion;
	private Boolean revPerPurchaseIsWinner;
	private Boolean revPerPurchaseIsLoser;
	private Boolean revPerPurchaseIsInconclusive;
	private Integer revPerPurchaseDecision;
	

	/*Data necessary to do Reveneue Calculations */

	
	private Long visitors;		// unique visitors coming to the variation 
	private Double revenue ; 	// total revenue for variation 
	private Long totalPurchases;		// Total PURCHASES MADE IN THE TIME RANGE
	private Long uniquePayingVisitors;



	
	public Long getVisitors() {
		return visitors;
	}
	public void setVisitors(Long visitors) {
		this.visitors = visitors;
	}
	public Double getRevenue() {
		return revenue;
	}
	public void setRevenue(Double revenue) {
		this.revenue = revenue;
	}

	
	public Double getRevenuePerVisitor() {
		return revenuePerVisitor;
	}
	public void setRevenuePerVisitor(Double revenuePerVisitor) {
		this.revenuePerVisitor = revenuePerVisitor;
	}
	public Long getTotalPurchases() {
		return totalPurchases;
	}
	public void setTotalPurchases(Long totalPurchases) {
		this.totalPurchases = totalPurchases;
	}
	public Long getUniquePayingVisitors() {
		return uniquePayingVisitors;
	}
	public void setUniquePayingVisitors(Long uniquePayingVisitors) {
		this.uniquePayingVisitors = uniquePayingVisitors;
	}


	public Double getRevPerVisitorImprovement() {
		return revPerVisitorImprovement;
	}
	public void setRevPerVisitorImprovement(Double revPerVisitorImprovement) {
		this.revPerVisitorImprovement = revPerVisitorImprovement;
	}
	public Double getRevPerVisitorSignificance() {
		return revPerVisitorSignificance;
	}
	public void setRevPerVisitorSignificance(Double revPerVisitorSignificance) {
		this.revPerVisitorSignificance = revPerVisitorSignificance;
	}
	public Double getRevPerVisitorConfidence() {
		return revPerVisitorConfidence;
	}
	public void setRevPerVisitorConfidence(Double revPerVisitorConfidence) {
		this.revPerVisitorConfidence = revPerVisitorConfidence;
	}
	public String getRevPerVisitorConclusion() {
		return revPerVisitorConclusion;
	}
	public void setRevPerVisitorConclusion(String revPerVisitorConclusion) {
		this.revPerVisitorConclusion = revPerVisitorConclusion;
	}
	public Boolean getRevPerVisitorIsWinner() {
		return revPerVisitorIsWinner;
	}
	public void setRevPerVisitorIsWinner(Boolean revPerVisitorIsWinner) {
		this.revPerVisitorIsWinner = revPerVisitorIsWinner;
	}
	public Double getRevenuePerPayingVisitor() {
		return revenuePerPayingVisitor;
	}
	public void setRevenuePerPayingVisitor(Double revenuePerPayingVisitor) {
		this.revenuePerPayingVisitor = revenuePerPayingVisitor;
	}
	public Double getRevPerPayingVisitorImprovement() {
		return revPerPayingVisitorImprovement;
	}
	public void setRevPerPayingVisitorImprovement(
			Double revPerPayingVisitorImprovement) {
		this.revPerPayingVisitorImprovement = revPerPayingVisitorImprovement;
	}
	public Double getRevPerPayingVisitorSignificance() {
		return revPerPayingVisitorSignificance;
	}
	public void setRevPerPayingVisitorSignificance(
			Double revPerPayingVisitorSignificance) {
		this.revPerPayingVisitorSignificance = revPerPayingVisitorSignificance;
	}
	public Double getRevPerPayingVisitorConfidence() {
		return revPerPayingVisitorConfidence;
	}
	public void setRevPerPayingVisitorConfidence(
			Double revPerPayingVisitorConfidence) {
		this.revPerPayingVisitorConfidence = revPerPayingVisitorConfidence;
	}
	public String getRevPerPayingVisitorConclusion() {
		return revPerPayingVisitorConclusion;
	}
	public void setRevPerPayingVisitorConclusion(
			String revPerPayingVisitorConclusion) {
		this.revPerPayingVisitorConclusion = revPerPayingVisitorConclusion;
	}
	public Boolean getRevPerPayingVisitorIsWinner() {
		return revPerPayingVisitorIsWinner;
	}
	public void setRevPerPayingVisitorIsWinner(Boolean revPerPayingVisitorIsWinner) {
		this.revPerPayingVisitorIsWinner = revPerPayingVisitorIsWinner;
	}
	public Double getRevenuePerPurchase() {
		return revenuePerPurchase;
	}
	public void setRevenuePerPurchase(Double revenuePerPurchase) {
		this.revenuePerPurchase = revenuePerPurchase;
	}
	public Double getRevPerPurchaseImprovement() {
		return revPerPurchaseImprovement;
	}
	public void setRevPerPurchaseImprovement(Double revPerPurchaseImprovement) {
		this.revPerPurchaseImprovement = revPerPurchaseImprovement;
	}
	public Double getRevPerPurchaseSignificance() {
		return revPerPurchaseSignificance;
	}
	public void setRevPerPurchaseSignificance(Double revPerPurchaseSignificance) {
		this.revPerPurchaseSignificance = revPerPurchaseSignificance;
	}
	public Double getRevPerPurchaseConfidence() {
		return revPerPurchaseConfidence;
	}
	public void setRevPerPurchaseConfidence(Double revPerPurchaseConfidence) {
		this.revPerPurchaseConfidence = revPerPurchaseConfidence;
	}
	public String getRevPerPurchaseConclusion() {
		return revPerPurchaseConclusion;
	}
	public void setRevPerPurchaseConclusion(String revPerPurchaseConclusion) {
		this.revPerPurchaseConclusion = revPerPurchaseConclusion;
	}
	public Boolean getRevPerPurchaseIsWinner() {
		return revPerPurchaseIsWinner;
	}
	public void setRevPerPurchaseIsWinner(Boolean revPerPurchaseIsWinner) {
		this.revPerPurchaseIsWinner = revPerPurchaseIsWinner;
	}
	public Boolean getRevPerPurchaseIsLoser() {
		return revPerPurchaseIsLoser;
	}
	public void setRevPerPurchaseIsLoser(Boolean revPerPurchaseIsLoser) {
		this.revPerPurchaseIsLoser = revPerPurchaseIsLoser;
	}
	public Boolean getRevPerVisitorIsLoser() {
		return revPerVisitorIsLoser;
	}
	public void setRevPerVisitorIsLoser(Boolean revPerVisitorIsLoser) {
		this.revPerVisitorIsLoser = revPerVisitorIsLoser;
	}
	public Boolean getRevPerPayingVisitorIsLoser() {
		return revPerPayingVisitorIsLoser;
	}
	public void setRevPerPayingVisitorIsLoser(Boolean revPerPayingVisitorIsLoser) {
		this.revPerPayingVisitorIsLoser = revPerPayingVisitorIsLoser;
	}

	public Boolean getRevPerVisitorIsInconclusive() {
		return revPerVisitorIsInconclusive;
	}
	public void setRevPerVisitorIsInconclusive(Boolean revPerVisitorIsInconclusive) {
		this.revPerVisitorIsInconclusive = revPerVisitorIsInconclusive;
	}
	public Integer getRevPerVisitorDecision() {
		return revPerVisitorDecision;
	}
	public void setRevPerVisitorDecision(Integer revPerVisitorDecision) {
		this.revPerVisitorDecision = revPerVisitorDecision;
	}
	public Boolean getRevPerPayingVisitorIsInconclusive() {
		return revPerPayingVisitorIsInconclusive;
	}
	public void setRevPerPayingVisitorIsInconclusive(
			Boolean revPerPayingVisitorIsInconclusive) {
		this.revPerPayingVisitorIsInconclusive = revPerPayingVisitorIsInconclusive;
	}
	public Integer getRevPerPayingVisitorDecision() {
		return revPerPayingVisitorDecision;
	}
	public void setRevPerPayingVisitorDecision(Integer revPerPayingVisitorDecision) {
		this.revPerPayingVisitorDecision = revPerPayingVisitorDecision;
	}
	public Boolean getRevPerPurchaseIsInconclusive() {
		return revPerPurchaseIsInconclusive;
	}
	public void setRevPerPurchaseIsInconclusive(Boolean revPerPurchaseIsInconclusive) {
		this.revPerPurchaseIsInconclusive = revPerPurchaseIsInconclusive;
	}
	public Integer getRevPerPurchaseDecision() {
		return revPerPurchaseDecision;
	}
	public void setRevPerPurchaseDecision(Integer revPerPurchaseDecision) {
		this.revPerPurchaseDecision = revPerPurchaseDecision;
	}
	public static HashMap<Long , RevenueReport>  revenueCalculation(HashMap<Long , RevenueReport> revenueMeta , Long expId,Long originalVariationId){
		
		Long originalVisitors=  0l;
		Double originalRevenue =  0d;            
		Long originalPurchases = 0l;
		Long originalPayingVisitors  = 0l;

		Integer variationCount  = revenueMeta.size();
		RevenueReport original  = revenueMeta.get(originalVariationId);
		originalVisitors= original.getVisitors();
		originalRevenue = original.getRevenue();
		originalPurchases = original.getTotalPurchases();
		originalPayingVisitors = original.getUniquePayingVisitors();

		
		ArrayList<Long> revPerVisitorWinners = new ArrayList<Long>();
		ArrayList<Long> revPerVisitorLosers = new ArrayList<Long>();
		ArrayList<Long> revPerVisitorInconclusive = new ArrayList<Long>();
		
		ArrayList<Long> revPerPayingVisitorWinners = new ArrayList<Long>();
		ArrayList<Long> revPerPayingVisitorLosers = new ArrayList<Long>();
		ArrayList<Long> revPerPayingVisitorInconclusive = new ArrayList<Long>();
		
		
		ArrayList<Long> revPerPurchaseWinners = new ArrayList<Long>();
		ArrayList<Long> revPerPurchaseLosers = new ArrayList<Long>();
		ArrayList<Long> revPerPurchaseInconclusive = new ArrayList<Long>();
		
		// ITERATE RESULTS AND DO CALCULATIONS TO GET RESULTS
		Integer expSignifcance  =ABSplitExperiment.getABSplitExperiment(expId).getStatisticalSignificance();			
		Set<Long> keys  = revenueMeta.keySet();
		Iterator<Long> keysItr = keys.iterator();
		
		//TO CALCULATE TOTAL REVENUE 
		
		Double totalRevenuePerVisitor = 0d;
		Double totalRevenuePerPayingVisitor = 0d;
		Double totalRevenuePerPurchase = 0d;
		while(keysItr.hasNext()){
			Long variationId  = keysItr.next();
			RevenueReport report = revenueMeta.get(variationId);
			Long varVisitors  = report.getVisitors();
			Long varpayingVisitors = report.getUniquePayingVisitors();
			Long varpurchases  = report.getTotalPurchases();
			if(varVisitors>0){
				Double varRevenue  = report.getRevenue();
				Double RevenuePerVisitor  = ReportStatistics.getConversionRate(varVisitors, varRevenue);
				Double revenuePerPayingVisitor = ReportStatistics.getConversionRate(varpayingVisitors, varRevenue);
				Double revenuePerPurchase = ReportStatistics.getConversionRate(varpurchases, varRevenue);
				totalRevenuePerVisitor+=RevenuePerVisitor;
				totalRevenuePerPayingVisitor+=revenuePerPayingVisitor;
				totalRevenuePerPurchase+=revenuePerPurchase;
			}
			
		}
		
		
		keysItr = keys.iterator();
		while(keysItr.hasNext()){
			Long variationId  = keysItr.next();
			RevenueReport report = revenueMeta.get(variationId);

			//if(originalVisitors >0){			
				Long varVisitors  = report.getVisitors();
				Long varpayingVisitors = report.getUniquePayingVisitors();
				Long varpurchases  = report.getTotalPurchases();
				if(varVisitors>0){
					Double varRevenue  = report.getRevenue();
					
					
					//REVENUE PER VISITORS CALCULATIONS
					Double RevenuePerVisitor  = ReportStatistics.getConversionRate(varVisitors, varRevenue);
					Double revPerVisitorConfidence =  ReportStatistics.getConfidenceLevelFromConversionRate(varVisitors, roundToTwoDecimalPlaces(RevenuePerVisitor/totalRevenuePerVisitor), expSignifcance);
					revPerVisitorConfidence = revPerVisitorConfidence*totalRevenuePerVisitor;
					report.setRevenuePerVisitor(RevenuePerVisitor);
					report.setRevPerVisitorConfidence(revPerVisitorConfidence);
					
					//REVENUE PER PAYING VISITORS CALCULATIONS
					Double revenuePerPayingVisitor = ReportStatistics.getConversionRate(varpayingVisitors, varRevenue);
					Double revPerPyingVisitorConfidence =  ReportStatistics.getConfidenceLevelFromConversionRate(varpayingVisitors, roundToTwoDecimalPlaces(revenuePerPayingVisitor/totalRevenuePerPayingVisitor), expSignifcance);
					revPerPyingVisitorConfidence =  revPerPyingVisitorConfidence*totalRevenuePerPayingVisitor;
					report.setRevenuePerPayingVisitor(revenuePerPayingVisitor);
					report.setRevPerPayingVisitorConfidence(revPerPyingVisitorConfidence);
					
					//REVENUE PER  PURCHASE CALCULATIONS
					Double revenuePerPurchase = ReportStatistics.getConversionRate(varpurchases, varRevenue);
					Double revPerPurchaseConfidence =  ReportStatistics.getConfidenceLevelFromConversionRate(varpurchases, roundToTwoDecimalPlaces(revenuePerPurchase/totalRevenuePerPurchase), expSignifcance);
					revPerPurchaseConfidence = revPerPurchaseConfidence*totalRevenuePerPurchase;
					report.setRevenuePerPurchase(revenuePerPurchase);
					report.setRevPerPurchaseConfidence(revPerPurchaseConfidence);


					if(!variationId.equals(originalVariationId) && originalVisitors>0){
						
						// REVNUE PER VISITOR CALCULATIONS
						
						Double originalRevPerVisitor = ReportStatistics.getConversionRate(originalVisitors, originalRevenue);
						
						Double revPerVisitorSignificance  = ReportStatistics.getStatisticalSignificance(roundToTwoDecimalPlaces(originalRevPerVisitor/totalRevenuePerVisitor),roundToTwoDecimalPlaces(RevenuePerVisitor/totalRevenuePerVisitor), originalVisitors,varVisitors);
						Double revPerVisitorImprovement  = ReportStatistics.getImprovement( originalRevPerVisitor, RevenuePerVisitor);
						report.setRevPerVisitorSignificance(revPerVisitorSignificance);
						report.setRevPerVisitorImprovement(revPerVisitorImprovement);
						Boolean revPerVisitorisSignificant = ReportStatistics.isSignificant(expSignifcance, revPerVisitorSignificance);
						String revPerVisitorconclusion = ReportStatistics.isWinner(revPerVisitorisSignificant,revPerVisitorImprovement,varVisitors,originalVisitors,originalRevenue,expSignifcance,roundToTwoDecimalPlaces(RevenuePerVisitor/totalRevenuePerVisitor));
						report.setRevPerVisitorConclusion(revPerVisitorconclusion);

						if(revPerVisitorconclusion.equals(CumulativeReportConstants.WINNER)){
							revPerVisitorWinners.add(variationId);
						}else if(revPerVisitorconclusion.equals(CumulativeReportConstants.LOSER)){
							revPerVisitorLosers.add(variationId);
						}else if(revPerVisitorconclusion.equals(CumulativeReportConstants.INCOCLUSIVE)){
							report.setRevPerVisitorIsInconclusive(Boolean.TRUE);
							revPerVisitorInconclusive.add(variationId);
						}
						
						// REVNUE PER PAYING VISITOR CALCULATIONS
						Double originalRevPerPayingVisitor = ReportStatistics.getConversionRate(originalPayingVisitors, originalRevenue);
						
						
						Double revPerPayingVisitorSignificance  = ReportStatistics.getStatisticalSignificance(roundToTwoDecimalPlaces(originalRevPerPayingVisitor/totalRevenuePerPayingVisitor),roundToTwoDecimalPlaces(revenuePerPayingVisitor/totalRevenuePerPayingVisitor), originalPayingVisitors,varpayingVisitors);
						Double revPerPayingVisitorImprovement  = ReportStatistics.getImprovement(originalRevPerPayingVisitor, revenuePerPayingVisitor);
						report.setRevPerPayingVisitorSignificance(revPerPayingVisitorSignificance);
						report.setRevPerPayingVisitorImprovement(revPerPayingVisitorImprovement);
						Boolean revPerPayingVisitorisSignificant = ReportStatistics.isSignificant(expSignifcance, revPerPayingVisitorSignificance);
						String revPerPyingVisitorconclusion = ReportStatistics.isWinner(revPerPayingVisitorisSignificant,revPerPayingVisitorImprovement,varpayingVisitors,originalPayingVisitors,originalRevenue,expSignifcance,roundToTwoDecimalPlaces(revenuePerPayingVisitor/totalRevenuePerPayingVisitor));
						report.setRevPerPayingVisitorConclusion(revPerPyingVisitorconclusion);
						
						if(revPerPyingVisitorconclusion.equals(CumulativeReportConstants.WINNER)){
							revPerPayingVisitorWinners.add(variationId);
						}else if(revPerPyingVisitorconclusion.equals(CumulativeReportConstants.LOSER)){
							revPerPayingVisitorLosers.add(variationId);
						}
						else if(revPerPyingVisitorconclusion.equals(CumulativeReportConstants.INCOCLUSIVE)){
							report.setRevPerPayingVisitorIsInconclusive(Boolean.TRUE);
							revPerPayingVisitorInconclusive.add(variationId);
						}
						
						
						// REVNUE PER PURCHASE CALCULATIONS
						Double originalRevPerPurchase = ReportStatistics.getConversionRate(originalPurchases, originalRevenue);
						
						
						Double revPerPurchaseSignificance  = ReportStatistics.getStatisticalSignificance(roundToTwoDecimalPlaces(originalRevPerPurchase/totalRevenuePerPurchase),roundToTwoDecimalPlaces(revenuePerPurchase/totalRevenuePerPurchase), originalPurchases, varpurchases);
						Double revPerPurchaseImprovement  = ReportStatistics.getImprovement(originalRevPerPurchase, revenuePerPurchase);
						report.setRevPerPurchaseSignificance(revPerPurchaseSignificance);
						report.setRevPerPurchaseImprovement(revPerPurchaseImprovement);
						Boolean revPerPurchaseisSignificant = ReportStatistics.isSignificant(expSignifcance, revPerPurchaseSignificance);
						String revPerPurchaseconclusion = ReportStatistics.isWinner(revPerPurchaseisSignificant,revPerPurchaseImprovement,varpurchases,originalPurchases,originalRevenue,expSignifcance,roundToTwoDecimalPlaces(revenuePerPurchase/totalRevenuePerPurchase));
						report.setRevPerPurchaseConclusion(revPerPurchaseconclusion);
						
						if(revPerPurchaseconclusion.equals(CumulativeReportConstants.WINNER)){
							revPerPurchaseWinners.add(variationId);
						}else if(revPerPurchaseconclusion.equals(CumulativeReportConstants.LOSER)){
							revPerPurchaseLosers.add(variationId);
						}
						else if(revPerPurchaseconclusion.equals(CumulativeReportConstants.INCOCLUSIVE)){
							report.setRevPerPurchaseIsInconclusive(Boolean.TRUE);
							revPerPurchaseInconclusive.add(variationId);
						}
						
					}
				}

			//}
			report.setRevPerVisitorIsWinner(Boolean.FALSE);
			report.setRevPerPayingVisitorIsWinner(Boolean.FALSE);
			report.setRevPerPurchaseIsWinner(Boolean.FALSE);
			report.setRevPerVisitorIsLoser(Boolean.FALSE);
			report.setRevPerPayingVisitorIsLoser(Boolean.FALSE);
			report.setRevPerPurchaseIsLoser(Boolean.FALSE);
			report.setRevPerVisitorIsInconclusive(Boolean.FALSE);
			report.setRevPerPayingVisitorIsInconclusive(Boolean.FALSE);
			report.setRevPerPurchaseIsInconclusive(Boolean.FALSE);
			
			report.setSuccess(Boolean.TRUE);
		}
		Boolean rpvHasWinner = Boolean.FALSE;
		Boolean rpvIsInconclusive = Boolean.FALSE;
		if(revPerVisitorWinners.size()>=1){
			rpvHasWinner=Boolean.TRUE;
			Long revPerVisitorWinner = findTopWinningVariationId(revPerVisitorWinners,revenueMeta);
			revPerVisitorWinners.remove(revPerVisitorWinner);
			revenueMeta.get(revPerVisitorWinner).setRevPerVisitorIsWinner(Boolean.TRUE);
			revenueMeta = setEmptyConclusiopn(revPerVisitorWinners,revenueMeta,"setRevPerVisitorConclusion");		// NO I18N
			
		}
		
		if(revPerVisitorLosers.size()>=1){
			if(revPerVisitorLosers.size() ==  (variationCount-1)){
				Double minSignificance  = null;
				for(int i=0;i<revPerVisitorLosers.size();i++){
					Long varId  = revPerVisitorLosers.get(i);
					RevenueReport report = revenueMeta.get(varId);
					report.setRevPerVisitorConclusion(" ");
					Double rpvSignigicacne = report.getRevPerVisitorSignificance();
					if(minSignificance == null){
						minSignificance = rpvSignigicacne;
					}else if(rpvSignigicacne < minSignificance){
						minSignificance = rpvSignigicacne;
					}
					
				}
				
				original.setRevPerVisitorIsWinner(Boolean.TRUE);
				original.setRevPerVisitorConclusion(CumulativeReportConstants.WINNER);
				original.setRevPerVisitorSignificance(minSignificance);
				rpvHasWinner=Boolean.TRUE;
				
			}else{
				if(rpvHasWinner){
					revenueMeta = setEmptyConclusiopn(revPerVisitorLosers,revenueMeta,"setRevPerVisitorConclusion");// NO I18N
				}else{
					Long revPerVisitorLoser = findTopLosingVariationId(revPerVisitorLosers,revenueMeta);
					revPerVisitorLosers.remove(revPerVisitorLoser);
					revenueMeta.get(revPerVisitorLoser).setRevPerVisitorIsLoser(Boolean.TRUE);
					revenueMeta = setEmptyConclusiopn(revPerVisitorLosers,revenueMeta,"setRevPerVisitorConclusion");// NO I18N
				}
			}
		}
		
		if(revPerVisitorInconclusive.size() == variationCount-1){
			rpvIsInconclusive = Boolean.TRUE;
		}
		
		Integer rpvdecision  =findDecision(rpvHasWinner,rpvIsInconclusive);
		
		Boolean rppvHasWinner = Boolean.FALSE;
		Boolean rppvIsInconclusive = Boolean.FALSE;
		// REVENUE PER PAYING VISIOTR CONCLUSION TOUCH
		if(revPerPayingVisitorWinners.size()>=1){
			rppvHasWinner=Boolean.TRUE;
			Long revPerPayingVisitorWinner = findTopWinningVariationId(revPerPayingVisitorWinners,revenueMeta);
			
			revPerPayingVisitorWinners.remove(revPerPayingVisitorWinner);
			revenueMeta.get(revPerPayingVisitorWinner).setRevPerPayingVisitorIsWinner(Boolean.TRUE);
			revenueMeta = setEmptyConclusiopn(revPerPayingVisitorWinners,revenueMeta,"setRevPerPayingVisitorConclusion");// NO I18N
		}
		
		if(revPerPayingVisitorLosers.size()>=1){
			if(revPerPayingVisitorLosers.size() ==  (variationCount-1)){
				Double minSignificance  = null;
				for(int i=0;i<revPerPayingVisitorLosers.size();i++){
					Long varId  = revPerPayingVisitorLosers.get(i);
					RevenueReport report = revenueMeta.get(varId);
					report.setRevPerPayingVisitorConclusion(" ");
					Double rppvSignigicacne = report.getRevPerPayingVisitorSignificance();
					if(minSignificance == null){
						minSignificance = rppvSignigicacne;
					}else if(rppvSignigicacne < minSignificance){
						minSignificance = rppvSignigicacne;
					}
					
				}
				original.setRevPerPayingVisitorIsWinner(Boolean.TRUE);
				original.setRevPerPayingVisitorConclusion(CumulativeReportConstants.WINNER);
				original.setRevPerPayingVisitorSignificance(minSignificance);
				rppvHasWinner= Boolean.TRUE;
				
			}else{
				if(rppvHasWinner){
					revenueMeta = setEmptyConclusiopn(revPerPayingVisitorLosers,revenueMeta,"setRevPerPayingVisitorConclusion");// NO I18N
				}else{
					
					Long revPerPayingVisitorLoser = findTopLosingVariationId(revPerPayingVisitorLosers,revenueMeta);
					revPerPayingVisitorLosers.remove(revPerPayingVisitorLoser);
					revenueMeta.get(revPerPayingVisitorLoser).setRevPerPayingVisitorIsLoser(Boolean.TRUE);
					revenueMeta = setEmptyConclusiopn(revPerPayingVisitorLosers,revenueMeta,"setRevPerPayingVisitorConclusion");// NO I18N
					
				}
			}
			
		}

		if(revPerPayingVisitorInconclusive.size() == variationCount-1){
			rppvIsInconclusive = Boolean.TRUE;
		}
		
		Integer rppvdecision  = findDecision(rppvHasWinner,rppvIsInconclusive);
		
	//RPP CONCLUSION TOUCH

		Boolean rppHasWinner = Boolean.FALSE;
		Boolean rppIsInconclusive = Boolean.FALSE;
		if(revPerPurchaseWinners.size()>=1){
			rppHasWinner=Boolean.TRUE;
			Long revPerPurchaseWinner = findTopWinningVariationId(revPerPurchaseWinners,revenueMeta);
			revPerPurchaseWinners.remove(revPerPurchaseWinner);
			revenueMeta.get(revPerPurchaseWinner).setRevPerPurchaseIsWinner(Boolean.TRUE);
			revenueMeta = setEmptyConclusiopn(revPerPurchaseWinners,revenueMeta,"setRevPerPurchaseConclusion");// NO I18N
			
		}
		
		if(revPerPurchaseLosers.size()>=1){
			if(revPerPurchaseLosers.size() ==  (variationCount-1)){
				Double minSignificance  = null;
				for(int i=0;i<revPerPurchaseLosers.size();i++){
					Long varId  = revPerPurchaseLosers.get(i);
					RevenueReport report = revenueMeta.get(varId);
					report.setRevPerPurchaseConclusion(" ");
					Double rppSignigicacne = report.getRevPerPurchaseSignificance();
					if(minSignificance == null){
						minSignificance = rppSignigicacne;
					}else if(rppSignigicacne < minSignificance){
						minSignificance = rppSignigicacne;
					}
					
				}
				original.setRevPerPurchaseIsWinner(Boolean.TRUE);
				original.setRevPerPurchaseConclusion(CumulativeReportConstants.WINNER);
				original.setRevPerPurchaseSignificance(minSignificance);
				rppHasWinner= Boolean.TRUE;
				
			}else{
				if(rppHasWinner){
					revenueMeta = setEmptyConclusiopn(revPerVisitorLosers,revenueMeta,"setRevPerPurchaseConclusion");// NO I18N
				}else{
					
					Long revPerPurchaseLoser = findTopLosingVariationId(revPerPurchaseLosers,revenueMeta);
					revPerPurchaseLosers.remove(revPerPurchaseLoser);
					revenueMeta.get(revPerPurchaseLoser).setRevPerPurchaseIsLoser(Boolean.TRUE);
					revenueMeta = setEmptyConclusiopn(revPerPurchaseLosers,revenueMeta,"setRevPerPurchaseConclusion");// NO I18N
				}
			}
			
		}
		if(revPerPurchaseInconclusive.size() == variationCount-1){
			rppIsInconclusive = Boolean.TRUE;
		}
		
		Integer rppdecision  = findDecision(rppHasWinner,rppIsInconclusive);
		revenueMeta = updateDecisionInMeta(revenueMeta,rppdecision,rpvdecision,rppvdecision);
		return revenueMeta;
	}
	public static Long findTopWinningVariationId(ArrayList<Long> winners , HashMap<Long , RevenueReport> revenueMeta ){
		Double WinningImprovement = null;
		Long Winner = null;
		for(int i=0;i<winners.size();i++){
			Long varId  = winners.get(i);
			RevenueReport report = revenueMeta.get(varId);
			Double improvement = report.getRevPerVisitorImprovement();
			if(WinningImprovement == null){
				WinningImprovement = improvement;
				Winner=varId;
			}else if (WinningImprovement<improvement){
				WinningImprovement=improvement;
				Winner=varId;
			}
		}
		return Winner;
	}
	public static Long findTopLosingVariationId(ArrayList<Long> losers , HashMap<Long , RevenueReport> revenueMeta){
		Double LosingImprovement = null;
		Long Loser = null;
		for(int i=0;i<losers.size();i++){
			Long varId  = losers.get(i);
			RevenueReport report = revenueMeta.get(varId);
			Double improvement = report.getRevPerPurchaseImprovement();
			if(LosingImprovement == null){
				LosingImprovement = improvement;
				Loser=varId;
			}else if (LosingImprovement>improvement){
				LosingImprovement=improvement;
				Loser=varId;
			}
		}
		return Loser;
	}
	public static Integer findDecision(Boolean isWinner, Boolean isInconclusive){
		Integer decision  = DecisionType.LEADING_VARIANT.getDecisionTypeId();
		if(isWinner){
			decision  = DecisionType.WINNER.getDecisionTypeId();
		
		}else if(isInconclusive){
			decision  = DecisionType.INCONCLUSIVE.getDecisionTypeId();
			
		}
		return decision;
	}
	public static HashMap<Long , RevenueReport> updateDecisionInMeta(HashMap<Long , RevenueReport> revenueMeta, Integer rppDecision, Integer rpvDecision, Integer rppvDecision){
		
		Set<Long> keys = revenueMeta.keySet();
		Iterator<Long> itr = keys.iterator();
		while(itr.hasNext()){
			Long key = itr.next();
			RevenueReport rev = revenueMeta.get(key);
			rev.setRevPerPurchaseDecision(rppDecision);
			rev.setRevPerVisitorDecision(rpvDecision);
			rev.setRevPerPayingVisitorDecision(rppvDecision);
		}
		
		return revenueMeta;
		
	}
	
	public static HashMap<Long , RevenueReport>  setEmptyConclusiopn(ArrayList<Long> variationIds,HashMap<Long , RevenueReport> revenueMeta, String methodname ) {
	
		try{
			for(int i=0;i<variationIds.size();i++){
				Long varId  = variationIds.get(i);
				RevenueReport report = revenueMeta.get(varId);
				
				Method method = report.getClass().getMethod(methodname, String.class);
				method.invoke(report, " ");
				
			}
		}catch(Exception e){
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		
		return revenueMeta;
		
	}



	public static 	HashMap<Long , RevenueReport>  multiSegmentCriteriaReport(Long expId, String multisegmentCriteria ,Long startTime, Long endTime, List<Long> variationIds ) throws Exception{
		HashMap<Long , RevenueReport> revenueMeta = new 	HashMap<Long , RevenueReport> ();

		Long goalId = ABSplitExperiment.getRevenueGoalOfExperiment(expId);
		if(goalId == null ){
			throw new ZABException("Revenue Goal is not added to the Experiment");	// NO I18N
		}
		ZABUserBean userBean = (ZABUserBean)BeanUtil.lookup("ZABUserBean", ZABUtil.getCurrentUserDbSpace());
		HashMap<String, Object> multisegmentCriteriaHs = userBean.generateMultisegmentCriteria(multisegmentCriteria);
		ZABRevenueBean revenueBean = (ZABRevenueBean)BeanUtil.lookup("ZABRevenueBean", ZABUtil.getCurrentUserDbSpace());
		revenueMeta =revenueBean.getMultiSegmentGoalReportDetails(expId, startTime, endTime, multisegmentCriteriaHs,variationIds,goalId);

		return revenueMeta;
	}

	public static String converSegmentToMultiSegmentCriteira( String segmentType, JSONArray segmentValueCodes,String dynamicAttrLinkName){

		String segmentCriteria = "";
		try{
			JSONObject innercondition = new JSONObject();
			innercondition.put("type", segmentType);
			innercondition.put("operator", "1");
			innercondition.put("values", segmentValueCodes);
			if(dynamicAttrLinkName!=null){
				innercondition.put(ReportConstants.ATTRIBUTE_NAME,dynamicAttrLinkName);
			}


			JSONArray innerConditionArray = new JSONArray();
			innerConditionArray.put(innercondition);

			JSONObject outerConditionObj = new JSONObject();
			outerConditionObj.put("conditions", innerConditionArray);
			outerConditionObj.put("condition_type", "1");

			JSONArray outerArray = new JSONArray();
			outerArray.put(outerConditionObj);

			JSONObject rootObj = new JSONObject();
			rootObj.put("condition_type", "1");
			rootObj.put("conditions", outerArray);

			segmentCriteria= rootObj.toString();
		}catch(Exception e){
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}


		return segmentCriteria;

	}

	public static HashMap<Long , RevenueReport> combineVisitorMetaAndRevenueMeta(ArrayList<HashMap<String, String>> visitorMeta ,HashMap<Long , RevenueReport> revenueMeta, ArrayList<Variation> variations ){
	
		HashMap<Long , RevenueReport> retrunMeta = new HashMap<Long , RevenueReport>();
		for(int i=0;i<variations.size();i++ ){
			Long varId = variations.get(i).getVariationId();
			
			if(revenueMeta.containsKey(varId)){
				retrunMeta.put(varId,revenueMeta.get(varId));
			}else{
				RevenueReport report= new RevenueReport();
				report.setVisitors(0l);
				report.setRevenue(0d);
				report.setUniquePayingVisitors(0l);
				report.setTotalPurchases(0l);
				retrunMeta.put(varId, report);
			}
		}
		
		for(int i = 0;i<visitorMeta.size();i++){
			HashMap<String, String> hs = visitorMeta.get(i);
			Long varId = Long.parseLong(hs.get(VariationConstants.VARIATION_ID));
			Long visitors = Long.parseLong(hs.get(ReportArchieveDimensionConstants.UNIQUE_COUNT));
			retrunMeta.get(varId).setVisitors(visitors);
		}
		return retrunMeta;
	}
	public static Double roundToTwoDecimalPlaces(Double value){
		return Math.round(value*100.0)/100.0;
	}
	
}
