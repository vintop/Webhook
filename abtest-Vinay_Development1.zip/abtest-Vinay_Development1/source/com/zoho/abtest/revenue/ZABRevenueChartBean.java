//$Id$
package com.zoho.abtest.revenue;

import java.util.HashMap;


public interface ZABRevenueChartBean {

	
	//public ArrayList<HashMap<String, String>> getDataPointGoalReportDetails(boolean isLatestInforequired,boolean isCombinedTableInforequired,Long expId, Long startTime, Long endTime);
	public HashMap<String , HashMap<String, String>> getDataPointHourGoalReportDetails(Long expId,  Long startTime, Long endTime   );
//	public ArrayList<HashMap<String, String>> getDataPointMultiSegmentGoalReportDetails(Long expId,Long startTime, Long endTime,boolean isLatestInforequired,boolean isCombinedTableInforequired,HashMap<String, Object> multisegmentCriteriaHs);
	public HashMap<String , HashMap<String, String>> getDataPointMultiSegmentHourGoalReportDetails(Long expId,Long startTime, Long endTime,HashMap<String, Object> multisegmentCriteriaHs,Long goalId  );
	

	
}
