//$Id$
package com.zoho.abtest.revenue;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.zoho.abtest.REVENUE_REPORT_DAY;
import com.zoho.abtest.REVENUE_REPORT_HOUR;
import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.report.CumulativeReportConstants;
import com.zoho.abtest.report.ReportArchieveDimensionConstants;

public class RevenueConstants {
	
	public static final String API_MODULE = "revenue"; //No I18N
	
	public static final String REVENUE_RAW = "revenue_raw";		//NO I18N
	
	public static final String REVENUE = "revenue";				//NO I18N
	public static final String PURCAHSES = "purcahses";		// NO I18N
	public static final String PAYING_VISITORS_COUNT = "paying_visitors_count";			// NO I18N
	public static final String VISITORS = "visitors" ;		// NO I18N
	
	
	
	public static final String REVENUE_REPORT_DAY_ID  = "revenue_report_day_id";	// NO I18N	
	public static final String REVENUE_REPORT_HOUR_ID  = "revenue_report_hour_id";	// NO I18N	
	
	// REVENUE PER VISITOR RELATED CONSTANTS
	
	public static final String REVENUE_PER_VISITOR = "revenue_per_visitor";				//NO I18N
	public static final String REVENUE_PER_VISITOR_CONFIDENCE = "rpv_confidence";				//NO I18N
	public static final String REVENUE_PER_VISITOR_SIGNIFICANCE = "rpv_significance";				//NO I18N
	public static final String REVENUE_PER_VISITOR_IMPROVEMENT = "rpv_improvement";				//NO I18N
	public static final String REVENUE_PER_VISITOR_CONCLUSION = "rpv_conclusion";				//NO I18N
	public static final String REVENUE_PER_VISITOR_IS_WINNER = "rpv_is_winner";				//NO I18N
	public static final String REVENUE_PER_VISITOR_IS_LOSER = "rpv_is_loser";				//NO I18N
	public static final String REVENUE_PER_VISITOR_IS_INCONCLUSIVE = "rpv_isInconclusive";				//NO I18N
	public static final String REVENUE_PER_VISITOR_DECISION = "rpv_decision";				//NO I18N

	
	// REVENUE PER PAYING VISITOR RELATED CONSTANTS
	
	public static final String REVENUE_PER_PAYING_VISITOR = "revenue_per_paying_visitor";				//NO I18N
	public static final String REVENUE_PER_PAYING_VISITOR_CONFIDENCE = "rppv_confidence";				//NO I18N
	public static final String REVENUE_PER_PAYING_VISITOR_SIGNIFICANCE = "rppv_significance";				//NO I18N
	public static final String REVENUE_PER_PAYING_VISITOR_IMPROVEMENT = "rppv_improvement";				//NO I18N
	public static final String REVENUE_PER_PAYING_VISITOR_CONCLUSION = "rppv_conclusion";				//NO I18N
	public static final String REVENUE_PER_PAYING_VISITOR_IS_WINNER = "rppv_is_winner";				//NO I18N
	public static final String REVENUE_PER_PAYING_VISITOR_IS_LOSER = "rppv_is_loser";				//NO I18N
	public static final String REVENUE_PER_PAYING_VISITOR_IS_INCONCLUSIVE = "rppv_isInconclusive";				//NO I18N
	public static final String REVENUE_PER_PAYING_VISITOR_DECISION  = "rppv_decision";				//NO I18N
	
	// REVENUE PER PURCHASE RELATED CONSTANTS
	
	public static final String REVENUE_PER_PURCHASE = "revenue_per_purchase";				//NO I18N
	public static final String REVENUE_PER_PURCHASE_CONFIDENCE = "rpp_confidence";				//NO I18N
	public static final String REVENUE_PER_PURCHASE_SIGNIFICANCE = "rpp_significance";				//NO I18N
	public static final String REVENUE_PER_PURCHASE_IMPROVEMENT = "rpp_improvement";				//NO I18N
	public static final String REVENUE_PER_PURCHASE_CONCLUSION = "rpp_conclusion";				//NO I18N
	public static final String REVENUE_PER_PURCHASE_IS_WINNER = "rpp_is_winner";				//NO I18N
	public static final String REVENUE_PER_PURCHASE_IS_LOSER = "rpp_is_loser";				//NO I18N
	public static final String REVENUE_PER_PURCHASE_IS_INCONCLUSIVE = "rpp_isInconclusive";				//NO I18N
	public static final String REVENUE_PER_PURCHASE_DECISION  = "rpp_decision";				//NO I18N
	
	
	public static final List<Constants> REVEMUE_REPORT_DAY_CONSTANTS;
	
	static{
		List<Constants> archieveTableMetaConstants = new ArrayList<Constants>();
		archieveTableMetaConstants.add(new Constants(REVENUE_REPORT_DAY_ID,REVENUE_REPORT_DAY.REVENUE_REPORT_DAY_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.EXPERIMENT_ID,REVENUE_REPORT_DAY.EXPERIMENT_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.VARIATION_ID,REVENUE_REPORT_DAY.VARIATION_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(REVENUE,REVENUE_REPORT_DAY.REVENUE,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(PAYING_VISITORS_COUNT,REVENUE_REPORT_DAY.PAYING_VISITORS_COUNT,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.DATE,REVENUE_REPORT_DAY.DATE,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		
		REVEMUE_REPORT_DAY_CONSTANTS = Collections.unmodifiableList(archieveTableMetaConstants);
	}
	
	
	public static final List<Constants> REVEMUE_REPORT_HOUR_CONSTANTS;
	
	static{
		List<Constants> archieveTableMetaConstants = new ArrayList<Constants>();
		archieveTableMetaConstants.add(new Constants(REVENUE_REPORT_HOUR_ID,REVENUE_REPORT_HOUR.REVENUE_REPORT_HOUR_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.EXPERIMENT_ID,REVENUE_REPORT_HOUR.EXPERIMENT_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(ReportArchieveDimensionConstants.VARIATION_ID,REVENUE_REPORT_HOUR.VARIATION_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(REVENUE,REVENUE_REPORT_HOUR.REVENUE,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(PAYING_VISITORS_COUNT,REVENUE_REPORT_HOUR.PAYING_VISITORS_COUNT,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		archieveTableMetaConstants.add(new Constants(CumulativeReportConstants.HOUR,REVENUE_REPORT_HOUR.TIME,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		
		REVEMUE_REPORT_HOUR_CONSTANTS = Collections.unmodifiableList(archieveTableMetaConstants);
	}
	
	
}
