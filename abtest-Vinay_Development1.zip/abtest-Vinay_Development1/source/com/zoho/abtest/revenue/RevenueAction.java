//$Id$
package com.zoho.abtest.revenue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.json.JSONException;

import com.opensymphony.xwork2.ActionSupport;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.report.CumulativeReportConstants;
import com.zoho.abtest.utility.ZABUtil;

public class RevenueAction extends ActionSupport implements ServletResponseAware, ServletRequestAware{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private HttpServletRequest request;
	
	private HttpServletResponse response;
	private String experimentLinkName ;

	
	public void setServletRequest(HttpServletRequest arg0) {
		request = arg0;
	}


	public void setServletResponse(HttpServletResponse arg0) {
		response = arg0;
	}
	
	public String getExperimentLinkName() {
		return experimentLinkName;
	}

	public void setExperimentLinkName(String experimentLinkName) {
		this.experimentLinkName = experimentLinkName;
		request.setAttribute(ExperimentConstants.EXPERIMENT_LINKNAME, experimentLinkName);
	}
	
	
	public String execute() throws IOException, JSONException 
	{
		
		/*ArrayList<RevenueReport> revenueReports = new ArrayList<RevenueReport>();
		HashMap<String,String> hs;
		try {			
			switch(ZABAction.getHTTPMethod(request)) {
			case POST:	

				
				hs = ZABAction.getRequestParser(request).parseReport(request);

				if(hs.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					RevenueReport report = new RevenueReport();
					report.setSuccess(Boolean.FALSE);
					report.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
					revenueReports.add(report);
				}else{
					revenueReports.addAll(RevenueReport.getRevenueInformation(hs));
					
				}

				break;

			}
		} catch(Exception ex){
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), CumulativeReportConstants.API_MODULE));
			return null; 	
		}		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getRevenueResponse(request, revenueReports));		
	    */
		return null;
	}
	
	
	public String getRevenueChart() throws IOException, JSONException 
	{
		ArrayList<RevenueChartReport> charts = new ArrayList<RevenueChartReport>();
		
		/*try {			
			switch(ZABAction.getHTTPMethod(request)) {
			case POST:	
				HashMap<String,String> hs;
				hs = ZABAction.getRequestParser(request).parseReport(request);

				if(hs.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					RevenueChartReport report = new RevenueChartReport();
					report.setSuccess(Boolean.FALSE);
					report.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
					charts.add(report);
				}else{
					charts.addAll(RevenueChartReport.getDataPointReportInformation(hs));
				}

				break;

			}
		} catch(Exception ex){
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), CumulativeReportConstants.API_MODULE));
			return null; 	
		}	*/	
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getRevenueChartRpeortResponse(request, charts));		
	   
		return null;
	}

}
