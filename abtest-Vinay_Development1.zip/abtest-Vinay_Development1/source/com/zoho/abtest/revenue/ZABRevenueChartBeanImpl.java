//$Id$
package com.zoho.abtest.revenue;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.db.api.RelationalAPI;
import com.zoho.abtest.REVENUE_REPORT_HOUR;
import com.zoho.abtest.report.ReportArchieveDimensionConstants;
import com.zoho.abtest.utility.ZABUserBeanImpl;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.abtest.variation.VariationConstants;

public class ZABRevenueChartBeanImpl implements ZABRevenueChartBean{


	private static final Logger LOGGER = Logger.getLogger(ZABUserBeanImpl.class.getName());

	
	public 	HashMap<String , HashMap<String, String>> getDataPointHourGoalReportDetails(Long expId,  Long startTime, Long endTime  )
	{

		HashMap<String , HashMap<String, String>> metaHs = new HashMap<String , HashMap<String , String>>();

		
		Connection connection = null;
		
		PreparedStatement revenueSt = null;
		ResultSet revenueResultSet = null;

		try
		{
			
			String revenueHourTableName = REVENUE_REPORT_HOUR.TABLE;
		
			RelationalAPI relationalApi = RelationalAPI.getInstance();
			connection = relationalApi.getConnection();
		
			int index = 1;
		
			
			String hourTableRevenueQuery = "SELECT variation_id, time as date ,revenue, paying_visitors_count FROM "+revenueHourTableName+"  where EXPERIMENT_ID = ?  and time between ? and ?";		// NO I18N
			revenueSt = connection.prepareStatement(hourTableRevenueQuery);
			index = 1;
			revenueSt.setLong(index++, expId);
			revenueSt.setLong(index++, startTime);
			revenueSt.setLong(index++, endTime);

			revenueResultSet = revenueSt.executeQuery();
			

			while(revenueResultSet.next())
			{
				Long varId =(Long)revenueResultSet.getLong("VARIATION_ID");	// NO I18N
				Long date  = ((Long)revenueResultSet.getLong("DATE"));			// NO I18N
				Long revenue  = ((Long)revenueResultSet.getLong(3));	
				Long purchases  = ((Long)revenueResultSet.getLong(4));	

				revenue=revenue/100;
				String key  = varId+":"+date;
				HashMap<String, String> meta = new HashMap<String, String>();
				
				meta.put( ReportArchieveDimensionConstants.DATE, date.toString());
				meta.put(VariationConstants.VARIATION_ID, varId.toString());
				meta.put(RevenueConstants.PAYING_VISITORS_COUNT,"0");
				meta.put(RevenueConstants.REVENUE, revenue.toString());
				meta.put(RevenueConstants.PURCAHSES, purchases.toString());
			
				metaHs.put(key, meta);
				
			}


		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);

		}
		finally
		{
			
			try
			{
				if(revenueResultSet != null)
				{
					revenueResultSet.close();
				}
				if(revenueSt != null)
				{
					revenueSt.close();
				}
				if(connection != null)
				{
					connection.close();
				}

			}
			catch(Exception ex)
			{
				LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			}
		}

		return metaHs; 

	}


	public HashMap<String , HashMap<String, String>> getDataPointMultiSegmentHourGoalReportDetails(Long expId,Long startTime, Long endTime,HashMap<String, Object> multisegmentCriteriaHs,Long goalId)
	{

		HashMap<String , HashMap<String, String>> metaHs = new HashMap<String , HashMap<String , String>>();
		
		Connection connection = null;
	
		PreparedStatement revenueSt = null;
		ResultSet revenueResultSet = null;

		try
		{


			boolean isUrlparamTableJoin = (Boolean)multisegmentCriteriaHs.get("isUrlparamTableJoin");
			boolean isCookieTableJoin = (Boolean)multisegmentCriteriaHs.get("isCookieTableJoin");
			boolean isJsvariableTableJoin = (Boolean)multisegmentCriteriaHs.get("isJsvariableTableJoin");
			boolean isCustomDimensionTableJoin = (Boolean)multisegmentCriteriaHs.get("isCustomDimensionTableJoin");
			String rootConditionStr = (String)multisegmentCriteriaHs.get("rootConditionStr");
			List<Integer> valuesList = (List<Integer>)multisegmentCriteriaHs.get("valuesList");

			String dbspaceId = ZABUtil.getCurrentUserDbSpace();
			
			//HOUR table query START

			String hourTableGoalConditionClause = " WHERE EXPERIMENT_ID = ? AND GOAL_ID  = ? AND TIME BETWEEN ? AND ? "; // No I18N
			String hourTableJoinClause = " INNER JOIN REVENUE_DIMENSION_HOUR_VISITORS_"+dbspaceId+" ON REVENUE_DIMENSION_HOUR_VISITORS_"+dbspaceId+".HOUR_ID = GOAL_DIMENSION_HOUR.GOAL_DIMENSION_HOUR_ID "; //NO I18N


			if(isUrlparamTableJoin)
			{
				hourTableJoinClause = hourTableJoinClause + " INNER JOIN URLPARAM_COMBINATION_GOAL_HOUR_"+dbspaceId+" ON URLPARAM_COMBINATION_GOAL_HOUR_"+dbspaceId+".GOAL_DIMENSION_HOUR_ID = GOAL_DIMENSION_HOUR.GOAL_DIMENSION_HOUR_ID "; // No I18N
			}
			if(isCookieTableJoin)
			{
				hourTableJoinClause = hourTableJoinClause + " INNER JOIN COOKIE_COMBINATION_GOAL_HOUR_"+dbspaceId+" ON COOKIE_COMBINATION_GOAL_HOUR_"+dbspaceId+".GOAL_DIMENSION_HOUR_ID = GOAL_DIMENSION_HOUR.GOAL_DIMENSION_HOUR_ID "; // No I18N
			}
			if(isJsvariableTableJoin)
			{
				hourTableJoinClause = hourTableJoinClause + " INNER JOIN JSVAR_COMBINATION_GOAL_HOUR_"+dbspaceId+" ON JSVAR_COMBINATION_GOAL_HOUR_"+dbspaceId+".GOAL_DIMENSION_HOUR_ID = GOAL_DIMENSION_HOUR.GOAL_DIMENSION_HOUR_ID "; // No I18N
			}
			if(isCustomDimensionTableJoin)
			{
				hourTableJoinClause = hourTableJoinClause + " INNER JOIN CUSTOMDIMEN_COMBINATION_GOAL_HOUR_"+dbspaceId+" ON CUSTOMDIMEN_COMBINATION_GOAL_HOUR_"+dbspaceId+".GOAL_DIMENSION_HOUR_ID = GOAL_DIMENSION_HOUR.GOAL_DIMENSION_HOUR_ID "; // No I18N
			}
			if(!rootConditionStr.isEmpty())
			{
				hourTableGoalConditionClause = hourTableGoalConditionClause + " AND (" + rootConditionStr +")"; //No I18N
			}
		
			//HOUR table query END


			RelationalAPI relationalApi = RelationalAPI.getInstance();
			connection = relationalApi.getConnection();

			
			int index = 1;
			
		
			String revenueHourSelectClause = "SELECT variation_id , time as date, revenue , paying_visitors_count FROM GOAL_DIMENSION_HOUR ";//NO I18N
			String revenueHourQuery =revenueHourSelectClause + hourTableJoinClause + hourTableGoalConditionClause;

			revenueSt = connection.prepareStatement(  revenueHourQuery );
			index = 1;
			revenueSt.setLong(index++, expId);
			revenueSt.setLong(index++, goalId);
			revenueSt.setLong(index++, startTime);
			revenueSt.setLong(index++, endTime);

			if(!rootConditionStr.isEmpty())
			{
				for(Integer code:valuesList)
				{
					revenueSt.setInt(index++, code);
				}
			}

			revenueResultSet = revenueSt.executeQuery();



			while(revenueResultSet.next())
			{
				Long varId =(Long)revenueResultSet.getLong("VARIATION_ID");	// NO I18N
				Long date  = ((Long)revenueResultSet.getLong("DATE"));			// NO I18N
				Long revenue  = ((Long)revenueResultSet.getLong(3));			
				Long purchases  = (Long)revenueResultSet.getLong(4);
				revenue=revenue/100;
				String key  = varId+":"+date;
				HashMap<String, String> meta = new HashMap<String, String>();
				
				meta.put( ReportArchieveDimensionConstants.DATE, date.toString());
				meta.put(VariationConstants.VARIATION_ID, varId.toString());
				meta.put(RevenueConstants.PAYING_VISITORS_COUNT,"0");
				
				meta.put(RevenueConstants.REVENUE, revenue.toString());
				meta.put(RevenueConstants.PURCAHSES, purchases.toString());

				metaHs.put(key, meta);


			}


		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);

		}
		finally
		{
			
			try
			{
				if(revenueResultSet != null)
				{
					revenueResultSet.close();
				}
				if(revenueSt != null)
				{
					revenueSt.close();
				}
				if(connection != null)
				{
					connection.close();
				}

			}
			catch(Exception ex)
			{
				LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			}
		}

		return metaHs; 


	}



}
