//$Id$
package com.zoho.abtest.sessionrecording;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.zoho.abtest.SR_PAGE_BUFFER;
import com.zoho.abtest.common.ZABColumn;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.common.ZABTable;
import com.zoho.abtest.utility.ZABUtil;

@ZABTable(name=SR_PAGE_BUFFER.TABLE)
public class SessionRawDataPageBuffer extends ZABModel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@ZABColumn(name=SR_PAGE_BUFFER.SR_PAGE_BUFFER_ID)
	private Long bufferId;
	
	@ZABColumn(name=SR_PAGE_BUFFER.DATA)
	private String data;

	public Long getBufferId() {
		return bufferId;
	}

	public void setBufferId(Long bufferId) {
		this.bufferId = bufferId;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}
	
	public static SessionRawDataPageBuffer getData(Long id) throws Exception {
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		Criteria c = new Criteria(new Column(SR_PAGE_BUFFER.TABLE, SR_PAGE_BUFFER.SR_PAGE_BUFFER_ID), id, QueryConstants.EQUAL);
		DataObject dobj = getRow(SR_PAGE_BUFFER.TABLE, c);
		ZABUtil.setDBSpace(existingDBSpace);
		return getFirstModelFromDobj(dobj, SR_PAGE_BUFFER.TABLE, SessionRawDataPageBuffer.class);
	}
	
	public void destroyData() throws Exception {
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		Criteria c = new Criteria(new Column(SR_PAGE_BUFFER.TABLE, SR_PAGE_BUFFER.SR_PAGE_BUFFER_ID), this.getBufferId(), QueryConstants.EQUAL);
		deleteResource(c);
		ZABUtil.setDBSpace(existingDBSpace);
	}
}
