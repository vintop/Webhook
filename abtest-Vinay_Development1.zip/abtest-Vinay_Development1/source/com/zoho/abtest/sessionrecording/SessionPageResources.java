//$Id$
package com.zoho.abtest.sessionrecording;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.json.JSONObject;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.Range;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.ds.query.SelectQueryImpl;
import com.adventnet.ds.query.Table;
import com.adventnet.iam.IAMUtil;
import com.adventnet.iam.ServiceOrg;
import com.adventnet.iam.ServiceOrgDomain;
import com.adventnet.mfw.bean.BeanUtil;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.SESSION_RECORDING_PAGE_DETAILS;
import com.zoho.abtest.SR_PAGE_RESOURCES;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.dfs.DFS;
import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.sessionrecording.pagesnapshot.SResourceMQMessage;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUserBean;
import com.zoho.abtest.utility.ZABUtil;

public class SessionPageResources extends ZABModel{
	
	private final static Logger LOGGER = Logger.getLogger(SessionPageResources.class.getName());

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long zsoid;
	
	private String resourceKey;
	
	private String resourceBlockId;
	
	private String resourceUrl;
	
	private String resourceContentType;
	
	private String pageKey;
	
	private Integer processingStatus;
	
	private String experimentKey;
	
	private String esIndex;
	
	private String dfsFilePath;

	public String getDfsFilePath() {
		return dfsFilePath;
	}

	public void setDfsFilePath(String dfsFilePath) {
		this.dfsFilePath = dfsFilePath;
	}

	public String getEsIndex() {
		return esIndex;
	}

	public void setEsIndex(String esIndex) {
		this.esIndex = esIndex;
	}

	public String getExperimentKey() {
		return experimentKey;
	}

	public void setExperimentKey(String experimentKey) {
		this.experimentKey = experimentKey;
	}

	public String getResourceKey() {
		return resourceKey;
	}

	public void setResourceKey(String resourceKey) {
		this.resourceKey = resourceKey;
	}

	public String getResourceBlockId() {
		return resourceBlockId;
	}

	public void setResourceBlockId(String resourceBlockId) {
		this.resourceBlockId = resourceBlockId;
	}

	public String getResourceUrl() {
		return resourceUrl;
	}

	public void setResourceUrl(String resourceUrl) {
		this.resourceUrl = resourceUrl;
	}

	public String getResourceContentType() {
		return resourceContentType;
	}

	public void setResourceContentType(String resourceContentType) {
		this.resourceContentType = resourceContentType;
	}

	public String getPageKey() {
		return pageKey;
	}

	public void setPageKey(String pageKey) {
		this.pageKey = pageKey;
	}

	public Integer getProcessingStatus() {
		return processingStatus;
	}

	public void setProcessingStatus(Integer processingStatus) {
		this.processingStatus = processingStatus;
	}

	public Long getZsoid() {
		return zsoid;
	}

	public void setZsoid(Long zsoid) {
		this.zsoid = zsoid;
	}

	public String getDFSResourcePath(String portal, String experimentKey, String pageKey) {
		if(portal!=null && pageKey!=null && this.getResourceKey()!=null) {			
			return SessionPage.getDFSBasePath(portal, experimentKey, pageKey) + this.getResourceKey();
		}
		return null;
	}
	
	public String getDFSResourcePathFolderLess(String experimentKey, String pageKey) {
		if(pageKey!=null && this.getResourceKey()!=null) {			
			return SessionPage.getDFSBasePathFolderLess(experimentKey, pageKey) + "_" + this.getResourceKey();
		}
		return null;
	}
	
	public SessionPageResources() {
		
	}
	
	public SessionPageResources(SResourceMQMessage message) {
		this.resourceKey =  message.getResourceKey();
		this.resourceUrl = message.getResourceURL();
	}
	
	public void deleteFile(Long zsoid) {
		try {			
			if(this.getResourceBlockId()!=null) {
				String dfsPath = this.getDfsFilePath();
				if(dfsPath==null) {
					dfsPath = getDFSResourcePath(zsoid.toString(), this.getExperimentKey(), this.getPageKey());
				}
				DFS.deleteFromDFS(this.getResourceBlockId(), this.getDfsFilePath(), zsoid.toString());
			} else {
				LOGGER.log(Level.INFO, "Insufficient details to delete file"+this.getDfsFilePath());
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Exception occured", e);
		}
	}
	
	public void updateResourceMeta() throws Exception {
		JSONObject json = new JSONObject();
		
		json.put(ElasticSearchConstants.PAGE_RESOURCE_STATUS, this.getProcessingStatus());
		json.put(ElasticSearchConstants.PAGE_RESOURCE_CONTENT_TYPE, this.getResourceContentType());
		json.put(ElasticSearchConstants.PAGE_RESOURCE_BLOCKID, this.getResourceBlockId());
		json.put(ElasticSearchConstants.PAGE_RESOURCE_DFS_FILE_PATH, this.getDfsFilePath());
		
		ElasticSearchUtil.updateIndex(this.getEsIndex(),
				ElasticSearchConstants.SESSION_PAGE_RESOURCE_TYPE,
				this.getResourceKey(),
				json.toString());
	}
	
	
	public static void migrateFromPostgresToElastic(String zsoid) throws Exception {
		SelectQuery query = new SelectQueryImpl(new Table(SR_PAGE_RESOURCES.TABLE));
		Column column = new Column(SR_PAGE_RESOURCES.TABLE, "*").count();
		column.setColumnAlias("TOTAL_COUNT");
		query.addSelectColumn(column);
		ZABUserBean bean= (ZABUserBean)BeanUtil.lookup(ZABUserBean.BEAN_NAME, zsoid);
		AtomicInteger atomicInteger = new AtomicInteger(0);
		bean.executeQuery(query, (ds) -> {
			if(ds.next()) {	
				atomicInteger.addAndGet((Integer)ds.getValue("TOTAL_COUNT")); //NO I18N
			}
		});
		
		Integer size = atomicInteger.intValue();
		if(size > 0) {
			
			LOGGER.log(Level.INFO, "Total Records count::"+size);
			
			int batchSize = 1000;
			Double s = size/new Double(batchSize);
			double batches = Math.ceil(s);
			
			LOGGER.log(Level.INFO, "Total batches::"+batches);
			
			for(int i=0; i<batches; i++) {
				int startIndex = i*batchSize;
				int bsize = (i == batches-1)?(size - startIndex):batchSize;
				
				LOGGER.log(Level.INFO, "Batch Index::"+i+"::Start Index::"+startIndex+"::Size::"+bsize);
				
				SelectQuery q = new SelectQueryImpl(new Table(SR_PAGE_RESOURCES.TABLE));
				Column c1 = new Column(SR_PAGE_RESOURCES.TABLE, "*");
				Column c2 = new Column(SESSION_RECORDING_PAGE_DETAILS.TABLE, "*");
				Column c3 = new Column(EXPERIMENT.TABLE, "*");
				q.addSelectColumn(c1);
				q.addSelectColumn(c2);
				q.addSelectColumn(c3);
				
				q.setRange(new Range(startIndex, bsize));
				
				Join join1=new Join(SR_PAGE_RESOURCES.TABLE,SESSION_RECORDING_PAGE_DETAILS.TABLE,new String[]{SR_PAGE_RESOURCES.PAGE_ID},new String[]{SESSION_RECORDING_PAGE_DETAILS.SESSION_RECORDING_PD_ID},Join.INNER_JOIN);
				Join join2=new Join(SESSION_RECORDING_PAGE_DETAILS.TABLE,EXPERIMENT.TABLE,new String[]{SESSION_RECORDING_PAGE_DETAILS.EXPERIMENT_ID},new String[]{EXPERIMENT.EXPERIMENT_ID},Join.INNER_JOIN);
				
				q.addJoin(join1);
				q.addJoin(join2);
				
				DataObject dobj = ZABModel.getResource(q);
				Iterator it = dobj.getRows(SR_PAGE_RESOURCES.TABLE);
				
				HashMap<String, JSONObject> docs = new HashMap<String, JSONObject>();
				while(it.hasNext()) {
					
					Row row = (Row)it.next();
					
					JSONObject json = new JSONObject();
					
					json.put(ElasticSearchConstants.PAGE_RESOURCE_URL, (String) row.get(SR_PAGE_RESOURCES.RESOURCE_URL));
					json.put(ElasticSearchConstants.PAGE_RESOURCE_STATUS,  (Integer) row.get(SR_PAGE_RESOURCES.PROCESS_STATUS));
					json.put(ElasticSearchConstants.PAGE_RESOURCE_CONTENT_TYPE, (String) row.get(SR_PAGE_RESOURCES.RESOURCE_CONTENT_TYPE));
					json.put(ElasticSearchConstants.PAGE_RESOURCE_BLOCKID,  (String) row.get(SR_PAGE_RESOURCES.RESOURCE_BLOCK_ID));
					
					json.put(ElasticSearchConstants.ZSOID, ZABUtil.getDBSpace());
					
					Long pageId =  (Long) row.get(SR_PAGE_RESOURCES.PAGE_ID);
					
					Criteria c = new Criteria(new Column(SESSION_RECORDING_PAGE_DETAILS.TABLE, SESSION_RECORDING_PAGE_DETAILS.SESSION_RECORDING_PD_ID), pageId, QueryConstants.EQUAL);
					
					Row pageRow = dobj.getRow(SESSION_RECORDING_PAGE_DETAILS.TABLE, c);
					if(pageRow!=null) {
						String pageKey = (String)pageRow.get(SESSION_RECORDING_PAGE_DETAILS.PAGE_ID);
						json.put(ElasticSearchConstants.PAGE_ID, pageKey);
						
						Long experimentId = (Long)pageRow.get(SESSION_RECORDING_PAGE_DETAILS.EXPERIMENT_ID);
						json.put(ElasticSearchConstants.EXPERIMENTID, experimentId);
						
						Criteria criteriaForExp = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
						
						Row experimentRow = dobj.getRow(EXPERIMENT.TABLE, criteriaForExp);
						
						if(experimentRow!=null) {
							String experimentKey = (String)experimentRow.get(EXPERIMENT.EXPERIMENT_KEY);
							json.put(ElasticSearchConstants.EXPERIMENTKEY, experimentKey);
							
							String id = (String) row.get(SR_PAGE_RESOURCES.RESOURCE_KEY);
							docs.put(id, json);
						}
					}
				}
				
				LOGGER.log(Level.INFO, "Totals docs ready for insertion::"+docs.size());
				
				ServiceOrg org = ZABServiceOrgUtil.getServiceOrg(zsoid);
				String portalName = org.getDomains().get(0).getDomain();
				
				String indexName = ElasticSearchUtil.getIndexByPortal(portalName);
				
				LOGGER.log(Level.INFO, "Portal::"+portalName+"::zsoid::"+zsoid+"::indexName::"+indexName);
				
				if(docs.size() > 0) {					
					ElasticSearchUtil.bulkInsertDocumentsWithIds(indexName, ElasticSearchConstants.SESSION_PAGE_RESOURCE_TYPE, docs);
				}
				
				
			}
			
		}
		
	}
	
	public void createResourceMeta() throws Exception {
		
		ZABUtil.setDBSpace(this.getZsoid().toString());
		Long experimentId = Experiment.getExperimentIdByExperimentKey(this.getExperimentKey());
		
		JSONObject json = new JSONObject();
		json.put(ElasticSearchConstants.PAGE_ID, this.getPageKey());
		json.put(ElasticSearchConstants.ZSOID, this.getZsoid());
		json.put(ElasticSearchConstants.EXPERIMENTKEY, this.getExperimentKey());
		json.put(ElasticSearchConstants.EXPERIMENTID, experimentId);
		json.put(ElasticSearchConstants.PAGE_RESOURCE_URL, this.getResourceUrl());
		json.put(ElasticSearchConstants.PAGE_RESOURCE_STATUS, this.getProcessingStatus());
		
		 
		IndexResponse response = ElasticSearchUtil.createIndex(
				this.getEsIndex(),
				ElasticSearchConstants.SESSION_PAGE_RESOURCE_TYPE,
				json.toString());
		String resourceKey = response.getId();
		this.setResourceKey(resourceKey);
		
	}
	
	private static SessionPageResources getSessionPageResourceFromSource(Map<String, Object> source) {
		SessionPageResources resource = new SessionPageResources();
		resource.setResourceUrl((String)source.get(ElasticSearchConstants.PAGE_RESOURCE_URL));
		resource.setPageKey((String)source.get(ElasticSearchConstants.PAGE_ID));
		resource.setExperimentKey((String)source.get(ElasticSearchConstants.EXPERIMENTKEY));
		resource.setResourceBlockId((String)source.get(ElasticSearchConstants.PAGE_RESOURCE_BLOCKID));
		resource.setResourceContentType((String)source.get(ElasticSearchConstants.PAGE_RESOURCE_CONTENT_TYPE));
		resource.setProcessingStatus((Integer)source.get(ElasticSearchConstants.PAGE_RESOURCE_STATUS));
		resource.setDfsFilePath((String)source.get(ElasticSearchConstants.PAGE_RESOURCE_DFS_FILE_PATH));
		resource.setSuccess(true);
		return resource;
	}
	
	public static ArrayList<SessionPageResources> getSessionPageResource(String pageId) {
		ArrayList<SessionPageResources> resources = new ArrayList<SessionPageResources>();
		try {

			ServiceOrgDomain domain = IAMUtil.getCurrentServiceOrg().getDomains().get(0);
			String portalName = domain.getDomain();
			String zsoid = ZABUtil.getDBSpace();
			Long zsoidL = Long.parseLong(zsoid);
			
			String indexName = ElasticSearchUtil.getIndexByPortal(portalName);

			String[] includes = new String[] {
					ElasticSearchConstants.PAGE_RESOURCE_URL,
					ElasticSearchConstants.PAGE_RESOURCE_DFS_FILE_PATH,
					ElasticSearchConstants.ZSOID,
					ElasticSearchConstants.PAGE_ID,
					ElasticSearchConstants.PAGE_RESOURCE_URL,
					ElasticSearchConstants.PAGE_RESOURCE_BLOCKID,
					ElasticSearchConstants.PAGE_RESOURCE_CONTENT_TYPE,
					ElasticSearchConstants.PAGE_RESOURCE_STATUS
			};

			BoolQueryBuilder qb = QueryBuilders
					.boolQuery()
					.must(QueryBuilders.termQuery(ElasticSearchConstants.ZSOID,
							zsoidL))
					.must(QueryBuilders.termQuery(
							ElasticSearchConstants.PAGE_ID, pageId));
					


			LOGGER.log(Level.INFO, "Getting meta data from ES start");
			SearchResponse response = ElasticSearchUtil.getData(indexName,
			ElasticSearchConstants.SESSION_PAGE_RESOURCE_TYPE, qb,
			includes, null, ElasticSearchConstants.MAX_WINDOW_SIZE, null, null);
			
			SearchHits hits = response.getHits();
			
			long totalHits = hits.getTotalHits();
			if(totalHits > 0) {
				for(int i=0; i<totalHits; i++) {
					SearchHit hit = hits.getAt(i);
					Map<String, Object> source = hit.getSourceAsMap();
					SessionPageResources resource = getSessionPageResourceFromSource(source);
					resource.setResourceKey(hit.getId());
					resources.add(resource);
				}
			}
			
		} catch (Exception e) {
			SessionPageResources resource = new SessionPageResources();
			resource.setSuccess(Boolean.FALSE);
			resource.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			resources.add(resource);
		}
		return resources;
	}
	
	public static SessionPageResources getSessionPageResource(String pageId, String resourceId, String resourceUrl) {
		SessionPageResources resource = new SessionPageResources();
		resource.setSuccess(false);
		try {
			
			
			ServiceOrgDomain domain = IAMUtil.getCurrentServiceOrg().getDomains().get(0);
			String portalName = domain.getDomain();
			
			String indexName = ElasticSearchUtil.getIndexByPortal(portalName);

			String[] includes = new String[] {
					ElasticSearchConstants.PAGE_RESOURCE_URL,
					ElasticSearchConstants.ZSOID,
					ElasticSearchConstants.PAGE_ID,
					ElasticSearchConstants.EXPERIMENTKEY,
					ElasticSearchConstants.PAGE_RESOURCE_URL,
					ElasticSearchConstants.PAGE_RESOURCE_DFS_FILE_PATH,
					ElasticSearchConstants.PAGE_RESOURCE_BLOCKID,
					ElasticSearchConstants.PAGE_RESOURCE_CONTENT_TYPE,
					ElasticSearchConstants.PAGE_RESOURCE_STATUS
			};
			
			
			GetResponse response = ElasticSearchUtil.getDataById(indexName, ElasticSearchConstants.SESSION_PAGE_RESOURCE_TYPE, resourceId, includes, new String[]{});
			if(response.isExists()) {
				Map<String, Object> source = response.getSourceAsMap();
				
				Integer zsoid = (Integer) source.get(ElasticSearchConstants.ZSOID);
				String rpid = (String) source.get(ElasticSearchConstants.PAGE_ID);
				if(rpid.equals(pageId) && ZABUtil.getDBSpace().equals(zsoid.toString())) {					
					resource = getSessionPageResourceFromSource(source);
					resource.setResourceKey(response.getId());
				}
				
			}
			
		} catch (Exception e) {
			resource = new SessionPageResources();
			resource.setSuccess(Boolean.FALSE);
			resource.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
		}
		return resource;
	}
	
}
