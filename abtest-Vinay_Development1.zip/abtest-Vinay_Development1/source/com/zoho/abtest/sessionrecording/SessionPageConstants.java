//$Id$
package com.zoho.abtest.sessionrecording;

public class SessionPageConstants {

	public static final String PAGE_ID = "pid"; //NO I18N
	
	public static final String PAGE_ID_QP = "page_id"; //NO I18N
	
	public static final String API_MODULE = "sessionpagedetails"; //NO I18N
	
	public static final String PAGE_KEY = "page_key"; //NO I18N
	
	public static final String PAGE_URL = "cv"; //NO I18N
	
	public static final String HEIGHT = "height"; //NO I18N
	
	public static final String WIDTH = "width"; //NO I18N
	
	public static final String PAGE_HTML = "pv"; //NO I18N
	
	public static final String RESOURCE_MAP = "resource_map"; //NO I18N
}
