//$Id$
package com.zoho.abtest.sessionrecording;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.zoho.abtest.report.ReportRawDataConstants;
import com.zoho.abtest.report.VisitorRawDataWrapper;

public class SessionRawDataInHandler {
	
	public static final Logger LOGGER = Logger.getLogger(SessionRawDataInHandler.class.getName()); 
	
	public static void handleSessionRawData(VisitorRawDataWrapper wrapper) throws Exception {
		if(wrapper.getIsOptOut()) {
			ArrayList<HashMap<String, String>> consentData = (ArrayList<HashMap<String, String>>) wrapper.getOptOutData();
			int length = consentData.size();
			for(int i=0; i<length; i++) {
				HashMap<String, String> consent = consentData.get(i);
				String sessionId = consent.get(ReportRawDataConstants.UUID);
				String portal = consent.get(ReportRawDataConstants.PORTAL);
				String experimentKey = consent.get(ReportRawDataConstants.EXPERIMENT_KEY);
				SessionRawData.optOutSession(sessionId, portal, experimentKey);
			}
			LOGGER.log(Level.INFO, "Opted out for session", wrapper);
		} else {
			SessionRawData data = new SessionRawData(wrapper);
			data.snapshotHTML();
			data.persistVisitorDoc();
			data.logPageVisitEvent();			
		}
	}
	
	public static void handleSessionEventData(VisitorRawDataWrapper wrapper) throws Exception {
		SessionEventData data = new SessionEventData(wrapper);
		data.persistEventStream();
		data.persistUserEvents();
		data.addEventDataToVisitorDoc();
	}
	
}
