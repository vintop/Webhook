//$Id$
package com.zoho.abtest.sessionrecording;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.script.Script;
import org.elasticsearch.script.ScriptType;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.dimension.DimensionConstants.DynamicAttributeType;
import com.zoho.abtest.dimension.DynamicAttributes;
import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.report.ReportRawDataConstants;
import com.zoho.abtest.report.VisitorRawDataHandler;
import com.zoho.abtest.report.VisitorRawDataWrapper;
import com.zoho.abtest.sessionrecording.SessionRecordingConstants.SessionEventTypes;
import com.zoho.abtest.sessionrecording.pagesnapshot.SessionDFSMetaBlock;
import com.zoho.abtest.sessionrecording.pagesnapshot.SessionPageSnapShotEngine;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUtil;

public class SessionRawData {
	
	private static final Logger LOGGER = Logger.getLogger(SessionRawData.class.getName());
	
	private String htmlContentJSON;
	
	private String pageKey;
	
	private Long time;
	
	private String portalName;
	
	private String esIndex;
	
	private String url;
	
	private String height;
	
	private String width;
	
	private Long zsoid;
	
	private ArrayList<String> experimentKeys = new ArrayList<String>();
	
	private ArrayList<SessionElasticDoc> visitorRawDoc = new ArrayList<SessionElasticDoc>();
	
	private ArrayList<JSONObject> sessionEventDoc = new ArrayList<JSONObject>();
	
	private HashMap<String, SessionDFSMetaBlock> experimentBlockIdMap = new HashMap<String, SessionDFSMetaBlock>();
	
	private SessionEventData eventData = null;
	
	private VisitorRawDataWrapper wrapper;
	
	private Script updateScript;
	
	public Script getUpdateScript() {
		return updateScript;
	}

	public void setUpdateScript(Script updateScript) {
		this.updateScript = updateScript;
	}
	
	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getHeight() {
		return height;
	}

	public void setHeight(String height) {
		this.height = height;
	}

	public String getWidth() {
		return width;
	}

	public void setWidth(String width) {
		this.width = width;
	}

	public ArrayList<String> getExperimentKeys() {
		return experimentKeys;
	}

	public void setExperimentKeys(ArrayList<String> experimentKeys) {
		this.experimentKeys = experimentKeys;
	}

	public Long getZsoid() {
		return zsoid;
	}

	public void setZsoid(Long zsoid) {
		this.zsoid = zsoid;
	}
	
	public HashMap<String, SessionDFSMetaBlock> getExperimentBlockIdMap() {
		return experimentBlockIdMap;
	}

	public void setExperimentBlockIdMap(HashMap<String, SessionDFSMetaBlock> experimentBlockIdMap) {
		this.experimentBlockIdMap = experimentBlockIdMap;
	}

	public static void optOutSession(String sessionId, String portal, String experimentKey) throws Exception {
		
		LOGGER.log(Level.INFO, "Opted out for ::sessionId:"+sessionId+"::portal:"+portal+"::experimentKey:"+experimentKey);
		
		Long zsoid = ZABServiceOrgUtil.getZSOIDFromDomain(portal);
		if(zsoid == null)
		{
			throw new ZABException("Invalid portal provided :"+portal); //NO I18N
		}
		String index = ElasticSearchUtil.getIndexByPortal(portal);

		Script updateSript = new Script(ScriptType.INLINE, "painless", SessionElasticDocDetails.SOFT_DELETE_RECORDING, new HashMap<String, Object>()); //NO I18N
		
		JSONObject json = new JSONObject();
		json.put(ElasticSearchConstants.EXPERIMENTKEY, experimentKey);
		json.put(ElasticSearchConstants.ZSOID, zsoid);
		json.put(ElasticSearchConstants.SESSION_ID, sessionId);
		json.put(ElasticSearchConstants.IS_OPT_OUT, true);
		
		ElasticSearchUtil.upsertIndex(index, ElasticSearchConstants.SESSION_RAW_DATA_TYPE, sessionId, json.toString(), updateSript, 5);
	}

	public SessionRawData(VisitorRawDataWrapper wrapper) throws Exception {
		LOGGER.log(Level.INFO, "Processing session raw data start");
		//Collecting basic details
		String portal = wrapper.getSessionRawData().get(0).get(ReportRawDataConstants.PORTAL),
			   url = wrapper.getUserAgenths().get(ReportRawDataConstants.CURRENTURL_VALUE),
			   dim = wrapper.getUserAgenths().get(ReportRawDataConstants.SCREEN_RESOLUTION_VALUE),
			   dimArray[] = dim.split("x"),
			   height = dimArray[1],
			   width = dimArray[0],
			   pageId = wrapper.getUserAgenths().get(ReportRawDataConstants.PAGE_ID);
		
		
		SessionRawDataPageBuffer buffer = SessionRawDataPageBuffer.getData(wrapper.getPageBufferId());
		String html = buffer.getData();
		buffer.destroyData();
		
		Long zsoid = ZABServiceOrgUtil.getZSOIDFromDomain(portal);
		if(zsoid == null)
		{
			throw new ZABException("Invalid portal provided :"+portal); //NO I18N
		}
		String index = ElasticSearchUtil.getIndexByPortal(portal);
		
		this.setZsoid(zsoid);
		this.setEsIndex(index);
		
		for(HashMap<String, String> srd: wrapper.getSessionRawData()) {
			experimentKeys.add(srd.get(ReportRawDataConstants.EXPERIMENT_KEY));
		}
		
		this.setUrl(url);
		this.setHeight(height);
		this.setWidth(width);
		this.setTime(wrapper.getTime());
		this.setPortalName(portal);
		this.setHtmlContentJSON(html);
		this.setPageKey(pageId);
		this.wrapper = wrapper;
		this.eventData = new SessionEventData(wrapper);
		LOGGER.log(Level.INFO, "Processing session raw data start");
	}
	
	public void snapshotHTML() throws Exception {
		LOGGER.log(Level.INFO, "Taking html snapshot data");
		SessionPageSnapShotEngine.generateSnapshot(this);
		LOGGER.log(Level.INFO, "Taking html snapshot end");
	}
	
	public void logPageVisitEvent() throws Exception {
		for(JSONObject sessionEventDoc: this.getSessionEventDoc()) {			
			ElasticSearchUtil.createIndex(this.getEsIndex(), ElasticSearchConstants.SESSION_USER_EVENT_DATA_TYPE, sessionEventDoc.toString());
		}
		
		eventData.persistEventStream();
	}
	
	
	public void persistVisitorDoc() throws Exception {
		if(this.getPageKey() == null) {
			throw new ZABException("Called persistVisitorDoc function before saving HTML page"); //NO I18N
		}
		buildElasticDocForVisitorRaw(wrapper);
		
		for(SessionElasticDoc doc: this.getVisitorRawDoc()) {			
			SessionElasticBand.saveSessionRawData(doc, this.getPortalName(), this.getEsIndex());
		}
	}
	
	public String getEsIndex() {
		return esIndex;
	}

	public void setEsIndex(String esIndex) {
		this.esIndex = esIndex;
	}

	public ArrayList<SessionElasticDoc> getVisitorRawDoc() {
		return visitorRawDoc;
	}

	public void setVisitorRawDoc(ArrayList<SessionElasticDoc> visitorRawDoc) {
		this.visitorRawDoc = visitorRawDoc;
	}

	public ArrayList<JSONObject> getSessionEventDoc() {
		return sessionEventDoc;
	}

	public void setSessionEventDoc(ArrayList<JSONObject> sessionEventDoc) {
		this.sessionEventDoc = sessionEventDoc;
	}

	public String getHtmlContentJSON() {
		return htmlContentJSON;
	}

	public void setHtmlContentJSON(String htmlContentJSON) {
		this.htmlContentJSON = htmlContentJSON;
	}

	public Long getTime() {
		return time;
	}

	public void setTime(Long time) {
		this.time = time;
	}
	
	public String getPageKey() {
		return pageKey;
	}

	public void setPageKey(String pageKey) {
		this.pageKey = pageKey;
	}

	public String getPortalName() {
		return portalName;
	}

	public void setPortalName(String portalName) {
		this.portalName = portalName;
	}

	private void buildElasticDocForVisitorRaw(VisitorRawDataWrapper wrapper) throws ZABException, JSONException {
		
		HashMap<String, String> dimensionData = wrapper.getUserAgenths();
		ArrayList<HashMap<String, String>> experimentDatas = wrapper.getSessionRawData();
		
		
		for(HashMap<String, String> experimentData: experimentDatas) {
			
			Boolean isNewVisitor = Boolean.parseBoolean(experimentData.get(ReportRawDataConstants.IS_NEW_VISITOR));
			
			String userType = isNewVisitor?"NEW":"RETURNING"; //No I18N
			
			SessionElasticDoc docData = new SessionElasticDoc();
			
			JSONObject resultJson = new JSONObject();
			String portal = experimentData.get(ReportRawDataConstants.PORTAL),
				   sessionId = experimentData.get(ReportRawDataConstants.UUID),
				   visitId = experimentData.get(ReportRawDataConstants.UVID),
				   euuid = dimensionData.get(ReportRawDataConstants.UUID);
			
			ZABUtil.setDBSpaceByPortal(portal);
			
			String experimentKey = experimentData.get(ReportRawDataConstants.EXPERIMENT_KEY);
			
			Experiment experiment = Experiment.getExperimentByKey(experimentKey);
			
			if(experiment!=null && experiment.getSuccess()) {
				
				String browser = dimensionData.get(ReportRawDataConstants.BROWSER_VALUE).toUpperCase();
				String device = dimensionData.get(ReportRawDataConstants.DEVICE_VALUE).toUpperCase();
				String language = ZABUtil.getLanguageFromCode(dimensionData.get(ReportRawDataConstants.LANGUAGE_VALUE).toUpperCase());
				String os = dimensionData.get(ReportRawDataConstants.OS_VALUE).toUpperCase();
				String currenturl = dimensionData.get(ReportRawDataConstants.CURRENTURL_VALUE);
				String referurl = dimensionData.get(ReportRawDataConstants.REFFERERURL_VALUE);
				String trafficSource = dimensionData.get(ReportRawDataConstants.TRAFFICSOURCE_VALUE).toUpperCase();
				
				
				resultJson.put(ElasticSearchConstants.EXPERIMENTID, experiment.getExperimentId());
				resultJson.put(ElasticSearchConstants.USERTYPE, userType);
				
				resultJson.put(ElasticSearchConstants.EXPERIMENTKEY, experiment.getExperimentKey());
				resultJson.put(ElasticSearchConstants.ZSOID, this.getZsoid());
				resultJson.put(ElasticSearchConstants.TIME, this.getTime());
				resultJson.put(ElasticSearchConstants.SESSION_IS_PARTIAL_DATA, false);
				resultJson.put(ElasticSearchConstants.IS_OPT_OUT, false);
				resultJson.put(ElasticSearchConstants.CURRENTURL, currenturl);
				resultJson.put(ElasticSearchConstants.LAST_ACTIVITY_TIME, this.getTime());
				resultJson.put(ElasticSearchConstants.LAST_INTERACTED_TIME, this.getTime());
				
				
				resultJson.put(ElasticSearchConstants.LAST_URL_VISITED, currenturl);
				resultJson.put(ElasticSearchConstants.HEIGHT, this.getHeight());
				resultJson.put(ElasticSearchConstants.WIDTH, this.getWidth());
				resultJson.put(ElasticSearchConstants.SESSION_ALIAS_USERNAME, SessionRandomAliasNameGenerator.generateRandomName());
				
				resultJson.put(ElasticSearchConstants.TRAFFICSOURCE, trafficSource);
				resultJson.put(ElasticSearchConstants.REFFERERURL, referurl);
				resultJson.put(ElasticSearchConstants.SESSION_ID, sessionId);
				resultJson.put(ElasticSearchConstants.UUID, euuid);
				resultJson.put(ElasticSearchConstants.PORTAL, portal);
				resultJson.put(ElasticSearchConstants.BROWSER, browser);
				resultJson.put(ElasticSearchConstants.DEVICE, device);
				resultJson.put(ElasticSearchConstants.LANGUAGE, language);
				resultJson.put(ElasticSearchConstants.OS, os);
				
				setLocationDetails(wrapper, resultJson);
				
				//Pages Visited
				JSONArray urlsVisited = new JSONArray();
				
				
				JSONObject urlVisited = new JSONObject();
				urlVisited.put(ElasticSearchConstants.UVID, visitId);
				urlVisited.put(ElasticSearchConstants.TIME, this.getTime());
				urlVisited.put(ElasticSearchConstants.URL, currenturl);
				urlVisited.put(ElasticSearchConstants.LAST_ACTIVITY_TIME, this.getTime());
				urlVisited.put(ElasticSearchConstants.SESSION_IS_PARTIAL_DATA, false);
				urlVisited.put(ElasticSearchConstants.PAGE_ID, this.getPageKey());
				urlVisited.put(ElasticSearchConstants.PAGE_BLOCK_ID, this.getExperimentBlockIdMap().get(experimentKey).getDfsBlockId());
				urlVisited.put(ElasticSearchConstants.PAGE_DFS_FILE_PATH, this.getExperimentBlockIdMap().get(experimentKey).getFilePath());
				urlVisited.put(ElasticSearchConstants.REFFERERURL, referurl);
				urlVisited.put(ElasticSearchConstants.TRAFFICSOURCE, trafficSource);
				
				setDynamicAttributeDetails(urlVisited, experiment.getExperimentId(), dimensionData);
				
				urlsVisited.put(urlVisited);
				
				resultJson.put(ElasticSearchConstants.URLS_VISITED, urlsVisited);
				resultJson.put(ElasticSearchConstants.ELEMENTS_CLICKED, new JSONArray());
				resultJson.put(ElasticSearchConstants.INPUT_INTERACTED, new JSONArray());
				resultJson.put(ElasticSearchConstants.ACHEIVED_GOALS, new JSONArray());
				resultJson.put(ElasticSearchConstants.TAGS, new JSONArray());
				
				docData.setVisitorDoc(resultJson);
				
				Map<String, Object> urlVisitedJSONMap = ZABUtil.convertJSONtoMap(urlVisited);
				convertDAToList(urlVisitedJSONMap, ElasticSearchConstants.NCOOKIE);
				convertDAToList(urlVisitedJSONMap, ElasticSearchConstants.NURLPARAMETER);
				convertDAToList(urlVisitedJSONMap, ElasticSearchConstants.NJSVARIABLE);
				convertDAToList(urlVisitedJSONMap, ElasticSearchConstants.NCUSTOMDIMENSION);
				
				Set<String> mergeFields = urlVisitedJSONMap.keySet();
				mergeFields.remove(ElasticSearchConstants.LAST_ACTIVITY_TIME);
				
				Map<String, Object> params = new HashMap<String, Object>();
				params.put("merge_fields", mergeFields.toArray(new String[mergeFields.size()]));
				params.put("url_visited", urlVisitedJSONMap);
				params.put(ElasticSearchConstants.ACHEIVED_GOALS, new ArrayList<HashMap<String, Object>>());
				params.put("last_url", currenturl);
				params.put("last_act_time", this.getTime());
				params.put("last_int_time", this.getTime());				
				params.put("timer", this.eventData.getTimer());
				params.put("page_id", this.getPageKey());
				
				Script updateSript = new Script(ScriptType.INLINE, "painless", SessionElasticDocDetails.UPDATE_SESSION_DOC_SCRIPT, params); //NO I18N
				
				docData.setScript(updateSript);
				
				JSONObject updateDoc = new JSONObject(resultJson.toString());
				updateDoc.remove(ElasticSearchConstants.URLS_VISITED);
				updateDoc.remove(ElasticSearchConstants.LAST_ACTIVITY_TIME);
				updateDoc.remove(ElasticSearchConstants.ELEMENTS_CLICKED);
				updateDoc.remove(ElasticSearchConstants.INPUT_INTERACTED);
				updateDoc.remove(ElasticSearchConstants.ACHEIVED_GOALS);
				updateDoc.remove(ElasticSearchConstants.TAGS);
				
				docData.setUpdateDoc(updateDoc);

				visitorRawDoc.add(docData);
				
				JSONObject eventDoc = new JSONObject();
				eventDoc.put(ElasticSearchConstants.EXPERIMENTKEY, experimentKey);
				eventDoc.put(ElasticSearchConstants.PORTAL, this.getPortalName());
				eventDoc.put(ElasticSearchConstants.ZSOID, this.getZsoid());
				eventDoc.put(ElasticSearchConstants.SESSION_EVENT_TYPE, SessionEventTypes.NAVIGATION.getTypeId());
				eventDoc.put(ElasticSearchConstants.SESSION_TIMER, 0);
				eventDoc.put(ElasticSearchConstants.SESSION_ID, sessionId);
				eventDoc.put(ElasticSearchConstants.UVID, visitId);
				eventDoc.put(ElasticSearchConstants.PAGE_ID, this.getPageKey());
				eventDoc.put(ElasticSearchConstants.URL, this.getUrl());
				sessionEventDoc.add(eventDoc);
				
			}
		}
		
		
	}
	
	private void convertDAToList(Map<String, Object> map, String key) {
		if(map.containsKey(key)) {
			try {
				ArrayList<HashMap<String, Object>> daValues = new ArrayList<HashMap<String,Object>>();
				JSONArray array = (JSONArray) map.get(key);
				int length = array.length();
				for(int i = 0;  i < length; i ++) {
					JSONObject obj = array.getJSONObject(i);
					daValues.add(ZABUtil.convertJSONtoMap(obj));
				}
				map.put(key, daValues);
			} catch (Exception e) {
				LOGGER.log(Level.SEVERE, "Exception occured", e);
				map.remove(key);
			}
		}
	}
	
	private void setDynamicAttributeDetails(JSONObject object, Long experimentId, HashMap<String, String> dimensionData) throws JSONException {

		JSONArray cookieArr = new JSONArray();
		JSONArray jsVariableArr = new JSONArray();
		JSONArray customDimensionArr = new JSONArray();
		
		
		HashMap<String,DynamicAttributes> dynamicAttriHs =  DynamicAttributes.getDynamicAttributesOfExperiment(experimentId.toString());
		
		if(dimensionData.containsKey(ReportRawDataConstants.DYNAMICATTRIBUTES)){
			JSONArray dynamicAttributeAray = new JSONArray(dimensionData.get(ReportRawDataConstants.DYNAMICATTRIBUTES));
			Integer cookieCode =DynamicAttributeType.COOKIE.getAttributeTypeCode();
			Integer jsVariableCode =DynamicAttributeType.JSVARIABLE.getAttributeTypeCode();
			Integer customDimensionCode =DynamicAttributeType.CUSTOMDIMENSION.getAttributeTypeCode();
			
			
			for(int i=0;i<dynamicAttributeAray.length();i++){
				JSONObject dynamicAttribute = (JSONObject)dynamicAttributeAray.get(i);
				String attributeLinkName =(String) dynamicAttribute.get(ReportRawDataConstants.ATTRIBUTE_LINK_NAME);
				if(dynamicAttriHs.containsKey(attributeLinkName)){
					Integer attributeType =(Integer) dynamicAttribute.get(ReportRawDataConstants.ATTRIBUTE_TYPE);
					String attributeValue =(String) dynamicAttribute.get(ReportRawDataConstants.ATTRIBUTE_VALUE);
					JSONObject daObject = new JSONObject();
					daObject.put(ElasticSearchConstants.NAME, attributeLinkName);
					daObject.put(ElasticSearchConstants.VALUE, attributeValue);
					if(attributeType.equals(cookieCode)){
						cookieArr.put(daObject);
					}else if(attributeType.equals(jsVariableCode)){
						jsVariableArr.put(daObject);
					}else if(attributeType.equals(customDimensionCode)){
						customDimensionArr.put(daObject);
					}
					
					dynamicAttriHs.remove(attributeLinkName);
				}
				
			}
			// DYNAMIC ATTRIBUTES WHICK ARE NOT SENT IN REQUEST ARE FILLED WITH 'UNKNOWN'
			
			Set<String> keySet = dynamicAttriHs.keySet();
			Iterator<String> keysItr = keySet.iterator();
			while(keysItr.hasNext()){
				String attributeLinkName  =  keysItr.next();
				DynamicAttributes da = dynamicAttriHs.get(attributeLinkName);
				Integer attributeType = da.getAttributeType();	
				String attributeValue = ReportRawDataConstants.UNKNOWN_VALUE;
				JSONObject daObject = new JSONObject();
				daObject.put(ElasticSearchConstants.NAME, attributeLinkName);
				daObject.put(ElasticSearchConstants.VALUE, attributeValue);
				if(attributeType.equals(cookieCode)){
					cookieArr.put(daObject);
				}else if(attributeType.equals(jsVariableCode)){
					jsVariableArr.put(daObject);
				}else if(attributeType.equals(customDimensionCode)){
					customDimensionArr.put(daObject);
				}
				
			}
			
		}
		
		String urlParamStr = dimensionData.get(ReportRawDataConstants.URLPARAMETER_VALUE);
		JSONArray urlParamArr = VisitorRawDataHandler.parseUrlparamValues(urlParamStr);
		
		object.put(ElasticSearchConstants.NCOOKIE, cookieArr);
		object.put(ElasticSearchConstants.NURLPARAMETER,urlParamArr );
		object.put(ElasticSearchConstants.NJSVARIABLE, jsVariableArr);
		object.put(ElasticSearchConstants.NCUSTOMDIMENSION, customDimensionArr);
		
	}
	
	private void setLocationDetails(VisitorRawDataWrapper wrapper, JSONObject doc) throws JSONException {
		
		String country, city, region;
		
		JSONObject ipDetailsJson = ZABUtil.getIpAddressDetails(wrapper.getIpAddress());
		country = ipDetailsJson.has("COUNTRY_NAME") ? ipDetailsJson.get("COUNTRY_NAME").toString() : "-"; //NO I18N
		if(StringUtils.isEmpty(country) || country.equals("-"))
		{
			country = ReportRawDataConstants.UNKNOWN_VALUE;
		}
		country = country.toUpperCase();
		//Get city details
		city = ipDetailsJson.has("CITY") ? ipDetailsJson.get("CITY").toString() : "-"; //NO I18N
		if(StringUtils.isEmpty(city) || city.equals("-"))
		{
			city = ReportRawDataConstants.UNKNOWN_VALUE;
		}
		city = city.toUpperCase();
		//Get region details
		region = ipDetailsJson.has("REGION") ? ipDetailsJson.get("REGION").toString() : "-"; //NO I18N
		if(StringUtils.isEmpty(region) || region.equals("-"))
		{
			region = ReportRawDataConstants.UNKNOWN_VALUE;
		}
		region = region.toUpperCase();
		
		doc.put(ElasticSearchConstants.COUNTRY, country); 
		doc.put(ElasticSearchConstants.CITY, city);
		doc.put(ElasticSearchConstants.REGION, region);
	}
	
	protected class SessionElasticDoc {
		
		private JSONObject visitorDoc;
		
		private Script script;
		
		private JSONObject updateDoc;

		public JSONObject getUpdateDoc() {
			return updateDoc;
		}

		public void setUpdateDoc(JSONObject updateDoc) {
			this.updateDoc = updateDoc;
		}

		public JSONObject getVisitorDoc() {
			return visitorDoc;
		}

		public void setVisitorDoc(JSONObject visitorDoc) {
			this.visitorDoc = visitorDoc;
		}

		public Script getScript() {
			return script;
		}

		public void setScript(Script script) {
			this.script = script;
		}
	}
}
