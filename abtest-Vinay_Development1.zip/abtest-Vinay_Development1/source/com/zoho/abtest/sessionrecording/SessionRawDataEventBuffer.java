//$Id$
package com.zoho.abtest.sessionrecording;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.zoho.abtest.SR_EVENT_BUFFER;
import com.zoho.abtest.common.ZABColumn;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.common.ZABTable;
import com.zoho.abtest.utility.ZABUtil;

@ZABTable(name=SR_EVENT_BUFFER.TABLE)
public class SessionRawDataEventBuffer extends ZABModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@ZABColumn(name=SR_EVENT_BUFFER.SR_EVENT_BUFFER_ID)
	private Long bufferId;
	
	@ZABColumn(name=SR_EVENT_BUFFER.DATA)
	private String data;

	public Long getBufferId() {
		return bufferId;
	}

	public void setBufferId(Long bufferId) {
		this.bufferId = bufferId;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}
	
	public static SessionRawDataEventBuffer getData(Long id) throws Exception {
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		Criteria c = new Criteria(new Column(SR_EVENT_BUFFER.TABLE, SR_EVENT_BUFFER.SR_EVENT_BUFFER_ID), id, QueryConstants.EQUAL);
		DataObject dobj = getRow(SR_EVENT_BUFFER.TABLE, c);
		ZABUtil.setDBSpace(existingDBSpace);
		return getFirstModelFromDobj(dobj, SR_EVENT_BUFFER.TABLE, SessionRawDataEventBuffer.class);
	}
	
	public void destroyData() throws Exception {
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		Criteria c = new Criteria(new Column(SR_EVENT_BUFFER.TABLE, SR_EVENT_BUFFER.SR_EVENT_BUFFER_ID), this.getBufferId(), QueryConstants.EQUAL);
		deleteResource(c);
		ZABUtil.setDBSpace(existingDBSpace);
	}
	
}
