//$Id$
package com.zoho.abtest.sessionrecording;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;

import com.zoho.abtest.common.ZABRequest;

public class SessionRawDataRequest extends ZABRequest{
	
	@Override
	public void updateFromRequest(HashMap<String, String> map, HttpServletRequest request) 
	{
		
	}
	
	@Override
	public void specificValidation(HashMap<String, String> map, HttpServletRequest request) throws IOException, JSONException 
	{
//		validateUserAgentRawdata(map);
//		ArrayList<String> fields = new ArrayList<String>();
//			
//		if(!map.containsKey(FunnelReportConstants.PORTAL)){
//			fields.add(ReportRawDataConstants.PORTAL);
//		}
//		if(!map.containsKey(FunnelReportConstants.EXPERIMENT_KEY)){
//			fields.add(ReportRawDataConstants.EXPERIMENT_KEY);
//		}
//		if(!map.containsKey(FunnelReportConstants.STEP_KEY)){
//			fields.add(FunnelReportConstants.STEP_KEY);
//		}
//		
//		if(!fields.isEmpty()) {
//			ZABRequest.updateError(map, ZABAction.getAppropriateMessage(ZABConstants.ErrorMessages.MANDATORY_FIELD_MISSING.getErrorString(),fields));
//		}
	}

}
