//$Id$
package com.zoho.abtest.sessionrecording;

import static com.zoho.abtest.funnel.report.FlexibleQueryConstants.PAINLESS;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.lucene.search.join.ScoreMode;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.NestedQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.TermsQueryBuilder;
import org.elasticsearch.script.Script;
import org.elasticsearch.script.ScriptType;
import org.elasticsearch.search.aggregations.Aggregation;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.filter.Filter;
import org.elasticsearch.search.aggregations.bucket.filter.FilterAggregationBuilder;
import org.elasticsearch.search.aggregations.bucket.filters.FiltersAggregationBuilder;
import org.elasticsearch.search.aggregations.bucket.filters.FiltersAggregator.KeyedFilter;
import org.elasticsearch.search.aggregations.bucket.nested.Nested;
import org.elasticsearch.search.aggregations.bucket.nested.NestedAggregationBuilder;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.tophits.TopHitsAggregationBuilder;
import org.elasticsearch.search.sort.SortBuilder;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.audience.AudienceAttributeConstants.AudienceAttributeMatchTypes;
import com.zoho.abtest.audience.AudienceAttributeConstants.AudienceAttributes;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.elastic.ESQuickFilterConstants.QuickFilterAttributes;
import com.zoho.abtest.elastic.ESQuickFilterConstants.QuickFilterBoundValues;
import com.zoho.abtest.elastic.ESQuickFilterStatistics;
import com.zoho.abtest.elastic.ElasticSearchStatistics;
import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.funnel.report.FlexibleQueryConstants;
import com.zoho.abtest.goal.Goal;
import com.zoho.abtest.projectgoals.ProjectGoal;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.report.ReportConstants;
import com.zoho.abtest.sessionrecording.SessionRawData.SessionElasticDoc;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUtil;

public class SessionElasticBand {
	
	private static final String NO_GOALS_ACHIEVED_KEY = "segment.nogoalachieve.name"; //NO I18N
	
	private static final Logger LOGGER = Logger.getLogger(SessionElasticBand.class.getName());
	
	private static boolean isDynamicAttributes(String dimension) {
		return dimension.equals(ElasticSearchConstants.NURLPARAMETER)
				|| dimension.equals(ElasticSearchConstants.NCOOKIE)
				|| dimension.equals(ElasticSearchConstants.NJSVARIABLE)
				|| dimension.equals(ElasticSearchConstants.NCUSTOMDIMENSION);
	}
	
	private static boolean donotCapatalizeDimensions(String dimension) {
		return dimension.equals(ElasticSearchConstants.CURRENTURL)
				|| dimension.equals(ElasticSearchConstants.REFFERERURL)
				|| dimension.equals(AudienceAttributes.GOALS.getKeyName())
				|| isDynamicAttributes(dimension);
	}
	
	private static String[] handleDimensionValues(JSONArray valueArr, String dimension) throws JSONException {
		String[] valueStrArr  = new String[valueArr.length()];
		for(int valueIdex=0;valueIdex<valueArr.length();valueIdex++)
		{
			String value = null;
			if (donotCapatalizeDimensions(dimension))
			{
				value = valueArr.getString(valueIdex);
			}else if(FlexibleQueryConstants.FIELD_VALUE_SWAPS.containsKey(dimension)) {
				HashMap<String, String> valueSwaps = FlexibleQueryConstants.FIELD_VALUE_SWAPS.get(dimension);
				String val = valueArr.getString(valueIdex);
				if(valueSwaps.containsKey(val)) {								
					value = valueSwaps.get(val);
				} else {
					value = valueArr.getString(valueIdex).toUpperCase();
				}
			}
			else
			{
				value = valueArr.getString(valueIdex).toUpperCase();
			}
			valueStrArr[valueIdex] = value;
		}
		return valueStrArr;
	}
	
	public static Long getSessionCount(List<String> portalList, Long startTime, Long endTime) {
		Long count = 0l;
		try {
			String indexPattern = ElasticSearchConstants.DEFAULT_INDEX_PREFIX + "*";
			Script script = new Script(ScriptType.INLINE, PAINLESS, SessionElasticDocDetails.ACHEIVED_MIN_DURATION, new HashMap<String, Object>());
			BoolQueryBuilder builder =  getVisitorBasicCriteria()
											.must(QueryBuilders.termsQuery(ElasticSearchConstants.PORTAL, portalList))
											.must(QueryBuilders
									   						.rangeQuery(ElasticSearchConstants.TIME)
									   						.gte(startTime)
									   						.lte(startTime));
			
			count = ElasticSearchUtil.getCount(indexPattern, ElasticSearchConstants.SESSION_RAW_DATA_TYPE, builder);
			
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Exception occured", e);
		}
		return count;
	}
	
	public static HashMap<String, Long> getSessionCount(List<String> portalList) {
		HashMap<String, Long> portalCountMap = new HashMap<String, Long>();
		try {
			String indexPattern = ElasticSearchConstants.DEFAULT_INDEX_PREFIX + "*";
			Script script = new Script(ScriptType.INLINE, PAINLESS, SessionElasticDocDetails.ACHEIVED_MIN_DURATION, new HashMap<String, Object>());
			BoolQueryBuilder builder =  getVisitorBasicCriteria()
											.must(QueryBuilders.termsQuery(ElasticSearchConstants.PORTAL, portalList));
			
			TermsAggregationBuilder expAggr2 = AggregationBuilders.terms("visitor_count").  //NO I18N
					field(ElasticSearchConstants.SESSION_ID).
					size(ElasticSearchConstants.INTEGER_MAX_COUNT);
			
			SearchResponse response = ElasticSearchUtil.getData(indexPattern, ElasticSearchConstants.SESSION_RAW_DATA_TYPE, 0, builder, expAggr2);
			Aggregations aggrResponse = response.getAggregations();
			Terms terms = aggrResponse.get("visitor_count");
			List<? extends Bucket> buckets = terms.getBuckets();
			for(Bucket bucket:buckets)
			{
				Long visitorCount = 0l;
				String portal = (String)bucket.getKey();
				visitorCount = bucket.getDocCount();
				portalCountMap.put(portal, visitorCount);
			}
			
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Exception occured", e);
		}
		return portalCountMap;
	}
	
	protected static void saveSessionRawData(SessionElasticDoc doc, String portal, String index) throws Exception {
		String type = ElasticSearchConstants.SESSION_RAW_DATA_TYPE;
		JSONObject jsonObject = doc.getVisitorDoc();
		jsonObject.put(ElasticSearchConstants.PORTAL, portal);
		try {
			
			// Needs to Reverify This code.
			
			String sessionId = jsonObject.getString(ElasticSearchConstants.SESSION_ID);
			GetResponse response = ElasticSearchUtil
					.getDataById(
							index,
							type,
							sessionId,
							new String[] { ElasticSearchConstants.SESSION_IS_PARTIAL_DATA},
							null);

			Boolean isPartial = false;
			
			if(response.isExists()) {
				Map<String, Object> sourceMap =response.getSource();
				 isPartial = (Boolean)sourceMap.get(ElasticSearchConstants.SESSION_IS_PARTIAL_DATA);
			}
			
			if(isPartial) {				
				ElasticSearchUtil.updateIndex(index, type, sessionId, doc.getUpdateDoc().toString());
			}
			
			ElasticSearchUtil.upsertIndex(index, type, sessionId, jsonObject.toString(), doc.getScript(), 5);

		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		LOGGER.log(Level.INFO,"Elastic search funnel rawdata push completed");
	}

	protected static String getElasticIndex(String portal) throws Exception {
		Long zsoid = ZABServiceOrgUtil.getZSOIDFromDomain(portal);
		if(zsoid == null)
		{
			LOGGER.log(Level.SEVERE,"Invalid portal provided :"+portal);
		}
		return ElasticSearchUtil.getIndexByPortal(portal);
	}
	
	public static BoolQueryBuilder getVisitorBasicCriteria(Long zsoid, String experimentKey) {
		return getVisitorBasicCriteria()
				.must(QueryBuilders.termQuery(ElasticSearchConstants.ZSOID, zsoid))
				.must(QueryBuilders.termQuery(ElasticSearchConstants.EXPERIMENTKEY, experimentKey));
	}
	
	public static BoolQueryBuilder getVisitorBasicCriteria() {
		Script script = new Script(ScriptType.INLINE, PAINLESS, SessionElasticDocDetails.ACHEIVED_MIN_DURATION, new HashMap<String, Object>());
		return QueryBuilders
				.boolQuery()
				.mustNot(QueryBuilders.termQuery(ElasticSearchConstants.IS_OPT_OUT, Boolean.TRUE))
				.must(QueryBuilders.termQuery(ElasticSearchConstants.SESSION_IS_PARTIAL_DATA, Boolean.FALSE))
				.must(QueryBuilders.boolQuery().must(QueryBuilders.scriptQuery(script)));
	}
	
	public static BoolQueryBuilder getVisitorBasicCriteria(Long zsoid) {
		return getVisitorBasicCriteria().must(QueryBuilders.termQuery(ElasticSearchConstants.ZSOID, zsoid));
				
	}
	
	public static FiltersAggregationBuilder getEventsAggregation(Long zsoid, String experimentKey, String sessionId) {

		BoolQueryBuilder totalCountBuilder = QueryBuilders
												.boolQuery()
												.must(QueryBuilders.termQuery(ElasticSearchConstants.ZSOID, zsoid))
												.must(QueryBuilders.termQuery(ElasticSearchConstants.EXPERIMENTKEY, experimentKey))
												.must(QueryBuilders.termQuery(ElasticSearchConstants.SESSION_ID, sessionId));
		
		
		BoolQueryBuilder userInteractionCountBuilder = QueryBuilders
															.boolQuery()
															.must(QueryBuilders.termQuery(ElasticSearchConstants.ZSOID, zsoid))
															.must(QueryBuilders.termQuery(ElasticSearchConstants.EXPERIMENTKEY, experimentKey))
															.must(QueryBuilders.termQuery(ElasticSearchConstants.SESSION_ID, sessionId))
															.must(QueryBuilders.termsQuery(ElasticSearchConstants.SESSION_EVENT_TYPE, SessionRecordingConstants.USER_INTERACION_EVENTS));

		return AggregationBuilders
		         .filters("events_count", //NO I18N
		            new KeyedFilter("total_events_count", totalCountBuilder), //NO I18N
		            new KeyedFilter("interaction_events_count", userInteractionCountBuilder)); //NO I18N
	}
	
	public static TopHitsAggregationBuilder getTopHitsAggregation(String[] fields, Integer from, Integer size, SortBuilder sort) {
		TopHitsAggregationBuilder aggs = AggregationBuilders.topHits("docs") //NO I18N
													.from(from)
													.size(size)
													.fetchSource(fields, new String[]{});
		
		if(sort!=null) {
			aggs.sort(sort);
		}
		return aggs;
	}
	
	private static void handleGoalSegment(String operator, List<BoolQueryBuilder> subConditionqueryList, String[] valueStrArr) {
		BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery(); 
		TermsQueryBuilder paramNameQuery = QueryBuilders.termsQuery(ElasticSearchConstants.ACHEIVED_GOALS+"."+ElasticSearchConstants.GOALID, valueStrArr);
		BoolQueryBuilder conditionQueries = QueryBuilders.boolQuery();
		
		Boolean noGoalAchievedFilter = valueStrArr.length == 1 && valueStrArr[0].isEmpty();
		
		if(operator.equals(AudienceAttributeMatchTypes.EQUALS.getTypeId().toString())) {								
			if(noGoalAchievedFilter) {
				Script script = new Script(ScriptType.INLINE, PAINLESS, SessionElasticDocDetails.NO_GOALS_ACHIEVED_FILTER, new HashMap<String, Object>());
				conditionQueries.must().add(QueryBuilders.scriptQuery(script));
			} else {
				conditionQueries.must().add(paramNameQuery);
				
			}
		} else if(operator.equals(AudienceAttributeMatchTypes.NOT_EQUALS.getTypeId().toString())){
			conditionQueries.mustNot().add(paramNameQuery);
		}
		
		
		if(noGoalAchievedFilter) {
			boolQueryBuilder.must(conditionQueries);
		} else {			
			NestedQueryBuilder nestedQuery = QueryBuilders.nestedQuery(ElasticSearchConstants.ACHEIVED_GOALS, conditionQueries, ScoreMode.None);
			boolQueryBuilder.must(nestedQuery);
		}
		subConditionqueryList.add(boolQueryBuilder);
	}
	
	private static void handleTimeSpentSegment(JSONObject atomicCondition, List<BoolQueryBuilder> subConditionqueryList) throws JSONException {
		 HashMap<String, Object> hs = new HashMap<String, Object>();
		
		 String boundUnitKey = atomicCondition.getString(SessionReportConstants.BOUND_UNIT_KEY);
		 String operator = atomicCondition.getString("operator");  //No I18N
		 
		 QuickFilterBoundValues bound = QuickFilterBoundValues.getQuickFilterAttributeByLinkname(boundUnitKey);
		 
		 Integer boundStartValue = atomicCondition.has(SessionReportConstants.BOUNDARY_START_VALUE)? atomicCondition.getInt(SessionReportConstants.BOUNDARY_START_VALUE):null;
		 Integer boundEndValue = atomicCondition.has(SessionReportConstants.BOUNDARY_END_VALUE)?atomicCondition.getInt(SessionReportConstants.BOUNDARY_END_VALUE):null;
		 
		 if(boundStartValue!=null || boundEndValue!=null) {			 
			 Long startInMillis = null,
					 endInMillis = null;
			 
			 switch(bound) {
			 case MINUTES:
				 startInMillis = boundStartValue == null?null:boundStartValue*60000l;
				 endInMillis = boundEndValue == null?null:boundEndValue*60000l;
				 break;
			 case SECONDS:
				 startInMillis = boundStartValue == null?null:boundStartValue*1000l;
				 endInMillis = boundEndValue == null?null:boundEndValue*1000l;
				 break;
			 }
			 
			 hs.put("starttime", startInMillis);
			 hs.put("endtime", endInMillis);
			 hs.put("operator", Integer.parseInt(operator));
			 
			 Script script = new Script(ScriptType.INLINE, PAINLESS, SessionElasticDocDetails.TIME_SPENT_FILTER, hs);
			 
			 BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery().must(QueryBuilders.scriptQuery(script));
			 subConditionqueryList.add(boolQueryBuilder);
		 }
		 
	}
	
	private static void handleNumberOfPages(JSONObject atomicCondition, List<BoolQueryBuilder> subConditionqueryList) throws JSONException {
		 HashMap<String, Object> hs = new HashMap<String, Object>();
		
		 String operator = atomicCondition.getString("operator");  //No I18N
		 
		 Integer boundStartValue = atomicCondition.has(SessionReportConstants.BOUNDARY_START_VALUE)? atomicCondition.getInt(SessionReportConstants.BOUNDARY_START_VALUE):null;
		 Integer boundEndValue = atomicCondition.has(SessionReportConstants.BOUNDARY_END_VALUE)?atomicCondition.getInt(SessionReportConstants.BOUNDARY_END_VALUE):null;
		 
		 if(boundStartValue!=null || boundEndValue!=null) {			 
			 hs.put("start", boundStartValue);
			 hs.put("end", boundEndValue);
			 hs.put("operator", Integer.parseInt(operator));
			 
			 Script script = new Script(ScriptType.INLINE, PAINLESS, SessionElasticDocDetails.UNIQUE_PAGE_COUNT_FILTER, hs);
			 BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery().must(QueryBuilders.scriptQuery(script));
			 
			 subConditionqueryList.add(boolQueryBuilder);
		 }
		 
	}
	
	public static ArrayList<ESQuickFilterStatistics> getGoalsQuickFilterStatistics(String indexName, Long experimentId, Long startTime, Long endTime) {
		ArrayList<ESQuickFilterStatistics> stats = new ArrayList<ESQuickFilterStatistics>();
		try {			
			Experiment experiment = Experiment.getExperimentById(experimentId);
			
			ArrayList<Goal> goals = ProjectGoal.getProjectGoalsForProjectWithoutStats(experiment.getProjectId(), null);
			
			Long zsoid = Long.parseLong(ZABUtil.getDBSpace());
			
			BoolQueryBuilder query = SessionElasticBand.getVisitorBasicCriteria(zsoid, experiment.getExperimentKey());
			query.must(QueryBuilders.rangeQuery(ElasticSearchConstants.TIME).gte(startTime).lte(endTime));
			
			ArrayList<AggregationBuilder> aggs = new ArrayList<AggregationBuilder>();
			
			String field = ElasticSearchConstants.ACHEIVED_GOALS + "." + ElasticSearchConstants.GOALID;
			
			HashMap<String, String> goalNameIdMap = new HashMap<String, String>();
			
			goals.forEach(goal -> {
				NestedAggregationBuilder agg = AggregationBuilders.nested(goal.getGoalId().toString(), ElasticSearchConstants.ACHEIVED_GOALS);
				QueryBuilder builder = QueryBuilders.boolQuery().must(QueryBuilders.termQuery(field, goal.getGoalId()));
				FilterAggregationBuilder fag = AggregationBuilders.filter(goal.getGoalId().toString(), builder);
				agg.subAggregation(fag);
				aggs.add(agg);
				
				goalNameIdMap.put(goal.getGoalId().toString(), goal.getGoalName());
			});
			
			Script script = new Script(ScriptType.INLINE, PAINLESS, SessionElasticDocDetails.NO_GOALS_ACHIEVED_FILTER, new HashMap<String, Object>());
			QueryBuilder builder = QueryBuilders.boolQuery().must(QueryBuilders.scriptQuery(script));
			FilterAggregationBuilder fag = AggregationBuilders.filter(NO_GOALS_ACHIEVED_KEY, builder);
			aggs.add(fag);
			
			SearchResponse response = ElasticSearchUtil.getData(indexName, ElasticSearchConstants.SESSION_RAW_DATA_TYPE, 0, query, aggs);
			
			Long totalHits =  response.getHits().getTotalHits();
			
			if(totalHits > 0 && aggs.size() > 0) {
				List<Aggregation> resAggs = response.getAggregations().asList();
				for(Aggregation agg: resAggs) {
					Filter fagg = null;
					ESQuickFilterStatistics stat = new ESQuickFilterStatistics();
					if(agg instanceof Nested) {
						Nested nagg = (Nested)agg;
						String goalId = nagg.getName();
						fagg = (Filter) nagg.getAggregations().asList().get(0);
						long count = fagg.getDocCount();
						stat.setDiplayName(goalNameIdMap.get(goalId));
						stat.setSegmentValue(fagg.getName());
						stat.setVisitorCount(count);
						stat.setSuccess(true);
						stats.add(stat);
					} else if(agg instanceof Filter) {
						fagg = (Filter) agg;
						long count = fagg.getDocCount();
						stat.setDiplayName(ZABAction.getMessage(NO_GOALS_ACHIEVED_KEY));
						stat.setSegmentValue("");
						stat.setVisitorCount(count);
						stat.setSuccess(true);
						stats.add(stat);
					}
				}
			}
			
			LOGGER.log(Level.SEVERE, "REsponse", response);
			
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Exception occured", e);
		}
		
		return stats;
	}
	
	public static QueryBuilder generateMultiSegmentCriteria(String criteriaObjectStr, Long startDateInMillis, Long endDateInMillis) throws Exception
	{
		BoolQueryBuilder boolQueryBuilderlevel1 = QueryBuilders.boolQuery();
		try
		{
			
			List<BoolQueryBuilder> conditionqueryList = new ArrayList<BoolQueryBuilder>();
			
			JSONObject rootJsonObject = new JSONObject(criteriaObjectStr);
			String rootOperator = rootJsonObject.getString("condition_type"); //No I18N

			JSONArray rootJsonArr = rootJsonObject.getJSONArray("conditions"); //No I18N
			int rootArrSize = rootJsonArr.length();
			
			for(int i=0;i<rootArrSize;i++)
			{
				
					List<BoolQueryBuilder> subConditionqueryList = new ArrayList<BoolQueryBuilder>();
					
					JSONObject subJsonObject = rootJsonArr.getJSONObject(i);
					String subOperator = subJsonObject.getString("condition_type"); //No I18N
					JSONArray subJsonArr = subJsonObject.getJSONArray("conditions"); //No I18N
					
					int subArrSize = subJsonArr.length();
				
					for(int j=0;j<subArrSize;j++)
					{
						
						JSONObject atomicCondition = subJsonArr.getJSONObject(j);
						String dimension = atomicCondition.getString("type");  //No I18N
						String operator = atomicCondition.getString("operator");  //No I18N
						
						boolean isLocation = dimension.equals(ReportConstants.SEGMENT_LOCATION);
						
						if(FlexibleQueryConstants.FIELD_KEY_SWAPS.containsKey(dimension)) {
							dimension = FlexibleQueryConstants.FIELD_KEY_SWAPS.get(dimension);
						} else if(dimension.equals(SessionReportConstants.URLVISITED)) {
							dimension = ElasticSearchConstants.URLS_VISITED + "." + ElasticSearchConstants.URL;
						}
						
						//Array of string values
						JSONArray valueArr = new JSONArray();
						String[] valueStrArr = {};
						if(atomicCondition.has("values")) {
							valueArr = atomicCondition.getJSONArray("values");  //No I18N
							valueStrArr  = handleDimensionValues(valueArr, dimension);
						} else if(atomicCondition.has("value") && !atomicCondition.getString("value").isEmpty()) {
							String value = atomicCondition.getString("value");
							valueArr.put(value);
							valueStrArr = new String[]{value};
						}
						
						String dynamicAttributeLinkName = "";
						if(atomicCondition.has(ReportConstants.ATTRIBUTE_NAME))
						{
							dynamicAttributeLinkName = atomicCondition.getString(ReportConstants.ATTRIBUTE_NAME);
						}
						
						boolean isDynamicAttr = false;
						String dimensionNamePath = ""; 
						String dimensionValuePath = ""; 
						
						if (isDynamicAttributes(dimension))
						{
							isDynamicAttr = true;
							//due to change in property name in ES
							dimension = ElasticSearchConstants.URLS_VISITED + "." + dimension; //No I18N
							dimensionNamePath = dimension+"."+ElasticSearchConstants.NAME;
							dimensionValuePath = dimension+"."+ElasticSearchConstants.VALUE;
						}
						
						if(dimension.equals(AudienceAttributes.GOALS.getKeyName())) {
							handleGoalSegment(operator, subConditionqueryList, valueStrArr);
						} else if(dimension.equals(QuickFilterAttributes.TIMESPENT.getSegmentName())) {
							handleTimeSpentSegment(atomicCondition, subConditionqueryList);
						} else if(dimension.equals(QuickFilterAttributes.PAGECOUNT.getSegmentName())) {
							handleNumberOfPages(atomicCondition, subConditionqueryList);
						} else {							
							BoolQueryBuilder boolQueryBuilder = ElasticSearchStatistics.innerConditionBuilder(
									operator, dimension, valueStrArr, valueArr,
									isDynamicAttr, isLocation,
									dynamicAttributeLinkName, dimensionNamePath,
									dimensionValuePath);
							subConditionqueryList.add(boolQueryBuilder);
						}
					
					}
					
					
					BoolQueryBuilder boolQueryBuilderlevel2 = QueryBuilders.boolQuery();
					
					switch(subOperator)
					{
					case "1":  //No I18N
						//must
						boolQueryBuilderlevel2.must().addAll(subConditionqueryList);
						break;
					case "2":  //No I18N
						//should
						boolQueryBuilderlevel2.should().addAll(subConditionqueryList);
						break;
					}
					
					conditionqueryList.add(boolQueryBuilderlevel2);
					
			}
			
			switch(rootOperator)
			{
			case "1":  //No I18N
				//must
				boolQueryBuilderlevel1.must().addAll(conditionqueryList);
				break;
			case "2":  //No I18N
				//should
				boolQueryBuilderlevel1.should().addAll(conditionqueryList);
				break;
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred",ex);
		}
		return boolQueryBuilderlevel1;
		
	}
	
}
