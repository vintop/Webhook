//$Id$
package com.zoho.abtest.sessionrecording;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.listener.IPRestrictionData;
import com.zoho.abtest.listener.ZABListener;
import com.zoho.mqueue.consumer.MessageListener;

public class SessionAssetDigestListener extends ZABListener implements MessageListener<String, String> {

	private static final Logger LOGGER = Logger.getLogger(SessionAssetDigestListener.class.getName());
	
	@Override
	public IPRestrictionData getIPRestrictionData(Object message)
			throws ZABException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void consumeMessage(Object object) throws Exception {
		try {
			if(object!=null) {	
		//TODO: when we decide to save other assets, uncomment below and adapt with current changesets
//				SResourceMQMessage message = (SResourceMQMessage)object;
//				SessionPageResources resource = new SessionPageResources(message);
//				SessionPageSnapShotEngine.grabResource(resource, message.getPageKey(), message.getPortalName());
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Exception occured", e);
		}
	}

}
