//$Id$
package com.zoho.abtest.sessionrecording;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class SessionRandomAliasNameGenerator {
	
	private static final List<String> NOUNS = Arrays.asList("aardvark", 		//NO I18N
			"albatross", "alligator", "alpaca", "ant", "anteater", "antelope",	//NO I18N
			"ape", "armadillo", "baboon", "badger", "barracuda", "bat", "bear",	//NO I18N
			"beaver", "bee", "bison", "boar", "buffalo", "butterfly", "camel",	//NO I18N
			"capybara", "caribou", "cassowary", "cat", "caterpillar", "cattle",	//NO I18N
			"chamois", "cheetah", "chicken", "chimpanzee", "chinchilla",	//NO I18N
			"chough", "clam", "cobra", "cockroach", "cod", "cormorant",	//NO I18N
			"coyote", "crab", "crane", "crocodile", "crow", "curlew", "deer",	//NO I18N
			"dinosaur", "dog", "dogfish", "dolphin", "donkey", "dotterel",	//NO I18N
			"dove", "dragonfly", "duck", "dugong", "dunlin", "eagle",	//NO I18N
			"echidna", "eel", "eland", "elephant", "elephant-seal", "elk",	//NO I18N
			"emu", "falcon", "ferret", "finch", "fish", "flamingo", "fly",	//NO I18N
			"fox", "frog", "gaur", "gazelle", "gerbil", "giant-panda",	//NO I18N
			"giraffe", "gnat", "gnu", "goat", "goose", "goldfinch", "goldfish",	//NO I18N
			"gorilla", "goshawk", "grasshopper", "grouse", "guanaco",	//NO I18N
			"guinea-fowl", "guinea-pig", "gull", "hamster", "hare", "hawk",	//NO I18N
			"hedgehog", "heron", "herring", "hippopotamus", "hornet", "horse",	//NO I18N
			"human", "hummingbird", "hyena", "ibex", "ibis", "jackal",	//NO I18N
			"jaguar", "jay", "jellyfish", "kangaroo", "kingfisher", "koala",	//NO I18N
			"komodo-dragon", "kookabura", "kouprey", "kudu", "lapwing", "lark",	//NO I18N
			"lemur", "leopard", "lion", "llama", "lobster", "locust", "loris",	//NO I18N
			"louse", "lyrebird", "magpie", "mallard", "manatee", "mandrill",	//NO I18N
			"mantis", "marten", "meerkat", "mink", "mole", "mongoose",	//NO I18N
			"monkey", "moose", "mouse", "mosquito", "mule", "narwhal", "newt",	//NO I18N
			"nightingale", "octopus", "okapi", "opossum", "oryx", "ostrich",	//NO I18N
			"otter", "owl", "ox", "oyster", "panther", "parrot", "partridge",	//NO I18N
			"peafowl", "pelican", "penguin", "pheasant", "pig", "pigeon",	//NO I18N
			"polar-bear", "pony", "porcupine", "porpoise", "prairie-dog",	//NO I18N
			"quail", "quelea", "quetzal", "rabbit", "raccoon", "rail", "ram",	//NO I18N
			"rat", "raven", "red-deer", "red-panda", "reindeer", "rhinoceros",	//NO I18N
			"rook", "salamander", "salmon", "sand-dollar", "sandpiper",	//NO I18N
			"sardine", "scorpion", "sea-lion", "sea-urchin", "seahorse",	//NO I18N
			"seal", "shark", "sheep", "shrew", "skunk", "snail", "snake",	//NO I18N
			"sparrow", "spider", "spoonbill", "squid", "squirrel", "starling",	//NO I18N
			"stingray", "stinkbug", "stork", "swallow", "swan", "tapir",	//NO I18N
			"tarsier", "termite", "tiger", "toad", "trout", "turkey", "turtle",	//NO I18N
			"viper", "vulture", "wallaby", "walrus", "wasp",	//NO I18N
			"water-buffalo", "weasel", "whale", "wolf", "wolverine", "wombat",	//NO I18N
			"woodcock", "woodpecker", "worm", "wren", "yak", "zebra");	//NO I18N
	
	private static final List<String> ADJECTIVES = Arrays.asList("adorable",//NO I18N
			"fair", "fancy", "perfect", "attractive", "fine", "pleasant",//NO I18N
			"beautiful", "precious", "glowing", "blushing", "gorgeous",//NO I18N
			"graceful", "bright", "shiny", "handsome", "slender", "clumsy",//NO I18N
			"healthy", "snobbish", "colorful", "hilarious", "sparkling",//NO I18N
			"confident", "splendid", "cultured", "spotless", "lovely",//NO I18N
			"magnificent", "elegant", "warm", "wild", "adaptable",//NO I18N
			"adventurous", "affectionate", "ambitious", "amiable",//NO I18N
			"compassionate", "considerate", "courageous", "courteous",//NO I18N
			"diligent", "empathetic", "exuberant", "frank", "generous",//NO I18N
			"gregarious", "impartial", "intuitive", "inventive", "passionate",//NO I18N
			"persistent", "philosophical", "practical", "rational", "reliable",//NO I18N
			"resourceful", "sensible", "sincere", "sympathetic", "unassuming",//NO I18N
			"witty");//NO I18N
	
	private static String capitalize(String s) {
		return s.substring(0, 1).toUpperCase() + s.substring(1);
	}
	
	public static String generateRandomName() {
		Random r = new Random();
		Integer nounIndex =  r.nextInt(NOUNS.size()-1);
		Integer adjIndex =  r.nextInt(ADJECTIVES.size()-1);
		return capitalize(ADJECTIVES.get(adjIndex))+" "+ capitalize(NOUNS.get(nounIndex));
	}
	
}
