//$Id$
package com.zoho.abtest.sessionrecording;

import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.listener.IPRestrictionData;
import com.zoho.abtest.listener.ZABListener;
import com.zoho.abtest.report.ReportRawDataConstants;
import com.zoho.abtest.report.VisitorRawDataWrapper;
import com.zoho.mqueue.consumer.MessageListener;

public class SessionRawDataListener extends ZABListener implements MessageListener<String, String> {
	
	private static final Logger LOGGER = Logger.getLogger(SessionRawDataListener.class.getName());

	@Override
	public IPRestrictionData getIPRestrictionData(Object message)
			throws ZABException {
		VisitorRawDataWrapper wrapper = (VisitorRawDataWrapper)message;
		if(wrapper.getSessionRawData().size() > 0) {			
			HashMap<String, String> sessionRawData = wrapper.getSessionRawData().get(0);
			String portal = sessionRawData.get(ReportRawDataConstants.PORTAL);
			
			String experimentKey = sessionRawData.get(ReportRawDataConstants.EXPERIMENT_KEY);
			setDBSpace(portal);
			Long projectId = Experiment.getProjectIdByExperimentKey(experimentKey);
			LOGGER.log(Level.INFO, "Getting IP Address from session raw data:"+experimentKey+", "+projectId+", ****");
			return new IPRestrictionData(portal, projectId, wrapper.getIpAddress());
		}
		return null;
	}

	@Override
	public void consumeMessage(Object obj) throws Exception {
		try {			
			if(obj!=null) {
				VisitorRawDataWrapper wrapper = (VisitorRawDataWrapper)obj;
				SessionRawDataInHandler.handleSessionRawData(wrapper);
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			try {
				VisitorRawDataWrapper wrapper = (VisitorRawDataWrapper)obj;
				SessionRawDataPageBuffer buffer = SessionRawDataPageBuffer.getData(wrapper.getPageBufferId());
				buffer.destroyData();
				
			} catch (Exception e2) {
				LOGGER.log(Level.SEVERE, e2.getMessage(),e2);
			}
			
			try {
				VisitorRawDataWrapper wrapper = (VisitorRawDataWrapper)obj;
				SessionRawDataPageBuffer buffer = SessionRawDataPageBuffer.getData(wrapper.getEventBufferId());
				buffer.destroyData();
				
			} catch (Exception e2) {
				LOGGER.log(Level.SEVERE, e2.getMessage(),e2);
			}
//			throw new Exception(e);
		}
	}

}
