//$Id$
package com.zoho.abtest.sessionrecording;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.audience.AudienceAttributeConstants.AudienceAttributeMatchTypes;
import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.report.ElasticSearchConstants.ElasticJSONColumn;


public class SessionElasticDocDetails {
	
	private static final String UPDATE_URLS_VISITED =   "def urls_visited = ctx._source."+ElasticSearchConstants.URLS_VISITED+";" //NO I18N
														+"urls_visited = urls_visited == null?[]:urls_visited;" 	//NO I18N
														+"def page_visit = urls_visited.find(p -> p.page_id == params.page_id);" //NO I18N
														+"if(page_visit!=null){ " 									//NO I18N
														+	"for(int i=0; i < params.merge_fields.length; i++) {" 	//NO I18N
														+ 		"page_visit[params.merge_fields[i]] = params.url_visited[params.merge_fields[i]];" //NO I18N
														+ 	"}" 													//NO I18N
														+ 	"page_visit.is_partial_data = false;" 					//NO I18N
														+"} else {" 												//NO I18N
														+   "urls_visited.add(params.url_visited);" //NO I18N
														+"}" 														//NO I18N
														+"ctx._source."+ElasticSearchConstants.URLS_VISITED+"=urls_visited;"; //NO I18N
	
	private static final String UPDATE_LAST_URL_VISITED = "if(params.last_url!=null && " //NO I18N
																+ "params.last_act_time > ctx._source."+ElasticSearchConstants.TIME+") { "	//NO I18N							//NO I18N
																+ "ctx._source."+ElasticSearchConstants.LAST_URL_VISITED+"= params.last_url;" //NO I18N
														   +"}"; //NO I18N
	
	
	private static final String UPDATE_INTERACTED_TIME = "if(params.last_int_time!=null && " //NO I18N
																	+ "(ctx._source."+ElasticSearchConstants.LAST_INTERACTED_TIME+"==null ||" //NO I18N
																	+ "ctx._source."+ElasticSearchConstants.LAST_INTERACTED_TIME+"> params.last_int_time)) {" //NO I18N
															+"ctx._source."+ElasticSearchConstants.LAST_INTERACTED_TIME+"= params.last_int_time;" //NO I18N
														+"}"; //NO I18N
	
	private static final String UPDATE_GOALS = "def acheived_goals = ctx._source."+ElasticSearchConstants.ACHEIVED_GOALS+";" //NO I18N
												+"acheived_goals = acheived_goals == null?[]:acheived_goals;" 	//NO I18N
												+"if(params.acheived_goals!=null) {"//NO I18N
													+"for(int i=0; i<params.acheived_goals.length; i++) {"//NO I18N
													+"    def agoal = acheived_goals.find(ag -> params.acheived_goals[i].goalid == ag.goalid);"//NO I18N
													+"    if(agoal == null) {"//NO I18N
													+"        acheived_goals.add(params.acheived_goals[i]);"//NO I18N
													+"    }"//NO I18N
													+"}"//NO I18N
													+"ctx._source."+ElasticSearchConstants.ACHEIVED_GOALS+"=acheived_goals;" //NO I18N
												+"}"; //NO I18N
	
	private static final String UPDATE_ACTIVITY_TIME = "def act_time = (ctx._source."+ElasticSearchConstants.TIME+" + params.timer);" //NO I18N
													  + "if(params.last_act_time!=null && " //NO I18N
														+ "(ctx._source."+ElasticSearchConstants.LAST_ACTIVITY_TIME+"== null ||" //NO I18N
														+ "act_time  >  ctx._source."+ElasticSearchConstants.LAST_ACTIVITY_TIME+ ") ) {" //NO I18N 
														+ "ctx._source."+ElasticSearchConstants.LAST_ACTIVITY_TIME+"= act_time;"  //NO I18N
													  +"}";
	
	/**
	 * Update vistor document when URL is visited by same user next time.
	 * Params:
	 * url_visited
	 * last_url
	 * last_act_time
	 * merge_fields
	 * 
	 */
	public static final String UPDATE_SESSION_DOC_SCRIPT = 	 UPDATE_URLS_VISITED
															
														   + UPDATE_LAST_URL_VISITED
															
														   + UPDATE_INTERACTED_TIME
														   
														   + UPDATE_GOALS
														   
														   + UPDATE_ACTIVITY_TIME;
	
	
	public static final String SOFT_DELETE_RECORDING = "ctx._source."+ElasticSearchConstants.IS_OPT_OUT+"=true;"; //NO I18N
	
	
	/**
	 * Scripted field for computing timer
	 * Params:
	 * fv_time
	 * 
	 */
	public static final String ACHEIVED_MIN_DURATION = "return doc['"+ElasticSearchConstants.LAST_ACTIVITY_TIME+"'].value - doc['"+ElasticSearchConstants.TIME+"'].value > 0"; //NO I18N
	
	public static final String TIME_SPENT_FILTER = "def timespent = doc['"+ElasticSearchConstants.LAST_ACTIVITY_TIME+"'].value - doc['"+ElasticSearchConstants.TIME+"'].value;" //NO I18N
												  +"if(params.operator =="+AudienceAttributeMatchTypes.MORETHAN.getTypeId()+") {" //NO I18N
												  		+"return timespent > params.starttime;" //NO I18N
												  +"} else if(params.operator =="+AudienceAttributeMatchTypes.LESSTHAN.getTypeId()+") {" //NO I18N
														+"return timespent < params.endtime;" //NO I18N
											      +"} else  if(params.operator =="+AudienceAttributeMatchTypes.BETWEEN.getTypeId()+") {" //NO I18N
											      		+"return timespent > params.starttime && timespent < params.endtime;" //NO I18N
											      +"}"
											      + "return false;"; //NO I18N
	
	public static final String UNIQUE_PAGE_COUNT_FILTER = "def urlSet = new HashSet();" //NO I18N
												+ "for(int i=0; i<params._source."+ElasticSearchConstants.URLS_VISITED+".length;i++) {" //NO I18N
													+" if(params._source."+ElasticSearchConstants.URLS_VISITED+"[i].url !=null) {" //NO I18N
															+ "urlSet.add(params._source."+ElasticSearchConstants.URLS_VISITED+"[i].url);" //NO I18N
													+ "}"
												+ "}" //NO I18N
												+ "def pageCount = urlSet.size();" //NO I18N
												+"if(params.operator =="+AudienceAttributeMatchTypes.MORETHAN.getTypeId()+") {" //NO I18N
													+"return pageCount > params.start;" //NO I18N
												+"} else if(params.operator =="+AudienceAttributeMatchTypes.LESSTHAN.getTypeId()+") {" //NO I18N
													+"return pageCount < params.end;" //NO I18N
												+"} else  if(params.operator =="+AudienceAttributeMatchTypes.BETWEEN.getTypeId()+") {" //NO I18N
														+"return pageCount >= params.start && pageCount <= params.end;" //NO I18N
												+"}"
												+ "return false;"; //NO I18N
	
	public static final String NO_GOALS_ACHIEVED_FILTER = "return params._source."+ElasticSearchConstants.ACHEIVED_GOALS+".length == 0"; //NO I18N
	
	public static class SessionRawDataType {
			
			public static final ArrayList<ElasticJSONColumn> FIELDS_META;
			static {
				ArrayList<ElasticJSONColumn> funnelRawDataTypes = new ArrayList<ElasticJSONColumn>();
				funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.PORTAL, "string", false)); //NO I18N
				funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.ZSOID, "long", false)); //NO I18N
				funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.EXPERIMENTID, "long", false)); //NO I18N
				funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.EXPERIMENTKEY, "string", false)); //NO I18N
				funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.USERTYPE, "string", false)); //NO I18N
				funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.SESSION_ALIAS_USERNAME, "string", false)); //NO I18N
				funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.SESSION_IS_PARTIAL_DATA,"boolean",false)); //NO I18N
				funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.IS_OPT_OUT,"boolean",false)); //NO I18N
				funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.TIME, "date", false)); //NO I18N
				funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.CURRENTURL, "string", false)); //NO I18N
				funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.LAST_ACTIVITY_TIME, "date", false)); //NO I18N
				funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.LAST_INTERACTED_TIME, "date", false)); //NO I18N
				funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.LAST_URL_VISITED, "string", false)); //NO I18N
				funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.BROWSER, "string", false)); //NO I18N
				funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.HEIGHT, "integer", false)); //NO I18N
				funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.WIDTH, "integer", false)); //NO I18N
				funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.TRAFFICSOURCE, "string", false)); //NO I18N
				funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.DEVICE, "string", false)); //NO I18N
				funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.COUNTRY, "string", false)); //NO I18N
				funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.CITY, "string", false)); //NO I18N
				funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.REGION, "string", false)); //NO I18N
				funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.LANGUAGE, "string", false)); //NO I18N
				funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.OS, "string", false)); //NO I18N
				funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.SESSION_ID, "string", false)); //NO I18N
				funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.UUID, "string", false)); //NO I18N
				funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.REFFERERURL, "string", false)); //NO I18N

				FIELDS_META = funnelRawDataTypes;
			}
			
			public static class URLSVisited {
				public static final ArrayList<ElasticJSONColumn> FIELDS_META;
				static {
					ArrayList<ElasticJSONColumn> funnelRawDataTypes = new ArrayList<ElasticJSONColumn>();
					funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.UVID, "string", false)); //NO I18N
					
					funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.REFFERERURL, "string", false)); //NO I18N
					funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.PAGE_ID, "string", false)); //NO I18N
					funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.PAGE_BLOCK_ID, "string", false)); //NO I18N
					funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.PAGE_DFS_FILE_PATH, "string", false)); //NO I18N
					funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.UVID, "string", false)); //NO I18N
					funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.URL, "string", false)); //NO I18N
					funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.TIME, "date", false)); //NO I18N
					funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.LAST_ACTIVITY_TIME, "date", false)); //NO I18N
					funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.NJSVARIABLE, "nested", false)); //NO I18N
					funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.NCUSTOMDIMENSION, "nested", false)); //NO I18N
					funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.NURLPARAMETER, "nested", false)); //NO I18N
					funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.NCOOKIE, "nested", false)); //NO I18N
					FIELDS_META = funnelRawDataTypes;
				}
			}
			
			public static class AcheivedGoals {
				public static final ArrayList<ElasticJSONColumn> FIELDS_META;
				static {
					ArrayList<ElasticJSONColumn> funnelRawDataTypes = new ArrayList<ElasticJSONColumn>();
					funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.PAGE_ID, "string", false)); //NO I18N
					funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.TIME, "date", false)); //NO I18N
					funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.GOALID, "long", false)); //NO I18N
					FIELDS_META = funnelRawDataTypes;
				}
			}
			
			public static class ElementsClicked {
				public static final ArrayList<ElasticJSONColumn> FIELDS_META;
				static {
					ArrayList<ElasticJSONColumn> funnelRawDataTypes = new ArrayList<ElasticJSONColumn>();
					funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.UVID, "string", false)); //NO I18N
					funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.TIME, "date", false)); //NO I18N
					funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.SELECTOR, "string", false)); //NO I18N
					funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.TEXT, "string", false)); //NO I18N
					funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.ELEMENT_ID, "string", false)); //NO I18N
					FIELDS_META = funnelRawDataTypes;
				}
			}
			
			public static class InputsInteracted {
				public static final ArrayList<ElasticJSONColumn> FIELDS_META;
				static {
					ArrayList<ElasticJSONColumn> funnelRawDataTypes = new ArrayList<ElasticJSONColumn>();
					funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.UVID, "string", false)); //NO I18N
					funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.TIME, "date", false)); //NO I18N
					funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.SELECTOR, "string", false)); //NO I18N
					funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.ELEMENT_ID, "string", false)); //NO I18N
					FIELDS_META = funnelRawDataTypes;
				}
			}
			
		}
	
	public static class SessionEventStreamType {
		
		public static final ArrayList<ElasticJSONColumn> FIELDS_META;
		static {
			ArrayList<ElasticJSONColumn> funnelRawDataTypes = new ArrayList<ElasticJSONColumn>();
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.PORTAL, "string", false)); //NO I18N
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.ZSOID, "long", false)); //NO I18N
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.EXPERIMENTID, "long", false)); //NO I18N
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.EXPERIMENTKEY, "string", false)); //NO I18N
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.TIME, "date", false)); //NO I18N
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.SESSION_TIMER, "long", false)); //NO I18N
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.SESSION_ID, "string", false)); //NO I18N
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.PAGE_ID, "string", false)); //NO I18N
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.SESSION_TIME_FRAME, false));
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.SESSION_TIMELINE_MAP, false));
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.SESSION_USER_EVENTS, false));
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.SESSION_PAGE_NAVIGATION, false));
			FIELDS_META = funnelRawDataTypes;
		}
	}
	
	public static class SessionUserEventDataType {
		
		public static final ArrayList<ElasticJSONColumn> FIELDS_META;
		static {
			ArrayList<ElasticJSONColumn> funnelRawDataTypes = new ArrayList<ElasticJSONColumn>();
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.PORTAL, "string", false)); //NO I18N
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.ZSOID, "long", false)); //NO I18N
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.EXPERIMENTID, "long", false)); //NO I18N
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.EXPERIMENTKEY, "string", false)); //NO I18N
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.SESSION_EVENT_TYPE, "string", false)); //NO I18N
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.TIME, "date", false)); //NO I18N
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.SESSION_TIMER, "long", false)); //NO I18N
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.SESSION_SEQUENCE_ID, "long", false)); //NO I18N
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.SESSION_ID, "string", false)); //NO I18N
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.UVID, "string", false)); //NO I18N
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.PAGE_ID, "string", false)); //NO I18N
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.CSS_SELECTOR, "string", false)); //NO I18N
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.ZSID, "string", false)); //NO I18N
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.SESSION_INPUT_VALUE, "string", false)); //NO I18N
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.URL, "string", false)); //NO I18N
			FIELDS_META = funnelRawDataTypes;
		}
	}
	
	public static class SessionPageResourceDataType {
		
		public static final ArrayList<ElasticJSONColumn> FIELDS_META;
		static {
			ArrayList<ElasticJSONColumn> funnelRawDataTypes = new ArrayList<ElasticJSONColumn>();
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.PORTAL, "string", false)); //NO I18N
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.ZSOID, "long", false)); //NO I18N
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.EXPERIMENTID, "long", false)); //NO I18N
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.EXPERIMENTKEY, "string", false)); //NO I18N
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.PAGE_ID, "string", false)); //NO I18N
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.PAGE_RESOURCE_URL, "string", false)); //NO I18N
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.PAGE_RESOURCE_BLOCKID, "string", false)); //NO I18N
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.PAGE_RESOURCE_DFS_FILE_PATH, "string", false)); //NO I18N
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.PAGE_RESOURCE_CONTENT_TYPE, "string", false)); //NO I18N
			funnelRawDataTypes.add(new ElasticJSONColumn(ElasticSearchConstants.PAGE_RESOURCE_STATUS, "integer", false)); //NO I18N
			FIELDS_META = funnelRawDataTypes;
		}
	}


	
	public static JSONObject getSessionRawDataMapping() throws JSONException {
			
			ArrayList<ElasticJSONColumn> sessionRawDataTypes = SessionRawDataType.FIELDS_META;
			JSONObject mapping = new JSONObject();
			JSONObject maping_prop = new JSONObject();
			
			for(ElasticJSONColumn funnelRawDataType:sessionRawDataTypes)
			{
				String fieldName = funnelRawDataType.getColumnName();
				String fieldType = funnelRawDataType.getType();
				Boolean isAnalyzed = funnelRawDataType.getIsAnaylsed();
				JSONObject subjson = new JSONObject();
				subjson.put("type", fieldType);
				
				if(fieldType != "object" && !isAnalyzed){
					subjson.put("index","not_analyzed");
				}
				mapping.put(fieldName,subjson);
			}
			List<String> nestedAttr = ElasticSearchUtil.getNestedAttributes();
			ArrayList<ElasticJSONColumn> sessionRawURLVisitedDataType = SessionRawDataType.URLSVisited.FIELDS_META;
			JSONObject nestedmapping = new JSONObject();
			JSONObject npropertiesmapping = new JSONObject();
			for(ElasticJSONColumn funnelRawDataType:sessionRawURLVisitedDataType)
			{
				String fieldName = funnelRawDataType.getColumnName();
				String fieldValue = funnelRawDataType.getType();
				String fieldType = funnelRawDataType.getType();
				Boolean isAnalyzed = funnelRawDataType.getIsAnaylsed();
				JSONObject subjson = new JSONObject();
				subjson.put("type", fieldValue);
				
				if((fieldType != "object" && fieldType != "nested") && !isAnalyzed){
					subjson.put("index","not_analyzed");
				}
				if(nestedAttr.contains(fieldName))
				{
					JSONObject nestedPropJson = ElasticSearchUtil.getNestedProperties();
					subjson.put("properties",nestedPropJson);
				}
				npropertiesmapping.put(fieldName,subjson);
			}
			
			nestedmapping.put("properties", npropertiesmapping);
			nestedmapping.put("type", "nested");
			mapping.put(ElasticSearchConstants.URLS_VISITED, nestedmapping);
			
			nestedmapping = new JSONObject();
			npropertiesmapping = new JSONObject();
			ArrayList<ElasticJSONColumn> sessionRawElementsCLickedDataType = SessionRawDataType.ElementsClicked.FIELDS_META;
			for(ElasticJSONColumn funnelRawDataType:sessionRawElementsCLickedDataType)
			{
				String fieldName = funnelRawDataType.getColumnName();
				String fieldValue = funnelRawDataType.getType();
				String fieldType = funnelRawDataType.getType();
				Boolean isAnalyzed = funnelRawDataType.getIsAnaylsed();
				JSONObject subjson = new JSONObject();
				subjson.put("type", fieldValue);
				
				if((fieldType != "object" && fieldType != "nested") && !isAnalyzed){
					subjson.put("index","not_analyzed");
				}
				npropertiesmapping.put(fieldName,subjson);
			}
			
			nestedmapping.put("properties", npropertiesmapping);
			nestedmapping.put("type", "nested");
			mapping.put(ElasticSearchConstants.ELEMENTS_CLICKED, nestedmapping);
			
			nestedmapping = new JSONObject();
			npropertiesmapping = new JSONObject();
			ArrayList<ElasticJSONColumn> acheivedGoalsDT = SessionRawDataType.AcheivedGoals.FIELDS_META;
			for(ElasticJSONColumn funnelRawDataType:acheivedGoalsDT)
			{
				String fieldName = funnelRawDataType.getColumnName();
				String fieldValue = funnelRawDataType.getType();
				String fieldType = funnelRawDataType.getType();
				Boolean isAnalyzed = funnelRawDataType.getIsAnaylsed();
				JSONObject subjson = new JSONObject();
				subjson.put("type", fieldValue);
				
				if((fieldType != "object" && fieldType != "nested") && !isAnalyzed){
					subjson.put("index","not_analyzed");
				}
				npropertiesmapping.put(fieldName,subjson);
			}
			
			nestedmapping.put("properties", npropertiesmapping);
			nestedmapping.put("type", "nested");
			mapping.put(ElasticSearchConstants.ACHEIVED_GOALS, nestedmapping);
			
			nestedmapping = new JSONObject();
			npropertiesmapping = new JSONObject();
			ArrayList<ElasticJSONColumn> sessionRawInputsInteractedDataType = SessionRawDataType.InputsInteracted.FIELDS_META;
			for(ElasticJSONColumn funnelRawDataType:sessionRawInputsInteractedDataType)
			{
				String fieldName = funnelRawDataType.getColumnName();
				String fieldValue = funnelRawDataType.getType();
				String fieldType = funnelRawDataType.getType();
				Boolean isAnalyzed = funnelRawDataType.getIsAnaylsed();
				JSONObject subjson = new JSONObject();
				subjson.put("type", fieldValue);
				
				if((fieldType != "object" && fieldType != "nested") && !isAnalyzed){
					subjson.put("index","not_analyzed");
				}
				npropertiesmapping.put(fieldName,subjson);
			}
			
			nestedmapping.put("properties", npropertiesmapping);
			nestedmapping.put("type", "nested");
			mapping.put(ElasticSearchConstants.INPUT_INTERACTED, nestedmapping);
			
			maping_prop.put("properties", mapping);
			return maping_prop;
	}
	
	public static JSONObject getSessionEventStreamMapping() throws JSONException {
		ArrayList<ElasticJSONColumn> sessionRawDataTypes = SessionEventStreamType.FIELDS_META;
		JSONObject mapping = new JSONObject();
		JSONObject maping_prop = new JSONObject();
		
		for(ElasticJSONColumn funnelRawDataType:sessionRawDataTypes)
		{
			String fieldName = funnelRawDataType.getColumnName();
			String fieldType = funnelRawDataType.getType();
			Boolean isAnalyzed = funnelRawDataType.getIsAnaylsed();
			JSONObject subjson = new JSONObject();
			if(fieldType!=null) {				
				subjson.put("type", fieldType);
				if(fieldType != "object" && !isAnalyzed){
					subjson.put("index","not_analyzed");
				}
			}
			
			if(!funnelRawDataType.getIsEnabled()) {
				subjson.put("enabled",false);
			}
			mapping.put(fieldName,subjson);
		}
		maping_prop.put("properties", mapping);
		return maping_prop;
	}
	
	public static JSONObject getSessionUserEventDataMapping() throws JSONException {
		ArrayList<ElasticJSONColumn> sessionRawDataTypes = SessionUserEventDataType.FIELDS_META;
		JSONObject mapping = new JSONObject();
		JSONObject maping_prop = new JSONObject();
		
		for(ElasticJSONColumn funnelRawDataType:sessionRawDataTypes)
		{
			String fieldName = funnelRawDataType.getColumnName();
			String fieldType = funnelRawDataType.getType();
			Boolean isAnalyzed = funnelRawDataType.getIsAnaylsed();
			JSONObject subjson = new JSONObject();
			subjson.put("type", fieldType);
			
			if(fieldType != "object" && !isAnalyzed){
				subjson.put("index","not_analyzed");
			}
			mapping.put(fieldName,subjson);
		}
		maping_prop.put("properties", mapping);
		return maping_prop;
	}
	
	public static JSONObject getSessionPageResourceDataMapping() throws JSONException {
		ArrayList<ElasticJSONColumn> sessionPageResourceDataTypes = SessionPageResourceDataType.FIELDS_META;
		JSONObject mapping = new JSONObject();
		JSONObject maping_prop = new JSONObject();
		
		for(ElasticJSONColumn sessionPageResourceDataType:sessionPageResourceDataTypes)
		{
			String fieldName = sessionPageResourceDataType.getColumnName();
			String fieldType = sessionPageResourceDataType.getType();
			Boolean isAnalyzed = sessionPageResourceDataType.getIsAnaylsed();
			JSONObject subjson = new JSONObject();
			subjson.put("type", fieldType);
			
			if(fieldType != "object" && !isAnalyzed){
				subjson.put("index","not_analyzed");
			}
			mapping.put(fieldName,subjson);
		}
		maping_prop.put("properties", mapping);
		return maping_prop;
	}

}
