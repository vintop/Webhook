//$Id$
package com.zoho.abtest.sessionrecording;

public enum SResourceProcessingStatus {
	IN_PROGRESS(1),
	COMPLETED(2),
	FAILURE(3);
	
	private int statusCode;

	public int getStatusCode() {
		return statusCode;
	}
	
	SResourceProcessingStatus(int status) {
		this.statusCode = status;
	}
}
