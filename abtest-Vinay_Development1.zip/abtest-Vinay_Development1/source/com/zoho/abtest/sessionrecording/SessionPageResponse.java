//$Id$
package com.zoho.abtest.sessionrecording;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;

public class SessionPageResponse {
	private static final Logger LOGGER = Logger.getLogger(SessionPageResponse.class.getName());

	public static String jsonResponse(HttpServletRequest request,
			ArrayList<SessionPage> pages) {
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(pages);			
			JSONObject json = ZABResponse.updateMetaInfo(request, SessionPageConstants.API_MODULE, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		return returnBuffer.toString();
	}
	
	private static JSONArray getJSONArray(ArrayList<SessionPage> pages) throws JSONException {
		JSONArray array =  new JSONArray();
		
		for(SessionPage page: pages) {
			JSONObject object = new JSONObject();
			object.put(SessionPageConstants.PAGE_ID, page.getPageKey());
			object.put(SessionPageConstants.PAGE_URL, page.getPageUrl());
			object.put(SessionPageConstants.HEIGHT, page.getHeight());
			object.put(SessionPageConstants.WIDTH, page.getWidth());
			object.put(ZABConstants.SUCCESS, page.getSuccess());
			object.put(ZABConstants.RESPONSE_STRING, page.getResponseString());
			object.put(SessionPageConstants.PAGE_HTML, page.getSessionPageJSON());
			
			if(page.getResources()!=null && page.getResources().size() > 0) {
				JSONObject resourceMap = new JSONObject();
				for(SessionPageResources resource: page.getResources()) {
					resourceMap.put(resource.getResourceUrl(), resource.getResourceKey());
				}
				object.put(SessionPageConstants.RESOURCE_MAP, resourceMap);
			}
			
			
			array.put(object);
		}
		return array;	
	}
}
