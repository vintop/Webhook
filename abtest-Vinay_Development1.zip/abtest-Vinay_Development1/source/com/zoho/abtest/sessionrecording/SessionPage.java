//$Id$
package com.zoho.abtest.sessionrecording;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.lucene.search.join.ScoreMode;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.json.JSONObject;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.UpdateQuery;
import com.adventnet.ds.query.UpdateQueryImpl;
import com.adventnet.iam.IAMUtil;
import com.adventnet.iam.ServiceOrgDomain;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.persistence.WritableDataObject;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.SESSION_RECORDING_PAGE_DETAILS;
import com.zoho.abtest.SR_PAGE_RESOURCES;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABColumn;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.dfs.DFS;
import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.utility.ZABUtil;

public class SessionPage extends ZABModel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final Logger LOGGER = Logger.getLogger(SessionPage.class.getName());
	
	private String pageUrl;
	
	private String height;
	
	private String width;
	
	private String portal;
	
	private String pageKey;
	
	private String pageBlockId;
	
	private Long time;
	
	private Long experimentId;
	
	private JSONObject sessionPageJSON;
	
	private ArrayList<SessionPageResources> resources = new ArrayList<SessionPageResources>();

	public ArrayList<SessionPageResources> getResources() {
		return resources;
	}

	public void setResources(ArrayList<SessionPageResources> resources) {
		this.resources = resources;
	}

	public JSONObject getSessionPageJSON() {
		return sessionPageJSON;
	}

	public void setSessionPageJSON(JSONObject sessionPageJSON) {
		this.sessionPageJSON = sessionPageJSON;
	}

	public String getPageBlockId() {
		return pageBlockId;
	}

	public void setPageBlockId(String pageBlockId) {
		this.pageBlockId = pageBlockId;
	}

	public String getPageKey() {
		return pageKey;
	}

	public void setPageKey(String pageKey) {
		this.pageKey = pageKey;
	}

	public String getPageUrl() {
		return pageUrl;
	}

	public void setPageUrl(String pageUrl) {
		this.pageUrl = pageUrl;
	}

	public String getHeight() {
		return height;
	}

	public void setHeight(String height) {
		this.height = height;
	}

	public String getWidth() {
		return width;
	}

	public void setWidth(String width) {
		this.width = width;
	}

	public String getPortal() {
		return portal;
	}

	public void setPortal(String portal) {
		this.portal = portal;
	}

	public Long getTime() {
		return time;
	}

	public void setTime(Long time) {
		this.time = time;
	}

	public Long getExperimentId() {
		return experimentId;
	}

	public void setExperimentId(Long experimentId) {
		this.experimentId = experimentId;
	}

	public boolean deletePage(String zsoid, String experimentKey) {
		boolean isDeletedSucess = false;
		try {			
			isDeletedSucess = DFS.deleteDirectoryFromDFS(getDFSBasePath(zsoid, experimentKey, this.getPageKey()), zsoid);
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,"Excepion occured", e);
		}
		return isDeletedSucess;
	}
	
	public static void deletePageFilesCascaded(Long zsoid, String pageId, String dfsPath, String pageBlockId) {
		try {			
			DFS.deleteFromDFS(pageBlockId, dfsPath, zsoid.toString());
			ArrayList<SessionPageResources> resources = SessionPageResources.getSessionPageResource(pageId);
			for(SessionPageResources resource: resources) {
				resource.deleteFile(zsoid);
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,"Excepion occured", e);
		}
		
	}
	
	public static SessionPage getSessionPageDetails(String experimentLinkname, String pageId) {
		SessionPage page = new SessionPage();
		page.setSuccess(false);
		try {
			String zsoid = ZABUtil.getDBSpace();
			Long zsoidL = Long.parseLong(zsoid);
			
			ServiceOrgDomain domain = IAMUtil.getCurrentServiceOrg().getDomains().get(0);
			String portalName = domain.getDomain();
			
			String indexName = ElasticSearchUtil.getIndexByPortal(portalName);
			
			String experimentKey = Experiment.getExperimentKeyByLinkname(experimentLinkname);
			
			BoolQueryBuilder qb = SessionElasticBand
					.getVisitorBasicCriteria(zsoidL, experimentKey)
					.must(QueryBuilders.nestedQuery(
							ElasticSearchConstants.URLS_VISITED,
							QueryBuilders
									.boolQuery()
									.must(QueryBuilders
											.termQuery(ElasticSearchConstants.URLS_VISITED + "."+ ElasticSearchConstants.PAGE_ID,
													pageId)), ScoreMode.None));

			
			
			String [] includeFields = {
					ElasticSearchConstants.URLS_VISITED,
					ElasticSearchConstants.HEIGHT,
					ElasticSearchConstants.WIDTH
				};

			LOGGER.log(Level.INFO, "Getting meta data from ES start");
			SearchResponse response = ElasticSearchUtil.getData(indexName,
			ElasticSearchConstants.SESSION_RAW_DATA_TYPE, qb,
			includeFields, null, 1, null, null);
			
			LOGGER.log(Level.INFO, "Getting meta data from ES end");
			SearchHits hits = response.getHits();
			
			
			if(hits.getTotalHits() > 0) {
				SearchHit hit = hits.getAt(0);
			
				Map<String, Object> source = hit.getSource();
				
				String height = (String) source.get(ElasticSearchConstants.HEIGHT);
				String width = (String) source.get(ElasticSearchConstants.WIDTH);
				
				ArrayList<HashMap<String, Object>> pageMetaMaps = (ArrayList<HashMap<String, Object>>) source.get(ElasticSearchConstants.URLS_VISITED);
				
				for(HashMap<String, Object> map: pageMetaMaps) {
					
					
					String spid = (String) map.get(ElasticSearchConstants.PAGE_ID);
					if(spid.equals(pageId)) {
						
						String blockId = (String) map.get(ElasticSearchConstants.PAGE_BLOCK_ID);
						
						String pageUrl = (String) map.get(ElasticSearchConstants.URL);
						
						String dfsPath = (String) map.get(ElasticSearchConstants.PAGE_DFS_FILE_PATH);
						if(dfsPath == null || dfsPath.isEmpty()) {
							dfsPath = getDFSPagePath(zsoid, experimentKey, pageId);
						}
						byte[] jsonBytes = DFS.retrieveDecryptedFromDFS(blockId, dfsPath, zsoidL);
						page.setSessionPageJSON(new JSONObject(new String(jsonBytes)));
						
						page.setPageUrl(pageUrl);
						page.setHeight(height);
						page.setWidth(width);
						page.setPageKey(spid);
						
						page.setResources(SessionPageResources.getSessionPageResource(pageId));
						
						page.setSuccess(Boolean.TRUE);
						return page;
					}
					
				}				
			} else {
				page = new SessionPage();
				page.setSuccess(Boolean.FALSE);
				page.setResponseString(ZABAction.getMessage(ZABConstants.ErrorMessages.RESOURCE_NOT_FOUND.getErrorString(),new String[]{"Page"})); //NO I18N
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Exception occured", e);
			page.setSuccess(Boolean.FALSE);
			page.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
		}
		return page;
	}
	

	
	public static String getDFSBasePathFolderLess(String experimentKey, String pageKey) {
		return experimentKey + "/" +pageKey;
	}
	
	public static String getDFSPagePathFolderLess(String experimentKey, String pageKey) {
		return getDFSBasePathFolderLess(experimentKey, pageKey) + "_" +"index.json"; //NO I18N
	}
	
	public static String getDFSExperimentBasePath(String zsoid, String experimentKey) {
		return zsoid + "/" + experimentKey;
	}
	
	public static String getDFSBasePath(String zsoid, String experimentKey, String pageKey) {
		return getDFSExperimentBasePath(zsoid, experimentKey) + "/"+ pageKey + "/";
	}
	
	public static String getDFSPagePath(String zsoid, String experimentKey, String pageKey) {
		return getDFSBasePath(zsoid, experimentKey, pageKey) + "index.json"; //NO I18N
	}
}
