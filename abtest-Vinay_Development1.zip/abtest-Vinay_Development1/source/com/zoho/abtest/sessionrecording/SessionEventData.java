//$Id$
package com.zoho.abtest.sessionrecording;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.elasticsearch.action.update.UpdateResponse;
import org.elasticsearch.script.Script;
import org.elasticsearch.script.ScriptType;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.GOAL;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.report.ReportRawDataConstants;
import com.zoho.abtest.report.VisitorRawDataWrapper;
import com.zoho.abtest.sessionrecording.SessionRecordingConstants.SessionEventTypes;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUtil;

public class SessionEventData {
	
	private static final Logger LOGGER = Logger.getLogger(SessionEventData.class.getName());
	
	private static final List<SessionEventTypes> USER_ACTIONS = Arrays
			.asList(SessionEventTypes.CLICK, SessionEventTypes.FOCUSIN,
					SessionEventTypes.FOCUSOUT, SessionEventTypes.KEYPRESS,
					SessionEventTypes.MOVE, SessionEventTypes.NAVIGATION,
					SessionEventTypes.SCROLL);
	
	private static final List<SessionEventTypes> USER_INTERACTION_ACTIONS = Arrays
			.asList(SessionEventTypes.CLICK, SessionEventTypes.FOCUSIN,
					SessionEventTypes.FOCUSOUT, SessionEventTypes.KEYPRESS
//					Commented it as it will be handled in session raw data
//					,SessionEventTypes.NAVIGATION
					);
	
	private ArrayList<JSONObject> eventDocs = new ArrayList<JSONObject>();
	
	private ArrayList<JSONObject> userEventDocs = new ArrayList<JSONObject>();
	
	private ArrayList<Long> goalIds = new ArrayList<Long>();
	
	private String portal;
	
	private Long time;
	
	private Long lastEventTime;
	
	private HashMap<String, String> sessionIds = new HashMap<String, String>();
	
	private String esIndex;
	
	private String pageId;
	
	private Long zsoid;
	
	private Boolean userInteracted = Boolean.FALSE;
	
	private Long timer;

	public Long getTimer() {
		return timer;
	}

	public void setTimer(Long timer) {
		this.timer = timer;
	}

	public ArrayList<JSONObject> getUserEventDocs() {
		return userEventDocs;
	}

	public void setUserEventDocs(ArrayList<JSONObject> userEventDocs) {
		this.userEventDocs = userEventDocs;
	}

	public Boolean getUserInteracted() {
		return userInteracted;
	}

	public void setUserInteracted(Boolean userInteracted) {
		this.userInteracted = userInteracted;
	}

	public Long getZsoid() {
		return zsoid;
	}

	public void setZsoid(Long zsoid) {
		this.zsoid = zsoid;
	}

	public String getPageId() {
		return pageId;
	}

	public void setPageId(String pageId) {
		this.pageId = pageId;
	}

	public String getEsIndex() {
		return esIndex;
	}

	public void setEsIndex(String esIndex) {
		this.esIndex = esIndex;
	}

	public Long getTime() {
		return time;
	}

	public void setTime(Long time) {
		this.time = time;
	}

	public String getPortal() {
		return portal;
	}

	public Long getLastEventTime() {
		return lastEventTime;
	}

	public void setLastEventTime(Long lastEventTime) {
		this.lastEventTime = lastEventTime;
	}

	public ArrayList<Long> getGoalIds() {
		return goalIds;
	}

	public void setGoalIds(ArrayList<Long> goalIds) {
		this.goalIds = goalIds;
	}

	public void setPortal(String portal) throws Exception {
		if(this.getZsoid() == null) {
			Long zsoid = ZABServiceOrgUtil.getZSOIDFromDomain(portal);
			if(zsoid == null)
			{
				throw new ZABException("Invalid portal provided :"+portal); //NO I18N
			}
			this.setZsoid(zsoid);
		}
		
		if (this.getEsIndex()==null) {			
			this.setEsIndex(ElasticSearchUtil.getIndexByPortal(portal));
		}
		this.portal = portal;
	}

	public ArrayList<JSONObject> getEventDocs() {
		return eventDocs;
	}

	public void setEventDocs(ArrayList<JSONObject> eventDocs) {
		this.eventDocs = eventDocs;
	}

	public HashMap<String, String> getSessionIds() {
		return sessionIds;
	}

	public void setSessionIds(HashMap<String, String> sessionIds) {
		this.sessionIds = sessionIds;
	}
	
	private void handleUserEvents(JSONArray eventJsonArray, Long maxTimer, String sessionId, Long experimentId, String experimentKey, String uuid, String uvid) throws JSONException {
		int length = eventJsonArray.length();
		ArrayList<JSONObject> sessionEventStream = new ArrayList<JSONObject>();
		for(int i = 0; i < length; i++) {
			JSONObject event = eventJsonArray.getJSONObject(i);
			Integer eventType = event.getInt(SessionRecordingConstants.SRD_EVENT_TYPE);
			SessionEventTypes type = SessionEventTypes.getEventTypeByNumber(eventType);
			if(USER_ACTIONS.contains(type)) {
				this.setUserInteracted(Boolean.TRUE);
			}
			
			if(type != null && USER_INTERACTION_ACTIONS.contains(type)) {
				
				JSONObject eventDoc = new JSONObject();
				
				Long timer = event.getLong(SessionRecordingConstants.SRD_TIMER_VALUE);
				Long eventTime = this.getTime();
				if(i != length -1) {
					eventTime = eventTime - (maxTimer - timer);
				}

				eventDoc.put(ElasticSearchConstants.EXPERIMENTKEY, experimentKey);
				eventDoc.put(ElasticSearchConstants.EXPERIMENTID, experimentId);
				eventDoc.put(ElasticSearchConstants.PORTAL, portal);
				eventDoc.put(ElasticSearchConstants.TIME, eventTime);
				eventDoc.put(ElasticSearchConstants.ZSOID, this.getZsoid());
				eventDoc.put(ElasticSearchConstants.SESSION_EVENT_TYPE, type.getTypeId());
				eventDoc.put(ElasticSearchConstants.SESSION_TIMER, timer);
				eventDoc.put(ElasticSearchConstants.SESSION_ID, uuid);
				eventDoc.put(ElasticSearchConstants.UVID, uvid);
				eventDoc.put(ElasticSearchConstants.PAGE_ID, pageId);
				eventDoc.put(ElasticSearchConstants.ZSID, ZABUtil.getValueOrNull(event, ReportRawDataConstants.ZSID));
				eventDoc.put(ElasticSearchConstants.CSS_SELECTOR, ZABUtil.getValueOrNull(event, SessionRecordingConstants.SRD_ELEMENT_SELECTOR));
				eventDoc.put(ElasticSearchConstants.SESSION_INPUT_VALUE, ZABUtil.getValueOrNull(event, SessionRecordingConstants.SRD_INPUT_VALUE));
				
				if(eventDoc!=null) {
					sessionEventStream.add(eventDoc);
				}
			}
		}
		
		this.setUserEventDocs(sessionEventStream);

	}
	
	private void extractUserEvents(JSONObject sessionTimeFrame, Long maxTimer, String sessionId, String experimentKey, Long experimentId, String uuid, String uvid) throws JSONException {
		if(sessionTimeFrame!=null) {
			Iterator<String> oit = sessionTimeFrame.keys();

			Consumer<String> outerConsumer = s -> {
				try {
					JSONObject obj = sessionTimeFrame.getJSONObject(s);
					Iterator<String> it =  obj.keys();
					it.forEachRemaining( s2 -> {
						try {
							JSONObject objInner = obj.getJSONObject(s2);
							JSONArray events = objInner.getJSONArray(ReportRawDataConstants.SESSION_EVENTS_ARRAY);
							handleUserEvents(events, maxTimer, sessionId, experimentId, experimentKey, uuid, uvid);
							
						} catch (Exception e) {
							LOGGER.log(Level.SEVERE, "Exception occured", e);
						}
					});
				} catch (Exception e) {
					LOGGER.log(Level.SEVERE, "Exception occured", e);
				}
			};
			
			oit.forEachRemaining(outerConsumer);
		}
	}

	public SessionEventData(VisitorRawDataWrapper wrapper) throws Exception {
		
		//TODO: Need to set and define user interaction time.
		
		ArrayList<HashMap<String, String>> userAgentArray = wrapper.getSessionRawData();
		
		SessionRawDataEventBuffer buffer = SessionRawDataEventBuffer.getData(wrapper.getEventBufferId());
		String eventsArrayString = buffer.getData();
		buffer.destroyData();
		
		this.setTime(wrapper.getTime());
		
		if(eventsArrayString!=null) {
			JSONObject eventStream = new JSONObject(eventsArrayString);
		
			String pageId = eventStream.getString(ReportRawDataConstants.PAGE_PID);
			
			Long timer =  eventStream.getLong(ReportRawDataConstants.SESSION_LAST_TIMER);
			
			this.setPageId(pageId);
			
			for(HashMap<String, String> userAgentHash: userAgentArray) {
				String portal = userAgentHash.get(ReportRawDataConstants.PORTAL);
				this.setPortal(portal);
				
				
				String experimentKey = userAgentHash.get(ReportRawDataConstants.EXPERIMENT_KEY);
				String sessionId = userAgentHash.get(ReportRawDataConstants.UUID);
				String uvid = userAgentHash.get(ReportRawDataConstants.UVID);
				String goals = eventStream.getString(ReportRawDataConstants.SESSION_GOAL);
				
				ZABUtil.setDBSpace(this.getZsoid().toString());
				processGoals(goals);
				
				Long experimentId = Experiment.getExperimentIdByExperimentKey(experimentKey);
				
				this.getSessionIds().put(experimentKey, sessionId);
				
				
				if(eventsArrayString!=null) {
					JSONObject eventDoc = new JSONObject();
					
					JSONObject sessionTimeFrame = eventStream.getJSONObject(ReportRawDataConstants.SESSION_TIME_FRAME);
					
					//TODO: Passing sessionId as user id for now.
					extractUserEvents(sessionTimeFrame, timer, sessionId, experimentKey, experimentId, sessionId, uvid);
					
					JSONObject sessionTimelineMap = eventStream.getJSONObject(ReportRawDataConstants.SESSION_TIMELINE_MAP);
					JSONArray sessionUserEvents =  eventStream.getJSONArray(ReportRawDataConstants.SESSION_USER_EVENTS);
					JSONArray sessionPageNavigation = eventStream.getJSONArray(ReportRawDataConstants.SESSION_PAGE_NAVIGATION);
					
					eventDoc.put(ElasticSearchConstants.PORTAL, portal);
					eventDoc.put(ElasticSearchConstants.ZSOID, this.getZsoid());
					eventDoc.put(ElasticSearchConstants.EXPERIMENTKEY, experimentKey);
					eventDoc.put(ElasticSearchConstants.EXPERIMENTID, experimentId);
					eventDoc.put(ElasticSearchConstants.TIME, this.getTime());
					eventDoc.put(ElasticSearchConstants.SESSION_TIMER, timer);
					eventDoc.put(ElasticSearchConstants.SESSION_ID, sessionId);
					eventDoc.put(ElasticSearchConstants.PAGE_ID, this.getPageId());
					
					this.setTimer(timer);
					
					eventDoc.put(ElasticSearchConstants.SESSION_TIME_FRAME, ZABUtil.toBase64String(sessionTimeFrame.toString()));
					eventDoc.put(ElasticSearchConstants.SESSION_TIMELINE_MAP, ZABUtil.toBase64String(sessionTimelineMap.toString()));
					eventDoc.put(ElasticSearchConstants.SESSION_USER_EVENTS, ZABUtil.toBase64String(sessionUserEvents.toString()));

					eventDoc.put(ElasticSearchConstants.SESSION_PAGE_NAVIGATION, ZABUtil.toBase64String(sessionPageNavigation.toString()));
					this.getEventDocs().add(eventDoc);
				}
			}
		}
		
	}
	
	public void processGoals(String goals) throws Exception {
		if(goals!=null) {
			JSONArray goalsArray = new JSONArray(goals);
			int length = goalsArray.length();
			String [] goalLinknames = new String[length];
			for(int i = 0; i<length; i++) {
				goalLinknames[i] = goalsArray.getString(i);
			}
			Criteria c = new Criteria(new Column(GOAL.TABLE, GOAL.GOAL_LINK_NAME), goalLinknames, QueryConstants.IN);
			DataObject dobj = ZABModel.getRow(GOAL.TABLE, c);
			if(dobj.containsTable(GOAL.TABLE)) {	
				Consumer<Row> consumer = row -> {
					Long goalId = (Long) row.get(GOAL.GOAL_ID);
					this.getGoalIds().add(goalId);
				};
				
				dobj.getRows(GOAL.TABLE).forEachRemaining(consumer);
			}
		}
	}
	
	public void persistEventStream() throws Exception {
		for(JSONObject eventDoc: this.getEventDocs()) {
			ElasticSearchUtil.createIndex(this.getEsIndex(), ElasticSearchConstants.SESSION_EVENT_STREAM_DATA_TYPE, eventDoc.toString());
		}
	}
	
	public void persistUserEvents() throws Exception {
		if(this.getUserEventDocs().size() > 0) {			
			ElasticSearchUtil.bulkInsertDocuments(this.getEsIndex(), ElasticSearchConstants.SESSION_USER_EVENT_DATA_TYPE, this.getUserEventDocs());
		}
	}
	
	public void addEventDataToVisitorDoc() throws Exception {
		//Things needs to be updated in visitor doc
		//Elements clicked
		//Inputs interacted
		for(String experimentKey: this.getSessionIds().keySet()) {	
			String sessionId = this.getSessionIds().get(experimentKey);
			JSONObject resultJson = new JSONObject();
			resultJson.put(ElasticSearchConstants.EXPERIMENTKEY, experimentKey);			
			resultJson.put(ElasticSearchConstants.SESSION_IS_PARTIAL_DATA, true);
			resultJson.put(ElasticSearchConstants.LAST_ACTIVITY_TIME, this.getTime());
			resultJson.put(ElasticSearchConstants.TIME, this.getTime());
			resultJson.put(ElasticSearchConstants.SESSION_ID, sessionId);
			resultJson.put(ElasticSearchConstants.PORTAL, this.getPortal());
			resultJson.put(ElasticSearchConstants.ZSOID, this.getZsoid());
			
			resultJson.put(ElasticSearchConstants.URLS_VISITED, new JSONArray());
			resultJson.put(ElasticSearchConstants.ELEMENTS_CLICKED, new JSONArray());
			resultJson.put(ElasticSearchConstants.INPUT_INTERACTED, new JSONArray());
			resultJson.put(ElasticSearchConstants.ACHEIVED_GOALS, new JSONArray());
			
			JSONArray urlsVisited = new JSONArray();
			JSONObject urlVisited = new JSONObject();
			urlVisited.put(ElasticSearchConstants.LAST_ACTIVITY_TIME, this.getTime());
			urlVisited.put(ElasticSearchConstants.PAGE_ID, this.getPageId());
			urlVisited.put(ElasticSearchConstants.SESSION_IS_PARTIAL_DATA, true);
			
			JSONArray acheivedGoals = new JSONArray();
			
			ArrayList<HashMap<String, Object>> acheivedGoalsMap = new ArrayList<HashMap<String,Object>>();
			
			for(Long goalId: this.getGoalIds()) {				
				JSONObject acheivedGoal = new JSONObject();
				acheivedGoal.put(ElasticSearchConstants.PAGE_ID, this.getPageId());
				acheivedGoal.put(ElasticSearchConstants.TIME, this.getTime());
				acheivedGoal.put(ElasticSearchConstants.GOALID, goalId);
				acheivedGoals.put(acheivedGoal);
				
				HashMap<String, Object> goalMap = new HashMap<String, Object>();
				goalMap.put(ElasticSearchConstants.PAGE_ID, this.getPageId());
				goalMap.put(ElasticSearchConstants.TIME, this.getTime());
				goalMap.put(ElasticSearchConstants.GOALID, goalId);
				acheivedGoalsMap.add(goalMap);
			}
			
			resultJson.put(ElasticSearchConstants.ACHEIVED_GOALS, acheivedGoals);
			
			resultJson.put(ElasticSearchConstants.URLS_VISITED, urlsVisited);
			
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("merge_fields", new String[]{ElasticSearchConstants.LAST_ACTIVITY_TIME});
			params.put("url_visited", ZABUtil.convertJSONToHashMapOfObject(urlVisited));
			params.put("acheived_goals", acheivedGoalsMap);
			params.put("last_act_time", this.getTime());
			params.put("timer", this.getTimer());
			
			if(this.getUserInteracted()) {				
				params.put("last_int_time", this.getTime());
			}
			
			params.put("page_id", this.getPageId());
			
			Script updateSript = new Script(ScriptType.INLINE, "painless", SessionElasticDocDetails.UPDATE_SESSION_DOC_SCRIPT, params); //NO I18N
			
			UpdateResponse response = ElasticSearchUtil.upsertIndex(this.getEsIndex(), ElasticSearchConstants.SESSION_RAW_DATA_TYPE, sessionId, resultJson.toString(), updateSript, 5);
			LOGGER.log(Level.INFO, "Upsert of visitor doc in event SessionID::"+sessionId+", Doc::"+resultJson+", updateSript::"+updateSript +"response::"+response);
		}
	}
}
