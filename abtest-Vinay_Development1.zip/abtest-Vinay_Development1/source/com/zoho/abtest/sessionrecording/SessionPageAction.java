//$Id$
package com.zoho.abtest.sessionrecording;

import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.json.JSONException;

import com.opensymphony.xwork2.ActionSupport;
import com.zoho.abtest.common.ZABAction;

public class SessionPageAction  extends ActionSupport implements ServletResponseAware, ServletRequestAware{
	
	private static final Logger LOGGER = Logger.getLogger(SessionPageAction.class.getName());
	private static final long serialVersionUID = 1L;
	
	private HttpServletRequest request;
	private HttpServletResponse response;
	
	private String experimentLinkName;
	
	public String getExperimentLinkName() {
		return experimentLinkName;
	}

	public void setExperimentLinkName(String experimentLinkName) {
		this.experimentLinkName = experimentLinkName;
	}

	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		request = arg0;
	}

	@Override
	public void setServletResponse(HttpServletResponse arg0) {
		response = arg0;
	}

	public String execute() throws IOException, JSONException {
		ArrayList<SessionPage> sessionPage = new ArrayList<SessionPage>();
		try {			
			switch(ZABAction.getHTTPMethod(request)) {
				case GET:
					String pageId = request.getParameter(SessionPageConstants.PAGE_ID_QP);
					sessionPage.add(SessionPage.getSessionPageDetails(experimentLinkName, pageId));
				break;
			}
		} catch(Exception e) {
			LOGGER.log(Level.SEVERE, "Exceptiion occured:", e);
		}
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getSessionPageDetails(request, sessionPage));
		return null;
	}
}
 