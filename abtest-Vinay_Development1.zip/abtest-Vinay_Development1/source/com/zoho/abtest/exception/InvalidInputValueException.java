//$Id$
package com.zoho.abtest.exception;

import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;

public class InvalidInputValueException extends Exception{
	private static final long serialVersionUID = 1L;
	private String errorCode = ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorCode();
	private String errorMessage = null ; 
	
	public InvalidInputValueException(String errorMessage) {
		this.errorMessage = ZABAction.getMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(),new String[]{errorMessage});
	}
	
	public String getMessage() {
		return errorMessage;
	}
	
	public String toString() {
		return errorMessage;  
	}
	
	public String getErrorCode() {
		return errorCode;
	}
}
