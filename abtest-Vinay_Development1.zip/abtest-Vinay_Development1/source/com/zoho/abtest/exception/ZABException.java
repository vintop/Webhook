//$Id$
package com.zoho.abtest.exception;

import com.zoho.abtest.common.ZABConstants.ErrorMessages;

public class ZABException extends Exception{
	private static final long serialVersionUID = 1L;
	private String errorCode = null;
	private String errorMessage = null;
	
	public ZABException(String errorMessage, String errorCode)
	{
		this.errorMessage = errorMessage;
		this.errorCode = errorCode;
	}
	public ZABException(String errorMessage)
	{
		this.errorMessage = errorMessage;
		this.errorCode = null;
	}
	public ZABException(ErrorMessages errorMessage)
	{
		this.errorMessage = errorMessage.getErrorString();
		this.errorCode = errorMessage.getErrorCode();
	}
	
	public String getMessage() {
		return errorMessage;
	}
	
	public String toString() {
		return errorMessage;  
	}
	
	public String getErrorCode() {
		return errorCode;
	}
}
