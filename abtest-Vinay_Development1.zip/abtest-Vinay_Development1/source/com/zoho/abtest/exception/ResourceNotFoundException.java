//$Id$

package com.zoho.abtest.exception;

import java.lang.Exception;

import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;

public class ResourceNotFoundException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String errorCode = ZABConstants.ErrorMessages.RESOURCE_NOT_FOUND.getErrorCode();
	private String errorMessage = null ; 
	
	public ResourceNotFoundException(String errorMessage) {
		this.errorMessage = ZABAction.getMessage(ZABConstants.ErrorMessages.RESOURCE_NOT_FOUND.getErrorString(),new String[]{errorMessage});
	}
	
	public String getMessage() {
		return errorMessage;
	}
	
	public String toString() {
		return errorMessage;  
	}
	
	public String getErrorCode() {
		return errorCode;
	}

}
