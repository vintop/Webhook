//$Id$
package com.zoho.abtest.project;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.zoho.abtest.listener.IPRestrictionData;
import com.zoho.abtest.listener.ZABListener;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.mqueue.consumer.ConsumerRecord;
import com.zoho.mqueue.consumer.MessageListener;

public class ProjectTreeEventListener extends ZABListener implements MessageListener<String, String>{
	
	private static final Logger LOGGER = Logger.getLogger(ProjectTreeEventListener.class.getName());

	@Override
	public void consumeMessage(Object obj) throws Exception {
		try {			
			if(obj!=null) {
				ProjectTreeEventWrapper wrapper = (ProjectTreeEventWrapper)obj;
				ProjectTreeEventHandler.handleProjectTreeEvent(wrapper);
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			throw new Exception(e);
		}
	}

	@Override
	public IPRestrictionData getIPRestrictionData(Object message) {
		return null;
	}
}
