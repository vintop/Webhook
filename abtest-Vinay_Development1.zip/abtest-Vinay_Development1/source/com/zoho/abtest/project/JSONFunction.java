//$Id$
package com.zoho.abtest.project;

import org.json.JSONObject;

public class JSONFunction extends JSONObject{
	private String value = null;
	
	public JSONFunction(String value){
		this.value = value;
	}

	@Override
	public String toString() {
		if(this.value == null){
			return "function(){}"; //NO I18N
		}
		return "new Function(\""+this.value.replaceAll("\"", "\\\\\"").replaceAll("\n", "")+"\")"; //NO I18N
	}
	
}
