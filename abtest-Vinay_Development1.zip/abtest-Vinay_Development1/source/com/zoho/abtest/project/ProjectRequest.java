//$Id$
package com.zoho.abtest.project;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABRequest;
import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.project.ProjectConstants.IPMatchType;
import com.zoho.abtest.project.ProjectConstants.ProjectStatus;

public class ProjectRequest extends ZABRequest{

	@Override
	public void updateFromRequest(HashMap<String, String> map,
			HttpServletRequest request) {
		String linkName = (String)request.getAttribute(ZABConstants.LINKNAME);
		if(linkName!=null) {			
			map.put(ZABConstants.LINKNAME, linkName);
		}
	}

	@Override
	public void specificValidation(HashMap<String, String> map,
			HttpServletRequest request) throws IOException, JSONException {
			
			String httpMethod = ZABAction.getHTTPMethod(request).toString();
			
			if(httpMethod.equalsIgnoreCase("POST")){
					ArrayList<String> fields = new ArrayList<String>();
					if(!map.containsKey(ProjectConstants.PROJECT_NAME) || map.get(ProjectConstants.PROJECT_NAME).isEmpty()){
						fields.add(ProjectConstants.PROJECT_NAME);
					}
					
					if(!fields.isEmpty()) {
						ZABRequest.updateError(map, ZABAction.getAppropriateMessage(ZABConstants.ErrorMessages.MANDATORY_FIELD_MISSING.getErrorString(),fields));
					}
					
				}
			
			if(httpMethod.equalsIgnoreCase("PUT")){
				ArrayList<String> fields = new ArrayList<String>();
				if(!map.containsKey(ZABConstants.LINKNAME)) {
						fields.add(ZABConstants.LINKNAME);
				}
				
				if(map.containsKey(ProjectConstants.PROJECT_NAME) && map.get(ProjectConstants.PROJECT_NAME).isEmpty()){
					fields.add(ProjectConstants.PROJECT_NAME);
				}
				
				if(map.containsKey(ProjectConstants.IP_FILTERS)) {
					String ipFilter = map.get(ProjectConstants.IP_FILTERS);
					try {
						JSONArray array = new JSONArray(ipFilter);
						int length = array.length();
						for(int k = 0; k < length; k++) {
							JSONObject obj = array.getJSONObject(k);
							if(!obj.has(ZABConstants.DISPLAY_NAME) || obj.getString(ZABConstants.DISPLAY_NAME).isEmpty()) {
								fields.add(ProjectConstants.IP_FILTERS+"."+ZABConstants.DISPLAY_NAME);
							}
							
							if(!obj.has(ProjectConstants.IP_FILTER_MATCH_TYPE) || obj.getString(ProjectConstants.IP_FILTER_MATCH_TYPE).isEmpty()) {
								fields.add(ProjectConstants.IP_FILTERS+"."+ProjectConstants.IP_FILTER_MATCH_TYPE);
							} else {
								try {
									Integer matchType = obj.getInt(ProjectConstants.IP_FILTER_MATCH_TYPE);
									IPMatchType type = IPMatchType.getIPMatchTypeByNumber(matchType);
									if(type == null) {
										ZABRequest.updateError(map, ZABAction.getMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{ProjectConstants.IP_FILTERS+"."+ProjectConstants.IP_FILTER_MATCH_TYPE}));
										return;
									} else if(type.equals(IPMatchType.EQUALS) || type.equals(IPMatchType.REGEX)) {
										if(!obj.has(ProjectConstants.IP_FILTER_VALUE) || obj.getString(ProjectConstants.IP_FILTER_VALUE).isEmpty()) {
											fields.add(ProjectConstants.IP_FILTERS+"."+ProjectConstants.IP_FILTER_VALUE);
										} else if(type.equals(IPMatchType.REGEX)) {
											String regex = obj.getString(ProjectConstants.IP_FILTER_VALUE);
											try {
												Pattern.compile(regex);												
											} catch (PatternSyntaxException e) {
												ZABRequest.updateError(map, ZABAction.getMessage(ZABConstants.INVALID_REGEX_MESSAGE, new String[]{obj.getString(ZABConstants.DISPLAY_NAME)}));
												return;
											}
										}
									} else if(type.equals(IPMatchType.RANGE)) {
										if(!obj.has(ProjectConstants.IP_FILTER_FROM) || obj.getString(ProjectConstants.IP_FILTER_FROM).isEmpty()) {
											fields.add(ProjectConstants.IP_FILTERS+"."+ProjectConstants.IP_FILTER_FROM);
										}
										
										if(!obj.has(ProjectConstants.IP_FILTER_TO) || obj.getString(ProjectConstants.IP_FILTER_TO).isEmpty()) {
											fields.add(ProjectConstants.IP_FILTERS+"."+ProjectConstants.IP_FILTER_TO);
										}
									}
								} catch (JSONException e) {
									ZABRequest.updateError(map, ZABAction.getMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{ProjectConstants.IP_FILTERS+"."+ProjectConstants.IP_FILTER_MATCH_TYPE}));
									return;
								}
							}
						}
						
					} catch (JSONException e) {
						ZABRequest.updateError(map, ZABAction.getMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{ProjectConstants.IP_FILTERS}));
						return;
					}
				}
				
				if(!fields.isEmpty()) {
					ZABRequest.updateError(map, ZABAction.getAppropriateMessage(ZABConstants.ErrorMessages.MANDATORY_FIELD_MISSING.getErrorString(),fields));
				}
			}
			
			if(httpMethod.equalsIgnoreCase("POST") || httpMethod.equalsIgnoreCase("PUT")){
				if(map.containsKey(ProjectConstants.PROJECT_STATUS)) {
					String projectStatusString = map.get(ProjectConstants.PROJECT_STATUS);
					try {
						Integer projectStatus = Integer.parseInt(projectStatusString);
						if(ProjectStatus.getProjectStatusByNumber(projectStatus)==null) {
							ZABRequest.updateError(map, ZABAction.getMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{ProjectConstants.PROJECT_STATUS}));
							return;
						}
					} catch (NumberFormatException e) {
						ZABRequest.updateError(map, ZABAction.getMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{ProjectConstants.PROJECT_STATUS}));
						return;
					}
				}
				
				if(map.containsKey(ProjectConstants.PROJECT_TYPE)) {
					String projectStatusString = map.get(ProjectConstants.PROJECT_TYPE);
					try {
						Integer projectStatus = Integer.parseInt(projectStatusString);
						if(ProjectStatus.getProjectStatusByNumber(projectStatus)==null) {
							ZABRequest.updateError(map, ZABAction.getMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{ProjectConstants.PROJECT_TYPE}));
							return;
						}
					} catch (NumberFormatException e) {
						ZABRequest.updateError(map, ZABAction.getMessage(ZABConstants.ErrorMessages.INVALID_INPUT_ERROR.getErrorString(), new String[]{ProjectConstants.PROJECT_TYPE}));
						return;
					}
				}
			}
	}
}