//$Id$
package com.zoho.abtest.project;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.zoho.abtest.PROJECT;
import com.zoho.abtest.PROJECT_IPFILTER;
import com.zoho.abtest.PROJECT_SETTINGS;
import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.user.ZABUserConstants;

public class ProjectConstants {
	public static final String API_MODULE = "project"; //No I18N
	public static final String API_MODULE_PLURAL = "projects"; //No I18N
	public static final String API_MODULE_USAGE = "usagestats"; //No I18N
	
	public static final String API_MODULE_USAGE_SINGULAR = "usagestat"; //No I18N
	public static final String API_RESOURCE = "resource.project"; //NO I18N
	public static final String API_RESOURCE_INITIAL = "resource.project.initial"; //NO I18N
	public static final String EXPERIMENT = "experiments"; //No I18N
	public static final String EXPERIMENT_DETAILS = "experiments_details"; //No I18N
	public static final String PERSONALITY_NAME = "projectDetails"; //No I18N
	
	public static final String PROJECT_LABEL = ZABAction.getMessage(API_RESOURCE_INITIAL);
	
	public static final String USAGE_LINK = "usagelink"; //No I18N
	// PROJECT CONSTANTS
	public static final String EXISTING_PROJECTS_COUNT = "existing_projects_count"; //No I18N
	public static final String ALLOWED_PROJECTS_COUNT = "allowed_projects_count"; //No I18N
	public static final String REMAINING_DAYS = "remaining_days"; //No I18N
	public static final String TOTAL_NUMBER_OF_VISITORS = "total_number_of_visitors"; //No I18N
	public static final String TOTAL_NUMBER_OF_VISITORS_EXPERIMENTED = "total_number_of_visitors_experimented"; //No I18N
	public static final String TOTAL_NUMBER_OF_VISITORS_EXPERIMENTED_FOR_PROJECT = "total_number_of_visitors_experimented_for_project"; //No I18N
	public static final String PORTAL_STATUS_FLAG = "portal_status_flag"; //No I18N
	public static final String TOTAL_NUMBER_OF_DAYS = "total_number_of_days"; //No I18N
	public static final String EXPERIMENT_COUNT = "experiment_count"; //No I18N
	public static final String VISITORS_COUNT = "visitors_count"; //No I18N
	public static final String PORTAL = "portal"; //No I18N
	public static final String ID = "id"; //No I18N

	public static final String PROJECT_TYPE="project_type"; //No I18N 
	public static final String PROJECT_STATUS="project_status"; //No I18N 
	public static final String PROJECT_ID = "project_id"; //No I18N
	public static final String PROJECT_NAME = "display_name"; //No I18N
	public static final String PROJECT_LINKNAME = "project_linkname"; //No I18N
	public static final String PROJECT_KEY = "project_key"; //No I18N
	public static final String PROJECT_DESCRIPTION = "project_description";	// NO I18N
	public static final String TOTAL_EXPERIMENTS = "total_experiments";	// NO I18N
	public static final String RUNNING_EXPERIMENTS = "running_experiments";	// NO I18N
	public static final String SCRIPT_URL = "script_url";	// NO I18N
	public static final String ALT_SCRIPT_URL = "alt_script_url";	// NO I18N
	public static final String USER_ROLE_LINK_NAME = "user_role_link_name";	// NO I18N
	public static final String SCRIPT_INCLUDED_WARNING = "script_included_warning";	// NO I18N
	
	public static final String DEFAULT_PROJECT_NAME = "My Project"; //No I18N
	public static final String ASYNC = "async"; //No I18N
	
	public static final String PROJECT_ARCHIVE_VALIDATION_ERROR = "project.archive.validation.error"; //NO I18N
	public static final String PROJECT_DELETE_VALIDATION_ERROR = "project.delete.validation.error"; //NO I18N
	public static final String PROJECT_NOT_EXISTS = "project.not.exists"; //NO I18N
	public static final String PROJECT_ALREADY_EXISTS = "project.name.exists"; //NO I18N
	public static final String PROJECT_EMPTY_NAME = "project.empty.name"; //NO I18N
	
	public static final String MAIL_SNIPPET_SUBJECT = "mail.projectsnippet.subject"; //No I18N
	
	public static final String IP_FILTERS = "ip_filters"; //No I18N
	
	public static final String IP_FILTER_MATCH_TYPE = "ip_match_type"; //No I18N
	
	public static final String IP_FILTER_VALUE = "ip_value"; //No I18N
	
	public static final String IP_FILTER_FROM = "ip_value_from"; //No I18N
	
	public static final String IP_FILTER_TO = "ip_value_to"; //No I18N
	
	// PROJECT SETTINGS CONSTANTS
	
	public static final String PROJECT_JSON_TABLE_NAME = ""; //No I18N
	public static final String JS_CONTENT_ZFS_ID = "js_content_zfs_id" ; //No I18N 
	
	public static enum IPMatchType {
		
		EQUALS(1),
		RANGE(2),
		REGEX(3);
		
		private Integer typeNumber;

		public Integer getTypeNumber() {
			return typeNumber;
		}

		public static IPMatchType getIPMatchTypeByNumber(Integer number) {
			for(IPMatchType status: IPMatchType.values()) {
				if(number!=null && status.getTypeNumber().equals(number)) {
					return status;
				}
			}
			return null;
		}

		private IPMatchType(Integer typeNumber) {
			this.typeNumber = typeNumber;
		}
	}
	
	public static enum ProjectStatus {
		ACTIVE(1),
		ARCHIVE(2);
		
		private Integer typeNumber;
		
		public Integer getStatusNumber() {
			return typeNumber;
		}

		public static ProjectStatus getProjectStatusByNumber(Integer number) {
			for(ProjectStatus status: ProjectStatus.values()) {
				if(number!=null && status.getStatusNumber().equals(number)) {
					return status;
				}
			}
			return null;
		}

		private ProjectStatus(Integer typeNumber) {
			this.typeNumber = typeNumber;
		}
	}
	
	public static enum ProjectType {
		WEB(1),
		MOBILE(2);
		
		private Integer typeNumber;
		
		public Integer getTypeNumber() {
			return typeNumber;
		}

		public static ProjectType getProjectTypeByNumber(Integer number) {
			for(ProjectType status: ProjectType.values()) {
				if(number!=null && status.getTypeNumber().equals(number)) {
					return status;
				}
			}
			return null;
		}

		private ProjectType(Integer typeNumber) {
			this.typeNumber = typeNumber;
		}
	}
	
	public final static List<Constants> PROJECT_TABLE;
	static{
		ArrayList<Constants> list = new ArrayList<Constants>();

		list.add(new Constants(PROJECT_ID,PROJECT.PROJECT_ID,ZABConstants.LONG,Boolean.FALSE));
		list.add(new Constants(ZABConstants.LINKNAME,PROJECT.PROJECT_LINK_NAME,ZABConstants.STRING,Boolean.FALSE));
		list.add(new Constants(PROJECT_KEY,PROJECT.PROJECT_KEY,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
		list.add(new Constants(PROJECT_NAME,PROJECT.PROJECT_NAME,ZABConstants.STRING,Boolean.TRUE));
		list.add(new Constants(PROJECT_TYPE,PROJECT.PROJECT_TYPE,ZABConstants.INTEGER,Boolean.FALSE));
		list.add(new Constants(PROJECT_STATUS,PROJECT.STATUS,ZABConstants.INTEGER,Boolean.TRUE));
		list.add(new Constants(PROJECT_DESCRIPTION,PROJECT.PROJECT_DESCRIPTION,ZABConstants.STRING,Boolean.TRUE));
		list.add(new Constants(ZABUserConstants.CREATED_BY,PROJECT.CREATED_BY,ZABConstants.LONG,Boolean.FALSE));
		list.add(new Constants(ZABUserConstants.CREATED_TIME,PROJECT.CREATED_TIME,ZABConstants.LONG,Boolean.FALSE));
		list.add(new Constants(ZABUserConstants.MODIFIED_TIME,PROJECT.MODIFIED_TIME,ZABConstants.LONG,Boolean.TRUE));
		list.add(new Constants(SCRIPT_INCLUDED_WARNING,PROJECT.SCRIPT_INCLUDED_WARNING,ZABConstants.BOOLEAN,Boolean.TRUE,Boolean.TRUE));
		PROJECT_TABLE = (List<Constants>) Collections.unmodifiableList(list);
	}
	
	public final static List<Constants> PROJECT_SETTINGS_TABLE;
	static {
		ArrayList<Constants> list=new ArrayList<Constants>();
		list.add(new Constants(PROJECT_ID, PROJECT_SETTINGS.PROJECT_ID, ZABConstants.STRING, Boolean.TRUE, true));
		list.add(new Constants(JS_CONTENT_ZFS_ID, PROJECT_SETTINGS.JS_CONTENT_ZFS_ID, ZABConstants.STRING, Boolean.TRUE, true));
		PROJECT_SETTINGS_TABLE=(List<Constants>) Collections.unmodifiableList(list);
	}
	
	public final static List<Constants> PROJECT_IPFILTER_TABLE;
	static {
		ArrayList<Constants> list=new ArrayList<Constants>();
		list.add(new Constants(PROJECT_ID, PROJECT_IPFILTER.PROJECT_ID, ZABConstants.LONG, Boolean.FALSE));
		list.add(new Constants(ZABConstants.DISPLAY_NAME, PROJECT_IPFILTER.IP_FILTER_NAME, ZABConstants.STRING, Boolean.FALSE, true));
		list.add(new Constants(IP_FILTER_MATCH_TYPE, PROJECT_IPFILTER.IP_FILTER_MATCH_TYPE, ZABConstants.INTEGER, Boolean.FALSE, true));
		list.add(new Constants(IP_FILTER_VALUE, PROJECT_IPFILTER.IP_FILTER_VALUE, ZABConstants.STRING, Boolean.FALSE, true));
		PROJECT_IPFILTER_TABLE=(List<Constants>) Collections.unmodifiableList(list);
	}
}
