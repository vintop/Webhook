//$Id$
package com.zoho.abtest.project;


import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringEscapeUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.mfw.bean.BeanUtil;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.ABSPLITEXPERIMENT;
import com.zoho.abtest.AUDIENCE;
import com.zoho.abtest.CUSTOM_EVENT_GOAL;
import com.zoho.abtest.DYNAMIC_ATTRIBUTES;
import com.zoho.abtest.ELEMENT_CLICK_GOAL;
import com.zoho.abtest.EVENTS;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.EXPERIMENT_AUDIENCE;
import com.zoho.abtest.EXPERIMENT_DYNAMIC_ATTR;
import com.zoho.abtest.EXPERIMENT_GOAL;
import com.zoho.abtest.EXPERIMENT_PROJECT_INTEGRATION;
import com.zoho.abtest.FORM_CUSTOM_EVENTS;
import com.zoho.abtest.FORM_DETAILS;
import com.zoho.abtest.FORM_FIELD_DETAILS;
import com.zoho.abtest.FORM_SUBMIT_GOAL;
import com.zoho.abtest.FUNNEL_ANALYSIS;
import com.zoho.abtest.FUNNEL_STEPS;
import com.zoho.abtest.FUNNEL_STEP_EVENTS;
import com.zoho.abtest.GOAL;
import com.zoho.abtest.HEATMAP_EXPERIMENT;
import com.zoho.abtest.LINK_CLICK_GOAL;
import com.zoho.abtest.PAGE_VISIT_GOAL;
import com.zoho.abtest.PRIVACY_CONSENT;
import com.zoho.abtest.PROJECT;
import com.zoho.abtest.PROJECT_GOAL;
import com.zoho.abtest.PROJECT_INTEGRATION;
import com.zoho.abtest.SESSION_RECORDING_EXPERIMENT;
import com.zoho.abtest.TIME_SPENT_GOAL;
import com.zoho.abtest.VARIATION;
import com.zoho.abtest.audience.Audience;
import com.zoho.abtest.cdn.ZABCDN;
import com.zoho.abtest.common.MatchType;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.dimension.DimensionConstants;
import com.zoho.abtest.dimension.DynamicAttributes;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentActivationMode;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentStatus;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentType;
import com.zoho.abtest.forms.FormConstants;
import com.zoho.abtest.forms.FormConstants.FormMatchType;
import com.zoho.abtest.forms.FormParseUrl;
import com.zoho.abtest.funnel.FunnelAnalysisConstants.FunnelMatchType;
import com.zoho.abtest.goal.GoalConstants;
import com.zoho.abtest.goal.GoalConstants.GoalStatus;
import com.zoho.abtest.goal.GoalConstants.GoalType;
import com.zoho.abtest.integration.GoogleAnalytics;
import com.zoho.abtest.integration.IntegrationConstants;
import com.zoho.abtest.integration.IntegrationConstants.Integ;
import com.zoho.abtest.privacyconsent.PrivacyConstants;
import com.zoho.abtest.project.ProjectConstants.ProjectStatus;
import com.zoho.abtest.project.ProjectTreeEventConstants.Module;
import com.zoho.abtest.utility.FileUtil;
import com.zoho.abtest.utility.ZABUserBean;
import com.zoho.abtest.variation.Variation;

public class ProjectJSONService {
	
	private static final Logger LOGGER = Logger.getLogger(ProjectJSONService.class.getName());
	
	public static String getBasicJSON(String dbspace) {
		return "{\""+ProjectJSONConstants.SPACEID+"\":\""+dbspace+"\"}";
	}
	
	public static void updateProjectJSON(Long projectId, String portalName, String json, Module module, Long userId) throws Exception {
		
		ZABCDN cdn = (ZABCDN)BeanUtil.lookup("ZABCDN");
		String fileName = Project.getProjectFileName(projectId, portalName);
		if(module.equals(Module.PROJECT)) {
			cdn.createFile(fileName, FileUtil.createInputStream(json), userId, portalName);
		} else {			
			cdn.updateFile(Project.getProjectFileName(projectId, portalName), FileUtil.createInputStream(json), userId, portalName);
		}
		LOGGER.log(Level.INFO, "File written to CDN:"+cdn);
   }
	
	/*
	public static JSONObject convertToJSON(Experiment experiment) throws JSONException {
		JSONObject experimentJSON = new JSONObject();
		experimentJSON.put(ProjectJSONConstants.EXPERIMENT_ID, experiment.getExperimentKey());
		experimentJSON.put(ProjectJSONConstants.STATUS, experiment.getExperimentStatus());
		experimentJSON.put(ProjectJSONConstants.PERMITTED_TRAFFIC, experiment.getPermittedTraffic());
		experimentJSON.put(ProjectJSONConstants.TYPE, experiment.getExperimentType());
		ArrayList<Variation> variations = experiment.getVariations();
		if(variations!=null && !variations.isEmpty()) {
			JSONObject variationArray = new JSONObject();
			int size = variations.size();
			for(int i=0; i<size; i++) {
				Variation variation = variations.get(i);
				variationArray.put(variation.getVariationLinkname(), convertToJSON(variation));
			}
			experimentJSON.put(ProjectJSONConstants.VARIATIONS, variationArray);
		}
		ArrayList<Goal> goals = experiment.getGoals();
		if(goals!=null && !goals.isEmpty()) {
			JSONArray goalsArray = new JSONArray();
			int size = goals.size();
			for(int i=0; i<size; i++) {
				Goal goal = goals.get(i);
				goalsArray.put(goal.getGoalLinkname());
			}
			experimentJSON.put(ProjectJSONConstants.GOAL, goalsArray);
		}
		List<DynamicAttributes> dynamicAttributes = experiment.getDynamicAttributes();
		if(dynamicAttributes != null)
		{
			JSONArray dynamicAttrArray = new JSONArray();
			for(DynamicAttributes dynamicAttribute:dynamicAttributes)
			{
				dynamicAttrArray.put(dynamicAttribute.getAttributeLinkName());
			}
			experimentJSON.put(ProjectJSONConstants.DYNAMIC_ATTRIBUTE, dynamicAttrArray);
		}
		return experimentJSON;
	}
	*/
	
	public static JSONObject convertToJSON(Variation variation) throws JSONException {
		JSONObject variationJSON = new JSONObject();
		variationJSON.put(ProjectJSONConstants.IS_ORIGINAL, variation.getIsOriginal());
		variationJSON.put(ProjectJSONConstants.ALLOTED_PERCENTAGE, variation.getTrafficAllocation());
		
		try {
			String changes = variation.getVariationChanges();
			if(changes!=null &&!changes.isEmpty()) {					
//				JSONArray changesJson = new JSONArray(changes);
				variationJSON.put(ProjectJSONConstants.VARIATION_CHANGES, changes);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		variationJSON.put(ProjectJSONConstants.URL, variation.getTargetUrl());
		variationJSON.put(ProjectJSONConstants.ID, variation.getVariationKey());
		variationJSON.put(ProjectJSONConstants.LINKNAME, variation.getVariationLinkname());
		return variationJSON;
	}
	
	/*public static JSONObject convertToJSON(Goal ld) throws JSONException {
		JSONObject goal = new JSONObject();
		goal.put(GoalConstants.GOAL_TYPE, ld.getGoalTypeTag());
		if(ld instanceof CustomEventGoal) {
			CustomEventGoal child = (CustomEventGoal)ld;
			goal.put(GoalConstants.CUSTOM_EVENT_NAME, child.getEventName());
		} else if(ld instanceof ElementClickGoal) {
			ElementClickGoal child = (ElementClickGoal)ld;
			goal.put(GoalConstants.ELEMENT_CSS_SELECTOR, child.getElementCssSelector());
		} else if(ld instanceof FormSubmitGoal) {
			FormSubmitGoal child = (FormSubmitGoal)ld;
			JSONArray urls = new JSONArray();
			JSONObject url = new JSONObject();
			url.put(GoalConstants.MATCH_TYPE, child.getMatchType());
			url.put(GoalConstants.VALUE, child.getSubmitUrl());
			urls.put(url);
			goal.put(GoalConstants.URL, urls);
		} else if(ld instanceof LinkClickGoal) {
			LinkClickGoal child = (LinkClickGoal)ld;
			JSONArray urls = new JSONArray();
			JSONObject url = new JSONObject();
			url.put(GoalConstants.MATCH_TYPE, child.getMatchType());
			url.put(GoalConstants.VALUE, child.getLinkUrl());
			urls.put(url);
			goal.put(GoalConstants.URL, urls);
			
		} else if(ld instanceof PageVisitGoal) {
			PageVisitGoal child = (PageVisitGoal)ld;
			int size2 = child.getPageVisitUrls().size();
			JSONArray urls = new JSONArray();
			for(int j=0; j<size2; j++) {
				PageVisitGoal pvgoal = child.getPageVisitUrls().get(j);
				JSONObject url = new JSONObject();
				url.put(GoalConstants.MATCH_TYPE, pvgoal.getMatchType());
				url.put(GoalConstants.VALUE, pvgoal.getUrl());
				urls.put(url);
			}
			goal.put(GoalConstants.URL, urls);
		}
		return goal;
	}*/
	
	public static JSONObject convertToJSON(Audience audience) throws JSONException {
		JSONObject audienceJSON = new JSONObject();
		audienceJSON.put(ProjectJSONConstants.AUDIENCE_CONDITION, audience.getAudienceConditionJSON());
		return audienceJSON;
	}
	
	public static JSONObject convertToJSON(DynamicAttributes dynamicAttribute) throws JSONException {
		JSONObject dynamicAttributeJson = new JSONObject();
		dynamicAttributeJson.put(DimensionConstants.ATTRIBUTE_TYPE, dynamicAttribute.getAttributeType());
		dynamicAttributeJson.put(DimensionConstants.ATTRIBUTE_NAME, dynamicAttribute.getAttributeName());
		return dynamicAttributeJson;
	}
	
	
	public static JSONObject getExperimentJSONForFormAnalytics(Row row,DataObject dobj) throws DataAccessException, JSONException{
		JSONObject expJSON=new JSONObject();
		Long experimentId = (Long)row.get(EXPERIMENT.EXPERIMENT_ID);
		expJSON=getFullFormJSON(dobj,experimentId,row);
		return expJSON;
	}
	
	public static JSONObject getFullFormJSON(DataObject dobj,Long experimentId,Row row2) throws DataAccessException, JSONException
	{
		JSONObject json=new JSONObject();
		JSONArray urls = null;
		
		String experimentKey = (String)row2.get(EXPERIMENT.EXPERIMENT_KEY);
		
		Criteria c2 = new Criteria(new Column(FORM_DETAILS.TABLE, FORM_DETAILS.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
		Row formanalyticsRow = dobj.getRow(FORM_DETAILS.TABLE, c2);
		
		//TODO: Need to implement match types in Experiment. Below is default value
		String url = (String)formanalyticsRow.get(FORM_DETAILS.EXPERIMENT_URL);
		String includeurls = (String)formanalyticsRow.get(FORM_DETAILS.INCLUDE_URLS);
		
		
		if(includeurls!=null){
			urls = new JSONArray(includeurls);
		}
		
		if(urls == null || urls.length() == 0){
			urls = new JSONArray();
			urls.put(new JSONObject().put(ProjectJSONConstants.VALUE, url).put(ProjectJSONConstants.MATCH_TYPE, MatchType.SIMPLE_MATCH.getMatchTypeId()));
		}
		
		json.put(ProjectJSONConstants.URLS, urls);
		

		String excludeurls = (String)formanalyticsRow.get(FORM_DETAILS.EXCLUDE_URLS);
		if(excludeurls!=null){
			json.put(ProjectJSONConstants.EXCLUDE_URLS, new JSONArray(excludeurls));
		}else{
			json.put(ProjectJSONConstants.EXCLUDE_URLS, new JSONArray());
		}
		
		json.put(ProjectJSONConstants.NAME, (String)row2.get(EXPERIMENT.EXPERIMENT_NAME));
		json.put(ProjectJSONConstants.KEY, experimentKey);
		json.put(ProjectJSONConstants.STATUS, (Integer)row2.get(EXPERIMENT.EXPERIMENT_STATUS));
		json.put(ProjectJSONConstants.TYPE, (Integer)row2.get(EXPERIMENT.EXPERIMENT_TYPE));
		
		//form details
		JSONObject jobject=new JSONObject();
		if(dobj.containsTable(FORM_DETAILS.TABLE)) {
		
			Criteria c = new Criteria(new Column(FORM_DETAILS.TABLE, FORM_DETAILS.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
			Iterator it = dobj.getRows(FORM_DETAILS.TABLE,c);
			JSONArray conversionUrls=new JSONArray();
			
			if(it.hasNext()) {
			
				Row row = (Row)it.next();
				Integer matchType = (Integer)row.get(FORM_DETAILS.MATCH_TYPE);
				if(!matchType.equals(FormMatchType.CUSTOM_EVENT.getMatchTypeId())) {
					if(row.get(FORM_DETAILS.FORM_CONVERSION_URL)!=null){
						conversionUrls.put(new JSONObject().put(ProjectJSONConstants.VALUE,(String)row.get(FORM_DETAILS.FORM_CONVERSION_URL)).put(ProjectJSONConstants.MATCH_TYPE, (Integer)row.get(FORM_DETAILS.MATCH_TYPE)));
					}
				}
				
				jobject.put(FormConstants.EXPERIMENT_KEY,experimentKey);
				jobject.put(FormConstants.FORM_ELEMENT_NAME, (String)row.get(FORM_DETAILS.FORM_ELEMENT_NAME));
				jobject.put(FormConstants.FORM_ELEMENT_ID, (String)row.get(FORM_DETAILS.FORM_ELEMENT_ID));
				jobject.put(FormConstants.FORM_ELEMENT_SELECTOR, StringEscapeUtils.unescapeHtml4((String)row.get(FORM_DETAILS.FORM_ELEMENT_SELECTOR)));
				jobject.put(FormConstants.FORM_LOADED, (Boolean)row.get(FORM_DETAILS.IS_AUTO_LOADED));
				
				if(matchType.equals(FormMatchType.CUSTOM_EVENT.getMatchTypeId())){
					
					Criteria Cri = new Criteria(new Column( FORM_CUSTOM_EVENTS.TABLE,FORM_CUSTOM_EVENTS.EXPERIMENT_ID),experimentId,QueryConstants.EQUAL);
					try {
							
						Row farow = dobj.getRow(FORM_CUSTOM_EVENTS.TABLE, Cri);
						Long eventId = (Long) farow.get(FORM_CUSTOM_EVENTS.EVENT_ID);
						Criteria customStepCri = new Criteria(new Column(EVENTS.TABLE,EVENTS.EVENT_ID),eventId,QueryConstants.EQUAL);
						Row eventRow = dobj.getRow(EVENTS.TABLE, customStepCri);
						String eventLinkName = (String)eventRow.get(EVENTS.EVENT_LINKNAME);
						String eventName = (String)eventRow.get(EVENTS.EVENT_NAME);
						jobject.put(FormConstants.CUSTOM_EVENT_LINK_NAME, eventLinkName);
						jobject.put(FormConstants.CUSTOM_EVENT_NAME, eventName);
					} catch (Exception e) {
						LOGGER.log(Level.SEVERE,e.getMessage(),e);
					}
						
				}else if(matchType.equals(FormMatchType.SIMPLE_MATCH.getMatchTypeId()) || matchType.equals(FormMatchType.EXACT_MATCH.getMatchTypeId())){
						jobject.put(FormConstants.FORM_CONVERSION_URL,conversionUrls);
						jobject.put(FormConstants.DOMAIN_MATCH,FormParseUrl.compareUrls(url,(String)row.get(FORM_DETAILS.FORM_CONVERSION_URL)));
				} else {
					jobject.put(FormConstants.FORM_CONVERSION_URL,conversionUrls);
					jobject.put(FormConstants.DOMAIN_MATCH, false);
				}
					
				Criteria c1=new Criteria(new Column(FORM_FIELD_DETAILS.TABLE, FORM_FIELD_DETAILS.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
				Iterator it1 = dobj.getRows(FORM_FIELD_DETAILS.TABLE,c1);
				JSONArray jarray1=new JSONArray();
				
				while(it1.hasNext())
				{
					Row row1 = (Row)it1.next();
					
					if((Boolean)row1.get(FORM_FIELD_DETAILS.IS_ENABLED)) {
					
						JSONObject field=new JSONObject();
						field.put(FormConstants.FORM_FIELD_KEY, (String)row1.get(FORM_FIELD_DETAILS.FORM_FIELD_KEY));
						field.put(FormConstants.FIELD_ID, (String)row1.get(FORM_FIELD_DETAILS.FIELD_ID));
						field.put(FormConstants.FORM_FIELD_NAME, (String)row1.get(FORM_FIELD_DETAILS.FORM_FIELD_NAME));
						jarray1.put(field);
					}
				}
				jobject.put(ProjectJSONConstants.FORM_FIELD_DETAILS,jarray1);
			}
		}
		json.put(ProjectJSONConstants.FORM_DETAILS, jobject);
		return json;
	}
	public static JSONObject getExperimentJSONForABSplit(Row row, DataObject dobj) throws DataAccessException, JSONException {
		
		Long experimentId = (Long)row.get(EXPERIMENT.EXPERIMENT_ID);
		Criteria c1 = new Criteria(new Column(ABSPLITEXPERIMENT.TABLE, ABSPLITEXPERIMENT.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
		Row absplitRow = dobj.getRow(ABSPLITEXPERIMENT.TABLE, c1);
		JSONObject expJSON = new JSONObject();
		String experimentKey = (String)row.get(EXPERIMENT.EXPERIMENT_KEY);
		expJSON.put(ProjectJSONConstants.NAME, (String)row.get(EXPERIMENT.EXPERIMENT_NAME));
		expJSON.put(ProjectJSONConstants.KEY, experimentKey);
		expJSON.put(ProjectJSONConstants.STATUS, (Integer)row.get(EXPERIMENT.EXPERIMENT_STATUS));
		expJSON.put(ProjectJSONConstants.TYPE, (Integer)row.get(EXPERIMENT.EXPERIMENT_TYPE));
		expJSON.put(ProjectJSONConstants.PERMITTED_TRAFFIC, (Integer)absplitRow.get(ABSPLITEXPERIMENT.PERMITTED_TRAFFIC));

		expJSON.put(ProjectJSONConstants.ACTIVATION_MODE, (Integer)row.get(EXPERIMENT.ACTIVATION_MODE));
		if(expJSON.get(ProjectJSONConstants.ACTIVATION_MODE).equals(ExperimentActivationMode.CONDITIONAL.getModeNo())){
			expJSON.put(ProjectJSONConstants.ACTIVATION_CONDITION, (String)row.get(EXPERIMENT.ACTIVATION_CONDITION));
		}
			
		if((Boolean)absplitRow.get(ABSPLITEXPERIMENT.IS_HEATMAP_ENABLED)){
			expJSON.put(ProjectJSONConstants.HEATMAP,ExperimentStatus.RUNNING.getStatusCode());
		}else{
			expJSON.put(ProjectJSONConstants.HEATMAP,ExperimentStatus.PAUSED.getStatusCode());
		}

		expJSON.put(ProjectJSONConstants.REDIRECT_PARAMS,(Boolean)absplitRow.get(ABSPLITEXPERIMENT.REDIRECT_PARAMS));
		expJSON.put(ProjectJSONConstants.GLOBAL_JS,(String)absplitRow.get(ABSPLITEXPERIMENT.GLOBAL_JS));
		expJSON.put(ProjectJSONConstants.GLOBAL_CSS,(String)absplitRow.get(ABSPLITEXPERIMENT.GLOBAL_CSS));

		//TODO: Need to implement match types in Experiment. Below is default value
		String url = (String)absplitRow.get(ABSPLITEXPERIMENT.EXPERIMENT_URL);
		String includeurls = (String)absplitRow.get(ABSPLITEXPERIMENT.INCLUDE_URLS);
		JSONArray urls = null;
		
		if(includeurls!=null){
			urls = new JSONArray(includeurls);
		}
		
		if(urls == null || urls.length() == 0){
			urls = new JSONArray();
			urls.put(new JSONObject().put(ProjectJSONConstants.VALUE, url).put(ProjectJSONConstants.MATCH_TYPE, MatchType.SIMPLE_MATCH.getMatchTypeId()));
		}
		
		expJSON.put(ProjectJSONConstants.URLS, urls);
		

		String excludeurls = (String)absplitRow.get(ABSPLITEXPERIMENT.EXCLUDE_URLS);
		if(excludeurls!=null){
			expJSON.put(ProjectJSONConstants.EXCLUDE_URLS, new JSONArray(excludeurls));
		}else{
			expJSON.put(ProjectJSONConstants.EXCLUDE_URLS, new JSONArray());
		}
		
		if(dobj.containsTable(VARIATION.TABLE)) {
			
			JSONObject variationJSArray = new JSONObject();
			Criteria variationCriteria = new Criteria(new Column(VARIATION.TABLE, VARIATION.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
			Iterator variationIterator = dobj.getRows(VARIATION.TABLE, variationCriteria);
			while(variationIterator.hasNext()) {
				Row variationRow = (Row)variationIterator.next();
				JSONObject variationJSON = new JSONObject();
				String variationKey = (String)variationRow.get(VARIATION.VARIATION_KEY);
				variationJSON.put(ProjectJSONConstants.IS_ORIGINAL, (Boolean)variationRow.get(VARIATION.IS_ORIGINAL));
				variationJSON.put(ProjectJSONConstants.ALLOTED_PERCENTAGE, (Float)variationRow.get(VARIATION.TRAFFIC_ALLOCATION));
				variationJSON.put(ProjectJSONConstants.URL, (String)variationRow.get(VARIATION.TARGET_URL));
				variationJSON.put(ProjectJSONConstants.NAME, (String)variationRow.get(VARIATION.VARIATION_NAME));
				variationJSON.put(ProjectJSONConstants.KEY, variationKey);
//				variationJSON.put(ProjectJSONConstants.ID, (Long)variationRow.get(VARIATION.VARIATION_ID));
//				variationJSON.put(ProjectJSONConstants.VARIATION_CHANGES, new JSONFunction((String)variationRow.get(VARIATION.CONTENT_VARIATION_CHANGES)));

				//TODO: Need to change the changes as array of changesets. 
				//Access CONTENT_VARIATION_CHANGES_JSON , iterate and get "jsText" to form array of changesets.
				//Need to implement it once client side work is done. Below is the workaround until implementation. 
				String variationString = (String) variationRow.get(VARIATION.CONTENT_VARIATION_CHANGES);
//				
				if(variationString != null){
					variationJSON.put(ProjectJSONConstants.VARIATION_CHANGES, new JSONArray().put(variationString));
				}

				String variationCSSChanges = (String) variationRow.get(VARIATION.CONTENT_VARIATION_CSS_CHANGES);
				if(variationCSSChanges != null){
					variationJSON.put(ProjectJSONConstants.VARIATION_CSS_CHANGES, variationCSSChanges);
				}
				
				variationJSArray.put((String)variationRow.get(VARIATION.VARIATION_KEY), variationJSON);
			}
			expJSON.put(ProjectJSONConstants.VARIATIONS, variationJSArray);
		}
		
		//Initiate array
		expJSON.put(ProjectJSONConstants.AUDIENCE, new JSONArray());
		expJSON.put(ProjectJSONConstants.GOAL, new JSONArray());
		expJSON.put(ProjectJSONConstants.DYNAMIC_ATTRIBUTE, new JSONArray());
		expJSON.put(ProjectJSONConstants.INTEGRATIONS, new JSONObject());
		return expJSON;
	}
	
	public static JSONObject getExperimentObjectForFunnel(Row row, DataObject dobj) throws JSONException, DataAccessException {
		JSONObject expJSON = new JSONObject();
		String experimentKey = (String)row.get(EXPERIMENT.EXPERIMENT_KEY);
		Long experimentId = (Long)row.get(EXPERIMENT.EXPERIMENT_ID);

        expJSON.put(ProjectJSONConstants.NAME, (String)row.get(EXPERIMENT.EXPERIMENT_NAME));
		expJSON.put(ProjectJSONConstants.KEY, experimentKey);
		expJSON.put(ProjectJSONConstants.STATUS, (Integer)row.get(EXPERIMENT.EXPERIMENT_STATUS));
		expJSON.put(ProjectJSONConstants.TYPE, (Integer)row.get(EXPERIMENT.EXPERIMENT_TYPE));

        if(dobj.containsTable(FUNNEL_ANALYSIS.TABLE)) {
			Criteria c = new Criteria(new Column(FUNNEL_ANALYSIS.TABLE, FUNNEL_ANALYSIS.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
			Row funRow = dobj.getRow(FUNNEL_ANALYSIS.TABLE, c);
			Long sessionTime = (Long)funRow.get(FUNNEL_ANALYSIS.SESSION_TIME);
			expJSON.put(ProjectJSONConstants.SESSSION_TIME, sessionTime);
		}
		
		if(dobj.containsTable(FUNNEL_STEPS.TABLE)) {
			JSONObject steps =new JSONObject();
			Criteria c = new Criteria(new Column(FUNNEL_STEPS.TABLE, FUNNEL_STEPS.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
			Iterator it = dobj.getRows(FUNNEL_STEPS.TABLE, c);
			while(it.hasNext()) {
				Row fsRow = (Row)it.next();
				Integer stepOrder = (Integer)fsRow.get(FUNNEL_STEPS.STEP_ORDER);
				JSONObject eachStep = new JSONObject();
				eachStep.put(ProjectJSONConstants.STEP_ORDER, stepOrder);
				String stepKey = (String)fsRow.get(FUNNEL_STEPS.STEP_KEY);
				eachStep.put(ProjectJSONConstants.KEY, (String)fsRow.get(FUNNEL_STEPS.STEP_KEY));
			
				Integer matchType = (Integer)fsRow.get(FUNNEL_STEPS.STEP_MATCH_TYPE);
				if(matchType.equals(FunnelMatchType.URLLESS.getMatchTypeId())){
					Long stepId = (Long)fsRow.get(FUNNEL_STEPS.STEP_ID);
					Criteria funnelStepCri = new Criteria(new Column( FUNNEL_STEP_EVENTS.TABLE,FUNNEL_STEP_EVENTS.STEP_ID),stepId,QueryConstants.EQUAL);
					try {
						
						Row fmrow = dobj.getRow(FUNNEL_STEP_EVENTS.TABLE, funnelStepCri);
						Long eventId = (Long) fmrow.get(FUNNEL_STEP_EVENTS.EVENT_ID);
						Criteria customStepCri = new Criteria(new Column(EVENTS.TABLE,EVENTS.EVENT_ID),eventId,QueryConstants.EQUAL);
						Row eventRow = dobj.getRow(EVENTS.TABLE, customStepCri);
						String eventName = (String)eventRow.get(EVENTS.EVENT_NAME);
						eachStep.put(ProjectJSONConstants.CUSTOM_STEP, eventName);
						steps.put(stepKey, eachStep);
					} catch (Exception e) {
						
						e.printStackTrace();
					}
					
				}else{
					JSONArray url = new JSONArray();
					JSONObject urlObj = new JSONObject();
					urlObj.put(ProjectJSONConstants.MATCH_TYPE,matchType);
					urlObj.put(ProjectJSONConstants.VALUE, (String)fsRow.get(FUNNEL_STEPS.STEP_VALUE));
					eachStep.put(ProjectJSONConstants.URL, url.put(urlObj));
					steps.put(stepKey, eachStep);
				}
				
			}
			
			expJSON.put(ProjectJSONConstants.STEPS, steps);
		}
		
        return expJSON;
	}



	/**
	 * @param row
	 * @param dobj
	 * @return
	 * @throws DataAccessException
	 * @throws JSONException
	 */
	public static JSONObject getExperimentJSONForHeatmap(Row row, DataObject dobj) throws DataAccessException, JSONException {
		
		Long experimentId = (Long)row.get(EXPERIMENT.EXPERIMENT_ID);
		
		Criteria c1 = new Criteria(new Column(HEATMAP_EXPERIMENT.TABLE, HEATMAP_EXPERIMENT.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
		Row heatmapRow = dobj.getRow(HEATMAP_EXPERIMENT.TABLE, c1);
		
		JSONObject expJSON = new JSONObject();
		String experimentKey = (String)row.get(EXPERIMENT.EXPERIMENT_KEY);

        expJSON.put(ProjectJSONConstants.NAME, (String)row.get(EXPERIMENT.EXPERIMENT_NAME));
		expJSON.put(ProjectJSONConstants.KEY, experimentKey);
		expJSON.put(ProjectJSONConstants.STATUS, (Integer)row.get(EXPERIMENT.EXPERIMENT_STATUS));
		expJSON.put(ProjectJSONConstants.TYPE, (Integer)row.get(EXPERIMENT.EXPERIMENT_TYPE));
		expJSON.put(ProjectJSONConstants.ACTIVATION_MODE, (Integer)row.get(EXPERIMENT.ACTIVATION_MODE));
		if(expJSON.get(ProjectJSONConstants.ACTIVATION_MODE).equals(ExperimentActivationMode.CONDITIONAL.getModeNo())){
			expJSON.put(ProjectJSONConstants.ACTIVATION_CONDITION, (String)row.get(EXPERIMENT.ACTIVATION_CONDITION));
		}

        //expJSON.put(ProjectJSONConstants.PERMITTED_TRAFFIC, (Integer)heatmapRow.get(HEATMAP_EXPERIMENT.PERMITTED_TRAFFIC));
		
		//TODO: Need to implement match types in Experiment. Below is default value
		String url = (String)heatmapRow.get(HEATMAP_EXPERIMENT.EXPERIMENT_URL);
		String includeurls = (String)heatmapRow.get(HEATMAP_EXPERIMENT.INCLUDE_URLS);
		JSONArray urls = null;
		
		if(includeurls!=null){
			urls = new JSONArray(includeurls);
		}
		
		if(urls == null || urls.length() == 0){
			urls = new JSONArray();
			urls.put(new JSONObject().put(ProjectJSONConstants.VALUE, url).put(ProjectJSONConstants.MATCH_TYPE, MatchType.SIMPLE_MATCH.getMatchTypeId()));
		}
		
		expJSON.put(ProjectJSONConstants.URLS, urls);
		
		String excludeurls = (String)heatmapRow.get(HEATMAP_EXPERIMENT.EXCLUDE_URLS);
		if(excludeurls!=null){
			expJSON.put(ProjectJSONConstants.EXCLUDE_URLS, new JSONArray(excludeurls));
		}else{
			expJSON.put(ProjectJSONConstants.EXCLUDE_URLS, new JSONArray());
		}

        return expJSON;
	}

	public static JSONObject getExperimentJSONForSessionRecording(Row row, DataObject dobj) throws JSONException, DataAccessException {
		JSONObject expJSON = new JSONObject();
		String experimentKey = (String)row.get(EXPERIMENT.EXPERIMENT_KEY);
		Long experimentId = (Long)row.get(EXPERIMENT.EXPERIMENT_ID);

        expJSON.put(ProjectJSONConstants.NAME, (String)row.get(EXPERIMENT.EXPERIMENT_NAME));
		expJSON.put(ProjectJSONConstants.KEY, experimentKey);
		expJSON.put(ProjectJSONConstants.STATUS, (Integer)row.get(EXPERIMENT.EXPERIMENT_STATUS));
		expJSON.put(ProjectJSONConstants.TYPE, (Integer)row.get(EXPERIMENT.EXPERIMENT_TYPE));

        if(dobj.containsTable(SESSION_RECORDING_EXPERIMENT.TABLE)) {
			Criteria c = new Criteria(new Column(SESSION_RECORDING_EXPERIMENT.TABLE, SESSION_RECORDING_EXPERIMENT.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
			Row funRow = dobj.getRow(SESSION_RECORDING_EXPERIMENT.TABLE, c);
			
			String includeurls = (String)funRow.get(SESSION_RECORDING_EXPERIMENT.INCLUDE_URLS);
			JSONArray urls = null;
			
			if(includeurls!=null){
				urls = new JSONArray(includeurls);
			}
			
			expJSON.put(ProjectJSONConstants.URLS, urls);
			
			String excludeurls = (String)funRow.get(HEATMAP_EXPERIMENT.EXCLUDE_URLS);
			if(excludeurls!=null){
				expJSON.put(ProjectJSONConstants.EXCLUDE_URLS, new JSONArray(excludeurls));
			}else{
				expJSON.put(ProjectJSONConstants.EXCLUDE_URLS, new JSONArray());
			}
			
			String maskSelector = (String)funRow.get(SESSION_RECORDING_EXPERIMENT.MASKED_ELEM_SELECTORS);
			
			if(maskSelector!=null) {
				String unescaped = StringEscapeUtils.unescapeJava(maskSelector);
				expJSON.put(ProjectJSONConstants.MASK_ELEMENTS, unescaped);
			}
			

			expJSON.put(ProjectJSONConstants.PERMITTED_TRAFFIC, (Integer)funRow.get(SESSION_RECORDING_EXPERIMENT.PERMITTED_TRAFFIC));
			//expJSON.put(ProjectJSONConstants.MAX_RECORDING_COUNT, (String)funRow.get(SESSION_RECORDING_EXPERIMENT.MAX_RECORDING_COUNT));
		}
		
        return expJSON;
	}
	
	public static JSONObject constructExperimentJSON(DataObject dobj) throws Exception {

		Iterator it = dobj.getRows(EXPERIMENT.TABLE);
		JSONObject experimentsJson = new JSONObject();
		while(it.hasNext()) {
			
			Row row = (Row)it.next();
			Integer typeNumber = (Integer)row.get(EXPERIMENT.EXPERIMENT_TYPE);
			String experimentKey = (String)row.get(EXPERIMENT.EXPERIMENT_KEY);
			ExperimentType type = ExperimentType.getExperimentTypeByNumber(typeNumber);
			JSONObject expJSON = null;
			switch (type) {
			case ABTEST:
			case SPLITURL:
				expJSON = getExperimentJSONForABSplit(row, dobj);
				break;
			case FORMANALYTICS:
				expJSON =getExperimentJSONForFormAnalytics(row,dobj);
				break;
			case FUNNEL:
				expJSON = getExperimentObjectForFunnel(row, dobj);
				break;
			case HEATMAP:
				expJSON = getExperimentJSONForHeatmap(row, dobj);
				break;
			case SESSION_RECORDING:
				expJSON = getExperimentJSONForSessionRecording(row, dobj);
				break;
			default:
				break;
			}
			
			if(expJSON!=null) {				
				experimentsJson.put(experimentKey, expJSON); 
			}
		}
		return experimentsJson;
	}
	
	public static JSONObject constructGoalJSON(Long projId ,DataObject expdobj, JSONObject experiments) throws Exception {
		JSONObject goalJSON = new JSONObject();
		Criteria eventCri = new Criteria(new Column(EVENTS.TABLE,EVENTS.PROJECT_ID),projId,QueryConstants.EQUAL);
		DataObject eventdobj = ZABModel.getRow(EVENTS.TABLE, eventCri);
	
		Criteria goalCri = new Criteria(new Column(GOAL.TABLE,GOAL.PROJECT_ID),projId,QueryConstants.EQUAL);
		DataObject goaldobj = ZABModel.getPersonality("goalDetail", goalCri); // NO I18N
		
		if(goaldobj.containsTable(GOAL.TABLE)){
			Iterator it = goaldobj.getRows(GOAL.TABLE);
			while(it.hasNext()) {
				//Adding try catch here as failure in one goal affects other goal creation
				try {
				Row grow = (Row)it.next();
				Integer goalstatus = (Integer)grow.get(GOAL.GOAL_STATUS);
				if(goalstatus.equals(GoalStatus.PAUSED.getStatusCode())){
					continue;
				}
				Long goalId = (Long)grow.get(GOAL.GOAL_ID);
				String linkname = (String)grow.get(GOAL.GOAL_LINK_NAME);
				Boolean isprojectlevel =  (Boolean)grow.get(GOAL.IS_PROJECT_LEVEL);
				Integer goalType =  (Integer)grow.get(GOAL.GOAL_TYPE_FLAG);
				JSONObject goalData = new JSONObject();
				goalData.put(GoalConstants.GOAL_TYPE, goalType);
				goalData.put(GoalConstants.IS_PROJECT_LEVEL, isprojectlevel);
			
				if(isprojectlevel){
					
					if(goaldobj.containsTable(PROJECT_GOAL.TABLE)) {
						Criteria c1 = new Criteria(new Column(PROJECT_GOAL.TABLE, PROJECT_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
						Row projgoalrow = goaldobj.getRow(PROJECT_GOAL.TABLE, c1);
						if(projgoalrow!=null ){
							String goalurl = (String)projgoalrow.get(PROJECT_GOAL.GOAL_URL);
							if(goalType.equals(GoalType.CUSTOM_EVENT_GOAL.getGoalTypeId()) && (goalurl!=null && goalurl.equals("*"))){
								goalData.put(GoalConstants.GOAL_URL, "*");
							}else{
								String includeurls = (String)projgoalrow.get(PROJECT_GOAL.INCLUDE_URLS);
								JSONArray urls = null;
								
								if(includeurls!=null){
									urls = new JSONArray(includeurls);
								}
								
								if(urls == null || urls.length() == 0){
									urls = new JSONArray();
									if(goalurl!=null && !goalurl.isEmpty()){
										urls.put(new JSONObject().put(ProjectJSONConstants.VALUE, goalurl).put(ProjectJSONConstants.MATCH_TYPE, MatchType.SIMPLE_MATCH.getMatchTypeId()));		
									}
								}
								goalData.put(GoalConstants.GOAL_URL, urls);
								String excludeurls = (String)projgoalrow.get(PROJECT_GOAL.EXCLUDE_URLS);
								if(excludeurls!=null){
									goalData.put(ProjectJSONConstants.EXCLUDE_URLS, new JSONArray(excludeurls));
								}else{
									goalData.put(ProjectJSONConstants.EXCLUDE_URLS, new JSONArray());
								}
							}
						}

					}
				}
				if(goaldobj.containsTable(PAGE_VISIT_GOAL.TABLE)) {
					Criteria c1 = new Criteria(new Column(PAGE_VISIT_GOAL.TABLE, PAGE_VISIT_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
					Iterator iter = goaldobj.getRows(PAGE_VISIT_GOAL.TABLE, c1);
					JSONArray url = new JSONArray();
					while(iter.hasNext()) {
						Row rw = (Row)iter.next();
						JSONObject urlObj = new JSONObject();
						urlObj.put(GoalConstants.VALUE, (String)rw.get(PAGE_VISIT_GOAL.PAGE_URL));
						urlObj.put(GoalConstants.MATCH_TYPE, (Integer)rw.get(PAGE_VISIT_GOAL.MATCH_TYPE)+"");
						url.put(urlObj);
					}
					if(url.length() > 0) {								
						goalData.put(GoalConstants.URL, url);
					}
				}
				if(goaldobj.containsTable(LINK_CLICK_GOAL.TABLE)) {
					Criteria c1 = new Criteria(new Column(LINK_CLICK_GOAL.TABLE, LINK_CLICK_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
					Row rw = goaldobj.getRow(LINK_CLICK_GOAL.TABLE, c1);
					if(rw!=null) {								
						JSONArray url = new JSONArray();
						JSONObject urlObj = new JSONObject();
						urlObj.put(GoalConstants.VALUE, (String)rw.get(LINK_CLICK_GOAL.LINK_URL));
						urlObj.put(GoalConstants.MATCH_TYPE, (Integer)rw.get(LINK_CLICK_GOAL.MATCH_TYPE)+"");
						url.put(urlObj);
						goalData.put(GoalConstants.URL, url);
					}
				}
				if(goaldobj.containsTable(FORM_SUBMIT_GOAL.TABLE)) {
					Criteria c1 = new Criteria(new Column(FORM_SUBMIT_GOAL.TABLE, FORM_SUBMIT_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
					Row rw = goaldobj.getRow(FORM_SUBMIT_GOAL.TABLE, c1);
					if(rw!=null) {								
						JSONArray url = new JSONArray();
						JSONObject urlObj = new JSONObject();
						urlObj.put(GoalConstants.VALUE, (String)rw.get(FORM_SUBMIT_GOAL.SUBMIT_URL));
						urlObj.put(GoalConstants.MATCH_TYPE, (Integer)rw.get(FORM_SUBMIT_GOAL.MATCH_TYPE)+"");
						url.put(urlObj);
						goalData.put(GoalConstants.URL, url);
					}
				} 
				if(goaldobj.containsTable(CUSTOM_EVENT_GOAL.TABLE)) {
					Criteria c1 = new Criteria(new Column(CUSTOM_EVENT_GOAL.TABLE, CUSTOM_EVENT_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
					Row cerow = goaldobj.getRow(CUSTOM_EVENT_GOAL.TABLE, c1);
					
					try {
						Long eventId = (Long) cerow.get(CUSTOM_EVENT_GOAL.EVENT_ID);
						Criteria customEventCriteria = new Criteria(new Column(EVENTS.TABLE, EVENTS.EVENT_ID), eventId, QueryConstants.EQUAL);
						Row erow = eventdobj.getRow(EVENTS.TABLE, customEventCriteria); 
						String eventName = (String)erow.get(EVENTS.EVENT_NAME);
						goalData.put(GoalConstants.CUSTOM_EVENT_NAME, eventName);
						
					} catch (Exception e) {
						e.printStackTrace();
					}
					
				} 
				if(goaldobj.containsTable(ELEMENT_CLICK_GOAL.TABLE)) {
					Criteria c1 = new Criteria(new Column(ELEMENT_CLICK_GOAL.TABLE, ELEMENT_CLICK_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
					Row rw = goaldobj.getRow(ELEMENT_CLICK_GOAL.TABLE, c1);
					if(rw!=null) {
						goalData.put(GoalConstants.ELEMENT_CSS_SELECTOR, StringEscapeUtils.unescapeHtml4((String)rw.get(ELEMENT_CLICK_GOAL.ELEMENT_CSS_SELECTOR)));								
					}
				}
				if(goaldobj.containsTable(TIME_SPENT_GOAL.TABLE)) {
					Criteria c1 = new Criteria(new Column(TIME_SPENT_GOAL.TABLE, TIME_SPENT_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
					Row rw = goaldobj.getRow(TIME_SPENT_GOAL.TABLE, c1);
					if(rw!=null) {
						goalData.put(GoalConstants.TIME_THRESHOLD, (Long)rw.get(TIME_SPENT_GOAL.TIME_THRESHOLD));								
					}
				}
				
//				if(dobj.containsTable(ELEMENT_CLICK_VARIATION.TABLE)) {
//					Criteria c1 = new Criteria(new Column(ELEMENT_CLICK_GOAL.TABLE, ELEMENT_CLICK_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
//					Row rw = dobj.getRow(ELEMENT_CLICK_VARIATION.TABLE, c1);
//					if(rw!=null) {								
//						goalData.put(GoalConstants.ELEMENT_CSS_SELECTOR, (String)rw.get(ELEMENT_CLICK_VARIATION.ELEMENT_CSS_SELECTOR));
//						goalData.put(GoalConstants.VARIATION_ID, (Long)rw.get(ELEMENT_CLICK_VARIATION.ELEMENT_CLICK_VARIATION_ID)+"");
//					}
//				}
//					goalData.put(ProjectJSONConstants.EXPERIMENT, new JSONArray().put(experimentKey));
				goalJSON.put(linkname, goalData);
			
				Criteria goalExpCri = new Criteria(new Column(EXPERIMENT_GOAL.TABLE,EXPERIMENT_GOAL.GOAL_ID),goalId,QueryConstants.EQUAL);
				Iterator<?> goalExpItr = expdobj.getRows(EXPERIMENT_GOAL.TABLE,goalExpCri);
				while(goalExpItr.hasNext()){
					Row row = (Row)goalExpItr.next();
					Long experimentId =  (Long)row.get(EXPERIMENT_GOAL.EXPERIMENT_ID);
					String experimentKey = getExperimentKey(expdobj, experimentId);
					addEntityRelationToExpObj(experiments, experimentKey, ProjectJSONConstants.GOAL, linkname);
					
				}
				} catch(Exception e) {
					LOGGER.log(Level.SEVERE, "Exception occured", e);
				}
			}
			
		}
		
		return goalJSON;

	}

	public static String getExperimentKey(DataObject dobj, Long experimentId) throws DataAccessException {
		if(dobj.containsTable(EXPERIMENT.TABLE)) {
			Criteria c = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
			Row row = dobj.getRow(EXPERIMENT.TABLE, c);
			if(row!=null) {
				return (String)row.get(EXPERIMENT.EXPERIMENT_KEY);
			}
		}
		return null;
	}
	
	
	public static JSONObject addEntityRelationToExpObj(JSONObject experiments, String experimentKey, String entityKey, String entityLinkname) throws JSONException {
		if(experiments!=null && experiments.has(experimentKey)) {
			JSONObject eachExperiment = experiments.getJSONObject(experimentKey);			
			if(eachExperiment.has(entityKey)) {
				addKeyToArray(eachExperiment.getJSONArray(entityKey), entityLinkname);
			} else {
				eachExperiment.put(entityKey, new JSONArray().put(entityLinkname));
			}
			return eachExperiment;
		}
		return null;
	}
	
	public static JSONObject constructAudienceJSON(DataObject dobj, JSONObject experiments) throws Exception {
		JSONObject audienceJSON = new JSONObject();
		if(dobj.containsTable(EXPERIMENT_AUDIENCE.TABLE)) {
			Iterator it = (Iterator)dobj.getRows(EXPERIMENT_AUDIENCE.TABLE);
			while(it.hasNext()) {
				Row row = (Row)it.next();
				Long audienceId = (Long)row.get(EXPERIMENT_AUDIENCE.AUDIENCE_ID);
				Long experimentId = (Long)row.get(EXPERIMENT_AUDIENCE.EXPERIMENT_ID);
				
				String experimentKey = getExperimentKey(dobj, experimentId);
				
				Criteria c = new Criteria(new Column(AUDIENCE.TABLE, AUDIENCE.AUDIENCE_ID), audienceId, QueryConstants.EQUAL);
				//Row audienceRow = dobj.getRow(AUDIENCE.TABLE, c);
				DataObject dobj1 = ZABModel.getRow(AUDIENCE.TABLE, c);
				if(dobj1.containsTable(AUDIENCE.TABLE)) {
					Row audienceRow = dobj1.getFirstRow(AUDIENCE.TABLE);
					String audienceLinkname = (String)audienceRow.get(AUDIENCE.AUDIENCE_LINK_NAME);
					Boolean audienceIsCountry = (Boolean)audienceRow.get(AUDIENCE.AUDIENCE_IS_COUNTRY);
					
					JSONObject eachExperiment = addEntityRelationToExpObj(experiments, experimentKey, ProjectJSONConstants.AUDIENCE, audienceLinkname);
					
					if(eachExperiment!=null && audienceIsCountry!=null) {
						eachExperiment.put(ProjectJSONConstants.COUNTRY_REQUIRED, audienceIsCountry);
					}
					
					if(audienceJSON.has(audienceLinkname)) {
						JSONObject audienceData = audienceJSON.getJSONObject(audienceLinkname);
//					addExperimentKeyToArray(audienceData.getJSONArray(ProjectJSONConstants.EXPERIMENT), experimentKey);
					} else {
						JSONObject audienceData = new JSONObject();
						audienceData.put(ProjectJSONConstants.AUDIENCE_NAME, (String)audienceRow.get(AUDIENCE.AUDIENCE_NAME));
						try {
							String audienceCondition = (String)audienceRow.get(AUDIENCE.AUDIENCE_CONDITION_JSON);
							audienceData.put(ProjectJSONConstants.AUDIENCE_CONDITION, new JSONObject(audienceCondition));
						} catch (JSONException e) {
							e.printStackTrace();
						}
//					audienceData.put(ProjectJSONConstants.EXPERIMENT, new JSONArray().put(experimentKey));
						audienceJSON.put(audienceLinkname, audienceData);
					}
					
				}
			}
		}
		return audienceJSON;
	}
	
	private static void addKeyToArray(JSONArray array, String experimentLinkname) throws JSONException {
		
		if(array!=null) {
			Boolean doesKeyExists = false;
			for(int i=0; i<array.length(); i++) {
				String key = array.getString(i);
				if(key.equals(experimentLinkname)) {
					doesKeyExists = true;
					break;
				}
			}
			if(!doesKeyExists) {
				array.put(experimentLinkname);
			}
		}
	}
	
	public static JSONObject constructDynamicAttributeJSON(DataObject dobj, JSONObject experiments) throws Exception {
		JSONObject dynamicAttributeJSON = new JSONObject();
		if(dobj.containsTable(EXPERIMENT_DYNAMIC_ATTR.TABLE)) {
			Iterator it = (Iterator)dobj.getRows(EXPERIMENT_DYNAMIC_ATTR.TABLE);
			while(it.hasNext()) {
				Row row = (Row)it.next();
				Long dynId = (Long)row.get(EXPERIMENT_DYNAMIC_ATTR.DYNAMIC_ATTRIBUTE_ID);
				Long experimentId = (Long)row.get(EXPERIMENT_DYNAMIC_ATTR.EXPERIMENT_ID);
				Criteria c = new Criteria(new Column(DYNAMIC_ATTRIBUTES.TABLE, DYNAMIC_ATTRIBUTES.DYNAMIC_ATTRIBUTE_ID), dynId, QueryConstants.EQUAL);
				Row dynamicAttrsRow = dobj.getRow(DYNAMIC_ATTRIBUTES.TABLE, c);
				Criteria c2 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
				Row erow = dobj.getRow(EXPERIMENT.TABLE, c2);
				String dynAttrLinkname = (String)dynamicAttrsRow.get(DYNAMIC_ATTRIBUTES.ATTRIBUTE_LINK_NAME);
				String experimentKey = (String)erow.get(EXPERIMENT.EXPERIMENT_KEY);
				
				addEntityRelationToExpObj(experiments, experimentKey, ProjectJSONConstants.DYNAMIC_ATTRIBUTE, dynAttrLinkname);
				if(!dynamicAttributeJSON.has(dynAttrLinkname)) {
//					JSONObject audienceData = dynamicAttributeJSON.getJSONObject(dynAttrLinkname);
//					addKeyToArray(audienceData.getJSONArray(ProjectJSONConstants.EXPERIMENT), experimentKey);
//				} else {
					JSONObject dynamicAttributeData = new JSONObject();
					dynamicAttributeData.put(DimensionConstants.ATTRIBUTE_TYPE, (Integer)dynamicAttrsRow.get(DYNAMIC_ATTRIBUTES.ATTRIBUTE_TYPE));
					dynamicAttributeData.put(DimensionConstants.ATTRIBUTE_NAME, (String)dynamicAttrsRow.get(DYNAMIC_ATTRIBUTES.ATTRIBUTE_NAME));
					dynamicAttributeData.put(ProjectJSONConstants.EXPERIMENT, new JSONArray().put(experimentKey));
					dynamicAttributeJSON.put(dynAttrLinkname, dynamicAttributeData);
				}
				
			}
		}
		return dynamicAttributeJSON;
	}
	
	private static void setIntegrationsData(DataObject dobj, JSONObject experiments) throws Exception {
		if(dobj.containsTable(EXPERIMENT_PROJECT_INTEGRATION.TABLE)) {
			Iterator it = (Iterator)dobj.getRows(EXPERIMENT_PROJECT_INTEGRATION.TABLE);
			while(it.hasNext()) {
				Row row = (Row)it.next();
				Long exp_proj_integration_id = (Long)row.get(EXPERIMENT_PROJECT_INTEGRATION.EXPERIMENT_PROJECT_INTEGRATION_ID);
				Long experimentId = (Long)row.get(EXPERIMENT_PROJECT_INTEGRATION.EXPERIMENT_ID);
				Long pintegId = (Long)row.get(EXPERIMENT_PROJECT_INTEGRATION.PROJECT_INTEGRATION_ID);
				String ekey = getExperimentKey(dobj, experimentId);
				JSONObject experiment = experiments.getJSONObject(ekey);
				if(experiment!=null) {					
					Criteria c = new Criteria(new Column(PROJECT_INTEGRATION.TABLE, PROJECT_INTEGRATION.PROJECT_INTEGRATION_ID), pintegId, QueryConstants.EQUAL);
					Row integRow = dobj.getRow(PROJECT_INTEGRATION.TABLE, c);
					if(integRow!=null) {
						Integer iid = (Integer) integRow.get(PROJECT_INTEGRATION.INTEGRATION_ID);
						
						for(Integ integ: Integ.values()) {
							if(integ.getIntegrationId().equals(iid) ){
								String name = (String) integ.getDisplayName();
								JSONObject ejson = new JSONObject();
								ejson.put(IntegrationConstants.EXPERIMENT_PROJECT_INTEGRATION_ID, exp_proj_integration_id);
								if(iid.equals(1)) {										
									GoogleAnalytics googleAnalytics = GoogleAnalytics.getGoogleAnalyticsFromExpProjIntegrationId(dobj, exp_proj_integration_id);
									ejson.put(IntegrationConstants.CUSTOM_DIMENSION, googleAnalytics.getCustomDimension());
									//ejson.put(IntegrationConstants.CUSTOM_TRACKER, googleAnalytics.getCustomTracker());
								}
								if(experiment.has(ProjectJSONConstants.INTEGRATIONS)) {
									experiment.getJSONObject(ProjectJSONConstants.INTEGRATIONS).put(name, ejson);
								} else {
									experiment.put(ProjectJSONConstants.INTEGRATIONS, new JSONObject().put(name, ejson));
								}
							}
						}
					}
				}
				
			}
		}
	}
	
	private static JSONObject constructProjectJSON(Criteria c, String portalName) throws Exception {
		JSONObject project = new JSONObject();
		JSONObject experimentObject = new JSONObject();
		project = new JSONObject( "{\""+ProjectJSONConstants.PORTAL_NAME+"\":\""+portalName+"\"}");
		DataObject dobj = ZABModel.getPersonality(ProjectConstants.PERSONALITY_NAME, c);
		if(dobj.containsTable(PROJECT.TABLE))
		{
			Row projectRow = dobj.getFirstRow(PROJECT.TABLE);
			Boolean scriptIncludedWarning = (Boolean)projectRow.get(PROJECT.SCRIPT_INCLUDED_WARNING);
			project.put(ProjectConstants.SCRIPT_INCLUDED_WARNING, scriptIncludedWarning);
		}
		if(dobj.containsTable(EXPERIMENT.TABLE)) {
			experimentObject = constructExperimentJSON(dobj);
			
			setIntegrationsData(dobj, experimentObject);
			
			project.put(ProjectJSONConstants.EXPERIMENT, experimentObject);
			project.put(ProjectJSONConstants.AUDIENCE, constructAudienceJSON(dobj, experimentObject));
			project.put(ProjectJSONConstants.DYNAMIC_ATTRIBUTE, constructDynamicAttributeJSON(dobj, experimentObject));
			
		
		}
		try{
			
			Long projId = (Long)c.getRightCriteria().getValue();
			Criteria privacyCri = new Criteria(new Column(PRIVACY_CONSENT.TABLE, PRIVACY_CONSENT.PROJECT_ID), projId, QueryConstants.EQUAL);
			DataObject privacydobj = ZABModel.getPersonality(ProjectConstants.PERSONALITY_NAME, privacyCri);
			if(privacydobj.containsTable(PRIVACY_CONSENT.TABLE)) {
				Row privacyRow = privacydobj.getRow(PRIVACY_CONSENT.TABLE,privacyCri);
				project.put(PrivacyConstants.PRIVACY_VALUE, (Integer)privacyRow.get(PRIVACY_CONSENT.PRIVACY_VALUE));
			}
			Project pro =  Project.getProjectByProjectId(projId);
			String projKey = pro.getProjectKey();
			if(pro.getProjectStatus().equals(ProjectStatus.ARCHIVE.getStatusNumber())){
				project.put(ProjectJSONConstants.EVENTS,new JSONArray() );
				project.put(ProjectJSONConstants.GOAL,new JSONArray() );
				
			}else{
				project.put(ProjectJSONConstants.EVENTS, constructEventsJSON(projId));
				project.put(ProjectJSONConstants.GOAL, constructGoalJSON(projId , dobj, experimentObject));
				
			}
			project.put(ProjectJSONConstants.PROJECT_KEY, projKey);
			project.put(ProjectJSONConstants.IS_LANDING_PAGE, Boolean.FALSE);
			
			
		}catch(Exception eventsExc){
			LOGGER.log(Level.SEVERE, eventsExc.getMessage(),eventsExc);
		}
	
		return project;
	}
	
	public static JSONArray constructEventsJSON(Long projId) throws Exception{
		
		JSONArray array = new JSONArray();
		Criteria c = new Criteria(new Column(EVENTS.TABLE,EVENTS.PROJECT_ID),projId,QueryConstants.EQUAL);
		DataObject dobj = ZABModel.getRow(EVENTS.TABLE, c);
		if(dobj.containsTable(EVENTS.TABLE)){
			Iterator<?> itr = dobj.getRows(EVENTS.TABLE);
			while(itr.hasNext()){
				Row row  = (Row)itr.next();
				String eventname = (String)row.get(EVENTS.EVENT_NAME);
				array.put(eventname);
			}
		}
		return array;
		
	}
	public static JSONObject constructProjectJSON(String linkName, String portalName) throws Exception {
		Criteria c = new Criteria(new Column(PROJECT.TABLE, PROJECT.PROJECT_LINK_NAME), linkName, QueryConstants.EQUAL);
		Criteria c1 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.IS_ACTIVE), Boolean.TRUE, QueryConstants.EQUAL);
		Criteria c2 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_STATUS), ExperimentStatus.RUNNING.getStatusCode(), QueryConstants.EQUAL);
		Criteria c3 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_STATUS), ExperimentStatus.PAUSED.getStatusCode(), QueryConstants.EQUAL);
		return constructProjectJSON(c1.and(c2.or(c3)).and(c), portalName);
	}
	
	public static JSONObject constructProjectJSON(Long projectId, String portalName) throws Exception {
		Criteria c = new Criteria(new Column(PROJECT.TABLE, PROJECT.PROJECT_ID), projectId, QueryConstants.EQUAL);
		Criteria c1 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.IS_ACTIVE), Boolean.TRUE, QueryConstants.EQUAL);
		Criteria c2 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_STATUS), ExperimentStatus.RUNNING.getStatusCode(), QueryConstants.EQUAL);
		Criteria c3 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_STATUS), ExperimentStatus.PAUSED.getStatusCode(), QueryConstants.EQUAL);
		return constructProjectJSON(c1.and(c2.or(c3)).and(c), portalName);
	}
	
}
