//$Id$
package com.zoho.abtest.project;

public class ProjectJSONConstants {
	
	public static final String EXPERIMENT_ID = "expid"; //No I18N
	
	public static final String VALUE = "value"; //No I18N
	
	public static final String IS_ORIGINAL = "is_original"; //No I18N
	
	public static final String KEY = "key"; //No I18N
	
	public static final String NAME = "name"; //No I18N
	
	public static final String STATUS = "status"; //No I18N
	
	public static final String TYPE = "type"; //No I18N
	
	public static final String SESSSION_TIME = "session_time"; //No I18N
	
	public static final String STEPS = "steps"; //No I18N
	
	public static final String STEP_ORDER = "step_order"; //No I18N
	
	public static final String CUSTOM_STEP = "custom_step"; //No I18N
	
	public static final String PREVIOUS_STEP_KEY = "previous_step_key"; //No I18N
	
	public static final String ALLOTED_PERCENTAGE = "allotedPercentage"; //No I18N
	
	public static final String VARIATION_CHANGES = "variation_changes"; //No I18N
	
	public static final String VARIATION_CSS_CHANGES = "variation_css_changes"; //No I18N
	
	public static final String SPACEID = "spaceid"; //No I18N
	
	public static final String PORTAL_NAME = "portal_name"; //No I18N
	
	public static final String PERMITTED_TRAFFIC = "permittedTrafic"; //No I18N
	
	public static final String URL = "url"; //No I18N
	
	public static final String URLS = "urls"; //No I18N
	
	public static final String ID = "id"; //No I18N
	
	public static final String LINKNAME = "linkname"; //No I18N
	
	public static final String VARIATIONS = "variations"; //No I18N
	
	public static final String AUDIENCE = "audience"; //No I18N
	
	public static final String GOAL = "goal"; //No I18N
	
	public static final String DYNAMIC_ATTRIBUTE = "dynamicattribute"; //No I18N
	
	public static final String EVENTS = "events"; //No I18N
	
	public static final String IS_LANDING_PAGE = "is_landing_page"; //No I18N
	
	
	public static final String PROJECT_KEY = "project_key"; //No I18N
	
	public static final String EXPERIMENT = "experiment"; //No I18N
	
	public static final String AUDIENCE_NAME = "audience_name"; //No I18N
	
	public static final String AUDIENCE_CONDITION = "audience_condition"; //No I18N
	
	public static final String PRIMARY_GOAL = "primary_goal"; //No I18N
	
	public static final String PROJECT_JSON_TABLE = "PROJECT_JSON"; //No I18N
	
	public static final String PROJECT_ID = "PROJECT_ID"; //No I18N
	
	public static final String PROJECT_JSON_COL = "PROJECT_JSON"; //No I18N
	
	public static final String COUNTRY_REQUIRED = "country_required"; //No I18N
	
	public static final String MATCH_TYPE = "match_type"; //No I18N
	
	public static final String INTEGRATIONS = "integrations"; //No I18N
	
	public static final String EXCLUDE_URLS = "exclude_urls"; //No I18N
	
	public static final String MASK_ELEMENTS = "mask_elements"; //No I18N
	
	public static final String INCLUDE_URLS = "include_urls"; //No I18N
	
	public static final String FORM_DETAILS="forms"; //No I18N
	
	public static final String FORM_FIELD_DETAILS="fields"; //No I18N
	public static final String SCRIPT_URL = "script_url"; 		//No I18N
	
	public static final String IS_SYNCHRONOUS = "is_synchronous"; 		//No I18N
	
	public static final String HEATMAP = "heatmap"; 		//No I18N
	
	public static final String REDIRECT_PARAMS = "redirect_params"; 		//No I18N
	
	public static final String GLOBAL_JS = "global_js"; 		//No I18N
	public static final String GLOBAL_CSS = "global_css"; 		//No I18N
	
	public static final String ACTIVATION_MODE = "activation_mode"; 		//No I18N
	
	public static final String ACTIVATION_CONDITION = "activation_condition"; 		//No I18N
	
	
	
}
