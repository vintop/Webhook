//$Id$
package com.zoho.abtest.project;

import java.io.Serializable;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;

import com.adventnet.iam.IAMUtil;
import com.zoho.abtest.audience.Audience;
import com.zoho.abtest.audience.ExperimentAudience;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.customevent.CustomEvent;
import com.zoho.abtest.dimension.DynamicAttributes;
import com.zoho.abtest.dimension.ExperimentDynamicAttribute;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.goal.ExperimentGoal;
import com.zoho.abtest.goal.Goal;
import com.zoho.abtest.portal.PortalAction;
import com.zoho.abtest.project.ProjectTreeEventConstants.Module;
import com.zoho.abtest.project.ProjectTreeEventConstants.OperationType;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.abtest.variation.Variation;

public class ProjectTreeEventWrapper implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = Logger.getLogger(ProjectTreeEventWrapper.class.getName());

	private ZABModel model;
	
	private OperationType type;
	
	private Object customObject;
	
	private Module module;
	
	private String dbspace;
	
	private String zsoid;
	
	private Long userId;
	
	private String portalName;
	
	private HashMap<String, String> changeSets = new HashMap<String, String>();

	public String getPortalName() {
		return portalName;
	}

	public void setPortalName(String portalName) {
		this.portalName = portalName;
	}

	public ProjectTreeEventWrapper() 
	{
		if(IAMUtil.getCurrentUser() != null)
		{
			userId = IAMUtil.getCurrentUser().getZUID();
		}
	}

	public HashMap<String, String> getChangeSets() {
		return changeSets;
	}

	public void setChangeSets(HashMap<String, String> changeSets) {
		this.changeSets = changeSets;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public ZABModel getModel() {
		return model;
	}

	public void setModel(ZABModel model) {
		setModule(model);
		this.model = model;
	}

	public OperationType getType() {
		return type;
	}

	public void setType(OperationType type) {
		this.type = type;
	}

	public Module getModule() {
		return module;
	}

	public Object getCustomObject() {
		return customObject;
	}

	public void setCustomObject(Object customObject) {
		this.customObject = customObject;
	}
	
	public String getZsoid() {
		return zsoid;
	}

	public void setZsoid(String zsoid) {
		this.zsoid = zsoid;
	}

	public void setModule(ZABModel model) {
		if(model instanceof Experiment) {
			module = Module.EXPERIMENT;
		} else if(model instanceof Project) {
			module = Module.PROJECT;
		} else if(model instanceof ExperimentGoal) {
			module = Module.EXPERIMENT_GOAL;
		} else if(model instanceof Variation) {
			module = Module.VARIATION;
		} else if(model instanceof Goal) {
			module = Module.GOAL;
		} else if(model instanceof ExperimentGoal) {
			module = Module.EXPERIMENT_GOAL;
		} else if(model instanceof Audience) {
			module = Module.AUDIENCE;
		} else if(model instanceof ExperimentAudience) {
			module = Module.EXPERIMENT_AUDIENCE;
		} else if(model instanceof ExperimentDynamicAttribute) {
			module = Module.EXPERIMENT_DYNAMIC_ATTRIBUTE;
		} else if(model instanceof DynamicAttributes){
			module = Module.DYNAMIC_ATTRIBUTE;
		} else if(model instanceof CustomEvent){
			module = Module.CUSTOM_EVENT;
		}
	}
	
	public void setModule(Module module) {
		this.module = module;
	}

	public String getDbspace() {
		return dbspace;
	}

	public void setDbspace(String dbspace) {
		String portaldomain = null;
		if(IAMUtil.getCurrentServiceOrg() != null)
		{
			portaldomain = IAMUtil.getCurrentServiceOrg().getDomains().get(0).getDomain();
		}
		else if(StringUtils.isNotEmpty(ZABUtil.getPortaldomain()))
		{
			portaldomain = ZABUtil.getPortaldomain();
		}
		else
		{
			try
			{
				portaldomain = ZABServiceOrgUtil.getServiceOrg(dbspace).getDomains().get(0).getDomain();
			}
			catch(Exception ex)
			{
				LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			}
		}
		this.setPortalName(portaldomain);
		this.dbspace = dbspace;
	}

	@Override
	public String toString() {
		return "ProjectTreeEventWrapper [model=" + model + ", type=" + type + ", customObject=" + customObject + ", module=" + module + ", dbspace=" + dbspace + ", userId=" + userId + "]"; //No I18N
	}
	
}
