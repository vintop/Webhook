//$Id$
package com.zoho.abtest.project;

import java.math.BigInteger;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.zoho.abtest.PROJECT_IPFILTER;
import com.zoho.abtest.common.ZABColumn;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.project.ProjectConstants.IPMatchType;

public class ProjectIPFilter extends ZABModel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = Logger.getLogger(ProjectIPFilter.class.getName());

	@ZABColumn(name = PROJECT_IPFILTER.IP_FILTER_NAME)
	private String displayName;
	
	@ZABColumn(name = PROJECT_IPFILTER.IP_FILTER_MATCH_TYPE)
	private Integer matchType;
	
	@ZABColumn(name = PROJECT_IPFILTER.IP_FILTER_VALUE)
	private String value;
	
	private String fromValue;
	
	private String toValue;

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public Integer getMatchType() {
		return matchType;
	}

	public void setMatchType(Integer matchType) {
		this.matchType = matchType;
		setFromToValues();
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
		setFromToValues();
	}

	public String getFromValue() {
		return fromValue;
	}

	public void setFromValue(String fromValue) {
		this.fromValue = fromValue;
	}

	public String getToValue() {
		return toValue;
	}

	public void setToValue(String toValue) {
		this.toValue = toValue;
	}
	
	public void setFromToValues() {
		if(this.matchType !=null && this.value != null) {
			if(this.matchType.equals(IPMatchType.RANGE.getTypeNumber())) {
				String[] values = this.value.split(",");
				if(values.length == 2) {					
					this.setFromValue(values[0]);
					this.setToValue(values[1]);
					this.setValue(null);
				}
			}
		}
	}
	
	public static Boolean validateIP(String ipAddress, Long projectId) {
		try {			
			Criteria c = new Criteria(new Column(PROJECT_IPFILTER.TABLE, PROJECT_IPFILTER.PROJECT_ID), projectId, QueryConstants.EQUAL);
			DataObject dobj = getRow(PROJECT_IPFILTER.TABLE, c);
			ArrayList<ProjectIPFilter> ipFilters = getModelsFromDobj(dobj, PROJECT_IPFILTER.TABLE, ProjectIPFilter.class, Boolean.TRUE);
			if(ipFilters.size() == 0) {
				return false;
			} else {
				for(ProjectIPFilter filter:ipFilters) {
					IPMatchType matchType = IPMatchType.getIPMatchTypeByNumber(filter.getMatchType());
					switch(matchType) {
					case EQUALS:
//						LOGGER.log(Level.INFO, "MT:EQ: Receiving IP:"+ipAddress+", Compare IP:"+filter.getValue());
						if(ipAddress.trim().equals(filter.getValue())) {
							return true;
						}
						break;
					case RANGE:
//						LOGGER.log(Level.INFO, "MT:RAN: Receiving IP:"+ipAddress+", Compare IP:"+filter.getValue());
						if(IPIsInRange(filter.getFromValue(), filter.getToValue(), ipAddress)) {
							return true;
						}
						break;
					case REGEX:
//						LOGGER.log(Level.INFO, "MT:REG: Receiving IP:"+ipAddress+", Compare IP:"+filter.getValue());
						if(validateIPWithRegex(ipAddress, filter.getValue())) {
							return true;
						}
						break;
					}
				}
				return false;
			}
			
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Exception occured while IPFiltering", e);
			return false;
		}
	}
	
	public static boolean IPIsInRange(String startAddress, String endAddress, String address) throws UnknownHostException {
		InetAddress startInet = InetAddress.getByName(startAddress);
		InetAddress endInet = InetAddress.getByName(endAddress);
		InetAddress addressInet = InetAddress.getByName(address);
		
        BigInteger startBI = new BigInteger(1, startInet.getAddress());
        BigInteger endBI = new BigInteger(1, endInet.getAddress());
        BigInteger addressBI = new BigInteger(1, addressInet.getAddress());
        int startComp =startBI.compareTo(addressBI);
        int endComp = addressBI.compareTo(endBI);
        return (startComp == -1 || startComp == 0) && (endComp == -1 || endComp == 0);
	}
	
	public static boolean validateIPWithRegex(String address, String regex) throws UnknownHostException {
		Pattern p = Pattern.compile(regex);
        return p.matcher(address).matches();
	}
}
