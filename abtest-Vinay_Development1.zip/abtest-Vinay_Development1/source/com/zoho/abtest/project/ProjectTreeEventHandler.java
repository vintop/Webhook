//$Id$
package com.zoho.abtest.project;

import static com.zoho.abtest.project.ProjectTreeEventConstants.OperationType.CREATE;
import static com.zoho.abtest.project.ProjectTreeEventConstants.OperationType.DELETE;
import static com.zoho.abtest.project.ProjectTreeEventConstants.OperationType.UPDATE;

import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.json.JSONObject;

import com.adventnet.mfw.bean.BeanUtil;
import com.zoho.abtest.audience.Audience;
import com.zoho.abtest.audience.ExperimentAudience;
import com.zoho.abtest.audience.ProjectAudience;
import com.zoho.abtest.cdn.ZABCDN;
import com.zoho.abtest.customevent.CustomEvent;
import com.zoho.abtest.dfs.DFS;
import com.zoho.abtest.dfs.DFSFileInfo;
import com.zoho.abtest.dimension.DynamicAttributes;
import com.zoho.abtest.dimension.ExperimentDynamicAttribute;
import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.experiment.ABSplitExperiment;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentStatus;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentType;
import com.zoho.abtest.forms.FormAnalyticsExperiment;
import com.zoho.abtest.funnel.FunnelAnalysis;
import com.zoho.abtest.funnel.FunnelAnalysisConstants.FunnelMatchType;
import com.zoho.abtest.funnel.FunnelStep;
import com.zoho.abtest.goal.ExperimentGoal;
import com.zoho.abtest.goal.Goal;
import com.zoho.abtest.heatmaps.HeatmapExperiment;
import com.zoho.abtest.integration.Integration;
import com.zoho.abtest.license.PortalLicenseMapping;
import com.zoho.abtest.privacyconsent.Privacy;
import com.zoho.abtest.project.ProjectTreeEventConstants.OperationType;
import com.zoho.abtest.sessionrecording.SessionPage;
import com.zoho.abtest.sessionrecording.SessionRecording;
import com.zoho.abtest.snapshot.ImageGenerator;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.abtest.variation.Variation;

public class ProjectTreeEventHandler {
	
	private static final Logger	LOGGER = Logger.getLogger(ProjectTreeEventHandler.class.getName());
	
	public static void deleteCascadeExperiment(Experiment experiment, String portalName) throws Exception {
		//TODO: delete screen shot.
		ExperimentType type = experiment.getExperimentTypeEnum();
		switch (type) {
		case ABTEST:
		case SPLITURL:
		case FUNNEL:
		case HEATMAP:
		case FORMANALYTICS:
			 ElasticSearchUtil.deleteExperimentData(experiment.getExperimentId(), portalName);
			 break;
		case SESSION_RECORDING:
			ElasticSearchUtil.deleteExperimentData(experiment.getExperimentId(), portalName);
			Long zsoid = ZABServiceOrgUtil.getZSOIDFromDomain(portalName);
			String path = SessionPage.getDFSExperimentBasePath(zsoid.toString(), experiment.getExperimentKey());
			DFS.deleteDirectoryFromDFS(path, zsoid.toString());
		default:
			break;
		}
	}
	
	public static void deleteCascadeProject(Project project, String portalName) throws Exception {
		ZABCDN cdn = (ZABCDN)BeanUtil.lookup("ZABCDN");
		String fileName = "js/" + Project.getAbsoluteScriptUrl(project.getProjectKey(), portalName); //NO I18N
		cdn.deleteFile(fileName);
		//TODO: Handle deleting elastic search documents
		
	}
	
	private static void genetateThumbnail(String experimentKey, long uid, String portalName, String expUrl) throws Exception {
		 
		String smallImgLoc = experimentKey+"-1.png";  //imgfol+experiment.getExperimentKey()+"-1.png"; //NO I18N
		String largeImgLoc = experimentKey+"-2.png";  //imgfol+experiment.getExperimentKey()+"-2.png"; //NO I18N
	 
		DFSFileInfo fileinfo = DFSFileInfo.getDFSFileInfoFromFilepath(smallImgLoc);
		
		if(fileinfo == null){
			ImageGenerator.generateThumbnail(expUrl, 640, 480, uid, smallImgLoc, portalName,null);
			ImageGenerator.generateThumbnail(expUrl, 1280, 960, uid, largeImgLoc, portalName,null);	
		}else{
			ImageGenerator.generateThumbnail(expUrl, 640, 480, uid, smallImgLoc, portalName, fileinfo.getBlockId());
			ImageGenerator.generateThumbnail(expUrl, 1280, 960, uid, largeImgLoc, portalName, fileinfo.getBlockId());	
		}
	}
	
	public static void handleProjectTreeEvent(ProjectTreeEventWrapper event) {
		
		try {	
			Long projectId = null;
			Boolean updateRequired = false;
			String dbspace = event.getDbspace();
			ZABUtil.setDBSpace(dbspace);
			
			Long zsoid = Long.parseLong(dbspace);
			
			try {				
				PortalLicenseMapping lcdetail = PortalLicenseMapping.getPortalLicense(zsoid);
				if(!lcdetail.getIsAppActive()) {
					LOGGER.log(Level.INFO, "As the license is not active, skipping script update::"+event);
					return;
				}
			} catch (Exception e) {
				LOGGER.log(Level.SEVERE, "Exception occured while verifying license"); //NO I18N
			}
			
			switch (event.getModule()) {
			case PROJECT:
				Project project = (Project)event.getModel();
				projectId = project.getProjectId();
				if(event.getType().equals(CREATE)) {
					updateRequired = true;
				}else if (event.getType().equals(UPDATE)) {
					updateRequired = true;
				}
				else if(event.getType().equals(DELETE)) {
					deleteCascadeProject(project, event.getPortalName());
					return;
				}
				break;
			case EXPERIMENT:
				Experiment experiment = (Experiment)event.getModel();
				
				if(experiment instanceof ABSplitExperiment)
				{
					 ABSplitExperiment absplitExperiment = ABSplitExperiment.getABSplitExperimentDetail(experiment.getExperimentLinkname());
					 projectId = absplitExperiment.getProjectId();
					 
					 if(event.getType().equals(CREATE) 
							 || event.getType().equals(ProjectTreeEventConstants.OperationType.UPDATE)){							
						
						String expUrl = absplitExperiment.getExperimentUrl();
						HashMap<String, String> hs = event.getChangeSets();
						
						if(expUrl!=null && !expUrl.isEmpty() 
								&& (event.getType().equals(CREATE) || hs.containsKey(ExperimentConstants.EXPERIMENT_URL))){
							
							long uid = event.getUserId();
							String portnalName = event.getPortalName();
							genetateThumbnail(absplitExperiment.getExperimentKey(),
									uid, portnalName, expUrl);	
							
						}
					}
				} 
				
				if(experiment instanceof FunnelAnalysis)
				{
					FunnelAnalysis fanalysis = FunnelAnalysis.getFunnelAnalysisWithSteps(experiment.getExperimentLinkname());
					if(event.getType().equals(CREATE)){
						if(fanalysis.getSteps() !=null && fanalysis.getSteps().size() > 0) {
							FunnelStep step = fanalysis.getSteps().get(0);
							if (step.getStepMatchType().equals(FunnelMatchType.SIMPLE_MATCH.getMatchTypeId())
									|| step.getStepMatchType().equals(FunnelMatchType.EXACT_MATCH.getMatchTypeId())) {
								String expUrl = step.getStepValue();
								long uid = event.getUserId();
								String portnalName = event.getPortalName();
								genetateThumbnail(
										fanalysis.getExperimentKey(),
										uid, portnalName, expUrl);
							}
						}
					}
				}
				
				if(experiment instanceof SessionRecording)
				{
//					SessionRecording sessionRecording = SessionRecording.getSessionRecordingWithLinkname(experiment.getExperimentLinkname());
//					if(event.getType().equals(CREATE)){
//							if (sessionRecording.getMatchType().equals(FunnelMatchType.SIMPLE_MATCH.getMatchTypeId())
//									|| sessionRecording.getMatchType().equals(FunnelMatchType.EXACT_MATCH.getMatchTypeId())) {
//								String expUrl = sessionRecording.getExperimentUrl();
//								long uid = event.getUserId();
//								String portnalName = event.getPortalName();
//								genetateThumbnail(
//										sessionRecording.getExperimentKey(),
//										uid, portnalName, expUrl);
//							}
//						}
				}
				
				if(experiment instanceof HeatmapExperiment)
				{
					HeatmapExperiment heatmapExperiment = HeatmapExperiment.getHeatmapExperimentDetails(experiment.getExperimentLinkname());
					projectId = heatmapExperiment.getProjectId();
					 
					if(event.getType().equals(CREATE) 
							|| event.getType().equals(ProjectTreeEventConstants.OperationType.UPDATE)){
						
						String expUrl = heatmapExperiment.getExperimentUrl();
						HashMap<String, String> hs = event.getChangeSets();
						
						if(expUrl!=null && !expUrl.isEmpty() 
								&& (event.getType().equals(CREATE) || hs.containsKey(ExperimentConstants.EXPERIMENT_URL))){
							
							long uid = event.getUserId();
							String portnalName = event.getPortalName();
							genetateThumbnail(heatmapExperiment.getExperimentKey(),
									uid, portnalName, expUrl);	
							
						}
					}
				}	
				
				if(experiment instanceof FormAnalyticsExperiment)
				{
					FormAnalyticsExperiment fanalysis = FormAnalyticsExperiment.getFormAnalyticsExperimentDetails(experiment.getExperimentLinkname());
					projectId = fanalysis.getProjectId();

					if(event.getType().equals(CREATE) 
							|| event.getType().equals(ProjectTreeEventConstants.OperationType.UPDATE)){
						
						String expUrl = fanalysis.getExperimentUrl();
						HashMap<String, String> hs = event.getChangeSets();
						
						if(expUrl!=null && !expUrl.isEmpty() 
								&& (event.getType().equals(CREATE) || hs.containsKey(ExperimentConstants.EXPERIMENT_URL))){
							
							long uid = event.getUserId();
							String portnalName = event.getPortalName();
							genetateThumbnail(fanalysis.getExperimentKey(),
									uid, portnalName, expUrl);	
							
						}
					}
				}
				
				
				if (event.getType().equals(UPDATE)
						|| event.getType().equals(CREATE)) {
					HashMap<String, String> hs = event.getChangeSets();
					projectId = Experiment.getProjectIdByExperimentLinkName(hs.get(ExperimentConstants.EXPERIMENT_LINKNAME));
					if (hs.containsKey(ExperimentConstants.IS_ACTIVE) || hs.containsKey(ExperimentConstants.IS_EXP_STATUS_CHANGED)
							|| (hs.containsKey(ExperimentConstants.EXPERIMENT_STATUS) && (ExperimentStatus.PAUSED
									.getStatusCode()
									.equals(Integer.parseInt(hs
											.get(ExperimentConstants.EXPERIMENT_STATUS))) || ExperimentStatus.RUNNING
									.getStatusCode()
									.equals(Integer.parseInt(hs
											.get(ExperimentConstants.EXPERIMENT_STATUS)))))) {
					   //Flag to update CDN only is the status is changed to paused or running
						updateRequired = true;
					}
				}
				

				if(event.getType().equals(DELETE)) {
					projectId = experiment.getProjectId();
					updateRequired = true;
					deleteCascadeExperiment(experiment, event.getPortalName());
				}
				

//				if(experiment instanceof FormAnalyticsExperiment)
//				{
//					 FormAnalyticsExperiment formanalyticsExperiment = FormAnalyticsExperiment.getFormAnalyticsExperimentDetails(experiment.getExperimentLinkname());
//					 projectId = formanalyticsExperiment.getProjectId();
//					  
//					 if(event.getType().equals(CREATE)||event.getType().equals(UPDATE)){
//					  
//					   String expUrl = formanalyticsExperiment.getExperimentUrl();
//					  
//					   String smallImgLoc = formanalyticsExperiment.getExperimentKey()+"-1.png";  //imgfol+experiment.getExperimentKey()+"-1.png"; //NO I18N
//					   String largeImgLoc = formanalyticsExperiment.getExperimentKey()+"-2.png";  //imgfol+experiment.getExperimentKey()+"-2.png"; //NO I18N
//					  
//					   DFSFileInfo fileinfo = DFSFileInfo.getDFSFileInfoFromFilepath(smallImgLoc);
//						
//						if(fileinfo == null && expUrl!=null && !expUrl.isEmpty()){
//							
//							long uid = event.getUserId();
//							String portnalName = event.getPortalName();
//							
//							ImageGenerator.generateThumbnail(expUrl, 640, 480, uid, smallImgLoc, portnalName);
//							ImageGenerator.generateThumbnail(expUrl, 1280, 960, uid, largeImgLoc, portnalName);							
//						}
//						  updateRequired = (event.getCustomObject()!=null && (Boolean)event.getCustomObject());
//					 } 
//					 
//				}

				

				break;
			case VARIATION:
				Variation variation = (Variation)event.getModel();
				if(variation.getExperimentId()==null && variation.getVariationLinkname()!=null) {
					variation = Variation.getVariationByLinkname(variation.getVariationLinkname()).get(0);
				}
				Experiment experiment2 = Experiment.getExperimentById(variation.getExperimentId());
				if (experiment2.getExperimentStatus() != null
						&& experiment2.getExperimentStatus().equals(
								ExperimentConstants.ExperimentStatus.RUNNING.getStatusCode())) {
					updateRequired = true;
				}
				projectId = experiment2.getProjectId();
				break;
			case AUDIENCE:
				if(!event.getType().equals(OperationType.CREATE)) {
					Audience audience = (Audience)event.getModel();
					if(audience.getProjectId()==null && audience.getAudienceLinkName()!=null) {
						audience = Audience.getAudienceByLinkName(audience.getAudienceLinkName(),null);
					}
					updateRequired = audience.isInvolvedRunningExperiments();
					ProjectAudience pa = ProjectAudience.getProjectAudienceByAudienceId(audience.getAudienceId());
					if(pa!=null) {
						projectId = pa.getProjectId();
					}
					
				}
				break;
			case EXPERIMENT_AUDIENCE:
				ExperimentAudience eAudience = (ExperimentAudience)event.getModel();
				Audience audience2 = Audience.getAudienceById(eAudience.getAudienceId(),null);
				updateRequired = audience2.isInvolvedRunningExperiments();
				ProjectAudience pa = ProjectAudience.getProjectAudienceByAudienceId(audience2.getAudienceId());
				if(pa!=null) {
					projectId = pa.getProjectId();
				}
				break;
			case GOAL:
//				if(!event.getType().equals(OperationType.CREATE)) {					
					Goal goal = (Goal)event.getModel();
					if(goal.getProjectId()==null && goal.getGoalLinkname()!=null) {
						goal = Goal.getGoalByLinkname(goal.getGoalLinkname());
					}
					updateRequired = Boolean.TRUE;
					projectId = goal.getProjectId();
//				}
				break;
			case EXPERIMENT_GOAL:
				ExperimentGoal experimentGoal = (ExperimentGoal)event.getModel();
				Goal goal2 = Goal.getGoalByGoalId(experimentGoal.getGoalId());
				updateRequired = goal2.isInvolvedRunningExperiments();
				projectId = goal2.getProjectId();
				break;
			case DYNAMIC_ATTRIBUTE:
				if(!event.getType().equals(OperationType.CREATE)) {					
					DynamicAttributes dynamicAttributes = (DynamicAttributes)event.getModel();
					projectId = dynamicAttributes.getProjectId();
					//updateRequired = dynamicAttributes.isInvolvedRunningExperiments();;
				}
				break;
			case EXPERIMENT_DYNAMIC_ATTRIBUTE:
				ExperimentDynamicAttribute experimentDynamicAttribute = (ExperimentDynamicAttribute)event.getModel();
				Experiment experiment3 = Experiment.getExperimentById(experimentDynamicAttribute.getExperimentId());
				projectId = experiment3.getProjectId();
				if (experiment3.getExperimentStatus() != null
						&& experiment3.getExperimentStatus().equals(
								ExperimentConstants.ExperimentStatus.RUNNING.getStatusCode())) {
					updateRequired = true;
				}
				break;
			case PROJECT_INTEGRATION:
			case EXPERIMENT_INTEGRATION:
				Integration integration = (Integration)event.getModel();
				projectId = integration.getProjectId();
				//TODO: Setting it false to by default. Need to check the cases and implement it.
				//updateRequired = true;
				break;
			case CUSTOM_EVENT:
				CustomEvent customEvent = (CustomEvent)event.getModel();
				projectId = customEvent.getProjectId();
				updateRequired = true;
				break;
			case PRIVACY_CONSENT:
				Privacy privacy = (Privacy)event.getModel();
				projectId = privacy.getProjectId();
				updateRequired = true;
				break;
			default:
				break;
			}
			LOGGER.log(Level.SEVERE, "End of ProTree processing - Event:"+event+", Update Required:"+updateRequired);
			if(projectId!=null && updateRequired) {
				JSONObject projectJSON = ProjectJSONService.constructProjectJSON(projectId, event.getPortalName());
				ProjectJSONService.updateProjectJSON(projectId, event.getPortalName(), projectJSON.toString(), event.getModule(), event.getUserId());
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
	}
	
	
//	public synchronized static void handleProjectTreeEvent(ProjectTreeEventWrapper event) {
//		try {			
//			switch (event.getModule()) {
//			case PROJECT:
//				handleEvent(event.getType(), (Project)event.getModel(), event.getDbspace());
//				break;
//			case EXPERIMENT:
//				handleEvent(event.getType(), (Experiment)event.getModel(), event.getDbspace());
//				break;
//			case VARIATION:
//				handleEvent(event.getType(), (Variation)event.getModel(), event.getDbspace());
//				break;
//			case AUDIENCE:
//				handleEvent(event.getType(), (Audience)event.getModel(), event.getDbspace());
//				break;
//			case EXPERIMENT_AUDIENCE:
//				handleEvent(event.getType(), (ExperimentAudience)event.getModel(), event.getDbspace());
//				break;
//			case EXPERIMENT_GOAL:
//				handleEvent(event.getType(), (ExperimentGoal)event.getModel(), event.getDbspace());
//				break;
//			case GOAL:
//				handleEvent(event.getType(), (Goal)event.getModel(), event.getDbspace());
//				break;
//			case EXPERIMENT_DYNAMIC_ATTRIBUTE:
//				handleEvent(event.getType(), (ExperimentDynamicAttribute)event.getModel(), event.getDbspace());
//				break;
//			case DYNAMIC_ATTRIBUTE:
//				handleEvent(event.getType(), (DynamicAttributes)event.getModel(), event.getDbspace());
//				break;
//			default:
//				break;
//			}
//		} catch (Exception e) {
//			LOGGER.log(Level.SEVERE, e.getMessage());
//		}
//		
//	}
	/*
	private static void handleEvent(OperationType type, Project project, String dbspace) {
		switch (type) {
		case CREATE:
			ProjectJSONService.createProjectInitialJSON(project.getProjectId(), dbspace);
			break;
		case UPDATE:
			break;
		case DELETE:
			break;
		default:
			break;
		}
	}
	
	private static void handleEvent(OperationType type, Experiment experiment, String dbspace) {
		switch (type) {
		case CREATE:
			onExperimentCreation(experiment, dbspace);
			break;
		case UPDATE:
			onExperimentUpdation(experiment, dbspace);
			break;
		case DELETE:
			onExperimentDeletion(experiment, dbspace);
			break;
		default:
			break;
		}
	}
	
	private static void handleEvent(OperationType type, Variation variation, String dbspace) {
		switch (type) {
		case CREATE:
			onVariationCreation(variation, dbspace);
			break;
		case UPDATE:
			onVariationUpdation(variation, dbspace);
			break;
		case DELETE:
			onVariationDeletion(variation, dbspace);
			break;
		default:
			break;
		}
	}
	
	private static void handleEvent(OperationType type, Goal goal, String dbspace) {
		switch (type) {
		case CREATE:
			onGoalCreation(goal, dbspace);
			break;
		case UPDATE:
			onGoalUpdation(goal, dbspace);
			break;
		case DELETE:
			onGoalDeletion(goal, dbspace);
			break;
		default:
			break;
		}
	}
	
	private static void handleEvent(OperationType type, Audience audience, String dbspace) {
		switch (type) {
		case CREATE:
			onAudienceCreation(audience, dbspace);
			break;
		case UPDATE:
			onAudienceUpdation(audience, dbspace);
			break;
		case DELETE:
			onAudienceDeletion(audience, dbspace);
			break;
		default:
			break;
		}
	}
	
	private static void handleEvent(OperationType type, ExperimentGoal goal, String dbspace) {
		switch (type) {
		case CREATE:
			onExperimentGoalCreation(goal, dbspace);
			break;
		case UPDATE:
			onExperimentGoalUpdation(goal, dbspace);
			break;
		case DELETE:
			onExperimentGoalDeletion(goal, dbspace);
			break;
		default:
			break;
		}
	}
	
	private static void handleEvent(OperationType type, ExperimentAudience audience, String dbspace) {
		switch (type) {
		case CREATE:
			onExperimentAudienceCreation(audience, dbspace);
			break;
		case UPDATE:
			onExperimentAudienceUpdation(audience, dbspace);
			break;
		case DELETE:
			onExperimentAudienceDeletion(audience, dbspace);
			break;
		default:
			break;
		}
	}
	
	private static void handleEvent(OperationType type, ExperimentDynamicAttribute experimentDynamicAttribute, String dbspace) {
		switch (type) {
		case CREATE:
			onExperimentDynamicAttributeCreation(experimentDynamicAttribute, dbspace);
			break;
		case DELETE:
			onExperimentDynamicAttributeDeletion(experimentDynamicAttribute, dbspace);
			break;
		default:
			break;
		}
	}
	
	private static void handleEvent(OperationType type, DynamicAttributes dynamicAttribute, String dbspace) {
		switch (type) {
		case CREATE:
			break;
		case UPDATE:
			onDynamicAttributeUpdation(dynamicAttribute, dbspace);
			break;
		case DELETE:
			onDynamicAttributeDeletion(dynamicAttribute, dbspace);
			break;
		default:
			break;
		}
	}
	
	private static void onExperimentGoalCreation(ExperimentGoal eGoal, String dbspace) {
		try {			
			ZABUtil.setDBSpace(dbspace);
			Goal goal = Goal.getGoalByGoalId(eGoal.getGoalId());
			Long projectId = goal.getProjectId();
			if(projectId!=null) {				
				Experiment experiment = Experiment.getExperimentById(eGoal.getExperimentId());
				if(experiment!=null && experiment.getExperimentStatus()!=null && ExperimentStatus.RUNNING.getStatusCode().equals(experiment.getExperimentStatus())) {					
//					processGoalCreationEvent(goal, experiments, dbspace);
					JSONObject projectJSON = ProjectJSONService.getProjectJSON(dbspace, projectId);
					if(projectJSON.has(ProjectJSONConstants.EXPERIMENT)) {
						JSONObject experimentJSON = projectJSON.getJSONObject(ProjectJSONConstants.EXPERIMENT);
						if(experimentJSON.has(experiment.getExperimentUrl())) {
							JSONObject exArray =  experimentJSON.getJSONObject(experiment.getExperimentUrl());
							if(exArray.has(experiment.getExperimentLinkname())) {
								JSONObject exObj = exArray.getJSONObject(experiment.getExperimentLinkname());
								if(exObj.has(ProjectJSONConstants.GOAL)) {
									JSONArray goalsArray = exObj.getJSONArray(ProjectJSONConstants.GOAL);
									if(!doesGoalExists(goal.getGoalLinkname(), goalsArray)) {									
										goalsArray.put(goal.getGoalLinkname());
									}
								} else {
									JSONArray goalsArray = new JSONArray();
									goalsArray.put(goal.getGoalLinkname());
									exObj.put(ProjectJSONConstants.GOAL, goalsArray);
								}
							}
						}
					}
					
					if(projectJSON.has(ProjectJSONConstants.GOAL)) {
						JSONObject goalJSON = projectJSON.getJSONObject(ProjectJSONConstants.GOAL);
						goalJSON.put(goal.getGoalLinkname(), ProjectJSONService.convertToJSON(goal));
						
					} else {
						JSONObject goalJSON = new JSONObject();
						goalJSON.put(goal.getGoalLinkname(), ProjectJSONService.convertToJSON(goal));
						projectJSON.put(ProjectJSONConstants.GOAL, goalJSON);
					}
					ProjectJSONService.updateProjectJSON(projectId, dbspace, projectJSON.toString());
				}
			}
			
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
	}
	
	private static void onExperimentGoalUpdation(ExperimentGoal eGoal, String dbspace) {
		try {			
			ZABUtil.setDBSpace(dbspace);
			Goal goal = Goal.getGoalByGoalId(eGoal.getGoalId());
			Long projectId = goal.getProjectId();
			//Only thing that we can update in experiment goal is "is_primary"
			if(projectId!=null && eGoal.getIsPrimary()) {				
				Experiment experiment = Experiment.getExperimentById(eGoal.getExperimentId());
				JSONObject projectJSON = ProjectJSONService.getProjectJSON(dbspace, projectId);
				if(projectJSON.has(ProjectJSONConstants.EXPERIMENT)) {
					JSONObject experimentJSON = projectJSON.getJSONObject(ProjectJSONConstants.EXPERIMENT);
					if(experimentJSON.has(experiment.getExperimentUrl())) {
						JSONObject exArray =  experimentJSON.getJSONObject(experiment.getExperimentUrl());
						if(exArray.has(experiment.getExperimentLinkname())) {
							JSONObject expObj = exArray.getJSONObject(experiment.getExperimentLinkname());
							expObj.put(ProjectJSONConstants.PRIMARY_GOAL, goal.getGoalLinkname());
						}
					}
				}
				ProjectJSONService.updateProjectJSON(projectId, dbspace, projectJSON.toString());
			}
			
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
	}
	
	private static void onExperimentGoalDeletion(ExperimentGoal eGoal, String dbspace) {
		try {			
			ZABUtil.setDBSpace(dbspace);
			Experiment experiment = Experiment.getExperimentById(eGoal.getExperimentId());
			Long projectId = experiment.getProjectId();
			JSONObject projectJSON = ProjectJSONService.getProjectJSON(dbspace, projectId);
			String goalLinkname = Goal.getGoalLinknameForGoal(eGoal.getGoalId());
			removeGoalFromExpeirment(experiment, goalLinkname, projectJSON);
			ArrayList<Experiment> experiments = ExperimentGoal.getRunningExperimentsForGoal(eGoal.getGoalId(), projectId);
			if(experiments.size() == 0) {
				if(goalLinkname!=null) {					
					deleteGoalFromJSON(goalLinkname, projectJSON);
				}
			}
			ProjectJSONService.updateProjectJSON(projectId, dbspace, projectJSON.toString());
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
	}
	
	private static void onExperimentDynamicAttributeCreation(ExperimentDynamicAttribute experimentDynamicAttribute, String dbspace) {
		try {			
			ZABUtil.setDBSpace(dbspace);
			
			Long experimentId = experimentDynamicAttribute.getExperimentId();
			Experiment experiment = Experiment.getExperimentById(experimentId);
			Long projectId = experiment.getProjectId();
			
			if(projectId!=null) {				
				if(experiment!=null && experiment.getExperimentStatus()!=null && ExperimentStatus.RUNNING.getStatusCode().equals(experiment.getExperimentStatus())) {	
					
					List<Long> dynamicAttributeIdList = experimentDynamicAttribute.getDynamicAttributeIdList();
					List<DynamicAttributes> dynamicAttributeList = new ArrayList<DynamicAttributes>();
					for(Long dynamicAttributeId:dynamicAttributeIdList)
					{
						DynamicAttributes dynamicAttribute =  DynamicAttributes.getDynamicAttributesById(dynamicAttributeId);
						dynamicAttributeList.add(dynamicAttribute);
					}
					
					JSONObject projectJSON = ProjectJSONService.getProjectJSON(dbspace, projectId);
					
					if(projectJSON.has(ProjectJSONConstants.EXPERIMENT)) {
						JSONObject experimentJSON = projectJSON.getJSONObject(ProjectJSONConstants.EXPERIMENT);
						if(experimentJSON.has(experiment.getExperimentUrl())) {
							JSONObject exArray =  experimentJSON.getJSONObject(experiment.getExperimentUrl());
							if(exArray.has(experiment.getExperimentLinkname())) {
								JSONObject exObj = exArray.getJSONObject(experiment.getExperimentLinkname());
								if(exObj.has(ProjectJSONConstants.DYNAMIC_ATTRIBUTE)) {
									JSONArray dynamicAttributeArray = exObj.getJSONArray(ProjectJSONConstants.DYNAMIC_ATTRIBUTE);
									
									for(DynamicAttributes dynamicAttribute:dynamicAttributeList)
									{
										if(!isLinkNameExists(dynamicAttribute.getAttributeLinkName(), dynamicAttributeArray)) {									
											dynamicAttributeArray.put(dynamicAttribute.getAttributeLinkName());
										}
									}
									
								} else {
									JSONArray dynamicAttributeArray = new JSONArray();
									
									for(DynamicAttributes dynamicAttribute:dynamicAttributeList)
									{
										dynamicAttributeArray.put(dynamicAttribute.getAttributeLinkName());
									}
									
									exObj.put(ProjectJSONConstants.DYNAMIC_ATTRIBUTE, dynamicAttributeArray);
								}
							}
						}
					}
					
					if(projectJSON.has(ProjectJSONConstants.DYNAMIC_ATTRIBUTE)) {
						JSONObject dynamicAttributeJSON = projectJSON.getJSONObject(ProjectJSONConstants.DYNAMIC_ATTRIBUTE);
						for(DynamicAttributes dynamicAttribute:dynamicAttributeList)
						{
							dynamicAttributeJSON.put(dynamicAttribute.getAttributeLinkName(), ProjectJSONService.convertToJSON(dynamicAttribute));
						}
					} else {
						JSONObject dynamicAttributeJSON = new JSONObject();
						for(DynamicAttributes dynamicAttribute:dynamicAttributeList)
						{
							dynamicAttributeJSON.put(dynamicAttribute.getAttributeLinkName(), ProjectJSONService.convertToJSON(dynamicAttribute));
						}
						projectJSON.put(ProjectJSONConstants.DYNAMIC_ATTRIBUTE, dynamicAttributeJSON);
					}
					ProjectJSONService.updateProjectJSON(projectId, dbspace, projectJSON.toString());
				}
			}
			
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
	}
	
	private static void onExperimentDynamicAttributeDeletion(ExperimentDynamicAttribute experimentDynamicAttribute, String dbspace) {
		try {			
			ZABUtil.setDBSpace(dbspace);
			
			List<Long> dynamicAttributeIdList = experimentDynamicAttribute.getDynamicAttributeIdList();
			List<DynamicAttributes> dynamicAttributeList = new ArrayList<DynamicAttributes>();
			List<String> dynamicAttrLinkNames = new ArrayList<String>();
			for(Long dynamicAttributeId:dynamicAttributeIdList)
			{
				DynamicAttributes dynamicAttribute =  DynamicAttributes.getDynamicAttributesById(dynamicAttributeId);
				dynamicAttributeList.add(dynamicAttribute);
				dynamicAttrLinkNames.add(dynamicAttribute.getAttributeLinkName());
			}
			Long experimentId = experimentDynamicAttribute.getExperimentId();
			Experiment experiment = Experiment.getExperimentById(experimentId);
			Long projectId = experiment.getProjectId();
			
			JSONObject projectJSON = ProjectJSONService.getProjectJSON(dbspace, projectId);
			
			removeDynamicAttributesFromExperiment(experiment, dynamicAttrLinkNames, projectJSON);
			
			for(DynamicAttributes dynamicAttribute:dynamicAttributeList)
			{
				List<Experiment> experiments = ExperimentDynamicAttribute.getActiveExperimentsByDynamicAttributeId(dynamicAttribute.getDynamicAttributeId());
				if(experiments.size() == 0) {
					deleteDynamicAttributeFromJSON(dynamicAttribute.getAttributeLinkName(), projectJSON);
				}
			}
			
			ProjectJSONService.updateProjectJSON(projectId, dbspace, projectJSON.toString());
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
	}
	
	//Experiment events
	private static void onExperimentCreation(Experiment experiment, String dbspace) {
		try {			
			ZABUtil.setDBSpace(dbspace);
			ExperimentStatus experimentStatus = ExperimentStatus.getStatusByNumber(experiment.getExperimentStatus());
			if(experiment!=null && experiment.getProjectId()!=null && experiment.getSuccess() && experimentStatus!=null && experimentStatus.equals(ExperimentStatus.RUNNING)) {
				Long projectId = experiment.getProjectId();
				JSONObject projectJSON = ProjectJSONService.getProjectJSON(dbspace, projectId);
				String url = experiment.getExperimentUrl();
				experiment.setGoals(Goal.getGoalByExperimentByExperimentId(experiment.getExperimentId()));
				experiment.setDynamicAttributes(ExperimentDynamicAttribute.getDynamicAttributesByExperiment(experiment.getExperimentId()));
				if(projectJSON.has(ProjectJSONConstants.EXPERIMENT)) {
					JSONObject experimentJSON = projectJSON.getJSONObject(ProjectJSONConstants.EXPERIMENT);
					if(experimentJSON.has(url)) {
						JSONObject exArray = experimentJSON.getJSONObject(url);
						exArray.put(experiment.getExperimentLinkname(), ProjectJSONService.convertToJSON(experiment));
					} else {
						JSONObject exArray = new JSONObject();
						exArray.put(experiment.getExperimentLinkname(), ProjectJSONService.convertToJSON(experiment));
						experimentJSON.put(url, exArray);
					}
				} else {
					JSONObject experimentJSON = new JSONObject();
					JSONObject exArray = new JSONObject();
					exArray.put(experiment.getExperimentLinkname(), ProjectJSONService.convertToJSON(experiment));
					experimentJSON.put(url, exArray);
					projectJSON.put(ProjectJSONConstants.EXPERIMENT, experimentJSON);
				}
				
				//Add relavent goals
				addGoalsToJSON(experiment.getGoals(), projectJSON);
				addDynamicAttributesToJSON(experiment.getDynamicAttributes(),projectJSON);
				ProjectJSONService.updateProjectJSON(projectId, dbspace, projectJSON.toString());
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
	}
	
	private static void onExperimentUpdation(Experiment updatedObj, String dbspace) {
		try {			
			ZABUtil.setDBSpace(dbspace);
			ArrayList<Experiment> experiments = Experiment.getExperimentDetailsByLinkname(updatedObj.getExperimentLinkname());
			Experiment experimentDetail = null;
			if(experiments!=null && !experiments.isEmpty()) {
				experimentDetail = experiments.get(0);
				experimentDetail.setGoals(Goal.getGoalByExperimentByExperimentId(experimentDetail.getExperimentId()));
				experimentDetail.setDynamicAttributes(ExperimentDynamicAttribute.getDynamicAttributesByExperiment(experimentDetail.getExperimentId()));
				experimentDetail.setAudiences(Audience.getAudienceByExperimentId(experimentDetail.getExperimentId()));
			}
			if(updatedObj!=null && experimentDetail!=null) {				
					ExperimentStatus experimentStatus = ExperimentStatus.getStatusByNumber(experimentDetail.getExperimentStatus());
					if(experimentDetail!=null && experimentDetail.getProjectId()!=null && experimentDetail.getSuccess() && experimentStatus!=null) {
						Long projectId = experimentDetail.getProjectId();
						JSONObject projectJSON = ProjectJSONService.getProjectJSON(dbspace, projectId);
						String url = experimentDetail.getExperimentUrl();
						if(experimentStatus.equals(ExperimentStatus.RUNNING)) {							
							if(projectJSON.has(ProjectJSONConstants.EXPERIMENT)) {
								JSONObject experimentJSON = projectJSON.getJSONObject(ProjectJSONConstants.EXPERIMENT);
								if(experimentJSON.has(url)) {
									JSONObject exArray = experimentJSON.getJSONObject(url);
									exArray.put(experimentDetail.getExperimentLinkname(), ProjectJSONService.convertToJSON(experimentDetail));
								} else {
									JSONObject exArray = new JSONObject();
									exArray.put(experimentDetail.getExperimentLinkname(), ProjectJSONService.convertToJSON(experimentDetail));
									experimentJSON.put(url, exArray);	
								}
							} else {
								projectJSON = new JSONObject();
								JSONObject experimentJSON = new JSONObject();
								JSONObject exArray = new JSONObject();
								exArray.put(experimentDetail.getExperimentLinkname(), ProjectJSONService.convertToJSON(experimentDetail));
								experimentJSON.put(url, exArray);
								projectJSON.put(ProjectJSONConstants.EXPERIMENT, experimentJSON);
							}
							addGoalsToJSON(experimentDetail.getGoals(), projectJSON);
							addDynamicAttributesToJSON(experimentDetail.getDynamicAttributes(),projectJSON);
							addAudienceToJSON(experimentDetail.getAudiences(), projectJSON);
						} else {
//							if(projectJSON.has(ProjectJSONConstants.EXPERIMENT)) {
//								JSONObject experimentJSON = projectJSON.getJSONObject(ProjectJSONConstants.EXPERIMENT);
//								if(experimentJSON.has(url)) {
//									JSONObject exArray = experimentJSON.getJSONObject(url);
//									
//									if(exArray.has(experimentDetail.getExperimentLinkname())) {
//										JSONObject ejson = exArray.getJSONObject(experimentDetail.getExperimentLinkname());
//										if(ejson.has(ProjectJSONConstants.GOAL)) 
//										{
//											JSONArray array = ejson.getJSONArray(ProjectJSONConstants.GOAL);
//											for(int k=0; k < array.length(); k++) {
//												String goalLinkname = array.getString(k);
//												// check if other experiments has its goal
//												ArrayList<Experiment> goalExpeirment = ExperimentGoal.getRunningExperimentsForGoal(goalLinkname, projectId);
//												if(goalExpeirment.size() == 0) {													
//													deleteGoalFromJSON(goalLinkname, projectJSON);
//												}
//											}
//										}
//										if(ejson.has(ProjectJSONConstants.DYNAMIC_ATTRIBUTE))
//										{
//											JSONArray array = ejson.getJSONArray(ProjectJSONConstants.DYNAMIC_ATTRIBUTE);
//											for(int k=0; k < array.length(); k++) {
//												String dynamicAttrLinkname = array.getString(k);
//												// check if other experiments has its goal
//												List<Experiment> activeExperimentList = ExperimentDynamicAttribute.getActiveExperimentsByDynamicAttributeLinkName(dynamicAttrLinkname);
//												if(activeExperimentList.size() == 0) {													
//													deleteDynamicAttributeFromJSON(dynamicAttrLinkname, projectJSON);
//												}
//											}
//										}
//										
//										if(ejson.has(ProjectJSONConstants.AUDIENCE))
//										{
//											JSONArray array = ejson.getJSONArray(ProjectJSONConstants.AUDIENCE);
//											for(int k=0; k < array.length(); k++) {
//												String audienceLinkname = array.getString(k);
//												// check if other experiments has its goal
//												List<Experiment> activeExperimentList = ExperimentAudience.getRunningExperimentForAudience(audienceLinkname, projectId);
//												if(activeExperimentList.size() == 0) {													
//													deleteAudienceFromJSON(audienceLinkname, projectJSON);
//												}
//											}
//										}
//										
//										if(exArray.length()==1)
//										{
//											experimentJSON.remove(url);
//										}
//										else if(exArray.length()>1)
//										{
//											exArray.remove(experimentDetail.getExperimentLinkname());
//										}
//									} 
//								}
//							}
							handleExperimentCascadeDeletion(projectJSON, experimentDetail);
						}
						ProjectJSONService.updateProjectJSON(projectId, dbspace, projectJSON.toString());
					}
				
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
	}
	
	private static void handleExperimentCascadeDeletion(JSONObject projectJSON, Experiment experiment) throws JSONException {
		String url = experiment.getExperimentUrl();
		Long projectId = experiment.getProjectId();
		if(projectJSON.has(ProjectJSONConstants.EXPERIMENT)) {
			JSONObject experimentJSON = projectJSON.getJSONObject(ProjectJSONConstants.EXPERIMENT);
			if(experimentJSON.has(url)) {
				JSONObject exArray = experimentJSON.getJSONObject(url);
				
				if(exArray.has(experiment.getExperimentLinkname()))
				{
					
					JSONObject ejson = exArray.getJSONObject(experiment.getExperimentLinkname());
					if(ejson.has(ProjectJSONConstants.GOAL)) {
						JSONArray array = ejson.getJSONArray(ProjectJSONConstants.GOAL);
						for(int k=0; k < array.length(); k++) {
							String goalLinkname = array.getString(k);
							// check if other experiments has its goal
							ArrayList<Experiment> goalExpeirment = ExperimentGoal.getRunningExperimentsForGoal(goalLinkname, projectId);
							if(goalExpeirment.size() == 0) {													
								deleteGoalFromJSON(goalLinkname, projectJSON);
							}
						}
					}
					if(ejson.has(ProjectJSONConstants.DYNAMIC_ATTRIBUTE))
					{
						JSONArray array = ejson.getJSONArray(ProjectJSONConstants.DYNAMIC_ATTRIBUTE);
						for(int k=0; k < array.length(); k++) {
							String dynamicAttrLinkname = array.getString(k);
							// check if other experiments has its goal
							List<Experiment> activeExperimentList = ExperimentDynamicAttribute.getActiveExperimentsByDynamicAttributeLinkName(dynamicAttrLinkname);
							if(activeExperimentList.size() == 0) {													
								deleteDynamicAttributeFromJSON(dynamicAttrLinkname, projectJSON);
							}
						}
					}
					if(ejson.has(ProjectJSONConstants.AUDIENCE))
					{
						JSONArray array = ejson.getJSONArray(ProjectJSONConstants.AUDIENCE);
						for(int k=0; k < array.length(); k++) {
							String audienceLinkname = array.getString(k);
							// check if other experiments has its goal
							List<Experiment> activeExperimentList = ExperimentAudience.getRunningExperimentForAudience(audienceLinkname, projectId);
							if(activeExperimentList.size() == 0) {													
								deleteAudienceFromJSON(audienceLinkname, projectJSON);
							}
						}
					}
					if(exArray.length()==1) {
						experimentJSON.remove(url);
					} else if(exArray.length()>1 ) {
						exArray.remove(experiment.getExperimentLinkname());
					}
				
				}
				
			}
		}
	}
	
	private static void onExperimentDeletion(Experiment experiment, String dbspace) {
		
		try {			
			if(experiment!=null && experiment.getProjectId()!=null && experiment.getSuccess()) {
				Long projectId = experiment.getProjectId();
				JSONObject projectJSON = ProjectJSONService.getProjectJSON(dbspace, projectId);
				handleExperimentCascadeDeletion(projectJSON, experiment);
				ProjectJSONService.updateProjectJSON(projectId, dbspace, projectJSON.toString());
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
	}
	
	//Variation events
	private static void onVariationCreation(Variation variation, String dbspace) {
		ZABUtil.setDBSpace(dbspace);
		try {
			if(variation!=null && variation.getExperimentId()!=null && variation.getSuccess()) {
				Experiment experiment = Experiment.getExperimentById(variation.getExperimentId());
				ExperimentStatus experimentStatus = ExperimentStatus.getStatusByNumber(experiment.getExperimentStatus());
				//Update variations only for running experiments
				if(experimentStatus!=null && experimentStatus.equals(ExperimentStatus.RUNNING)) {					
					Long projectId = experiment.getProjectId();
					JSONObject projectJSON = ProjectJSONService.getProjectJSON(dbspace, projectId);
					JSONObject experimentJSON = projectJSON.getJSONObject(ProjectJSONConstants.EXPERIMENT);
					JSONObject experimentArray = experimentJSON.getJSONObject(experiment.getExperimentUrl());
					if(experimentArray.has(experiment.getExperimentLinkname())) {
						JSONObject expJson = experimentArray.getJSONObject(experiment.getExperimentLinkname());
						JSONObject variations = expJson.getJSONObject(ProjectJSONConstants.VARIATIONS);
						variations.put(variation.getVariationLinkname(), ProjectJSONService.convertToJSON(variation));
					}
					ProjectJSONService.updateProjectJSON(projectId, dbspace, projectJSON.toString());
				}
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
	}
	
	private static void onVariationUpdation(Variation variation, String dbspace) {
		ZABUtil.setDBSpace(dbspace);
		ArrayList<Variation> variations = Variation.getVariationByLinkname(variation.getVariationLinkname());
		if(variations!=null && !variations.isEmpty()) {
			onVariationCreation(variations.get(0), dbspace);
		}
	}
	
	private static void onVariationDeletion(Variation variation, String dbspace) {
		ZABUtil.setDBSpace(dbspace);
		try {
			if(variation!=null && variation.getExperimentId()!=null && variation.getSuccess()) {
				Experiment experiment = Experiment.getExperimentById(variation.getExperimentId());
				ExperimentStatus experimentStatus = ExperimentStatus.getStatusByNumber(experiment.getExperimentStatus());
				//Update variations only for running experiments
				if(experimentStatus!=null && experimentStatus.equals(ExperimentStatus.RUNNING)) {					
					Long projectId = experiment.getProjectId();
					JSONObject projectJSON = ProjectJSONService.getProjectJSON(dbspace, projectId);
					JSONObject experimentJSON = projectJSON.getJSONObject(ProjectJSONConstants.EXPERIMENT);
					JSONObject experimentArray = experimentJSON.getJSONObject(experiment.getExperimentUrl());
					if(experimentArray.has(experiment.getExperimentLinkname())) {
						JSONObject expJson = experimentArray.getJSONObject(experiment.getExperimentLinkname());
						JSONObject variations = expJson.getJSONObject(ProjectJSONConstants.VARIATIONS);
						if(variations.has(variation.getVariationLinkname())) {
							variations.remove(variation.getVariationLinkname());
						}
					}
					ProjectJSONService.updateProjectJSON(projectId, dbspace, projectJSON.toString());
				}
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
	}
	
	private static void deleteGoalFromJSON(String linkname, JSONObject projectJSON) throws JSONException {
		if(projectJSON.has(ProjectJSONConstants.GOAL)) {
			JSONObject goalJSON = projectJSON.getJSONObject(ProjectJSONConstants.GOAL);
			goalJSON.remove(linkname);
		}
	}
	
	private static void deleteDynamicAttributeFromJSON(String linkname, JSONObject projectJSON) throws JSONException {
		if(projectJSON.has(ProjectJSONConstants.DYNAMIC_ATTRIBUTE)) {
			JSONObject dynamicAttrJSON = projectJSON.getJSONObject(ProjectJSONConstants.DYNAMIC_ATTRIBUTE);
			dynamicAttrJSON.remove(linkname);
		}
	}
	
	private static void addGoalsToJSON(ArrayList<Goal> goals, JSONObject projectJSON) throws JSONException {
		for(int i=0; i<goals.size(); i++) {
			Goal goal = goals.get(i);
			if(projectJSON.has(ProjectJSONConstants.GOAL)) {
				JSONObject goalJSON = projectJSON.getJSONObject(ProjectJSONConstants.GOAL);
				goalJSON.put(goal.getGoalLinkname(), ProjectJSONService.convertToJSON(goal));
			} else {
				JSONObject goalJSON = new JSONObject();
				goalJSON.put(goal.getGoalLinkname(), ProjectJSONService.convertToJSON(goal));
				projectJSON.put(ProjectJSONConstants.GOAL, goalJSON);
			}
		}
		
	}
	
	private static void addDynamicAttributesToJSON(List<DynamicAttributes> dynamicAttributes, JSONObject projectJSON) throws Exception
	{
		if(dynamicAttributes != null && !dynamicAttributes.isEmpty())
		{
			if(projectJSON.has(ProjectJSONConstants.DYNAMIC_ATTRIBUTE)) {
				JSONObject dynamicAttrJSON = projectJSON.getJSONObject(ProjectJSONConstants.DYNAMIC_ATTRIBUTE);
				for(DynamicAttributes dynamicAttribute:dynamicAttributes)
				{
					dynamicAttrJSON.put(dynamicAttribute.getAttributeLinkName(), ProjectJSONService.convertToJSON(dynamicAttribute));
				}
			} else {
				JSONObject dynamicAttrJSON = new JSONObject();
				for(DynamicAttributes dynamicAttribute:dynamicAttributes)
				{
					dynamicAttrJSON.put(dynamicAttribute.getAttributeLinkName(), ProjectJSONService.convertToJSON(dynamicAttribute));
				}
				projectJSON.put(ProjectJSONConstants.DYNAMIC_ATTRIBUTE, dynamicAttrJSON);
			}
		}
	}
	
	private static void addAudienceToJSON(List<Audience> audiences, JSONObject projectJSON) throws Exception
	{
		if(audiences != null && !audiences.isEmpty())
		{
			if(projectJSON.has(ProjectJSONConstants.AUDIENCE)) {
				JSONObject dynamicAttrJSON = projectJSON.getJSONObject(ProjectJSONConstants.AUDIENCE);
				for(Audience audience:audiences)
				{
					dynamicAttrJSON.put(audience.getAudienceLinkName(), ProjectJSONService.convertToJSON(audience));
				}
			} else {
				JSONObject dynamicAttrJSON = new JSONObject();
				for(Audience audience:audiences)
				{
					dynamicAttrJSON.put(audience.getAudienceLinkName(), ProjectJSONService.convertToJSON(audience));
				}
				projectJSON.put(ProjectJSONConstants.AUDIENCE, dynamicAttrJSON);
			}
		}
	}
	
	private static void onGoalDeletion(Goal goal, String dbspace) {
		ZABUtil.setDBSpace(dbspace);
		try {
				Long projectId = goal.getProjectId();
				JSONObject projectJSON = ProjectJSONService.getProjectJSON(dbspace, projectId);
				deleteGoalFromJSON(goal.getGoalLinkname(), projectJSON);
				ArrayList<Experiment> experiments = goal.getExperiments();
				int size = experiments.size();
				for(int i=0; i<size; i++) {
					Experiment experiment = experiments.get(i);
					removeGoalFromExpeirment(experiment, goal.getGoalLinkname(), projectJSON);
				}
				ProjectJSONService.updateProjectJSON(projectId, dbspace, projectJSON.toString());
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
	}
	
	private static void onDynamicAttributeDeletion(DynamicAttributes dynamicAttribute, String dbspace)
	{
		ZABUtil.setDBSpace(dbspace);
		try
		{
			Long projectId = dynamicAttribute.getProjectId();
			String dynamicAttributeLinkName = dynamicAttribute.getAttributeLinkName();
			List<String> linkNames = new ArrayList<String>();
			linkNames.add(dynamicAttributeLinkName);
			JSONObject projectJSON = ProjectJSONService.getProjectJSON(dbspace, projectId);
			deleteDynamicAttributeFromJSON(dynamicAttributeLinkName, projectJSON);
			List<Experiment> experimentList = dynamicAttribute.getExperimentList();
			for(Experiment experiment:experimentList)
			{
				removeDynamicAttributesFromExperiment(experiment, linkNames, projectJSON);
			}
			ProjectJSONService.updateProjectJSON(projectId, dbspace, projectJSON.toString());
		}
		catch (Exception e) 
		{
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
	}
	
	private static void removeGoalFromExpeirment(Experiment experiment, String goalLinkname, JSONObject projectJSON) throws JSONException {
		if(projectJSON.has(ProjectJSONConstants.EXPERIMENT)) {
			JSONObject experimentJSON = projectJSON.getJSONObject(ProjectJSONConstants.EXPERIMENT);
			if(experimentJSON.has(experiment.getExperimentUrl())) {
				JSONObject exArray =  experimentJSON.getJSONObject(experiment.getExperimentUrl());
				if(exArray.has(experiment.getExperimentLinkname())) {
					JSONObject exObj = exArray.getJSONObject(experiment.getExperimentLinkname());
					if(exObj.has(ProjectJSONConstants.GOAL)) {
						JSONArray goalsArray = exObj.getJSONArray(ProjectJSONConstants.GOAL);
						JSONArray newJSON = new JSONArray();
						for(int j=0; j<goalsArray.length(); j++) {
							if(!goalsArray.getString(j).equals(goalLinkname)) {
								newJSON.put(goalsArray.getString(j));
							}
						}
						exObj.put(ProjectJSONConstants.GOAL, newJSON);
					}
				}
			}
		}
	}
	
	private static void removeDynamicAttributesFromExperiment(Experiment experiment, List<String> attributeLinknames, JSONObject projectJSON) throws JSONException {
		if(projectJSON.has(ProjectJSONConstants.EXPERIMENT)) {
			JSONObject experimentJSON = projectJSON.getJSONObject(ProjectJSONConstants.EXPERIMENT);
			if(experimentJSON.has(experiment.getExperimentUrl())) {
				JSONObject exArray =  experimentJSON.getJSONObject(experiment.getExperimentUrl());
				if(exArray.has(experiment.getExperimentLinkname())) {
					JSONObject exObj = exArray.getJSONObject(experiment.getExperimentLinkname());
					if(exObj.has(ProjectJSONConstants.DYNAMIC_ATTRIBUTE)) {
						JSONArray dynamicAttrsArray = exObj.getJSONArray(ProjectJSONConstants.DYNAMIC_ATTRIBUTE);
						JSONArray newJSON = new JSONArray();
						int length = dynamicAttrsArray.length();
						for(int j=0; j<length; j++) {
							if(!attributeLinknames.contains(dynamicAttrsArray.getString(j)))
							{
								newJSON.put(dynamicAttrsArray.getString(j));
							}
						}
						exObj.put(ProjectJSONConstants.DYNAMIC_ATTRIBUTE, newJSON);
					}
				}
			}
		}
	}
	
	private static void onGoalUpdation(Goal goal, String dbspace) {
		ZABUtil.setDBSpace(dbspace);
		try {
				Long projectId = goal.getProjectId();
				JSONObject projectJSON = ProjectJSONService.getProjectJSON(dbspace, projectId);
//				ArrayList<Experiment> experiments = ExperimentGoal.getRunningExperimentsForGoal(goal.getGoalId(), projectId);
				//if there is no running experiments, dont do any update.
//				if(!experiments.isEmpty()) {					
					if(projectJSON.has(ProjectJSONConstants.GOAL)) {
						JSONObject goalJSON = projectJSON.getJSONObject(ProjectJSONConstants.GOAL);
						if(goalJSON.has(goal.getGoalLinkname())) {							
							goalJSON.put(goal.getGoalLinkname(), ProjectJSONService.convertToJSON(goal));
						}
					}
					ProjectJSONService.updateProjectJSON(projectId, dbspace, projectJSON.toString());
//				}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
	}
	
	private static void onDynamicAttributeUpdation(DynamicAttributes dynamicAttribute, String dbspace)
	{
		ZABUtil.setDBSpace(dbspace);
		try
		{
			Long projectId = dynamicAttribute.getProjectId();
			JSONObject projectJSON = ProjectJSONService.getProjectJSON(dbspace, projectId);
			if(projectJSON.has(ProjectJSONConstants.DYNAMIC_ATTRIBUTE))
			{
				JSONObject dynamicAttributeJSON = projectJSON.getJSONObject(ProjectJSONConstants.DYNAMIC_ATTRIBUTE);
				if(dynamicAttributeJSON.has(dynamicAttribute.getAttributeLinkName()))
				{
					dynamicAttributeJSON.put(dynamicAttribute.getAttributeLinkName(), ProjectJSONService.convertToJSON(dynamicAttribute));
				}
				ProjectJSONService.updateProjectJSON(projectId, dbspace, projectJSON.toString());
			}
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
	}
	
	//Goal events
	private static void onGoalCreation(Goal goal, String dbspace) {
		ZABUtil.setDBSpace(dbspace);
		try {			
			//Nothing to do with goal creation. The responsibility goes to experiment goals.
//			ArrayList<Experiment> experiments = ExperimentGoal.getExperimentsForGoal(goal.getGoalId());
//			processGoalCreationEvent(goal, experiments, dbspace);
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
	}
	
	public static Boolean doesGoalExists(String linkname, JSONArray goalsArray) throws JSONException {
		if(goalsArray!=null) {
			for(int i=0; i<goalsArray.length(); i++) {
				if(goalsArray.getString(i).equals(linkname)) {
					return true;
				}
			}
		}
		return false;
	}
	
	public static boolean isLinkNameExists(String linkname, JSONArray jsonArray)
	{
		boolean isExists = false;
		try
		{
			if(jsonArray != null)
			{
				int size = jsonArray.length();
				for(int i=0;i<size;i++)
				{
					if(jsonArray.getString(i).equals(linkname))
					{
						isExists = true;
						break;
					}
				}
			}
		}
		catch(Exception ex)
		{
			isExists = false;
		}
		return isExists;
	}
	
	public static void processGoalCreationEvent(Goal goal, ArrayList<Experiment> experiments, String dbspace) throws Exception {
		int size = experiments.size();
		if(size > 0) {				
			Long projectId = goal.getProjectId();
			JSONObject projectJSON = ProjectJSONService.getProjectJSON(dbspace, projectId);
			for(int i=0; i<size; i++) {
				Experiment experiment = experiments.get(i);
				if(projectJSON.has(ProjectJSONConstants.EXPERIMENT)) {
					JSONObject experimentJSON = projectJSON.getJSONObject(ProjectJSONConstants.EXPERIMENT);
					if(experimentJSON.has(experiment.getExperimentUrl())) {
						JSONObject exArray =  experimentJSON.getJSONObject(experiment.getExperimentUrl());
						if(exArray.has(experiment.getExperimentLinkname())) {
							JSONObject exObj = exArray.getJSONObject(experiment.getExperimentLinkname());
							if(exObj.has(ProjectJSONConstants.GOAL)) {
								JSONArray goalsArray = exObj.getJSONArray(ProjectJSONConstants.GOAL);
								if(!doesGoalExists(goal.getGoalLinkname(), goalsArray)) {									
									goalsArray.put(goal.getGoalLinkname());
								}
							} else {
								JSONArray goalsArray = new JSONArray();
								goalsArray.put(goal.getGoalLinkname());
								exObj.put(ProjectJSONConstants.GOAL, goalsArray);
							}
						}
					}
				}
			}
			if(projectJSON.has(ProjectJSONConstants.GOAL)) {
				JSONObject goalJSON = projectJSON.getJSONObject(ProjectJSONConstants.GOAL);
				//TODO: check if the goal is included in any running expeirment
				goalJSON.put(goal.getGoalLinkname(), ProjectJSONService.convertToJSON(goal));
				
			} else {
				JSONObject goalJSON = new JSONObject();
				//TODO: check if the goal is included in any running expeirment
				goalJSON.put(goal.getGoalLinkname(), ProjectJSONService.convertToJSON(goal));
				projectJSON.put(ProjectJSONConstants.GOAL, goalJSON);
			}
			ProjectJSONService.updateProjectJSON(projectId, dbspace, projectJSON.toString());
		}
	}
	
	//Audience events
		private static void onAudienceCreation(Audience audience, String dbspace) {
			ZABUtil.setDBSpace(dbspace);
			
		}
		
		public static Boolean doesAudienceExists(String linkname, JSONArray audienceArray) throws JSONException {
			if(audienceArray!=null) {
				for(int i=0; i<audienceArray.length(); i++) {
					if(audienceArray.getString(i).equals(linkname)) {
						return true;
					}
				}
			}
			return false;
		}
		
		public static void processAudienceCreationEvent(Audience audience, ArrayList<Experiment> experiments, String dbspace) throws Exception {
			int size = experiments.size();
			if(size > 0) {				
				Long projectId = audience.getProjectId();
				JSONObject projectJSON = ProjectJSONService.getProjectJSON(dbspace, projectId);
				for(int i=0; i<size; i++) {
					Experiment experiment = experiments.get(i);
					if(projectJSON.has(ProjectJSONConstants.EXPERIMENT)) {
						JSONObject experimentJSON = projectJSON.getJSONObject(ProjectJSONConstants.EXPERIMENT);
						if(experimentJSON.has(experiment.getExperimentUrl())) {
							JSONObject exArray =  experimentJSON.getJSONObject(experiment.getExperimentUrl());
							if(exArray.has(experiment.getExperimentLinkname())) {
								JSONObject exObj = exArray.getJSONObject(experiment.getExperimentLinkname());
								if(exObj.has(ProjectJSONConstants.GOAL)) {
									JSONArray audienceArray = exObj.getJSONArray(ProjectJSONConstants.GOAL);
									if(!doesAudienceExists(audience.getAudienceLinkName(), audienceArray)) {									
										audienceArray.put(audience.getAudienceLinkName());
									}
								} else {
									JSONArray audienceArray = new JSONArray();
									audienceArray.put(audience.getAudienceLinkName());
									exObj.put(ProjectJSONConstants.AUDIENCE, audienceArray);
								}
							}
						}
					}
				}
				if(projectJSON.has(ProjectJSONConstants.AUDIENCE)) {
					JSONObject audienceJSON = projectJSON.getJSONObject(ProjectJSONConstants.AUDIENCE);
					//TODO: check if the goal is included in any running expeirment
					audienceJSON.put(audience.getAudienceLinkName(), ProjectJSONService.convertToJSON(audience));
					
				} else {
					JSONObject audienceJSON = new JSONObject();
					//TODO: check if the goal is included in any running expeirment
					audienceJSON.put(audience.getAudienceLinkName(), ProjectJSONService.convertToJSON(audience));
					projectJSON.put(ProjectJSONConstants.AUDIENCE, audienceJSON);
				}
				ProjectJSONService.updateProjectJSON(projectId, dbspace, projectJSON.toString());
			}
		}
		
		
		private static void onAudienceUpdation(Audience audience, String dbspace) {
			ZABUtil.setDBSpace(dbspace);
			try {
					Long projectId = audience.getProjectId();
					JSONObject projectJSON = ProjectJSONService.getProjectJSON(dbspace, projectId);
//					ArrayList<Experiment> experiments = ExperimentGoal.getRunningExperimentsForGoal(goal.getGoalId(), projectId);
					//if there is no running experiments, dont do any update.
//					if(!experiments.isEmpty()) {					
						if(projectJSON.has(ProjectJSONConstants.AUDIENCE)) {
							JSONObject audienceJSON = projectJSON.getJSONObject(ProjectJSONConstants.AUDIENCE);
							if(audienceJSON.has(audience.getAudienceLinkName())) {							
								audienceJSON.put(audience.getAudienceLinkName(), ProjectJSONService.convertToJSON(audience));
							}
						}
						ProjectJSONService.updateProjectJSON(projectId, dbspace, projectJSON.toString());
//					}
			} catch (Exception e) {
				LOGGER.log(Level.SEVERE, e.getMessage(),e);
			}
		}
		
		private static void onAudienceDeletion(Audience audience, String dbspace) {
			ZABUtil.setDBSpace(dbspace);
			try {
					Long projectId = audience.getProjectId();
					JSONObject projectJSON = ProjectJSONService.getProjectJSON(dbspace, projectId);
					deleteAudienceFromJSON(audience.getAudienceLinkName(), projectJSON);
					ArrayList<Experiment> experiments = audience.getExperiments();
					int size = experiments.size();
					for(int i=0; i<size; i++) {
						Experiment experiment = experiments.get(i);
						removeAudienceFromExperiment(experiment, audience.getAudienceLinkName(), projectJSON);
					}
					ProjectJSONService.updateProjectJSON(projectId, dbspace, projectJSON.toString());
			} catch (Exception e) {
				LOGGER.log(Level.SEVERE, e.getMessage(),e);
			}
		}
		
		private static void removeAudienceFromExperiment(Experiment experiment, String audienceLinkname, JSONObject projectJSON) throws JSONException {
			if(projectJSON.has(ProjectJSONConstants.EXPERIMENT)) {
				JSONObject experimentJSON = projectJSON.getJSONObject(ProjectJSONConstants.EXPERIMENT);
				if(experimentJSON.has(experiment.getExperimentUrl())) {
					JSONObject exArray =  experimentJSON.getJSONObject(experiment.getExperimentUrl());
					if(exArray.has(experiment.getExperimentLinkname())) {
						JSONObject exObj = exArray.getJSONObject(experiment.getExperimentLinkname());
						if(exObj.has(ProjectJSONConstants.AUDIENCE)) {
							JSONArray audienceArray = exObj.getJSONArray(ProjectJSONConstants.AUDIENCE);
							JSONArray newJSON = new JSONArray();
							for(int j=0; j<audienceArray.length(); j++) {
								if(!audienceArray.getString(j).equals(audienceLinkname)) {
									newJSON.put(audienceArray.getString(j));
								}
							}
							exObj.put(ProjectJSONConstants.AUDIENCE, newJSON);
						}
					}
				}
			}
		}

		private static void deleteAudienceFromJSON(String linkname, JSONObject projectJSON) throws JSONException {
			if(projectJSON.has(ProjectJSONConstants.AUDIENCE)) {
				JSONObject audienceJSON = projectJSON.getJSONObject(ProjectJSONConstants.AUDIENCE);
				audienceJSON.remove(linkname);
			}
		}
	
		private static void onExperimentAudienceCreation(ExperimentAudience eAudience, String dbspace) {
			try {			
				ZABUtil.setDBSpace(dbspace);
				Audience audience = Audience.getAudienceById(eAudience.getAudienceId(),null);
				Long projectId = audience.getProjectId();
				if(projectId!=null) {				
					Experiment experiment = Experiment.getExperimentById(eAudience.getExperimentId());
					if(experiment!=null && experiment.getExperimentStatus()!=null && ExperimentStatus.RUNNING.getStatusCode().equals(experiment.getExperimentStatus())) {					
//						processGoalCreationEvent(goal, experiments, dbspace);
						JSONObject projectJSON = ProjectJSONService.getProjectJSON(dbspace, projectId);
						if(projectJSON.has(ProjectJSONConstants.EXPERIMENT)) {
							JSONObject experimentJSON = projectJSON.getJSONObject(ProjectJSONConstants.EXPERIMENT);
							if(experimentJSON.has(experiment.getExperimentUrl())) {
								JSONObject exArray =  experimentJSON.getJSONObject(experiment.getExperimentUrl());
								if(exArray.has(experiment.getExperimentLinkname())) {
									JSONObject exObj = exArray.getJSONObject(experiment.getExperimentLinkname());
									if(exObj.has(ProjectJSONConstants.AUDIENCE)) {
										JSONArray audienceArray = exObj.getJSONArray(ProjectJSONConstants.GOAL);
										if(!doesGoalExists(audience.getAudienceLinkName(), audienceArray)) {									
											audienceArray.put(audience.getAudienceLinkName());
										}
									} else {
										JSONArray audienceArray = new JSONArray();
										audienceArray.put(audience.getAudienceLinkName());
										exObj.put(ProjectJSONConstants.AUDIENCE, audienceArray);
									}
								}
							}
						}
						
						if(projectJSON.has(ProjectJSONConstants.AUDIENCE)) {
							JSONObject audienceJSON = projectJSON.getJSONObject(ProjectJSONConstants.AUDIENCE);
							audienceJSON.put(audience.getAudienceLinkName(), ProjectJSONService.convertToJSON(audience));
							
						} else {
							JSONObject audienceJSON = new JSONObject();
							audienceJSON.put(audience.getAudienceLinkName(), ProjectJSONService.convertToJSON(audience));
							projectJSON.put(ProjectJSONConstants.GOAL, audienceJSON);
						}
						ProjectJSONService.updateProjectJSON(projectId, dbspace, projectJSON.toString());
					}
				}
				
			} catch (Exception e) {
				LOGGER.log(Level.SEVERE, e.getMessage(),e);
			}
		}
		
		private static void onExperimentAudienceUpdation(ExperimentAudience eAudience, String dbspace) {
			try {			
				ZABUtil.setDBSpace(dbspace);
				Audience audience = Audience.getAudienceById(eAudience.getAudienceId(),null);
				Long projectId = audience.getProjectId();
				//Only thing that we can update in experiment goal is "is_primary"
				if(projectId!=null && eAudience.getIsPrimary()) {					
					Experiment experiment = Experiment.getExperimentById(eAudience.getExperimentId());
					JSONObject projectJSON = ProjectJSONService.getProjectJSON(dbspace, projectId);
					if(projectJSON.has(ProjectJSONConstants.EXPERIMENT)) {
						JSONObject experimentJSON = projectJSON.getJSONObject(ProjectJSONConstants.EXPERIMENT);
						if(experimentJSON.has(experiment.getExperimentUrl())) {
							JSONObject exArray =  experimentJSON.getJSONObject(experiment.getExperimentUrl());
							if(exArray.has(experiment.getExperimentLinkname())) {
								JSONObject expObj = exArray.getJSONObject(experiment.getExperimentLinkname());
								expObj.put(ProjectJSONConstants.PRIMARY_GOAL, audience.getAudienceLinkName());
							}
						}
					}
					ProjectJSONService.updateProjectJSON(projectId, dbspace, projectJSON.toString());
				}
				
			} catch (Exception e) {
				LOGGER.log(Level.SEVERE, e.getMessage(),e);
			}
		}
		
		private static void onExperimentAudienceDeletion(ExperimentAudience eAudience, String dbspace) {
			try {			
				ZABUtil.setDBSpace(dbspace);
				Experiment experiment = Experiment.getExperimentById(eAudience.getExperimentId());
				Long projectId = experiment.getProjectId();
				JSONObject projectJSON = ProjectJSONService.getProjectJSON(dbspace, projectId);
				String goalLinkname = Goal.getGoalLinknameForGoal(eAudience.getAudienceId());
				removeGoalFromExpeirment(experiment, goalLinkname, projectJSON);
				ArrayList<Experiment> experiments = ExperimentGoal.getRunningExperimentsForGoal(eAudience.getAudienceId(), projectId);
				if(experiments.size() == 0) {
					if(goalLinkname!=null) {					
						deleteGoalFromJSON(goalLinkname, projectJSON);
					}
				}
				ProjectJSONService.updateProjectJSON(projectId, dbspace, projectJSON.toString());
			} catch (Exception e) {
				LOGGER.log(Level.SEVERE, e.getMessage(),e);
			}
		}*/
		
}
