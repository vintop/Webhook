//$Id$
package com.zoho.abtest.project;

public class ProjectTreeEventConstants {
	
	public static final String EVENT_MODULE_NAME = "ProjectTreeEventListener"; //No I18N
	
	public static enum OperationType {
		CREATE,
		UPDATE,
		DELETE
	}
	
	public static enum Module {
		PROJECT,
		EXPERIMENT,
		EXPERIMENT_GOAL,
		VARIATION,
		GOAL,
		AUDIENCE,
		EXPERIMENT_AUDIENCE,
		EXPERIMENT_DYNAMIC_ATTRIBUTE,
		PROJECT_INTEGRATION,
		EXPERIMENT_INTEGRATION,
		DYNAMIC_ATTRIBUTE,
		CUSTOM_EVENT,
		PRIVACY_CONSENT
	}
	
}
