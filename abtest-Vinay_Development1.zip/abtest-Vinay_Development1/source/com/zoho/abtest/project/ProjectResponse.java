//$Id$
package com.zoho.abtest.project;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.experiment.ExperimentResponse;
import com.zoho.abtest.user.ZABUser;
import com.zoho.abtest.user.ZABUserConstants;
import com.zoho.abtest.utility.ZABUtil;

public class ProjectResponse {
	
	private static final Logger LOGGER = Logger.getLogger(ProjectResponse.class.getName());
	
	public static String usageStatsJsonResponse(HttpServletRequest request,ArrayList<Project> lst) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(lst);			
			JSONObject json = ZABResponse.updateMetaInfo(request, ProjectConstants.API_MODULE_USAGE, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){}
		return returnBuffer.toString();
	}
	
	public static String jsonResponse(HttpServletRequest request,ArrayList<Project> lst) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(lst);			
			JSONObject json = ZABResponse.updateMetaInfo(request, ProjectConstants.API_MODULE_PLURAL, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){}
		return returnBuffer.toString();
	}
	
	private static JSONObject getJSONObject(Project ld) throws JSONException {
		JSONObject jsonObj = new JSONObject();
		
		LOGGER.log(Level.INFO, ">> Project ID in response:"+ld.getProjectId());
		
		if(ld.getProjectId() != null) {
			jsonObj.put(ProjectConstants.PROJECT_ID, ld.getProjectId().toString());
		}
		
		jsonObj.put(ProjectConstants.PROJECT_NAME, ld.getProjectName());
		jsonObj.put(ProjectConstants.PROJECT_STATUS, ld.getProjectStatus());
		jsonObj.put(ProjectConstants.PROJECT_TYPE, ld.getProjectType());
		jsonObj.put(ZABConstants.LINKNAME, ld.getProjectLinkName());
		jsonObj.put(ProjectConstants.SCRIPT_URL, ld.getScriptUrl());
		jsonObj.put(ProjectConstants.ALT_SCRIPT_URL, ld.getAltScriptUrl());
		jsonObj.put(ProjectConstants.PROJECT_KEY, ld.getProjectKey());
		jsonObj.put(ProjectConstants.PROJECT_DESCRIPTION, ld.getDescription());
		jsonObj.put(ProjectConstants.USER_ROLE_LINK_NAME, ld.getUserRoleLinkName());
		jsonObj.put(ZABUserConstants.CREATED_TIME, ZABUtil.getDateTimeFormatted(ld.getCreatedTime()));
		jsonObj.put(ZABUserConstants.MODIFIED_TIME,ZABUtil.getDateTimeFormatted(ld.getModifiedTime()));
		//jsonObj.put(ZABUserConstants.CREATED_BY, ZABUser.getUserName(ld.getCreatedById()));
		jsonObj.put(ZABUserConstants.CREATED_BY, ld.getCreatedByName());
		jsonObj.put(ProjectConstants.SCRIPT_INCLUDED_WARNING, ld.getScriptIncludedWarning());
		jsonObj.put(ProjectConstants.TOTAL_EXPERIMENTS, ld.getTotalExperiments());
		jsonObj.put(ProjectConstants.RUNNING_EXPERIMENTS, ld.getRunningExperiments());
		
//		 This is a temporary and cruft way to flag a feature. will be removed soon.
		jsonObj.put("enablesr", ld.isSessionRecordingEnabled());
		
		if(!ld.getExperiments().isEmpty()) {
			jsonObj.put(ProjectConstants.EXPERIMENT, ExperimentResponse.getJSONArray(ld.getExperiments()));
		}
		
		if(!ld.getIpFilters().isEmpty()) {
			JSONArray array = new JSONArray();
			for(ProjectIPFilter filter:ld.getIpFilters()) {
				JSONObject obj = new JSONObject();
				obj.put(ProjectConstants.IP_FILTER_FROM, filter.getFromValue());
				obj.put(ProjectConstants.IP_FILTER_TO, filter.getToValue());
				obj.put(ProjectConstants.IP_FILTER_VALUE, filter.getValue());
				obj.put(ProjectConstants.IP_FILTER_MATCH_TYPE, filter.getMatchType());
				obj.put(ZABConstants.DISPLAY_NAME, filter.getDisplayName());
				array.put(obj);
			}
			jsonObj.put(ProjectConstants.IP_FILTERS, array);
		}
		jsonObj.put(ProjectConstants.EXISTING_PROJECTS_COUNT, ld.getExistingProjectsCount());
		jsonObj.put(ProjectConstants.ALLOWED_PROJECTS_COUNT, ld.getAllowedProjectsCount());
		jsonObj.put(ProjectConstants.REMAINING_DAYS, ld.getRemainingDays());
		jsonObj.put(ProjectConstants.TOTAL_NUMBER_OF_VISITORS, ld.getTotalNumberOfVisitors());
		jsonObj.put(ProjectConstants.TOTAL_NUMBER_OF_VISITORS_EXPERIMENTED, ld.getTotalNumberOfVisitorsExperimented());
		//jsonObj.put(ProjectConstants.TOTAL_NUMBER_OF_VISITORS_EXPERIMENTED_FOR_PROJECT,ld.getTotalNumberOfVisitorsExperimentedForProject());
		jsonObj.put(ProjectConstants.TOTAL_NUMBER_OF_DAYS,ld.getTotalNumberOfDaysAvailable());
		jsonObj.put(ProjectConstants.PORTAL,ld.getPortal());
		jsonObj.put(ProjectConstants.USAGE_LINK,ld.getId());


		jsonObj.put(ProjectConstants.PORTAL_STATUS_FLAG,ld.getPortalStatusFlag());

		jsonObj.put(ZABConstants.RESPONSE_STRING, ld.getResponseString());
		jsonObj.put(ZABConstants.STATUS_CODE, ld.getResponseCode());
		jsonObj.put(ZABConstants.SUCCESS, ld.getSuccess());
		
		LOGGER.log(Level.INFO, "Project response json:"+ld.getProjectId());
		
		return jsonObj;
	}
	
	public static JSONArray getJSONArray(ArrayList<Project> lst) throws JSONException {
		JSONArray array = new JSONArray();
		int size =lst.size();
		for (int i=0;i<size;i++) {
			Project ld=lst.get(i);
			if(ld!=null) {				
				array.put(getJSONObject(ld));
			}
		}
		return array;
	}
}
