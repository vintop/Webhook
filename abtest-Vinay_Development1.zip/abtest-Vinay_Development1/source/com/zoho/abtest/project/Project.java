//$Id$
package com.zoho.abtest.project;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.TransactionManager;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.DataSet;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.ds.query.SelectQueryImpl;
import com.adventnet.ds.query.SortColumn;
import com.adventnet.ds.query.Table;
import com.adventnet.iam.IAMUtil;
import com.adventnet.iam.User;
import com.adventnet.mfw.bean.BeanUtil;
import com.adventnet.persistence.DataAccess;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.GOAL;
import com.zoho.abtest.LICENSE_DETAIL;
import com.zoho.abtest.PORTAL_LICENSE_MAPPING;
import com.zoho.abtest.PORTAL_LICENSE_YEARLY_DETAIL;
import com.zoho.abtest.PROJECT;
import com.zoho.abtest.PROJECT_IPFILTER;
import com.zoho.abtest.PROJECT_SETTINGS;
import com.zoho.abtest.PROJECT_USER_ROLE;
import com.zoho.abtest.ROLES;
import com.zoho.abtest.adminconsole.AdminConsoleConstants;
import com.zoho.abtest.adminconsole.AdminConsoleHandler;
import com.zoho.abtest.adminconsole.AdminConsoleWrapper;
import com.zoho.abtest.adminconsole.AdminConsoleConstants.AcOperationType;
import com.zoho.abtest.cdn.ZABCDN;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.eventactivity.EventActivityConstants;
import com.zoho.abtest.eventactivity.EventActivityConstants.Module;
import com.zoho.abtest.eventactivity.EventActivityWrapper;
import com.zoho.abtest.eventactivity.EventModuleDetail;
import com.zoho.abtest.exception.ResourceNotFoundException;
import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentStatus;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentType;
import com.zoho.abtest.goal.GoalConstants.GoalStatus;
import com.zoho.abtest.license.LicenseVerification;
import com.zoho.abtest.license.PortalLicenseAddon;
import com.zoho.abtest.license.PortalLicenseMapping;
import com.zoho.abtest.listener.ZABNotifier;
import com.zoho.abtest.privacyconsent.Privacy;
import com.zoho.abtest.project.ProjectConstants.IPMatchType;
import com.zoho.abtest.project.ProjectConstants.ProjectStatus;
import com.zoho.abtest.project.ProjectConstants.ProjectType;
import com.zoho.abtest.project.ProjectTreeEventConstants.OperationType;
import com.zoho.abtest.user.ProjectUserRole;
import com.zoho.abtest.user.ProjectUserRoleConstants;
import com.zoho.abtest.user.Role;
import com.zoho.abtest.user.RoleConstants.UserRoles;
import com.zoho.abtest.user.ZABUser;
import com.zoho.abtest.user.ZABUserConstants;
import com.zoho.abtest.user.ZABUserDetailWrapper;
import com.zoho.abtest.utility.ApplicationProperty;
import com.zoho.abtest.utility.FileUtil;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.conf.Configuration;

public class Project extends ZABModel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(Project.class.getName());
	private String id;
	private String portal;
	private Long projectId;
	private String projectName;
	private String projectLinkName;
	private String projectKey;
	private Integer projectType;
	private Integer projectStatus;
	private ArrayList<Experiment> experiments = new ArrayList<Experiment>();
	private String description;
	private Long createdTime;
	private Long modifiedTime;
	private Boolean scriptIncludedWarning;
	private Long createdById;
	private String createdByName;
	private Integer totalExperiments;
	private Integer runningExperiments;
	private String scriptUrl;
	private String altScriptUrl;
	private String userRoleLinkName;
	private Integer existingProjectsCount;
	private Integer allowedProjectsCount;
	private Long remainingDays;
	private Long totalNumberOfVisitors;
	private Long totalNumberOfVisitorsExperimented;
	private Integer portalStatusFlag;
	private Integer totalNumberOfDaysAvailable;
	private JSONArray totalNumberOfVisitorsExperimentedForProject;
	
	private final Long pageSenseProjectId = ApplicationProperty.getLong("com.abtest.pagesense.projectid"); //NO I18N
	ArrayList<ProjectIPFilter> ipFilters = new ArrayList<ProjectIPFilter>();
	
	
	public String getAltScriptUrl() {
		return altScriptUrl;
	}

	public void setAltScriptUrl(String altScriptUrl) {
		this.altScriptUrl = altScriptUrl;
	}

	public Boolean getScriptIncludedWarning() {
		return scriptIncludedWarning;
	}

	public void setScriptIncludedWarning(Boolean scriptIncludedWarning) {
		this.scriptIncludedWarning = scriptIncludedWarning;
	}

	/**
	 * @return
	 * This is a temporary and cruft way to flag a feature. will be removed soon.
	 */
	public Boolean isSessionRecordingEnabled() {
		boolean enableSession = false;
		if (!ZABConstants.IS_PRODUCION_MODE
				|| (
						IAMUtil.getCurrentUser().getZOID() == AdminConsoleHandler.ZOHOCORP_ID
						&& this.getProjectId()!=null && this.getProjectId().equals(pageSenseProjectId)))
		{
			enableSession = true;
		}
		return enableSession;
	}
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPortal() {
		return portal;
	}

	public void setPortal(String portal) {
		this.portal = portal;
	}

	public Integer getTotalNumberOfDaysAvailable() {
		return totalNumberOfDaysAvailable;
	}

	public void setTotalNumberOfDaysAvailable(Integer totalNumberOfDaysAvailable) {
		this.totalNumberOfDaysAvailable = totalNumberOfDaysAvailable;
	}

	public Integer getPortalStatusFlag() {
		return portalStatusFlag;
	}

	public void setPortalStatusFlag(Integer portalStatusFlag) {
		this.portalStatusFlag = portalStatusFlag;
	}

	public JSONArray getTotalNumberOfVisitorsExperimentedForProject() {
		return totalNumberOfVisitorsExperimentedForProject;
	}

	public void setTotalNumberOfVisitorsExperimentedForProject(
			JSONArray totalNumberOfVisitorsExperimentedForProject) {
		this.totalNumberOfVisitorsExperimentedForProject = totalNumberOfVisitorsExperimentedForProject;
	}

	public Long getTotalNumberOfVisitorsExperimented() {
		return totalNumberOfVisitorsExperimented;
	}

	public void setTotalNumberOfVisitorsExperimented(
			Long totalNumberOfVisitorsExperimented) {
		this.totalNumberOfVisitorsExperimented = totalNumberOfVisitorsExperimented;
	}

	public Long getTotalNumberOfVisitors() {
		return totalNumberOfVisitors;
	}

	public void setTotalNumberOfVisitors(Long totalNumberOfVisitors) {
		this.totalNumberOfVisitors = totalNumberOfVisitors;
	}

	public Long getRemainingDays() {
		return remainingDays;
	}

	public void setRemainingDays(Long remainingDays) {
		this.remainingDays = remainingDays;
	}

	public Integer getExistingProjectsCount() {
		return existingProjectsCount;
	}

	public void setExistingProjectsCount(Integer existingProjectsCount) {
		this.existingProjectsCount = existingProjectsCount;
	}

	public Integer getAllowedProjectsCount() {
		return allowedProjectsCount;
	}

	public void setAllowedProjectsCount(Integer allowedProjectsCount) {
		this.allowedProjectsCount = allowedProjectsCount;
	}

	public String getUserRoleLinkName() {
		return userRoleLinkName;
	}

	public void setUserRoleLinkName(String userRoleLinkName) {
		this.userRoleLinkName = userRoleLinkName;
	}

	public String getProjectKey() {
		return projectKey;
	}

	public void setProjectKey(String projectKey) {
		this.projectKey = projectKey;
	}
	public Integer getTotalExperiments() {
		return totalExperiments;
	}

	public void setTotalExperiments(Integer totalExperiments) {
		this.totalExperiments = totalExperiments;
	}

	public Integer getRunningExperiments() {
		return runningExperiments;
	}

	public void setRunningExperiments(Integer runningExperiments) {
		this.runningExperiments = runningExperiments;
	}

	public String getProjectLinkName() {
		return projectLinkName;
	}

	public void setProjectLinkName(String projectLinkName) {
		this.projectLinkName = projectLinkName;
	}

	public Long getProjectId() {
		return projectId;
	}

	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	
	public ArrayList<Experiment> getExperiments() {
		return experiments;
	}

	public void setExperiments(ArrayList<Experiment> experiments) {
		this.experiments = experiments;
	}
	
	public Integer getProjectType() {
		return projectType;
	}

	public void setProjectType(Integer projectType) {
		this.projectType = projectType;
	}

	public Integer getProjectStatus() {
		return projectStatus;
	}

	public void setProjectStatus(Integer projectStatus) {
		this.projectStatus = projectStatus;
	}
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Long getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Long createdTime) {
		this.createdTime = createdTime;
	}

	public Long getModifiedTime() {
		return modifiedTime;
	}

	public void setModifiedTime(Long modifiedTime) {
		this.modifiedTime = modifiedTime;
	}

	public Long getCreatedById() {
		return createdById;
	}

	public void setCreatedById(Long createdById) {
		this.createdById = createdById;
	}

	public String getCreatedByName() {
		return createdByName;
	}

	public void setCreatedByName(String createdByName) {
		this.createdByName = createdByName;
	}

	public String getScriptUrl() {
		return scriptUrl;
	}

	public void setScriptUrl(String scriptUrl) {
		this.scriptUrl = scriptUrl;
	}

	public ArrayList<ProjectIPFilter> getIpFilters() {
		return ipFilters;
	}

	public void setIpFilters(ArrayList<ProjectIPFilter> ipFilters) {
		this.ipFilters = ipFilters;
	}

	public static Project getProjectFromRow(Row row) {
		Project project = new Project();
		project.setSuccess(Boolean.TRUE);
		LOGGER.log(Level.INFO, ">> Project ID before casting:"+row.get(PROJECT.PROJECT_ID));
		LOGGER.log(Level.INFO, ">> Project ID:"+(Long)row.get(PROJECT.PROJECT_ID));
		LOGGER.log(Level.INFO, ">> Project ROW:"+row);
		project.setProjectId((Long)row.get(PROJECT.PROJECT_ID));
		project.setProjectName((String)row.get(PROJECT.PROJECT_NAME));
		project.setProjectType((Integer)row.get(PROJECT.PROJECT_TYPE));
		project.setProjectStatus((Integer)row.get(PROJECT.STATUS));
		project.setProjectLinkName((String)row.get(PROJECT.PROJECT_LINK_NAME));
		project.setProjectKey((String)row.get(PROJECT.PROJECT_KEY));
		project.setDescription((String)row.get(PROJECT.PROJECT_DESCRIPTION));
		project.setCreatedById((Long)row.get(PROJECT.CREATED_BY));
		project.setCreatedTime((Long)row.get(PROJECT.CREATED_TIME));
		project.setModifiedTime((Long)row.get(PROJECT.MODIFIED_TIME));
		project.setScriptIncludedWarning((Boolean)row.get(PROJECT.SCRIPT_INCLUDED_WARNING));
		project.setScriptUrl(getProjectJsSnippetPrimaryUrl(project.getProjectKey()));
		project.setAltScriptUrl(Project.getProjectJsSnippetAltUrl(project.getProjectKey()));
		return project;
	}
	
	public static Project getProjectFromProjectRow(Row row) {
		Project project = new Project();
		project.setProjectId((Long)row.get(PROJECT.PROJECT_ID));
		return project;
	}
	
	public static Project getProjectFromDateSet(DataSet ds, Project project, String prefix) throws SQLException {
		project.setSuccess(Boolean.TRUE);
		project.setProjectId((Long)ds.getValue(prefix+PROJECT.PROJECT_ID));
		project.setProjectName((String)ds.getValue(prefix+PROJECT.PROJECT_NAME));
		project.setProjectType((Integer)ds.getValue(prefix+PROJECT.PROJECT_TYPE));
		project.setProjectStatus((Integer)ds.getValue(prefix+PROJECT.STATUS));
		project.setProjectLinkName((String)ds.getValue(prefix+PROJECT.PROJECT_LINK_NAME));
		project.setProjectKey((String)ds.getValue(prefix+PROJECT.PROJECT_KEY));
		project.setDescription((String)ds.getValue(prefix+PROJECT.PROJECT_DESCRIPTION));
		project.setCreatedById((Long)ds.getValue(prefix+PROJECT.CREATED_BY));
		project.setCreatedTime((Long)ds.getValue(prefix+PROJECT.CREATED_TIME));
		project.setModifiedTime((Long)ds.getValue(prefix+PROJECT.MODIFIED_TIME));
		project.setScriptUrl(getProjectJsSnippetPrimaryUrl(project.getProjectKey()));
		return project;
	}
	
	public static ArrayList<Project> getProjectFromDobj(DataObject dobj) throws DataAccessException {
		ArrayList<Project> projects = new ArrayList<Project>();
		if(dobj.containsTable(PROJECT.TABLE)) {
			Iterator<?> it = dobj.getRows(PROJECT.TABLE);
			while(it.hasNext()) {
				Row row = (Row)it.next();
				Project proj = getProjectFromRow(row);
				proj = getExperimentCountOfProject(proj);
				projects.add(proj);
			}
		}
		return projects;
	}
	
	public static ArrayList<Project> getProjectFromProjectDobj(DataObject dobj) throws DataAccessException {
		ArrayList<Project> projects = new ArrayList<Project>();
		if(dobj.containsTable(PROJECT.TABLE)) {
			Iterator<?> it = dobj.getRows(PROJECT.TABLE);
			while(it.hasNext()) {
				Row row = (Row)it.next();
				Project proj = getProjectFromProjectRow(row);
				projects.add(proj);
			}
		}
		return projects;
	}

	public static Project createProject(HashMap<String, String> hs) {
		Project project = null;
		TransactionManager tMgr = DataAccess.getTransactionManager();
		try {
			tMgr.begin();
			
			String displayName = hs.get(ProjectConstants.PROJECT_NAME);
			displayName = displayName.trim();
			if(displayName.length() == 0 ){
				throw new ZABException(ZABAction.getMessage(ProjectConstants.PROJECT_EMPTY_NAME,null));
			}
			Criteria c = new Criteria(new Column(PROJECT.TABLE, PROJECT.PROJECT_NAME), displayName, QueryConstants.EQUAL, Boolean.FALSE);
			if(resourceExists(PROJECT.TABLE, c)) {
				throw new ZABException(ZABAction.getMessage(ProjectConstants.PROJECT_ALREADY_EXISTS,new String[]{displayName}));
			}
			
			String linkName = generateLinkName(PROJECT.TABLE, PROJECT.PROJECT_LINK_NAME, null, null, displayName);
			hs.put(ZABConstants.LINKNAME, linkName);
			String projectKey = generateUniqueId(PROJECT.TABLE, PROJECT.PROJECT_KEY);
			hs.put(ProjectConstants.PROJECT_KEY, projectKey);
			hs.put(ZABUserConstants.CREATED_BY, ZABUtil.getCurrentUser().getUserId().toString());
			String time = ZABUtil.getCurrentTimeInMilliSeconds().toString();
			hs.put(ZABUserConstants.CREATED_TIME, time);
			hs.put(ZABUserConstants.MODIFIED_TIME, time);
			
			DataObject dobj = createRow(ProjectConstants.PROJECT_TABLE, PROJECT.TABLE, hs);
			Long projectId = (Long)dobj.getFirstValue(PROJECT.TABLE, PROJECT.PROJECT_ID);
			manageProjectUserRoleMapping(projectId);
			ArrayList<Project> projectRes = getProjectFromDobj(dobj);
			Privacy.createPrivacy(projectId);
			tMgr.commit();
			if(projectRes!=null && !projectRes.isEmpty()) {
				project = projectRes.get(0);
				project.setCreatedByName(ZABUtil.getCurrentUser().getName());
//				pro.setScriptUrl(createEmbedScript(pro.getProjectId()));
				//Creating default goals for the project
//				HashMap<String, String> goalMap = new HashMap<String, String>();
//				goalMap.put(GoalConstants.PROJECT_ID, project.getProjectId()+"");
//				goalMap.put(GoalConstants.GOAL_NAME, GoalConstants.ENGAGEMENT);
//				goalMap.put(GoalConstants.GOAL_TYPE, GoalType.ENGAGEMENT_GOAL.getGoalTypeId()+"");
//				Goal goal = Goal.createGoal(goalMap);
//				if(goal==null || !goal.getSuccess()) {
//					throw new ZABException("Error while creating goal"); //No I18N
//				}
//				
				ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
				wrapper.setModel(project);
				wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
				wrapper.setType(OperationType.CREATE);
				ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);
				
				
				//Saving the project display name for the use of event activity
				HashMap<String, String> eventModuleHs = new HashMap<String, String>();
				eventModuleHs.put(EventActivityConstants.MODULE_TYPE, Module.PROJECT.getValue().toString());
				eventModuleHs.put(EventActivityConstants.MODULE_ELEMENT_ID, project.getProjectId().toString());
				eventModuleHs.put(EventActivityConstants.MODULE_ELEMENT_NAME, project.getProjectName());
				EventModuleDetail.createEventModuleDetail(eventModuleHs);
				
				//Event Activity Log
				HashMap<String, String> updatedValues = new HashMap<String, String>();
				updatedValues.put(EventActivityConstants.PROJECT_ID, project.getProjectId().toString());
				updatedValues.put(EventActivityConstants.USER_ID, ZABUtil.getCurrentUser().getUserId().toString());
				updatedValues.put(EventActivityConstants.TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
				EventActivityWrapper activityWrapper = new EventActivityWrapper();
				activityWrapper.setModule(Module.PROJECT);
				activityWrapper.setOperationType(com.zoho.abtest.eventactivity.EventActivityConstants.OperationType.CREATE);
				activityWrapper.setDbSpace(ZABUtil.getCurrentUserDbSpace());
				activityWrapper.setUpdatedValues(updatedValues);
				ZABNotifier.notifyListeners(EventActivityConstants.EVENT_MODULE_NAME, activityWrapper);
				
				//Admin console record
				Long zuid = IAMUtil.getCurrentUser().getZUID();
				HashMap<String, String> acHs = new HashMap<String, String>();
				acHs.put(AdminConsoleConstants.PROJECT_ID, project.getProjectId().toString());
				acHs.put(AdminConsoleConstants.PROJECT_STATUS, project.getProjectStatus().toString());
				acHs.put(AdminConsoleConstants.ZSOID, ZABUtil.getDBSpace());
				acHs.put(AdminConsoleConstants.CREATED_ZUID, zuid.toString());
				acHs.put(AdminConsoleConstants.CREATED_TIME, project.getCreatedTime().toString());
				AdminConsoleWrapper acWrapper = new AdminConsoleWrapper();
				acWrapper.setValueHs(acHs);
				acWrapper.setOperationType(AcOperationType.PROJECT_CREATE);
				ZABNotifier.notifyListeners(AdminConsoleConstants.ADMIN_CONSOLE_MODULE_NAME,acWrapper);
			}
			
		} catch (ZABException e) {
			project = new Project();
			project.setSuccess(Boolean.FALSE);
			project.setResponseString(e.getMessage());
			try {
				tMgr.rollback();
			} catch (Exception e1) {
				LOGGER.log(Level.SEVERE, e1.getMessage(),e);
			} 
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		} catch (Exception e) {
			project = new Project();
			project.setSuccess(Boolean.FALSE);
			project.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			try {
				tMgr.rollback();
			} catch (Exception e1) {
				LOGGER.log(Level.SEVERE, e1.getMessage(),e);
			} 
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		return project;
	}
	
	public static void manageProjectUserRoleMapping(Long projectId)
	{
		try
		{
			Long userId = ZABUtil.getCurrentUser().getUserId();
			
			List<Long> adminIds = ZABUser.getAdminUserIds();
			Long adminRoleId = Role.getRoleIdByName(UserRoles.ADMIN.getRole());
			ArrayList<HashMap<String,String>> hsArray = new ArrayList<HashMap<String,String>>();
			for(Long adminId:adminIds)
			{
				HashMap<String,String> hsMap = new HashMap<String,String>();
				hsMap.put(ProjectUserRoleConstants.PROJECT_ID, projectId.toString());
				hsMap.put(ProjectUserRoleConstants.USER_ID, adminId.toString());
				hsMap.put(ProjectUserRoleConstants.ROLE_ID, adminRoleId.toString());
				hsArray.add(hsMap);
			}
			ProjectUserRole.createProjectUserRoleMapping(hsArray);
			
			if(!ZABUtil.getCurrentUser().getIsAdmin())
			{
				Long projAdminRoleId = Role.getRoleIdByName(UserRoles.PROJECTADMIN.getRole());
				HashMap<String,String> hsMap = new HashMap<String,String>();
				hsMap.put(ProjectUserRoleConstants.PROJECT_ID, projectId.toString());
				hsMap.put(ProjectUserRoleConstants.USER_ID, userId.toString());
				hsMap.put(ProjectUserRoleConstants.ROLE_ID, projAdminRoleId.toString());
				ProjectUserRole.createProjectUserRoleMapping(hsMap);
			}
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
	}
	
	public static boolean containsSchedOrRunnningExperiments(String projectLinkname) throws Exception {
		Criteria c = new Criteria(new Column(PROJECT.TABLE, PROJECT.PROJECT_LINK_NAME), projectLinkname, QueryConstants.EQUAL);
		Criteria c2 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_STATUS), new Integer[]{ExperimentStatus.SCHEDULED.getStatusCode(),ExperimentStatus.RUNNING.getStatusCode()}, QueryConstants.IN);
		Join join = new Join(PROJECT.TABLE, EXPERIMENT.TABLE, new String[]{PROJECT.PROJECT_ID}, new String[]{EXPERIMENT.PROJECT_ID}, Join.INNER_JOIN);
		DataObject dobj = getRow(PROJECT.TABLE, c.and(c2),join);
		return dobj.containsTable(PROJECT.TABLE);
	}
	
	public static boolean containsRunnningGoals(String projectLinkname) throws Exception {
		Criteria c = new Criteria(new Column(PROJECT.TABLE, PROJECT.PROJECT_LINK_NAME), projectLinkname, QueryConstants.EQUAL);
		Criteria c2 = new Criteria(new Column(GOAL.TABLE, GOAL.GOAL_STATUS), GoalStatus.RUNNING.getStatusCode(), QueryConstants.EQUAL);
		Join join = new Join(PROJECT.TABLE, GOAL.TABLE, new String[]{PROJECT.PROJECT_ID}, new String[]{GOAL.PROJECT_ID}, Join.INNER_JOIN);
		DataObject dobj = getRow(PROJECT.TABLE, c.and(c2),join);
		return dobj.containsTable(PROJECT.TABLE);
	}
	public static void updateIPFilter(Long projectId, JSONArray ipConfigs) throws Exception {
		Criteria cip = new Criteria(new Column(PROJECT_IPFILTER.TABLE, PROJECT_IPFILTER.PROJECT_ID), projectId, QueryConstants.EQUAL);
		deleteResource(cip);
		int length = ipConfigs.length();
		ArrayList<HashMap<String, String>> rows = new ArrayList<HashMap<String,String>>();
		for(int i = 0; i < length; i++) {
			JSONObject obj = ipConfigs.getJSONObject(i);
			HashMap<String, String> hs = ZABUtil.convertJSONToHashMap(obj);
			IPMatchType mt = IPMatchType.getIPMatchTypeByNumber(obj.getInt(ProjectConstants.IP_FILTER_MATCH_TYPE));
			if(mt.equals(IPMatchType.RANGE)) {
				hs.put(ProjectConstants.IP_FILTER_VALUE, hs.get(ProjectConstants.IP_FILTER_FROM)+","+hs.get(ProjectConstants.IP_FILTER_TO));
			}
			hs.put(ProjectConstants.PROJECT_ID, projectId+"");
			rows.add(hs);
		}
		createRow(ProjectConstants.PROJECT_IPFILTER_TABLE, PROJECT_IPFILTER.TABLE, rows);
	}
	
	public static Project updateProject(HashMap<String, String> hs) {
		Project project = null;
		TransactionManager mgr = null;
		try {
			mgr = DataAccess.getTransactionManager();
			mgr.begin();
			String linkname = hs.get(ZABConstants.LINKNAME);
			//Archive validation
			if(hs.containsKey(ProjectConstants.PROJECT_STATUS) &&
					ProjectStatus.ARCHIVE.getStatusNumber().toString().equals(hs.get(ProjectConstants.PROJECT_STATUS)) &&
					(containsSchedOrRunnningExperiments(linkname) || containsRunnningGoals(linkname))) {
				throw new ZABException(ZABAction.getMessage(ProjectConstants.PROJECT_ARCHIVE_VALIDATION_ERROR));
			}
			Project oldproj = Project.getProjectByLinkname(linkname);
			
			String displayName = hs.get(ProjectConstants.PROJECT_NAME);
			Criteria c1 = new Criteria(new Column(PROJECT.TABLE, PROJECT.PROJECT_NAME), displayName, QueryConstants.EQUAL);
			Criteria c2 = new Criteria(new Column(PROJECT.TABLE, PROJECT.PROJECT_ID), oldproj.getProjectId(), QueryConstants.NOT_EQUAL);
			if(resourceExists(PROJECT.TABLE, c1.and(c2))) {
				throw new ZABException(ZABAction.getMessage(ProjectConstants.PROJECT_ALREADY_EXISTS,new String[]{displayName}));
			}
			
			//Logging event activity purpose
			HashMap<String,String> oldValues = generateHashMapFromProjectObj(oldproj,hs);
			
			hs.put(ZABUserConstants.MODIFIED_TIME,  ZABUtil.getCurrentTimeInMilliSeconds().toString());
			Criteria c = new Criteria(new Column(PROJECT.TABLE, PROJECT.PROJECT_LINK_NAME), linkname, QueryConstants.EQUAL);
			ZABModel.updateRow(ProjectConstants.PROJECT_TABLE, PROJECT.TABLE, hs, c, ProjectConstants.API_MODULE);
			project = new Project();
			project.setSuccess(Boolean.TRUE);
			project.setProjectLinkName(linkname);
			project.setProjectId(oldproj.getProjectId());
			
			//Saving the project display name for the use of event activity
			if(hs.containsKey(ProjectConstants.IP_FILTERS))
			{
				updateIPFilter(oldproj.getProjectId(), new JSONArray(hs.get(ProjectConstants.IP_FILTERS)));
			}
			
			Long projectId = oldproj.getProjectId();
			//Saving the project display name for the use of event activity
			if(hs.containsKey(ProjectConstants.PROJECT_NAME))
			{
				HashMap<String, String> eventModuleHs = new HashMap<String, String>();
				eventModuleHs.put(EventActivityConstants.MODULE_ELEMENT_NAME, hs.get(ProjectConstants.PROJECT_NAME));
				EventModuleDetail.updateEventModuleDetail(eventModuleHs, Module.PROJECT.getValue(), projectId);
			}
			mgr.commit();
			//Event Activity Log
			HashMap<String, String> updatedValues = new HashMap<String, String>();
			updatedValues.putAll(hs);
			updatedValues.put(EventActivityConstants.PROJECT_ID, projectId.toString());
			updatedValues.put(EventActivityConstants.USER_ID, ZABUtil.getCurrentUser().getUserId().toString());
			updatedValues.put(EventActivityConstants.TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
			EventActivityWrapper activityWrapper = new EventActivityWrapper();
			activityWrapper.setModule(Module.PROJECT);
			activityWrapper.setOperationType(com.zoho.abtest.eventactivity.EventActivityConstants.OperationType.UPDATE);
			activityWrapper.setDbSpace(ZABUtil.getCurrentUserDbSpace());
			activityWrapper.setUpdatedValues(updatedValues);
			activityWrapper.setOldValues(oldValues);
			ZABNotifier.notifyListeners(EventActivityConstants.EVENT_MODULE_NAME, activityWrapper);
			
			//Admin console record
			if(hs.containsKey(ProjectConstants.PROJECT_STATUS))
			{
				HashMap<String, String> acHs = new HashMap<String, String>();
				acHs.put(AdminConsoleConstants.PROJECT_ID, projectId.toString());
				acHs.put(AdminConsoleConstants.PROJECT_STATUS, hs.get(ProjectConstants.PROJECT_STATUS));
				acHs.put(AdminConsoleConstants.ZSOID, ZABUtil.getDBSpace());
				AdminConsoleWrapper acWrapper = new AdminConsoleWrapper();
				acWrapper.setValueHs(acHs);
				acWrapper.setOperationType(AcOperationType.PROJECT_UPDATE);
				ZABNotifier.notifyListeners(AdminConsoleConstants.ADMIN_CONSOLE_MODULE_NAME,acWrapper);
		
				ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
				wrapper.setModel(project);
				wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
				wrapper.setType(OperationType.UPDATE);
				ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);
				
			}
			
		} catch(ZABException e) {
			project = new Project();
			project.setSuccess(Boolean.FALSE);
			project.setResponseString(e.getMessage());
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			if(mgr!=null) {
				try {
					mgr.rollback();
				} catch (Exception e1) {
					LOGGER.log(Level.SEVERE,"Exception Occurred",e1);
				}
			}
		} catch(ResourceNotFoundException re) {
			project = new Project();
			setModelWithRNFData(project, re);
			if(mgr!=null) {
				try {
					mgr.rollback();
				} catch (Exception e1) {
					LOGGER.log(Level.SEVERE,"Exception Occurred",e1);
				}
			}
		} catch (Exception e) {
			project = new Project();
			project.setSuccess(Boolean.FALSE);
			project.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			if(mgr!=null) {
				try {
					mgr.rollback();
				} catch (Exception e1) {
					LOGGER.log(Level.SEVERE,"Exception Occurred",e1);
				}
			}
		}
		return project;
	}
	
	public static String getProjectFileName(Long projectId, String portalName) throws Exception {
		String fileName = null;
		Criteria c = new Criteria(new Column(PROJECT.TABLE, PROJECT.PROJECT_ID), projectId, QueryConstants.EQUAL);
		DataObject dobj = getRow(PROJECT.TABLE, c);
		if(dobj.containsTable(PROJECT.TABLE)) {
			String projectKey = (String)dobj.getFirstRow(PROJECT.TABLE).get(PROJECT.PROJECT_KEY);
			fileName = getAbsoluteScriptUrl(projectKey, portalName);
		}
		
		return fileName;
	}
	
	private static String createEmbedScript(Long projectId) throws Exception {
		ZABCDN cdn = (ZABCDN)BeanUtil.lookup("ZABCDN");
		String fileName = projectId+".js"; //No I18N
		fileName = cdn.createFile(fileName, FileUtil.createFileObj(projectId, ProjectJSONService.getBasicJSON(ZABUtil.getDBSpace())), IAMUtil.getCurrentUser().getZUID(), ZABUtil.getDBSpace());
		Project.saveProjectFileNameMapping(fileName, projectId);
		return ApplicationProperty.getString(ZABConstants.SCRIPT_CDN)+fileName;
	}
	
//	private static void createEmbedScript(Long projectId) {
////		String filePath=Configuration.getString("zap.embedScript.location");
//		
////		String destFile=filePath+File.separator+projectId+".js"; //No I18N
////		String srcFile=filePath+File.separator+"scriptTemplate.js"; //No I18N
//		String srcFile=FileUtil.class.getResource("/../../../../"+Configuration.getString("zap.embedScript.location")+File.separator+Configuration.getString("zap.embedScript.name")).getPath(); //No I18N
//		String destFile=srcFile.replace(Configuration.getString("zap.embedScript.name"),  projectId+".js"); //No I18N
//		String srcFileContent=null;
//		try {
//			srcFileContent=FileUtil.readFile(srcFile);
//			srcFileContent=srcFileContent.replace("ZAB.spaceId=\"Test\"", "ZAB.spaceId=\""+ZABUtil.getDBSpace()+"\""); // No I18N
//		} catch (IOException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
//		
//		try {
//			FileUtil.updateFile(destFile, srcFileContent);
//			//new FileUtil().copyFile(srcFile, destFile);
//			HashMap<String, String> hs=new HashMap<String, String>();
//			hs.put(ProjectConstants.PROJECT_ID, projectId+"");
//			hs.put(ProjectConstants.JS_CONTENT_ZFS_ID, projectId+".js");
//			try {
//				 ZABModel.createRow(ProjectConstants.PROJECT_SETTINGS_TABLE, PROJECT_SETTINGS.TABLE, hs);
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//   }
	
	public static void saveProjectFileNameMapping(String fileName, Long projectId) {
		HashMap<String, String> hs=new HashMap<String, String>();
		hs.put(ProjectConstants.PROJECT_ID, projectId+"");
		hs.put(ProjectConstants.JS_CONTENT_ZFS_ID, fileName);
		try {
			 ZABModel.createRow(ProjectConstants.PROJECT_SETTINGS_TABLE, PROJECT_SETTINGS.TABLE, hs);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static ArrayList<Project> getProjectByCriteria(Criteria c) {
		ArrayList<Project> projects = new ArrayList<Project>();
		try {
			DataObject dobj = ZABModel.getRow(PROJECT.TABLE, c);
			projects.addAll(getProjectFromDobj(dobj));
		} catch (Exception e) {
			Project project = new Project();
			project.setSuccess(Boolean.FALSE);
			project.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			projects.add(project);
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		return projects;
	}
	
	public static ArrayList<Project> getProjectByCriteria(Criteria criteria,Join join) {
		ArrayList<Project> projects = new ArrayList<Project>();
		try {
			SortColumn sort = new SortColumn(new Column(PROJECT.TABLE, PROJECT.CREATED_TIME), Boolean.FALSE);
			DataObject dobj = ZABModel.getRow(PROJECT.TABLE, criteria, sort, new Join[]{join});
			projects.addAll(getProjectFromDobj(dobj));
			LOGGER.log(Level.INFO, "Getting user details for projects start");
			ZABUser.setUserDetails(projects, new ZABUserDetailWrapper() {
				
				@Override
				public void setUserDetails(User user, ZABModel model) {
					Project project = (Project)model;
					project.setCreatedByName(user.getFirstName() + " " + user.getLastName());
				}
				
				@Override
				public Long getUserId(ZABModel model) {
					Project project = (Project)model;
					return project.getCreatedById();
				}
			});
			LOGGER.log(Level.INFO, "Getting user details for projects end");
		} catch (Exception e) {
			Project project = new Project();
			project.setSuccess(Boolean.FALSE);
			project.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			projects.add(project);
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		return projects;
	}
	
	public static ArrayList<Project> getProjects() throws Exception{
		Table projectTable = new Table(PROJECT.TABLE);
		SelectQuery selectQuery = new SelectQueryImpl(projectTable);
		selectQuery.addSelectColumn(new Column(PROJECT.TABLE,"*"));
		DataObject dobj = ZABModel.getResource(selectQuery);
		return getProjectFromDobj(dobj);
	}
	
	public static ArrayList<Project> getProjects(Long userId) {
		LOGGER.log(Level.INFO,"  TRYING T GET PROJECT INFORMATION");
		HttpServletRequest request = ZABUtil.getCurrentRequest();
		String projectStatus =(String) request.getParameter(ProjectConstants.PROJECT_STATUS);
		String projectType =(String) request.getParameter(ProjectConstants.PROJECT_TYPE);
		Criteria c = null;

		try{
			if(projectStatus!=null && ProjectStatus.getProjectStatusByNumber(Integer.parseInt(projectStatus))!=null) {
				c= new Criteria (new Column(PROJECT.TABLE,PROJECT.STATUS),projectStatus,QueryConstants.EQUAL);

			}
		}catch(Exception e){
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		try{
			if(projectType!=null && ProjectType.getProjectTypeByNumber(Integer.parseInt(projectType))!=null) {
				if(c==null){
					c= new Criteria (new Column(PROJECT.TABLE,PROJECT.PROJECT_TYPE),projectType,QueryConstants.EQUAL);
				}else{
					c=c.and( new Criteria (new Column(PROJECT.TABLE,PROJECT.PROJECT_TYPE),projectType,QueryConstants.EQUAL));
				}
			}
		}catch(Exception e){
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		Long currentUserId = null;
		if(ZABUtil.getCurrentUser() != null)
		{
			currentUserId = ZABUtil.getCurrentUser().getUserId();
		}
		else if(userId != null)
		{
			currentUserId = userId;
		}
		
		Criteria userCriteria = new Criteria (new Column(PROJECT_USER_ROLE.TABLE,PROJECT_USER_ROLE.USER_ID),currentUserId,QueryConstants.EQUAL);
		if(c==null)
		{
			c = userCriteria;
		}
		else
		{
			c.and(userCriteria);
		}
		Join join = new Join(PROJECT.TABLE, PROJECT_USER_ROLE.TABLE, new String[]{PROJECT.PROJECT_ID}, new String[]{PROJECT_USER_ROLE.PROJECT_ID}, Join.INNER_JOIN);
		
		return getProjectByCriteria(c,join);
	}
	
	public static Long getProjectId(String linkName) {
		Criteria c = new Criteria(new Column(PROJECT.TABLE, PROJECT.PROJECT_LINK_NAME), linkName, QueryConstants.EQUAL);
		ArrayList<Project> projects = getProjectByCriteria(c);
		if(!projects.isEmpty() && projects.get(0).getSuccess()) {
			return projects.get(0).getProjectId();
		}
		return null;
	}
	
	public static Project getProjectBasicDetails(String linkName) {
		Project project = null;
		Criteria c = new Criteria(new Column(PROJECT.TABLE, PROJECT.PROJECT_LINK_NAME), linkName, QueryConstants.EQUAL);
		try
		{
			DataObject dobj = ZABModel.getRow(PROJECT.TABLE, c);
			Row row = dobj.getFirstRow(PROJECT.TABLE);
			if(row != null)
			{
				Long projectId = (Long)row.get(PROJECT.PROJECT_ID);
				String projectName = (String)row.get(PROJECT.PROJECT_NAME);
				String projectKey = (String)row.get(PROJECT.PROJECT_KEY);
				project = new Project();
				project.setProjectId(projectId);
				project.setProjectName(projectName);
				project.setProjectKey(projectKey);
			}
		}
		catch(Exception e)
		{
			project = null;
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		return project;
	}
	
	public static Project getUserProjectByLinkname(String linkName) {
		Project project = null;
		try {
			Long currentUserId = ZABUtil.getCurrentUser().getUserId();
			Criteria c = new Criteria(new Column(PROJECT.TABLE, PROJECT.PROJECT_LINK_NAME), linkName, QueryConstants.EQUAL);
			Criteria c2 = new Criteria(new Column(PROJECT_USER_ROLE.TABLE, PROJECT_USER_ROLE.USER_ID), currentUserId, QueryConstants.EQUAL);
			Join join1=new Join(PROJECT.TABLE,PROJECT_USER_ROLE.TABLE,new String[]{PROJECT.PROJECT_ID},new String[]{PROJECT_USER_ROLE.PROJECT_ID},Join.LEFT_JOIN);
			Join join2=new Join(PROJECT_USER_ROLE.TABLE,ROLES.TABLE,new String[]{PROJECT_USER_ROLE.ROLE_ID},new String[]{ROLES.ROLE_ID},Join.INNER_JOIN);
			Join join3=new Join(PROJECT.TABLE,PROJECT_IPFILTER.TABLE,new String[]{PROJECT.PROJECT_ID},new String[]{PROJECT_IPFILTER.PROJECT_ID},Join.LEFT_JOIN);
			DataObject dobj = getRow(PROJECT.TABLE, c.and(c2),new Join[]{join1,join2, join3});
			if(dobj.containsTable(PROJECT.TABLE)) {
				Iterator<?> it = dobj.getRows(PROJECT.TABLE);
				if(it.hasNext()) {
					Row row = (Row)it.next();
					project = getProjectFromRow(row);
					project = getExperimentCountOfProject(project);
					String roleLinkName = (String)dobj.getFirstValue(ROLES.TABLE, ROLES.ROLE_LINK_NAME);
					project.setUserRoleLinkName(roleLinkName);
					project.setIpFilters(getModelsFromDobj(dobj, PROJECT_IPFILTER.TABLE, ProjectIPFilter.class, Boolean.TRUE));
				}
			}
			
		}catch (Exception e) {
			project = new Project();
			project.setSuccess(Boolean.FALSE);
			project.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			return project;
		}
		
		return project;
	}
	
	public static Project getProjectByLinkname(String linkName) {
		
		try {
			Criteria c = new Criteria(new Column(PROJECT.TABLE, PROJECT.PROJECT_LINK_NAME), linkName, QueryConstants.EQUAL);
//			Join join1=new Join(PROJECT.TABLE,EXPERIMENT.TABLE,new String[]{PROJECT.PROJECT_ID},new String[]{EXPERIMENT.PROJECT_ID},Join.LEFT_JOIN);
			DataObject dobj = getRow(PROJECT.TABLE, c);
			if(dobj.containsTable(PROJECT.TABLE)) {
				Iterator<?> it = dobj.getRows(PROJECT.TABLE);
				while(it.hasNext()) {
					Row row = (Row)it.next();
					Project project = getProjectFromRow(row);
					project = getExperimentCountOfProject(project);
//					if(dobj.containsTable(EXPERIMENT.TABLE)) {	
//						Criteria c2 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.PROJECT_ID), project.getProjectId(), QueryConstants.EQUAL);
//						Iterator<?> it2 = dobj.getRows(EXPERIMENT.TABLE, c2);
//						while(it2.hasNext()) {
//							Row erow = (Row)it2.next();
//							Experiment experiment = Experiment.getExperimentFromRow(erow);
//							experiment.setProjectLinkname(project.getProjectLinkName());
//							project.getExperiments().add(experiment);
//						}
//					}
					return project;
				}
			}
		}catch (Exception e) {
			Project project = new Project();
			project.setSuccess(Boolean.FALSE);
			project.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			return project;
		}
		
		return null;
	}
	
	public static String getProjectLinkname(DataObject dobj, Long projectId) throws DataAccessException {
		String projectLinkname = null;
		if(dobj.containsTable(PROJECT.TABLE)) {
			Criteria c2 = new Criteria(new Column(PROJECT.TABLE, PROJECT.PROJECT_ID), projectId, QueryConstants.EQUAL);
			Row prow = dobj.getRow(PROJECT.TABLE, c2);
			if(prow!=null) {
				projectLinkname = (String)prow.get(PROJECT.PROJECT_LINK_NAME);
			}					
		}
		return projectLinkname;
	}
	
	public static Long getProjectIdFromExperimentLinkName(String experimentLinkName) throws DataAccessException,Exception {
		
		Long projectId = null;
		try{
			Criteria c2 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_LINK_NAME), experimentLinkName, QueryConstants.EQUAL);
			DataObject dobj = ZABModel.getRow(EXPERIMENT.TABLE, c2);
			if(dobj.containsTable(EXPERIMENT.TABLE)) {
				Row row = dobj.getFirstRow(EXPERIMENT.TABLE);
				projectId = (Long)row.get(EXPERIMENT.PROJECT_ID);
			}					
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return projectId;
	}
	
	public static Long getProjectIdFromExperimentId(Long experimentId) throws DataAccessException,Exception {
		
		Long projectId = null;
		try{
			Criteria c2 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
			DataObject dobj = ZABModel.getRow(EXPERIMENT.TABLE, c2);
			if(dobj.containsTable(EXPERIMENT.TABLE)) {
				Row row = dobj.getFirstRow(EXPERIMENT.TABLE);
				projectId = (Long)row.get(EXPERIMENT.PROJECT_ID);
			}					
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return projectId;
	}
	
	
	public static Project getProjectByProjectId(Long projectId){
		Criteria c = new Criteria(new Column(PROJECT.TABLE, PROJECT.PROJECT_ID), projectId+"", QueryConstants.EQUAL);
//		Join join1=new Join(PROJECT.TABLE,EXPERIMENT.TABLE,new String[]{PROJECT.PROJECT_ID},new String[]{EXPERIMENT.PROJECT_ID},Join.LEFT_JOIN);
		try {
			DataObject dobj = getRow(PROJECT.TABLE, c);
			if(dobj.containsTable(PROJECT.TABLE)) {
				Iterator<?> it = dobj.getRows(PROJECT.TABLE);
				while(it.hasNext()) {
					Row row = (Row)it.next();
					Project project = getProjectFromRow(row);
					//Commented as no source calling it requires experiment count
					//project = getExperimentCountOfProject(project);
					if(dobj.containsTable(EXPERIMENT.TABLE)) {	
						Criteria c2 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.PROJECT_ID), project.getProjectId(), QueryConstants.EQUAL);
						Iterator<?> it2 = dobj.getRows(EXPERIMENT.TABLE, c2);
						while(it2.hasNext()) {
							Row erow = (Row)it2.next();
							Experiment experiment = Experiment.getExperimentFromRow(erow);
							project.getExperiments().add(experiment);
						}
					}
					return project;
				}
			}
		}catch (Exception e) {
			Project project = new Project();
			project.setSuccess(Boolean.FALSE);
			project.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			return project;
		}
		
		return null;
		
	}
	
	public static String getAbsoluteScriptUrl(String projectKey, String portalName) {
		return portalName + "/" + projectKey + ".js"; //NO I18N
	}
	
	public static String getProjectJSURL(String projectKey, String serverUrl) {
		String portaldomain = null;
		if(IAMUtil.getCurrentServiceOrg() != null)
		{
			portaldomain = IAMUtil.getCurrentServiceOrg().getDomains().get(0).getDomain();
		}
		else
		{
			portaldomain = ZABUtil.getPortaldomain();
		}
		String jsName = getAbsoluteScriptUrl(projectKey, portaldomain);
		return serverUrl + jsName;
	}
	
	public static String getProjectJsSnippetPrimaryUrl(String projectKey) {
		String serverUrl = ApplicationProperty.getString(ZABConstants.SCRIPT_CDN);
		return getProjectJSURL(projectKey, serverUrl);
	}
	
	public static String getProjectJsSnippetAltUrl(String projectKey) {
		String serverUrl = ApplicationProperty.getString(ZABConstants.SCRIPT_CDN_ALT);
		return serverUrl==null?null:getProjectJSURL(projectKey, serverUrl);
	}
	
	public static String getProjectJsSnippetEmbedCode(String projectKey)
	{
		String jsSnippetEmbedCode = "";
		try
		{
			String jsUrl = getProjectJsSnippetPrimaryUrl(projectKey);
			jsSnippetEmbedCode = "<script src=\""+jsUrl+"\"></script>";
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			jsSnippetEmbedCode = "";
		}
		return jsSnippetEmbedCode;
	}
	
	public static String getProjectAsyncJsSnippetEmbedCode(String projectKey)
	{
		String jsSnippetEmbedCode = "";
		try
		{
			String jsUrl = getProjectJsSnippetPrimaryUrl(projectKey);
			
			String templatePath = "/../../mailtemplate/async-projectsnippet.html"; //No I18N
			String url = Project.class.getResource(templatePath).getPath();
			String codesnippet = new String(Files.readAllBytes(Paths.get(url)));
			codesnippet = codesnippet.replace("${projectjsurl}", jsUrl); //No I18N
			jsSnippetEmbedCode = codesnippet;
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			jsSnippetEmbedCode = "";
		}
		return jsSnippetEmbedCode;
	}

	public static Project getExperimentCountOfProject(Project  proj){
		 proj.setRunningExperiments(0);
		 proj.setTotalExperiments(0);
		try{
			Criteria c = new Criteria(new Column(EXPERIMENT.TABLE,EXPERIMENT.PROJECT_ID),proj.getProjectId(),QueryConstants.EQUAL);
			Criteria c2 = new Criteria(new Column(EXPERIMENT.TABLE,EXPERIMENT.IS_ACTIVE),Boolean.TRUE,QueryConstants.EQUAL);
			
			
			/* To exclude enabled heatmap experiments*/
			Integer[] types = new Integer[]{ExperimentType.ENABLED_HEATMAP.getTypeNumber()};
			Criteria c3 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_TYPE), types, QueryConstants.NOT_IN);
			
			DataObject dobj  =  ZABModel.getRow(EXPERIMENT.TABLE, c.and(c2).and(c3));
			Integer  totalExperiments = dobj.size(EXPERIMENT.TABLE);
			
			/* Including goals count in experiments count */
			Criteria c4 = new Criteria(new Column(GOAL.TABLE,GOAL.PROJECT_ID),proj.getProjectId(),QueryConstants.EQUAL);
			Criteria c5 = new Criteria(new Column(GOAL.TABLE,GOAL.IS_PROJECT_LEVEL),Boolean.TRUE,QueryConstants.EQUAL);
			DataObject dobj2  =  ZABModel.getRow(GOAL.TABLE, c4.and(c5));
			Integer totalGoals = dobj2.size(GOAL.TABLE);
			
			if(totalGoals>0){
				if(totalExperiments>0){
					totalExperiments = totalExperiments + totalGoals;
				}
				else{
					totalExperiments = totalGoals;
				}
				
			}
			
			
			if(totalExperiments>0){
				c = new Criteria(new Column(EXPERIMENT.TABLE,EXPERIMENT.EXPERIMENT_STATUS),ExperimentStatus.RUNNING.getStatusCode(),QueryConstants.EQUAL);
				 dobj =  dobj.getDataObject(EXPERIMENT.TABLE, c);
				 Integer runningExperiments = dobj.size(EXPERIMENT.TABLE);
				 
				 /* Including active goals count in active experiments count */
				 c4 = new Criteria(new Column(GOAL.TABLE,GOAL.GOAL_STATUS),GoalStatus.RUNNING.getStatusCode(),QueryConstants.EQUAL);
				 dobj2 =  dobj2.getDataObject(GOAL.TABLE, c4);
				 Integer runningGoals = dobj2.size(GOAL.TABLE);
				 if(runningGoals>0){
					 if(runningExperiments>0){
						 runningExperiments = runningExperiments + runningGoals;
					 }
					 else{
						 runningExperiments = runningGoals;
					 }
					
				 }
				 
				 
				 if(runningExperiments>0){
					 proj.setRunningExperiments(runningExperiments);
				 }else{
					 proj.setRunningExperiments(0);
				 }
				
			}
			else{
				totalExperiments = 0;
			}
			
			 proj.setTotalExperiments(totalExperiments);
		}catch(Exception e ){
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		return proj;
		
	}
	
	public static Project deleteProject(String linkname) {
		Project project = null;
		try {			
			project = getProjectByLinkname(linkname);
			
			Criteria c = new Criteria(new Column(PROJECT.TABLE, PROJECT.PROJECT_LINK_NAME), linkname, QueryConstants.EQUAL);
			if(containsSchedOrRunnningExperiments(linkname) || containsRunnningGoals(linkname)) {
				throw new ZABException(ZABAction.getMessage(ProjectConstants.PROJECT_DELETE_VALIDATION_ERROR));
			}
			
			Join join = new Join(PROJECT.TABLE, EXPERIMENT.TABLE, new String[]{PROJECT.PROJECT_ID}, new String[]{EXPERIMENT.PROJECT_ID}, Join.INNER_JOIN);
			
			DataObject dobj = getRow(PROJECT.TABLE, c, new Join[] {join});
			
			ArrayList<Long> experimentIds = new ArrayList<Long>();
			Iterator it = dobj.getRows(EXPERIMENT.TABLE);
			while(it.hasNext()) {
				Row row = (Row)it.next();
				Long experimentid = (Long)row.get(EXPERIMENT.EXPERIMENT_ID);
				experimentIds.add(experimentid);
			}
			
			deleteResource(c);
			experimentIds.forEach((experimentId) -> {
				ElasticSearchUtil.deleteExperimentData(experimentId);
			});
			
			ElasticSearchUtil.deleteProjectData(project.getProjectId());
			
			ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
			wrapper.setModel(project);
			wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
			wrapper.setType(OperationType.DELETE);
			ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);
			
			
			//Saving the project display name for the use of event activity
			HashMap<String, String> eventModuleHs = new HashMap<String, String>();
			eventModuleHs.put(EventActivityConstants.MODULE_TYPE, Module.PROJECT.getValue().toString());
			eventModuleHs.put(EventActivityConstants.MODULE_ELEMENT_ID, project.getProjectId().toString());
			eventModuleHs.put(EventActivityConstants.MODULE_ELEMENT_NAME, project.getProjectName());
			EventModuleDetail.createEventModuleDetail(eventModuleHs);
			
			//Event Activity Log
			HashMap<String, String> updatedValues = new HashMap<String, String>();
			updatedValues.put(EventActivityConstants.PROJECT_ID, project.getProjectId().toString());
			updatedValues.put(EventActivityConstants.USER_ID, ZABUtil.getCurrentUser().getUserId().toString());
			updatedValues.put(EventActivityConstants.TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
			EventActivityWrapper activityWrapper = new EventActivityWrapper();
			activityWrapper.setModule(Module.PROJECT);
			activityWrapper.setOperationType(com.zoho.abtest.eventactivity.EventActivityConstants.OperationType.DELETE);
			activityWrapper.setDbSpace(ZABUtil.getCurrentUserDbSpace());
			activityWrapper.setUpdatedValues(updatedValues);
			ZABNotifier.notifyListeners(EventActivityConstants.EVENT_MODULE_NAME, activityWrapper);
			
			//Admin console record
			HashMap<String, String> acHs = new HashMap<String, String>();
			acHs.put(AdminConsoleConstants.PROJECT_ID, project.getProjectId().toString());
			acHs.put(AdminConsoleConstants.ZSOID, ZABUtil.getDBSpace());
			AdminConsoleWrapper acWrapper = new AdminConsoleWrapper();
			acWrapper.setValueHs(acHs);
			acWrapper.setOperationType(AcOperationType.PROJECT_DELETE);
			ZABNotifier.notifyListeners(AdminConsoleConstants.ADMIN_CONSOLE_MODULE_NAME,acWrapper);
		} catch (ZABException e) {
			project = new Project();
			project.setSuccess(Boolean.FALSE);
			project.setResponseString(e.getMessage());
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		catch (Exception e) {
			project = new Project();
			project.setSuccess(Boolean.FALSE);
			project.setResponseString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE));
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		return project;
	}
	
	public static HashMap<String,String> generateHashMapFromProjectObj(Project proj, HashMap<String,String> hs)
	{
		HashMap<String,String> oldValues = new HashMap<String,String>();
		try
		{
			for(String attributeName:EventActivityConstants.PROJECT_ATTR_TO_TRACE)
			{
				if(hs.containsKey(attributeName))
				{
					switch(attributeName)
					{
					case ProjectConstants.PROJECT_NAME:
						oldValues.put(ProjectConstants.PROJECT_NAME, proj.getProjectName());
						break;
					case ProjectConstants.PROJECT_STATUS:
						oldValues.put(ProjectConstants.PROJECT_STATUS, proj.getProjectStatus().toString());
						break;
					case ProjectConstants.PROJECT_DESCRIPTION:
						oldValues.put(ProjectConstants.PROJECT_DESCRIPTION, proj.getDescription());
						break;
					}
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		return oldValues;
	}
	
	public static List<Long> getProjectIds()
	{
		List<Long> projectIds = new ArrayList<Long>();
		try
		{
			DataObject dataObj = ZABModel.getRow(PROJECT.TABLE, null);
			Iterator<?> iterator = dataObj.getRows(PROJECT.TABLE);
			while(iterator.hasNext())
			{
				Row row = (Row)iterator.next();
				projectIds.add((Long)row.get(PROJECT.PROJECT_ID));
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			projectIds = new ArrayList<Long>();
		}
		return projectIds;
	}
	public static Integer getProjectsCount()
	{
		int projectsCount =  0;
		try
		{
			DataObject dataObj = ZABModel.getRow(PROJECT.TABLE, null);
			projectsCount = dataObj.size(PROJECT.TABLE);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			projectsCount =  0;
		}
		return projectsCount;
	}
	
	public static Integer getExperimentsCountForProject(Long projectId)
	{
		int expCount =  0;
		try
		{
			Criteria c = new Criteria(new Column(EXPERIMENT.TABLE,EXPERIMENT.PROJECT_ID),projectId,QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(EXPERIMENT.TABLE, c);
			expCount = dataObj.size(EXPERIMENT.TABLE);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
			expCount =  0;
		}
		return expCount;
	}
	
	public static HashMap<Long,Long> getProjectExperimentMapping(){
		HashMap<Long,Long> ProjectExperimentMapping = new HashMap<Long,Long>();
		try{
			DataObject dataObj = ZABModel.getRow(EXPERIMENT.TABLE, null);
			Iterator<?> iterator = dataObj.getRows(EXPERIMENT.TABLE);
			while(iterator.hasNext()){
				Row row = (Row)iterator.next();
				Long expId = (Long)row.get(EXPERIMENT.EXPERIMENT_ID);
				Long projectId = (Long)row.get(EXPERIMENT.PROJECT_ID);
				ProjectExperimentMapping.put(expId,projectId);
			}
		}catch(Exception e){
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		return ProjectExperimentMapping;
	}
	
	public static Long getRemainingDaysForExpiration(){

		
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		Long remainingDays = 0L;
		try{
			//Join join = new Join(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_YEARLY_DETAIL.TABLE, new String[]{PORTAL_LICENSE_MAPPING.PORTAL_LICENSE_MAPPING_ID}, new String[]{PORTAL_LICENSE_YEARLY_DETAIL.PORTAL_LICENSE_MAPPING_ID}, Join.LEFT_JOIN);
			Criteria criteria = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.ZSOID), Long.parseLong(existingDBSpace), QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(PORTAL_LICENSE_MAPPING.TABLE, criteria);
			if(dataObj.containsTable(PORTAL_LICENSE_MAPPING.TABLE)){
				Row row = dataObj.getFirstRow(PORTAL_LICENSE_MAPPING.TABLE);
				Boolean bool = (Boolean)row.get(PORTAL_LICENSE_MAPPING.IS_ANNUAL);
				Long currentTime = ZABUtil.getCurrentTimeInMilliSeconds();
				Long endTime;
				endTime = (Long)row.get(PORTAL_LICENSE_MAPPING.END_TIME);
				remainingDays = ZABUtil.getDaysDifferenceBetween(currentTime,endTime);
			}
		}catch(Exception ex){
			
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		ZABUtil.setDBSpace(existingDBSpace);
		return remainingDays;
	}
	public static Long getVisitorsCount(){
		

		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N 
		Long licenseVisitorCount = 0L;
		try {
			Criteria criteria = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.ZSOID), Long.parseLong(existingDBSpace), QueryConstants.EQUAL);
			Join join = new Join(PORTAL_LICENSE_MAPPING.TABLE, LICENSE_DETAIL.TABLE, new String[]{PORTAL_LICENSE_MAPPING.LICENSE_DETAIL_ID}, new String[]{LICENSE_DETAIL.LICENSE_DETAIL_ID}, Join.INNER_JOIN);
			DataObject dataObj = ZABModel.getRow(PORTAL_LICENSE_MAPPING.TABLE, criteria, join);
			if(dataObj.containsTable(PORTAL_LICENSE_MAPPING.TABLE)&&dataObj.containsTable(LICENSE_DETAIL.TABLE)){
				Row licenseRow = dataObj.getFirstRow(LICENSE_DETAIL.TABLE);
				Row portalLicenseMappingRow = dataObj.getFirstRow(PORTAL_LICENSE_MAPPING.TABLE);
				licenseVisitorCount = PortalLicenseAddon.getPlanVisitorCount((Long)portalLicenseMappingRow.get(PORTAL_LICENSE_MAPPING.PORTAL_LICENSE_MAPPING_ID),(Long)licenseRow.get(LICENSE_DETAIL.STORE_PLAN_ID),(Boolean)portalLicenseMappingRow.get(PORTAL_LICENSE_MAPPING.IS_ANNUAL));
			}
		} catch(Exception e){
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		ZABUtil.setDBSpace(existingDBSpace);
		return licenseVisitorCount;
	}

	public static Long getVisitorsExperimented() {
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N 
		Long expsVisitorCount = 0L;
		try{
			Criteria criteria = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.ZSOID), Long.parseLong(existingDBSpace), QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(PORTAL_LICENSE_MAPPING.TABLE, criteria);
			String portalDomain =  ZABUtil.getPortaldomain();
			List<String> userPortalList = new ArrayList<String>();
			userPortalList.add(portalDomain);
			if(StringUtils.isNotEmpty(portalDomain) && userPortalList.size() > 0 && dataObj.containsTable(PORTAL_LICENSE_MAPPING.TABLE))
			{	
				Row row = dataObj.getFirstRow(PORTAL_LICENSE_MAPPING.TABLE);
				Long endTime = (Long)row.get(PORTAL_LICENSE_MAPPING.END_TIME);
				Long startTime = (Long)row.get(PORTAL_LICENSE_MAPPING.START_TIME);
				expsVisitorCount = LicenseVerification.getVisitorsCount(userPortalList, startTime, endTime);
			}
		}catch(Exception e){
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		ZABUtil.setDBSpace(existingDBSpace);
		return expsVisitorCount;
	}
	
	public static void getVisitorsExperimentedInProject(Project project) {
		
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N 
		try{
			Criteria criteria = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.ZSOID), Long.parseLong(existingDBSpace), QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(PORTAL_LICENSE_MAPPING.TABLE, criteria);
			String portalDomain =  ZABUtil.getPortaldomain();
			List<String> userPortalList = new ArrayList<String>();
			userPortalList.add(portalDomain);
			
			if(StringUtils.isNotEmpty(portalDomain) && userPortalList.size() > 0 && dataObj.containsTable(PORTAL_LICENSE_MAPPING.TABLE))
			{	
				Row row = dataObj.getFirstRow(PORTAL_LICENSE_MAPPING.TABLE);
				Long endTime = (Long)row.get(PORTAL_LICENSE_MAPPING.END_TIME);
				Long startTime = (Long)row.get(PORTAL_LICENSE_MAPPING.START_TIME);
				ZABUtil.setDBSpace(existingDBSpace);
				JSONArray expsVisitorCount = LicenseVerification.getVisitorsCountForProject(userPortalList, startTime, endTime);
				project.setTotalNumberOfVisitorsExperimentedForProject(expsVisitorCount);
			}
			ZABUtil.setDBSpace(existingDBSpace);
		}catch(Exception e){
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		
	}
	
	public static Integer getTotalNumberOfDays(){
		
		int totalNumberOfDays = 0;
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N 
		try{
		Criteria criteria = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.ZSOID), Long.parseLong(existingDBSpace), QueryConstants.EQUAL);
		DataObject dataObj = ZABModel.getRow(PORTAL_LICENSE_MAPPING.TABLE, criteria);
		Row row = dataObj.getFirstRow(PORTAL_LICENSE_MAPPING.TABLE);
		Boolean bool = (Boolean)row.get(PORTAL_LICENSE_MAPPING.IS_ANNUAL);
		totalNumberOfDays = bool?365:30;
		}catch(Exception e){
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		ZABUtil.setDBSpace(existingDBSpace);	
		return totalNumberOfDays;
	}
	
	public static ArrayList<Project> getProjectsForCurrentPortal(){
		ArrayList<Project> projects = new ArrayList<Project>();
		try{
			Criteria c = null;
			DataObject dobj = ZABModel.getRow(PROJECT.TABLE,c);
			projects = getProjectFromDobj(dobj);
		}catch(Exception e){
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			}
		return projects;
	}
	
	public static ArrayList<Project> getAllProjectsForCurrentPortal(){
		ArrayList<Project> projects = new ArrayList<Project>();
		try{
			Criteria c = null;
			DataObject dobj = ZABModel.getRow(PROJECT.TABLE,c);
			projects = getProjectFromProjectDobj(dobj);
		}catch(Exception e){
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
			}
		return projects;
	}

	public static Long getProjectIdFromKey(String projkey) {
		Long projid =null;
		Criteria c = new Criteria(new Column(PROJECT.TABLE,PROJECT.PROJECT_KEY),projkey,QueryConstants.EQUAL);
		DataObject dobj;
		try {
			dobj = ZABModel.getRow(PROJECT.TABLE, c);
			projid = (Long) dobj.getFirstValue(PROJECT.TABLE, PROJECT.PROJECT_ID);
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
		return projid;
	}
	
	public static void updateScriptByProject(Long projectId, String portalName) throws Exception {
		JSONObject projectJSON = ProjectJSONService.constructProjectJSON(projectId, portalName);
		ProjectJSONService
				.updateProjectJSON(
						projectId,
						portalName,
						projectJSON.toString(),
						com.zoho.abtest.project.ProjectTreeEventConstants.Module.EXPERIMENT,
						null);
		LOGGER.log(Level.INFO, "Uploaded to s3 via handler for project is successful for project:" + projectId);
	}
	
	public static void updateScriptByPortalName(String portalName) throws Exception {
		DataObject dobj = ZABModel.getRow(PROJECT.TABLE, null);
		Iterator it = dobj.getRows(PROJECT.TABLE);
		int totalcounter = 0;
		int successcounter = 0;
		while(it.hasNext()) {
			totalcounter++;
			Row row = (Row)it.next();
			Long projectId = (Long)row.get(PROJECT.PROJECT_ID);
			String projectName = (String)row.get(PROJECT.PROJECT_NAME);
			try {							
				JSONObject projectJSON = ProjectJSONService.constructProjectJSON(projectId, portalName);
				ProjectJSONService.updateProjectJSON(projectId, portalName, projectJSON.toString(), com.zoho.abtest.project.ProjectTreeEventConstants.Module.EXPERIMENT, null);
				LOGGER.log(Level.INFO, "Uploaded to s3 via handler for project is successful for project:" + projectName);
				successcounter++;
			} catch (Exception e) {
				LOGGER.log(Level.SEVERE, "Failed to upload script for project:" + projectName);
			}
		}
		
		LOGGER.log(Level.INFO, "Uploaded to s3 is completed for portal:" + portalName);
		LOGGER.log(Level.INFO, "AWS Upgrade status (totalcount/successcount):"+totalcounter+"/"+successcounter);
	}
}
