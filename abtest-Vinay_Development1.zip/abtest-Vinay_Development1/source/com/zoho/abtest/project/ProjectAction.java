//$Id$
package com.zoho.abtest.project;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.json.JSONException;


import com.adventnet.iam.IAMUtil;
import com.adventnet.iam.xss.IAMEncoder;

import com.opensymphony.xwork2.ActionSupport;

import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.elastic.ElasticSearchIndexConstants;
import com.zoho.abtest.license.LicenseConstants;
import com.zoho.abtest.license.PortalLicenseMapping;
import com.zoho.abtest.user.ZABUserConstants;
import com.zoho.abtest.utility.ZABUtil;

public class ProjectAction extends ActionSupport implements ServletResponseAware, ServletRequestAware{

	private static final Logger LOGGER = Logger.getLogger(ProjectAction.class.getName());
	
	private static final long serialVersionUID = 1L;
	
	private HttpServletRequest request;
	
	private HttpServletResponse response;
	
	private String linkname;
	
	public String getLinkname() {
		return linkname;
	}

	public void setLinkname(String linkname) {
		this.linkname = linkname;
	}

	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		request = arg0;
	}

	@Override
	public void setServletResponse(HttpServletResponse arg0) {
		response = arg0;
	}

	public String execute() throws IOException, JSONException {
		
		LOGGER.log(Level.INFO, "Project Action Start"); //No I18Nbb
		ArrayList<Project> projects = new ArrayList<Project>();
		try {			
			switch(ZABAction.getHTTPMethod(request)) {
			case POST:	
				HashMap<String,String> hs = ZABAction.getRequestParser(request).parseProject(request);
				if(hs.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hs.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					Project project = new Project();
					project.setSuccess(Boolean.FALSE);
					project.setResponseString(hs.get(ZABConstants.RESPONSE_STRING));
					projects.add(project);
				}else{
					//Checking project limit for this portal
					int existingProjectsCount = Project.getProjectsCount();
					int allowedProjectsCount = PortalLicenseMapping.getPortalLicenseProjectLimit(Long.parseLong(ZABUtil.getDBSpace()));
					if(existingProjectsCount < allowedProjectsCount)
					{
						projects.add(Project.createProject(hs));
					}
					else
					{
						Project project = new Project();
						project.setSuccess(Boolean.FALSE);
						project.setResponseString(ZABAction.getMessage(LicenseConstants.LICENSE_PROJECT_LIMIT_EXCEED));
						projects.add(project);
					}
				}
				break;
			case GET:
				if(linkname==null || linkname.isEmpty()) {	
					projects.addAll(Project.getProjects(null));
				} else {
					Project project = Project.getUserProjectByLinkname(linkname);
					//Comment above and uncomment below for old ui
				     // Project project = Project.getProjectDetailsWithLinkname(linkname);
					projects.add(project);
				}
				break;
			case DELETE:
				projects.add(Project.deleteProject(linkname));
				break;
			case PUT:
				HashMap<String,String> hsPut = ZABAction.getRequestParser(request).parseProject(request);
				if(hsPut.containsKey(ZABConstants.SUCCESS)&&!ZABUtil.parseBoolean(hsPut.get(ZABConstants.SUCCESS),ZABConstants.SUCCESS)){
					Project project = new Project();
					project.setSuccess(Boolean.FALSE);
					project.setResponseString(hsPut.get(ZABConstants.RESPONSE_STRING));
					projects.add(project);
				}else{					
					projects.add(Project.updateProject(hsPut));
				}
				break;
			}
		}catch(JSONException ex){	
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getInvalidInputFormatException(ProjectConstants.API_MODULE_PLURAL));
			return null; 	
		}  catch(Exception ex){
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), ProjectConstants.API_MODULE_PLURAL));
			return null; 	
		}		
		LOGGER.log(Level.INFO, "Project Action Ends"); //No I18N
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getProjectResponse(request, projects));	
	    return null;
	}
	
	public void getProjectJsSnippetEmbedCode()
	{
		try
		{
			Project project = Project.getProjectByLinkname(linkname);
			String jsSnippetEmbedCode  = Project.getProjectJsSnippetEmbedCode(project.getProjectKey());
			response.setContentType("text/html"); // NO I18N
			PrintWriter writer = response.getWriter();
			writer.println(jsSnippetEmbedCode);
		    writer.flush();
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
	}
	
	public void sendProjectJsSnippet()
	{
		try
		{
			HashMap<String,String> hs = null;
			hs = ZABAction.getRequestParser(request).parseProject(request);
			String emailAddress = hs.get(ZABUserConstants.EMAIL_ADDRESS);
			boolean async = Boolean.parseBoolean(hs.get(ProjectConstants.ASYNC));
			
			Project project = Project.getProjectBasicDetails(linkname);
			String projectName = project.getProjectName();
			String senderFName = IAMUtil.getCurrentUser().getFirstName();
			String senderEMail =  IAMUtil.getCurrentUser().getPrimaryEmail();
			String senderName = StringUtils.isEmpty(senderFName)?senderEMail:senderFName;
			
			String jsSnippetEmbedCode  = null;
			if(async)
			{
				jsSnippetEmbedCode = Project.getProjectAsyncJsSnippetEmbedCode(project.getProjectKey());
			}
			else
			{
				jsSnippetEmbedCode = Project.getProjectJsSnippetEmbedCode(project.getProjectKey());
			}
			//Encoding the script part so that it will not be executed as a script
			jsSnippetEmbedCode = IAMEncoder.encodeHTML(jsSnippetEmbedCode);
			
			String fromAddress = ElasticSearchIndexConstants.ES_MAIL_FROM_ADDRESS;
			String toAddress = emailAddress;
			String subject = ZABAction.getMessage(ProjectConstants.MAIL_SNIPPET_SUBJECT);
			String message = "";
			String templatePath = "/../../mailtemplate/projectsnippet-mail.html"; //No I18N
			String url = ProjectAction.class.getResource(templatePath).getPath();
			String mailTemplate = new String(Files.readAllBytes(Paths.get(url)));
			mailTemplate = mailTemplate.replace("${codesnippet}", jsSnippetEmbedCode);  //No I18N
			mailTemplate = mailTemplate.replace("${projectName}", projectName);  //No I18N
			mailTemplate = mailTemplate.replace("${senderName}", senderName);  //No I18N
			message = mailTemplate;
			
			ZABUtil.sendEmail(message, fromAddress, toAddress, subject);
			
			//Dummy response
			ArrayList<Project> projects = new ArrayList<Project>();
			project = new Project();
			project.setSuccess(Boolean.TRUE);
			projects.add(project);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getProjectResponse(request, projects));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception in sendProjectJsSnippet");
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
	}
	
	public String getUsageStats(){
		try{
		ArrayList<Project> projects = new ArrayList<Project>();
		Project project = new Project();
		//get projects limit for the portal and total number of projects created for the portal
		int existingProjectsCount = Project.getProjectsCount();
		existingProjectsCount = (existingProjectsCount==-1)?0:existingProjectsCount;
		int allowedProjectsCount = PortalLicenseMapping.getPortalLicenseProjectLimit(Long.parseLong(ZABUtil.getDBSpace()));
		project.setAllowedProjectsCount(allowedProjectsCount);
		project.setExistingProjectsCount(existingProjectsCount);
		//getting Remaining days left for subscription
		int totalNumberOfDays = Project.getTotalNumberOfDays();
		project.setTotalNumberOfDaysAvailable(totalNumberOfDays);
		Long remainingDays = Project.getRemainingDaysForExpiration();
		if(remainingDays<=0){
			project.setRemainingDays(0L);
		}else{
			project.setRemainingDays(remainingDays);
		}
		//getting Total number of visitors limit for the portal 
		Long licenseVisitorCount = Project.getVisitorsCount();
		project.setTotalNumberOfVisitors(licenseVisitorCount);
		//visitors tracked in this space
		Long expsVisitorCount= Project.getVisitorsExperimented();
		project.setTotalNumberOfVisitorsExperimented(expsVisitorCount);
		//visitors experimented in every Project
		//Project.getVisitorsExperimentedInProject(project);
		project.setPortal(linkname);
		project.setId(linkname);
		project.setSuccess(Boolean.TRUE);
		projects.add(project);		
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getUsageStatsResponse(request, projects));

		} catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		return null;
	}
	
	public String getPortalStatus(){
		try{
			ArrayList<Project> projects = new ArrayList<Project>();
			Project project = new Project();
			Boolean bool = PortalLicenseMapping.getLicenseStatus();
			if(!bool){
				// 2 if user license is inactive
				project.setPortalStatusFlag(2);
			} else {
				double totalNumberOfDays = Project.getTotalNumberOfDays().doubleValue();
				double remainingDays = Project.getRemainingDaysForExpiration().doubleValue();
				double per = ( ( totalNumberOfDays - remainingDays ) / ( totalNumberOfDays ) ) * 100;
			
				double licenseVisitorCount = Project.getVisitorsCount().doubleValue();
				double expsVisitorCount= Project.getVisitorsExperimented().doubleValue();
				double per1 = ( ( expsVisitorCount ) / ( licenseVisitorCount ) ) * 100;
			
				if(per1<80 && per<80){
					//0 if user license is active
					project.setPortalStatusFlag(0);
				}else{
					//1 if user license is about to end
					project.setPortalStatusFlag(1);
				}
			}
			
			project.setSuccess(Boolean.TRUE);
			projects.add(project);		
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getProjectResponse(request, projects));
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(),ex);
		}
		return null;
	}
}
