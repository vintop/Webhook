//$Id$
package com.zoho.abtest.eventactivity;

import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.zoho.abtest.EVENT_MODULE_DETAIL;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.common.ZABModel;

public class EventModuleDetail extends ZABModel {

	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = Logger.getLogger(EventModuleDetail.class.getName());
	
	private Long eventModuleDetailId;
	private Integer moduleType;
	private Long moduleElementId;
	private String moduleElementName;
	
	public Long getEventModuleDetailId() {
		return eventModuleDetailId;
	}
	public void setEventModuleDetailId(Long eventModuleDetailId) {
		this.eventModuleDetailId = eventModuleDetailId;
	}
	public Integer getModuleType() {
		return moduleType;
	}
	public void setModuleType(Integer moduleType) {
		this.moduleType = moduleType;
	}
	public Long getModuleElementId() {
		return moduleElementId;
	}
	public void setModuleElementId(Long moduleElementId) {
		this.moduleElementId = moduleElementId;
	}
	public String getModuleElementName() {
		return moduleElementName;
	}
	public void setModuleElementName(String moduleElementName) {
		this.moduleElementName = moduleElementName;
	}
	
	public static void createEventModuleDetail(HashMap<String, String> hs)
	{
		try
		{
			ZABModel.createRow(EventActivityConstants.EVENT_MODULE_DETAIL_CONSTANTS, EVENT_MODULE_DETAIL.TABLE, hs);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	public static void updateEventModuleDetail(HashMap<String, String> hs, Integer moduleType, Long moduleElementId)
	{
		try
		{
			Criteria criteria1 = new Criteria(new Column(EVENT_MODULE_DETAIL.TABLE, EVENT_MODULE_DETAIL.MODULE_TYPE), moduleType, QueryConstants.EQUAL);
			Criteria criteria2 = new Criteria(new Column(EVENT_MODULE_DETAIL.TABLE, EVENT_MODULE_DETAIL.MODULE_ELEMENT_ID), moduleElementId, QueryConstants.EQUAL);
			ZABModel.updateRow(EventActivityConstants.EVENT_MODULE_DETAIL_CONSTANTS, EVENT_MODULE_DETAIL.TABLE, hs, criteria1.and(criteria2), EventActivityConstants.API_RESOURCE_EVENT_MODULE);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	public static String getEventModuleElementDisplayName(Integer moduleType, Long moduleElementId)
	{
		String displayName  = "";
		try
		{
			Criteria criteria1 = new Criteria(new Column(EVENT_MODULE_DETAIL.TABLE, EVENT_MODULE_DETAIL.MODULE_TYPE), moduleType, QueryConstants.EQUAL);
			Criteria criteria2 = new Criteria(new Column(EVENT_MODULE_DETAIL.TABLE, EVENT_MODULE_DETAIL.MODULE_ELEMENT_ID), moduleElementId, QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(EVENT_MODULE_DETAIL.TABLE, criteria1.and(criteria2));
			displayName  = (String)dataObj.getFirstValue(EVENT_MODULE_DETAIL.TABLE, EVENT_MODULE_DETAIL.MODULE_ELEMENT_NAME);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			displayName  = "";
		}
		return displayName;
	}
	
}
