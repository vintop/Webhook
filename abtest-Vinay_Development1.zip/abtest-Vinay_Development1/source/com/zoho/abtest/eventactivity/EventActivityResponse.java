//$Id$
package com.zoho.abtest.eventactivity;

import java.util.List;
import java.util.logging.Level;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;

public class EventActivityResponse {
	
	private static final Logger LOGGER = Logger.getLogger(EventActivityResponse.class.getName());
	
	public static String jsonResponse(HttpServletRequest request,List<EventActivityLog> lst, String module) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(lst);			
			JSONObject json = ZABResponse.updateMetaInfo(request, module, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){
			
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			
		}
		return returnBuffer.toString();
	}
	
	public static JSONArray getJSONArray(List<EventActivityLog> lst) throws JSONException {
		JSONArray array = new JSONArray();
		int size =lst.size();
		for (int i=0;i<size;i++) {
			EventActivityLog eventActivity=lst.get(i);
			JSONObject jsonObj = new JSONObject();
			
			jsonObj.put(EventActivityConstants.EVENT_ACTIVITY_LOG_ID, eventActivity.getEventActivityLogId());
			jsonObj.put(EventActivityConstants.PROJECT_ID, eventActivity.getProjectId());
			jsonObj.put(EventActivityConstants.PROJECT_NAME, eventActivity.getProjectDisplayName());
			jsonObj.put(EventActivityConstants.EXPERIMENT_ID, eventActivity.getExperimentId());
			jsonObj.put(EventActivityConstants.VARIATION_ID, eventActivity.getVariationId());
			jsonObj.put(EventActivityConstants.EXPERIMENT_NAME, eventActivity.getExperimentDisplayName());
			jsonObj.put(EventActivityConstants.MODULE, eventActivity.getModule());
			jsonObj.put(EventActivityConstants.EVENT_TYPE, eventActivity.getEventType());
			jsonObj.put(EventActivityConstants.VALUE, eventActivity.getValue());
			jsonObj.put(EventActivityConstants.OLD_VALUE, eventActivity.getOldValue());
			jsonObj.put(EventActivityConstants.MESSAGE, eventActivity.getMessage());
			jsonObj.put(EventActivityConstants.TIME, eventActivity.getTime());
			jsonObj.put(EventActivityConstants.FORMATTED_TIME, eventActivity.getFormattedTime());
			jsonObj.put(EventActivityConstants.FORMATTED_TIME_ONLY, eventActivity.getTimeOnly());
			jsonObj.put(EventActivityConstants.FORMATTED_DATE_ONLY, eventActivity.getDateOnly());
			jsonObj.put(EventActivityConstants.USER_ID, eventActivity.getUserId());
			//For Scheduled job changes such as experiment start on schedule, the userid will be null  
			String userName = "System"; // No I18N
			if(eventActivity.getUserId() != null)
			{
				userName = eventActivity.getUserName();
			}
			jsonObj.put(EventActivityConstants.USER_NAME, userName);
			jsonObj.put(ZABConstants.RESPONSE_STRING, eventActivity.getResponseString());
			jsonObj.put(ZABConstants.STATUS_CODE, eventActivity.getResponseCode());
			jsonObj.put(ZABConstants.SUCCESS, eventActivity.getSuccess());
			array.put(jsonObj);
		}
		return array;
	}
	
}
