//$Id$
package com.zoho.abtest.eventactivity;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.json.JSONException;

import com.opensymphony.xwork2.ActionSupport;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.goal.Goal;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.user.ZABUser;
import com.zoho.abtest.utility.ZABUtil;

public class GoalEventActivityAction  extends ActionSupport implements ServletResponseAware, ServletRequestAware {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(EventActivityAction.class.getName());
	
	private HttpServletRequest request;
	
	private HttpServletResponse response;
	
	private String projectLinkName;
	
	private String goalLinkName;
	
	
	public String getGoalLinkName() {
		return goalLinkName;
	}

	public void setGoalLinkName(String experimentLinkName) {
		this.goalLinkName = experimentLinkName;
	}

	public String getProjectLinkName() {
		return projectLinkName;
	}

	public void setProjectLinkName(String projectLinkName) {
		this.projectLinkName = projectLinkName;
	}

	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		request = arg0;
	}

	@Override
	public void setServletResponse(HttpServletResponse arg0) {
		response = arg0;
	}

	public String getGoalEventActivity() throws IOException, JSONException {
		List<EventActivityLog> eventActivityList = new ArrayList<EventActivityLog>();
		try
		{
			Long goalid = Goal.getGoalIdForGoal(goalLinkName);
			
			Long startDate = null;
			Long endDate = null;
			String startDateStr = request.getParameter(EventActivityConstants.START_DATE);
			if(StringUtils.isNotEmpty(startDateStr))
			{
				startDate = ZABUtil.getTimeInLongFromDateFormStr(startDateStr, "yyyy-MM-dd");		// NO I18N
			}
			String endDateStr = request.getParameter(EventActivityConstants.END_DATE);
			if(StringUtils.isNotEmpty(endDateStr))
			{
				endDate = ZABUtil.getTimeInLongFromDateFormStr(endDateStr, "yyyy-MM-dd");		// NO I18N
				//Get the time for 11:59:59 PM for that day
				endDate = ZABUtil.getNthDayDateInLong( endDate, 1) - 1;
			}
			
			eventActivityList.addAll(EventActivityLog.getEventActivityLogByGoal(goalid,startDate,endDate));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), EventActivityConstants.EAPI_MODULE));
			return null; 	
		}	
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExperimentEventActivityResponse(request, eventActivityList));		
	    return null;
	}
	
	
	
}
