//$Id$
package com.zoho.abtest.eventactivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.zoho.abtest.EVENT_ACTIVITY_LOG;
import com.zoho.abtest.EVENT_MODULE_DETAIL;
import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.goal.GoalConstants;
import com.zoho.abtest.heatmaps.HeatmapExperimentConstants;
import com.zoho.abtest.privacyconsent.PrivacyConstants;
import com.zoho.abtest.project.ProjectConstants;
import com.zoho.abtest.variation.VariationConstants;

public class EventActivityConstants extends ZABConstants{
	
//	public static final String API_MODULE = "eventactivity"; //No I18N
	
	public static final String PAPI_MODULE = "projecteventactivity"; //No I18N
	
	public static final String EAPI_MODULE = "experimenteventactivity"; //No I18N
	
	public static final String UAPI_MODULE = "useractivity"; //No I18N
	
	public static final String API_RESOURCE_EVENT_MODULE = "resource.eventmoduledetail"; //No I18N

	public static final String EVENT_MODULE_NAME = "EventActivityListener"; //No I18N
	
	public static final String RESOURCE_EXPERIMENT_INFO = "activity.experiment.head"; //No I18N
	public static final String RESOURCE_PROJECT_INFO = "activity.project.head"; //No I18N
	
	public static final String PROJECT_DESC_UPDATE_NEWONLY = "activity.projectdesc.update.newonly"; //No I18N
	public static final String PROJECT_DESC_UPDATE_OLDONLY = "activity.projectdesc.update.oldonly"; //No I18N
	
	public static final String GOAL_URL_UPDATE_NEWONLY = "activity.projectgoal.url.update.newonly"; //No I18N
	public static final String GOAL_URL_UPDATE_OLDONLY = "activity.projectgoal.url.update.oldonly"; //No I18N
	
	public static final String EXP_START_DATE_UPDATE_NEWONLY = "activity.experimentstartdate.update.newonly"; //No I18N
	public static final String EXP_START_DATE_UPDATE_OLDONLY = "activity.experimentstartdate.update.oldonly"; //No I18N
	public static final String EXP_END_DATE_UPDATE_NEWONLY = "activity.experimentenddate.update.newonly"; //No I18N
	public static final String EXP_END_DATE_UPDATE_OLDONLY = "activity.experimentenddate.update.oldonly"; //No I18N
	
	public static final String ACTIVITY_ENABLED_UPDATE = "activity.enabled.update"; //No I18N
	public static final String ACTIVITY_DISABLED_UPDATE = "activity.disabled.update"; //No I18N
	
	
	public static enum OperationType {
		CREATE(1),
		UPDATE(2),
		DELETE(3);
		
		private Integer value;

		public Integer getValue() {
			return value;
		}

		public void setValue(Integer value) {
			this.value = value;
		}
		
		private OperationType(Integer value)
		{
			this.value = value;
		}
	}
	
	public static enum EventType
	{
		PROJECT_CREATE("project_create",1,"activity.project.create"), //No I18N
		PROJECT_DELETE("project_delete",2,"activity.project.delete"), //No I18N
		PROJECT_NAME_UPDATE("project_name_update",3,"activity.projectname.update"), //No I18N
		PROJECT_STATUS_UPDATE("project_status_update",4,"activity.projectstatus.update"), //No I18N
		PROJECT_DESC_UPDATE("project_desc_update",5,"activity.projectdesc.update"), //No I18N
		EXPERIMENT_CREATE("experiment_create",6,"activity.experiment.create"), //No I18N
		EXPERIMENT_DELETE("experiment_delete",7,"activity.experiment.delete"), //No I18N
		EXPERIMENT_NAME_UPDATE("experiment_name_update",8,"activity.experimentname.update"), //No I18N
		EXPERIMENT_URL_UPDATE("experiment_url_update",9,"activity.experimenturl.update"), //No I18N
		EXPERIMENT_STATUS_UPDATE("experiment_status_update",10,"activity.experimentstatus.update"), //No I18N
		EXP_PERMITTED_TRAFFIC_UPDATE("exp_permitted_traffic_update",11,"activity.experimentpermittedtraffic.update"), //No I18N
		EXP_STAT_SIGNIFICANCE_UPDATE("exp_stat_significance_update",12,"activity.experimentstatisficalsignificance.update"), //No I18N
		EXP_START_DATE_UPDATE("exp_start_date_update",13,"activity.experimentstartdate.update"), //No I18N
		EXP_END_DATE_UPDATE("exp_end_date_update",14,"activity.experimentenddate.update"), //No I18N
		VARIATION_CREATE("variation_create",15,"activity.variation.create"), //No I18N
		VARIATION_DELETE("variation_delete",16,"activity.variation.delete"), //No I18N
		VARIATION_NAME_UPDATE("variation_name_update",17,"activity.variationname.update"), //No I18N
		VARIATION_TARGET_URL_UPDATE("variation_target_url_update",18,"activity.variationtargeturl.update"), //No I18N
		VARIATION_SEQUENCE_UPDATE("variation_sequence_update",19,"activity.variationsequence.update"), //No I18N
		VARIATION_TRAFFIC_ALLOCATION_UPDATE("variation_traffic_allocation_update",20,"activity.variationtrafficallocation.update"), //No I18N
		VARIATION_CHANGES_UPDATE("variation_changes_update",21,"activity.variationchanges.update"), //No I18N
		EXP_GOAL_CREATE("exp_goal_create",22,"activity.expgoal.create"), //No I18N
		EXP_GOAL_DELETE("exp_goal_delete",23,"activity.expgoal.delete"), //No I18N
		EXP_GOAL_UPDATE("exp_goal_update",24,"activity.expgoal.update"), //No I18N
		EXP_AUDIENCE_CREATE("exp_audience_create",25,"activity.expaudience.create"), //No I18N
		EXP_AUDIENCE_DELETE("exp_audience_delete",26,"activity.expaudience.delete"), //No I18N
		EXP_URLPARAM_CREATE("exp_urlparam_create",27,"activity.expurlparam.create"), //No I18N
		EXP_COOKIE_CREATE("exp_cookie_create",28,"activity.expcookie.create"), //No I18N
		EXP_JSVAR_CREATE("exp_jsvar_create",29,"activity.expjsvar.create"), //No I18N
		EXP_CUSTDIMENSION_CREATE("exp_custdimension_create",30,"activity.expcustdimension.create"), //No I18N
		EXP_URLPARAM_DELETE("exp_urlparam_delete",31,"activity.expurlparam.delete"), //No I18N
		EXP_COOKIE_DELETE("exp_cookie_delete",32,"activity.expcookie.delete"), //No I18N
		EXP_JSVAR_DELETE("exp_jsvar_delete",33,"activity.expjsvar.delete"), //No I18N
		EXP_CUSTDIMENSION_DELETE("exp_custdimension_delete",34,"activity.expcustdimension.delete"), //No I18N
		EXP_EXCLUDEURLS_UPDATE("exp_excludeurls_updated",35,"activity.expexcludeurls.update"), //No I18N
		EXP_INCLUDEURLS_UPDATE("exp_includeurls_updated",36,"activity.expincludeurls.update"), //No I18N
		EXP_AUDIENCE_UPDATE("exp_audience_update",37,"activity.expaudience.update"), //No I18N
		EXP_IS_HEATMAP_ENABLED_UPDATE("exp_is_heatmap_enabled_update",38,"activity.heatmapenabled.update"), //No I18N
		EXP_REPORT_SHARING("exp_report_sharing",39,"activity.reportsharing.update"), //No I18N
		EXP_INTEGRATION_CREATE("exp_integration_create",40,"activity.exp.integration.create"), //No I18N
		EXP_INTEGRATION_DELETE("exp_integration_delete",41,"activity.exp.integration.delete"), //No I18N
		PROJECT_GOAL_CREATE("project_goal_create",42,"activity.projectgoal.create"), //No I18N
		PROJECT_GOAL_INCLUDEURLS_UPDATE("project_goal_includeurls_update",43,"activity.expincludeurls.update"), //No I18N
		PROJECT_GOAL_EXCLUDEURLS_UPDATE("project_goal_excludeurls_update",44,"activity.expexcludeurls.update"), //No I18N
		PROJECT_GOAL_NAME_UPDATE("project_goal_name_update",45,"activity.projectgoal.name.update"), //No I18N
		PROJECT_GOAL_UPDATE("project_goal_name_update",46,"activity.projectgoal.update"), //No I18N
		PROJECT_GOAL_URL_UPDATE("project_goal_url_update",47,"activity.projectgoal.url.update"), //No I18N
		PROJECT_GOAL_DELETE("project_goal_delete",48,"activity.projectgoal.delete"), //No I18N
		PRIVACY_CONSENT_VALUE_UPDATE("privacy_consent_value_update",49,"activity.privacyconsentvalue.update"),//No I18N
		PROJECT_GOAL_STATUS("project_goal_status",50,"activity.projectgoal.status"); //No I18N

		
		private String eventName;
		private Integer eventValue;
		private String eventMessagekey;
		
		public String getEventName() {
			return eventName;
		}
		public void setEventName(String eventName) {
			this.eventName = eventName;
		}
		public Integer getEventValue() {
			return eventValue;
		}
		public void setEventValue(Integer eventValue) {
			this.eventValue = eventValue;
		}
		public String getEventMessageKey() {
			return eventMessagekey;
		}
		public void setEventMessageKey(String eventMessagekey) {
			this.eventMessagekey = eventMessagekey;
		}
		
		private EventType(String eventName, Integer eventValue, String eventMessagekey)
		{
			this.eventName = eventName;
			this.eventValue = eventValue;
			this.eventMessagekey = eventMessagekey;
		}
		
		public static EventType getEventTypeByValue(int eventValue)
		{
			EventType eType = null; 
			for(EventType eventType:EventType.values())
			{
				if(eventType.getEventValue().equals(eventValue))
				{
					eType = eventType;
					break;
				}
			}
			return eType;
		}
		
	}
	
	public static enum Module {
		PROJECT(1),
		EXPERIMENT(2),
		VARIATION(3),
		EXPERIMENT_GOAL(4),
		EXPERIMENT_AUDIENCE(5),
		EXPERIMENT_DYNAMIC_ATTRIBUTE(6),
		INTEGRATION(7),
		PROJECT_GOAL(8);
		
		private Integer value;

		public Integer getValue() {
			return value;
		}

		public void setValue(Integer value) {
			this.value = value;
		}
		
		private Module(Integer value)
		{
			this.value = value;
		}
	}
	
	public static enum ActivityRequestType
	{
		EXPERIMENT(1),
		PROJECT(2),
		USER(3),
		PROJECT_GOAL(4);
		
		private Integer typeValue;

		public Integer getTypeValue() {
			return typeValue;
		}

		public void setTypeValue(Integer typeValue) {
			this.typeValue = typeValue;
		}
		
		private ActivityRequestType(Integer typeValue)
		{
			this.typeValue = typeValue;
		}
		
		public static ActivityRequestType getActivityRequestTypeByValue(int typeValue)
		{
			ActivityRequestType requestType = null; 
			for(ActivityRequestType type:ActivityRequestType.values())
			{
				if(type.getTypeValue().equals(typeValue))
				{
					requestType = type;
					break;
				}
			}
			return requestType;
		}
	}
	
	public static final String EVENT_ACTIVITY_LOG_ID = "event_activity_log_id";			// No I18N
	public static final String PROJECT_ID = "project_id";			// No I18N
	public static final String PROJECT_NAME = "project_name";			// No I18N
	public static final String EXPERIMENT_ID = "experiment_id";			// No I18N
	public static final String VARIATION_ID = "variation_id";			// No I18N
	public static final String GOAL_ID = "goal_id";			// No I18N
	public static final String EXPERIMENT_NAME = "experiment_name";			// No I18N
	public static final String MODULE = "module";			// No I18N
	public static final String EVENT_TYPE = "event_type";			// No I18N
	public static final String VALUE = "value";			// No I18N
	public static final String OLD_VALUE = "old_value";			// No I18N
	public static final String TIME = "time";			// No I18N
	public static final String FORMATTED_TIME = "formatted_time";			// No I18N
	public static final String FORMATTED_TIME_ONLY = "formatted_time_only";			// No I18N
	public static final String FORMATTED_DATE_ONLY = "formatted_date_only";			// No I18N
	public static final String USER_ID = "user_id";			// No I18N
	public static final String USER_ID_TOKEN = "user_id_token";			// No I18N
	public static final String USER_NAME = "user_name";			// No I18N
	public static final String MESSAGE = "message";			// No I18N
	
	public static final String EVENT_MODULE_DETAIL_ID = "event_module_detail_id";			// No I18N
	public static final String MODULE_TYPE = "module_type";			// No I18N
	public static final String MODULE_ELEMENT_ID = "module_element_id";			// No I18N
	public static final String MODULE_ELEMENT_NAME = "module_element_name";			// No I18N
	
	public static final String LINK_NAME = "link_name";			// No I18N
	public static final String TYPE = "type";			// No I18N
	
	public static final String START_DATE = "start_date";	// NO I18N
	public static final String END_DATE = "end_date";	// NO I18N
	
	public static final List<Constants> EVENT_ACTIVITY_LOG_CONSTANTS;
	
	static{
		List<Constants> eventActivityLogConstants = new ArrayList<Constants>();
		eventActivityLogConstants.add(new Constants(EVENT_ACTIVITY_LOG_ID,EVENT_ACTIVITY_LOG.EVENT_ACTIVITY_LOG_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		eventActivityLogConstants.add(new Constants(PROJECT_ID,EVENT_ACTIVITY_LOG.PROJECT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.TRUE));
		eventActivityLogConstants.add(new Constants(EXPERIMENT_ID,EVENT_ACTIVITY_LOG.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.TRUE));
		eventActivityLogConstants.add(new Constants(VARIATION_ID,EVENT_ACTIVITY_LOG.VARIATION_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.TRUE));
		eventActivityLogConstants.add(new Constants(GOAL_ID,EVENT_ACTIVITY_LOG.GOAL_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.TRUE));
		eventActivityLogConstants.add(new Constants(MODULE,EVENT_ACTIVITY_LOG.MODULE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		eventActivityLogConstants.add(new Constants(EVENT_TYPE,EVENT_ACTIVITY_LOG.EVENT_TYPE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		eventActivityLogConstants.add(new Constants(VALUE,EVENT_ACTIVITY_LOG.VALUE,ZABConstants.STRING,Boolean.TRUE,Boolean.TRUE));
		eventActivityLogConstants.add(new Constants(OLD_VALUE,EVENT_ACTIVITY_LOG.OLD_VALUE,ZABConstants.STRING,Boolean.TRUE,Boolean.TRUE));
		eventActivityLogConstants.add(new Constants(TIME,EVENT_ACTIVITY_LOG.TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		eventActivityLogConstants.add(new Constants(USER_ID,EVENT_ACTIVITY_LOG.USER_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.TRUE));
		EVENT_ACTIVITY_LOG_CONSTANTS = Collections.unmodifiableList(eventActivityLogConstants);
	}
	
	public static final List<Constants> EVENT_MODULE_DETAIL_CONSTANTS;
	
	static{
		List<Constants> eventModuleDetailConstants = new ArrayList<Constants>();
		eventModuleDetailConstants.add(new Constants(EVENT_MODULE_DETAIL_ID,EVENT_MODULE_DETAIL.EVENT_MODULE_DETAIL_ID,ZABConstants.LONG,Boolean.FALSE,Boolean.FALSE));
		eventModuleDetailConstants.add(new Constants(MODULE_TYPE,EVENT_MODULE_DETAIL.MODULE_TYPE,ZABConstants.INTEGER,Boolean.TRUE,Boolean.FALSE));
		eventModuleDetailConstants.add(new Constants(MODULE_ELEMENT_ID,EVENT_MODULE_DETAIL.MODULE_ELEMENT_ID,ZABConstants.LONG,Boolean.TRUE,Boolean.FALSE));
		eventModuleDetailConstants.add(new Constants(MODULE_ELEMENT_NAME,EVENT_MODULE_DETAIL.MODULE_ELEMENT_NAME,ZABConstants.STRING,Boolean.TRUE,Boolean.FALSE));
		EVENT_MODULE_DETAIL_CONSTANTS = Collections.unmodifiableList(eventModuleDetailConstants);
	}
	
	//Project attributes to be traced for logging if any update occurs
	public static final List<String> PROJECT_ATTR_TO_TRACE;
	
	static
	{
		List<String> projAttrToTrace = new ArrayList<String>();
		projAttrToTrace.add(ProjectConstants.PROJECT_NAME);
		projAttrToTrace.add(ProjectConstants.PROJECT_STATUS);
		projAttrToTrace.add(ProjectConstants.PROJECT_DESCRIPTION);
		projAttrToTrace.add(PrivacyConstants.PRIVACY_VALUE);
		PROJECT_ATTR_TO_TRACE = Collections.unmodifiableList(projAttrToTrace);
	}
		
	//Experiment attributes to be traced for logging if any update occurs
	public static final List<String> EXPERIMENT_ATTR_TO_TRACE;
	
	static
	{
		List<String> experimentAttrToTrace = new ArrayList<String>();
		experimentAttrToTrace.add(ExperimentConstants.EXPERIMENT_NAME);
		experimentAttrToTrace.add(ExperimentConstants.EXPERIMENT_STATUS);
		experimentAttrToTrace.add(ExperimentConstants.START_DATE);
		experimentAttrToTrace.add(ExperimentConstants.END_DATE);
		experimentAttrToTrace.add(ExperimentConstants.MAKE_PUBLIC);
		EXPERIMENT_ATTR_TO_TRACE = Collections.unmodifiableList(experimentAttrToTrace);
	}
	
	public static final List<String> ABSPLIT_EXPERIMENT_ATTR_TO_TRACE;
	
	static
	{
		List<String> experimentAttrToTrace = new ArrayList<String>();
		experimentAttrToTrace.add(ExperimentConstants.EXPERIMENT_URL);
		experimentAttrToTrace.add(ExperimentConstants.EXCLUDE_URLS);
		experimentAttrToTrace.add(ExperimentConstants.INCLUDE_URLS);
		experimentAttrToTrace.add(ExperimentConstants.PERMITTED_TRAFFIC);
		experimentAttrToTrace.add(ExperimentConstants.STATISTICAL_SIGNIFICANCE);
		experimentAttrToTrace.add(ExperimentConstants.IS_HEATMAP_ENABLED);
		ABSPLIT_EXPERIMENT_ATTR_TO_TRACE = Collections.unmodifiableList(experimentAttrToTrace);
	}
	
	public static final List<String> PROJECT_GOAL_ATTR_TO_TRACE;
	
	static
	{
		List<String> experimentAttrToTrace = new ArrayList<String>();
		experimentAttrToTrace.add(GoalConstants.GOAL_URL);
		experimentAttrToTrace.add(GoalConstants.GOAL_NAME);
		experimentAttrToTrace.add(GoalConstants.EXCLUDE_URLS);
		experimentAttrToTrace.add(GoalConstants.INCLUDE_URLS);
		experimentAttrToTrace.add(GoalConstants.GOAL_STATUS);
		PROJECT_GOAL_ATTR_TO_TRACE = Collections.unmodifiableList(experimentAttrToTrace);
	}
	
	
	public static final List<String> FORM_ANALYTICS_EXPERIMENT_ATTR_TO_TRACE;

	static
	{
		List<String> experimentAttrToTrace = new ArrayList<String>();
		experimentAttrToTrace.add(ExperimentConstants.EXPERIMENT_URL);
		experimentAttrToTrace.add(ExperimentConstants.EXCLUDE_URLS);
		experimentAttrToTrace.add(ExperimentConstants.INCLUDE_URLS);
		experimentAttrToTrace.add(ExperimentConstants.PERMITTED_TRAFFIC);
		experimentAttrToTrace.add(ExperimentConstants.STATISTICAL_SIGNIFICANCE);
		FORM_ANALYTICS_EXPERIMENT_ATTR_TO_TRACE = Collections.unmodifiableList(experimentAttrToTrace);
	}
	
	//Variation attributes to be traced for logging if any update occurs
	public static final List<String> VARIATION_ATTR_TO_TRACE;
	
	static
	{
		List<String> variationAttrToTrace = new ArrayList<String>();
		variationAttrToTrace.add(VariationConstants.VARIATION_NAME);
		variationAttrToTrace.add(VariationConstants.TARGET_URL);
		variationAttrToTrace.add(VariationConstants.SEQUENCE);
		variationAttrToTrace.add(VariationConstants.TRAFFIC_ALLOCATION);
		variationAttrToTrace.add(VariationConstants.VARIATION_CHANGES);
		VARIATION_ATTR_TO_TRACE = Collections.unmodifiableList(variationAttrToTrace);
	}
	
	public static final List<String> HEATMPA_EXPERIMENT_ATTR_TO_TRACE;
	
	static
	{
		List<String> experimentAttrToTrace = new ArrayList<String>();
		experimentAttrToTrace.add(HeatmapExperimentConstants.EXPERIMENT_URL);
		experimentAttrToTrace.add(HeatmapExperimentConstants.EXCLUDE_URLS);
		experimentAttrToTrace.add(HeatmapExperimentConstants.INCLUDE_URLS);
		experimentAttrToTrace.add(HeatmapExperimentConstants.PERMITTED_TRAFFIC);
		experimentAttrToTrace.add(HeatmapExperimentConstants.MAX_VISITORS);
		HEATMPA_EXPERIMENT_ATTR_TO_TRACE = Collections.unmodifiableList(experimentAttrToTrace);
	}
	
	// Collection to maintain the readable text for each property to be used for event logging
	public static final Map<String, String> READABLE_TEXT_COLLECTION;
	
	static
	{
		HashMap<String, String> readableText = new HashMap<String, String>();
		readableText.put(ProjectConstants.PROJECT_NAME, "Display name"); //No I18N
		readableText.put(ProjectConstants.PROJECT_STATUS, "Project status"); //No I18N
		readableText.put(ProjectConstants.PROJECT_DESCRIPTION, "Project description"); //No I18N
		
		readableText.put(ExperimentConstants.EXPERIMENT_NAME, "Display name"); //No I18N
		readableText.put(ExperimentConstants.EXPERIMENT_URL, "Experiment url"); //No I18N
		readableText.put(ExperimentConstants.EXPERIMENT_STATUS, "Experiment status"); //No I18N
		readableText.put(ExperimentConstants.PERMITTED_TRAFFIC, "Permitted traffic"); //No I18N
		readableText.put(ExperimentConstants.STATISTICAL_SIGNIFICANCE, "Statistical significance"); //No I18N
		readableText.put(ExperimentConstants.START_DATE, "Start date"); //No I18N
		readableText.put(ExperimentConstants.END_DATE, "End date"); //No I18N
		
		readableText.put(VariationConstants.VARIATION_NAME, "Display name"); //No I18N
		readableText.put(VariationConstants.TARGET_URL, "Target url"); //No I18N
		readableText.put(VariationConstants.SEQUENCE, "Sequence"); //No I18N
		readableText.put(VariationConstants.TRAFFIC_ALLOCATION, "Traffic allocation"); //No I18N
		readableText.put(VariationConstants.VARIATION_CHANGES, "Variation content"); //No I18N
		
		READABLE_TEXT_COLLECTION = Collections.unmodifiableMap(readableText);
	}

}
