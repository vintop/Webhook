//$Id$
package com.zoho.abtest.eventactivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.SortColumn;
import com.adventnet.iam.User;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.eventactivity.EventActivityConstants.ActivityRequestType;
import com.zoho.abtest.eventactivity.EventActivityConstants.EventType;
import com.zoho.abtest.eventactivity.EventActivityConstants.Module;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentMode;
import com.zoho.abtest.integration.IntegrationConstants.Integ;
import com.zoho.abtest.project.ProjectConstants;
import com.zoho.abtest.user.ZABUser;
import com.zoho.abtest.user.ZABUserDetailWrapper;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.abtest.APP_USER;
import com.zoho.abtest.EVENT_ACTIVITY_LOG;

public class EventActivityLog extends ZABModel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = Logger.getLogger(EventActivityLog.class.getName());
	
	private Long eventActivityLogId;
	private Long projectId;
	private String projectDisplayName;
	private Long experimentId;
	private Long variationId;
	private Long goalId;
	private String experimentDisplayName;
	private Integer module;
	private Integer eventType;
	private String value;
	private String oldValue;
	private String message;
	private Long time;
	private String formattedTime;
	private String dateOnly;
	private String timeOnly;
	private Long userId;
	private String userName;
	
	
	public String getDateOnly() {
		return dateOnly;
	}
	public void setDateOnly(String dateOnly) {
		this.dateOnly = dateOnly;
	}
	public String getTimeOnly() {
		return timeOnly;
	}
	public void setTimeOnly(String timeOnly) {
		this.timeOnly = timeOnly;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getOldValue() {
		return oldValue;
	}
	public void setOldValue(String oldValue) {
		this.oldValue = oldValue;
	}
	public Long getVariationId() {
		return variationId;
	}
	public void setVariationId(Long variationId) {
		this.variationId = variationId;
	}
	public Long getGoalId() {
		return goalId;
	}
	public void setGoalId(Long goalId) {
		this.goalId = goalId;
	}

	public String getProjectDisplayName() {
		return projectDisplayName;
	}
	public void setProjectDisplayName(String projectDisplayName) {
		this.projectDisplayName = projectDisplayName;
	}
	public String getExperimentDisplayName() {
		return experimentDisplayName;
	}
	public void setExperimentDisplayName(String experimentDisplayName) {
		this.experimentDisplayName = experimentDisplayName;
	}
	public Long getProjectId() {
		return projectId;
	}
	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}
	public String getFormattedTime() {
		return formattedTime;
	}
	public void setFormattedTime(String formattedTime) {
		this.formattedTime = formattedTime;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Long getEventActivityLogId() {
		return eventActivityLogId;
	}
	public void setEventActivityLogId(Long eventActivityLogId) {
		this.eventActivityLogId = eventActivityLogId;
	}
	public Long getExperimentId() {
		return experimentId;
	}
	public void setExperimentId(Long experimentId) {
		this.experimentId = experimentId;
	}
	public Integer getModule() {
		return module;
	}
	public void setModule(Integer module) {
		this.module = module;
	}
	public Integer getEventType() {
		return eventType;
	}
	public void setEventType(Integer eventType) {
		this.eventType = eventType;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Long getTime() {
		return time;
	}
	public void setTime(Long time) {
		this.time = time;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	
	public static void createEventActivityLog(HashMap<String, String> hs)
	{
		try
		{
			ZABModel.createRow(EventActivityConstants.EVENT_ACTIVITY_LOG_CONSTANTS, EVENT_ACTIVITY_LOG.TABLE, hs);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	public static List<EventActivityLog> getEventActivityLogByExperiment(Long experimentId, Long startDate, Long endDate)
	{
		ArrayList<EventActivityLog> eventActivityLogs = new ArrayList<EventActivityLog>();
		EventActivityLog eventActivityLog;
		try
		{
			Criteria finalCriteria = null;
			Criteria criteria = new Criteria(new Column(EVENT_ACTIVITY_LOG.TABLE,EVENT_ACTIVITY_LOG.EXPERIMENT_ID),experimentId,QueryConstants.EQUAL);
			finalCriteria = criteria;
			if(startDate != null)
			{
				Criteria startDateCriteria = new Criteria(new Column(EVENT_ACTIVITY_LOG.TABLE,EVENT_ACTIVITY_LOG.TIME),startDate,QueryConstants.GREATER_EQUAL);
				finalCriteria = finalCriteria.and(startDateCriteria);
			}
			if(endDate != null)
			{
				Criteria endDateCriteria = new Criteria(new Column(EVENT_ACTIVITY_LOG.TABLE,EVENT_ACTIVITY_LOG.TIME),endDate,QueryConstants.LESS_EQUAL);
				finalCriteria = finalCriteria.and(endDateCriteria);
			}
			SortColumn sortColumn = new SortColumn(EVENT_ACTIVITY_LOG.TABLE, EVENT_ACTIVITY_LOG.TIME, Boolean.FALSE);
			Join join = new Join(EVENT_ACTIVITY_LOG.TABLE, APP_USER.TABLE, new String[]{EVENT_ACTIVITY_LOG.USER_ID}, new String[]{APP_USER.USER_ID},Join.LEFT_JOIN);
			DataObject dataObj = ZABModel.getRow(EVENT_ACTIVITY_LOG.TABLE, finalCriteria, sortColumn, new Join[]{join});	
			Iterator<?> iterator = dataObj.getRows(EVENT_ACTIVITY_LOG.TABLE);
			while(iterator.hasNext())
			{
				Row row = (Row)iterator.next();
				eventActivityLog = getEventActivityLogFromRow(row,dataObj,ActivityRequestType.EXPERIMENT.getTypeValue());
				eventActivityLogs.add(eventActivityLog);
			}
			//Setting user names
			ZABUser.setUserDetails(eventActivityLogs, new ZABUserDetailWrapper() {
				@Override
				public void setUserDetails(User user, ZABModel model) {
					EventActivityLog log = (EventActivityLog)model;
					log.setUserName(user.getFirstName() + " " + user.getLastName());
				}
				
				@Override
				public Long getUserId(ZABModel model) {
					EventActivityLog log = (EventActivityLog)model;
					return log.getUserId();
				}
			});
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		return eventActivityLogs;
	}
	
	public static List<EventActivityLog> getEventActivityLogByGoal(Long goalId, Long startDate, Long endDate)
	{
		ArrayList<EventActivityLog> eventActivityLogs = new ArrayList<EventActivityLog>();
		EventActivityLog eventActivityLog;
		try
		{
			Criteria finalCriteria = null;
			Criteria criteria = new Criteria(new Column(EVENT_ACTIVITY_LOG.TABLE,EVENT_ACTIVITY_LOG.GOAL_ID),goalId,QueryConstants.EQUAL);
			finalCriteria = criteria;
			if(startDate != null)
			{
				Criteria startDateCriteria = new Criteria(new Column(EVENT_ACTIVITY_LOG.TABLE,EVENT_ACTIVITY_LOG.TIME),startDate,QueryConstants.GREATER_EQUAL);
				finalCriteria = finalCriteria.and(startDateCriteria);
			}
			if(endDate != null)
			{
				Criteria endDateCriteria = new Criteria(new Column(EVENT_ACTIVITY_LOG.TABLE,EVENT_ACTIVITY_LOG.TIME),endDate,QueryConstants.LESS_EQUAL);
				finalCriteria = finalCriteria.and(endDateCriteria);
			}
			SortColumn sortColumn = new SortColumn(EVENT_ACTIVITY_LOG.TABLE, EVENT_ACTIVITY_LOG.TIME, Boolean.FALSE);
			Join join = new Join(EVENT_ACTIVITY_LOG.TABLE, APP_USER.TABLE, new String[]{EVENT_ACTIVITY_LOG.USER_ID}, new String[]{APP_USER.USER_ID},Join.LEFT_JOIN);
			DataObject dataObj = ZABModel.getRow(EVENT_ACTIVITY_LOG.TABLE, finalCriteria, sortColumn, new Join[]{join});	
			Iterator<?> iterator = dataObj.getRows(EVENT_ACTIVITY_LOG.TABLE);
			while(iterator.hasNext())
			{
				Row row = (Row)iterator.next();
				eventActivityLog = getEventActivityLogFromRow(row,dataObj,ActivityRequestType.PROJECT_GOAL.getTypeValue());
				eventActivityLogs.add(eventActivityLog);
			}
			//Setting user names
			ZABUser.setUserDetails(eventActivityLogs, new ZABUserDetailWrapper() {
				@Override
				public void setUserDetails(User user, ZABModel model) {
					EventActivityLog log = (EventActivityLog)model;
					log.setUserName(user.getFirstName() + " " + user.getLastName());
				}
				
				@Override
				public Long getUserId(ZABModel model) {
					EventActivityLog log = (EventActivityLog)model;
					return log.getUserId();
				}
			});
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		return eventActivityLogs;
	}
	
	public static List<EventActivityLog> getEventActivityLogByExperimentAndType(Long experimentId, Long startDate, Long endDate, int type)
	{
		ArrayList<EventActivityLog> eventActivityLogs = new ArrayList<EventActivityLog>();
		EventActivityLog eventActivityLog;
		try
		{
			Criteria finalCriteria = null;
			Criteria criteria = new Criteria(new Column(EVENT_ACTIVITY_LOG.TABLE,EVENT_ACTIVITY_LOG.EXPERIMENT_ID),experimentId,QueryConstants.EQUAL);
			finalCriteria = criteria;
			if(startDate != null)
			{
				Criteria startDateCriteria = new Criteria(new Column(EVENT_ACTIVITY_LOG.TABLE,EVENT_ACTIVITY_LOG.TIME),startDate,QueryConstants.GREATER_EQUAL);
				finalCriteria = finalCriteria.and(startDateCriteria);
			}
			if(endDate != null)
			{
				Criteria endDateCriteria = new Criteria(new Column(EVENT_ACTIVITY_LOG.TABLE,EVENT_ACTIVITY_LOG.TIME),endDate,QueryConstants.LESS_EQUAL);
				finalCriteria = finalCriteria.and(endDateCriteria);
			}
			
			Criteria eventTypeCriteria = new Criteria(new Column(EVENT_ACTIVITY_LOG.TABLE,EVENT_ACTIVITY_LOG.EVENT_TYPE),type,QueryConstants.EQUAL);
			finalCriteria = finalCriteria.and(eventTypeCriteria);
			
			SortColumn sortColumn = new SortColumn(EVENT_ACTIVITY_LOG.TABLE, EVENT_ACTIVITY_LOG.TIME, Boolean.TRUE);
			Join join = new Join(EVENT_ACTIVITY_LOG.TABLE, APP_USER.TABLE, new String[]{EVENT_ACTIVITY_LOG.USER_ID}, new String[]{APP_USER.USER_ID},Join.LEFT_JOIN);
			DataObject dataObj = ZABModel.getRow(EVENT_ACTIVITY_LOG.TABLE, finalCriteria, sortColumn, new Join[]{join});	
			Iterator<?> iterator = dataObj.getRows(EVENT_ACTIVITY_LOG.TABLE);
			while(iterator.hasNext())
			{
				Row row = (Row)iterator.next();
				eventActivityLog = getEventActivityLogFromRow(row,dataObj,ActivityRequestType.EXPERIMENT.getTypeValue());
				eventActivityLogs.add(eventActivityLog);
			}
			//Setting user names
			ZABUser.setUserDetails(eventActivityLogs, new ZABUserDetailWrapper() {
				@Override
				public void setUserDetails(User user, ZABModel model) {
					EventActivityLog log = (EventActivityLog)model;
					log.setUserName(user.getFirstName());
				}
				
				@Override
				public Long getUserId(ZABModel model) {
					EventActivityLog log = (EventActivityLog)model;
					return log.getUserId();
				}
			});
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		return eventActivityLogs;
	}
	
	public static List<EventActivityLog> getEventActivityLogByProject(Long projectId, Long startDate, Long endDate)
	{
		List<EventActivityLog> eventActivityLogs = new ArrayList<EventActivityLog>();
		EventActivityLog eventActivityLog;
		try
		{
			Criteria finalCriteria = null;
			Criteria criteria = new Criteria(new Column(EVENT_ACTIVITY_LOG.TABLE,EVENT_ACTIVITY_LOG.PROJECT_ID),projectId,QueryConstants.EQUAL);
			finalCriteria = criteria;
			if(startDate != null)
			{
				Criteria startDateCriteria = new Criteria(new Column(EVENT_ACTIVITY_LOG.TABLE,EVENT_ACTIVITY_LOG.TIME),startDate,QueryConstants.GREATER_EQUAL);
				finalCriteria = finalCriteria.and(startDateCriteria);
			}
			if(endDate != null)
			{
				Criteria endDateCriteria = new Criteria(new Column(EVENT_ACTIVITY_LOG.TABLE,EVENT_ACTIVITY_LOG.TIME),endDate,QueryConstants.LESS_EQUAL);
				finalCriteria = finalCriteria.and(endDateCriteria);
			}
			SortColumn sortColumn = new SortColumn(EVENT_ACTIVITY_LOG.TABLE, EVENT_ACTIVITY_LOG.TIME, Boolean.FALSE);
			Join join = new Join(EVENT_ACTIVITY_LOG.TABLE, APP_USER.TABLE, new String[]{EVENT_ACTIVITY_LOG.USER_ID}, new String[]{APP_USER.USER_ID},Join.LEFT_JOIN);
			DataObject dataObj = ZABModel.getRow(EVENT_ACTIVITY_LOG.TABLE, finalCriteria, sortColumn, new Join[]{join});	
			Iterator<?> iterator = dataObj.getRows(EVENT_ACTIVITY_LOG.TABLE);
			while(iterator.hasNext())
			{
				Row row = (Row)iterator.next();
				eventActivityLog = getEventActivityLogFromRow(row,dataObj,ActivityRequestType.PROJECT.getTypeValue());
				eventActivityLogs.add(eventActivityLog);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		return eventActivityLogs;
	}
	
	public static List<EventActivityLog> getEventActivityLogByUser(Long userId, Long startDate, Long endDate)
	{
		List<EventActivityLog> eventActivityLogs = new ArrayList<EventActivityLog>();
		EventActivityLog eventActivityLog;
		try
		{
			Criteria finalCriteria = null;
			Criteria criteria = new Criteria(new Column(EVENT_ACTIVITY_LOG.TABLE,EVENT_ACTIVITY_LOG.USER_ID),userId,QueryConstants.EQUAL);
			finalCriteria = criteria;
			if(startDate != null)
			{
				Criteria startDateCriteria = new Criteria(new Column(EVENT_ACTIVITY_LOG.TABLE,EVENT_ACTIVITY_LOG.TIME),startDate,QueryConstants.GREATER_EQUAL);
				finalCriteria = finalCriteria.and(startDateCriteria);
			}
			if(endDate != null)
			{
				Criteria endDateCriteria = new Criteria(new Column(EVENT_ACTIVITY_LOG.TABLE,EVENT_ACTIVITY_LOG.TIME),endDate,QueryConstants.LESS_EQUAL);
				finalCriteria = finalCriteria.and(endDateCriteria);
			}
			SortColumn sortColumn = new SortColumn(EVENT_ACTIVITY_LOG.TABLE, EVENT_ACTIVITY_LOG.TIME, Boolean.FALSE);
			Join join = new Join(EVENT_ACTIVITY_LOG.TABLE, APP_USER.TABLE, new String[]{EVENT_ACTIVITY_LOG.USER_ID}, new String[]{APP_USER.USER_ID},Join.INNER_JOIN);
			DataObject dataObj = ZABModel.getRow(EVENT_ACTIVITY_LOG.TABLE, finalCriteria, sortColumn, new Join[]{join});	
			Iterator<?> iterator = dataObj.getRows(EVENT_ACTIVITY_LOG.TABLE);
			while(iterator.hasNext())
			{
				Row row = (Row)iterator.next();
				eventActivityLog = getEventActivityLogFromRow(row,dataObj,ActivityRequestType.USER.getTypeValue());
				eventActivityLogs.add(eventActivityLog);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		return eventActivityLogs;
	}
	
	public static EventActivityLog getEventActivityLogFromRow(Row row,DataObject dataObj,Integer activityRequestType)
	{
		EventActivityLog eventActivityLog = new EventActivityLog();
		
		try
		{
			Long experimentId = (Long)row.get(EVENT_ACTIVITY_LOG.EXPERIMENT_ID);
			Long projectId = (Long)row.get(EVENT_ACTIVITY_LOG.PROJECT_ID);
			Long variationId = (Long)row.get(EVENT_ACTIVITY_LOG.VARIATION_ID);
			Long goalId = (Long)row.get(EVENT_ACTIVITY_LOG.GOAL_ID);
			Long time = (Long)row.get(EVENT_ACTIVITY_LOG.TIME);
			Long userId = (Long)row.get(EVENT_ACTIVITY_LOG.USER_ID);
			
			String projectDisplayName = null;
			String experimentDisplayName = null;
			String variationDisplayName = null;
			String goalDisplayName = null;
			Integer eventType = (Integer)row.get(EVENT_ACTIVITY_LOG.EVENT_TYPE);
			String value = (String)row.get(EVENT_ACTIVITY_LOG.VALUE);
			String oldValue = (String)row.get(EVENT_ACTIVITY_LOG.OLD_VALUE);
			String message = "";
			
			if(projectId != null)
			{
				projectDisplayName = EventModuleDetail.getEventModuleElementDisplayName(Module.PROJECT.getValue(), projectId);
			}
			if(experimentId != null)
			{
				experimentDisplayName = EventModuleDetail.getEventModuleElementDisplayName(Module.EXPERIMENT.getValue(), experimentId);
			}
			if(variationId != null)
			{
				variationDisplayName = EventModuleDetail.getEventModuleElementDisplayName(Module.VARIATION.getValue(), variationId);
			}
			if(goalId != null)
			{
				goalDisplayName = EventModuleDetail.getEventModuleElementDisplayName(Module.PROJECT_GOAL.getValue(), goalId);
			}
			
			message = prepareActivityMessage(eventType, projectDisplayName, experimentDisplayName, variationDisplayName, value, oldValue, activityRequestType);
			
			eventActivityLog.setEventActivityLogId((Long)row.get(EVENT_ACTIVITY_LOG.EVENT_ACTIVITY_LOG_ID));
			eventActivityLog.setProjectId(projectId);
			eventActivityLog.setProjectDisplayName(projectDisplayName);
			eventActivityLog.setExperimentId(experimentId);
			eventActivityLog.setExperimentDisplayName(experimentDisplayName);
			eventActivityLog.setVariationId(variationId);
			eventActivityLog.setGoalId(goalId);
			eventActivityLog.setModule((Integer)row.get(EVENT_ACTIVITY_LOG.MODULE));
			eventActivityLog.setEventType(eventType);
			eventActivityLog.setValue(value);
			eventActivityLog.setOldValue(oldValue);
			eventActivityLog.setMessage(message);
			HashMap<String, String> formattedTimes = ZABUtil.getDateTimeAllFormatted(time);
			String formattedTime = formattedTimes.get(ZABConstants.DATETIME);
			String formattedTimeOnly = formattedTimes.get(ZABConstants.TIME);
			String formattedDateOnly = formattedTimes.get(ZABConstants.DATE);
			eventActivityLog.setTime(time);
			eventActivityLog.setFormattedTime(formattedTime);
			eventActivityLog.setDateOnly(formattedDateOnly);
			eventActivityLog.setTimeOnly(formattedTimeOnly);
			eventActivityLog.setUserId(userId);
			
			//Getting user name from userId
			//Criteria criteria = new Criteria(new Column(APP_USER.TABLE,APP_USER.USER_ID), userId, QueryConstants.EQUAL);
			//Row userRow = dataObj.getRow(APP_USER.TABLE, criteria);
			//eventActivityLog.setUserName((String)userRow.get(APP_USER.LAST_NAME));
			//TODO get name from IAMUtil
			eventActivityLog.setUserName("");
			
			eventActivityLog.setSuccess(Boolean.TRUE);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			eventActivityLog.setSuccess(Boolean.FALSE);
		}
		
		return eventActivityLog;
	}
	
	public static String prepareActivityMessage(Integer eventType, String projectName, String experimentName, String variationName, String value, String oldValue, int activityRequestType)
	{
		String message = "";
		try
		{
			//Preparing the additional information message based on the request type
			ActivityRequestType requestType = ActivityRequestType.getActivityRequestTypeByValue(activityRequestType);
			switch(requestType)
			{
			case EXPERIMENT:
			case PROJECT_GOAL:
				break;
			case PROJECT:
				if(experimentName != null)
				{
					message = ZABAction.getMessage(EventActivityConstants.RESOURCE_EXPERIMENT_INFO, new String[]{experimentName});
				}
				break;
			case USER:
				if(projectName != null)
				{
					message = ZABAction.getMessage(EventActivityConstants.RESOURCE_PROJECT_INFO, new String[]{projectName});
					if(experimentName != null)
					{
						message += ZABAction.getMessage(EventActivityConstants.RESOURCE_EXPERIMENT_INFO, new String[]{experimentName});
					}
				}
				break;
			}
			
			//Preparing the actual log message
			EventType event = EventType.getEventTypeByValue(eventType);
			switch(event)
			{
			case PROJECT_CREATE:
				message += ZABAction.getMessage(EventType.PROJECT_CREATE.getEventMessageKey());
				break;
			case PROJECT_DELETE:
				message += ZABAction.getMessage(EventType.PROJECT_DELETE.getEventMessageKey());
				break;
			case PROJECT_NAME_UPDATE:
				message += ZABAction.getMessage(EventType.PROJECT_NAME_UPDATE.getEventMessageKey(), new String[]{value,oldValue});
				break;
			case PROJECT_STATUS_UPDATE:
				message += ZABAction.getMessage(EventType.PROJECT_STATUS_UPDATE.getEventMessageKey(), new String[]{value,oldValue});
				break;
			case PROJECT_DESC_UPDATE:
				if(StringUtils.isNotEmpty(value) && StringUtils.isNotEmpty(oldValue))
				{
					message += ZABAction.getMessage(EventType.PROJECT_DESC_UPDATE.getEventMessageKey(), new String[]{value,oldValue});
				}
				else if(StringUtils.isNotEmpty(value))
				{
					message += ZABAction.getMessage(EventActivityConstants.PROJECT_DESC_UPDATE_NEWONLY, new String[]{value});
				}
				else if(StringUtils.isNotEmpty(oldValue))
				{
					message += ZABAction.getMessage(EventActivityConstants.PROJECT_DESC_UPDATE_OLDONLY, new String[]{oldValue});
				}
				break;
			case PROJECT_GOAL_CREATE:
				message += ZABAction.getMessage(EventType.PROJECT_GOAL_CREATE.getEventMessageKey());
				break;
			case PROJECT_GOAL_DELETE:
				message += ZABAction.getMessage(EventType.PROJECT_GOAL_DELETE.getEventMessageKey());
				break;
			case PROJECT_GOAL_NAME_UPDATE:
				message += ZABAction.getMessage(EventType.PROJECT_GOAL_NAME_UPDATE.getEventMessageKey(), new String[]{value,oldValue});
				break;
			case PROJECT_GOAL_STATUS:
				message += ZABAction.getMessage(EventType.PROJECT_GOAL_STATUS.getEventMessageKey(), new String[]{value,oldValue});
				break;
			
			case PROJECT_GOAL_URL_UPDATE:
				if(value!= null && oldValue!=null){
					message += ZABAction.getMessage(EventType.PROJECT_GOAL_URL_UPDATE.getEventMessageKey(),new String[]{value,oldValue});
				}else if (value != null && oldValue == null){
					message += ZABAction.getMessage(EventActivityConstants.GOAL_URL_UPDATE_NEWONLY , new String[]{value});
				}else if (value == null && oldValue != null){
					message += ZABAction.getMessage(EventActivityConstants.GOAL_URL_UPDATE_OLDONLY , new String[]{oldValue});
				}
				break;
			case PROJECT_GOAL_INCLUDEURLS_UPDATE:
				message += ZABAction.getMessage(EventType.PROJECT_GOAL_INCLUDEURLS_UPDATE.getEventMessageKey());
				break;
			case PROJECT_GOAL_EXCLUDEURLS_UPDATE:
				message += ZABAction.getMessage(EventType.PROJECT_GOAL_EXCLUDEURLS_UPDATE.getEventMessageKey());
				break;
			case PROJECT_GOAL_UPDATE:
				message += ZABAction.getMessage(EventType.PROJECT_GOAL_UPDATE.getEventMessageKey());
				break;
			case EXPERIMENT_CREATE:
				message += ZABAction.getMessage(EventType.EXPERIMENT_CREATE.getEventMessageKey());
				break;
			case EXPERIMENT_DELETE:
				message += ZABAction.getMessage(EventType.EXPERIMENT_DELETE.getEventMessageKey());
				break;
			case EXPERIMENT_NAME_UPDATE:
				message += ZABAction.getMessage(EventType.EXPERIMENT_NAME_UPDATE.getEventMessageKey(), new String[]{value,oldValue});
				break;
			case EXP_EXCLUDEURLS_UPDATE:
				message += ZABAction.getMessage(EventType.EXP_EXCLUDEURLS_UPDATE.getEventMessageKey());
				break;
			case EXP_INCLUDEURLS_UPDATE:
				message += ZABAction.getMessage(EventType.EXP_INCLUDEURLS_UPDATE.getEventMessageKey());
				break;
			case EXPERIMENT_URL_UPDATE:
				message += ZABAction.getMessage(EventType.EXPERIMENT_URL_UPDATE.getEventMessageKey(), new String[]{value,oldValue});
				break;
			case EXPERIMENT_STATUS_UPDATE:
				message += ZABAction.getMessage(EventType.EXPERIMENT_STATUS_UPDATE.getEventMessageKey(), new String[]{value,oldValue});
				break;
			case EXP_PERMITTED_TRAFFIC_UPDATE:
				message += ZABAction.getMessage(EventType.EXP_PERMITTED_TRAFFIC_UPDATE.getEventMessageKey(), new String[]{value,oldValue});
				break;
			case EXP_STAT_SIGNIFICANCE_UPDATE:
				if(StringUtils.isNotEmpty(value))
				{
					ExperimentMode mode = ExperimentMode.getModeByModeNo(Integer.parseInt(value));
					if(mode != null)
					{
						value = mode.getModeStr();
					}
				}
				if(StringUtils.isNotEmpty(oldValue))
				{
					ExperimentMode mode = ExperimentMode.getModeByModeNo(Integer.parseInt(oldValue));
					if(mode != null)
					{
						oldValue = mode.getModeStr();
					}
				}
				message += ZABAction.getMessage(EventType.EXP_STAT_SIGNIFICANCE_UPDATE.getEventMessageKey(), new String[]{value,oldValue});
				break;
			case EXP_IS_HEATMAP_ENABLED_UPDATE:
				if(StringUtils.isNotEmpty(value))
				{
					if(value.equals(Boolean.TRUE.toString())){
						message += ZABAction.getMessage(EventType.EXP_IS_HEATMAP_ENABLED_UPDATE.getEventMessageKey(),new String[]{ZABAction.getMessage(EventActivityConstants.ACTIVITY_ENABLED_UPDATE)});
					}else{
						message += ZABAction.getMessage(EventType.EXP_IS_HEATMAP_ENABLED_UPDATE.getEventMessageKey(),new String[]{ZABAction.getMessage(EventActivityConstants.ACTIVITY_DISABLED_UPDATE)});
					}
				}
				break;
			case EXP_START_DATE_UPDATE:
				//Convert the date from long to readable format
				if(StringUtils.isNotEmpty(value))
				{
					value = ZABUtil.getDateTimeFormatted(Long.parseLong(value));
				}
				if(StringUtils.isNotEmpty(oldValue))
				{
					oldValue = ZABUtil.getDateTimeFormatted(Long.parseLong(oldValue));
				}
				if(StringUtils.isNotEmpty(value) && StringUtils.isNotEmpty(oldValue))
				{
					message += ZABAction.getMessage(EventType.EXP_START_DATE_UPDATE.getEventMessageKey(), new String[]{value,oldValue});
				}
				else if(StringUtils.isNotEmpty(value))
				{
					message += ZABAction.getMessage(EventActivityConstants.EXP_START_DATE_UPDATE_NEWONLY, new String[]{value});
				}
				else if(StringUtils.isNotEmpty(oldValue))
				{
					message += ZABAction.getMessage(EventActivityConstants.EXP_START_DATE_UPDATE_OLDONLY, new String[]{oldValue});
				}
				break;
			case EXP_END_DATE_UPDATE:
				//Convert the date from long to readable format
				if(StringUtils.isNotEmpty(value))
				{
					value = ZABUtil.getDateTimeFormatted(Long.parseLong(value));
				}
				if(StringUtils.isNotEmpty(oldValue))
				{
					oldValue = ZABUtil.getDateTimeFormatted(Long.parseLong(oldValue));
				}
				if(StringUtils.isNotEmpty(value) && StringUtils.isNotEmpty(oldValue))
				{
					message += ZABAction.getMessage(EventType.EXP_END_DATE_UPDATE.getEventMessageKey(), new String[]{value,oldValue});
				}
				else if(StringUtils.isNotEmpty(value))
				{
					message += ZABAction.getMessage(EventActivityConstants.EXP_END_DATE_UPDATE_NEWONLY, new String[]{value});
				}
				else if(StringUtils.isNotEmpty(oldValue))
				{
					message += ZABAction.getMessage(EventActivityConstants.EXP_END_DATE_UPDATE_OLDONLY, new String[]{oldValue});
				}
				break;
			case EXP_REPORT_SHARING:
				String statusString = ZABAction.getMessage(EventActivityConstants.ACTIVITY_ENABLED_UPDATE);
				if(value != null && value.equalsIgnoreCase(Boolean.FALSE.toString()))
				{
					statusString = ZABAction.getMessage(EventActivityConstants.ACTIVITY_DISABLED_UPDATE);
				}
				message += ZABAction.getMessage(EventType.EXP_REPORT_SHARING.getEventMessageKey(), new String[]{statusString});
				break;
			case EXP_INTEGRATION_CREATE:
				value = Integ.getIntegrationById(Integer.parseInt(value)).getDisplayName();
				message += ZABAction.getMessage(EventType.EXP_INTEGRATION_CREATE.getEventMessageKey(), new String[]{value});
				break;
			case EXP_INTEGRATION_DELETE:
				value = Integ.getIntegrationById(Integer.parseInt(value)).getDisplayName();
				message += ZABAction.getMessage(EventType.EXP_INTEGRATION_DELETE.getEventMessageKey(), new String[]{value});
				break;
			case VARIATION_CREATE:
				message += ZABAction.getMessage(EventType.VARIATION_CREATE.getEventMessageKey(), new String[]{variationName});
				break;
			case VARIATION_DELETE:
				message += ZABAction.getMessage(EventType.VARIATION_DELETE.getEventMessageKey(), new String[]{variationName});
				break;
			case VARIATION_NAME_UPDATE:
				message += ZABAction.getMessage(EventType.VARIATION_NAME_UPDATE.getEventMessageKey(), new String[]{variationName,value,oldValue});
				break;
			case VARIATION_TARGET_URL_UPDATE:
				message += ZABAction.getMessage(EventType.VARIATION_TARGET_URL_UPDATE.getEventMessageKey(), new String[]{variationName,value,oldValue});
				break;
			case VARIATION_SEQUENCE_UPDATE:
				message += ZABAction.getMessage(EventType.VARIATION_SEQUENCE_UPDATE.getEventMessageKey(), new String[]{variationName,value,oldValue});
				break;
			case VARIATION_TRAFFIC_ALLOCATION_UPDATE:
				message += ZABAction.getMessage(EventType.VARIATION_TRAFFIC_ALLOCATION_UPDATE.getEventMessageKey(), new String[]{variationName,value,oldValue});
				break;
			case VARIATION_CHANGES_UPDATE:
				message += ZABAction.getMessage(EventType.VARIATION_CHANGES_UPDATE.getEventMessageKey(), new String[]{variationName});
				break;
			case EXP_GOAL_CREATE:
				message += ZABAction.getMessage(EventType.EXP_GOAL_CREATE.getEventMessageKey(), new String[]{value});
				break;
			case EXP_GOAL_DELETE:
				message += ZABAction.getMessage(EventType.EXP_GOAL_DELETE.getEventMessageKey(), new String[]{value});
				break;
			case EXP_GOAL_UPDATE:
				message += ZABAction.getMessage(EventType.EXP_GOAL_UPDATE.getEventMessageKey(), new String[]{value});
				break;
			case EXP_AUDIENCE_CREATE:
				message += ZABAction.getMessage(EventType.EXP_AUDIENCE_CREATE.getEventMessageKey(), new String[]{value});
				break;
			case EXP_AUDIENCE_UPDATE:
				message += ZABAction.getMessage(EventType.EXP_AUDIENCE_UPDATE.getEventMessageKey(), new String[]{value});
				break;
			case EXP_AUDIENCE_DELETE:
				message += ZABAction.getMessage(EventType.EXP_AUDIENCE_DELETE.getEventMessageKey(), new String[]{value});
				break;
			case EXP_URLPARAM_CREATE:
				message += ZABAction.getMessage(EventType.EXP_URLPARAM_CREATE.getEventMessageKey(), new String[]{value});
				break;
			case EXP_COOKIE_CREATE:
				message += ZABAction.getMessage(EventType.EXP_COOKIE_CREATE.getEventMessageKey(), new String[]{value});
				break;
			case EXP_JSVAR_CREATE:
				message += ZABAction.getMessage(EventType.EXP_JSVAR_CREATE.getEventMessageKey(), new String[]{value});
				break;
			case EXP_CUSTDIMENSION_CREATE:
				message += ZABAction.getMessage(EventType.EXP_CUSTDIMENSION_CREATE.getEventMessageKey(), new String[]{value});
				break;
			case EXP_URLPARAM_DELETE:
				message += ZABAction.getMessage(EventType.EXP_URLPARAM_DELETE.getEventMessageKey(), new String[]{value});
				break;
			case EXP_COOKIE_DELETE:
				message += ZABAction.getMessage(EventType.EXP_COOKIE_DELETE.getEventMessageKey(), new String[]{value});
				break;
			case EXP_JSVAR_DELETE:
				message += ZABAction.getMessage(EventType.EXP_JSVAR_DELETE.getEventMessageKey(), new String[]{value});
				break;
			case EXP_CUSTDIMENSION_DELETE:
				message += ZABAction.getMessage(EventType.EXP_CUSTDIMENSION_DELETE.getEventMessageKey(), new String[]{value});
				break;
			default:
				message = "";
				break;
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			message = "";
		}
		return message;
	}
	
}
