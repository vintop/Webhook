//$Id$
package com.zoho.abtest.eventactivity;

import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;

import com.zoho.abtest.audience.Audience;
import com.zoho.abtest.audience.AudienceConstants;
import com.zoho.abtest.dimension.DimensionConstants;
import com.zoho.abtest.dimension.DynamicAttributes;
import com.zoho.abtest.dimension.DimensionConstants.DynamicAttributeType;
import com.zoho.abtest.eventactivity.EventActivityConstants.EventType;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentMode;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentStatus;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentType;
import com.zoho.abtest.goal.Goal;
import com.zoho.abtest.goal.GoalConstants;
import com.zoho.abtest.goal.GoalConstants.GoalStatus;
import com.zoho.abtest.integration.IntegrationConstants;
import com.zoho.abtest.privacyconsent.PrivacyConstants;
import com.zoho.abtest.project.ProjectConstants;
import com.zoho.abtest.project.ProjectConstants.ProjectStatus;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.abtest.variation.VariationConstants;

public class EventActivityHandler {
	
	private static final Logger	LOGGER = Logger.getLogger(EventActivityHandler.class.getName());
	
	public static void handleEventActivity(EventActivityWrapper wrapper)
	{
		try
		{
			String dbSpace = wrapper.getDbSpace();
			ZABUtil.setDBSpace(dbSpace);
			
			switch(wrapper.getModule())
			{
			case PROJECT:
				handleProjectEvent(wrapper);
				break;
			case EXPERIMENT:
				handleExperimentEvent(wrapper);
				break;
			case VARIATION:
				handleVariationEvent(wrapper);
				break;
			case EXPERIMENT_GOAL:
				handleExperimentGoalEvent(wrapper);
				break;
			case EXPERIMENT_AUDIENCE:
				handleExperimentAudienceEvent(wrapper);
				break;
			case EXPERIMENT_DYNAMIC_ATTRIBUTE:
				handleExperimentDynamicAttributeEvent(wrapper);
				break;
			case INTEGRATION:
				handleExpIntegrationEvent(wrapper);
				break;
			case PROJECT_GOAL:
				handleProjectGoalEvent(wrapper);
				break;
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	public static void handleProjectEvent(EventActivityWrapper wrapper)
	{
		try
		{
			HashMap<String, String> updatedValues = wrapper.getUpdatedValues();
			HashMap<String,String> oldValues = wrapper.getOldValues();
			switch(wrapper.getOperationType())
			{
			case CREATE:
				onProjectCreation(updatedValues);
				break;
			case UPDATE:
				onProjectUpdate(updatedValues,oldValues);
				break;
			case DELETE:
				//TODO - no api created yet
				break;
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	public static void handleExperimentEvent(EventActivityWrapper wrapper)
	{
		try
		{
			HashMap<String, String> updatedValues = wrapper.getUpdatedValues();
			HashMap<String,String> oldValues = wrapper.getOldValues();
			switch(wrapper.getOperationType())
			{
			case CREATE:
				onExperimentCreation(updatedValues);
				break;
			case UPDATE:
				onExperimentUpdate(updatedValues,oldValues);
				break;
			case DELETE:
				onExperimentDeletion(updatedValues);
				break;
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	public static void handleExpIntegrationEvent(EventActivityWrapper wrapper)
	{
		try
		{
			HashMap<String, String> updatedValues = wrapper.getUpdatedValues();
			switch(wrapper.getOperationType())
			{
			case CREATE:
				onExpIntegrationCreation(updatedValues);
				break;
			case DELETE:
				onExpIntegrationDeletion(updatedValues);
				break;
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	public static void handleVariationEvent(EventActivityWrapper wrapper)
	{
		try
		{
			HashMap<String, String> updatedValues = wrapper.getUpdatedValues();
			HashMap<String,String> oldValues = wrapper.getOldValues();
			switch(wrapper.getOperationType())
			{
			case CREATE:
				onVariationCreation(updatedValues);
				break;
			case UPDATE:
				onVariationUpdate(updatedValues,oldValues);
				break;
			case DELETE:
				onVariationDeletion(updatedValues);
				break;
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	public static void handleExperimentGoalEvent(EventActivityWrapper wrapper)
	{
		try
		{
			HashMap<String, String> updatedValues = wrapper.getUpdatedValues();
			switch(wrapper.getOperationType())
			{
			case CREATE:
				onExperimentGoalCreation(updatedValues);
				break;
			case UPDATE:
				onExperimentGoalUpdate(updatedValues);
				break;
			case DELETE:
				onExperimentGoalDeletion(updatedValues);
				break;
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	public static void handleProjectGoalEvent(EventActivityWrapper wrapper)
	{
		try
		{
			HashMap<String, String> updatedValues = wrapper.getUpdatedValues();
			switch(wrapper.getOperationType())
			{
			case CREATE:
				onProjectGoalCreation(updatedValues);
				break;
			case UPDATE:
				onProjecttGoalUpdate(updatedValues,wrapper.getOldValues());
				break;
			case DELETE:
				onProjectGoalDelete(updatedValues);
				break;
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	
	public static void handleExperimentAudienceEvent(EventActivityWrapper wrapper)
	{
		try
		{
			HashMap<String, String> updatedValues = wrapper.getUpdatedValues();
			switch(wrapper.getOperationType())
			{
			case CREATE:
				onExperimentAudienceCreation(updatedValues);
				break;
			case UPDATE:
				onExperimentAudienceUpdation(updatedValues);
				break;
			case DELETE:
				//TODO api for this is not yet implemented, i hope
				onExperimentAudienceDeletion(updatedValues);
				break;
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	public static void handleExperimentDynamicAttributeEvent(EventActivityWrapper wrapper)
	{
		try
		{
			HashMap<String, String> updatedValues = wrapper.getUpdatedValues();
			List<Long> dynamicAttributeIdList = (List<Long>) wrapper.getCustomObject();
			switch(wrapper.getOperationType())
			{
			case CREATE:
				onExperimentDynamicAttributeCreation(updatedValues,dynamicAttributeIdList);
				break;
			case UPDATE:
				break;
			case DELETE:
				onExperimentDynamicAttributeDeletion(updatedValues,dynamicAttributeIdList);
				break;
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}

	public static void onProjectCreation(HashMap<String, String> updatedValues)
	{
		try
		{
			String projectId = updatedValues.get(EventActivityConstants.PROJECT_ID);
			String userId = updatedValues.get(EventActivityConstants.USER_ID);
			String time = updatedValues.get(EventActivityConstants.TIME);
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(EventActivityConstants.PROJECT_ID, projectId);
			hs.put(EventActivityConstants.USER_ID, userId);
			hs.put(EventActivityConstants.TIME, time);
			hs.put(EventActivityConstants.MODULE, EventActivityConstants.Module.PROJECT.getValue().toString());
 			hs.put(EventActivityConstants.EVENT_TYPE, EventActivityConstants.EventType.PROJECT_CREATE.getEventValue().toString());
 			if(updatedValues.containsKey(PrivacyConstants.PRIVACY_VALUE)) {
				hs.put(EventActivityConstants.VALUE, updatedValues.get(PrivacyConstants.PRIVACY_VALUE));
				Integer eventValue = EventType.PRIVACY_CONSENT_VALUE_UPDATE.getEventValue();
				hs.put(EventActivityConstants.EVENT_TYPE, eventValue.toString());
			}
			EventActivityLog.createEventActivityLog(hs);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	public static void onProjectUpdate(HashMap<String, String> updatedValues,HashMap<String, String> oldValues)
	{
		try
		{
			String projectId = updatedValues.get(EventActivityConstants.PROJECT_ID);
			String userId = updatedValues.get(EventActivityConstants.USER_ID);
			String time = updatedValues.get(EventActivityConstants.TIME);
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(EventActivityConstants.PROJECT_ID, projectId.toString());
			hs.put(EventActivityConstants.USER_ID, userId);
			hs.put(EventActivityConstants.TIME, time);
			hs.put(EventActivityConstants.MODULE, EventActivityConstants.Module.PROJECT.getValue().toString());
			
			for(String attribute:EventActivityConstants.PROJECT_ATTR_TO_TRACE)
			{
				if(updatedValues.containsKey(attribute))
				{
					Integer eventValue = getProjectUpdateEvent(attribute);
					String newValue = updatedValues.get(attribute);
					String oldValue = oldValues.get(attribute);
					
					boolean isSameStr = ZABUtil.stringEquals(oldValue, newValue);
					
					if(!isSameStr)
					{
						//fetching the status value
						if(attribute.equals(ProjectConstants.PROJECT_STATUS))
						{
							Integer newValueCode = Integer.parseInt(newValue);
							Integer oldValueCode = Integer.parseInt(oldValue);
							newValue = ProjectStatus.getProjectStatusByNumber(newValueCode).name();
							oldValue = ProjectStatus.getProjectStatusByNumber(oldValueCode).name();
						}
						
						hs.put(EventActivityConstants.VALUE, newValue);
						hs.put(EventActivityConstants.OLD_VALUE, oldValue);
						hs.put(EventActivityConstants.EVENT_TYPE, eventValue.toString());
						
						//create an entry for an update operation of an attribute
						EventActivityLog.createEventActivityLog(hs);
					}
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	public static Integer getProjectUpdateEvent(String attribute)
	{
		Integer eventValue = 0;
		switch(attribute)
		{
		case ProjectConstants.PROJECT_NAME:
			eventValue = EventType.PROJECT_NAME_UPDATE.getEventValue();
			break;
		case ProjectConstants.PROJECT_STATUS:
			eventValue = EventType.PROJECT_STATUS_UPDATE.getEventValue();
			break;
		case ProjectConstants.PROJECT_DESCRIPTION:
			eventValue = EventType.PROJECT_DESC_UPDATE.getEventValue();
			break;
		case PrivacyConstants.PRIVACY_VALUE:
			eventValue = EventType.PRIVACY_CONSENT_VALUE_UPDATE.getEventValue();
			
		}
		return eventValue;
	}
	
	public static void onExperimentCreation(HashMap<String, String> updatedValues)
	{
		try
		{
			String experimentId = updatedValues.get(EventActivityConstants.EXPERIMENT_ID);
			String userId = updatedValues.get(EventActivityConstants.USER_ID);
			String time = updatedValues.get(EventActivityConstants.TIME);
			Long projectId = Experiment.getProjectIdByExperimentId(Long.valueOf(experimentId));
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(EventActivityConstants.PROJECT_ID, projectId.toString());
			hs.put(EventActivityConstants.EXPERIMENT_ID, experimentId);
			hs.put(EventActivityConstants.USER_ID, userId);
			hs.put(EventActivityConstants.TIME, time);
			hs.put(EventActivityConstants.MODULE, EventActivityConstants.Module.EXPERIMENT.getValue().toString());
			hs.put(EventActivityConstants.EVENT_TYPE, EventActivityConstants.EventType.EXPERIMENT_CREATE.getEventValue().toString());
			EventActivityLog.createEventActivityLog(hs);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	public static void onExperimentUpdate(HashMap<String, String> updatedValues,HashMap<String, String> oldValues)
	{
		try
		{
			String experimentId = updatedValues.get(EventActivityConstants.EXPERIMENT_ID);
			String userId = updatedValues.get(EventActivityConstants.USER_ID);
			String time = updatedValues.get(EventActivityConstants.TIME);
			Long projectId = Experiment.getProjectIdByExperimentId(Long.valueOf(experimentId));
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(EventActivityConstants.PROJECT_ID, projectId.toString());
			hs.put(EventActivityConstants.EXPERIMENT_ID, experimentId);
			hs.put(EventActivityConstants.USER_ID, userId);
			hs.put(EventActivityConstants.TIME, time);
			hs.put(EventActivityConstants.MODULE, EventActivityConstants.Module.EXPERIMENT.getValue().toString());
			
			int eventExpType = 0;
			String eventExpTypeStr = oldValues.get(ExperimentConstants.EVENT_EXPERIMENT_TYPE);
			if(StringUtils.isNotEmpty(eventExpTypeStr))
			{
				eventExpType =	Integer.parseInt(eventExpTypeStr);
			}
			
			ExperimentType experimentType = ExperimentType.getExperimentTypeByNumber(eventExpType);
			List<String> eventActivityConstants = EventActivityConstants.EXPERIMENT_ATTR_TO_TRACE;
			
			if(experimentType != null)
			{
				switch(experimentType)
				{
				case ABTEST:
					eventActivityConstants = EventActivityConstants.ABSPLIT_EXPERIMENT_ATTR_TO_TRACE;
					break;
				case HEATMAP:
					eventActivityConstants = EventActivityConstants.HEATMPA_EXPERIMENT_ATTR_TO_TRACE;
					break;
				default:
					eventActivityConstants = EventActivityConstants.EXPERIMENT_ATTR_TO_TRACE;
					break;
				}
			}
			
			for(String attribute:eventActivityConstants)
			{
				if(updatedValues.containsKey(attribute))
				{
					Integer eventValue = getExperimentUpdateEvent(attribute);
					String newValue = updatedValues.get(attribute);
					String oldValue = oldValues.get(attribute);
					
					boolean isSameStr = ZABUtil.stringEquals(oldValue, newValue);
					
					if(!isSameStr)
					{
						//fetching the status value
						if(attribute.equals(ExperimentConstants.EXPERIMENT_STATUS))
						{
							Integer newValueCode = Integer.parseInt(newValue);
							Integer oldValueCode = Integer.parseInt(oldValue);
							newValue = ExperimentStatus.getStatusByNumber(newValueCode).name();
							oldValue = ExperimentStatus.getStatusByNumber(oldValueCode).name();
						}
						else if(attribute.equals(ExperimentConstants.STATISTICAL_SIGNIFICANCE))
						{
							Integer newValueCode = Integer.parseInt(newValue);
							Integer oldValueCode = Integer.parseInt(oldValue);
							newValue = ExperimentMode.getModeByModeValue(newValueCode).getModeNo().toString();
							oldValue = ExperimentMode.getModeByModeValue(oldValueCode).getModeNo().toString();
						}
						hs.put(EventActivityConstants.EVENT_TYPE, eventValue.toString());
						hs.put(EventActivityConstants.VALUE, newValue);
						hs.put(EventActivityConstants.OLD_VALUE, oldValue);
						
						//create an entry for an update operation of an attribute
						EventActivityLog.createEventActivityLog(hs);
					}
				}
			}
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	public static Integer getExperimentUpdateEvent(String attribute)
	{
		Integer eventValue = 0;
		switch(attribute)
		{
		case ExperimentConstants.EXPERIMENT_NAME:
			eventValue = EventType.EXPERIMENT_NAME_UPDATE.getEventValue();
			break;
		case ExperimentConstants.EXPERIMENT_URL:
			eventValue = EventType.EXPERIMENT_URL_UPDATE.getEventValue();
			break;
		case ExperimentConstants.INCLUDE_URLS:
			eventValue = EventType.EXP_INCLUDEURLS_UPDATE.getEventValue();
			break;
		case ExperimentConstants.EXCLUDE_URLS:
			eventValue = EventType.EXP_EXCLUDEURLS_UPDATE.getEventValue();
			break;
		case ExperimentConstants.EXPERIMENT_STATUS:
			eventValue = EventType.EXPERIMENT_STATUS_UPDATE.getEventValue();
			break;
		case ExperimentConstants.PERMITTED_TRAFFIC:
			eventValue = EventType.EXP_PERMITTED_TRAFFIC_UPDATE.getEventValue();
			break;
		case ExperimentConstants.STATISTICAL_SIGNIFICANCE:
			eventValue = EventType.EXP_STAT_SIGNIFICANCE_UPDATE.getEventValue();
			break;
		case ExperimentConstants.START_DATE:
			eventValue = EventType.EXP_START_DATE_UPDATE.getEventValue();
			break;
		case ExperimentConstants.END_DATE:
			eventValue = EventType.EXP_END_DATE_UPDATE.getEventValue();
			break;
		case ExperimentConstants.IS_HEATMAP_ENABLED:
			eventValue = EventType.EXP_IS_HEATMAP_ENABLED_UPDATE.getEventValue();
			break;
		case ExperimentConstants.MAKE_PUBLIC:
			eventValue = EventType.EXP_REPORT_SHARING.getEventValue();
			break;
		}
		return eventValue;
	}
	
	public static Integer getProjectGoalUpdateEvent(String attribute)
	{
		Integer eventValue = 0;
		switch(attribute)
		{
		case GoalConstants.GOAL_NAME:
			eventValue = EventType.PROJECT_GOAL_NAME_UPDATE.getEventValue();
			break;
		case GoalConstants.GOAL_URL:
			eventValue = EventType.PROJECT_GOAL_URL_UPDATE.getEventValue();
			break;
		case GoalConstants.INCLUDE_URLS:
			eventValue = EventType.PROJECT_GOAL_INCLUDEURLS_UPDATE.getEventValue();
			break;
		case GoalConstants.EXCLUDE_URLS:
			eventValue = EventType.PROJECT_GOAL_EXCLUDEURLS_UPDATE.getEventValue();
			break;
		case GoalConstants.GOAL_STATUS:
			eventValue = EventType.PROJECT_GOAL_STATUS.getEventValue();
			break;
		default:
			eventValue = EventType.PROJECT_GOAL_UPDATE.getEventValue();
			break;
		}
		return eventValue;
	}
	
	public static void onExperimentDeletion(HashMap<String, String> updatedValues)
	{
		try
		{
			String experimentId = updatedValues.get(EventActivityConstants.EXPERIMENT_ID);
			String projectId = updatedValues.get(EventActivityConstants.PROJECT_ID);
			String userId = updatedValues.get(EventActivityConstants.USER_ID);
			String time = updatedValues.get(EventActivityConstants.TIME);
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(EventActivityConstants.PROJECT_ID, projectId.toString());
			hs.put(EventActivityConstants.EXPERIMENT_ID, experimentId);
			hs.put(EventActivityConstants.USER_ID, userId);
			hs.put(EventActivityConstants.TIME, time);
			hs.put(EventActivityConstants.MODULE, EventActivityConstants.Module.EXPERIMENT.getValue().toString());
			hs.put(EventActivityConstants.EVENT_TYPE, EventActivityConstants.EventType.EXPERIMENT_DELETE.getEventValue().toString());
			EventActivityLog.createEventActivityLog(hs);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	public static void onVariationCreation(HashMap<String, String> updatedValues)
	{
		try
		{
			String experimentId = updatedValues.get(EventActivityConstants.EXPERIMENT_ID);
			String userId = updatedValues.get(EventActivityConstants.USER_ID);
			String time = updatedValues.get(EventActivityConstants.TIME);
			String variationId = updatedValues.get(VariationConstants.VARIATION_ID);
			Long projectId = Experiment.getProjectIdByExperimentId(Long.valueOf(experimentId));
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(EventActivityConstants.PROJECT_ID, projectId.toString());
			hs.put(EventActivityConstants.EXPERIMENT_ID, experimentId);
			hs.put(EventActivityConstants.VARIATION_ID, variationId);
			hs.put(EventActivityConstants.USER_ID, userId);
			hs.put(EventActivityConstants.TIME, time);
			hs.put(EventActivityConstants.MODULE, EventActivityConstants.Module.VARIATION.getValue().toString());
			hs.put(EventActivityConstants.EVENT_TYPE, EventActivityConstants.EventType.VARIATION_CREATE.getEventValue().toString());
			EventActivityLog.createEventActivityLog(hs);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	public static void onVariationUpdate(HashMap<String, String> updatedValues,HashMap<String, String> oldValues)
	{
		try
		{
			String experimentId = updatedValues.get(EventActivityConstants.EXPERIMENT_ID);
			String userId = updatedValues.get(EventActivityConstants.USER_ID);
			String time = updatedValues.get(EventActivityConstants.TIME);
			String variationId = updatedValues.get(VariationConstants.VARIATION_ID);
			Long projectId = Experiment.getProjectIdByExperimentId(Long.valueOf(experimentId));
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(EventActivityConstants.PROJECT_ID, projectId.toString());
			hs.put(EventActivityConstants.EXPERIMENT_ID, experimentId);
			hs.put(EventActivityConstants.VARIATION_ID, variationId);
			hs.put(EventActivityConstants.USER_ID, userId);
			hs.put(EventActivityConstants.TIME, time);
			hs.put(EventActivityConstants.MODULE, EventActivityConstants.Module.VARIATION.getValue().toString());
			
			for(String attribute:EventActivityConstants.VARIATION_ATTR_TO_TRACE)
			{
				if(updatedValues.containsKey(attribute))
				{
					Integer eventValue = getVariationUpdateEvent(attribute);
					String newValue = updatedValues.get(attribute);
					String oldValue = oldValues.get(attribute);
					
					boolean isSameStr = ZABUtil.stringEquals(oldValue, newValue);
					
					if(!isSameStr)
					{
						hs.put(EventActivityConstants.VALUE, newValue);
						hs.put(EventActivityConstants.OLD_VALUE, oldValue);
						hs.put(EventActivityConstants.EVENT_TYPE, eventValue.toString());
						//create an entry for an update operation of an attribute
						EventActivityLog.createEventActivityLog(hs);
					}
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	public static Integer getVariationUpdateEvent(String attribute)
	{
		Integer eventValue = 0;
		switch(attribute)
		{
		case VariationConstants.VARIATION_NAME:
			eventValue = EventType.VARIATION_NAME_UPDATE.getEventValue();
			break;
		case VariationConstants.TARGET_URL:
			eventValue = EventType.VARIATION_TARGET_URL_UPDATE.getEventValue();
			break;
		case VariationConstants.SEQUENCE:
			eventValue = EventType.VARIATION_SEQUENCE_UPDATE.getEventValue();
			break;
		case VariationConstants.TRAFFIC_ALLOCATION:
			eventValue = EventType.VARIATION_TRAFFIC_ALLOCATION_UPDATE.getEventValue();
			break;
		case VariationConstants.VARIATION_CHANGES:
			eventValue = EventType.VARIATION_CHANGES_UPDATE.getEventValue();
			break;
		}
		return eventValue;
	}
	
	public static void onVariationDeletion(HashMap<String, String> updatedValues)
	{
		try
		{
			String experimentId = updatedValues.get(EventActivityConstants.EXPERIMENT_ID);
			String userId = updatedValues.get(EventActivityConstants.USER_ID);
			String time = updatedValues.get(EventActivityConstants.TIME);
			String variationId = updatedValues.get(VariationConstants.VARIATION_ID);
			Long projectId = Experiment.getProjectIdByExperimentId(Long.valueOf(experimentId));
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(EventActivityConstants.PROJECT_ID, projectId.toString());
			hs.put(EventActivityConstants.EXPERIMENT_ID, experimentId);
			hs.put(EventActivityConstants.VARIATION_ID, variationId);
			hs.put(EventActivityConstants.USER_ID, userId);
			hs.put(EventActivityConstants.TIME, time);
			hs.put(EventActivityConstants.MODULE, EventActivityConstants.Module.VARIATION.getValue().toString());
			hs.put(EventActivityConstants.EVENT_TYPE, EventActivityConstants.EventType.VARIATION_DELETE.getEventValue().toString());
			EventActivityLog.createEventActivityLog(hs);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	public static void onExperimentGoalCreation(HashMap<String, String> updatedValues)
	{
		try
		{
			String experimentId = updatedValues.get(EventActivityConstants.EXPERIMENT_ID);
			String userId = updatedValues.get(EventActivityConstants.USER_ID);
			String time = updatedValues.get(EventActivityConstants.TIME);
			String goalId = updatedValues.get(GoalConstants.GOAL_ID);
			Goal goal = Goal.getGoalByGoalId(Long.parseLong(goalId));
			String goalName = goal.getGoalName();
			Long projectId = Experiment.getProjectIdByExperimentId(Long.valueOf(experimentId));		
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(EventActivityConstants.PROJECT_ID, projectId.toString());
			hs.put(EventActivityConstants.EXPERIMENT_ID, experimentId);
			hs.put(EventActivityConstants.USER_ID, userId);
			hs.put(EventActivityConstants.TIME, time);
			hs.put(EventActivityConstants.MODULE, EventActivityConstants.Module.EXPERIMENT_GOAL.getValue().toString());
			hs.put(EventActivityConstants.EVENT_TYPE, EventActivityConstants.EventType.EXP_GOAL_CREATE.getEventValue().toString());
			hs.put(EventActivityConstants.VALUE, goalName);
			EventActivityLog.createEventActivityLog(hs);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	public static void onProjectGoalCreation(HashMap<String, String> updatedValues)
	{
		try
		{
			
			String userId = updatedValues.get(EventActivityConstants.USER_ID);
			String time = updatedValues.get(EventActivityConstants.TIME);
			String goalId = updatedValues.get(GoalConstants.GOAL_ID);
			Goal goal = Goal.getGoalByGoalId(Long.parseLong(goalId));
			String goalName = goal.getGoalName();
			Long projectId = goal.getProjectId();		
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(EventActivityConstants.PROJECT_ID, projectId.toString());
			hs.put(EventActivityConstants.USER_ID, userId);
			hs.put(EventActivityConstants.GOAL_ID, goalId);
			hs.put(EventActivityConstants.TIME, time);
			hs.put(EventActivityConstants.MODULE, EventActivityConstants.Module.PROJECT_GOAL.getValue().toString());
			hs.put(EventActivityConstants.EVENT_TYPE, EventActivityConstants.EventType.PROJECT_GOAL_CREATE.getEventValue().toString());
			hs.put(EventActivityConstants.VALUE, goalName);
			EventActivityLog.createEventActivityLog(hs);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	
	public static void onExperimentGoalUpdate(HashMap<String, String> updatedValues)
	{
		try
		{
			String experimentId = updatedValues.get(EventActivityConstants.EXPERIMENT_ID);
			String userId = updatedValues.get(EventActivityConstants.USER_ID);
			String time = updatedValues.get(EventActivityConstants.TIME);
			String goalId = updatedValues.get(GoalConstants.GOAL_ID);
			Goal goal = Goal.getGoalByGoalId(Long.parseLong(goalId));
			String goalName = goal.getGoalName();
			Long projectId = Experiment.getProjectIdByExperimentId(Long.valueOf(experimentId));		
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(EventActivityConstants.PROJECT_ID, projectId.toString());
			hs.put(EventActivityConstants.EXPERIMENT_ID, experimentId);
			hs.put(EventActivityConstants.USER_ID, userId);
			hs.put(EventActivityConstants.TIME, time);
			hs.put(EventActivityConstants.MODULE, EventActivityConstants.Module.EXPERIMENT_GOAL.getValue().toString());
			hs.put(EventActivityConstants.EVENT_TYPE, EventActivityConstants.EventType.EXP_GOAL_UPDATE.getEventValue().toString());
			hs.put(EventActivityConstants.VALUE, goalName);
			EventActivityLog.createEventActivityLog(hs);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	public static void onProjecttGoalUpdate(HashMap<String, String> updatedValues,HashMap<String, String> oldValues)
	{
		try
		{
			String userId = updatedValues.get(EventActivityConstants.USER_ID);
			String time = updatedValues.get(EventActivityConstants.TIME);
			String goalId = updatedValues.get(GoalConstants.GOAL_ID);
			Goal goal = Goal.getGoalByGoalId(Long.parseLong(goalId));
			Long projectId =goal.getProjectId();		
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(EventActivityConstants.PROJECT_ID, projectId.toString());
			hs.put(EventActivityConstants.USER_ID, userId);
			hs.put(EventActivityConstants.GOAL_ID, goalId);
			hs.put(EventActivityConstants.TIME, time);
			hs.put(EventActivityConstants.MODULE, EventActivityConstants.Module.PROJECT_GOAL.getValue().toString());
			try
			{
				List<String> eventActivityConstants = EventActivityConstants.PROJECT_GOAL_ATTR_TO_TRACE;
				for(String attribute:eventActivityConstants)
				{
					if(updatedValues.containsKey(attribute))
					{
						Integer eventValue = getProjectGoalUpdateEvent(attribute);
						String newValue = updatedValues.get(attribute);
						String oldValue = oldValues.get(attribute);
					
						
						boolean isSameStr = ZABUtil.stringEquals(oldValue, newValue);
						if(newValue!=null && newValue.equals("[]") && oldValue == null){ isSameStr =true;}
						if(oldValue!=null && oldValue.equals("[]") && newValue == null){ isSameStr =true;}
						
						if(!isSameStr)
						{
							
							if(attribute.equals(GoalConstants.GOAL_STATUS)){
								Integer newValueCode = Integer.parseInt(newValue);
								Integer oldValueCode = Integer.parseInt(oldValue);
								newValue = GoalStatus.getStatusByNumber(newValueCode).name();
								oldValue = GoalStatus.getStatusByNumber(oldValueCode).name();
							}
							
							hs.put(EventActivityConstants.EVENT_TYPE, eventValue.toString());
							hs.put(EventActivityConstants.VALUE, newValue);
							hs.put(EventActivityConstants.OLD_VALUE, oldValue);
							
							//create an entry for an update operation of an attribute
							EventActivityLog.createEventActivityLog(hs);
						}
					}
				}
				
			}
			catch(Exception ex)
			{
				LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	public static void onExperimentGoalDeletion(HashMap<String, String> updatedValues)
	{
		try
		{
			String experimentId = updatedValues.get(EventActivityConstants.EXPERIMENT_ID);
			String userId = updatedValues.get(EventActivityConstants.USER_ID);
			String time = updatedValues.get(EventActivityConstants.TIME);
			//String goalId = updatedValues.get(GoalConstants.GOAL_ID);
			//Goal goal = Goal.getGoalByGoalId(Long.parseLong(goalId));
			String goalName = updatedValues.get(GoalConstants.GOAL_NAME);
			Long projectId = Experiment.getProjectIdByExperimentId(Long.valueOf(experimentId));	
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(EventActivityConstants.PROJECT_ID, projectId.toString());
			hs.put(EventActivityConstants.EXPERIMENT_ID, experimentId);
			hs.put(EventActivityConstants.USER_ID, userId);
			hs.put(EventActivityConstants.TIME, time);
			hs.put(EventActivityConstants.MODULE, EventActivityConstants.Module.EXPERIMENT_GOAL.getValue().toString());
			hs.put(EventActivityConstants.EVENT_TYPE, EventActivityConstants.EventType.EXP_GOAL_DELETE.getEventValue().toString());
			hs.put(EventActivityConstants.VALUE, goalName);
			EventActivityLog.createEventActivityLog(hs);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	public static void onProjectGoalDelete(HashMap<String, String> updatedValues)
	{
		try
		{
			String userId = updatedValues.get(EventActivityConstants.USER_ID);
			String time = updatedValues.get(EventActivityConstants.TIME);
			String goalId = updatedValues.get(GoalConstants.GOAL_ID);
			String goalName = updatedValues.get(GoalConstants.GOAL_NAME);
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(EventActivityConstants.PROJECT_ID,  updatedValues.get(EventActivityConstants.PROJECT_ID));
			hs.put(EventActivityConstants.USER_ID, userId);
			hs.put(EventActivityConstants.GOAL_ID, goalId);
			hs.put(EventActivityConstants.TIME, time);
			hs.put(EventActivityConstants.MODULE, EventActivityConstants.Module.PROJECT_GOAL.getValue().toString());
			hs.put(EventActivityConstants.EVENT_TYPE, EventActivityConstants.EventType.PROJECT_GOAL_DELETE.getEventValue().toString());
			hs.put(EventActivityConstants.VALUE, goalName);
			EventActivityLog.createEventActivityLog(hs);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	public static void onExperimentAudienceCreation(HashMap<String, String> updatedValues)
	{
		try
		{
			String experimentId = updatedValues.get(EventActivityConstants.EXPERIMENT_ID);
			String userId = updatedValues.get(EventActivityConstants.USER_ID);
			String time = updatedValues.get(EventActivityConstants.TIME);
			String audienceId = updatedValues.get(AudienceConstants.AUDIENCE_ID);
			Audience audience = Audience.getAudienceById(Long.parseLong(audienceId),null);
			String audienceName = audience.getAudienceName();
			Long projectId = Experiment.getProjectIdByExperimentId(Long.valueOf(experimentId));
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(EventActivityConstants.PROJECT_ID, projectId.toString());
			hs.put(EventActivityConstants.EXPERIMENT_ID, experimentId);
			hs.put(EventActivityConstants.USER_ID, userId);
			hs.put(EventActivityConstants.TIME, time);
			hs.put(EventActivityConstants.MODULE, EventActivityConstants.Module.EXPERIMENT_AUDIENCE.getValue().toString());
			hs.put(EventActivityConstants.EVENT_TYPE, EventActivityConstants.EventType.EXP_AUDIENCE_CREATE.getEventValue().toString());
			hs.put(EventActivityConstants.VALUE, audienceName);
			EventActivityLog.createEventActivityLog(hs);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	public static void onExperimentAudienceUpdation(HashMap<String, String> updatedValues)
	{
		try
		{
			String experimentId = updatedValues.get(EventActivityConstants.EXPERIMENT_ID);
			String userId = updatedValues.get(EventActivityConstants.USER_ID);
			String time = updatedValues.get(EventActivityConstants.TIME);
			String audienceId = updatedValues.get(AudienceConstants.AUDIENCE_ID);
			Audience audience = Audience.getAudienceById(Long.parseLong(audienceId),null);
			String audienceName = audience.getAudienceName();
			Long projectId = Experiment.getProjectIdByExperimentId(Long.valueOf(experimentId));		
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(EventActivityConstants.PROJECT_ID, projectId.toString());
			hs.put(EventActivityConstants.EXPERIMENT_ID, experimentId);
			hs.put(EventActivityConstants.USER_ID, userId);
			hs.put(EventActivityConstants.TIME, time);
			hs.put(EventActivityConstants.MODULE, EventActivityConstants.Module.EXPERIMENT_AUDIENCE.getValue().toString());
			hs.put(EventActivityConstants.EVENT_TYPE, EventActivityConstants.EventType.EXP_AUDIENCE_UPDATE.getEventValue().toString());
			hs.put(EventActivityConstants.VALUE, audienceName);
			EventActivityLog.createEventActivityLog(hs);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	
	public static void onExperimentAudienceDeletion(HashMap<String, String> updatedValues)
	{
		try
		{
			String experimentId = updatedValues.get(EventActivityConstants.EXPERIMENT_ID);
			String userId = updatedValues.get(EventActivityConstants.USER_ID);
			String time = updatedValues.get(EventActivityConstants.TIME);
			String audienceId = updatedValues.get(AudienceConstants.AUDIENCE_ID);
			Audience audience = Audience.getAudienceById(Long.parseLong(audienceId),null);
			String audienceName = audience.getAudienceName();
			Long projectId = Experiment.getProjectIdByExperimentId(Long.valueOf(experimentId));
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(EventActivityConstants.PROJECT_ID, projectId.toString());
			hs.put(EventActivityConstants.EXPERIMENT_ID, experimentId);
			hs.put(EventActivityConstants.USER_ID, userId);
			hs.put(EventActivityConstants.TIME, time);
			hs.put(EventActivityConstants.MODULE, EventActivityConstants.Module.EXPERIMENT_AUDIENCE.getValue().toString());
			hs.put(EventActivityConstants.EVENT_TYPE, EventActivityConstants.EventType.EXP_AUDIENCE_DELETE.getEventValue().toString());
			hs.put(EventActivityConstants.VALUE, audienceName);
			EventActivityLog.createEventActivityLog(hs);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	public static void onExperimentDynamicAttributeCreation(HashMap<String, String> updatedValues, List<Long> dynamicAttributeIds)
	{
		try
		{
			String experimentId = updatedValues.get(EventActivityConstants.EXPERIMENT_ID);
			String userId = updatedValues.get(EventActivityConstants.USER_ID);
			String time = updatedValues.get(EventActivityConstants.TIME);
			Long projectId = Experiment.getProjectIdByExperimentId(Long.valueOf(experimentId));
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(EventActivityConstants.PROJECT_ID, projectId.toString());
			hs.put(EventActivityConstants.EXPERIMENT_ID, experimentId);
			hs.put(EventActivityConstants.USER_ID, userId);
			hs.put(EventActivityConstants.TIME, time);
			hs.put(EventActivityConstants.MODULE, EventActivityConstants.Module.EXPERIMENT_DYNAMIC_ATTRIBUTE.getValue().toString());
			
			
			for(Long dynamicAttributeId:dynamicAttributeIds)
			{
				DynamicAttributes dynamicAttribute = DynamicAttributes.getDynamicAttributesById(dynamicAttributeId);
				String attributename = dynamicAttribute.getAttributeName();
				Integer attributeType = dynamicAttribute.getAttributeType();
				Integer eventValue = 0;
				
				if(attributeType.equals(DynamicAttributeType.URLPARAMETER.getAttributeTypeCode()))
				{
					eventValue = EventActivityConstants.EventType.EXP_URLPARAM_CREATE.getEventValue();
				}
				else if(attributeType.equals(DynamicAttributeType.COOKIE.getAttributeTypeCode()))
				{
					eventValue = EventActivityConstants.EventType.EXP_COOKIE_CREATE.getEventValue();
				}
				else if(attributeType.equals(DynamicAttributeType.JSVARIABLE.getAttributeTypeCode()))
				{
					eventValue = EventActivityConstants.EventType.EXP_JSVAR_CREATE.getEventValue();
				}
				else if(attributeType.equals(DynamicAttributeType.CUSTOMDIMENSION.getAttributeTypeCode()))
				{
					eventValue = EventActivityConstants.EventType.EXP_CUSTDIMENSION_CREATE.getEventValue();
				}
				
				hs.put(EventActivityConstants.EVENT_TYPE, eventValue.toString());
				hs.put(EventActivityConstants.VALUE, attributename);
				EventActivityLog.createEventActivityLog(hs);
			}
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	public static void onExperimentDynamicAttributeDeletion(HashMap<String, String> updatedValues, List<Long> dynamicAttributeIds)
	{
		try
		{
			String experimentId = updatedValues.get(EventActivityConstants.EXPERIMENT_ID);
			String userId = updatedValues.get(EventActivityConstants.USER_ID);
			String time = updatedValues.get(EventActivityConstants.TIME);
			Long projectId = Experiment.getProjectIdByExperimentId(Long.valueOf(experimentId));
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(EventActivityConstants.PROJECT_ID, projectId.toString());
			hs.put(EventActivityConstants.EXPERIMENT_ID, experimentId);
			hs.put(EventActivityConstants.USER_ID, userId);
			hs.put(EventActivityConstants.TIME, time);
			hs.put(EventActivityConstants.MODULE, EventActivityConstants.Module.EXPERIMENT_DYNAMIC_ATTRIBUTE.getValue().toString());
			
			for(Long dynamicAttributeId:dynamicAttributeIds)
			{
				DynamicAttributes dynamicAttribute = DynamicAttributes.getDynamicAttributesById(dynamicAttributeId);
				String attributename = dynamicAttribute.getAttributeName();
				Integer attributeType = dynamicAttribute.getAttributeType();
				Integer eventValue = 0;
				
				if(attributeType.equals(DynamicAttributeType.URLPARAMETER.getAttributeTypeCode()))
				{
					eventValue = EventActivityConstants.EventType.EXP_URLPARAM_DELETE.getEventValue();
				}
				else if(attributeType.equals(DynamicAttributeType.COOKIE.getAttributeTypeCode()))
				{
					eventValue = EventActivityConstants.EventType.EXP_COOKIE_DELETE.getEventValue();
				}
				else if(attributeType.equals(DynamicAttributeType.JSVARIABLE.getAttributeTypeCode()))
				{
					eventValue = EventActivityConstants.EventType.EXP_JSVAR_DELETE.getEventValue();
				}
				else if(attributeType.equals(DynamicAttributeType.CUSTOMDIMENSION.getAttributeTypeCode()))
				{
					eventValue = EventActivityConstants.EventType.EXP_CUSTDIMENSION_DELETE.getEventValue();
				}
				
				hs.put(EventActivityConstants.EVENT_TYPE, eventValue.toString());
				hs.put(EventActivityConstants.VALUE, attributename);
				EventActivityLog.createEventActivityLog(hs);
			}
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	public static void onExpIntegrationCreation(HashMap<String, String> updatedValues)
	{
		try
		{
			String experimentId = updatedValues.get(EventActivityConstants.EXPERIMENT_ID);
			String userId = updatedValues.get(EventActivityConstants.USER_ID);
			String time = updatedValues.get(EventActivityConstants.TIME);
			String integrationId =  updatedValues.get(IntegrationConstants.INTEGRATION_ID);
			String projectId = updatedValues.get(EventActivityConstants.PROJECT_ID);
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(EventActivityConstants.PROJECT_ID, projectId);
			hs.put(EventActivityConstants.EXPERIMENT_ID, experimentId);
			hs.put(EventActivityConstants.USER_ID, userId);
			hs.put(EventActivityConstants.TIME, time);
			hs.put(EventActivityConstants.MODULE, EventActivityConstants.Module.INTEGRATION.getValue().toString());
			hs.put(EventActivityConstants.VALUE, integrationId);
			hs.put(EventActivityConstants.EVENT_TYPE, EventActivityConstants.EventType.EXP_INTEGRATION_CREATE.getEventValue().toString());
			EventActivityLog.createEventActivityLog(hs);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	public static void onExpIntegrationDeletion(HashMap<String, String> updatedValues)
	{
		try
		{
			String experimentId = updatedValues.get(EventActivityConstants.EXPERIMENT_ID);
			String projectId = updatedValues.get(EventActivityConstants.PROJECT_ID);
			String userId = updatedValues.get(EventActivityConstants.USER_ID);
			String time = updatedValues.get(EventActivityConstants.TIME);
			String integrationId =  updatedValues.get(IntegrationConstants.INTEGRATION_ID);
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(EventActivityConstants.PROJECT_ID, projectId.toString());
			hs.put(EventActivityConstants.EXPERIMENT_ID, experimentId);
			hs.put(EventActivityConstants.USER_ID, userId);
			hs.put(EventActivityConstants.TIME, time);
			hs.put(EventActivityConstants.MODULE, EventActivityConstants.Module.INTEGRATION.getValue().toString());
			hs.put(EventActivityConstants.VALUE, integrationId);
			hs.put(EventActivityConstants.EVENT_TYPE, EventActivityConstants.EventType.EXP_INTEGRATION_DELETE.getEventValue().toString());
			EventActivityLog.createEventActivityLog(hs);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
}
