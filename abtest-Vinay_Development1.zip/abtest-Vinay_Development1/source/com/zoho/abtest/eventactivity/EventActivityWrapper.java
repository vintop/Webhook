//$Id$
package com.zoho.abtest.eventactivity;

import java.io.Serializable;
import java.util.HashMap;

import com.zoho.abtest.eventactivity.EventActivityConstants.Module;
import com.zoho.abtest.eventactivity.EventActivityConstants.OperationType;

public class EventActivityWrapper implements Serializable{

	private static final long serialVersionUID = 1L;
	private Module module;
	private OperationType operationType;
	private String dbSpace;
	private HashMap<String, String> updatedValues;
	private HashMap<String, String> oldValues;
	private Object customObject;
	
	public HashMap<String, String> getOldValues() {
		return oldValues;
	}
	public void setOldValues(HashMap<String, String> oldValues) {
		this.oldValues = oldValues;
	}
	
	public Object getCustomObject() {
		return customObject;
	}
	public void setCustomObject(Object customObject) {
		this.customObject = customObject;
	}
	public Module getModule() {
		return module;
	}
	public void setModule(Module module) {
		this.module = module;
	}
	public OperationType getOperationType() {
		return operationType;
	}
	public void setOperationType(OperationType operationType) {
		this.operationType = operationType;
	}
	public String getDbSpace() {
		return dbSpace;
	}
	public void setDbSpace(String dbSpace) {
		this.dbSpace = dbSpace;
	}
	public HashMap<String, String> getUpdatedValues() {
		return updatedValues;
	}
	public void setUpdatedValues(HashMap<String, String> updatedValues) {
		this.updatedValues = updatedValues;
	}
	
}
