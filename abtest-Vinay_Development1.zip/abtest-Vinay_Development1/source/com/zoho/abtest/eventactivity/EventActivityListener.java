//$Id$
package com.zoho.abtest.eventactivity;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.zoho.abtest.listener.IPRestrictionData;
import com.zoho.abtest.listener.ZABListener;
import com.zoho.mqueue.consumer.ConsumerRecord;
import com.zoho.mqueue.consumer.MessageListener;
import com.zoho.abtest.project.ProjectTreeEventWrapper;
import com.zoho.abtest.utility.ZABUtil;

public class EventActivityListener extends ZABListener implements MessageListener<String, String>{

	private static final Logger LOGGER = Logger.getLogger(EventActivityListener.class.getName());

	@Override
	public void consumeMessage(Object obj) throws Exception {
		try
		{
			if(obj != null)
			{
				EventActivityWrapper wrapper = (EventActivityWrapper)obj;
				EventActivityHandler.handleEventActivity(wrapper);
			}
		}
		catch (Exception ex) 
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			throw new Exception(ex);
		}
	}

	@Override
	public IPRestrictionData getIPRestrictionData(Object message) {
		return null;
	}

}
