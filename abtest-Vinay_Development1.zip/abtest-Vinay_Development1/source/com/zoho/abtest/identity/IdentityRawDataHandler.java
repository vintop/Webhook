//$Id$
package com.zoho.abtest.identity;

import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.json.JSONObject;
import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.zoho.abtest.USER_IDENTITY_DETAILS;
import com.zoho.abtest.common.ZABModel;

import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.report.ReportRawDataAction;
import com.zoho.abtest.report.ReportRawDataConstants;
import com.zoho.abtest.report.VisitorRawDataWrapper;
import com.zoho.abtest.utility.ApplicationProperty;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.ear.encryptagent.EncryptAgent;

public class IdentityRawDataHandler extends ZABModel{
	
	private static final Logger LOGGER = Logger.getLogger(IdentityRawDataHandler.class.getName());
	
	//private static final String EAR_KEY = ApplicationProperty.getString("com.zoho.abtest.ear.key");//No I18N
		

	public static void handleIdentityRawData(VisitorRawDataWrapper wrapper) {
		// TODO Auto-generated method stub
		HashMap<String, String> hs = wrapper.getIdentityData();
		
		String portal = hs.get(ReportRawDataConstants.PORTAL);
		Long zsoid = ZABServiceOrgUtil.getZSOIDFromDomain(portal);
		
		String dbSpaceId = null;
		
		if(zsoid != null)
		{
			dbSpaceId = zsoid.toString();
		}
		else
		{
			LOGGER.log(Level.SEVERE,"Invalid portal provided :"+hs.get(ReportRawDataConstants.PORTAL));
			LOGGER.log(Level.SEVERE,hs.toString());
		}
		
		ZABUtil.setDBSpace(dbSpaceId);
		
		String projectKey = hs.get(ReportRawDataConstants.PROJECT_KEY);
		//Long projectId = Project.getProjectIdFromKey(projectKey);
		
		HashMap<String,String> hashMap = new HashMap<String,String>();

//		JSONObject json = new JSONObject();
//		String type = ElasticSearchConstants.IDENTITY_RAW_DATA_TYPE;
		try{
//			if(isVisitorExists(hs.get(ReportRawDataConstants.UUID))) {
//				return;
//			}
			hashMap.put(IdentityConstants.IDENTITY_DETAILS, hs.get(ReportRawDataConstants.IDENTITY_DETAILS));
			hashMap.put(IdentityConstants.UUID, hs.get(ReportRawDataConstants.UUID));
			hashMap.put(IdentityConstants.PROJECT_KEY, projectKey);
			hashMap.put(IdentityConstants.TIME, wrapper.getTime().toString());
			
			createRow(IdentityConstants.IDENTITY_DETAILS_TABLE,USER_IDENTITY_DETAILS.TABLE,hashMap);

//			String index = ElasticSearchUtil.getIndexByPortal(portal);
//			String encryptedName = EncryptAgent.getInstance().encrypt(zsoid, hs.get(ReportRawDataConstants.IDENTITY_DETAILS), EAR_KEY, true);
//			json.put(ElasticSearchConstants.PORTAL, portal);
//			json.put(ElasticSearchConstants.ZSOID, zsoid);
//			json.put(ElasticSearchConstants.IDENTITY_DETAILS, encryptedName);
//			json.put(ElasticSearchConstants.TIME, wrapper.getTime());
//			json.put(ElasticSearchConstants.PROJECTID, projectId);
//			json.put(ElasticSearchConstants.UUID, hs.get(ReportRawDataConstants.UUID));
//			ElasticSearchUtil.createIndex(index, type, hs.get(ReportRawDataConstants.UUID),json.toString());
		}catch(DataAccessException e) {
			int errCode = e.getErrorCode();
			if(errCode == 1001) {
				return;
			} else {
				LOGGER.log(Level.SEVERE, e.getMessage(), e);
			}
		}
		catch(Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}

	}
	
	
//	public static Boolean isVisitorExists(String visitorId) {
//		
//		Boolean isExists = true;
//
//		try{
//			Criteria criteria = new Criteria(new Column(USER_IDENTITY_DETAILS.TABLE, USER_IDENTITY_DETAILS.UUID),visitorId,QueryConstants.EQUAL);
//			DataObject dataObj = ZABModel.getRow(USER_IDENTITY_DETAILS.TABLE, criteria);
//			if(dataObj.isEmpty())
//			{
//				isExists = false;
//			} else {
//				isExists = true;
//			}
//		} catch(Exception e) {
//			LOGGER.log(Level.SEVERE, e.getMessage(), e);
//		}
//		return isExists;
//	}

}



