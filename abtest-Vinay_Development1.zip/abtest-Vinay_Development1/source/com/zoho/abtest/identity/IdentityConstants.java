//$Id$
package com.zoho.abtest.identity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.zoho.abtest.USER_IDENTITY_DETAILS;
import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.ZABConstants;

public class IdentityConstants {
	
	public static final String UUID = "uuid";    //No I18N
	public static final String IDENTITY_DETAILS = "identity_details";    //No I18N
	public static final String PORTAL_DOMAIN = "portal_domain";    //No I18N
	public static final String ZSOID = "zsoid";    //No I18N
	public static final String PROJECT_ID = "project_id";    //No I18N
	public static final String PROJECT_KEY = "project_key";    //No I18N
	public static final String TIME = "time";    //No I18N

    public final static List<Constants> IDENTITY_DETAILS_TABLE;

	static{
		
		ArrayList<Constants> list = new ArrayList<Constants>();
		
		list.add(new Constants(UUID,USER_IDENTITY_DETAILS.UUID,ZABConstants.STRING,Boolean.FALSE));
		list.add(new Constants(IDENTITY_DETAILS,USER_IDENTITY_DETAILS.IDENTITY_DETAILS,ZABConstants.STRING,Boolean.FALSE));
		list.add(new Constants(PROJECT_KEY,USER_IDENTITY_DETAILS.PROJECT_KEY,ZABConstants.STRING,Boolean.FALSE));
		list.add(new Constants(TIME,USER_IDENTITY_DETAILS.TIME,ZABConstants.LONG,Boolean.FALSE));

		IDENTITY_DETAILS_TABLE = (List<Constants>) Collections.unmodifiableList(list);
	}
}
