//$Id$
package com.zoho.abtest.identity;

import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.listener.IPRestrictionData;
import com.zoho.abtest.listener.ZABListener;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.project.ProjectConstants;
import com.zoho.abtest.report.ReportRawDataConstants;
import com.zoho.abtest.report.VisitorRawDataWrapper;
import com.zoho.abtest.sessionrecording.SessionRawDataInHandler;
import com.zoho.abtest.sessionrecording.SessionRawDataListener;
import com.zoho.mqueue.consumer.MessageListener;

public class IdentityRawDataListener extends ZABListener implements MessageListener<String, String> {
	
	private static final Logger LOGGER = Logger.getLogger(IdentityRawDataListener.class.getName());

	@Override
	public IPRestrictionData getIPRestrictionData(Object message) throws ZABException {
		
		VisitorRawDataWrapper wrapper = (VisitorRawDataWrapper)message;
		HashMap<String, String> identityRawData = wrapper.getIdentityData();
		String portal = identityRawData.get(ReportRawDataConstants.PORTAL);
		String projectKey = identityRawData.get(ReportRawDataConstants.PROJECT_KEY);
		setDBSpace(portal);
		Long projectId = Project.getProjectIdFromKey(projectKey);
		LOGGER.log(Level.INFO, "Getting IP Address from identity raw data:"+projectId+", "+ wrapper.getIpAddress());
		return new IPRestrictionData(portal, projectId, wrapper.getIpAddress());
		
	}

	@Override
	public void consumeMessage(Object obj) throws Exception {
		try {			
			if(obj!=null) {
				VisitorRawDataWrapper wrapper = (VisitorRawDataWrapper)obj;
				IdentityRawDataHandler.handleIdentityRawData(wrapper);
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(),e);
		}
	}

}
