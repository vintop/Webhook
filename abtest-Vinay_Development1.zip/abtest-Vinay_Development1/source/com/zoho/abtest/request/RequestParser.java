//$Id$
package com.zoho.abtest.request;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;

import com.google.gson.JsonObject;

public interface RequestParser {
	public HashMap<String,String> parseExperiment(HttpServletRequest request)throws JSONException, IOException;
	public HashMap<String, String> parseProject(HttpServletRequest request)throws JSONException, IOException;
	public HashMap<String, String> parseWebhook(HttpServletRequest request)throws JSONException, IOException;
	public HashMap<String, String> parseTrigger(HttpServletRequest request)throws JSONException, IOException;
	public HashMap<String,String> parseVariation(HttpServletRequest request)throws JSONException, IOException;
	public HashMap<String,String> parseGoal(HttpServletRequest request)throws JSONException, IOException;
	public HashMap<String, String> parseUser(HttpServletRequest request)throws JSONException, IOException;

	public HashMap<String,String> parseReport(HttpServletRequest request)throws JSONException, IOException;
	public ArrayList<HashMap<String,String>> parseVisitorRawData(HttpServletRequest request, Boolean isExperimentData)throws JSONException, IOException;
	
	public HashMap<String, String> parseDynamicAttributes(HttpServletRequest request)throws JSONException, IOException;
	public HashMap<String, String> parsePortal(HttpServletRequest request)throws JSONException, IOException;
	public HashMap<String, String> parseDefaultPortal(HttpServletRequest request)throws JSONException, IOException;
	public HashMap<String, String> parseProjectUserRole(HttpServletRequest request)throws JSONException, IOException;
	
	public ArrayList<HashMap<String,String>> parseGoalRawData(HttpServletRequest request, Boolean isExperimentData)throws JSONException, IOException;
	public ArrayList<HashMap<String,String>> parseHeatmapRawData(HttpServletRequest request, String type)throws JSONException, IOException;
	public ArrayList<HashMap<String,String>> parseFormAnalyticsRawData(HttpServletRequest request, String type)throws JSONException, IOException;

	public HashMap<String,String> parseAudience(HttpServletRequest request)throws JSONException, IOException;
	public HashMap<String,String> parseAudienceAttribute(HttpServletRequest request)throws JSONException, IOException;
	public HashMap<String,String> parseAudienceMatchType(HttpServletRequest request)throws JSONException, IOException;
	public HashMap<String,String> parseExperimentAudience(HttpServletRequest request)throws JSONException, IOException;
	public HashMap<String,String> parseProjectAudience(HttpServletRequest request)throws JSONException, IOException;
	public HashMap<String,String> parseDimension(HttpServletRequest request)throws JSONException, IOException;
	public HashMap<String,String> parseSampleSize(HttpServletRequest request)throws JSONException, IOException;
	public HashMap<String,String> parseIntegration(HttpServletRequest request)throws JSONException, IOException;
	public HashMap<String,String> parseGoogleAnalytics(HttpServletRequest request)throws JSONException, IOException;
	public HashMap<String,String> parseGoogleAdwords(HttpServletRequest request)throws JSONException, IOException;
	public HashMap<String,String> parseGoogleTagManager(HttpServletRequest request)throws JSONException, IOException;
	public HashMap<String, String> parseDynamicConfiguration(HttpServletRequest request)throws JSONException, IOException;
	public HashMap<String,String> parseForm(HttpServletRequest request)throws JSONException, IOException;
	public HashMap<String,String> parseFormRawData(HttpServletRequest request)throws JSONException, IOException;
	public HashMap<String,String> parseFormReport(HttpServletRequest request)throws JSONException, IOException;
	
	public HashMap<String,String> parseFunnelRawData(HttpServletRequest request, String type)throws JSONException, IOException;
	public ArrayList<HashMap<String,String>> parseSessionRawData(JsonObject obj, String type)throws JSONException, IOException;
	public String parseSessionEventData(JsonObject obj, String type)throws JSONException, IOException;
	public HashMap<String,String> parseFunnelReportData(HttpServletRequest request)throws JSONException, IOException;
	public HashMap<String,String> parseFunnelTimelineData(HttpServletRequest request)throws JSONException, IOException;
	public HashMap<String,String> parseFunnelSteps(HttpServletRequest request)throws JSONException, IOException;
	public HashMap<String, String> parseHeatmapReport(HttpServletRequest request) throws JSONException, IOException;
	public ArrayList<HashMap<String, String>> parseScrollmapRawData(HttpServletRequest request, String apiModuleScrollDataSh) throws JSONException, IOException;
	public HashMap<String, String> parseScrollmapReport(HttpServletRequest request) throws JSONException, IOException;
	public HashMap<String,String> parseLicense(HttpServletRequest request)throws JSONException, IOException;
	
	HashMap<String, String> parseESQuickFilterAttrReport(HttpServletRequest request) throws JSONException, IOException;
	public  HashMap<String,String> parseSessionUAData(JsonObject obj, String type)throws JSONException, IOException;
	
	public  HashMap<String,String> parseSessionPlayListRequest(HttpServletRequest request, String type)throws JSONException, IOException;

	public HashMap<String, String> parseAttentionmapReport(HttpServletRequest request) throws JSONException, IOException;

	public HashMap<String,String> parseCustomEvent(HttpServletRequest request)throws JSONException, IOException;
	
	public HashMap<String,String> parsePrivacy(HttpServletRequest request)throws JSONException, IOException;

}
