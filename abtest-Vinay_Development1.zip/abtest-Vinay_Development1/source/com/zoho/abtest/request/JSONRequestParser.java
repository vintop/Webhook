//$Id$
package com.zoho.abtest.request;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.zoho.abtest.audience.AudienceAttributeConstants;
import com.zoho.abtest.audience.AudienceConstants;
import com.zoho.abtest.audience.AudienceMatchTypeConstants;
import com.zoho.abtest.audience.AudienceRequest;
import com.zoho.abtest.audience.ExperimentAudienceConstants;
import com.zoho.abtest.audience.ExperimentAudienceRequest;
import com.zoho.abtest.audience.ProjectAudienceConstants;
import com.zoho.abtest.audience.ProjectAudienceRequest;
import com.zoho.abtest.customevent.CustomEventConstants;
import com.zoho.abtest.customevent.CustomEventRequest;
import com.zoho.abtest.dimension.DimensionConstants;
import com.zoho.abtest.dimension.DimensionRequest;
import com.zoho.abtest.dimension.DynamicAttributeRequest;
import com.zoho.abtest.dynamicconf.DynamicConfigurationConstants;
import com.zoho.abtest.dynamicconf.DynamicConfigurationRequest;
import com.zoho.abtest.elastic.ESQuickFilterAttrsRequest;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.experiment.ExperimentRequest;
import com.zoho.abtest.forms.FormConstants;
import com.zoho.abtest.forms.FormRawDataConstants;
import com.zoho.abtest.forms.FormRawDataRequest;
import com.zoho.abtest.forms.FormReportConstants;
import com.zoho.abtest.forms.FormReportRequest;
import com.zoho.abtest.forms.FormRequest;
import com.zoho.abtest.funnel.FunnelAnalysisConstants;
import com.zoho.abtest.funnel.FunnelStepRequest;
import com.zoho.abtest.funnel.report.FunnelRawDataRequest;
import com.zoho.abtest.funnel.report.FunnelReportConstants;
import com.zoho.abtest.funnel.report.FunnelReportRequest;
import com.zoho.abtest.funnel.report.FunnelTimelineReportRequest;
import com.zoho.abtest.goal.GoalConstants;
import com.zoho.abtest.goal.GoalRequest;
import com.zoho.abtest.heatmaps.HeatmapConstants;
import com.zoho.abtest.heatmaps.HeatmapDataRequest;
import com.zoho.abtest.heatmaps.HeatmapRawDataRequest;
import com.zoho.abtest.heatmaps.ScrollmapConstants;
import com.zoho.abtest.integration.GoogleAdwordsRequest;
import com.zoho.abtest.integration.GoogleAnalyticsRequest;
import com.zoho.abtest.integration.GoogleTagManagerRequest;
import com.zoho.abtest.integration.IntegrationConstants;
import com.zoho.abtest.integration.IntegrationRequest;
import com.zoho.abtest.license.LicenseConstants;
import com.zoho.abtest.license.LicenseRequest;
import com.zoho.abtest.misc.SampleSizeCalculatorRequest;
import com.zoho.abtest.portal.DefaultPortalRequest;
import com.zoho.abtest.portal.PortalConstants;
import com.zoho.abtest.portal.PortalRequest;
import com.zoho.abtest.privacyconsent.PrivacyConstants;
import com.zoho.abtest.privacyconsent.PrivacyRequest;
import com.zoho.abtest.project.ProjectConstants;
import com.zoho.abtest.project.ProjectRequest;
import com.zoho.abtest.report.CumulativeReportConstants;
import com.zoho.abtest.report.GoalRawDataRequest;
import com.zoho.abtest.report.ReportRawDataConstants;
import com.zoho.abtest.report.ReportRequest;
import com.zoho.abtest.report.VisitorRawDataRequest;
import com.zoho.abtest.sessionrecording.playlist.SessionPlayListRequest;
import com.zoho.abtest.trigger.TriggerConstants;
import com.zoho.abtest.trigger.TriggerRequest;
import com.zoho.abtest.user.ProjectUserRoleConstants;
import com.zoho.abtest.user.ProjectUserRoleRequest;
import com.zoho.abtest.user.ZABUserConstants;
import com.zoho.abtest.user.ZABUserRequest;
import com.zoho.abtest.variation.VariationConstants;
import com.zoho.abtest.variation.VariationRequest;

import com.zoho.abtest.webhook.WebhookConstants;
import com.zoho.abtest.webhook.WebhookRequest;
import com.zoho.abtest.integration.GoogleAnalyticsRequest;
import com.zoho.abtest.integration.GoogleAdwordsRequest;
import com.zoho.abtest.integration.GoogleTagManagerRequest;
import com.zoho.abtest.integration.IntegrationConstants;
import com.zoho.abtest.integration.IntegrationRequest;
import com.zoho.abtest.forms.FormRequest;
import com.zoho.abtest.forms.FormRawDataRequest;
import com.zoho.abtest.forms.FormReportRequest;
import com.zoho.abtest.forms.FormConstants;
import com.zoho.abtest.forms.FormRawDataConstants;
import com.zoho.abtest.forms.FormReportConstants;


public class JSONRequestParser implements RequestParser {

	@Override
	public HashMap<String, String> parseExperiment(HttpServletRequest request) throws JSONException, IOException {
		return new ExperimentRequest().parseSingleResourceJSON(request, ExperimentConstants.API_MODULE);
	}

	@Override
	public HashMap<String, String> parseVariation(HttpServletRequest request) throws JSONException, IOException {
		return new VariationRequest().parseSingleResourceJSON(request, VariationConstants.API_MODULE);
	}

	@Override
	public HashMap<String, String> parseReport(
			HttpServletRequest request) throws JSONException, IOException {
		return new ReportRequest().parseSingleResourceJSON(request, CumulativeReportConstants.API_MODULE);
	}
	
	@Override
	public HashMap<String, String> parseESQuickFilterAttrReport(
			HttpServletRequest request) throws JSONException, IOException {
		return new ESQuickFilterAttrsRequest().parseSingleResourceJSON(request, CumulativeReportConstants.API_MODULE);
	}
	
	@Override
	public HashMap<String, String> parseHeatmapReport(HttpServletRequest request)
			throws JSONException, IOException {		
		return new HeatmapDataRequest().parseSingleResourceJSON(request, HeatmapConstants.API_MODULE);
	}
	
	@Override
	public HashMap<String, String> parseScrollmapReport(HttpServletRequest request)
			throws JSONException, IOException {		
		return new HeatmapDataRequest().parseSingleResourceJSON(request, ScrollmapConstants.API_MODULE);
	}

	@Override
	public HashMap<String, String> parseProject(
			HttpServletRequest request) throws JSONException, IOException {
		return new ProjectRequest().parseSingleResourceJSON(request, ProjectConstants.API_MODULE);
	}
	
	@Override
	public HashMap<String, String> parseWebhook(HttpServletRequest request) throws JSONException, IOException {
		return new WebhookRequest().parseSingleResourceJSON(request, WebhookConstants.API_MODULE);
	}
	
	public ArrayList<HashMap<String,String>> parseVisitorRawData(HttpServletRequest request, Boolean isExperimentData)throws JSONException, IOException
	{
		ArrayList<HashMap<String,String>> mapArray = null;
		VisitorRawDataRequest visitorRawDataRequest = new VisitorRawDataRequest();
		if(isExperimentData)
		{
			mapArray = visitorRawDataRequest.parseJSONRawdata(request, ReportRawDataConstants.API_MODULE_VISITOR_RAW_SH,isExperimentData);
		}
		else
		{
			mapArray = visitorRawDataRequest.parseJSONRawdata(request, ReportRawDataConstants.API_MODULE_USERAGENT_RAW_SH,isExperimentData);
		}
		return mapArray;
	}
	
	public ArrayList<HashMap<String,String>> parseGoalRawData(HttpServletRequest request, Boolean isExperimentData)throws JSONException, IOException
	{
		ArrayList<HashMap<String,String>> mapArray = null;
		GoalRawDataRequest goalRawDataRequest = new GoalRawDataRequest();
		if(isExperimentData)
		{
			mapArray = goalRawDataRequest.parseJSONRawdata(request, ReportRawDataConstants.API_MODULE_GOAL_RAW_SH,isExperimentData);
		}
		else
		{
			mapArray = goalRawDataRequest.parseJSONRawdata(request, ReportRawDataConstants.API_MODULE_USERAGENT_RAW_SH,isExperimentData);
		}
		return mapArray;
	}

	public ArrayList<HashMap<String,String>> parseHeatmapRawData(HttpServletRequest request, String type)throws JSONException, IOException
	{
		ArrayList<HashMap<String,String>> mapArray = null;
		HeatmapRawDataRequest HeatmapRawDataRequest = new HeatmapRawDataRequest();
		switch(type)
		{ 
			case ReportRawDataConstants.API_MODULE_HEATMAP_RAW_SH :
				mapArray = HeatmapRawDataRequest.parseHeatmapJSONFromUrlParam(request, ReportRawDataConstants.API_MODULE_HEATMAP_RAW_SH,true);
				break;
			case ReportRawDataConstants.API_MODULE_HEATMAP_POINTS_SH :
				mapArray = HeatmapRawDataRequest.parseHeatmapJSONFromUrlParam(request, ReportRawDataConstants.API_MODULE_HEATMAP_POINTS_SH,false);
				break;
			case ReportRawDataConstants.API_MODULE_USERAGENT_RAW_SH :
				mapArray = HeatmapRawDataRequest.parseHeatmapJSONFromUrlParam(request, ReportRawDataConstants.API_MODULE_USERAGENT_RAW_SH,false);
				break;
			default : 
				break;
		}
		return mapArray;
	}
	
	public HashMap<String,String> parseFunnelRawData(HttpServletRequest request, String type)throws JSONException, IOException
	{
		HashMap<String,String> map = new HashMap<String, String>();
		ArrayList<HashMap<String,String>> arr = new FunnelRawDataRequest().parseJSONRawdata(request, type, Boolean.FALSE);
		if(arr.size() > 0) {
			map = arr.get(0);
		}
		return map;
	}
	
	public ArrayList<HashMap<String,String>> parseSessionRawData(JsonObject obj, String type)throws JSONException, IOException
	{
		ArrayList<HashMap<String,String>> arr = new ArrayList<HashMap<String,String>>();
		
		JsonArray array = obj.get(type).getAsJsonArray();
		
		array.forEach(elem -> {
			HashMap<String, String> hs = new HashMap<String, String>();
			elem.getAsJsonObject().entrySet().forEach(e -> {
				if(e.getValue().isJsonPrimitive()) {					
					hs.put(e.getKey(), e.getValue().getAsString());
				} else {
					hs.put(e.getKey(), e.getValue().toString());
				}
			});
			arr.add(hs);
		});
		
		return arr;
	}
	
	public HashMap<String,String> parseSessionUAData(JsonObject obj, String type)throws JSONException, IOException
	{
		HashMap<String, String> hs = new HashMap<String, String>();
		
		JsonElement typeElem = obj.get(type);
		JsonObject typeObj = typeElem.getAsJsonObject();
		
		typeObj.entrySet().forEach(e -> {
			if(e.getValue().isJsonPrimitive()) {					
				hs.put(e.getKey(), e.getValue().getAsString());
			} else {
				hs.put(e.getKey(), e.getValue().toString());
			}
		});
		
		return hs;
	}
	
	public String parseSessionEventData(JsonObject obj, String type)throws JSONException, IOException
	{		
		return obj.get(type).toString();
	}
	
	public ArrayList<HashMap<String,String>> parseScrollmapRawData(HttpServletRequest request, String type)throws JSONException, IOException
	{
		ArrayList<HashMap<String,String>> mapArray = null;
		HeatmapRawDataRequest HeatmapRawDataRequest = new HeatmapRawDataRequest();
		switch(type)
		{ 
			case ReportRawDataConstants.API_MODULE_SCROLLMAP_RAW_SH :
				mapArray = HeatmapRawDataRequest.parseScrollmapJSONFromUrlParam(request, ReportRawDataConstants.API_MODULE_SCROLLMAP_RAW_SH,true);
				break;
			case ReportRawDataConstants.API_MODULE_SCROLL_DATA_SH :
				mapArray = HeatmapRawDataRequest.parseScrollmapJSONFromUrlParam(request, ReportRawDataConstants.API_MODULE_SCROLL_DATA_SH,false);
				break;
			case ReportRawDataConstants.API_MODULE_USERAGENT_RAW_SH :
				mapArray = HeatmapRawDataRequest.parseScrollmapJSONFromUrlParam(request, ReportRawDataConstants.API_MODULE_USERAGENT_RAW_SH,false);
				break;
			default : 
				break;
		}
		return mapArray;
	}
	
	@Override
	public HashMap<String, String> parseGoal(HttpServletRequest request)
			throws JSONException, IOException {
		String requestUri =  request.getRequestURI();
		if(requestUri.contains("/projectgoals")){
			String requestUriArr[] = requestUri.split("/");
			 if( requestUriArr[6].equals("projectgoals")){
				 return new GoalRequest().parseSingleResourceJSON(request, GoalConstants.PROJECT_GOALS);
			 }
		
		}
		return new GoalRequest().parseSingleResourceJSON(request, GoalConstants.API_MODULE);
	}


	public HashMap<String, String> parseAudience(HttpServletRequest request) throws JSONException, IOException {
		return new AudienceRequest().parseSingleResourceJSON(request, AudienceConstants.API_MODULE_SINGLE);
	}
	
	public HashMap<String, String> parseAudienceAttribute(HttpServletRequest request) throws JSONException, IOException {
		return new AudienceRequest().parseSingleResourceJSON(request, AudienceAttributeConstants.API_MODULE);
	}

	public HashMap<String, String> parseAudienceMatchType(HttpServletRequest request) throws JSONException, IOException {
		return new AudienceRequest().parseSingleResourceJSON(request, AudienceMatchTypeConstants.API_MODULE);
	}

	
	public HashMap<String, String> parseExperimentAudience(HttpServletRequest request) throws JSONException, IOException {
		return new ExperimentAudienceRequest().parseSingleResourceJSON(request, ExperimentAudienceConstants.API_MODULE);
	}
	
	public HashMap<String, String> parseProjectAudience(HttpServletRequest request) throws JSONException, IOException {
		return new ProjectAudienceRequest().parseSingleResourceJSON(request, ProjectAudienceConstants.API_MODULE);
	}
	@Override
	public HashMap<String, String> parseDimension(HttpServletRequest request) throws JSONException, IOException {
		return new DimensionRequest().parseSingleResourceJSON(request, DimensionConstants.API_MODULE);
	}

	public HashMap<String, String> parseSampleSize(HttpServletRequest request)throws JSONException, IOException
	{
		return new SampleSizeCalculatorRequest().parseSingleResourceJSON(request, CumulativeReportConstants.SAMPLE_SIZE);
	}

	public HashMap<String, String> parseDynamicAttributes(HttpServletRequest request)throws JSONException, IOException
	{
		return new DynamicAttributeRequest().parseSingleResourceJSON(request, DimensionConstants.DYNAMIC_ATTRIBUTES_API_MODULE);
	}
	
	public HashMap<String, String> parsePortal(HttpServletRequest request)throws JSONException, IOException
	{
		return new PortalRequest().parseSingleResourceJSON(request, PortalConstants.API_MODULE);
	}
	
	public HashMap<String, String> parseDefaultPortal(HttpServletRequest request)throws JSONException, IOException
	{
		return new DefaultPortalRequest().parseSingleResourceJSON(request, PortalConstants.API_MODULE);
	}
	
	public HashMap<String, String> parseProjectUserRole(HttpServletRequest request)throws JSONException, IOException
	{
		return new ProjectUserRoleRequest().parseSingleResourceJSON(request, ProjectUserRoleConstants.API_MODULE);
	}

	public HashMap<String, String> parseIntegration(HttpServletRequest request) throws JSONException, IOException {
		return new IntegrationRequest().parseSingleResourceJSON(request, IntegrationConstants.API_MODULE);
	}
	

	@Override
	public HashMap<String, String> parseUser(HttpServletRequest request)
			throws JSONException, IOException {
		return new ZABUserRequest().parseSingleResourceJSON(request, ZABUserConstants.API_MODULE_SINGULAR);
	}

	@Override
	public HashMap<String, String> parseGoogleAnalytics(HttpServletRequest request) throws JSONException, IOException {
		return new GoogleAnalyticsRequest().parseSingleResourceJSON(request,IntegrationConstants.API_MODULE_GOOGLEANALYTICS);
	}
	
	@Override
	public HashMap<String, String> parseGoogleAdwords(HttpServletRequest request) throws JSONException, IOException {
		return new GoogleAdwordsRequest().parseSingleResourceJSON(request,IntegrationConstants.API_MODULE_GOOGLEADWORDS);
	}
	
	@Override
	public HashMap<String, String> parseGoogleTagManager(HttpServletRequest request) throws JSONException, IOException {
		return new GoogleTagManagerRequest().parseSingleResourceJSON(request,IntegrationConstants.API_MODULE_GOOGLETAGMANAGER);
	}
	public HashMap<String, String> parseDynamicConfiguration(HttpServletRequest request)throws JSONException, IOException
	{
		return new DynamicConfigurationRequest().parseSingleResourceJSON(request, DynamicConfigurationConstants.API_MODULE);
	}
	
	public HashMap<String, String> parseForm(HttpServletRequest request) throws JSONException, IOException {
		return new FormRequest().parseSingleResourceJSON(request, FormConstants.API_MODULE);
	}
	
	public HashMap<String, String> parseFormRawData(HttpServletRequest request) throws JSONException, IOException {
		return new FormRawDataRequest().parseSingleResourceJSON(request, FormRawDataConstants.API_MODULE);
	}
	
	public HashMap<String, String> parseFormReport(HttpServletRequest request) throws JSONException, IOException {
		return new FormReportRequest().parseSingleResourceJSON(request, FormReportConstants.API_MODULE);
	}

	 @Override
	 public ArrayList<HashMap<String, String>> parseFormAnalyticsRawData(
				HttpServletRequest request, String type) throws JSONException,
				IOException {
			// TODO Auto-generated method stub
			ArrayList<HashMap<String,String>> mapArray = null;
			FormRawDataRequest FormRawDataRequest = new FormRawDataRequest();
			switch(type){
			    case ReportRawDataConstants.API_MODULE_FORMANALYTICSEXP_RAW_SH:
			    	mapArray = FormRawDataRequest.parseFormAnalyticsJSONFromUrlParam(request, ReportRawDataConstants.API_MODULE_FORMANALYTICSEXP_RAW_SH,true);
			    	break;
			   case ReportRawDataConstants.API_MODULE_FORMANALYTICS_RAW_SH:
			    	mapArray = FormRawDataRequest.parseFormAnalyticsJSONFromUrlParam(request, ReportRawDataConstants.API_MODULE_FORMANALYTICS_RAW_SH,false);
			    	break;
			   case ReportRawDataConstants.API_MODULE_USERAGENT_RAW_SH:
			    	mapArray = FormRawDataRequest.parseFormAnalyticsJSONFromUrlParam(request, ReportRawDataConstants.API_MODULE_USERAGENT_RAW_SH,false);
			    	break;
			   default : 
					break;

			}
			
			return mapArray;
		}
		


	@Override
	public HashMap<String, String> parseFunnelReportData(
			HttpServletRequest request) throws JSONException, IOException {
		return new FunnelReportRequest().parseSingleResourceJSON(request, FunnelReportConstants.API_MODULE);
	}
	
	


	@Override
	public HashMap<String, String> parseFunnelSteps(HttpServletRequest request)
			throws JSONException, IOException {
		return new FunnelStepRequest().parseSingleResourceJSON(request, FunnelAnalysisConstants.STEP_API_MODULE_NAME);
	}
	public HashMap<String, String> parseLicense(HttpServletRequest request) throws JSONException, IOException {
		return new LicenseRequest().parseSingleResourceJSON(request, LicenseConstants.API_MODULE);
	}

	@Override
	public HashMap<String, String> parseFunnelTimelineData(
			HttpServletRequest request) throws JSONException, IOException {
		return new FunnelTimelineReportRequest().parseSingleResourceJSON(request, FunnelReportConstants.API_MODULE_TL);
	}
	public HashMap<String, String> parseCustomEvent(HttpServletRequest request) throws JSONException, IOException {
		return new CustomEventRequest().parseSingleResourceJSON(request, CustomEventConstants.API_MODULE);
	}

	@Override
	public HashMap<String, String> parseSessionPlayListRequest(
			HttpServletRequest request, String type) throws JSONException,
			IOException {
		return new SessionPlayListRequest().parseSingleResourceJSON(request, type);
	}

	@Override
	public HashMap<String, String> parseAttentionmapReport(HttpServletRequest request) throws JSONException, IOException {
		// TODO Auto-generated method stub
		return new HeatmapDataRequest().parseSingleResourceJSON(request, HeatmapConstants.ATTENTIONMAP_API_MODULE);
	}

	@Override
	public HashMap<String, String> parsePrivacy(HttpServletRequest request)
			throws JSONException, IOException {
		// TODO Auto-generated method stub
		return new PrivacyRequest().parseSingleResourceJSON(request, PrivacyConstants.PRIVACY_CONSENTS_MODULE);
	}

	@Override
	public HashMap<String, String> parseTrigger(HttpServletRequest request)
			throws JSONException, IOException {
		// TODO Auto-generated method stub
		return new TriggerRequest().parseSingleResourceJSON(request, TriggerConstants.API_MODULE);
	}
}
