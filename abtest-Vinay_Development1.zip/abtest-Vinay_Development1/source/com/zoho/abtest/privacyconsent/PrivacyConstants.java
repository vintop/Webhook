//$Id$
package com.zoho.abtest.privacyconsent;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.zoho.abtest.PRIVACY_CONSENT;
import com.zoho.abtest.PROJECT;
import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.project.ProjectConstants;
import com.zoho.abtest.user.ZABUserConstants;

public class PrivacyConstants {
	
	public static final String API_MODULE = "privacy"; //No I18N
	
	public static final String PRIVACY_CONSENTS_MODULE = "privacy"; //No I18N
	
	public static final String PRIVACY_VALUE  = "privacy_value"; //No I18N

	
	
	
	public final static List<Constants> PRIVACY_CONSENTS_TABLE;
	static{
		ArrayList<Constants> list = new ArrayList<Constants>();

		list.add(new Constants(ProjectConstants.PROJECT_ID,PRIVACY_CONSENT.PROJECT_ID,ZABConstants.LONG,Boolean.FALSE));
		list.add(new Constants(PRIVACY_VALUE,PRIVACY_CONSENT.PRIVACY_VALUE,ZABConstants.INTEGER,Boolean.TRUE));
		PRIVACY_CONSENTS_TABLE = (List<Constants>) Collections.unmodifiableList(list);
	}




}
