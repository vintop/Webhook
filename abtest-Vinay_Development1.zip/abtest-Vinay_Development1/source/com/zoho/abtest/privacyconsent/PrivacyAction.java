//$Id$
package com.zoho.abtest.privacyconsent;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.json.JSONException;

import com.opensymphony.xwork2.ActionSupport;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.project.ProjectConstants;

public class PrivacyAction extends ActionSupport implements ServletResponseAware, ServletRequestAware {
	
	private static final Logger LOGGER = Logger.getLogger(PrivacyAction.class.getName());

	private static final long serialVersionUID = 1L;
	
	private HttpServletRequest request;
	
	private HttpServletResponse response;
	
	private String linkname;
	
	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		// TODO Auto-generated method stub
		request = arg0;
	}

	@Override
	public void setServletResponse(HttpServletResponse arg0) {
		// TODO Auto-generated method stub
		response = arg0;
	}
	
	
	
	public String getLinkname() {
		return linkname;
	}

	public void setLinkname(String linkname) {
		this.linkname = linkname;
	}

	public String execute() throws IOException, JSONException {
		
		ArrayList<Privacy> privacy = new ArrayList<Privacy>();
		
		LOGGER.log(Level.INFO, "Privacy Action Starts"); //No I18N

		try {
			switch(ZABAction.getHTTPMethod(request)) {
			case POST:
				break;
			case GET: 
			{
				Long projectId = Project.getProjectId(linkname);//Long.parseLong(request.getParameter(ProjectConstants.PROJECT_ID));
				privacy.add(Privacy.getPrivacyDetails(projectId));
				break;
			}
			case PUT: 
			{
				HashMap<String,String> hs = ZABAction.getRequestParser(request).parsePrivacy(request);
				LOGGER.log(Level.INFO,hs.get(ProjectConstants.PROJECT_ID));
				Long projectId = Project.getProjectId(linkname);
				hs.put(ProjectConstants.PROJECT_ID, projectId.toString());
				privacy.add(Privacy.updatePrivacyDetails(hs));
				break;
			}
			case DELETE:
				break;
			default:
				break;
			}
		}  catch(Exception ex) {
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex); 

		}
		LOGGER.log(Level.INFO, "Privacy Action Ends"); //No I18N

		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getPrivacyResponse(request, privacy));	

		return null;
	}

}
