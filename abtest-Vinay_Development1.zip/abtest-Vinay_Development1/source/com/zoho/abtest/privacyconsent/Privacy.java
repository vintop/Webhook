//$Id$
package com.zoho.abtest.privacyconsent;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.PRIVACY_CONSENT;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.eventactivity.EventActivityConstants;
import com.zoho.abtest.eventactivity.EventActivityWrapper;
import com.zoho.abtest.listener.ZABNotifier;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.project.ProjectConstants;
import com.zoho.abtest.project.ProjectTreeEventConstants;
import com.zoho.abtest.project.ProjectTreeEventWrapper;
import com.zoho.abtest.project.ProjectTreeEventConstants.Module;
import com.zoho.abtest.project.ProjectTreeEventConstants.OperationType;
import com.zoho.abtest.utility.ZABUtil;

public class Privacy extends ZABModel implements Serializable{
	
	private static final Logger LOGGER = Logger.getLogger(Privacy.class.getName());
	
	private static final long serialVersionUID = 1L;
	
	private Long projectId;
	private Integer privacyValue;
	
	
	
	
	public Long getProjectId() {
		return projectId;
	}


	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}


	public Integer getPrivacyValue() {
		return privacyValue;
	}


	public void setPrivacyValue(Integer privacyValue) {
		this.privacyValue = privacyValue;
	}


	


	public static void createPrivacy(Long projectId) {
		try {
			HashMap<String,String> hs = new HashMap<String,String>();
			hs.put(ProjectConstants.PROJECT_ID, projectId.toString());
			createRow(PrivacyConstants.PRIVACY_CONSENTS_TABLE,PRIVACY_CONSENT.TABLE,hs);
			
			//Event Activity Log
			HashMap<String, String> updatedValues = new HashMap<String, String>();
			updatedValues.put(EventActivityConstants.PROJECT_ID, projectId.toString());
			updatedValues.put(EventActivityConstants.USER_ID, ZABUtil.getCurrentUser().getUserId().toString());
			updatedValues.put(EventActivityConstants.TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
			updatedValues.put(PrivacyConstants.PRIVACY_VALUE, 1+"");

			
			EventActivityWrapper activityWrapper = new EventActivityWrapper();
			activityWrapper.setModule(EventActivityConstants.Module.PROJECT);
			activityWrapper.setOperationType(com.zoho.abtest.eventactivity.EventActivityConstants.OperationType.CREATE);
			activityWrapper.setDbSpace(ZABUtil.getCurrentUserDbSpace());
			activityWrapper.setUpdatedValues(updatedValues);
			ZABNotifier.notifyListeners(EventActivityConstants.EVENT_MODULE_NAME, activityWrapper);
		} catch(Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}
	}
	
	public static Privacy getPrivacyDetails(Long projectId) {
		
		Privacy privacy = null;
		
		try{
			Criteria c = new Criteria(new Column(PRIVACY_CONSENT.TABLE,PRIVACY_CONSENT.PROJECT_ID),projectId,QueryConstants.EQUAL);
			DataObject dobj = getRow(PRIVACY_CONSENT.TABLE,c);
			Row row = dobj.getFirstRow(PRIVACY_CONSENT.TABLE);
			privacy = getRowFromDataObject(row);
			privacy.setSuccess(Boolean.TRUE);
		}catch(Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}
		return privacy;

	}


	public static Privacy getRowFromDataObject(Row row) {
		Privacy p = new Privacy();
		p.setProjectId((Long)row.get(PRIVACY_CONSENT.PROJECT_ID));
		p.setPrivacyValue((Integer)row.get(PRIVACY_CONSENT.PRIVACY_VALUE));
		return p;
	}


	public static Privacy updatePrivacyDetails(HashMap<String, String> hs) {
		Privacy privacy = new Privacy();
		try{
			
			Privacy p = new Privacy();
	
			Long projectId = Long.parseLong(hs.get(ProjectConstants.PROJECT_ID));

			p = getPrivacyDetails(projectId);
			
			
			Criteria c = new Criteria(new Column(PRIVACY_CONSENT.TABLE, PRIVACY_CONSENT.PROJECT_ID), projectId, QueryConstants.EQUAL);
			updateRow(PrivacyConstants.PRIVACY_CONSENTS_TABLE, PRIVACY_CONSENT.TABLE, hs, c, PrivacyConstants.API_MODULE);
			
			privacy.setSuccess(Boolean.TRUE);
			privacy.setProjectId(projectId);
			privacy.setPrivacyValue(Integer.parseInt(hs.get(PrivacyConstants.PRIVACY_VALUE)));
			
			
			
			HashMap<String,String> oldvalues = new HashMap<String,String>();
			oldvalues.put(PrivacyConstants.PRIVACY_VALUE, p.getPrivacyValue().toString());
			
			
			//Event Activity Log
			HashMap<String, String> updatedValues = new HashMap<String, String>();
			updatedValues.put(EventActivityConstants.PROJECT_ID, hs.get(ProjectConstants.PROJECT_ID));
			updatedValues.put(EventActivityConstants.USER_ID, ZABUtil.getCurrentUser().getUserId().toString());
			updatedValues.put(EventActivityConstants.TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
			updatedValues.put(PrivacyConstants.PRIVACY_VALUE, hs.get(PrivacyConstants.PRIVACY_VALUE));

			EventActivityWrapper activityWrapper = new EventActivityWrapper();
			activityWrapper.setModule(EventActivityConstants.Module.PROJECT);
			activityWrapper.setOperationType(com.zoho.abtest.eventactivity.EventActivityConstants.OperationType.UPDATE);
			activityWrapper.setDbSpace(ZABUtil.getCurrentUserDbSpace());
			activityWrapper.setUpdatedValues(updatedValues);
			activityWrapper.setOldValues(oldvalues);
			ZABNotifier.notifyListeners(EventActivityConstants.EVENT_MODULE_NAME, activityWrapper);

			ProjectTreeEventWrapper wrapper = new ProjectTreeEventWrapper();
			wrapper.setModel(privacy);
			wrapper.setModule(Module.PRIVACY_CONSENT);
			wrapper.setDbspace(ZABUtil.getCurrentUserDbSpace());
			wrapper.setType(OperationType.UPDATE);
			ZABNotifier.notifyListeners(ProjectTreeEventConstants.EVENT_MODULE_NAME, wrapper);
		} catch(Exception e) {
			privacy.setSuccess(Boolean.FALSE);
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}
		return privacy;
	}
	
	public static void migratePrivacyDetails() {
		ArrayList<Project> projects = new ArrayList<Project>();
		try{
			projects = Project.getAllProjectsForCurrentPortal();
			for(int i = 0; i < projects.size(); i++) {
				Project p = projects.get(i);
				HashMap<String,String> hs = new HashMap<String,String>();
				hs.put(ProjectConstants.PROJECT_ID, p.getProjectId().toString());
				try{
					createRow(PrivacyConstants.PRIVACY_CONSENTS_TABLE,PRIVACY_CONSENT.TABLE,hs);
				} catch(Exception e) {
					LOGGER.log(Level.INFO,p.getProjectId().toString());
					LOGGER.log(Level.SEVERE,e.getMessage(),e);
				}
			}
		}catch(Exception e) {
			LOGGER.log(Level.SEVERE,e.getMessage(),e);
		}
	}

}
