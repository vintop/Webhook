//$Id$
package com.zoho.abtest.privacyconsent;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;
import com.zoho.abtest.project.ProjectConstants;

public class PrivacyResponse {
	
	private static final Logger LOGGER = Logger.getLogger(PrivacyResponse.class.getName());

	public static String jsonResponse(HttpServletRequest request,ArrayList<Privacy> privacy) {
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(privacy);			
			JSONObject json = ZABResponse.updateMetaInfo(request, PrivacyConstants.API_MODULE, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE,ex.getMessage(),ex);
		}
		return returnBuffer.toString();
	}

	public static JSONArray getJSONArray(ArrayList<Privacy> privacy) {
		
		JSONArray array = new JSONArray();
		int size = privacy.size();
		for (int i = 0; i < size; i++) {
			Privacy ld = privacy.get(i);
			JSONObject jsonObj = new JSONObject();
			jsonObj = getPrivacyFromArray(ld);
			array.put(jsonObj);
		}
		return array;
	}

	public static JSONObject getPrivacyFromArray(Privacy ld) {
		
		JSONObject jsonObj = new JSONObject();
		try {
			jsonObj.put(ZABConstants.SUCCESS, ld.getSuccess());
			jsonObj.put(ZABConstants.RESPONSE_STRING, ld.getResponseString());
			LOGGER.log(Level.INFO, ">> Project ID in response:"+ld.getProjectId());
			
			if(ld.getProjectId() != null) {
				jsonObj.put(ProjectConstants.PROJECT_ID, ld.getProjectId().toString());
			}
			jsonObj.put(PrivacyConstants.PRIVACY_VALUE, ld.getPrivacyValue());
		} catch(Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}
		return jsonObj;
	}

}
