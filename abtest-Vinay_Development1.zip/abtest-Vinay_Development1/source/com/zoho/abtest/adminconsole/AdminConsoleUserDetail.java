//$Id$
package com.zoho.abtest.adminconsole;

import com.zoho.abtest.common.ZABModel;

public class AdminConsoleUserDetail extends ZABModel
{
	private static final long serialVersionUID = 1L;
	private Long zuid;
	private String emailId;
	private String domain;
	private Long zsoid;
	private Long startTime;
	private Boolean trackingHappenned;
	private Boolean licenseActive;
	private Long pausedTime;
	private Boolean limitWarned;
	private String licenseName;
	private Long visitorCount;
	private String fullName;
	
	public Long getZuid() {
		return zuid;
	}
	public void setZuid(Long zuid) {
		this.zuid = zuid;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public Long getZsoid() {
		return zsoid;
	}
	public void setZsoid(Long zsoid) {
		this.zsoid = zsoid;
	}
	public Long getStartTime() {
		return startTime;
	}
	public void setStartTime(Long startTime) {
		this.startTime = startTime;
	}
	public Boolean getTrackingHappenned() {
		return trackingHappenned;
	}
	public void setTrackingHappenned(Boolean trackingHappenned) {
		this.trackingHappenned = trackingHappenned;
	}
	public Boolean getLicenseActive() {
		return licenseActive;
	}
	public void setLicenseActive(Boolean licenseActive) {
		this.licenseActive = licenseActive;
	}
	public Long getPausedTime() {
		return pausedTime;
	}
	public void setPausedTime(Long pausedTime) {
		this.pausedTime = pausedTime;
	}
	public Boolean getLimitWarned() {
		return limitWarned;
	}
	public void setLimitWarned(Boolean limitWarned) {
		this.limitWarned = limitWarned;
	}
	public String getLicenseName() {
		return licenseName;
	}
	public void setLicenseName(String licenseName) {
		this.licenseName = licenseName;
	}
	public Long getVisitorCount() {
		return visitorCount;
	}
	public void setVisitorCount(Long visitorCount) {
		this.visitorCount = visitorCount;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
}
