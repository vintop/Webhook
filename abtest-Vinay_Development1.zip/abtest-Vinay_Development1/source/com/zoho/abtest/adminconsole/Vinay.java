//$Id$
package com.zoho.abtest.adminconsole;

public class Vinay {
	int a;
}
