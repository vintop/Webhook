//$Id$
package com.zoho.abtest.adminconsole;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.json.JSONException;

import com.opensymphony.xwork2.ActionSupport;
import com.zoho.abtest.auditlog.AdminConsoleAuditLog;
import com.zoho.abtest.auditlog.AuditLogConstants;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.eventactivity.EventActivityConstants;
import com.zoho.abtest.license.LicenseConstants;
import com.zoho.abtest.license.PortalLicenseMapping;
import com.zoho.abtest.user.ZABUser;
import com.zoho.abtest.utility.ZABSchedulerUtil;
import com.zoho.abtest.utility.ZABUtil;

public class AdminConsoleAction extends ActionSupport implements ServletResponseAware, ServletRequestAware
{
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(AdminConsoleAction.class.getName());
	private HttpServletRequest request;
	private HttpServletResponse response;
	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		request = arg0;
	}
	@Override
	public void setServletResponse(HttpServletResponse arg0) {
		response = arg0;
	}
	public void getDashBoardDetails() throws Exception 
	{
		try
		{
			ZABUtil.setCurrentRequest(request);
			ZABUtil.setDBCallCountMap(null);
			Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
			ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
			
			Long startTime = null;
			Long endTime = null;
			
			String startDate = request.getParameter("startdate");
			String endDate = request.getParameter("enddate");
			if(startDate != null && endDate != null)
			{
				startTime = ZABUtil.getTimeInLongFromDateFormStr(startDate, "yyyy-MM-dd");		// NO I18N
				endTime = ZABUtil.getTimeInLongFromDateFormStr(endDate, "yyyy-MM-dd");		// NO I18N
				endTime =  ZABUtil.getNthDayDateInLong(endTime, 1) - 1;
			}
			
			boolean isnonzohocorponly = false;
			String isnonzohocorpflagStr = request.getParameter("isnonzohocorp");
			if(isnonzohocorpflagStr != null)
			{
				isnonzohocorponly = Boolean.parseBoolean(isnonzohocorpflagStr);
			}
			
			AdminConsole acObj = AdminConsole.getAdminConsoleDashboardDetails(startTime, endTime, isnonzohocorponly);
			
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getAdminConsoleDashboardResponse(request, acObj));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), AdminConsoleConstants.API_MODULE_PLURAL));
		}
	}
	
	public void getPortalDetails()throws Exception
	{
		try {
			ZABUtil.setCurrentRequest(request);
			ZABUtil.setDBCallCountMap(null);
			Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
			ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
			
			String domain =  ZABUtil.getDomainFromPortalRequest(request,"/spacename/", 6);		// NO I18N
			
			AdminConsole acObj = AdminConsole.getProjects(domain);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getAdminConsolePortalDetails(request, acObj));
			
		}catch(Exception ex) {
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), AdminConsoleConstants.API_MODULE_PLURAL));
		}
	}
	
	public void getList() throws Exception{
		try{
			ZABUtil.setCurrentRequest(request);
			ZABUtil.setDBCallCountMap(null);
			String input=ZABAction.getInputString(request);
			LOGGER.log(Level.INFO, ">> Final1 Response:"+input);
			ZABUtil.setCurrentInputString(input);
			AdminConsole adObj=AdminConsole.getList();
			ZABAction.sendResponse(request, response, ZABAction.getResponseProvider(request).getSuggestedNameList(request,adObj));
						
		}	
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), AdminConsoleConstants.API_MODULE_PLURAL));
		}
	}
	
	public void regenerateScript() throws Exception{
		try{
			ZABUtil.setCurrentRequest(request);
			ZABUtil.setDBCallCountMap(null);
			String input=ZABAction.getInputString(request);
			LOGGER.log(Level.INFO, "Input Stream::"+input);
			ZABUtil.setCurrentInputString(input);
			AdminConsole adObj=AdminConsole.regenerateScript();
			ZABAction.sendResponse(request, response, ZABAction.getResponseProvider(request).getSuggestedNameList(request,adObj));
						
		}	
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), AdminConsoleConstants.API_MODULE_PLURAL));
		}
	}
	
	public void getPortals() throws Exception 
	{
		try
		{
			ZABUtil.setCurrentRequest(request);
			ZABUtil.setDBCallCountMap(null);
			String inputString = ZABAction.getInputString(request);
			LOGGER.log(Level.INFO,"ZUIDMan"+ inputString);
			ZABUtil.setCurrentInputString(inputString);
			Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
			ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
			AdminConsole acObj = AdminConsole.getPortals();
			
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getAdminConsolePortalList(request, acObj));
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), AdminConsoleConstants.API_MODULE_PLURAL));
		}
	}
	
	public String mapAcPortalNonZohoCorp()throws Exception
	{
		ZABUtil.setCurrentRequest(request);
		ZABUtil.setDBCallCountMap(null);
		Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
		ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
		try
		{
			ArrayList<PortalLicenseMapping> userLicenseMappingList = new ArrayList<PortalLicenseMapping>();
			
			AdminConsole.migrateACPortalZohoCorpFlag();
			
			PortalLicenseMapping userLicenseMappingObj = new PortalLicenseMapping();
			userLicenseMappingObj.setSuccess(true);
			userLicenseMappingList.add(userLicenseMappingObj);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getPortalLicenseMappingResponse(request, userLicenseMappingList));
		}
		catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), LicenseConstants.PORTAL_LICENSE_MAPPING_API_MODULE));
		}	
		return null;
	}
	
	public String markPortalAsZohoCorp()throws Exception
	{
		ZABUtil.setCurrentRequest(request);
		ZABUtil.setDBCallCountMap(null);
		Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
		ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
		try
		{
			ArrayList<PortalLicenseMapping> userLicenseMappingList = new ArrayList<PortalLicenseMapping>();
			
			String zsoidStr = request.getParameter("zsoid");
			if(zsoidStr != null)
			{
				Long zsoid = Long.parseLong(zsoidStr);
				AdminConsole.markPortalAsZohoCorp(zsoid);
			}
			
			PortalLicenseMapping userLicenseMappingObj = new PortalLicenseMapping();
			userLicenseMappingObj.setSuccess(true);
			userLicenseMappingList.add(userLicenseMappingObj);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getPortalLicenseMappingResponse(request, userLicenseMappingList));
		}
		catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), LicenseConstants.PORTAL_LICENSE_MAPPING_API_MODULE));
		}	
		return null;
	}
	
	public String updateRepetitiveJob()throws Exception
	{
		ZABUtil.setCurrentRequest(request);
		ZABUtil.setDBCallCountMap(null);
		Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
		ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
		try
		{
			String repetitionName = request.getParameter("repetitionName");
			Integer operationType = Integer.parseInt(request.getParameter("operationType"));
			if(repetitionName != null)
			{
				ZABSchedulerUtil.updateRepetitiveJob(repetitionName, operationType);
			}
			
			ArrayList<PortalLicenseMapping> userLicenseMappingList = new ArrayList<PortalLicenseMapping>();
			PortalLicenseMapping userLicenseMappingObj = new PortalLicenseMapping();
			userLicenseMappingObj.setSuccess(true);
			userLicenseMappingList.add(userLicenseMappingObj);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getPortalLicenseMappingResponse(request, userLicenseMappingList));
		}
		catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), LicenseConstants.PORTAL_LICENSE_MAPPING_API_MODULE));
		}	
		return null;
	}
	
	public String pushMissedPortalsToACPortal()throws Exception
	{
		ZABUtil.setCurrentRequest(request);
		ZABUtil.setDBCallCountMap(null);
		Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
		ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
		try
		{
			AdminConsole.pushMissedPortalsToACPortal();
			
			ArrayList<PortalLicenseMapping> userLicenseMappingList = new ArrayList<PortalLicenseMapping>();
			PortalLicenseMapping userLicenseMappingObj = new PortalLicenseMapping();
			userLicenseMappingObj.setSuccess(true);
			userLicenseMappingList.add(userLicenseMappingObj);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getPortalLicenseMappingResponse(request, userLicenseMappingList));
		}
		catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), LicenseConstants.PORTAL_LICENSE_MAPPING_API_MODULE));
		}	
		return null;
	}
	
	public String deleteVisitorDetailEntry()throws Exception
	{
		ZABUtil.setCurrentRequest(request);
		ZABUtil.setDBCallCountMap(null);
		Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
		ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
		try
		{
			Long dbspaceId = Long.parseLong(request.getParameter("zsoid"));
			ZABUtil.setDBSpace(dbspaceId.toString());
			Long startId = Long.parseLong(request.getParameter("startId"));
			Long endId = Long.parseLong(request.getParameter("endId"));
			AdminConsole.deleteVisitorDetailEntry(startId, endId);
			ArrayList<PortalLicenseMapping> userLicenseMappingList = new ArrayList<PortalLicenseMapping>();
			PortalLicenseMapping userLicenseMappingObj = new PortalLicenseMapping();
			userLicenseMappingObj.setSuccess(true);
			userLicenseMappingList.add(userLicenseMappingObj);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getPortalLicenseMappingResponse(request, userLicenseMappingList));
		}
		catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), LicenseConstants.PORTAL_LICENSE_MAPPING_API_MODULE));
		}	
		return null;
	}
	
	public String syncCRMPotentials()throws Exception
	{
		ZABUtil.setCurrentRequest(request);
		ZABUtil.setDBCallCountMap(null);
		Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
		ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
		try
		{
			String fromDateStr = request.getParameter("fromdate");
			if(fromDateStr != null)
			{
				Long fromTime = ZABUtil.getTimeInLongFromDateFormStr(fromDateStr, "yyyy-MM-dd");		// NO I18N
				AdminConsole.syncCRMPotentials(fromTime);
			}
			
			ArrayList<PortalLicenseMapping> userLicenseMappingList = new ArrayList<PortalLicenseMapping>();
			PortalLicenseMapping userLicenseMappingObj = new PortalLicenseMapping();
			userLicenseMappingObj.setSuccess(true);
			userLicenseMappingList.add(userLicenseMappingObj);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getPortalLicenseMappingResponse(request, userLicenseMappingList));
		}
		catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), LicenseConstants.PORTAL_LICENSE_MAPPING_API_MODULE));
		}	
		return null;
	}
	
	public String pushZsoidToExistingCrmPotentials()throws Exception
	{
		ZABUtil.setCurrentRequest(request);
		ZABUtil.setDBCallCountMap(null);
		Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
		ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
		try
		{
			AdminConsole.pushZsoidToExistingCrmPotentials();
			
			ArrayList<PortalLicenseMapping> userLicenseMappingList = new ArrayList<PortalLicenseMapping>();
			PortalLicenseMapping userLicenseMappingObj = new PortalLicenseMapping();
			userLicenseMappingObj.setSuccess(true);
			userLicenseMappingList.add(userLicenseMappingObj);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getPortalLicenseMappingResponse(request, userLicenseMappingList));
		}
		catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), LicenseConstants.PORTAL_LICENSE_MAPPING_API_MODULE));
		}	
		return null;
	}
	
	public String getUsersLicenseAndUsageDetails()throws Exception
	{
		ZABUtil.setCurrentRequest(request);
		ZABUtil.setDBCallCountMap(null);
		Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
		ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
		ArrayList<AdminConsoleUserDetail> responseList = new ArrayList<AdminConsoleUserDetail>();
		try
		{
			HashMap<String, String> hs = new HashMap<String, String>(); 
			hs.put("signedUpAfter", request.getParameter("signedUpAfter"));
			hs.put("signedUpBefore", request.getParameter("signedUpBefore"));
			hs.put("expired_date", request.getParameter("expired_date"));
			hs.put("exclude_zohoone", request.getParameter("exclude_zohoone"));
			hs.put("license_active", request.getParameter("license_active"));
			hs.put("tracking_happenned", request.getParameter("tracking_happenned"));
			hs.put("visitor_limit_warned", request.getParameter("visitor_limit_warned"));
			hs.put("minimum_visitor_count", request.getParameter("minimum_visitor_count"));
			hs.put("zsoid", request.getParameter("zsoid"));
			
			if(request.getParameter("zsoid") == null && (request.getParameter("signedUpAfter") == null || request.getParameter("signedUpBefore") == null))
			{
				ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString("If you are not providing ZSOID, then both SignedUpAfter and SignedUpBefore dates are mandatory!", AdminConsoleConstants.API_MODULE_PLURAL));  // No I18N
				return null;
			}
			
			responseList.addAll(AdminConsole.getUserLicenseDetails(hs));
			
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getACUserDetailsResponse(request, responseList));
		}
		catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ex.getMessage(), AdminConsoleConstants.API_MODULE_PLURAL));
		}	
		return null;
	} 
	
	public String getTrialExpiredUsers()throws Exception
	{
		ZABUtil.setCurrentRequest(request);
		ZABUtil.setDBCallCountMap(null);
		Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
		ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
		try
		{
			Long pausedafterTime = null;
			String pausedafterdateStr = request.getParameter("expiredafter");
			if(pausedafterdateStr != null)
			{
				pausedafterTime = ZABUtil.getTimeInLongFromDateFormStr(pausedafterdateStr, "yyyy-MM-dd");		// NO I18N
			}
			ArrayList<ZABUser> zabUserList = AdminConsole.getTrialExpiredDetails(pausedafterTime);
			
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getUserResponse(request, zabUserList));
		}
		catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), LicenseConstants.PORTAL_LICENSE_MAPPING_API_MODULE));
		}	
		return null;
	} 
	public String getAdminConsoleAuditLog() throws IOException, JSONException {
		ZABUtil.setCurrentRequest(request);
		ZABUtil.setDBCallCountMap(null);
		Long reqstartTime = ZABUtil.getCurrentTimeInMilliSeconds();
		ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", reqstartTime);
		List<AdminConsoleAuditLog> auditLogList = new ArrayList<AdminConsoleAuditLog>();
		try
		{
			Long startDate = null;
			Long endDate = null;
			String startDateStr = request.getParameter(EventActivityConstants.START_DATE);
			if(StringUtils.isNotEmpty(startDateStr))
			{
				startDate = ZABUtil.getTimeInLongFromDateFormStr(startDateStr, "yyyy-MM-dd");		// NO I18N
			}
			String endDateStr = request.getParameter(EventActivityConstants.END_DATE);
			if(StringUtils.isNotEmpty(endDateStr))
			{
				endDate = ZABUtil.getTimeInLongFromDateFormStr(endDateStr, "yyyy-MM-dd");		// NO I18N
				//Get the time for 11:59:59 PM for that day
				endDate = ZABUtil.getNthDayDateInLong( endDate, 1) - 1;
			}
			auditLogList = AdminConsoleAuditLog.getAdminConsoleAuditLog(startDate, endDate);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getExceptionString(ZABAction.getMessage(ZABConstants.RESOURCE_PROCESSING_FAILURE), AuditLogConstants.API_MODULE));
			return null; 	
		}	
		ZABAction.sendResponse(request,response,ZABAction.getResponseProvider(request).getAdminConsoleAuditLogResponse(request, auditLogList));		
	    return null;
	}
}
