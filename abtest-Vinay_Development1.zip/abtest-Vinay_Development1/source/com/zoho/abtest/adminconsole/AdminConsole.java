//$Id$
package com.zoho.abtest.adminconsole;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.lucene.search.join.ScoreMode;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.aggregations.metrics.cardinality.CardinalityAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.cardinality.InternalCardinality;
import org.json.JSONArray;
import org.json.JSONObject;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.DataSet;
import com.adventnet.ds.query.DeleteQuery;
import com.adventnet.ds.query.DeleteQueryImpl;
import com.adventnet.ds.query.DerivedColumn;
import com.adventnet.ds.query.GroupByClause;
import com.adventnet.ds.query.GroupByColumn;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.ds.query.SelectQueryImpl;
import com.adventnet.ds.query.SortColumn;
import com.adventnet.ds.query.Table;
import com.adventnet.iam.IAMProxy;
import com.adventnet.iam.IAMUtil;
import com.adventnet.iam.ServiceOrg;
import com.adventnet.iam.User;
import com.adventnet.iam.UserEmail;
import com.adventnet.mfw.bean.BeanUtil;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.ABSPLITEXPERIMENT;
import com.zoho.abtest.AC_EXPERIMENT;
import com.zoho.abtest.AC_GOAL;
import com.zoho.abtest.AC_PORTAL;
import com.zoho.abtest.AC_PROJECT;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.FORM_DETAILS;
import com.zoho.abtest.FUNNEL_STEPS;
import com.zoho.abtest.HEATMAP_EXPERIMENT;
import com.zoho.abtest.LICENSE_DETAIL;
import com.zoho.abtest.PORTAL_LICENSE_MAPPING;
import com.zoho.abtest.SESSION_RECORDING_EXPERIMENT;
import com.zoho.abtest.VISITOR_DETAIL;
import com.zoho.abtest.auditlog.AdminConsoleAuditLog;
import com.zoho.abtest.auditlog.AuditLogConstants;
import com.zoho.abtest.auditlog.AuditLogConstants.AuditLogEntityType;
import com.zoho.abtest.auditlog.AuditLogConstants.AuditLogType;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.elastic.ElasticSearchStatistics;
import com.zoho.abtest.elastic.ElasticSearchUtil;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentStatus;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentType;
import com.zoho.abtest.filter.PageSenseOrgFilter;
import com.zoho.abtest.forms.ElasticFormReport;
import com.zoho.abtest.forms.FormReportConstants;
import com.zoho.abtest.funnel.FunnelAnalysisConstants;
import com.zoho.abtest.funnel.FunnelStep;
import com.zoho.abtest.funnel.FunnelStepResponse;
import com.zoho.abtest.goal.GoalConstants.GoalType;
import com.zoho.abtest.experiment.ExperimentResponse;
import com.zoho.abtest.license.LicenseConstants.License;
import com.zoho.abtest.license.LicenseDetail;
import com.zoho.abtest.license.PortalLicenseAddon;
import com.zoho.abtest.license.PortalLicenseMapping;
import com.zoho.abtest.portal.Portal;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.report.ElasticSearchConstants;
import com.zoho.abtest.sessionrecording.SessionElasticBand;
import com.zoho.abtest.user.ZABUser;
import com.zoho.abtest.utility.DataSetWrapper;
import com.zoho.abtest.utility.ZABIAMUtil;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUserBean;
import com.zoho.abtest.utility.ZABUtil;

public class AdminConsole extends ZABModel
{
	private static final Logger LOGGER = Logger.getLogger(AdminConsole.class.getName());
	
	private Integer totalPortalCount;
	private Integer activePortalCount;
	private Integer totalAccountCount;
	private Integer inactivePortalCount;
	private Integer totalProjectCount;
	private Integer activeProjectCount;
	private Integer inactiveProjectCount;
	private Integer totalExpCount;
	private Long totalVisitorsCount;
	private boolean userDetails = false;
	private JSONObject portalLicenseDetails = new JSONObject();
	private JSONObject projectExperimentList = new JSONObject();
	private JSONObject userList=new JSONObject();
	private List<Portal> portalList;
	private ArrayList<Project> projectList;
	private HashMap<Integer,Integer> goalsList;
	private Integer totalGoalsCount;
	
	
	public Integer getTotalGoalsCount() {
		return totalGoalsCount;
	}

	public void setTotalGoalsCount(Integer totalGoalsCount) {
		this.totalGoalsCount = totalGoalsCount;
	}

	public HashMap<Integer, Integer> getGoalsList() {
		return goalsList;
	}

	public void setGoalsList(HashMap<Integer, Integer> goalsList) {
		this.goalsList = goalsList;
	}

	private HashMap<Integer, HashMap<Boolean, HashMap<Integer, Integer>>> expCountHs;
	
	public JSONObject getPortalLicenseDetails(String zsoid) throws Exception{
		return portalLicenseDetails.getJSONObject(zsoid);
	}
	
	private JSONObject setPortalLicenseDetails(String zsoid, JSONObject obj) throws Exception{
		return portalLicenseDetails.put(zsoid, obj);
	}
	
	public JSONObject setProjectExperimentList(String projectid, JSONArray obj) throws Exception{
		return projectExperimentList.put(projectid, obj);
	}
	
	public JSONArray getProjectExperimentList(String projectid) throws Exception{
		return projectExperimentList.getJSONArray(projectid);
	}
	
	public void setPortalList(List<Portal> portals) {
		portalList = portals;
	}
	
	public List<Portal> getPortalList(){
		return this.portalList;
	}
	
	public void setProjectList(ArrayList<Project> project) {
		projectList = project;
	}
	
	public ArrayList<Project> getProjectList(){
		return this.projectList;
	}
	
	public boolean getUserDetails(){
		return userDetails;
	}
	
	public void setUserDetails(boolean user) {
		this.userDetails = user;
	}
	
	public Long getTotalVisitorsCount() {
		return totalVisitorsCount;
	}
	public void setTotalVisitorsCount(Long totalVisitorsCount) {
		this.totalVisitorsCount = totalVisitorsCount;
	}
	
	public HashMap<Integer, HashMap<Boolean, HashMap<Integer, Integer>>> getExpCountHs() {
		return expCountHs;
	}
	public void setExpCountHs(
			HashMap<Integer, HashMap<Boolean, HashMap<Integer, Integer>>> expCountHs) {
		this.expCountHs = expCountHs;
	}
	public Integer getTotalPortalCount() {
		return totalPortalCount;
	}
	public void setTotalPortalCount(Integer totalPortalCount) {
		this.totalPortalCount = totalPortalCount;
	}
	public Integer getActivePortalCount() {
		return activePortalCount;
	}
	public void setActivePortalCount(Integer activePortalCount) {
		this.activePortalCount = activePortalCount;
	}
	public Integer getTotalAccountCount() {
		return totalAccountCount;
	}
	public void setTotalAccountCount(Integer totalAccountCount) {
		this.totalAccountCount = totalAccountCount;
	}
	public Integer getInactivePortalCount() {
		return inactivePortalCount;
	}
	public void setInactivePortalCount(Integer inactivePortalCount) {
		this.inactivePortalCount = inactivePortalCount;
	}
	public Integer getTotalProjectCount() {
		return totalProjectCount;
	}
	public void setTotalProjectCount(Integer totalProjectCount) {
		this.totalProjectCount = totalProjectCount;
	}
	public Integer getActiveProjectCount() {
		return activeProjectCount;
	}
	public void setActiveProjectCount(Integer activeProjectCount) {
		this.activeProjectCount = activeProjectCount;
	}
	public Integer getInactiveProjectCount() {
		return inactiveProjectCount;
	}
	public void setInactiveProjectCount(Integer inactiveProjectCount) {
		this.inactiveProjectCount = inactiveProjectCount;
	}
	public Integer getTotalExpCount() {
		return totalExpCount;
	}
	public void setTotalExpCount(Integer totalExpCount) {
		this.totalExpCount = totalExpCount;
	}
	public static void createAcPortal(HashMap<String, String> hs) 
	{
		try
		{
			String existingDBSpace = ZABUtil.getDBSpace();
			ZABUtil.setDBSpace("sharedspace");	//No I18N
			
			ZABModel.createRow(AdminConsoleConstants.AC_PORTAL_CONSTANTS, AC_PORTAL.TABLE, hs);
			
			ZABUtil.setDBSpace(existingDBSpace);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
	public static void deleteAcPortal(HashMap<String, String> hs) 
	{
		try
		{
			String existingDBSpace = ZABUtil.getDBSpace();
			ZABUtil.setDBSpace("sharedspace");	//No I18N
			
			Long zsoid = Long.parseLong(hs.get(AdminConsoleConstants.ZSOID));
			Criteria criteria1 = new Criteria(new Column(AC_PORTAL.TABLE, AC_PORTAL.ZSOID), zsoid, QueryConstants.EQUAL);
			ZABModel.deleteRow(AC_PORTAL.TABLE, criteria1, null);
			
			ZABUtil.setDBSpace(existingDBSpace);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
	public static Long getAcPortalId(Long zsoid) 
	{
		Long acPortalId = null;
		try
		{
			String existingDBSpace = ZABUtil.getDBSpace();
			ZABUtil.setDBSpace("sharedspace");	//No I18N
			
			Criteria criteria = new Criteria(new Column(AC_PORTAL.TABLE, AC_PORTAL.ZSOID), zsoid, QueryConstants.EQUAL);
			Row row = ZABModel.getFirstRow(AC_PORTAL.TABLE, criteria);
			acPortalId = (Long)row.get(AC_PORTAL.AC_PORTAL_ID);
			
			ZABUtil.setDBSpace(existingDBSpace);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		return acPortalId;
	}
	public static String getPortalDomain(Long zsoid)
	{
		String portalDomain = null;
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		try
		{
			Criteria criteria = new Criteria(new Column(AC_PORTAL.TABLE, AC_PORTAL.ZSOID), zsoid, QueryConstants.EQUAL);
			Row row = ZABModel.getFirstRow(AC_PORTAL.TABLE, criteria);
			portalDomain = (String)row.get(AC_PORTAL.PORTAL_DOMAIN);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		ZABUtil.setDBSpace(existingDBSpace);
		return portalDomain;
	}
	public static Long getPortalCreatedUser(Long zsoid)
	{
		Long zuid = null;
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		try
		{
			Criteria criteria = new Criteria(new Column(AC_PORTAL.TABLE, AC_PORTAL.ZSOID), zsoid, QueryConstants.EQUAL);
			Row row = ZABModel.getFirstRow(AC_PORTAL.TABLE, criteria);
			zuid = (Long)row.get(AC_PORTAL.CREATED_ZUID);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		ZABUtil.setDBSpace(existingDBSpace);
		return zuid;
	}
	public static List<String> getUserPortals(Long zuid)
	{
		List<String> portalList = new ArrayList<String>();
		try
		{
			Criteria criteria = new Criteria(new Column(AC_PORTAL.TABLE, AC_PORTAL.CREATED_ZUID), zuid, QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(AC_PORTAL.TABLE, criteria);
			Iterator<?> iterator = dataObj.getRows(AC_PORTAL.TABLE);
			while(iterator.hasNext())
			{
				Row row = (Row)iterator.next();
				String portalDomain = (String)row.get(AC_PORTAL.PORTAL_DOMAIN);
				portalList.add(portalDomain);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			portalList = new ArrayList<String>();
		}
		return portalList;
	}
	public static int getUserCreatedPortalCount(Long zuid)
	{
		int userPortalCount = 0;
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		try
		{
			Criteria criteria = new Criteria(new Column(AC_PORTAL.TABLE, AC_PORTAL.CREATED_ZUID), zuid, QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(AC_PORTAL.TABLE, criteria);
			if(!dataObj.isEmpty())
			{
				userPortalCount = dataObj.size(AC_PORTAL.TABLE);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		ZABUtil.setDBSpace(existingDBSpace);
		return userPortalCount;
	}
	public static void createAcProject(HashMap<String, String> hs) 
	{
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		try
		{
			Long zsoid = Long.parseLong(hs.get(AdminConsoleConstants.ZSOID));
			Long acPortalId = getAcPortalId(zsoid);
			hs.put(AdminConsoleConstants.AC_PORTAL_ID, acPortalId.toString());
			ZABModel.createRow(AdminConsoleConstants.AC_PROJECT_CONSTANTS, AC_PROJECT.TABLE, hs);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		ZABUtil.setDBSpace(existingDBSpace);
	}
	public static void updateAcProject(HashMap<String, String> hs) 
	{
		try
		{
			String existingDBSpace = ZABUtil.getDBSpace();
			ZABUtil.setDBSpace("sharedspace");	//No I18N
			
			Long zsoid = Long.parseLong(hs.get(AdminConsoleConstants.ZSOID));
			Long projectId = Long.parseLong(hs.get(AdminConsoleConstants.PROJECT_ID));
			
			Criteria criteria1 =new Criteria(new Column(AC_PROJECT.TABLE, AC_PROJECT.ZSOID), zsoid, QueryConstants.EQUAL);
			Criteria criteria2 =new Criteria(new Column(AC_PROJECT.TABLE, AC_PROJECT.PROJECT_ID), projectId, QueryConstants.EQUAL);
			ZABModel.updateRow(AdminConsoleConstants.AC_PROJECT_CONSTANTS, AC_PROJECT.TABLE, hs, criteria1.and(criteria2), null);
			
			ZABUtil.setDBSpace(existingDBSpace);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
	public static void deleteAcProject(HashMap<String, String> hs) 
	{
		try
		{
			String existingDBSpace = ZABUtil.getDBSpace();
			ZABUtil.setDBSpace("sharedspace");	//No I18N
			
			Long zsoid = Long.parseLong(hs.get(AdminConsoleConstants.ZSOID));
			Long projectId = Long.parseLong(hs.get(AdminConsoleConstants.PROJECT_ID));
			
			Criteria criteria1 =new Criteria(new Column(AC_PROJECT.TABLE, AC_PROJECT.ZSOID), zsoid, QueryConstants.EQUAL);
			Criteria criteria2 =new Criteria(new Column(AC_PROJECT.TABLE, AC_PROJECT.PROJECT_ID), projectId, QueryConstants.EQUAL);
			ZABModel.deleteRow(AC_PROJECT.TABLE, criteria1.and(criteria2), null);
			
			ZABUtil.setDBSpace(existingDBSpace);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
	public static Long getAcProjectId(Long projectId, Long zsoid) 
	{
		Long acProjectId = null;
		try
		{
			String existingDBSpace = ZABUtil.getDBSpace();
			ZABUtil.setDBSpace("sharedspace");	//No I18N
			
			Criteria criteria1 = new Criteria(new Column(AC_PROJECT.TABLE, AC_PROJECT.ZSOID), zsoid, QueryConstants.EQUAL);
			Criteria criteria2 = new Criteria(new Column(AC_PROJECT.TABLE, AC_PROJECT.PROJECT_ID), projectId, QueryConstants.EQUAL);
			Row row = ZABModel.getFirstRow(AC_PROJECT.TABLE, criteria1.and(criteria2));
			acProjectId = (Long)row.get(AC_PROJECT.AC_PROJECT_ID);
			
			ZABUtil.setDBSpace(existingDBSpace);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		return acProjectId;
	}
	public static void createAcExperiment(HashMap<String, String> hs) 
	{
		try
		{
			String existingDBSpace = ZABUtil.getDBSpace();
			ZABUtil.setDBSpace("sharedspace");	//No I18N
			
			Long zsoid = Long.parseLong(hs.get(AdminConsoleConstants.ZSOID));
			Long projectId = Long.parseLong(hs.get(AdminConsoleConstants.PROJECT_ID));
			Long acProjectId = getAcProjectId(projectId, zsoid);
			hs.put(AdminConsoleConstants.AC_PROJECT_ID, acProjectId.toString());
			ZABModel.createRow(AdminConsoleConstants.AC_EXPERIMENT_CONSTANTS, AC_EXPERIMENT.TABLE, hs);
			
			ZABUtil.setDBSpace(existingDBSpace);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
	
	public static void createAcGoal(HashMap<String, String> hs) 
	{
		try
		{
			String existingDBSpace = ZABUtil.getDBSpace();
			ZABUtil.setDBSpace("sharedspace");	//No I18N
			
			Long zsoid = Long.parseLong(hs.get(AdminConsoleConstants.ZSOID));
			Long projectId = Long.parseLong(hs.get(AdminConsoleConstants.PROJECT_ID));
			Long acProjectId = getAcProjectId(projectId, zsoid);
			hs.put(AdminConsoleConstants.AC_PROJECT_ID, acProjectId.toString());
			ZABModel.createRow(AdminConsoleConstants.AC_GOAL_CONSTANTS, AC_GOAL.TABLE, hs);
			
			ZABUtil.setDBSpace(existingDBSpace);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
	
	public static void updateAcGoal(HashMap<String, String> hs) 
	{
		try
		{
			String existingDBSpace = ZABUtil.getDBSpace();
			ZABUtil.setDBSpace("sharedspace");	//No I18N
			
			Long zsoid = Long.parseLong(hs.get(AdminConsoleConstants.ZSOID));
			Long goalId = Long.parseLong(hs.get(AdminConsoleConstants.GOAL_ID));
			
			Criteria criteria1 =new Criteria(new Column(AC_GOAL.TABLE, AC_GOAL.ZSOID), zsoid, QueryConstants.EQUAL);
			Criteria criteria2 =new Criteria(new Column(AC_GOAL.TABLE, AC_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
			ZABModel.updateRow(AdminConsoleConstants.AC_GOAL_CONSTANTS, AC_GOAL.TABLE, hs, criteria1.and(criteria2), null);
			
			ZABUtil.setDBSpace(existingDBSpace);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
	
	public static void updateAcExperiment(HashMap<String, String> hs) 
	{
		try
		{
			String existingDBSpace = ZABUtil.getDBSpace();
			ZABUtil.setDBSpace("sharedspace");	//No I18N
			
			Long zsoid = Long.parseLong(hs.get(AdminConsoleConstants.ZSOID));
			Long expId = Long.parseLong(hs.get(AdminConsoleConstants.EXPERIMENT_ID));
			
			Criteria criteria1 =new Criteria(new Column(AC_EXPERIMENT.TABLE, AC_EXPERIMENT.ZSOID), zsoid, QueryConstants.EQUAL);
			Criteria criteria2 =new Criteria(new Column(AC_EXPERIMENT.TABLE, AC_EXPERIMENT.EXPERIMENT_ID), expId, QueryConstants.EQUAL);
			ZABModel.updateRow(AdminConsoleConstants.AC_EXPERIMENT_CONSTANTS, AC_EXPERIMENT.TABLE, hs, criteria1.and(criteria2), null);
			
			ZABUtil.setDBSpace(existingDBSpace);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
	public static void deleteAcExperiment(HashMap<String, String> hs) 
	{
		try
		{
			String existingDBSpace = ZABUtil.getDBSpace();
			ZABUtil.setDBSpace("sharedspace");	//No I18N
			
			Long zsoid = Long.parseLong(hs.get(AdminConsoleConstants.ZSOID));
			Long expId = Long.parseLong(hs.get(AdminConsoleConstants.EXPERIMENT_ID));
			
			Criteria criteria1 =new Criteria(new Column(AC_EXPERIMENT.TABLE, AC_EXPERIMENT.ZSOID), zsoid, QueryConstants.EQUAL);
			Criteria criteria2 =new Criteria(new Column(AC_EXPERIMENT.TABLE, AC_EXPERIMENT.EXPERIMENT_ID), expId, QueryConstants.EQUAL);
			ZABModel.deleteRow(AC_EXPERIMENT.TABLE, criteria1.and(criteria2), null);
			
			ZABUtil.setDBSpace(existingDBSpace);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
	
	public static void deleteAcGoal(HashMap<String, String> hs) 
	{
		try
		{
			String existingDBSpace = ZABUtil.getDBSpace();
			ZABUtil.setDBSpace("sharedspace");	//No I18N
			
			Long zsoid = Long.parseLong(hs.get(AdminConsoleConstants.ZSOID));
			Long goalId = Long.parseLong(hs.get(AdminConsoleConstants.GOAL_ID));
			
			Criteria criteria1 =new Criteria(new Column(AC_GOAL.TABLE, AC_GOAL.ZSOID), zsoid, QueryConstants.EQUAL);
			Criteria criteria2 =new Criteria(new Column(AC_GOAL.TABLE, AC_GOAL.GOAL_ID), goalId, QueryConstants.EQUAL);
			ZABModel.deleteRow(AC_GOAL.TABLE, criteria1.and(criteria2), null);
			
			ZABUtil.setDBSpace(existingDBSpace);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
	
	public static AdminConsole getProjects(String domain) throws Exception{
		
		AdminConsole acObj = new AdminConsole();
		Long zsoid = ZABServiceOrgUtil.getZSOIDFromDomain(domain);
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace(zsoid+"");
		ZABUtil.setPortaldomain(domain);
		ArrayList<Project> projectList = Project.getProjects();
		acObj.setProjectList(projectList);
		projectList.forEach(project->{
			Long projectId = project.getProjectId();
			try {
				Criteria c1 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.PROJECT_ID), projectId, QueryConstants.EQUAL);
				Criteria c2 = new Criteria(new Column(EXPERIMENT.TABLE, EXPERIMENT.EXPERIMENT_TYPE), 100, QueryConstants.NOT_EQUAL);
				Criteria c = c1.and(c2);
				DataObject dataObj = getPersonality(ExperimentConstants.EXPERIMENT_DETAIL_PERSONALITY, c);
				Iterator<?> iterator = dataObj.getRows(EXPERIMENT.TABLE);
				JSONArray experimentArray = new JSONArray();
				while(iterator.hasNext())
				{
					Experiment experiment = null;
					Row expRow =  (Row)iterator.next();
					Experiment exp = Experiment.getExperimentFromRow(expRow);
					JSONObject experimentResponse = ExperimentResponse.getSingleExperimentResponse(exp);
					Integer expTypeNo =  (Integer)expRow.get(EXPERIMENT.EXPERIMENT_TYPE);
					Long experimentId = (Long)expRow.get(EXPERIMENT.EXPERIMENT_ID);
					ExperimentType expType = ExperimentType.getExperimentTypeByNumber(expTypeNo);
					String experimentUrl = null;
					JSONArray includesUrl = null;
					JSONArray excludestUrl = null;
					switch(expType)
					{
					case ABTEST:
					case SPLITURL:
						Criteria criteria2 = new Criteria(new Column(ABSPLITEXPERIMENT.TABLE, ABSPLITEXPERIMENT.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
						Row abtestRow = dataObj.getRow(ABSPLITEXPERIMENT.TABLE, criteria2);
						experimentUrl = (String)abtestRow.get(ABSPLITEXPERIMENT.EXPERIMENT_URL);
						includesUrl = ExperimentResponse.getObjectFromString((String)abtestRow.get(ABSPLITEXPERIMENT.INCLUDE_URLS));
						excludestUrl = ExperimentResponse.getObjectFromString((String)abtestRow.get(ABSPLITEXPERIMENT.EXCLUDE_URLS));
						break;
					case HEATMAP:
						Criteria criteria3 = new Criteria(new Column(HEATMAP_EXPERIMENT.TABLE, HEATMAP_EXPERIMENT.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
						Row hmRow = dataObj.getRow(HEATMAP_EXPERIMENT.TABLE, criteria3);

						experimentUrl = (String)hmRow.get(HEATMAP_EXPERIMENT.EXPERIMENT_URL);
						includesUrl = ExperimentResponse.getObjectFromString((String)hmRow.get(HEATMAP_EXPERIMENT.INCLUDE_URLS));
						excludestUrl = ExperimentResponse.getObjectFromString((String)hmRow.get(HEATMAP_EXPERIMENT.EXCLUDE_URLS));
						break;
					case FUNNEL:
						Criteria criteria4 = new Criteria(new Column(FUNNEL_STEPS.TABLE, FUNNEL_STEPS.EXPERIMENT_ID), experimentId, QueryConstants.EQUAL);
						SortColumn sort = new SortColumn(new Column(FUNNEL_STEPS.TABLE, FUNNEL_STEPS.STEP_ORDER), Boolean.TRUE);
						ArrayList<FunnelStep> funnelSteps = FunnelStep.getFunnelByCriteria(criteria4, sort);
						experimentResponse.put(FunnelAnalysisConstants.STEPS, FunnelStepResponse.getJSONArray(funnelSteps));
						break;
					case FORMANALYTICS:
						Criteria criteria5 = new Criteria(new Column(FORM_DETAILS.TABLE,FORM_DETAILS.EXPERIMENT_ID),experimentId,QueryConstants.EQUAL);
						Row formRow = dataObj.getRow(FORM_DETAILS.TABLE, criteria5);
						experimentUrl = (String)formRow.get(FORM_DETAILS.EXPERIMENT_URL);
						break;
					case SESSION_RECORDING:
						Criteria criteria6 = new Criteria(new Column(SESSION_RECORDING_EXPERIMENT.TABLE,SESSION_RECORDING_EXPERIMENT.EXPERIMENT_ID),experimentId,QueryConstants.EQUAL);
						Row SessionRow = dataObj.getRow(SESSION_RECORDING_EXPERIMENT.TABLE, criteria6);
						includesUrl = ExperimentResponse.getObjectFromString((String)SessionRow.get(SESSION_RECORDING_EXPERIMENT.INCLUDE_URLS));
						excludestUrl = ExperimentResponse.getObjectFromString((String)SessionRow.get(SESSION_RECORDING_EXPERIMENT.EXCLUDE_URLS));
						//experimentUrl = "";
						break;
						
					}
					experimentResponse.put(ExperimentConstants.EXPERIMENT_URL, experimentUrl);
					experimentResponse.put(ExperimentConstants.INCLUDE_URLS, includesUrl);
					experimentResponse.put(ExperimentConstants.EXCLUDE_URLS, excludestUrl);
					experimentArray.put(experimentResponse);
				}
				acObj.setProjectExperimentList(projectId+"", experimentArray);
			}catch(Exception ex) {
				LOGGER.log(Level.SEVERE, "Cannot get experiment details for project "+projectId, ex);
			}
		});
		ZABUtil.setDBSpace(existingDBSpace);
		return acObj;
	}
	
	public static AdminConsole getAdminConsoleDashboardDetails(Long startTime, Long endTime, boolean nonZohocorpOnly)throws Exception
	{
		AdminConsole acObj = new AdminConsole();
		try
		{
			Integer totalPortalCount = 0;
			Integer activePortalCount = 0;
			Integer totalAccountCount = 0;
			Integer inactivePortalCount = 0;
			Integer totalProjectCount = 0;
			Integer activeProjectCount = 0;
			Integer inactiveProjectCount = 0;
			Integer totalExpCount = 0;
			Long visitorCount = 0l;
			Criteria portalZohocorpCrit = new Criteria(new Column(AC_PORTAL.TABLE, AC_PORTAL.IS_ZOHOCORP), Boolean.FALSE, QueryConstants.EQUAL);
			Criteria portalTimeCrit = new Criteria(new Column(AC_PORTAL.TABLE, AC_PORTAL.CREATED_TIME), new Long[]{startTime,endTime}, QueryConstants.BETWEEN);
			Criteria projectTimeCrit = new Criteria(new Column(AC_PROJECT.TABLE, AC_PROJECT.CREATED_TIME), new Long[]{startTime,endTime}, QueryConstants.BETWEEN);
			Criteria expTimeCrit = new Criteria(new Column(AC_EXPERIMENT.TABLE, AC_EXPERIMENT.CREATED_TIME), new Long[]{startTime,endTime}, QueryConstants.BETWEEN);
			Criteria goalTimeCrit = new Criteria(new Column(AC_GOAL.TABLE, AC_GOAL.CREATED_TIME), new Long[]{startTime,endTime}, QueryConstants.BETWEEN);

			//Get space and account details
			Table portalTable = new Table(AC_PORTAL.TABLE);
			SelectQuery selectQuery = new SelectQueryImpl(portalTable);
			Join join = new Join(AC_PORTAL.TABLE, AC_EXPERIMENT.TABLE, new String[]{AC_PORTAL.ZSOID}, new String[]{AC_EXPERIMENT.ZSOID}, Join.LEFT_JOIN);
			selectQuery.addJoin(join);
			Column totalPortalCountCol = Column.getColumn(AC_PORTAL.TABLE, AC_PORTAL.ZSOID).distinct().count();
			totalPortalCountCol.setColumnAlias("TOTAL_PORTAL_COUNT");
			selectQuery.addSelectColumn(totalPortalCountCol);
			Column activePortalCountCol = Column.getColumn(AC_EXPERIMENT.TABLE, AC_EXPERIMENT.ZSOID).distinct().count();
			activePortalCountCol.setColumnAlias("ACTIVE_PORTAL_COUNT");
			selectQuery.addSelectColumn(activePortalCountCol);
			Column totalAccountCountCol = Column.getColumn(AC_PORTAL.TABLE, AC_PORTAL.CREATED_ZUID).distinct().count();
			totalAccountCountCol.setColumnAlias("TOTAL_ACCOUNT_COUNT");
			selectQuery.addSelectColumn(totalAccountCountCol);
			//Set criteria
			if(startTime != null || nonZohocorpOnly)
			{
				Criteria finalCriteria = null;
				if(nonZohocorpOnly)
				{
					finalCriteria = (finalCriteria != null) ?finalCriteria.and(portalZohocorpCrit) :portalZohocorpCrit;
				}
				if(startTime != null)
				{
					finalCriteria = (finalCriteria != null) ?finalCriteria.and(portalTimeCrit) :portalTimeCrit;
				}
				selectQuery.setCriteria(finalCriteria);
			}
			
			ZABUserBean bean= (ZABUserBean)BeanUtil.lookup(ZABUserBean.BEAN_NAME, "sharedspace");
			final HashMap<String, Integer> resultHs = new HashMap<String, Integer>();
			bean.executeQuery(selectQuery, new DataSetWrapper() {
				@Override
				public void execute(DataSet ds) throws Exception {
					if(ds.next()) {	
						Integer tpCount = (Integer)ds.getValue("TOTAL_PORTAL_COUNT"); //No I18N
						Integer apCount = (Integer)ds.getValue("ACTIVE_PORTAL_COUNT"); //No I18N
						Integer taCount = (Integer)ds.getValue("TOTAL_ACCOUNT_COUNT"); //No I18N
						resultHs.put("TOTAL_PORTAL_COUNT", tpCount);
						resultHs.put("ACTIVE_PORTAL_COUNT", apCount);
						resultHs.put("TOTAL_ACCOUNT_COUNT", taCount);
					}
				}
			});
			totalPortalCount = resultHs.get("TOTAL_PORTAL_COUNT");
			activePortalCount = resultHs.get("ACTIVE_PORTAL_COUNT");
			totalAccountCount = resultHs.get("TOTAL_ACCOUNT_COUNT");
			inactivePortalCount = totalPortalCount - activePortalCount;
			
			//Get project details
			Table projectTable = new Table(AC_PROJECT.TABLE);
			SelectQuery selectQuery2 = new SelectQueryImpl(projectTable);
			Join join2 = new Join(AC_PROJECT.TABLE, AC_EXPERIMENT.TABLE, new String[]{AC_PROJECT.AC_PROJECT_ID}, new String[]{AC_EXPERIMENT.AC_PROJECT_ID}, Join.LEFT_JOIN);
			selectQuery2.addJoin(join2);
			Join join22 = new Join(AC_PROJECT.TABLE, AC_PORTAL.TABLE, new String[]{AC_PROJECT.ZSOID}, new String[]{AC_PORTAL.ZSOID}, Join.INNER_JOIN);
			selectQuery2.addJoin(join22);
			Column totalProjectCountCol = Column.getColumn(AC_PROJECT.TABLE, AC_PROJECT.AC_PROJECT_ID).distinct().count();
			totalProjectCountCol.setColumnAlias("TOTAL_PROJECT_COUNT");
			selectQuery2.addSelectColumn(totalProjectCountCol);
			Column activeProjectCountCol = Column.getColumn(AC_EXPERIMENT.TABLE, AC_EXPERIMENT.AC_PROJECT_ID).distinct().count();
			activeProjectCountCol.setColumnAlias("ACTIVE_PROJECT_COUNT");
			selectQuery2.addSelectColumn(activeProjectCountCol);
			//Set criteria
			if(startTime != null || nonZohocorpOnly)
			{
				Criteria finalCriteria = null;
				if(nonZohocorpOnly)
				{
					finalCriteria = (finalCriteria != null) ?finalCriteria.and(portalZohocorpCrit) :portalZohocorpCrit;
				}
				if(startTime != null)
				{
					finalCriteria = (finalCriteria != null) ?finalCriteria.and(projectTimeCrit) :projectTimeCrit;
				}
				selectQuery2.setCriteria(finalCriteria);
			}
			
			bean.executeQuery(selectQuery2, new DataSetWrapper() {
				@Override
				public void execute(DataSet ds) throws Exception {
					if(ds.next()) {	
						Integer tprojCount = (Integer)ds.getValue("TOTAL_PROJECT_COUNT"); //No I18N
						Integer aprojCount = (Integer)ds.getValue("ACTIVE_PROJECT_COUNT"); //No I18N
						resultHs.put("TOTAL_PROJECT_COUNT", tprojCount);
						resultHs.put("ACTIVE_PROJECT_COUNT", aprojCount);
					}
				}
			});
			totalProjectCount = resultHs.get("TOTAL_PROJECT_COUNT");
			activeProjectCount = resultHs.get("ACTIVE_PROJECT_COUNT");
			inactiveProjectCount = totalProjectCount - activeProjectCount;
			
			//Get Experiment Details
			Table experimentTable = new Table(AC_EXPERIMENT.TABLE);
			SelectQuery selectQuery3 = new SelectQueryImpl(experimentTable);
			Join join3 = new Join(AC_EXPERIMENT.TABLE, AC_PORTAL.TABLE, new String[]{AC_EXPERIMENT.ZSOID}, new String[]{AC_PORTAL.ZSOID}, Join.INNER_JOIN);
			selectQuery3.addJoin(join3);
			selectQuery3.addSelectColumn(Column.getColumn(AC_EXPERIMENT.TABLE, AC_EXPERIMENT.EXPERIMENT_TYPE));
			selectQuery3.addSelectColumn(Column.getColumn(AC_EXPERIMENT.TABLE, AC_EXPERIMENT.IS_ACTIVE));
			selectQuery3.addSelectColumn(Column.getColumn(AC_EXPERIMENT.TABLE, AC_EXPERIMENT.EXPERIMENT_STATUS));
			Column expCountCol = Column.getColumn(AC_EXPERIMENT.TABLE, AC_EXPERIMENT.AC_EXPERIMENT_ID).distinct().count();
			expCountCol.setColumnAlias("EXPERIMENT_COUNT");
			selectQuery3.addSelectColumn(expCountCol);
			GroupByColumn g1 = new GroupByColumn(new Column(AC_EXPERIMENT.TABLE, AC_EXPERIMENT.EXPERIMENT_TYPE), false);
			GroupByColumn g2 = new GroupByColumn(new Column(AC_EXPERIMENT.TABLE, AC_EXPERIMENT.IS_ACTIVE), false);
			GroupByColumn g3 = new GroupByColumn(new Column(AC_EXPERIMENT.TABLE, AC_EXPERIMENT.EXPERIMENT_STATUS), false);
			List<GroupByColumn> glist = new ArrayList<GroupByColumn>();
			glist.add(g1);
			glist.add(g2);
			glist.add(g3);
			GroupByClause gClause = new GroupByClause(glist);
			selectQuery3.setGroupByClause(gClause);
			
			//Set criteria
			if(startTime != null || nonZohocorpOnly)
			{
				Criteria finalCriteria = null;
				if(nonZohocorpOnly)
				{
					finalCriteria = (finalCriteria != null) ?finalCriteria.and(portalZohocorpCrit) :portalZohocorpCrit;
				}
				if(startTime != null)
				{
					finalCriteria = (finalCriteria != null) ?finalCriteria.and(expTimeCrit) :expTimeCrit;
				}
				selectQuery3.setCriteria(finalCriteria);
			}
			
			final HashMap<Integer, HashMap<Boolean, HashMap<Integer, Integer>>> expCountResultHs = getInitialExpDetailsMap();
			bean.executeQuery(selectQuery3, new DataSetWrapper() {
				@Override
				public void execute(DataSet ds) throws Exception {
					while(ds.next()) {	
						Integer expType = (Integer)ds.getValue(AC_EXPERIMENT.EXPERIMENT_TYPE);
						boolean isActive = (Boolean)ds.getValue(AC_EXPERIMENT.IS_ACTIVE);
						Integer expStatus = (Integer)ds.getValue(AC_EXPERIMENT.EXPERIMENT_STATUS);
						Integer expCount = (Integer)ds.getValue("EXPERIMENT_COUNT"); //No I18N
						prepareExpCountResult(expType, isActive, expStatus, expCount, expCountResultHs);
					}
				}
			});
			
			//Get Goal Details
			Table goalTable = new Table(AC_GOAL.TABLE);
			SelectQuery selectQuery5 = new SelectQueryImpl(goalTable);
			Join join5 = new Join(AC_GOAL.TABLE, AC_PORTAL.TABLE, new String[]{AC_GOAL.ZSOID}, new String[]{AC_PORTAL.ZSOID}, Join.INNER_JOIN);
			selectQuery5.addJoin(join5);
			selectQuery5.addSelectColumn(Column.getColumn(AC_GOAL.TABLE, AC_GOAL.GOAL_TYPE));

			Column goalCountCol = Column.getColumn(AC_GOAL.TABLE, AC_GOAL.AC_GOAL_ID).distinct().count();
			goalCountCol.setColumnAlias("GOAL_COUNT");
			selectQuery5.addSelectColumn(goalCountCol);
			GroupByColumn goal1 = new GroupByColumn(new Column(AC_GOAL.TABLE, AC_GOAL.GOAL_TYPE), false);
			
			List<GroupByColumn> goallist = new ArrayList<GroupByColumn>();
			goallist.add(goal1);
			
			GroupByClause goalClause = new GroupByClause(goallist);
			selectQuery5.setGroupByClause(goalClause);
			
			//Set criteria
			if(startTime != null || nonZohocorpOnly)
			{
				Criteria finalCriteria = null;
				if(nonZohocorpOnly)
				{
					finalCriteria = (finalCriteria != null) ?finalCriteria.and(portalZohocorpCrit) :portalZohocorpCrit;
				}
				if(startTime != null)
				{
					finalCriteria = (finalCriteria != null) ?finalCriteria.and(goalTimeCrit) :goalTimeCrit;
				}
				selectQuery5.setCriteria(finalCriteria);
			}
			
			//final HashMap<Integer, HashMap<Boolean, HashMap<Integer, Integer>>> expCountResultHs = getInitialExpDetailsMap();
			final HashMap<Integer,Integer> goalCountHs = getInitialGoalMap();
			bean.executeQuery(selectQuery5, new DataSetWrapper() {
				@Override
				public void execute(DataSet ds) throws Exception {
					while(ds.next()) {	
						Integer Typgoal = (Integer)ds.getValue(AC_GOAL.GOAL_TYPE);
						Integer goalCount = (Integer)ds.getValue("GOAL_COUNT"); //No I18N
						goalCountHs.put(Typgoal, goalCount);
					}
				}
			});
			
			Integer totalGoalsCount = 0;
			
			Iterator it = goalCountHs.entrySet().iterator();
			
			while (it.hasNext()) {
		        Map.Entry pair = (Map.Entry)it.next();
		        totalGoalsCount = totalGoalsCount + (Integer)pair.getValue();
		    }
			
			//Get total experiment details
			Table expTable1 = new Table(AC_EXPERIMENT.TABLE);
			SelectQuery selectQuery4 = new SelectQueryImpl(expTable1);
			Join join4 = new Join(AC_EXPERIMENT.TABLE, AC_PORTAL.TABLE, new String[]{AC_EXPERIMENT.ZSOID}, new String[]{AC_PORTAL.ZSOID}, Join.INNER_JOIN);
			selectQuery4.addJoin(join4);
			Column expCountCol1 = Column.getColumn(AC_EXPERIMENT.TABLE, AC_EXPERIMENT.AC_EXPERIMENT_ID).distinct().count();
			expCountCol1.setColumnAlias("TOTAL_EXP_COUNT");
			selectQuery4.addSelectColumn(expCountCol1);
			//Set criteria
			if(startTime != null || nonZohocorpOnly)
			{
				Criteria finalCriteria = null;
				if(nonZohocorpOnly)
				{
					finalCriteria = (finalCriteria != null) ?finalCriteria.and(portalZohocorpCrit) :portalZohocorpCrit;
				}
				if(startTime != null)
				{
					finalCriteria = (finalCriteria != null) ?finalCriteria.and(expTimeCrit) :expTimeCrit;
				}
				selectQuery4.setCriteria(finalCriteria);
			}
			
			bean.executeQuery(selectQuery4, new DataSetWrapper() {
				@Override
				public void execute(DataSet ds) throws Exception {
					if(ds.next()) {	
						Integer teCount = (Integer)ds.getValue("TOTAL_EXP_COUNT"); //No I18N
						resultHs.put("TOTAL_EXP_COUNT", teCount);
					}
				}
			});
			totalExpCount = resultHs.get("TOTAL_EXP_COUNT");
			
			acObj.setTotalPortalCount(totalPortalCount);
			acObj.setActivePortalCount(activePortalCount);
			acObj.setTotalAccountCount(totalAccountCount);
			acObj.setInactivePortalCount(inactivePortalCount);
			acObj.setTotalProjectCount(totalProjectCount);
			acObj.setActiveProjectCount(activeProjectCount);
			acObj.setInactiveProjectCount(inactiveProjectCount);
			acObj.setTotalExpCount(totalExpCount);
			acObj.setExpCountHs(expCountResultHs);
			acObj.setExpCountHs(expCountResultHs);
			acObj.setGoalsList(goalCountHs);
			acObj.setTotalGoalsCount(totalGoalsCount);
			
			visitorCount = getVisitorsCount(startTime,endTime,nonZohocorpOnly);
			acObj.setTotalVisitorsCount(visitorCount);
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			throw ex;
		}
		return acObj;
	}
	
	
	public static void getPortalUserDetails() throws Exception
	{
		String inputString = ZABUtil.getCurrentInputString();
		JSONObject inputStr = new JSONObject(inputString);
		String zsoid = inputStr.getString(AdminConsoleConstants.ZSOID);
		String portalDomain = inputStr.getString(AdminConsoleConstants.PORTAL_DOMAIN);
		ZABUtil.setPortaldomain(portalDomain);
		ZABUtil.setDBSpace(zsoid);
	}
	
	public static AdminConsole getList() throws Exception
	{
		AdminConsole acObj=new AdminConsole();
		JSONObject result=new JSONObject();
		try {
			String inputString = ZABUtil.getCurrentInputString();
			JSONObject inputStr = new JSONObject(inputString);
			result=ZABIAMUtil.getListFromName(inputStr.getString(AdminConsoleConstants.ADMIN_CONSOLE_USER_NAME).toLowerCase());
			acObj.setUserList(result);
		}
		catch(Exception ex){
			LOGGER.log(Level.SEVERE,  ex.getMessage());
		}
		return acObj;
	}
	
	public static AdminConsole regenerateScript() throws Exception
	{
		AdminConsole acObj=new AdminConsole();
		try {
			String inputString = ZABUtil.getCurrentInputString();
			JSONObject inputStr = new JSONObject(inputString);
			Long zsoid = inputStr.has(AdminConsoleConstants.ZSOID)?inputStr.getLong(AdminConsoleConstants.ZSOID):null;
			Portal.regenerateScriptsinPortal(zsoid);
			acObj.setSuccess(true);
		}
		catch(Exception ex){
			LOGGER.log(Level.SEVERE,  ex.getMessage());
		}
		return acObj;
	}
	
	public static AdminConsole getPortals() throws Exception
	{
		AdminConsole acObj = new AdminConsole();
		try {
			String inputString = ZABUtil.getCurrentInputString();
			JSONObject inputStr = new JSONObject(inputString);
			Long zuid = Long.parseLong(inputStr.getString(AdminConsoleConstants.ADMIN_CONSOLE_ZUID));
			List<Portal> portallist = Portal.getUserPortals(zuid);
			acObj.setPortalList(portallist);
			String existingDBSpace = ZABUtil.getDBSpace();
			ZABUtil.setDBSpace("sharedspace");	//No I18N
		
			portallist.forEach(portal->{
				Long zsoid = portal.getZsoid();
				PortalLicenseMapping mapping = PortalLicenseMapping.getPortalLicense(Long.valueOf(zsoid));
				if(mapping != null) {
					LicenseDetail detail = LicenseDetail.getLicenseDetail(mapping.getLicenseDetailId());
					Long visitorCount = PortalLicenseAddon.getPlanVisitorCount(mapping.getPortalLicenseMappingId(), detail.getStorePlanId(),mapping.getIsAnnual());
					
						try {
							JSONObject licenseDetails = new JSONObject();
							licenseDetails.put("license_name", detail.getLicenseName());
							licenseDetails.put("project_count",mapping.getProjectCount());
							licenseDetails.put("visitor_count",visitorCount);
							licenseDetails.put("start_date",mapping.getStartTime());
							licenseDetails.put("end_date",mapping.getEndTime());
							licenseDetails.put("is_annual",mapping.getIsAnnual());
							licenseDetails.put("is_active",mapping.getIsAppActive());
							licenseDetails.put("zsoid",zsoid);
							acObj.setPortalLicenseDetails(zsoid+"", licenseDetails);
						}catch(Exception ex) {
							LOGGER.log(Level.SEVERE, "Cannot get licence details for portal "+zsoid, ex);
						}
					
				}
			});
			
			//Audit Log start
			HashMap<String, String> auditLogHs = new HashMap<String, String>();
			auditLogHs.put(AuditLogConstants.LOG_TYPE, AuditLogType.VIEW_USER_SPACE_DETAILS.getLogType().toString());
			auditLogHs.put(AuditLogConstants.ENTITY_TYPE, AuditLogEntityType.USER.getEntityType().toString());
			auditLogHs.put(AuditLogConstants.ENTITY_VALUE, zuid.toString());
			auditLogHs.put(AuditLogConstants.TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
			auditLogHs.put(AuditLogConstants.USER_ZUID, String.valueOf(IAMUtil.getCurrentUser().getZUID()));
			AdminConsoleAuditLog.createAdminConsoleAuditLog(auditLogHs);
			//Audit Log end
			
			
			ZABUtil.setDBSpace(existingDBSpace);
		}
		catch(Exception ex) {
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			throw ex;
		}
		return acObj;
	}
	
	public static void prepareExpCountResult(Integer expType,boolean isActive,Integer expStatus,Integer expCount,final HashMap<Integer, HashMap<Boolean, HashMap<Integer, Integer>>> expCountResultHs)
	{
		if(expCountResultHs.containsKey(expType))
		{
			HashMap<Boolean, HashMap<Integer, Integer>> isActiveBasedMap = expCountResultHs.get(expType);
			if(isActiveBasedMap.containsKey(isActive))
			{
				HashMap<Integer, Integer> statusBasedmap = isActiveBasedMap.get(isActive);
				statusBasedmap.put(expStatus, expCount);
			}
			//As per code flow this will be dead code
			else
			{
				HashMap<Integer, Integer> statusBasedmap = new HashMap<Integer, Integer>();
				statusBasedmap.put(expStatus, expCount);
				isActiveBasedMap.put(isActive, statusBasedmap);
			}
		}
		//As per code flow this will be dead code
		else
		{
			HashMap<Boolean, HashMap<Integer, Integer>> isActiveBasedMap = new HashMap<Boolean, HashMap<Integer, Integer>>();
			HashMap<Integer, Integer> statusBasedmap = new HashMap<Integer, Integer>();
			statusBasedmap.put(expStatus, expCount);
			isActiveBasedMap.put(isActive, statusBasedmap);
			expCountResultHs.put(expType, isActiveBasedMap);
		}
	}
	public static HashMap<Integer, HashMap<Boolean, HashMap<Integer, Integer>>> getInitialExpDetailsMap()
	{
		HashMap<Integer, HashMap<Boolean, HashMap<Integer, Integer>>> finalHs = new HashMap<Integer, HashMap<Boolean, HashMap<Integer, Integer>>>();
		ExperimentType[] experimentTypes = ExperimentType.values();
		for(ExperimentType expTypeObj:experimentTypes)
		{
			if(expTypeObj.equals(ExperimentType.MULTIVARIANT) || expTypeObj.equals(ExperimentType.ENABLED_HEATMAP))
			{
				continue;
			}
			Integer typeKey = expTypeObj.getTypeNumber();
			HashMap<Boolean, HashMap<Integer, Integer>> typeValueHs = new HashMap<Boolean, HashMap<Integer, Integer>>();
			typeValueHs.put(true, getInitialStatusMap());
			typeValueHs.put(false, getInitialStatusMap());
			finalHs.put(typeKey, typeValueHs);
		}
		return finalHs;
	}
	
	public static HashMap<Integer, Integer> getInitialGoalMap()
	{
		HashMap<Integer,Integer> finalHs = new HashMap<Integer, Integer>();
		GoalType[] goalTypes = GoalType.values();
		for(GoalType goalTypeObj:goalTypes)
		{
			if(goalTypeObj.equals(GoalType.ELEMENT_CLICK_GOAL) || goalTypeObj.equals(GoalType.CUSTOM_EVENT_GOAL) || goalTypeObj.equals(GoalType.LINK_CLICK_GOAL) || goalTypeObj.equals(GoalType.TIME_SPENT_GOAL))
			{
				Integer typeKey = goalTypeObj.getGoalTypeId();
				finalHs.put(typeKey, 0);
			}
			
		}
		return finalHs;
	}
	public static HashMap<Integer, Integer> getInitialStatusMap()
	{
		HashMap<Integer, Integer> hs = new HashMap<Integer, Integer>();
		ExperimentStatus[] expStatusArr = ExperimentStatus.values();
		for(ExperimentStatus expStatus:expStatusArr)
		{
			if(expStatus.equals(ExperimentStatus.COMPLETED))
			{
				continue;
			}
			hs.put(expStatus.getStatusCode(), 0);
		}
		return hs;
	}
	public static Long getVisitorsCount(Long startTime, Long endTime, boolean nonZohocorpOnly)
	{
		Long visitorCount = 0l;
		try
		{
			List<String> nonZohocorpPortalList = null;
			if(nonZohocorpOnly)
			{
				nonZohocorpPortalList = getNonZohocorpDomains();
			}
			//Getting data for AB,SPLIT,HEATMAP
			String indexPattern = ElasticSearchConstants.DEFAULT_INDEX_PREFIX + "*";
			String[] typeArray = {ElasticSearchConstants.VISITOR_RAW_TYPE};
			AggregationBuilder aggrBuilder = ElasticSearchStatistics.getVisitorCardinalityAggr();
			AggregationBuilder uuidAggrBuilder = ElasticSearchStatistics.getUUIDVisitorCardinalityAggr();
			
			BoolQueryBuilder query = null;
			if(startTime != null || nonZohocorpOnly)
			{
				query = QueryBuilders.boolQuery();
				if(nonZohocorpOnly)
				{
					QueryBuilder portalsQuery = QueryBuilders.termsQuery(ElasticSearchConstants.PORTAL, nonZohocorpPortalList);
					//query.must().add(portalsQuery);
					query.filter().add(portalsQuery);
				}
				if(startTime != null)
				{
					QueryBuilder timeQuery = QueryBuilders.rangeQuery("time").gte(startTime).lte(endTime); // No I18N
					query.must().add(timeQuery);
				}
			}
			
			SearchResponse response = ElasticSearchUtil.getData(indexPattern, typeArray, 0, query, aggrBuilder);
			
			
			Aggregations visitorAggrResponse = response.getAggregations();
			InternalCardinality cardinality = visitorAggrResponse.get("distinct_visitors");
			visitorCount = cardinality.getValue();
			
			response = ElasticSearchUtil.getData(indexPattern, typeArray, 0, query, uuidAggrBuilder);

			visitorAggrResponse = response.getAggregations();
			cardinality = visitorAggrResponse.get("distinct_uuid_visitors");
			visitorCount = visitorCount + cardinality.getValue();
			
			//Getting data for FUNNEL
			String[] funneltypeArray = {ElasticSearchConstants.FUNNEL_RAW_TYPE};
			AggregationBuilder funnelAggrBuilder = ElasticSearchStatistics.getFunnelSessionCardinalityAggr();
			
			
			BoolQueryBuilder funnelQuery = null;
			if(startTime != null || nonZohocorpOnly)
			{
				funnelQuery = QueryBuilders.boolQuery();
				if(nonZohocorpOnly)
				{
					QueryBuilder portalsQuery = QueryBuilders.termsQuery(ElasticSearchConstants.PORTAL, nonZohocorpPortalList);
					//funnelQuery.must().add(portalsQuery);
					funnelQuery.filter().add(portalsQuery);
				}
				if(startTime != null)
				{
					QueryBuilder timeQuery = QueryBuilders.nestedQuery("steps", QueryBuilders.rangeQuery(ElasticSearchConstants.STEPS+ "."+ElasticSearchConstants.TIME).gte(startTime).lte(endTime), ScoreMode.None); // No I18N
					funnelQuery.must().add(timeQuery);
				}
			}
			
			SearchResponse funnelResponse = ElasticSearchUtil.getData(indexPattern, funneltypeArray, 0, funnelQuery, funnelAggrBuilder);
			
			
			Aggregations funnelSessionAggrResponse = funnelResponse.getAggregations();
			InternalCardinality sessionCardinality = funnelSessionAggrResponse.get("distinct_sessions");
			visitorCount = visitorCount + sessionCardinality.getValue();
			//Getting Data For Form Analytics
			
			String[] formTypeArray = {ElasticSearchConstants.FORM_ANALYTICS_RAW_TYPE};
			AggregationBuilder formAggrBuilder = ElasticFormReport.getVisitorCardinalityAggr();
			
			
			BoolQueryBuilder formquery = null;
			if(startTime != null || nonZohocorpOnly)
			{
				formquery = QueryBuilders.boolQuery();
				if(nonZohocorpOnly)
				{
					QueryBuilder portalsQuery = QueryBuilders.termsQuery(ElasticSearchConstants.PORTAL, nonZohocorpPortalList);
					//query.must().add(portalsQuery);
					formquery.filter().add(portalsQuery);
				}
				if(startTime != null)
				{
					QueryBuilder timeQuery = QueryBuilders.rangeQuery("time").gte(startTime).lte(endTime); // No I18N
					formquery.must().add(timeQuery);
				}
			}
			
			SearchResponse formResponse = ElasticSearchUtil.getData(indexPattern, formTypeArray, 0, formquery, formAggrBuilder);
			Aggregations formAggrResponse = formResponse.getAggregations();
			InternalCardinality formCardinality = formAggrResponse.get(FormReportConstants.FORM_UNIQUE_VISITOR_COUNT);
			visitorCount = visitorCount + formCardinality.getValue();
			
			//Session Recording
			visitorCount = visitorCount + SessionElasticBand.getSessionCount(nonZohocorpPortalList, startTime, endTime);
			
			//For other features we have to implement it here
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			visitorCount = 0l;
		}
		return visitorCount;
	}
	
	public static void migrateACPortalZohoCorpFlag()
	{
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		try
		{
			DataObject dataObj = ZABModel.getRow(AC_PORTAL.TABLE, null);
			Iterator<?> iterator = dataObj.getRows(AC_PORTAL.TABLE);
			while(iterator.hasNext())
			{
				Row row = (Row)iterator.next();
				Long zsoid = (Long)row.get(AC_PORTAL.ZSOID);
				Long zuid = (Long)row.get(AC_PORTAL.CREATED_ZUID);
				User user = IAMProxy.getInstance().getUserAPI().getUser(zuid);
				if(user.getZOID() == AdminConsoleHandler.ZOHOCORP_ID)
				{
					HashMap<String, String> hs = new HashMap<String, String>();
					hs.put(AdminConsoleConstants.IS_ZOHOCORP, Boolean.TRUE.toString());
					Criteria c1 = new Criteria(new Column(AC_PORTAL.TABLE, AC_PORTAL.ZSOID), zsoid, QueryConstants.EQUAL);
					ZABModel.updateRow(AdminConsoleConstants.AC_PORTAL_CONSTANTS, AC_PORTAL.TABLE, hs, c1, null, true);
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
	
	public static void markPortalAsZohoCorp(Long zsoid)
	{
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		try
		{
			Criteria c1 = new Criteria(new Column(AC_PORTAL.TABLE, AC_PORTAL.ZSOID), zsoid, QueryConstants.EQUAL);
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put(AdminConsoleConstants.IS_ZOHOCORP, Boolean.TRUE.toString());
			ZABModel.updateRow(AdminConsoleConstants.AC_PORTAL_CONSTANTS, AC_PORTAL.TABLE, hs, c1, null);
			LOGGER.log(Level.INFO, "Mark Portal as Zohocorp completed - " + zsoid);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
	
	public static List<String> getNonZohocorpDomains()
	{
		String existingDBSpace = ZABUtil.getDBSpace();
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		List<String> portalList = new ArrayList<String>();
		try
		{
			Criteria c1 = new Criteria(new Column(AC_PORTAL.TABLE, AC_PORTAL.IS_ZOHOCORP), Boolean.FALSE, QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(AC_PORTAL.TABLE, c1);
			Iterator<?> iter = dataObj.getRows(AC_PORTAL.TABLE);
			while(iter.hasNext())
			{
				Row row = (Row)iter.next();
				String portalDomain = (String)row.get(AC_PORTAL.PORTAL_DOMAIN);
				portalList.add(portalDomain);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		ZABUtil.setDBSpace(existingDBSpace);
		return portalList;
	}
	
	public static int deleteVisitorDetailEntry(Long startId, Long endId)
	{
		int deleteRowCount = 0;
		try
		{
			DeleteQuery delQuery  = new DeleteQueryImpl(VISITOR_DETAIL.TABLE);
			Criteria c1 = new Criteria(new Column(VISITOR_DETAIL.TABLE, VISITOR_DETAIL.VISITOR_ID), startId, QueryConstants.GREATER_THAN);
			Criteria c2 = new Criteria(new Column(VISITOR_DETAIL.TABLE, VISITOR_DETAIL.VISITOR_ID), endId, QueryConstants.LESS_THAN);
			delQuery.setCriteria(c1.and(c2));
			deleteRowCount = ZABModel.deleteResource(delQuery);
			LOGGER.log(Level.INFO, "deleteVisitorDetailEntry count -" + deleteRowCount);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception in deleteVisitorDetailEntry");
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		return deleteRowCount;
	}
	
	public static void pushMissedPortalsToACPortal()
	{
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		try
		{
			LOGGER.log(Level.INFO, "Zsoids push started");
			SelectQuery query = new SelectQueryImpl(Table.getTable(PORTAL_LICENSE_MAPPING.TABLE));
			query.addSelectColumn(Column.getColumn(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.ZSOID));
			
			SelectQuery query2 = new SelectQueryImpl(Table.getTable(AC_PORTAL.TABLE));
			query2.addSelectColumn(Column.getColumn(AC_PORTAL.TABLE, AC_PORTAL.ZSOID));
			DerivedColumn dc = new DerivedColumn("ZSOID",query2); // No I18N
			
			query.setCriteria(new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE,PORTAL_LICENSE_MAPPING.ZSOID),dc,QueryConstants.NOT_IN));
			
			ZABUserBean bean= (ZABUserBean)BeanUtil.lookup(ZABUserBean.BEAN_NAME, "sharedspace");
			final List<Long> zsoidList = new ArrayList<Long>();
			bean.executeQuery(query, new DataSetWrapper() {
				@Override
				public void execute(DataSet ds) throws Exception {
					while(ds.next()) {	
						Long zsoid = (Long)ds.getValue(PORTAL_LICENSE_MAPPING.ZSOID);
						zsoidList.add(zsoid);
					}
				}
			});
			LOGGER.log(Level.INFO, "Zsoids are {0}", new String[]{zsoidList.toString()});
			
			for(Long zsoid:zsoidList)
			{
				try
				{
					Criteria criteria1 = new Criteria(new Column(AC_PORTAL.TABLE, AC_PORTAL.ZSOID), zsoid, QueryConstants.EQUAL);
					DataObject dataObj = ZABModel.getRow(AC_PORTAL.TABLE, criteria1);
					if(dataObj.isEmpty())
					{
						ServiceOrg serviceOrg = ZABServiceOrgUtil.getServiceOrg(zsoid);
						HashMap<String, String> acHs = new HashMap<String, String>();
						acHs.put(AdminConsoleConstants.ZSOID, zsoid.toString());
						acHs.put(AdminConsoleConstants.PORTAL_NAME, serviceOrg.getOrgName());
						acHs.put(AdminConsoleConstants.PORTAL_DOMAIN, serviceOrg.getDomains().get(0).getDomain());
						acHs.put(AdminConsoleConstants.CREATED_ZUID, String.valueOf(serviceOrg.getCreatedBy()));
						acHs.put(AdminConsoleConstants.CREATED_TIME, String.valueOf(serviceOrg.getCreatedTime()));
						User user = IAMProxy.getInstance().getUserAPI().getUser(serviceOrg.getCreatedBy());
						if(user.getZOID() == AdminConsoleHandler.ZOHOCORP_ID)
						{
							acHs.put(AdminConsoleConstants.IS_ZOHOCORP, Boolean.TRUE.toString());
						}
						else
						{
							acHs.put(AdminConsoleConstants.IS_ZOHOCORP, Boolean.FALSE.toString());
						}
						AdminConsole.createAcPortal(acHs);
					}
				}
				catch(Exception ex)
				{
					LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
					LOGGER.log(Level.SEVERE, "Exception occurred for zsoid {0}", new String[]{zsoid.toString()});
				}
			}
			LOGGER.log(Level.INFO, "Zsoids push completed");
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
	
	public static void syncCRMPotentials(Long fromDate)
	{
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		try
		{
			LOGGER.log(Level.INFO, "Sync CRM started - createdtime - "+ fromDate);
			Criteria criteria1 = new Criteria(new Column(AC_PORTAL.TABLE, AC_PORTAL.CREATED_TIME), fromDate, QueryConstants.GREATER_THAN);
			Criteria criteria2 = new Criteria(new Column(LICENSE_DETAIL.TABLE, LICENSE_DETAIL.LICENSE_TYPE), new Integer[]{License.ZOHOONETRIAL.getLicenseType(), License.ZOHOONE.getLicenseType()}, QueryConstants.NOT_IN);
			Join join1 = new Join(AC_PORTAL.TABLE, PORTAL_LICENSE_MAPPING.TABLE, new String[]{AC_PORTAL.ZSOID}, new String[]{PORTAL_LICENSE_MAPPING.ZSOID}, Join.INNER_JOIN);
			Join join2 = new Join(PORTAL_LICENSE_MAPPING.TABLE, LICENSE_DETAIL.TABLE, new String[]{PORTAL_LICENSE_MAPPING.LICENSE_DETAIL_ID}, new String[]{LICENSE_DETAIL.LICENSE_DETAIL_ID}, Join.INNER_JOIN);
			DataObject dataObj = ZABModel.getRow(AC_PORTAL.TABLE, criteria1.and(criteria2), new Join[]{join1,join2});
			Iterator<?> iter = dataObj.getRows(AC_PORTAL.TABLE);
			while(iter.hasNext())
			{
				Row row = (Row)iter.next();
				Long zsoid = (Long)row.get(AC_PORTAL.ZSOID);
				Long zuid = (Long)row.get(AC_PORTAL.CREATED_ZUID);
				Long createdTime = (Long)row.get(AC_PORTAL.CREATED_TIME);
				String portalDomain = (String)row.get(AC_PORTAL.PORTAL_DOMAIN);
				try
				{
					User user = IAMProxy.getInstance().getUserAPI().getUser(zuid);
					HashMap<String, String> hs = new HashMap<String, String>();
					String registeredDate = ZABUtil.getMillisToString(createdTime);
					hs.put(PageSenseOrgFilter.REGISTRATION_DATE, registeredDate);
					hs.put(AdminConsoleConstants.ZSOID, zsoid.toString());
					PageSenseOrgFilter.pushPotentialRequestIntoCRM(user, portalDomain, hs);
				}
				catch(Exception ex)
				{
					LOGGER.log(Level.SEVERE, "Exception occurred for zsoid - {0}", new String[]{zsoid.toString()});
					LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
				}
			}
			LOGGER.log(Level.INFO, "Sync CRM completed");
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Sync CRM error");
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
	
	public static void pushZsoidToExistingCrmPotentials()
	{
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		try
		{
			LOGGER.log(Level.INFO, "pushZsoidToExistingCrmPotentials started");
			Criteria criteria1 = new Criteria(new Column(AC_PORTAL.TABLE, AC_PORTAL.IS_ZOHOCORP), Boolean.FALSE, QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(AC_PORTAL.TABLE, criteria1);
			Iterator<?> iter = dataObj.getRows(AC_PORTAL.TABLE);
			while(iter.hasNext())
			{
				Row row = (Row)iter.next();
				Long zsoid = (Long)row.get(AC_PORTAL.ZSOID);
				Long zuid = (Long)row.get(AC_PORTAL.CREATED_ZUID);
				String portalDomain = (String)row.get(AC_PORTAL.PORTAL_DOMAIN);
				try
				{
					User user = IAMProxy.getInstance().getUserAPI().getUser(zuid);
					String email = user.getPrimaryEmail();
					PageSenseOrgFilter.pushZsoidIntoCrmPotentials(email, zsoid, portalDomain);
				}
				catch(Exception ex)
				{
					LOGGER.log(Level.SEVERE, "Exception occurred for zsoid - {0}", new String[]{zsoid.toString()});
					LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
				}
			}
			LOGGER.log(Level.INFO, "pushZsoidToExistingCrmPotentials completed");
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "pushZsoidToExistingCrmPotentials error");
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
	
	public static List<AdminConsoleUserDetail> getUserLicenseDetails(HashMap<String, String> hs) throws Exception
	{
		List<AdminConsoleUserDetail> responseList = null;
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		Long signedUpAfter = (hs.get("signedUpAfter") != null) ? ZABUtil.getTimeInLongFromDateFormStr(hs.get("signedUpAfter"), "yyyy-MM-dd") : null; //No I18N
		Long signedUpBefore = (hs.get("signedUpBefore") != null) ? ZABUtil.getNthDayDateInLong(ZABUtil.getTimeInLongFromDateFormStr(hs.get("signedUpBefore"), "yyyy-MM-dd"),1) : null; //No I18N
		Long expiredTime = (hs.get("expired_date") != null) ? ZABUtil.getTimeInLongFromDateFormStr(hs.get("expired_date"), "yyyy-MM-dd") : null; //No I18N
		Boolean excludeZohoOne = (hs.get("exclude_zohoone") != null) ? Boolean.parseBoolean(hs.get("exclude_zohoone")) : null;
		Boolean licenseActive =  (hs.get("license_active") != null) ? Boolean.parseBoolean(hs.get("license_active")) : null;
		Boolean trackingHappenned = (hs.get("tracking_happenned") != null) ? Boolean.parseBoolean(hs.get("tracking_happenned")) : null;
		Boolean limitWarned = (hs.get("visitor_limit_warned") != null) ? Boolean.parseBoolean(hs.get("visitor_limit_warned")) : null;
		Long minimumVisitorCount = (hs.get("minimum_visitor_count") != null) ? Long.parseLong(hs.get("minimum_visitor_count")) : null;
		Long zsoid = (hs.get("zsoid") != null) ? Long.parseLong(hs.get("zsoid")) : null;
		
		Criteria finalCriteria = new Criteria(new Column(AC_PORTAL.TABLE, AC_PORTAL.IS_ZOHOCORP), Boolean.FALSE, QueryConstants.EQUAL);
		if(zsoid != null)
		{
			finalCriteria = finalCriteria.and(new Criteria(new Column(AC_PORTAL.TABLE, AC_PORTAL.ZSOID), zsoid, QueryConstants.EQUAL));
		}
		if(signedUpAfter != null)
		{
			finalCriteria = finalCriteria.and(new Criteria(new Column(AC_PORTAL.TABLE, AC_PORTAL.CREATED_TIME), signedUpAfter, QueryConstants.GREATER_THAN));
		}
		if(signedUpBefore != null)
		{
			finalCriteria = finalCriteria.and(new Criteria(new Column(AC_PORTAL.TABLE, AC_PORTAL.CREATED_TIME), signedUpBefore, QueryConstants.LESS_THAN));
		}
		if(expiredTime != null)
		{
			expiredTime = ZABUtil.getNthDayDateInLong(expiredTime, 1);
			finalCriteria = finalCriteria.and(new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.PAUSED_TIME), expiredTime, QueryConstants.GREATER_THAN));
		}
		if(excludeZohoOne != null && excludeZohoOne)
		{
			finalCriteria = finalCriteria.and(new Criteria(new Column(LICENSE_DETAIL.TABLE, LICENSE_DETAIL.LICENSE_TYPE), new Integer[]{License.ZOHOONE.getLicenseType(),License.ZOHOONETRIAL.getLicenseType()}, QueryConstants.NOT_IN));
		}
		if(licenseActive != null)
		{
			finalCriteria = finalCriteria.and(new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.IS_APP_ACTIVE), licenseActive, QueryConstants.EQUAL));
		}
		if(trackingHappenned != null)
		{
			finalCriteria = finalCriteria.and(new Criteria(new Column(AC_PORTAL.TABLE, AC_PORTAL.SCRIPT_VERIFIED), trackingHappenned, QueryConstants.EQUAL));
		}
		if(limitWarned != null)
		{
			finalCriteria = finalCriteria.and(new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.IS_VISITORLIMIT_WARNED), limitWarned, QueryConstants.EQUAL));
		}
		
		Join join1 = new Join(AC_PORTAL.TABLE, PORTAL_LICENSE_MAPPING.TABLE, new String[]{AC_PORTAL.ZSOID}, new String[]{PORTAL_LICENSE_MAPPING.ZSOID}, Join.INNER_JOIN);
		Join join2 = new Join(PORTAL_LICENSE_MAPPING.TABLE, LICENSE_DETAIL.TABLE, new String[]{PORTAL_LICENSE_MAPPING.LICENSE_DETAIL_ID}, new String[]{LICENSE_DETAIL.LICENSE_DETAIL_ID}, Join.INNER_JOIN);
		
		Table portalTable = new Table(AC_PORTAL.TABLE);
		SelectQuery selectQuery = new SelectQueryImpl(portalTable);
		
		Column zuidsCol = Column.getColumn(AC_PORTAL.TABLE, AC_PORTAL.CREATED_ZUID);
		Column domainCol = Column.getColumn(AC_PORTAL.TABLE, AC_PORTAL.PORTAL_DOMAIN);
		Column zsoidCol = Column.getColumn(AC_PORTAL.TABLE, AC_PORTAL.ZSOID);
		Column startTimeCol = Column.getColumn(AC_PORTAL.TABLE, AC_PORTAL.CREATED_TIME);
		Column tracingHappennedCol = Column.getColumn(AC_PORTAL.TABLE, AC_PORTAL.SCRIPT_VERIFIED);
		Column licenseActiveCol = Column.getColumn(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.IS_APP_ACTIVE);
		Column pausedTimeCol = Column.getColumn(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.PAUSED_TIME);
		Column limitWarnedCol = Column.getColumn(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.IS_VISITORLIMIT_WARNED);
		Column licenseNameCol = Column.getColumn(LICENSE_DETAIL.TABLE, LICENSE_DETAIL.LICENSE_NAME);
		
		selectQuery.addSelectColumn(zuidsCol);
		selectQuery.addSelectColumn(domainCol);
		selectQuery.addSelectColumn(zsoidCol);
		selectQuery.addSelectColumn(startTimeCol);
		selectQuery.addSelectColumn(tracingHappennedCol);
		selectQuery.addSelectColumn(licenseActiveCol);
		selectQuery.addSelectColumn(pausedTimeCol);
		selectQuery.addSelectColumn(limitWarnedCol);
		selectQuery.addSelectColumn(licenseNameCol);
		
		selectQuery.addJoin(join1);
		selectQuery.addJoin(join2);
		
		selectQuery.setCriteria(finalCriteria);
		
		ZABUserBean bean= (ZABUserBean)BeanUtil.lookup(ZABUserBean.BEAN_NAME, "sharedspace");
		final List<AdminConsoleUserDetail> acObjList = new ArrayList<AdminConsoleUserDetail>();
		final List<String> domainList = new ArrayList<String>();
		bean.executeQuery(selectQuery, new DataSetWrapper() {
			@Override
			public void execute(DataSet ds) throws Exception {
				while(ds.next()) {	
					Long zuid = (Long)ds.getValue(AC_PORTAL.CREATED_ZUID); 
					String domain = (String)ds.getValue(AC_PORTAL.PORTAL_DOMAIN); 
					Long zsoid = (Long)ds.getValue(AC_PORTAL.ZSOID);
					Long startTime = (Long)ds.getValue(AC_PORTAL.CREATED_TIME);
					Boolean trackingHappenned = (Boolean)ds.getValue(AC_PORTAL.SCRIPT_VERIFIED);
					Boolean licenseActive = (Boolean)ds.getValue(PORTAL_LICENSE_MAPPING.IS_APP_ACTIVE);
					Long pausedTime = (Long)ds.getValue(PORTAL_LICENSE_MAPPING.PAUSED_TIME);
					Boolean limitWarned = (Boolean)ds.getValue(PORTAL_LICENSE_MAPPING.IS_VISITORLIMIT_WARNED);
					String licenseName = (String)ds.getValue(LICENSE_DETAIL.LICENSE_NAME);
					
					AdminConsoleUserDetail acObj = new AdminConsoleUserDetail();
					acObj.setZuid(zuid);
					acObj.setDomain(domain);
					acObj.setZsoid(zsoid);
					acObj.setStartTime(startTime);
					acObj.setTrackingHappenned(trackingHappenned);
					acObj.setLicenseActive(licenseActive);
					acObj.setPausedTime(pausedTime);
					acObj.setLimitWarned(limitWarned);
					acObj.setLicenseName(licenseName);
					acObj.setSuccess(true);
					acObjList.add(acObj);
					
					domainList.add(domain);
				}
			}
		});
		
		if(domainList.size() > 1000)
		{
			throw new Exception("Max number of spaces allowed to query is 1000. But number of spaces selected based on provided filter is "+ domainList.size() + ". Kindly provide shorter interval and make use of more opt filter params provided. Note: visitorlimit param will be applied post query only!");
		}
		
		
		HashMap<String, Long> domainVisitorCount = getVisitorsCount(domainList);
		
		for(AdminConsoleUserDetail acObj:acObjList)
		{
			User user = IAMProxy.getInstance().getUserAPI().getUser(acObj.getZuid());
			if(user != null)
			{
				acObj.setEmailId(user.getPrimaryEmail());
				acObj.setFullName(user.getFirstName() + " " + user.getLastName());
			}
			acObj.setVisitorCount(domainVisitorCount.get(acObj.getDomain()));
		}
		
		if(minimumVisitorCount != null)
		{
			responseList = new ArrayList<AdminConsoleUserDetail>();
			for(AdminConsoleUserDetail acObj:acObjList)
			{
				if(acObj.getVisitorCount() != null &&  acObj.getVisitorCount() >= minimumVisitorCount )
				{
					responseList.add(acObj);
				}
			}
		}
		else
		{
			responseList = acObjList;
		}
		return responseList;
	}
	
	public static ArrayList<ZABUser> getTrialExpiredDetails(Long pausedTime)
	{
		ArrayList<ZABUser> zabUserList = new ArrayList<ZABUser>();
		ZABUtil.setDBSpace("sharedspace");	//No I18N
		try
		{
			Criteria criteria1 = new Criteria(new Column(AC_PORTAL.TABLE, AC_PORTAL.CREATED_TIME), 1517250600000l, QueryConstants.GREATER_THAN);
			Criteria criteria2 = new Criteria(new Column(AC_PORTAL.TABLE, AC_PORTAL.SCRIPT_VERIFIED), Boolean.TRUE, QueryConstants.EQUAL);
			Criteria criteria3 = new Criteria(new Column(AC_PORTAL.TABLE, AC_PORTAL.IS_ZOHOCORP), Boolean.FALSE, QueryConstants.EQUAL);
			Criteria criteria4 = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.IS_APP_ACTIVE), Boolean.FALSE, QueryConstants.EQUAL);
			Criteria criteria5 = new Criteria(new Column(LICENSE_DETAIL.TABLE, LICENSE_DETAIL.LICENSE_TYPE), License.TRIAL.getLicenseType(), QueryConstants.EQUAL);
			Criteria criteria6 = new Criteria(new Column(PORTAL_LICENSE_MAPPING.TABLE, PORTAL_LICENSE_MAPPING.PAUSED_TIME), pausedTime, QueryConstants.GREATER_EQUAL);
			Join join1 = new Join(AC_PORTAL.TABLE, PORTAL_LICENSE_MAPPING.TABLE, new String[]{AC_PORTAL.ZSOID}, new String[]{PORTAL_LICENSE_MAPPING.ZSOID}, Join.INNER_JOIN);
			Join join2 = new Join(PORTAL_LICENSE_MAPPING.TABLE, LICENSE_DETAIL.TABLE, new String[]{PORTAL_LICENSE_MAPPING.LICENSE_DETAIL_ID}, new String[]{LICENSE_DETAIL.LICENSE_DETAIL_ID}, Join.INNER_JOIN);
			
			Table portalTable = new Table(AC_PORTAL.TABLE);
			SelectQuery selectQuery = new SelectQueryImpl(portalTable);
			Column zuidsCol = Column.getColumn(AC_PORTAL.TABLE, AC_PORTAL.CREATED_ZUID);
			//zuidsCol.setColumnAlias("ZUIDS");
			selectQuery.addSelectColumn(zuidsCol);
			Column domainCol = Column.getColumn(AC_PORTAL.TABLE, AC_PORTAL.PORTAL_DOMAIN);
			//domainCol.setColumnAlias("DOMAINS");
			selectQuery.addSelectColumn(domainCol);
			selectQuery.addJoin(join1);
			selectQuery.addJoin(join2);
			Criteria finalCrit = criteria1.and(criteria2).and(criteria3).and(criteria4).and(criteria5);
			if(pausedTime != null)
			{
				finalCrit = finalCrit.and(criteria6);
			}
			selectQuery.setCriteria(finalCrit);
			
			ZABUserBean bean= (ZABUserBean)BeanUtil.lookup(ZABUserBean.BEAN_NAME, "sharedspace");
			final List<Long> zuidList = new ArrayList<Long>();
			final List<String> domainList = new ArrayList<String>();
			final HashMap<Long, String> zuiddomainHs = new HashMap<Long, String>();
			bean.executeQuery(selectQuery, new DataSetWrapper() {
				@Override
				public void execute(DataSet ds) throws Exception {
					while(ds.next()) {	
						Long zuid = (Long)ds.getValue(AC_PORTAL.CREATED_ZUID); 
						String domain = (String)ds.getValue(AC_PORTAL.PORTAL_DOMAIN); 
						zuidList.add(zuid);
						domainList.add(domain);
						zuiddomainHs.put(zuid, domain);
					}
				}
			});
			
			HashMap<Long, String> zuidemailHs = new HashMap<Long, String>();
			Long[] zuidArr = zuidList.toArray(new Long[zuidList.size()]);
			List<UserEmail> userEmails= IAMProxy.getInstance().getUserAPI().getPrimaryEmails(zuidArr);
			for(UserEmail userEmail:userEmails)
			{
				String emailId = userEmail.getEmailId();
				Long zuid = userEmail.getZUID();
				zuidemailHs.put(zuid, emailId);
			}
			
			HashMap<String, Long> domainVisitorCount = getVisitorsCount(domainList);
			for(Map.Entry<Long, String> entry:zuiddomainHs.entrySet())
			{
				Long zuid = entry.getKey();
				String domain = entry.getValue();
				String emailId = zuidemailHs.get(zuid);
				Long visitorCount = domainVisitorCount.get(domain);
				ZABUser zabUser = new ZABUser();
				zabUser.setZuId(zuid);
				zabUser.setEmailAddress(emailId);
				zabUser.setVisitorCount(visitorCount);
				zabUser.setSuccess(true);
				zabUserList.add(zabUser);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "getTrialExpiredDetails error");
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		return zabUserList;
	}
	
	//Trial expired api
	public static HashMap<String, Long> getVisitorsCount(List<String> portalDomains)
	{
		HashMap<String, Long> visitorCountHs = new HashMap<String, Long>(); 
		try
		{
			//Getting data for AB,SPLIT,HEATMAP
			String indexPattern = ElasticSearchConstants.DEFAULT_INDEX_PREFIX + "*";
			
			String[] typeArray = {ElasticSearchConstants.VISITOR_RAW_TYPE};
			String portalTermsLabel = "portals"; // No I18N
			String expTermsLabel = "experiments"; // No I18N
			BoolQueryBuilder query = null;
			query = QueryBuilders.boolQuery();
			QueryBuilder portalsQuery = QueryBuilders.termsQuery(ElasticSearchConstants.PORTAL, portalDomains);
			//query.must().add(portalsQuery);
			query.filter().add(portalsQuery);
			TermsAggregationBuilder portalAggr = AggregationBuilders.terms(portalTermsLabel).  
					field(ElasticSearchConstants.PORTAL).
					size(ElasticSearchConstants.INTEGER_MAX_COUNT);
			TermsAggregationBuilder expAggr = AggregationBuilders.terms(expTermsLabel).  
					field(ElasticSearchConstants.EXPERIMENTID).
					size(ElasticSearchConstants.INTEGER_MAX_COUNT);
			CardinalityAggregationBuilder cardAggr = ElasticSearchStatistics.getVisitorCardinalityAggr();
			CardinalityAggregationBuilder uuidCardAggr = ElasticSearchStatistics.getUUIDVisitorCardinalityAggr();

			AggregationBuilder finalAggr = portalAggr.subAggregation(expAggr.subAggregation(cardAggr).subAggregation(uuidCardAggr));
			SearchResponse response = ElasticSearchUtil.getData(indexPattern, typeArray, 0, query, finalAggr);
			HashMap<String, Long>  heatabsplitHs = readVisitorResponseData(response,"distinct_visitors",portalTermsLabel,expTermsLabel);// No I18N
			
			
			//Getting data for FUNNEL
			String[] funneltypeArray = {ElasticSearchConstants.FUNNEL_RAW_TYPE};
			BoolQueryBuilder funnelQuery = null;
			funnelQuery = QueryBuilders.boolQuery();
			QueryBuilder portalsQuery1 = QueryBuilders.termsQuery(ElasticSearchConstants.PORTAL, portalDomains);
			//funnelQuery.must().add(portalsQuery);
			funnelQuery.filter().add(portalsQuery1);
			String portalTermsLabel1 = "portals1"; // No I18N
			String expTermsLabel1 = "experiments1"; // No I18N
			TermsAggregationBuilder portalAggr1 = AggregationBuilders.terms(portalTermsLabel1).  
					field(ElasticSearchConstants.PORTAL).
					size(ElasticSearchConstants.INTEGER_MAX_COUNT);
			TermsAggregationBuilder expAggr1 = AggregationBuilders.terms(expTermsLabel1).  
					field(ElasticSearchConstants.EXPERIMENTID).
					size(ElasticSearchConstants.INTEGER_MAX_COUNT);
			//Aggregation
			AggregationBuilder sessionCardAggr = ElasticSearchStatistics.getFunnelSessionCardinalityAggr();
			AggregationBuilder funFinalAggr = portalAggr1.subAggregation(expAggr1.subAggregation(sessionCardAggr));
			//Response
			SearchResponse funnelResponse = ElasticSearchUtil.getData(indexPattern, funneltypeArray, 0, funnelQuery, funFinalAggr);
			HashMap<String, Long>  funnelsessionHs  = readVisitorResponseData(funnelResponse,"distinct_sessions",portalTermsLabel1,expTermsLabel1);// No I18N
			
			
			//Getting Data For Form Analytics
			String[] formTypeArray = {ElasticSearchConstants.FORM_ANALYTICS_RAW_TYPE};
			BoolQueryBuilder formquery = null;
			formquery = QueryBuilders.boolQuery();
			QueryBuilder portalsQuery3 = QueryBuilders.termsQuery(ElasticSearchConstants.PORTAL, portalDomains);
			formquery.filter().add(portalsQuery3);
			TermsAggregationBuilder portalAggr2 = AggregationBuilders.terms(portalTermsLabel).  
					field(ElasticSearchConstants.PORTAL).
					size(ElasticSearchConstants.INTEGER_MAX_COUNT);
			TermsAggregationBuilder expAggr2 = AggregationBuilders.terms(expTermsLabel).  
					field(ElasticSearchConstants.EXPERIMENTID).
					size(ElasticSearchConstants.INTEGER_MAX_COUNT);
			CardinalityAggregationBuilder cardAggr2 = ElasticFormReport.getVisitorCardinalityAggr();
			finalAggr = portalAggr2.subAggregation(expAggr2.subAggregation(cardAggr2));
			SearchResponse formResponse = ElasticSearchUtil.getData(indexPattern, formTypeArray, 0, formquery, finalAggr);
			HashMap<String, Long>  formVisitorHs = readVisitorResponseData(formResponse,FormReportConstants.FORM_UNIQUE_VISITOR_COUNT,portalTermsLabel,expTermsLabel);
			
			//Session Recording
			HashMap<String, Long>  sessionRecordingHs = SessionElasticBand.getSessionCount(portalDomains);
			
			//For other features we have to implement it here
			
			if(portalDomains != null)
			{
				for(String portalDomain:portalDomains)
				{
					Long totalCount = 0l;
					totalCount += (heatabsplitHs.get(portalDomain) != null) ? heatabsplitHs.get(portalDomain) : 0l;
					totalCount += (funnelsessionHs.get(portalDomain) != null) ? funnelsessionHs.get(portalDomain) : 0l;
					totalCount += (formVisitorHs.get(portalDomain) != null) ? formVisitorHs.get(portalDomain) : 0l;
					totalCount += (sessionRecordingHs.get(portalDomain) != null) ? sessionRecordingHs.get(portalDomain) : 0l;
					visitorCountHs.put(portalDomain, totalCount);
				}
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		return visitorCountHs;
	}
	
	public static HashMap<String, Long> readVisitorResponseData(SearchResponse response, String countLabel, String portalLabel, String experimentLabel)
	{
		HashMap<String, Long> hs = new HashMap<String, Long>();
		try
		{
			Aggregations aggrResponse = response.getAggregations();
			Terms terms = aggrResponse.get(portalLabel);
			List<? extends Bucket> buckets = terms.getBuckets();
			for(Bucket bucket:buckets)
			{
				Long visitorCount = 0l;
				String portal = (String)bucket.getKey();
				Aggregations buckaggrResponse = bucket.getAggregations();
				Terms expterms = buckaggrResponse.get(experimentLabel);
				List<? extends Bucket> expbuckets = expterms.getBuckets();
				for(Bucket expbucket:expbuckets)
				{
					//String experiment = (String)expbucket.getKey();
					Long uniqueCount = 0l;
					Aggregations expaggrResponse = expbucket.getAggregations();
					InternalCardinality cardinality = expaggrResponse.get(countLabel);
					uniqueCount = cardinality.getValue();
					if(countLabel.equals("distinct_visitors")) {
						cardinality = expaggrResponse.get("distinct_uuid_visitors");
						uniqueCount = uniqueCount + cardinality.getValue();
					}
					visitorCount = visitorCount + uniqueCount;
				}
				hs.put(portal, visitorCount);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception occurred in readVisitorResponseData",ex);
		}
		return hs;
	}

	public JSONObject getUserList() {
		return userList;
	}

	public void setUserList(JSONObject userList) {
		this.userList = userList;
	}
}
