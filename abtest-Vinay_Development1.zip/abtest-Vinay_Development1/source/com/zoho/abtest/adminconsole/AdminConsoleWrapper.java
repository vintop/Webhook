//$Id$
package com.zoho.abtest.adminconsole;

import java.io.Serializable;
import java.util.HashMap;

import com.zoho.abtest.adminconsole.AdminConsoleConstants.AcOperationType;

public class AdminConsoleWrapper implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private AcOperationType operationType;
	
	private HashMap<String, String> valueHs;

	public HashMap<String, String> getValueHs() {
		return valueHs;
	}

	public void setValueHs(HashMap<String, String> valueHs) {
		this.valueHs = valueHs;
	}

	public AcOperationType getOperationType() {
		return operationType;
	}

	public void setOperationType(AcOperationType operationType) {
		this.operationType = operationType;
	}
}
