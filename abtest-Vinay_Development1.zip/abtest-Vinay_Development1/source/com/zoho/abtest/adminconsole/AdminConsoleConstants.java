//$Id$
package com.zoho.abtest.adminconsole;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.zoho.abtest.AC_EXPERIMENT;
import com.zoho.abtest.AC_PORTAL;
import com.zoho.abtest.AC_PROJECT;
import com.zoho.abtest.AC_GOAL;

import com.zoho.abtest.common.Constants;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentStatus;

public class AdminConsoleConstants 
{
	public static final String ADMIN_CONSOLE_MODULE_NAME = "AdminConsoleListener"; //No I18N
	public static final String API_MODULE_PLURAL = "adminconsoledashboard"; //No I18N
	
	public static final String AC_PORTAL_ID = "ac_portal_id"; //NO I18N
	public static final String ZSOID = "zsoid"; //NO I18N
	public static final String PORTAL_NAME = "portal_name"; //NO I18N
	public static final String PORTAL_DOMAIN = "portal_domain"; //NO I18N
	public static final String CREATED_ZUID = "created_zuid"; //NO I18N
	public static final String CREATED_TIME = "created_time"; //NO I18N
	public static final String IS_ZOHOCORP = "is_zohocorp"; //NO I18N
	public static final String AC_PROJECT_ID = "ac_project_id"; //NO I18N
	public static final String PROJECT_ID = "project_id"; //NO I18N
	public static final String PROJECT_STATUS = "project_status"; //NO I18N
	public static final String IS_ACTIVE = "is_Active"; //NO I18N
	public static final String AC_EXPERIMENT_ID = "ac_experiment_id"; //NO I18N
	public static final String EXPERIMENT_ID = "experiment_id"; //NO I18N
	public static final String EXPERIMENT_TYPE = "experiment_type"; //NO I18N
	public static final String EXPERIMENT_STATUS = "experiment_status"; //NO I18N
	public static final String MODIFIED_TIME = "modified_time"; //NO I18N
	public static final String LAST_EVENT_ACTIVITY = "last_event_activity"; //NO I18N
	public static final String ADMIN_CONSOLE_USER_EMAIL = "email_id";//NO I18N
	public static final String ADMIN_CONSOLE_USER_NAME = "user_name";//NO I18N
	public static final String ADMIN_CONSOLE_ZUID = "zuid";//NO I18N
	//public static final String ADMIN_CONSOLE_USER_Name = "UserName";
	public static final String IS_ZOHOONE = "is_zohoone";		//NO I18N
	public static final String IS_APP_SCREEN = "is_app_screen";		//NO I18N
	public static final String IPADDRESS = "ipaddress";		//NO I18N
	public static final String COUNTRY_NAME = "country_name";		//NO I18N
	public static final String NEWSLETTER_FLAG = "newsletter_flag";		//NO I18N
	
	public static final String AC_GOAL_ID = "ac_goal_id"; //NO I18N
	public static final String GOAL_ID = "goal_id"; //No I18N
	public static final String GOAL_TYPE = "goal_type"; //No I18N

	
	public static enum AcOperationType {
		PORTAL_CREATE,
		PORTAL_DELETE,
		PROJECT_CREATE,
		PROJECT_UPDATE,
		PROJECT_DELETE,
		EXPERIMENT_CREATE,
		EXPERIMENT_UPDATE,
		EXPERIMENT_DELETE,
		PROJECT_GOAL_CREATE,
		PROJECT_GOAL_UPDATE,
		PROJECT_GOAL_DELETE;
		
	}
	
	public final static List<Constants> AC_PORTAL_CONSTANTS;
	public final static List<Constants> AC_PROJECT_CONSTANTS;
	public final static List<Constants> AC_EXPERIMENT_CONSTANTS;
	public final static List<Constants> AC_GOAL_CONSTANTS;

	
	static{
		ArrayList<Constants> acportalConstants = new ArrayList<Constants>();
		acportalConstants.add(new Constants(AC_PORTAL_ID,AC_PORTAL.AC_PORTAL_ID,ZABConstants.LONG,Boolean.FALSE));
		acportalConstants.add(new Constants(ZSOID,AC_PORTAL.ZSOID,ZABConstants.LONG,Boolean.TRUE));
		acportalConstants.add(new Constants(PORTAL_NAME,AC_PORTAL.PORTAL_NAME,ZABConstants.STRING,Boolean.TRUE,Boolean.TRUE));
		acportalConstants.add(new Constants(PORTAL_DOMAIN,AC_PORTAL.PORTAL_DOMAIN,ZABConstants.STRING,Boolean.TRUE,Boolean.TRUE));
		acportalConstants.add(new Constants(CREATED_ZUID,AC_PORTAL.CREATED_ZUID,ZABConstants.LONG,Boolean.TRUE));
		acportalConstants.add(new Constants(CREATED_TIME,AC_PORTAL.CREATED_TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.TRUE));
		acportalConstants.add(new Constants(IS_ZOHOCORP,AC_PORTAL.IS_ZOHOCORP,ZABConstants.BOOLEAN,Boolean.TRUE,Boolean.FALSE));
		AC_PORTAL_CONSTANTS = (List<Constants>) Collections.unmodifiableList(acportalConstants);
	}
	
	static{
		ArrayList<Constants> acprojectConstants = new ArrayList<Constants>();
		acprojectConstants.add(new Constants(AC_PROJECT_ID,AC_PROJECT.AC_PROJECT_ID,ZABConstants.LONG,Boolean.FALSE));
		acprojectConstants.add(new Constants(PROJECT_ID,AC_PROJECT.PROJECT_ID,ZABConstants.LONG,Boolean.TRUE));
		acprojectConstants.add(new Constants(PROJECT_STATUS,AC_PROJECT.PROJECT_STATUS,ZABConstants.INTEGER,Boolean.TRUE,Boolean.TRUE));
		acprojectConstants.add(new Constants(ZSOID,AC_PROJECT.ZSOID,ZABConstants.LONG,Boolean.TRUE,Boolean.TRUE));
		acprojectConstants.add(new Constants(AC_PORTAL_ID,AC_PROJECT.AC_PORTAL_ID,ZABConstants.LONG,Boolean.TRUE));
		acprojectConstants.add(new Constants(CREATED_ZUID,AC_PROJECT.CREATED_ZUID,ZABConstants.LONG,Boolean.TRUE));
		acprojectConstants.add(new Constants(CREATED_TIME,AC_PROJECT.CREATED_TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.TRUE));
		AC_PROJECT_CONSTANTS = (List<Constants>) Collections.unmodifiableList(acprojectConstants);
	}
	
	static{
		ArrayList<Constants> acexperimentConstants = new ArrayList<Constants>();
		acexperimentConstants.add(new Constants(AC_EXPERIMENT_ID,AC_EXPERIMENT.AC_EXPERIMENT_ID,ZABConstants.LONG,Boolean.FALSE));
		acexperimentConstants.add(new Constants(EXPERIMENT_ID,AC_EXPERIMENT.EXPERIMENT_ID,ZABConstants.LONG,Boolean.TRUE));
		acexperimentConstants.add(new Constants(EXPERIMENT_TYPE,AC_EXPERIMENT.EXPERIMENT_TYPE,ZABConstants.INTEGER,Boolean.TRUE));
		acexperimentConstants.add(new Constants(EXPERIMENT_STATUS,AC_EXPERIMENT.EXPERIMENT_STATUS,ZABConstants.INTEGER,Boolean.TRUE));
		acexperimentConstants.add(new Constants(IS_ACTIVE,AC_EXPERIMENT.IS_ACTIVE,ZABConstants.BOOLEAN,Boolean.TRUE,Boolean.TRUE));
		acexperimentConstants.add(new Constants(ZSOID,AC_EXPERIMENT.ZSOID,ZABConstants.LONG,Boolean.TRUE));
		acexperimentConstants.add(new Constants(AC_PROJECT_ID,AC_EXPERIMENT.AC_PROJECT_ID,ZABConstants.LONG,Boolean.TRUE));
		acexperimentConstants.add(new Constants(CREATED_ZUID,AC_EXPERIMENT.CREATED_ZUID,ZABConstants.LONG,Boolean.TRUE));
		acexperimentConstants.add(new Constants(CREATED_TIME,AC_EXPERIMENT.CREATED_TIME,ZABConstants.LONG,Boolean.TRUE));
		acexperimentConstants.add(new Constants(MODIFIED_TIME,AC_EXPERIMENT.MODIFIED_TIME,ZABConstants.LONG,Boolean.TRUE,Boolean.TRUE));
		acexperimentConstants.add(new Constants(LAST_EVENT_ACTIVITY,AC_EXPERIMENT.LAST_EVENT_ACTIVITY,ZABConstants.INTEGER,Boolean.TRUE,Boolean.TRUE));
		AC_EXPERIMENT_CONSTANTS = (List<Constants>) Collections.unmodifiableList(acexperimentConstants);
	}
	
	static{
		ArrayList<Constants> acgoalConstants = new ArrayList<Constants>();
		acgoalConstants.add(new Constants(AC_GOAL_ID,AC_GOAL.AC_GOAL_ID,ZABConstants.LONG,Boolean.FALSE));
		acgoalConstants.add(new Constants(GOAL_ID,AC_GOAL.GOAL_ID,ZABConstants.LONG,Boolean.TRUE));
		acgoalConstants.add(new Constants(GOAL_TYPE,AC_GOAL.GOAL_TYPE,ZABConstants.INTEGER,Boolean.TRUE));
		acgoalConstants.add(new Constants(ZSOID,AC_GOAL.ZSOID,ZABConstants.LONG,Boolean.TRUE));
		acgoalConstants.add(new Constants(AC_PROJECT_ID,AC_GOAL.AC_PROJECT_ID,ZABConstants.LONG,Boolean.TRUE));
		acgoalConstants.add(new Constants(CREATED_ZUID,AC_GOAL.CREATED_ZUID,ZABConstants.LONG,Boolean.TRUE));
		acgoalConstants.add(new Constants(CREATED_TIME,AC_GOAL.CREATED_TIME,ZABConstants.LONG,Boolean.TRUE));
		AC_GOAL_CONSTANTS = (List<Constants>) Collections.unmodifiableList(acgoalConstants);
	}
}
