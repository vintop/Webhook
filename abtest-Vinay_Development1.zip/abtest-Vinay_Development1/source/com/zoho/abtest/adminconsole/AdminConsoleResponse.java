//$Id$
package com.zoho.abtest.adminconsole;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentStatus;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentType;
import com.zoho.abtest.goal.GoalConstants.GoalType;
import com.zoho.abtest.portal.Portal;
import com.zoho.abtest.portal.PortalResponse;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.project.ProjectConstants;
import com.zoho.abtest.project.ProjectResponse;
import com.zoho.abtest.utility.ZABUtil;

public class AdminConsoleResponse 
{
	private static final Logger LOGGER = Logger.getLogger(AdminConsoleResponse.class.getName());
	
	public static String jsonResponse(HttpServletRequest request,AdminConsole acObj) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(acObj);			
			JSONObject json = ZABResponse.updateMetaInfo(request, AdminConsoleConstants.API_MODULE_PLURAL, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		return returnBuffer.toString();
	}
	public static String userListResponse(HttpServletRequest request,AdminConsole acObj)throws Exception{
		StringBuffer returnBuffer=new StringBuffer();
		try{
			JSONObject userList=acObj.getUserList();
			returnBuffer.append(userList);
		}
		catch(Exception ex) {
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			throw ex;
		}
		return returnBuffer.toString();
	}
	public static String portalListResponse(HttpServletRequest request,AdminConsole acObj)throws Exception{		
		StringBuffer returnBuffer = new StringBuffer();
		try {
			List<Portal> portalList = acObj.getPortalList();
			JSONArray array = PortalResponse.getJSONArray(portalList);
			int size = array.length();
			for(int i = 0; i < size ; i++) {
				JSONObject portalDetail = array.getJSONObject(i);
				String zsoid = portalDetail.getString("zsoid");
				try {
					JSONObject licenseDetails = acObj.getPortalLicenseDetails(zsoid);
					portalDetail.put("license_details", licenseDetails);
				}catch(JSONException ex) {
					LOGGER.log(Level.SEVERE,"Cannot get License details for zsoid "+zsoid,ex);
				}
			}
			JSONObject json = ZABResponse.updateMetaInfo(request, AdminConsoleConstants.API_MODULE_PLURAL, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex) {
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			throw ex;
		}
		return returnBuffer.toString();
	}
	
	public static String projectDetailResponse(HttpServletRequest request,AdminConsole acObj) throws Exception{		
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = ProjectResponse.getJSONArray(acObj.getProjectList());			
			int size = array.length();
			for(int i = 0; i < size ; i++) {
				JSONObject projectDetail = array.getJSONObject(i);
				String projectid = projectDetail.getString("project_id");
				JSONArray experimentArray = acObj.getProjectExperimentList(projectid);
				projectDetail.put("Experiments", experimentArray);
			}
			JSONObject json = ZABResponse.updateMetaInfo(request, AdminConsoleConstants.API_MODULE_PLURAL, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			throw ex;
		}
		return returnBuffer.toString();
	}
	
	public static JSONArray getPortalArray(List<Portal> portals)throws JSONException{
		JSONArray array = new JSONArray();
		portals.forEach(portal -> {
			JSONObject portalObj = new JSONObject();
			try {
				portalObj.put("name", portal.getPortalName());
				array.put(portalObj);
			} catch (JSONException ex) {
				LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			}
		});
		return array;
	}
	
	public static JSONArray getJSONArray(AdminConsole acObj) throws JSONException {
		JSONArray array = new JSONArray();
		JSONObject resultjsonObj = new JSONObject();
		
		JSONObject accountobj = new JSONObject();
		accountobj.put("total", acObj.getTotalAccountCount());
		resultjsonObj.put("account", accountobj);
		
		JSONObject visitorobj = new JSONObject();
		visitorobj.put("total", acObj.getTotalVisitorsCount());
		resultjsonObj.put("visitor", visitorobj);
		
		JSONObject portalObj = new JSONObject();
		portalObj.put("total", acObj.getTotalPortalCount());
		portalObj.put("active", acObj.getActivePortalCount());
		portalObj.put("inactive", acObj.getInactivePortalCount());
		portalObj.put("chartdata", populatePortalOrProjChartDataStructure(acObj.getActivePortalCount(), acObj.getInactivePortalCount()));
		resultjsonObj.put("portal", portalObj);
		
		JSONObject projectObj = new JSONObject();
		projectObj.put("total", acObj.getTotalProjectCount());
		projectObj.put("active", acObj.getActiveProjectCount());
		projectObj.put("inactive", acObj.getInactiveProjectCount());
		projectObj.put("chartdata", populatePortalOrProjChartDataStructure(acObj.getActiveProjectCount(), acObj.getInactiveProjectCount()));
		resultjsonObj.put("project", projectObj);
		
		JSONObject expObj = new JSONObject();
		expObj.put("total", acObj.getTotalExpCount());
		JSONArray chartdata = populateExpChartDataStructure(acObj.getExpCountHs());
		expObj.put("chartdata", chartdata);
		resultjsonObj.put("experiment", expObj);
		
		JSONObject goalsObj = new JSONObject();
		goalsObj.put("total", acObj.getTotalGoalsCount());
		JSONArray goalsChartdata = populateGoalChartData(acObj.getGoalsList());
		goalsObj.put("chartdata", goalsChartdata);
		resultjsonObj.put("goals", goalsObj);
		resultjsonObj.put(ZABConstants.SUCCESS, true);
		array.put(resultjsonObj);
		return array;
	}
	
	public static JSONArray populatePortalOrProjChartDataStructure(Integer activeCount, Integer inactiveCount)
	{
		JSONArray chartdata = new JSONArray();
		try
		{
			JSONArray activeArr = new JSONArray();
			activeArr.put("ACTIVE");
			activeArr.put(activeCount);
			chartdata.put(activeArr);
			JSONArray inactiveArr = new JSONArray();
			inactiveArr.put("INACTIVE");
			inactiveArr.put(inactiveCount);
			chartdata.put(inactiveArr);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			chartdata = new JSONArray();
		}
		return chartdata;
	}
	public static JSONArray populateExpChartDataStructure(HashMap<Integer, HashMap<Boolean, HashMap<Integer, Integer>>> expCountHs)
	{
		JSONArray chartdata = new JSONArray();
		try
		{
			for(Map.Entry<Integer, HashMap<Boolean, HashMap<Integer, Integer>>> entryObj:expCountHs.entrySet())
			{
				Integer expTypeNo = entryObj.getKey();
				String expTypeStr = ExperimentType.getExperimentTypeByNumber(expTypeNo).name();
				HashMap<Boolean, HashMap<Integer, Integer>> activeStatusHs = entryObj.getValue();
				JSONArray typeDataArr = new JSONArray();
				for(Map.Entry<Boolean, HashMap<Integer, Integer>> activeStatusEntry:activeStatusHs.entrySet())
				{
					boolean activeStatus = activeStatusEntry.getKey();
					String activeStatusStr = activeStatus ? "ACTIVE" : "ARCHIVED"; //No I18N
					HashMap<Integer, Integer> expStatusHs = activeStatusEntry.getValue();
					JSONArray activeStatusDataArr = new JSONArray();
					for(Map.Entry<Integer, Integer> statusHs:expStatusHs.entrySet())
					{
						Integer expStatusNo = statusHs.getKey();
						String expStatusStr = ExperimentStatus.getStatusByNumber(expStatusNo).name().toLowerCase();
						Integer count = statusHs.getValue();
						JSONArray statusExpCountArr = new JSONArray();
						statusExpCountArr.put(expStatusStr);
						statusExpCountArr.put(count);
						activeStatusDataArr.put(statusExpCountArr);
					}
					JSONObject activeStatusObj = new JSONObject();
					activeStatusObj.put("seriesname", activeStatusStr);
					activeStatusObj.put("data", activeStatusDataArr);
					typeDataArr.put(activeStatusObj);
				}
				JSONObject typeObj = new JSONObject();
				typeObj.put("seriesname", expTypeStr);
				typeObj.put("data", typeDataArr);
				chartdata.put(typeObj);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
			chartdata = new JSONArray();
		}
		return chartdata;
	}
	
	public static JSONArray populateGoalChartData(HashMap<Integer, Integer> goalCountHs)
	{
		JSONArray chartdata = new JSONArray();
		try
		{
			for(Map.Entry<Integer, Integer> entryObj: goalCountHs.entrySet())
			{	
				JSONArray json = new JSONArray();
				Integer goalTypeNo = entryObj.getKey();
				String expTypeStr = GoalType.getGoalTypeById(goalTypeNo).name();
				expTypeStr = expTypeStr.replaceAll("_", " ");
				json.put(expTypeStr);
				json.put(entryObj.getValue());
				chartdata.put(json);				
//				chartdata.put(expTypeStr, (Integer)entryObj.getValue());
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
		return chartdata;
	}
	
	public static String jsonACUserDetailsResponse(HttpServletRequest request,ArrayList<AdminConsoleUserDetail> lst) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getACUserDetails(lst);			
			JSONObject json = ZABResponse.updateMetaInfo(request, AdminConsoleConstants.API_MODULE_PLURAL, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){}
		return returnBuffer.toString();
	}
	
	public static JSONArray getACUserDetails(ArrayList<AdminConsoleUserDetail> list)throws Exception
	{
		JSONArray arr = new JSONArray();
		for(AdminConsoleUserDetail obj:list)
		{
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("zuid", obj.getZuid());
			jsonObj.put("domain", obj.getDomain());
			jsonObj.put("zsoid", obj.getZsoid());
			jsonObj.put("tracking_happenned", obj.getTrackingHappenned());
			jsonObj.put("visitor_limit_warned", obj.getLimitWarned());
			jsonObj.put("license_active", obj.getLicenseActive());
			jsonObj.put("license_name", obj.getLicenseName());
			jsonObj.put("email", obj.getEmailId());
			jsonObj.put("full_name", obj.getFullName());
			jsonObj.put("visitor_count", obj.getVisitorCount());
			if(obj.getStartTime() != null)
			{
				jsonObj.put("start_date", ZABUtil.getDateTimeFormatted(obj.getStartTime()));
			}
			if(obj.getPausedTime() != null)
			{
				jsonObj.put("expired_date", ZABUtil.getDateTimeFormatted(obj.getPausedTime()));
			}
			jsonObj.put(ZABConstants.SUCCESS, obj.getSuccess());
			arr.put(jsonObj);
		}
		return arr;
	}
}
