//$Id$
package com.zoho.abtest.adminconsole;

import java.util.HashMap;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;

import com.adventnet.iam.IAMProxy;
import com.adventnet.iam.User;
import com.adventnet.iam.UserPreference;
import com.zoho.abtest.filter.PageSenseOrgFilter;
import com.zoho.abtest.user.ZABUser;
import com.zoho.abtest.utility.ApplicationProperty;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.abtest.zcampaigns.ZCampaignBridge;


public class AdminConsoleHandler 
{
	private static final Logger	LOGGER = Logger.getLogger(AdminConsoleHandler.class.getName());
	public static final long ZOHOCORP_ID = ApplicationProperty.getLong("org.ids.zohocorp"); //NO I18N
	
	public static void handleAdminConsoleOperation(AdminConsoleWrapper wrapper)
	{
		try
		{
			switch(wrapper.getOperationType())
			{
			case PORTAL_CREATE:
				recordPortalCreation(wrapper);
				break;
			case PORTAL_DELETE:
				recordPortalDeletion(wrapper);
				break;
			case PROJECT_CREATE:
				recordProjectCreation(wrapper);
				break;
			case PROJECT_UPDATE:
				recordProjectUpdation(wrapper);
				break;
			case PROJECT_DELETE:
				recordProjectDeletion(wrapper);
				break;
			case EXPERIMENT_CREATE:
				recordExperimentCreation(wrapper);
				break;
			case EXPERIMENT_UPDATE:
				recordExperimentUpdation(wrapper);
				break;
			case EXPERIMENT_DELETE:
				recordExperimentDeletion(wrapper);
				break;
			case PROJECT_GOAL_CREATE:
				recordProjectGoalCreation(wrapper);
				break;
			case PROJECT_GOAL_UPDATE:
				recordProjectGoalUpdation(wrapper);
				break;
			case PROJECT_GOAL_DELETE:
				recordProjectGoalDeletion(wrapper);
				break;
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred in handleAdminConsoleOperation",ex);
		}
	}
	
	public static void recordPortalCreation(AdminConsoleWrapper wrapper)
	{
		Long zuid = null;
		Long zsoid = null;
		try
		{
			HashMap<String, String> hs = wrapper.getValueHs();
			
			zuid = Long.parseLong(hs.get(AdminConsoleConstants.CREATED_ZUID));
			zsoid = Long.parseLong(hs.get(AdminConsoleConstants.ZSOID));
			User user = IAMProxy.getInstance().getUserAPI().getUser(zuid);
			if(user.getZOID() == ZOHOCORP_ID)
			{
				hs.put(AdminConsoleConstants.IS_ZOHOCORP, Boolean.TRUE.toString());
			}
			else
			{
				hs.put(AdminConsoleConstants.IS_ZOHOCORP, Boolean.FALSE.toString());
			}
			
			AdminConsole.createAcPortal(hs);
			
			//Send data to campaigns
			 if(hs.containsKey(AdminConsoleConstants.CREATED_ZUID)) {
				 User iamUser = ZABUser.getUserByZUID(hs.get(AdminConsoleConstants.CREATED_ZUID));
				Boolean isExistingUser = hs.containsKey(AdminConsoleConstants.IS_APP_SCREEN) ? 
						Boolean.parseBoolean(hs.get(AdminConsoleConstants.IS_APP_SCREEN))
						: false;
				 
				 ZCampaignBridge.addUser(iamUser.getFirstName(), iamUser.getLastName(), iamUser.getPrimaryEmail(), isExistingUser);
			 }
			 
			 //Push user details into CRM Potentials
			 try
			 {
				 if(!hs.containsKey(AdminConsoleConstants.IS_ZOHOONE))
				 {
					String countryCode = user.getCountry();
					String countryName = "";
					if(StringUtils.isNotEmpty(countryCode))
					{
						Locale locale = new Locale("", countryCode);
						countryName = locale.getDisplayCountry();
					}
					UserPreference userPref = user.getUserPreference();
					Boolean newsLetterSubscriptionEnabled = userPref != null && userPref.getNewsLetterSubscription() != 0;
					hs.put(AdminConsoleConstants.COUNTRY_NAME, countryName);
					hs.put(AdminConsoleConstants.NEWSLETTER_FLAG, newsLetterSubscriptionEnabled.toString());
					 
					 String portalName = hs.get(AdminConsoleConstants.PORTAL_DOMAIN);
					 if(user != null)
					 {
						 String registeredDate = ZABUtil.getCurrentServerDate();
						 hs.put(PageSenseOrgFilter.REGISTRATION_DATE, registeredDate);
						 PageSenseOrgFilter.pushPotentialRequestIntoCRM(user, portalName, hs);
					 }
				 }
			 }
			 catch(Exception ex)
			 {
				 LOGGER.log(Level.SEVERE,"Push into CRM issue",ex);
			 }
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred in recordPortalCreation zsoid - {0} - zuid - {1}",new String[]{zsoid.toString(), zuid.toString()});
			LOGGER.log(Level.SEVERE,"Exception Occurred in recordPortalCreation",ex);
		}
	}
	public static void recordPortalDeletion(AdminConsoleWrapper wrapper)
	{
		try
		{
			AdminConsole.deleteAcPortal(wrapper.getValueHs());
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	public static void recordProjectCreation(AdminConsoleWrapper wrapper)
	{
		try
		{
			AdminConsole.createAcProject(wrapper.getValueHs());
			
			HashMap<String, String> hs = wrapper.getValueHs();
			//Send data to campaigns
			 if(hs.containsKey(AdminConsoleConstants.ZSOID)) {
				 ZCampaignBridge.pushProjectCreationEvent(ZABUser.getPortalOwnerEmailByZSOID(hs.get(AdminConsoleConstants.ZSOID)));
			 }
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	public static void recordProjectUpdation(AdminConsoleWrapper wrapper)
	{
		try
		{
			AdminConsole.updateAcProject(wrapper.getValueHs());
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	public static void recordProjectDeletion(AdminConsoleWrapper wrapper)
	{
		try
		{
			AdminConsole.deleteAcProject(wrapper.getValueHs());
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	public static void recordExperimentCreation(AdminConsoleWrapper wrapper)
	{
		try
		{
			AdminConsole.createAcExperiment(wrapper.getValueHs());
			HashMap<String, String> hs = wrapper.getValueHs();
			//Send data to campaigns
			 if(hs.containsKey(AdminConsoleConstants.ZSOID) && hs.containsKey(AdminConsoleConstants.EXPERIMENT_TYPE)) {
				ZCampaignBridge.pushExperimentCreationEvent(hs
						.get(AdminConsoleConstants.EXPERIMENT_TYPE), ZABUser
						.getPortalOwnerEmailByZSOID(hs
								.get(AdminConsoleConstants.ZSOID)));
			 }
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	public static void recordProjectGoalCreation(AdminConsoleWrapper wrapper)
	{
		try
		{
			AdminConsole.createAcGoal(wrapper.getValueHs());
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	
	
	public static void recordExperimentUpdation(AdminConsoleWrapper wrapper)
	{
		try
		{
			AdminConsole.updateAcExperiment(wrapper.getValueHs());
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	public static void recordExperimentDeletion(AdminConsoleWrapper wrapper)
	{
		try
		{
			AdminConsole.deleteAcExperiment(wrapper.getValueHs());
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
	public static void recordProjectGoalUpdation(AdminConsoleWrapper wrapper)
	{
		try
		{
			AdminConsole.updateAcGoal(wrapper.getValueHs());
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	public static void recordProjectGoalDeletion(AdminConsoleWrapper wrapper)
	{
		try
		{
			AdminConsole.deleteAcGoal(wrapper.getValueHs());
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Exception Occurred",ex);
		}
	}
	
}
