//$Id$

package com.zoho.abtest.handlers;

import com.adventnet.iam.security.DefaultSecurityProvider;


public class ZMADynamicParamHandler extends DefaultSecurityProvider {

}
