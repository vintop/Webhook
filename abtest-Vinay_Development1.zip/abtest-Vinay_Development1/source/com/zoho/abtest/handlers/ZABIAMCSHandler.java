//$Id$
package com.zoho.abtest.handlers;

import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.adventnet.iam.IAMException;
import com.adventnet.iam.IAMUtil;
import com.zoho.abtest.adminconsole.AdminConsoleConstants;
import com.zoho.abtest.adminconsole.AdminConsoleWrapper;
import com.zoho.abtest.adminconsole.AdminConsoleConstants.AcOperationType;
import com.zoho.abtest.filter.PageSenseOrgFilter;
import com.zoho.abtest.listener.ZABNotifier;
import com.zoho.abtest.portal.Portal;
import com.zoho.abtest.portal.PortalAction;
import com.zoho.abtest.portal.PortalConstants;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.accounts.AccountsProto.Account;
import com.zoho.accounts.AccountsProto.Account.AppAccount;
import com.zoho.accounts.AccountsProto.Account.User;
import com.zoho.accounts.CSHandler;
import com.zoho.accounts.Credential;
import com.zoho.resource.ResourceException;

public class ZABIAMCSHandler extends CSHandler
{
	private static final Logger LOGGER = Logger.getLogger(ZABIAMCSHandler.class.getName());

	@Override
	public JSONObject updateFields(String screenname, JSONObject data)
			throws ResourceException 
	{
		LOGGER.log(Level.INFO,"Into custom signup");
		try
		{
			if(IAMUtil.getCurrentUser() != null)
			{
				Long zuid = IAMUtil.getCurrentUser().getZUID();
				LOGGER.log(Level.INFO,"Into custom signup start - {0}", new String[]{zuid.toString()});
				LOGGER.log(Level.INFO, data.toString());
				JSONObject params = data.getJSONObject("params"); //No I18N
				String portalName = null;
				if(params.has("x_portal_name"))
				{
					portalName = params.getString("x_portal_name").trim();
					String domainName = portalName.toLowerCase().replaceAll("[^a-z0-9]",""); //No I18N
					
					Long zsoid = ZABServiceOrgUtil.addServiceOrg(portalName, zuid);
					
					if(zsoid != null)
					{
						boolean isPortalExists = ZABServiceOrgUtil.isPortalExists(domainName);
						
						if(domainName.length() > 0 && !isPortalExists)
						{
							//Add the domain
							ZABServiceOrgUtil.addDomain(domainName, zsoid);
						}
						else
						{
							domainName = Portal.mapDomainToPortal(zsoid);
						}
						
						HashMap<String,String> hs = new HashMap<String,String>();
						hs.put(PortalConstants.ZSOID, zsoid.toString());
						hs.put(PortalConstants.DOMAINNAME, domainName);
						//Set it as default portal
						Portal.setDefaultPortal(hs, zuid);
						
						HttpServletRequest request = IAMUtil.getCurrentRequest();
						String ipAddress = ZABUtil.getIpAddressFromRequest(request);
								
						HashMap<String, String> crmPotentialValues = PageSenseOrgFilter.getSignUpRequestCookiesForCrmPotentials(request); 
						
						//Admin console record
						HashMap<String, String> acHs = new HashMap<String, String>();
						acHs.put(AdminConsoleConstants.ZSOID, zsoid.toString());
						acHs.put(AdminConsoleConstants.PORTAL_NAME, portalName);
						acHs.put(AdminConsoleConstants.PORTAL_DOMAIN, domainName);
						acHs.put(AdminConsoleConstants.CREATED_ZUID, zuid.toString());
						acHs.put(AdminConsoleConstants.CREATED_TIME, ZABUtil.getCurrentTimeInMilliSeconds().toString());
						acHs.put(AdminConsoleConstants.IPADDRESS, ipAddress);
						PageSenseOrgFilter.copyPotentialValuesIntoACHs(crmPotentialValues, acHs);
						
						AdminConsoleWrapper acWrapper = new AdminConsoleWrapper();
						acWrapper.setValueHs(acHs);
						acWrapper.setOperationType(AcOperationType.PORTAL_CREATE);
						ZABNotifier.notifyListeners(AdminConsoleConstants.ADMIN_CONSOLE_MODULE_NAME,acWrapper);
						
						ZABUtil.setPortaldomain(domainName);
						
						//Reserve dbspace and popuate values
						new PortalAction().dbSpaceCreation(IAMUtil.getCurrentUser(), zsoid.toString(), null,"");
						
						int specialReferrer = 0;
						if(crmPotentialValues.containsKey(PageSenseOrgFilter.FROM_PRODUCT_HUNT))
						{
							specialReferrer = 1;
						}
						else if(crmPotentialValues.containsKey(PageSenseOrgFilter.SWITCH_FROM_OPTIMIZELY))
						{
							specialReferrer = 2;
						}
						PortalAction.assignTrialLicenseToZsoid(zsoid,specialReferrer);
						LOGGER.log(Level.INFO,"Into custom signup success - {0} - {1}", new String[]{zuid.toString(), zsoid.toString()});
					}
				}
				LOGGER.log(Level.INFO,"Into custom signup completed - {0}", new String[]{zuid.toString()});
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in ZABIAMCSHANDLER updateFields " ,ex);
		}
		return null;
	}

	@Override
	public JSONObject validateFields(String screenName, JSONObject data)
			throws ResourceException 
	{
		LOGGER.log(Level.INFO,"Into custom signup validation");
		String portalName = null;
		String domainName = null;
		String portalFieldName = null;
		String errorMessage = null;
		boolean isValid = true;
		JSONObject resultJson = new JSONObject();
		try {
			if(data != null ){
				if(data.has("params") && data.has("validate")){ //No I18N
					JSONObject params = data.getJSONObject("params"); //No I18N
					String paramName = data.getString("validate"); //No I18N
					if(paramName.equals("x_portal_name") && params.has("x_portal_name")){ //No I18N
						portalName = params.getString("x_portal_name"); //No I18N
						domainName = portalName.toLowerCase().replaceAll("[^a-z0-9]",""); //No I18N
						portalFieldName = "x_portal_name";//No I18N
					} 
				}
			}
			
			if(portalName != null){
				if(!portalName.matches("[a-zA-Z0-9 ]*"))
				{
					resultJson.put("error", (new JSONObject()).put(portalFieldName, "Company Name should contain [A-Z], [a-z] and [0-9] only")); //No I18N
				}
				else if(domainName.trim().length() <= 3 || domainName.trim().length() > 30){
					resultJson.put("error", (new JSONObject()).put(portalFieldName, "Please use 4-30 characters")); //No I18N
				} 
			}
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		return resultJson;
	}
	
	@Override
	public void deleteOrg(String arg0, HttpServletRequest arg1,
			HttpServletResponse arg2) throws IAMException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteUser(String arg0, HttpServletRequest arg1,
			HttpServletResponse arg2) throws IAMException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public AppAccount getCurrentAppAccount(HttpServletRequest arg0,
			AppAccount[] arg1, String arg2, String arg3) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCurrentAppAccountScreenName(HttpServletRequest arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCurrentPortal(HttpServletRequest arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getPortalURL(String arg0, String arg1, String arg2,
			HttpServletRequest arg3) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void handleOrg(Credential arg0, HttpServletRequest arg1,
			HttpServletResponse arg2) throws IAMException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void handleUser(Credential arg0, HttpServletRequest arg1,
			HttpServletResponse arg2) throws IAMException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isUserAuthorized(Account arg0, AppAccount arg1, User arg2) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isUserSpace(HttpServletRequest arg0, String arg1) {
		// TODO Auto-generated method stub
		return false;
	}

}
