//$Id$
package com.zoho.abtest.handlers;

import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;

import com.adventnet.iam.Group;
import com.adventnet.iam.IAMException;
import com.adventnet.iam.IAMHandler;
import com.adventnet.iam.Org;
import com.adventnet.iam.ServiceOrg;
import com.adventnet.iam.User;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUtil;

public class ZABIAMHandler implements IAMHandler
{

	@Override
	public void deleteAppAccount(String arg0, HttpServletRequest arg1,
			HttpServletResponse arg2) throws IAMException {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void deleteGroup(long arg0, HttpServletRequest arg1,
			HttpServletResponse arg2) throws IAMException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteOrg(long arg0, HttpServletRequest arg1,
			HttpServletResponse arg2) throws IAMException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteUser(long arg0, HttpServletRequest arg1,
			HttpServletResponse arg2) throws IAMException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public ServiceOrg getCurrentServiceOrg(HttpServletRequest request, ServiceOrg[] serviceOrgs) throws IAMException {
		String domain = ZABUtil.getDomainFromPortalRequest(request);
		
		if(StringUtils.isNotEmpty(domain))
		{
			//check for the user service org containing the domain
			for(ServiceOrg serviceOrg:serviceOrgs)
			{
				if(serviceOrg.isEnabled() && serviceOrg.isDomainExists(domain))
				{
					return serviceOrg;
				}
			}
			
			//if not present in that user service org return the service org that contains the domain
			/*
			Long zsoid = ZABServiceOrgUtil.getZSOIDFromDomain(domain);
			if(zsoid != null)
			{
				ServiceOrg serviceOrg = ZABServiceOrgUtil.getServiceOrg(zsoid);
				return serviceOrg;
			}
			*/
		}
		
		return null;
	}

	@Override
	public void handleGroup(Group arg0, HttpServletRequest arg1,
			HttpServletResponse arg2) throws IAMException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void handleOrg(Org arg0, HttpServletRequest arg1,
			HttpServletResponse arg2) throws IAMException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void handlePreCloseAction(String arg0, String arg1, Properties arg2)
			throws IAMException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void handleUser(User arg0, HttpServletRequest arg1,
			HttpServletResponse arg2) throws IAMException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void handleUserInParentAccount(String arg0, JSONObject arg1)
			throws IAMException {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public boolean updateZOID(String arg0, String arg1) throws IAMException
	{
		return false;
	}
	
	@Override
	public JSONObject getOrgInformation(JSONObject dataJson)  throws IAMException
	{
		return null;
	}

}
