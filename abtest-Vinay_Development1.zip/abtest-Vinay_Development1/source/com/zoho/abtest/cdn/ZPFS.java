//$Id$
package com.zoho.abtest.cdn;

import java.io.File;
import java.io.InputStream;

import org.apache.commons.io.FileUtils;
import org.apache.tika.Tika;

import com.zoho.abtest.utility.ApplicationProperty;
import com.zoho.conf.Configuration;
import com.zoho.zfs.ZPFSAPI;

public class ZPFS implements ZABCDN {

	@Override
	public String createFile(String fileName, File file, Long userId, String dbspace)  throws Exception{
		if(fileName!=null) {
			fileName = fileName.replaceAll(" ", "_");
		}
		String domainName = ApplicationProperty.getString("abtest.publicserver.domain"); //No I18N
		String fname = "/abtest/images/"+dbspace+"/"+fileName; //No I18N
		ZPFSAPI.addPublicContent(userId.toString(), domainName, fname, new Tika().detect(fileName), FileUtils.readFileToByteArray(file));	
		return fname;
	}

	@Override
	public void updateFile(String fileName, File file, Long userId, String dbspace)  throws Exception {
		String domainName = ApplicationProperty.getString("abtest.publicserver.domain"); //No I18N
		ZPFSAPI.updatePublicContent(userId.toString(), domainName, fileName, new Tika().detect(fileName), FileUtils.readFileToByteArray(file));//No I18N
	}

	@Override
	public void init() {

	}

	@Override
	public void deleteFile(String fileName) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String createFile(String fileName, InputStream is, Long userId,
			String portalName) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateFile(String fileName, InputStream is, Long userId,
			String portalName) throws Exception {
		// TODO Auto-generated method stub
		
	}

}
