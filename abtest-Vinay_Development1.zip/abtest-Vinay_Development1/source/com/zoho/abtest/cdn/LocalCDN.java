//$Id$
package com.zoho.abtest.cdn;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.tika.Tika;

import com.zoho.abtest.utility.ApplicationProperty;

public class LocalCDN implements ZABCDN{
	
	private static final Logger LOGGER = Logger.getLogger(LocalCDN.class.getName());

	private String createOrUpdateScriptFile(String fileName, File file, String portalName) throws Exception {
		String templateEmbedFile=LocalCDN.class.getResource("/../../"+ApplicationProperty.getString("zap.embedScript.location")+File.separator+ApplicationProperty.getString("zap.embedScript.name")).getPath();
		URL pefUrl = LocalCDN.class.getResource("/../../"+ApplicationProperty.getString("zap.embedScript.location")+File.separator+fileName);
		String projectEmbedFile="";
		if(pefUrl!=null) {			
			projectEmbedFile = pefUrl.getPath();
		} else {
			projectEmbedFile = templateEmbedFile.replace(ApplicationProperty.getString("zap.embedScript.name"), fileName); //No I18N
		}
		File scrFile = new File(projectEmbedFile);
		String folderPath = projectEmbedFile.substring(0, projectEmbedFile.lastIndexOf("/"));
		checkForFolder(folderPath);
		if(!scrFile.exists()) {
			scrFile.createNewFile();
		}
		FileUtils.copyFile(file, scrFile);
		return "js/"+fileName; //No I18N
	}
	
	private String createOrUpdateScriptFile(String fileName, InputStream is, String portalName) throws Exception {
		OutputStream outputStream = null;
		try {
			String templateEmbedFile=LocalCDN.class.getResource("/../../"+ApplicationProperty.getString("zap.embedScript.location")+File.separator+ApplicationProperty.getString("zap.embedScript.name")).getPath();
			URL pefUrl = LocalCDN.class.getResource("/../../"+ApplicationProperty.getString("zap.embedScript.location")+File.separator+fileName);
			String projectEmbedFile="";
			if(pefUrl!=null) {			
				projectEmbedFile = pefUrl.getPath();
			} else {
				projectEmbedFile = templateEmbedFile.replace(ApplicationProperty.getString("zap.embedScript.name"), fileName); //No I18N
			}
			File scrFile = new File(projectEmbedFile);
			String folderPath = projectEmbedFile.substring(0, projectEmbedFile.lastIndexOf("/"));
			checkForFolder(folderPath);
			if(!scrFile.exists()) {
				scrFile.createNewFile();
			}
			outputStream = new FileOutputStream(scrFile);

			int read = 0;
			byte[] bytes = new byte[1024];
		
			while ((read = is.read(bytes)) != -1) {
				outputStream.write(bytes, 0, read);
			}
			return "js/"+fileName; //No I18N
		} finally {
			if(outputStream!=null) {
				try {
					outputStream.close();
				} catch (Exception e) {
					LOGGER.log(Level.SEVERE, "Exception occured", e);
				}
			}
			
			if(is != null) {
				try {
					is.close();
				} catch (Exception e) {
					LOGGER.log(Level.SEVERE, "Exception occured", e);
				}
			}
		}
	}
	
	private void checkForFolder(String folderName) {
		File file = new File(folderName);
		if(!file.exists()) {
			file.mkdirs();
		}			
	}
	
	private String createOrUpdateImage(String fileName, InputStream is, String portalName) throws IOException {
		OutputStream outputStream = null;
		
		try {
			if(fileName!=null) {
				fileName = fileName.replaceAll(" ", "_");
			}
			String folderLocation = System.getProperty("user.dir")+"/webapps/ROOT/images/"+portalName+"/";  //NO I18N
			checkForFolder(folderLocation);
			String fileLocation = folderLocation+fileName;
			File scrFile = new File(fileLocation);
			if(!scrFile.exists()) {
				scrFile.createNewFile();
			} else {
				int g = 0;
				String extension = FilenameUtils.getExtension(fileName);
				String rawFileName = fileName.replace("."+extension, "");
				while(scrFile.exists()) {
					g++;
					scrFile = new File(folderLocation+rawFileName+"_"+g+"."+extension);
				}
			}
			
			outputStream = new FileOutputStream(scrFile);
			int read = 0;
			byte[] bytes = new byte[1024];
			
			while ((read = is.read(bytes)) != -1) {
				outputStream.write(bytes, 0, read);
			}
			
			return "images/"+portalName+"/"+scrFile.getName(); //No I18N
			
		} finally {
			if(outputStream!=null) {
				try {
					outputStream.close();
				} catch (Exception e) {
					LOGGER.log(Level.SEVERE, "Exception occured", e);
				}
			}
			
			if(is != null) {
				try {
					is.close();
				} catch (Exception e) {
					LOGGER.log(Level.SEVERE, "Exception occured", e);
				}
			}
		}
	}
	
	private String createOrUpdateImage(String fileName, File file, String portalName) throws IOException {
		if(fileName!=null) {
			fileName = fileName.replaceAll(" ", "_");
		}
		String folderLocation = System.getProperty("user.dir")+"/webapps/ROOT/images/"+portalName+"/"; 
		checkForFolder(folderLocation);
		String fileLocation = folderLocation+fileName;
		File scrFile = new File(fileLocation);
		if(!scrFile.exists()) {
			scrFile.createNewFile();
		} else {
			int g = 0;
			String extension = FilenameUtils.getExtension(fileName);
			String rawFileName = fileName.replace("."+extension, "");
			while(scrFile.exists()) {
				g++;
				scrFile = new File(folderLocation+rawFileName+"_"+g+"."+extension);
			}
		}
		FileUtils.copyFile(file, scrFile);
		return "images/"+portalName+"/"+scrFile.getName(); //No I18N
	}
	
	@Override
	public String createFile(String fileName, File file, Long userId, String portalName) throws Exception {
		String type = new Tika().detect(fileName);
		if(type!=null && type.contains("javascript")) {
			fileName = createOrUpdateScriptFile(fileName, file, portalName);			
		} else if(type!=null && type.contains("image")){
			fileName = createOrUpdateImage(fileName, file, portalName);
		}
		return fileName;
	}

	@Override
	public void updateFile(String fileName, File file, Long userId, String portalName) throws Exception {
		if(fileName!=null) {
			fileName = fileName.replaceAll("js/", ""); //No I18N
		}
		createOrUpdateScriptFile(fileName, file, portalName);
	}

	@Override
	public void init() {
		
	}

	@Override
	public void deleteFile(String fileName) throws Exception {
		URL pefUrl = LocalCDN.class.getResource("/../../"+ApplicationProperty.getString("zap.embedScript.location")+File.separator+fileName);
		String projectEmbedFile="";
		if(pefUrl!=null) {			
			projectEmbedFile = pefUrl.getPath();
			File scrFile = new File(projectEmbedFile);
			scrFile.delete();
		}
		
	}

	@Override
	public String createFile(String fileName, InputStream is, Long userId,
			String portalName) throws Exception {
		String type = new Tika().detect(fileName);
		if(type!=null && type.contains("javascript")) {
			fileName = createOrUpdateScriptFile(fileName, is, portalName);			
		} else if(type!=null && type.contains("image")){
			fileName = createOrUpdateImage(fileName, is, portalName);
		}
		return fileName;
	}

	@Override
	public void updateFile(String fileName, InputStream is, Long userId,
			String portalName) throws Exception {
		if(fileName!=null) {
			fileName = fileName.replaceAll("js/", ""); //No I18N
		}
		createOrUpdateScriptFile(fileName, is, portalName);
	}

}
