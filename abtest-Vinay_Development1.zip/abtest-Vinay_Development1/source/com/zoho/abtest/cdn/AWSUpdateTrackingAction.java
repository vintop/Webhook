//$Id$
package com.zoho.abtest.cdn;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;

import com.adventnet.iam.ServiceOrg;
import com.opensymphony.xwork2.ActionSupport;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUtil;

public class AWSUpdateTrackingAction  extends ActionSupport implements ServletResponseAware, ServletRequestAware{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = Logger.getLogger(AWSUpdateTrackingAction.class.getName());

	private HttpServletRequest request;
	
	private HttpServletResponse response;

	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		request = arg0;
	}

	@Override
	public void setServletResponse(HttpServletResponse arg0) {
		response = arg0;
	}

	public String execute() {
		try {
			String zsoidQP = request.getParameter("zsoid"); //NO I18N
			String projectIdQP = request.getParameter("project_id"); //NO I18N
			Long proId = null;
			Long zsoid = null;
			
			try {
				proId = Long.parseLong(projectIdQP);
			} catch (NumberFormatException e) {
				// TODO: handle exception
			}
			
			try {
				zsoid = Long.parseLong(zsoidQP);
			} catch (NumberFormatException e) {
				// TODO: handle exception
			}
			
			if(zsoid!=null) {
				ZABUtil.setDBSpace(zsoidQP);
				ServiceOrg org = ZABServiceOrgUtil.getServiceOrg(zsoid);
				if(org!=null) {
					String portalName = org.getDomains().get(0).getDomain();
					if(proId != null) {
						Project.updateScriptByProject(proId, portalName);
					} else {
						Project.updateScriptByPortalName(portalName);
					}
					
				}
			} else {
				AWSCDNBackup.retryFailedEntries();
			}
			
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Exception occured while retrying upload of script:", e);
		}
		return null;
	}
}
