//$Id$
package com.zoho.abtest.cdn;

import java.io.File;
import java.io.InputStream;

public interface ZABCDN {
	
	public void init()  throws Exception;;
	
	public String createFile(String fileName, File file, Long userId, String portalName)  throws Exception;
	
	public void updateFile(String fileName, File file, Long userId, String portalName)  throws Exception;
	
	public String createFile(String fileName, InputStream is, Long userId, String portalName)  throws Exception;
	
	public void updateFile(String fileName, InputStream is, Long userId, String portalName)  throws Exception;
	
	public void deleteFile(String fileName)  throws Exception;
}
