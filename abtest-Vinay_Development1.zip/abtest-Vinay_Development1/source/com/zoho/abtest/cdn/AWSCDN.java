//$Id$
package com.zoho.abtest.cdn;

import java.io.File;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.io.FilenameUtils;
import org.apache.tika.Tika;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.auth.SystemPropertiesCredentialsProvider;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.cloudfront.AmazonCloudFrontClient;
import com.amazonaws.services.cloudfront.model.CreateInvalidationRequest;
import com.amazonaws.services.cloudfront.model.InvalidationBatch;
import com.amazonaws.services.cloudfront.model.Paths;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.AccessControlList;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.GroupGrantee;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.Permission;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.utility.ApplicationProperty;
import com.zoho.conf.Configuration;
public class AWSCDN implements ZABCDN{
	
	private static final String ACCESS_KEY_K = "cdn.abtest.aws.accessKeyId";
	
	private static final String SECRET_KEY_K = "cdn.abtest.aws.secretKey";
	
	private static final String DISTRIBUTION_ID_K = "cdn.abtest.aws.distribution_id";
	
	private static final String S3_REGION_KEY = "cdn.abtest.aws.region";//No I18N
	
	private static final String S3_REGION = ApplicationProperty.getString(S3_REGION_KEY);
	
	private static final Regions REGION = Regions.valueOf(S3_REGION);
	
	static {
		System.setProperty("aws.accessKeyId", Configuration.getString(ACCESS_KEY_K).trim()); //No I18N
		System.setProperty("aws.secretKey", Configuration.getString(SECRET_KEY_K).trim()); //No I18N
	}
	
	private static final Logger LOGGER = Logger.getLogger(AWSCDN.class.getName());
	
	private static AmazonS3 s3 = null;
	
	private static AmazonCloudFrontClient cloudFrontClient = null;
	
	private static final String DISTRIBUTION_ID = Configuration.getString(DISTRIBUTION_ID_K);
	
	public static void generateAmazonS3() throws Exception {
		LOGGER.log(Level.INFO, "Initiating S3 Instance");
		Boolean useProxy = Configuration.getBoolean("com.zoho.sas.proxy.enable"); //No I18N
		if(useProxy!=null && useProxy) {
			ClientConfiguration config = new ClientConfiguration();
			config.setProxyHost(Configuration.getString("com.zoho.sas.proxy.server.primary"));	 //No I18N
			config.setProxyPort(Configuration.getInteger("com.zoho.sas.proxy.port"));	 //No I18N
			config.setProxyUsername(Configuration.getString("com.zoho.sas.proxy.username"));
			config.setProxyPassword(com.adventnet.sas.provisioning.Configuration.checkAndDecrypt(Configuration.getString("com.zoho.sas.proxy.password")));//No I18N
			config.setMaxErrorRetry(10);
			
			s3 = AmazonS3ClientBuilder.standard()
					.withCredentials(new SystemPropertiesCredentialsProvider())
					.withClientConfiguration(config)
					.withRegion(REGION)
					.build();	
			cloudFrontClient =new AmazonCloudFrontClient(new SystemPropertiesCredentialsProvider(),config);
		} else {
			s3 = AmazonS3ClientBuilder.standard()
					.withCredentials(new SystemPropertiesCredentialsProvider())
					.withRegion(REGION)
					.build();
			cloudFrontClient =new AmazonCloudFrontClient(new SystemPropertiesCredentialsProvider());
		}
		LOGGER.log(Level.INFO, "S3 Instance configured");
	}

	private final String bucketName = Configuration.getString("cdn.abtest.aws.bucketname"); //No I18N
	
	private String createOrUpdateScriptFile(String fileName, File file) throws Exception{
		if(s3!=null) {	
			LOGGER.log(Level.INFO, "Uploading Script to S3");
			AccessControlList list = new AccessControlList();
			list.grantPermission(GroupGrantee.AllUsers, Permission.Read);
			ObjectMetadata meta = new ObjectMetadata();
			meta.addUserMetadata("Cache-Control", "max-age=0"); //No I18N	
			meta.setContentType(new Tika().detect(fileName));
			try {	
				s3.putObject(new PutObjectRequest(bucketName, "js/"+fileName, file).withAccessControlList(list).withMetadata(meta));//No I18N
			} catch (Exception e) {
				LOGGER.log(Level.SEVERE,"Exception Occurred",e);
			}
			LOGGER.log(Level.INFO, "Script uploaded to S3 successfully");
			return "js/"+fileName;//No I18N
		}
		return null;
	}
	
	private String createOrUpdateScriptFile(String fileName, InputStream is) throws Exception{
		try {
			if(s3!=null) {	
				LOGGER.log(Level.INFO, "Uploading Script to S3");
				AccessControlList list = new AccessControlList();
				list.grantPermission(GroupGrantee.AllUsers, Permission.Read);
				ObjectMetadata meta = new ObjectMetadata();
				meta.addUserMetadata("Cache-Control", "max-age=0"); //No I18N	
				meta.setContentType(new Tika().detect(fileName));
				try {	
					s3.putObject(new PutObjectRequest(bucketName, "js/" //NO I18N
							+ fileName, is, meta).withAccessControlList(list)
							.withMetadata(meta));
				} catch (Exception e) {
					LOGGER.log(Level.SEVERE,"Exception Occurred while uploading:"+fileName,e);
					AWSCDNBackup.logAWSError(fileName);
				}
				LOGGER.log(Level.INFO, "Script uploaded to S3 successfully");
				return "js/"+fileName;//No I18N
			}
		} finally {
			if(is!=null) {
				try {					
					is.close();
				} catch (Exception e) {
					LOGGER.log(Level.INFO, "Closing input stream error", e);
				}
			}
		}
		return null;
	}
	
	private String createImageFile(String fileName, File file, String portalName) {
		if(s3!=null) {
			LOGGER.log(Level.INFO, "Uploading Image to S3");
			String folderLocation = "images/"+portalName+"/";//No I18N
			String fname = folderLocation+fileName;
			String extension = FilenameUtils.getExtension(fileName);
			String rawFileName = fileName.replace("."+extension, "");
			int i=0;
			while(s3.doesObjectExist(bucketName, fname)) {
				i++;
				fname = folderLocation+rawFileName+"_"+i+"."+extension;
			}
			
			AccessControlList list = new AccessControlList();
			list.grantPermission(GroupGrantee.AllUsers, Permission.Read);
			ObjectMetadata meta = new ObjectMetadata();
			meta.addUserMetadata("Cache-Control", "max-age=0");//No I18N
			meta.addUserMetadata("Content-Type", new Tika().detect(fileName));//No I18N
			s3.putObject(new PutObjectRequest(bucketName, fname, file).withAccessControlList(list).withMetadata(meta));
			LOGGER.log(Level.INFO, "Image uploaded to S3 successfully");
			return fname;
		}
		return null;
	}
	
	private String createImageFile(String fileName, InputStream is, String portalName) {
		try {
			if(s3!=null) {
				LOGGER.log(Level.INFO, "Uploading Image to S3");
				String folderLocation = "images/"+portalName+"/";//No I18N
				String fname = folderLocation+fileName;
				String extension = FilenameUtils.getExtension(fileName);
				String rawFileName = fileName.replace("."+extension, "");
				int i=0;
				while(s3.doesObjectExist(bucketName, fname)) {
					i++;
					fname = folderLocation+rawFileName+"_"+i+"."+extension;
				}
				
				AccessControlList list = new AccessControlList();
				list.grantPermission(GroupGrantee.AllUsers, Permission.Read);
				ObjectMetadata meta = new ObjectMetadata();
				meta.addUserMetadata("Cache-Control", "max-age=0");//No I18N
				meta.addUserMetadata("Content-Type", new Tika().detect(fileName));//No I18N
				s3.putObject(new PutObjectRequest(bucketName, fname, is, meta).withAccessControlList(list).withMetadata(meta));
				LOGGER.log(Level.INFO, "Image uploaded to S3 successfully");
				return fname;
			}
			return null;
		} finally {
			if(is!=null) {
				try {					
					is.close();
				} catch (Exception e) {
					LOGGER.log(Level.INFO, "Closing input stream error", e);
				}
			}
		}
	}

	@Override
	public String createFile(String fileName, File file, Long userId,
			String portalName) throws Exception {
		String fname = null;
		String type = new Tika().detect(fileName);
		LOGGER.log(Level.INFO, "Creating file - AWS");
		if(fileName!=null) {
			fileName = fileName.replaceAll(" ", "_");
		}
		if(type!=null && type.contains("javascript")) {
			fname = createOrUpdateScriptFile(fileName, file);			
		} else if(type!=null && type.contains("image")){
			fname = createImageFile(fileName, file, portalName);
		} else {
			throw new ZABException("Unknown filetype is trying to uploaded to s3 FileName: "+fname+", File:"+file);
		}
		LOGGER.log(Level.INFO, "AWS create file end "+type+"::"+fname+"::"+file);
		return fname;
	}
	
	
	@Override
	public String createFile(String fileName, InputStream is, Long userId,
			String portalName) throws Exception {
		String fname = null;
		String type = new Tika().detect(fileName);
		LOGGER.log(Level.INFO, "Creating file - AWS");
		if(fileName!=null) {
			fileName = fileName.replaceAll(" ", "_");
		}
		if(type!=null && type.contains("javascript")) {
			fname = createOrUpdateScriptFile(fileName, is);			
		} else if(type!=null && type.contains("image")){
			fname = createImageFile(fileName, is, portalName);
		} else {
			throw new ZABException("Unknown filetype is trying to uploaded to s3 FileName: "+fname+", File:inputstream"); //NO I18N
		}
		LOGGER.log(Level.INFO, "AWS create file end "+type+"::"+fname+"::inputstream");
		return fname;
	}

	
	public void sendInvalidationRequest(String filePath) {
		LOGGER.log(Level.SEVERE, "Sending invalidation request to distribution for file :"+filePath);
		// Invalidation batch
		InvalidationBatch invalidationBatch = new InvalidationBatch();
		// paths
		Paths paths = new Paths();
		paths.setQuantity(1);
		paths.setItems(Arrays.asList(filePath));
		invalidationBatch.setPaths(paths);
		invalidationBatch.setCallerReference(new Date().getTime()+"CR");
		// Invalidation request
		CreateInvalidationRequest createInvalidationRequest = new CreateInvalidationRequest();
		createInvalidationRequest.setDistributionId(DISTRIBUTION_ID);
		createInvalidationRequest.setInvalidationBatch(invalidationBatch);
		//Invalidation
		cloudFrontClient.createInvalidation(createInvalidationRequest);
		LOGGER.log(Level.SEVERE, "Invalidation request sent:"+filePath);
	}
	
	@Override
	public void updateFile(String fileName, File file, Long userId,
			String portalName) throws Exception {
		if(fileName!=null) {
			fileName = fileName.replaceAll("js/", ""); //No I18N
		}
		String filePath = createOrUpdateScriptFile(fileName, file);
		sendInvalidationRequest("/"+filePath);
	}
	
	@Override
	public void updateFile(String fileName, InputStream is, Long userId,
			String portalName) throws Exception {
		if(fileName!=null) {
			fileName = fileName.replaceAll("js/", ""); //No I18N
		}
		String filePath = createOrUpdateScriptFile(fileName, is);
		sendInvalidationRequest("/"+filePath);
	}

	@Override
	public void init() throws Exception {
		if(s3==null) {			
			generateAmazonS3();
		}
	}

	@Override
	public void deleteFile(String fileName) throws Exception {
		DeleteObjectRequest dor = new DeleteObjectRequest(bucketName, fileName);
		s3.deleteObject(dor);
		sendInvalidationRequest("/"+fileName);
	}

}
