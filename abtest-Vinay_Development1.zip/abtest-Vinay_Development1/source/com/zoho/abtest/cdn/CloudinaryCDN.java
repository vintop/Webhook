//$Id$
package com.zoho.abtest.cdn;

import java.io.File;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import com.cloudinary.Cloudinary;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.exception.ZABException;
import com.zoho.abtest.utility.ApplicationProperty;
import com.zoho.conf.Configuration;

public class CloudinaryCDN implements ZABCDN{
	
	private static final Cloudinary CDN;

	static {
		String cloud_name = ApplicationProperty.getString("cdn.abtest.cloudinary.cloudname")!=null?ApplicationProperty.getString("cdn.abtest.cloudinary.cloudname").trim():"";
		String api_key = ApplicationProperty.getString("cdn.abtest.cloudinary.apikey")!=null?ApplicationProperty.getString("cdn.abtest.cloudinary.apikey").trim():"";
		String api_secret = ApplicationProperty.getString("cdn.abtest.cloudinary.apisecret")!=null?ApplicationProperty.getString("cdn.abtest.cloudinary.apisecret").trim():"";
		 Map<String, String> hs = new HashMap<String, String>();
		 hs.put("cloud_name", cloud_name);
		 hs.put("api_key", api_key);
		 hs.put("api_secret", api_secret);
		 CDN = new Cloudinary(hs);
	}
	
	@Override
	public String createFile(String fileName, File file, Long userId, String dbspace) throws Exception{
			HashMap<String, String> hs1 = new HashMap<>();
			hs1.put("resource_type", "raw");
			hs1.put("public_id", fileName);
			hs1.put("proxy", "http://192.168.100.100:3128");
			Map map = CDN.uploader().upload(file, hs1);
			Long version = (Long) map.get("version");
			return version+"/"+fileName;
	}

	@Override
	public void updateFile(String fileName, File file, Long userId, String dbspace) throws Exception {
		String[] fileDetail = fileName.split("/");
		if(fileDetail.length <=1) {
			throw new ZABException(ZABAction.getMessage(ZABConstants.CDN_FILE_NAME_ERROR));
		}
		String version = fileDetail[0];
		String fName = fileDetail[1];
		HashMap<String, String> hs1 = new HashMap<>();
		hs1.put("resource_type", "raw");
		hs1.put("public_id", fileName);
//		hs1.put("overwrite", Boolean.TRUE.toString());
//		hs1.put("invalidate", Boolean.TRUE.toString());
		hs1.put("proxy", "http://192.168.100.100:3128");
		hs1.put("version", version);
//		Map map =CDN.uploader().destroy(fileName, new HashMap());
		Map map = CDN.uploader().upload(file, hs1);
	}

	@Override
	public void init() {
		
	}

	@Override
	public void deleteFile(String fileName) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String createFile(String fileName, InputStream is, Long userId,
			String portalName) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateFile(String fileName, InputStream is, Long userId,
			String portalName) throws Exception {
		// TODO Auto-generated method stub
		
	}
	
}
