//$Id$
package com.zoho.abtest.cdn;

import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.CDN_FAILED_ENTRY;
import com.zoho.abtest.common.ZABColumn;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.common.ZABTable;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.utility.ZABUtil;

@ZABTable(name=CDN_FAILED_ENTRY.TABLE)
public class AWSCDNBackup extends ZABModel {

	private static final Logger LOGGER = Logger.getLogger(AWSCDNBackup.class.getName());
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@ZABColumn(name=CDN_FAILED_ENTRY.PORTAL)
	private String portal;
	
	@ZABColumn(name=CDN_FAILED_ENTRY.PROJECT_KEY)
	private String projectKey;

	public String getPortal() {
		return portal;
	}

	public void setPortal(String portal) {
		this.portal = portal;
	}

	public String getProjectKey() {
		return projectKey;
	}

	public void setProjectKey(String projectKey) {
		this.projectKey = projectKey;
	}
	
	public static void logAWSError(String filePath) {
		ZABUtil.setDBSpace("sharedspace"); //NO I18N
		LOGGER.log(Level.INFO, "Logging aws error to db:"+filePath);
		try {
			filePath = filePath.replace(".js", ""); //NO I18N
			String[] fragments = filePath.split("/");
			AWSCDNBackup cdnError = new AWSCDNBackup();
			cdnError.setPortal(fragments[0]);
			cdnError.setProjectKey(fragments[1]);
			cdnError.saveRecord();
			
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Exception occured while aws backup"+filePath);
		}
	}
	
	public static void retryFailedEntries() throws Exception {
		ZABUtil.setDBSpace("sharedspace"); //NO I18N
		DataObject dobj = getRow(CDN_FAILED_ENTRY.TABLE, null);
		Iterator<Row> it = dobj.getRows(CDN_FAILED_ENTRY.TABLE);
		while(it.hasNext()) {
			Row row = (Row)it.next();			
			String portal = (String) row.get(CDN_FAILED_ENTRY.PORTAL);
			String projectKey = (String) row.get(CDN_FAILED_ENTRY.PROJECT_KEY);
			ZABUtil.setDBSpaceByPortal(portal);
			Long projectId = Project.getProjectIdFromKey(projectKey);
			LOGGER.log(Level.INFO, "Retrying for project:"+projectId+" in space:"+portal);
			Project.updateScriptByProject(projectId, portal);
			LOGGER.log(Level.INFO, "After retry upload for project:"+projectKey+" in space:"+portal);
			ZABUtil.setDBSpace("sharedspace"); //NO I18N
			ZABModel.deleteResource(row);
		}
	}
}
