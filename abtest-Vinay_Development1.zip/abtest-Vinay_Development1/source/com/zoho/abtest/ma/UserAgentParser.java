//$Id$
package com.zoho.abtest.ma;

public class UserAgentParser 
{
	public static String getDevice(String os)
    {
            String device;
            switch (os)
            {
                    case "IOS":
                            device = "IPhone/IPad"; // No I18N
                            break;
                    case "Android":
                            device = "Android Phone/Tablet"; // No I18N
                            break;
                    default:
                            device = "Laptop/PC"; // No I18N
                            break;
            }
            return device;
    }
    
    public static String getOS(String userAgent)
    {
            String user = userAgent.toLowerCase();
            String os;
            
            if (user.contains("windows"))
            {
                    os = "Windows"; // No I18N
            } 
            else if (user.contains("mac"))
            {
                    os = "Mac"; // No I18N
            } 
            else if (user.contains("x11"))
            {
                    os = "Unix"; // No I18N
            } 
            else if (user.contains("android"))
            {
                    os = "Android"; // No I18N
            } 
            else if (user.contains("iphone"))
            {
                    os = "IOS"; // No I18N
            } 
            else
            {
                    os = "unknown"; // No I18N
            }
            return os;
    }
    
    public static String getBrowserAndVersion(String userAgent)
    {
            String user = userAgent.toLowerCase();
            String browser = "unknown-unknown"; // No I18N
            
            if (user.contains("msie"))
            {
                    String substring = userAgent.substring(userAgent.indexOf("MSIE")).split(";")[0];
                    browser = substring.split(" ")[0].replace("MSIE", "IE") + "-" + substring.split(" ")[1];
            } 
            else if (user.contains("safari") && user.contains("version"))
            {
                    browser = (userAgent.substring(userAgent.indexOf("Safari")).split(" ")[0]).split("/")[0] + "-" + (userAgent.substring(userAgent.indexOf("Version")).split(" ")[0]).split("/")[1];
            } 
            else if (user.contains("opr") || user.contains("opera"))
            {
                    if (user.contains("opera"))
                    {
                            browser = (userAgent.substring(userAgent.indexOf("Opera")).split(" ")[0]).split("/")[0] + "-" + (userAgent.substring(userAgent.indexOf("Version")).split(" ")[0]).split("/")[1];
                    } 
                    else if (user.contains("opr"))
                    {
                            browser = ((userAgent.substring(userAgent.indexOf("OPR")).split(" ")[0]).replace("/", "-")).replace("OPR", "Opera");
                    }
            } 
            else if (user.contains("chrome"))
            {
                    browser = (userAgent.substring(userAgent.indexOf("Chrome")).split(" ")[0]).replace("/", "-");
            } 
            else if ((user.contains("mozilla/7.0")) || (user.contains("netscape6")) || (user.contains("mozilla/4.7")) || (user.contains("mozilla/4.78")) || (user.contains("mozilla/4.08")) || (user.contains("mozilla/3")))
            {
                    browser = "Netscape-unknown"; // No I18N

            } 
            else if (user.contains("firefox"))
            {
                    browser = (userAgent.substring(userAgent.indexOf("Firefox")).split(" ")[0]).replace("/", "-");
            } 
            else if (user.contains("rv"))
            {
                    browser = "IE-unknown"; // No I18N
            } 
            else
            {
                    browser = "unknown-unknown"; // No I18N
            }
            return browser;
    }
}
