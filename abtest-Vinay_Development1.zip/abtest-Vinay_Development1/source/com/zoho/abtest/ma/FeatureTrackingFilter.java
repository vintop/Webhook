//$Id$
package com.zoho.abtest.ma;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;
import org.json.JSONObject;

import com.adventnet.iam.IAMUtil;
import com.adventnet.iam.security.IAMSecurityException;
import com.adventnet.iam.security.SecurityRequestWrapper;
import com.adventnet.sas.ds.SASThreadLocal;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.experiment.ExperimentConstants.ExperimentType;
import com.zoho.abtest.license.PortalLicenseMapping;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.instrument.ma.FeatureTracker;
import com.zoho.instrument.ma.TrackerConf;
import com.zoho.instrument.ma.TrackerData;

public class FeatureTrackingFilter implements Filter
{
	private static final Logger LOGGER = Logger.getLogger(FeatureTrackingFilter.class.getName());
	
	public static enum operationEnum {
		GET("GetInfo"), //No I18N
		POST("Create"), //No I18N
		UPDATE("Update"), //No I18N
		DELETE("Delete"); //No I18N
		
		public String operation;
		
		public String getOperation() {
			return operation;
		}

		operationEnum(String operation) {
			this.operation=operation;
		}
		
	}
	
	

    public void init(FilterConfig conf)throws ServletException
    {
    }

    public void doFilter(ServletRequest requests, ServletResponse responses, FilterChain chain) throws IOException,ServletException 
    {
           HttpServletRequest request = (HttpServletRequest)requests;
           String urlString;
           try
           {
              SecurityRequestWrapper securityWrapper = SecurityRequestWrapper.getInstance(request);
              urlString = securityWrapper.getURLActionRule().getPath();
           }
           catch(IAMSecurityException e)
           {
              urlString = request.getRequestURL().toString();
              urlString = urlString.substring(urlString.lastIndexOf("/"));
           }
           //LOGGER.log(Level.INFO,"URL : "+urlString); 
           try
           {
               TrackerConf conf = FeatureTracker.getTrackerConf(urlString);
               //LOGGER.log(Level.INFO,"And here ------ "+(conf==null));
               boolean b = FeatureTracker.isTrackingEnabled();
               if(conf==null || !b)
               {
                   LOGGER.log(Level.INFO,"Feature tracking is not enabled for URL : "+urlString+" enableProperty :"+b+" conf :"+conf);
                   chain.doFilter(requests,responses);
                   return;
               }
               LOGGER.log(Level.INFO,"Tracker URL : "+urlString+" ### Tracker conf is :"+conf.toString());
               FeatureTracker.start(conf);
               TrackerData trackerData = FeatureTracker.getTrackerData();
               //trackerData.addParam("newKey(not in mi-feature-tracker.xml)", "value of newKey");
               //trackerData.setPaymentPlan("somePaymentPlan_Of_Customer");
               
               
               Long zsoid = null;
               Long zuid = null; 
               if(IAMUtil.getCurrentServiceOrg() != null)
               {
            	   zsoid = IAMUtil.getCurrentServiceOrg().getZSOID();
            	   trackerData.setOrgID(zsoid); //orgID_Of_Request
            	   try {
            		   String planName=getPaymentPlan(zsoid);
					   if(planName!=null) {
						   trackerData.setPaymentPlan(planName);
					   }
					   trackerData.setSasID(SASThreadLocal.getUserId()); //sasID_Of_Request
				} catch (Exception e) {
					LOGGER.log(Level.SEVERE,"Exception while setting Plan details : "+e); 
				}

               }
               if(IAMUtil.getCurrentUser() != null)
               {
            	   zuid = IAMUtil.getCurrentUser().getZUID();
            	   trackerData.setZuid(zuid); //zuID_Of_Request
               }
               
               try {
            	String operationType = getOprType(request.getMethod());
   				trackerData.addParam("Operation", operationType); //No I18N
   				if(conf.getName().equals("Experiments") && request.getMethod().equalsIgnoreCase("post")) {
   					JSONObject requestJSON=null;
   					requestJSON=new JSONObject(ZABUtil.getCurrentInputString());
   					trackerData.addParam("ExperimentType", getExperimentType(requestJSON)); //No I18N
   				}
               } catch (Exception e) {
            	   LOGGER.log(Level.SEVERE,"Exception while setting request method : "+e);    
               }
               
               addUserAgentData(request,trackerData);

               FeatureTracker.includeDefaults(conf,request);
               chain.doFilter(requests,responses);
        	   LOGGER.log(Level.INFO,"MI Feature tracker  #######  TrackerData : "+trackerData);    

           }
           catch(Exception excp)
           {
        	   LOGGER.log(Level.SEVERE,"Exception in FeatureTrackingFilter",excp);
               chain.doFilter(requests,responses);
           }
           finally
           {
               try{
                   FeatureTracker.complete();
                   LOGGER.log(Level.INFO,"Feature Tracking complete");
               }
               catch(Exception e)
               {
                   LOGGER.log(Level.SEVERE,"Exception while completing feature tracking"+e);    
               }
           }
    }    
        
    private String getPaymentPlan(Long zsoid) throws Exception {
    	return PortalLicenseMapping.getLicenseDetailOfPortal(zsoid).getLicenseName();
	}

	private static String getOprType(String method) {
    	String operationType = null;
    	try
    	{
    		operationType = operationEnum.valueOf(method.toUpperCase()).getOperation();
    	}
    	catch(Exception ex)
    	{
    		operationType = "Others"; //No I18N
    	}
    	return operationType;
	}

	private String getExperimentType(JSONObject requestJSON) throws JSONException {
		int expType=(int) requestJSON.getJSONObject(ExperimentConstants.API_MODULE).getInt(ExperimentConstants.EXPERIMENT_TYPE);
		return ExperimentType.getExperimentTypeByNumber(expType).name();
	}

	private static void addUserAgentData(HttpServletRequest req, TrackerData data)
    {
            String userAgent = req.getHeader("User-Agent");
            if(userAgent != null)
            {
                    String ua = UserAgentParser.getBrowserAndVersion(userAgent);
                    String arr[] = ua.split("-");
                    String browser = arr[0];
                    String browserVersion = arr[1];
                    String os = UserAgentParser.getOS(userAgent);
                    String device = UserAgentParser.getDevice(os);
                    data.setBrowser(browser);
                    data.setBrowserVersion(browserVersion);
                    data.setOs(os);
                    data.setDevice(device);
            }
    }

    public void destroy()
    {
    }
}
