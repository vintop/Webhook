//$Id$
package com.zoho.abtest.search;

public class SearchConstants {
	public static final String API_MODULE = "search"; //No I18N
	public final static String SEARCH_NAME = "name"; //NO I18N
	

}
