//$Id$
package com.zoho.abtest.search;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.PROJECT;
import com.zoho.abtest.PROJECT_USER_ROLE;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.utility.ZABUtil;

public class Search extends ZABModel {
	private String searchTerm;
	private ArrayList<Experiment> experiments = new ArrayList<Experiment>();
	private ArrayList<Project> projects = new ArrayList<Project>();
	
	
	public String getSearchTerm() {
		return searchTerm;
	}

	public void setSearchTerm(String searchTerm) {
		this.searchTerm = searchTerm;
	}

	public ArrayList<Experiment> getExperiments() {
		return experiments;
	}

	public void setExperiments(ArrayList<Experiment> experiments) {
		this.experiments = experiments;
	}

	public ArrayList<Project> getProjects() {
		return projects;
	}

	public void setProjects(ArrayList<Project> projects) {
		this.projects = projects;
	}
	
	public static ArrayList<Search> search(){
		Search searchResult  = new Search();
		HttpServletRequest request  = ZABUtil.getCurrentRequest();
		String searchName   = request.getParameter(SearchConstants.SEARCH_NAME);
		searchResult.setSearchTerm(searchName);
		if(searchName!=null&&!searchName.isEmpty()){
			searchResult.setExperiments(searchExperiment(searchName));
			searchResult.setProjects(searchProject(searchName));
		}
	
		searchResult.setSuccess(Boolean.TRUE);
		ArrayList<Search> ans= new ArrayList<Search>();
		ans.add(searchResult);
		return ans;
	
	}

	public static ArrayList<Experiment> searchExperiment(String searchName){
		ArrayList<Experiment> experiments =new  ArrayList<Experiment>();
		experiments = Experiment.getAllExperimentsByCurrentUser(null, searchName);
		
		return experiments;
	}
	
	public static ArrayList<Project> searchProject(String searchName){
		
		ArrayList<Project> projects =new  ArrayList<Project>();
		Criteria c = new Criteria (new Column(PROJECT.TABLE,PROJECT.PROJECT_NAME),searchName,QueryConstants.CONTAINS,Boolean.FALSE);
		Long currentUserId = ZABUtil.getCurrentUser().getUserId();
		Criteria userCriteria = new Criteria (new Column(PROJECT_USER_ROLE.TABLE,PROJECT_USER_ROLE.USER_ID),currentUserId,QueryConstants.EQUAL);
		c.and(userCriteria);
		Join join = new Join(PROJECT.TABLE, PROJECT_USER_ROLE.TABLE, new String[]{PROJECT.PROJECT_ID}, new String[]{PROJECT_USER_ROLE.PROJECT_ID}, Join.INNER_JOIN);
		projects = Project.getProjectByCriteria(c,join);
		
		return projects;
	}


}
