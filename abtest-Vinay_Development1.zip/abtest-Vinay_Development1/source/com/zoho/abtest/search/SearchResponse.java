//$Id$
package com.zoho.abtest.search;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.common.ZABResponse;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.experiment.ExperimentResponse;
import com.zoho.abtest.project.Project;
import com.zoho.abtest.project.ProjectConstants;
import com.zoho.abtest.project.ProjectResponse;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.abtest.variation.VariationResponse;

public class SearchResponse {

	public static String jsonResponse(HttpServletRequest request,ArrayList<Search> lst) {			
		StringBuffer returnBuffer = new StringBuffer();
		try{
			JSONArray array = getJSONArray(lst);			
			JSONObject json = ZABResponse.updateMetaInfo(request, SearchConstants.API_MODULE, array);
			returnBuffer.append(json);
			json=null;
		}catch(Exception ex){
			
			ex.printStackTrace();
			
		}
		return returnBuffer.toString();
	}
	
	public static JSONArray getJSONArray(ArrayList<Search> lst) throws JSONException {
		JSONArray array = new JSONArray();
		int size =lst.size();
		for (int i=0;i<size;i++) {
			Search result =lst.get(i);
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(SearchConstants.SEARCH_NAME, result.getSearchTerm());
			
			ArrayList<Experiment> experiments  =result.getExperiments();
			JSONArray expResponse  = ExperimentResponse.getJSONArray(experiments);
			
			ArrayList<Project> projects  =result.getProjects();
			JSONArray prjResponse  = ProjectResponse.getJSONArray(projects);
			
			jsonObj.put(ExperimentConstants.API_MODULE_PLURAL, expResponse);
			jsonObj.put(ProjectConstants.API_MODULE_PLURAL, prjResponse);
			jsonObj.put(ZABConstants.SUCCESS,result.getSuccess());
			
			array.put(jsonObj);
		}
		return array;
	}

}
