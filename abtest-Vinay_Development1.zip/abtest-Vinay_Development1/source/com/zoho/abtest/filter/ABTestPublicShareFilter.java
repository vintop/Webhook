//$Id$
package com.zoho.abtest.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.iam.IAMUtil;
import com.adventnet.iam.ServiceOrg;
import com.adventnet.iam.User;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.zoho.abtest.APP_USER;
import com.zoho.abtest.EXPERIMENT;
import com.zoho.abtest.SHARED_REPORT_DETAILS;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.experiment.Experiment;
import com.zoho.abtest.experiment.ExperimentConstants;
import com.zoho.abtest.user.ZABUser;
import com.zoho.abtest.utility.ZABFilter;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUtil;

public class ABTestPublicShareFilter extends ZABFilter{

	private static final Logger LOGGER = Logger.getLogger(ABTestAccessFilter.class.getName());
	public void destroy(){}
	public void doFilter(ServletRequest req,ServletResponse resp,FilterChain chain) throws IOException,ServletException{
		HttpServletRequest request = (HttpServletRequest)req;
		HttpServletResponse response =(HttpServletResponse) resp;
		LOGGER.log(Level.INFO, "ABTest Public Share started");
		ZABUtil.setCurrentRequest(request); 
		startCountingDBCalls();
	

		String shareKey = null;
		String domain = null;
		String requestUri = request.getRequestURI();
		if(requestUri.contains("/share/"))
		{
			String requestUriArr[] = requestUri.split("/");
			int keyIndex = 3;
			int domainIndex = 5;
			if(!requestUri.contains("/pagesense/share/"))	
			{
				keyIndex = 2;
				domainIndex = 4;
			}
			shareKey =  requestUriArr[keyIndex];
			domain = requestUriArr[domainIndex];
		}
	

			try{		
				Long zsoid = ZABServiceOrgUtil.getZSOIDFromDomain(domain);
				if(zsoid != null) {
					ZABUtil.setDBSpace(zsoid.toString());
					Criteria c= new Criteria(new Column(SHARED_REPORT_DETAILS.TABLE,SHARED_REPORT_DETAILS.SHARE_KEY),shareKey,QueryConstants.EQUAL);

					DataObject dobj = ZABModel.getRow(SHARED_REPORT_DETAILS.TABLE, c);
					if(dobj.containsTable(SHARED_REPORT_DETAILS.TABLE)){
						Row row = dobj.getFirstRow(SHARED_REPORT_DETAILS.TABLE);
						Long expId=  (Long)row.get(SHARED_REPORT_DETAILS.EXPERIMENT_ID);
						String expLinkName = Experiment.getExperimentById(expId).getExperimentLinkname();
						Criteria expCri = new Criteria(new Column(EXPERIMENT.TABLE,EXPERIMENT.EXPERIMENT_ID),expId,QueryConstants.EQUAL);
						DataObject expdobj = ZABModel.getRow(EXPERIMENT.TABLE, expCri);
						Boolean makepublic  = (Boolean)expdobj.getFirstValue(EXPERIMENT.TABLE,EXPERIMENT.MAKE_PUBLIC);
						if(makepublic){
							request.setAttribute(ExperimentConstants.EXPERIMENT_LINKNAME, expLinkName);
						}else{
							return;
						}
						
					}else{
						return;
					}

					String dbSpaceId = zsoid.toString();
					ZABUtil.setPortaldomain(domain);
					ZABUtil.setDBSpace(dbSpaceId);
					ZABUtil.setCurrentRequest(request);
					setInputBodyString(request);
				}
				else
				{
					String errorString = ZABAction.getResponseProvider(request).getPortalNotExistsException(domain);
					ZABAction.sendResponse(request, response, errorString);
					return;
				}
			}catch(Exception e){
				LOGGER.log(Level.SEVERE,e.toString(),e);
			}
			
		LOGGER.log(Level.INFO, "ABTest Public Share completed");
		chain.doFilter(request, response);
	}
	
	public void setInputBodyString(HttpServletRequest request)
	{
		try
		{
			String inputString = ZABAction.getInputString(request);
			ZABUtil.setCurrentInputString(inputString);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,ex.toString(),ex);
			ZABUtil.setCurrentInputString("");
		}
	}
	public void startCountingDBCalls()
	{
		ZABUtil.setDBCallCountMap(null);
		Long startTime = ZABUtil.getCurrentTimeInMilliSeconds();
		ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", startTime);
	}
	
	
	
	@Override
	public Logger getLogger() {
		// TODO Auto-generated method stub
		return null;
	}
	

	
}
