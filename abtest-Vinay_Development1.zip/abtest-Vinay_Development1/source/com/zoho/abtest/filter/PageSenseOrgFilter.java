//$Id$
package com.zoho.abtest.filter;

import java.io.IOException;
import java.io.StringReader;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;

import com.adventnet.iam.IAMUtil;
import com.adventnet.iam.User;
import com.adventnet.iam.security.SecurityUtil;
import com.zoho.abtest.adminconsole.AdminConsoleConstants;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.utility.ApplicationProperty;
import com.zoho.abtest.utility.ZABFilter;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.conf.Configuration;

public class PageSenseOrgFilter extends ZABFilter{

	private static final Logger LOGGER = Logger.getLogger(PageSenseOrgFilter.class.getName());
	
	private static final boolean IS_PRODUCTION_MODE =Boolean.parseBoolean(ApplicationProperty.getString("com.abtest.productionmode").trim()); //NO I18N
	private static final boolean IS_EARLY_ACCESS_CHECK_ENABLED =Boolean.parseBoolean(ApplicationProperty.getString("com.abtest.crm.earlyaccess.enable").trim()); //NO I18N
	private static final String CRM_LARID =ApplicationProperty.getString("com.abtest.crm.larid").trim(); //NO I18N
	
	private static final Set<Long> ORG_IDS_TO_ALLOW = new HashSet<Long>();
	
	public static final int ELIGIBLE = 1;
	public static final int REQUEST_RECEIVED = 2;
	public static final int NOT_REGISTERED = 3;
	
	public static final String COOKIE_ZOHOMARK_SRC = "ZohoMarkSrc"; //NO I18N
	public static final String COOKIE_ZOHOMARK_REF = "ZohoMarkRef"; //NO I18N
	public static final String COOKIE_COOKIE_UID = "cookie-uid"; //NO I18N
	
	public static final String COOKIE_MARKETING_SOURCE = "Marketing Source"; //NO I18N
	public static final String COOKIE_LEAD_SOURCE = "Marketing Lead Source"; //NO I18N
	public static final String COOKIE_LAST_SOURCE = "Marketing Last Source"; //NO I18N
	public static final String COOKIE_REFERRAL_URL = "Marketing Referral URL"; //NO I18N
	public static final String COOKIE_USER_ID = "Marketing User id"; //NO I18N
	public static final String SIGNUP_URL = "Signup URL"; //NO I18N
	public static final String FROM_PRODUCT_HUNT = "from_product_hunt"; //NO I18N
	public static final String SWITCH_FROM_OPTIMIZELY = "switch_from_optimizely"; //NO I18N
	
	public static final String CRM_REQUEST_RECEIVED = "Request Received"; //NO I18N
	public static final String CRM_ACTIVATED = "Activated"; //NO I18N
	public static final String REGISTRATION_DATE = "registration_date"; //NO I18N
	static
	{
		String orgIdsToAllow =ApplicationProperty.getString("org.ids.toallow"); //NO I18N
		String[] orgIdsToAllowArr = orgIdsToAllow.split(",");
		for(int i=0;i<orgIdsToAllowArr.length;i++)
		{
			ORG_IDS_TO_ALLOW.add(Long.parseLong(orgIdsToAllowArr[i]));
		}
	}
	
	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}
	
	//This filter will not be called hereafter
	@Override
	public void doFilter(ServletRequest req,ServletResponse resp,FilterChain chain) throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest)req;
		HttpServletResponse response =(HttpServletResponse) resp;
		if(IS_PRODUCTION_MODE)
		{
			LOGGER.log(Level.INFO, "PageSenseOrgFilter started");
			if(skipUrl(request))
			{
				LOGGER.log(Level.INFO, "PageSenseOrgFilter Skip Urls executed");
				chain.doFilter(request, response);
				return;
			}
			User iamUser = IAMUtil.getCurrentUser();
			Long zoid = iamUser.getZOID();
			if(!ORG_IDS_TO_ALLOW.contains(zoid))
			{
				LOGGER.log(Level.SEVERE, "PageSenseOrgFilter - OrgId:"+zoid+" tried to access your app.");
				String errorString = ZABAction.getResponseProvider(request).getOrgNoAccessException();
				ZABAction.sendResponse(request, response, errorString);
				return;
			}
			LOGGER.log(Level.INFO, "PageSenseOrgFilter Completed");
		}
		chain.doFilter(request, response);
	}

	public static int checkAppAccessUserEligibility()
	{
		int status = NOT_REGISTERED;
		try
		{
			LOGGER.log(Level.INFO, "INside checkAppAccessUserEligibility:BOOL:IS_PRODUCTION_MODE::IS_EARLY_ACCESS_CHECK_ENABLED"+IS_PRODUCTION_MODE+"::"+IS_EARLY_ACCESS_CHECK_ENABLED);
			if(IS_PRODUCTION_MODE && IS_EARLY_ACCESS_CHECK_ENABLED)
			{
				LOGGER.log(Level.INFO, "INside if cond of (IS_PRODUCTION_MODE && IS_EARLY_ACCESS_CHECK_ENABLED)");
				Long zoid = IAMUtil.getCurrentUser().getZOID();
				if(ORG_IDS_TO_ALLOW.contains(zoid))
				{
					status = ELIGIBLE;
				}
				else
				{
					String emailAddr = IAMUtil.getCurrentUser().getPrimaryEmail();
					String userStatus = getEarlyAccessUserStatusFromCRM(emailAddr);
					if(userStatus != null)
					{
						if(userStatus.equals(CRM_ACTIVATED))
						{
							status = ELIGIBLE;
						}
						else if(userStatus.equals(CRM_REQUEST_RECEIVED))
						{
							status = REQUEST_RECEIVED;
						}
					}
					else
					{
						status = NOT_REGISTERED;
					}
				}
			}
			else
			{
				LOGGER.log(Level.INFO, "By Passed crm check. working!!!");
				status = ELIGIBLE;
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in getEarlyAccessUserStatus",ex);
			status = NOT_REGISTERED;
		}
		return status;
	}
	
	public static String getEarlyAccessUserStatusFromCRM(String emailAddr)
	{
		String userStatus = null; 
		HttpClient httpclient = null;
		PostMethod post = null;
		try
		{
			String criteria = "((Zoho Service:PageSense)AND(Edition Registered:EarlyAccess)AND(Email:${emailadddr}))"; //No I18N
			criteria = criteria.replace("${emailadddr}", emailAddr);  //No I18N
			String authtoken = Configuration.getString("pagesense.crmapi.authtoken");
			String targetURL = "https://crm.zoho.com/crm/private/json/Potentials/searchRecords";  //No I18N
			post = new PostMethod(targetURL);
	        post.setParameter("authtoken",authtoken);  //No I18N
	        post.setParameter("scope","crmapi");  //No I18N
	        post.setParameter("criteria",criteria);  //No I18N
	        post.setParameter("selectColumns","Potentials(User Status)");  //No I18N
	        httpclient = new HttpClient();
	        httpclient.executeMethod(post);
	        String postResp = post.getResponseBodyAsString();
	        JSONObject postRespJson = new JSONObject(postResp);
	        JSONObject responseJson = postRespJson.getJSONObject("response");
	        if(responseJson.has("result"))
	        {
	        	JSONObject resultJson = responseJson.getJSONObject("result");
	        	JSONObject potentialJson = resultJson.getJSONObject("Potentials");
	        	//TODO - also handle if the user is registered many times for early access - then it will be arr
	        	JSONObject rowJson = null;
	        	Object rowObj = potentialJson.get("row");
	        	if(rowObj instanceof JSONArray)
	        	{
	        		rowJson = ((JSONArray)rowObj).getJSONObject(0);
	        	}
	        	else
	        	{
	        		rowJson = (JSONObject)rowObj;
	        	}
	        	JSONArray flArr = rowJson.getJSONArray("FL");  //No I18N
	        	userStatus = flArr.getJSONObject(1).getString("content");
	        	LOGGER.log(Level.INFO, "Early access status for {0} is {1}",new String[]{emailAddr,userStatus});
	        }
	        
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in getEarlyAccessUserStatus",ex);
		}
		finally
		{
			try
			{
				if(post != null)
				{
					post.releaseConnection();
				}
			}
			catch(Exception ex)
			{
				LOGGER.log(Level.SEVERE, "Exception occurred in getEarlyAccessUserStatusFromCRM release post connection",ex);
			}
		}
		return userStatus;
	}
	
	public static boolean pushPotentialRequestIntoCRM(User user, String portalName, HashMap<String, String> acHs)
	{
		boolean success = false;
		try
		{
			if(IS_PRODUCTION_MODE)
			{
				//Get country details
				//JSONObject ipDetailsJson = ZABUtil.getIpAddressDetails(ipAddress);
				String country = user.getCountry() != null ? user.getCountry() : "";
				String region = "";
				String city = "";
				String ipaddress = acHs.get(AdminConsoleConstants.IPADDRESS);
				
				if(StringUtils.isNotEmpty(ipaddress))
				{
					//Get country details from IP Address
					JSONObject ipDetailsJson = ZABUtil.getIpAddressDetails(ipaddress);
					//Used hyphen since the api returns hyphen if ip is invalid kinda scenarios
					country = ipDetailsJson.has("COUNTRY_NAME") ? ipDetailsJson.get("COUNTRY_NAME").toString() : "-"; //NO I18N
					region = ipDetailsJson.has("REGION") ? ipDetailsJson.get("REGION").toString() : "-"; //NO I18N
					city = ipDetailsJson.has("CITY") ? ipDetailsJson.get("CITY").toString() : "-"; //NO I18N
				}
				
				String name = user.getDisplayName();
				//String regionName = null;
				//countryName = ipDetailsJson.has("COUNTRY_NAME") ? ipDetailsJson.get("COUNTRY_NAME").toString() : ""; //NO I18N
				//regionName = ipDetailsJson.has("REGION") ? ipDetailsJson.get("REGION").toString() : ""; //NO I18N
				
				String emailAddr = user.getPrimaryEmail();
				String addressCountry = acHs.get(AdminConsoleConstants.COUNTRY_NAME) != null ? acHs.get(AdminConsoleConstants.COUNTRY_NAME) : "";
				Boolean newsletterFlag = acHs.get(AdminConsoleConstants.NEWSLETTER_FLAG) != null ? Boolean.parseBoolean(acHs.get(AdminConsoleConstants.NEWSLETTER_FLAG)) : false;
				//Check CRM Contacts
				String contactId = getCRMContactId(emailAddr);
				if(contactId == null)
				{
					contactId = pushContactsIntoCRM(emailAddr, name, country,addressCountry,newsletterFlag);
				}
				boolean isAlreadyRegistered = isAlreadyRegisteredPotential(emailAddr);
				if(!isAlreadyRegistered)
				{
					String zsoid = acHs.get(AdminConsoleConstants.ZSOID) != null ? acHs.get(AdminConsoleConstants.ZSOID) : "";
					String registeredDate = acHs.get(REGISTRATION_DATE);
					String marketingSource = acHs.get(COOKIE_MARKETING_SOURCE) != null ? acHs.get(COOKIE_MARKETING_SOURCE) : "";
					String markLeadSource = acHs.get(COOKIE_LEAD_SOURCE) != null ? acHs.get(COOKIE_LEAD_SOURCE) : "";
					String markLastSource = acHs.get(COOKIE_LAST_SOURCE) != null ? acHs.get(COOKIE_LAST_SOURCE) : "";
					String markReffUrl = acHs.get(COOKIE_REFERRAL_URL) != null ? acHs.get(COOKIE_REFERRAL_URL) : "";
					String markUserId = acHs.get(COOKIE_USER_ID) != null ? acHs.get(COOKIE_USER_ID) : "";
					String markSignupUrl = acHs.get(SIGNUP_URL) != null ? acHs.get(SIGNUP_URL) : "";
					//Push into CRM Potentials
					String templatePath = "/../../crmtemplate/potential.xml"; //No I18N
					String url = PageSenseOrgFilter.class.getResource(templatePath).getPath();
					String potentialTemplate = new String(Files.readAllBytes(Paths.get(url)));
					potentialTemplate = potentialTemplate.replace("${contactId}", contactId);  //No I18N
					potentialTemplate = potentialTemplate.replace("${potentialemail}", emailAddr);  //No I18N
					potentialTemplate = potentialTemplate.replace("${country}", country);  //No I18N
					potentialTemplate = potentialTemplate.replace("${city}", city);  //No I18N
					potentialTemplate = potentialTemplate.replace("${state}", region);  //No I18N
					potentialTemplate = potentialTemplate.replace("${portalname}", portalName);  //No I18N
					potentialTemplate = potentialTemplate.replace("${addressCountry}", addressCountry);  //No I18N
					potentialTemplate = potentialTemplate.replace("${newsletterFlag}", newsletterFlag.toString());  //No I18N
					
					potentialTemplate = potentialTemplate.replace("${marketingSource}", marketingSource);  //No I18N
					potentialTemplate = potentialTemplate.replace("${markLeadSource}", markLeadSource);  //No I18N
					potentialTemplate = potentialTemplate.replace("${markLastSource}", markLastSource);  //No I18N
					potentialTemplate = potentialTemplate.replace("${markReffUrl}", markReffUrl);  //No I18N
					potentialTemplate = potentialTemplate.replace("${markUserId}", markUserId);  //No I18N
					potentialTemplate = potentialTemplate.replace("${markSignupUrl}", markSignupUrl);  //No I18N
					potentialTemplate = potentialTemplate.replace("${registrationDate}", registeredDate);  //No I18N
					potentialTemplate = potentialTemplate.replace("${orgId}", zsoid);  //No I18N
					//potentialTemplate = potentialTemplate.replace("${state}", regionName);  //No I18N
					//potentialTemplate = URLEncoder.encode(potentialTemplate, "UTF-8");  //No I18N
					
					String targetURL = "https://crm.zoho.com/crm/private/xml/Potentials/insertRecords";  //No I18N
					HashMap<String, String> parameters = new HashMap<String, String>();
					potentialTemplate = URLEncoder.encode(potentialTemplate.toString(), "UTF-8");   //No I18N
					parameters.put("larid", CRM_LARID);
					parameters.put("xmlData", potentialTemplate);
			        String postResp = ZABUtil.getCRMHttpResponse(targetURL, parameters);
			        
			        DocumentBuilder documentBuilder = SecurityUtil.getDocumentBuilder();
			        InputSource is = new InputSource(new StringReader(postResp));
					Document document = documentBuilder.parse(is);
					if(document.getElementsByTagName("result").getLength() > 0)
					{
						success = true;
						LOGGER.log(Level.INFO, "Pushed CRM request for {0}",new String[]{emailAddr});
					}
					else
					{
						success = false;
						LOGGER.log(Level.INFO, "Pushed CRM request failed for {0}",new String[]{emailAddr});
					}
				}
				else
				{
					//Already registered
					success = true;
					LOGGER.log(Level.INFO, "Email already registered for CRM, so not now. {0}",new String[]{emailAddr});
				}
				
			}
			else
			{
				success = true;
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in pushRequestIntoCRM - {0}",new String[]{user.getPrimaryEmail()});
			LOGGER.log(Level.SEVERE, "Exception occurred in pushRequestIntoCRM ", ex);
			success = false;
		}
		return success;
	}
	
	public static void pushZsoidIntoCrmPotentials(String emailAddr, Long zsoid, String portalDomain)throws Exception
	{
		String criteria = "((Zoho Service:PageSense)AND(Email:${emailadddr})AND(Portal Name:${portalName}))"; //No I18N
		criteria = criteria.replace("${emailadddr}", emailAddr);  //No I18N
		criteria = criteria.replace("${portalName}", portalDomain);  //No I18N
		String targetURL = "https://crm.zoho.com/crm/private/json/Potentials/searchRecords";  //No I18N
		HashMap<String, String> parameters = new HashMap<String, String>();
		criteria = URLEncoder.encode(criteria.toString(), "UTF-8");    //No I18N
		parameters.put("criteria",criteria);
		String selectColumns = "Potentials(POTENTIALID)";    //No I18N
		selectColumns = URLEncoder.encode(selectColumns.toString(), "UTF-8");    //No I18N
		parameters.put("selectColumns",selectColumns);
        String postResp = ZABUtil.getCRMHttpResponse(targetURL, parameters);
        JSONObject postRespJson = new JSONObject(postResp);
        JSONObject responseJson = postRespJson.getJSONObject("response");
        if(responseJson.has("result"))
        {
        	JSONObject resultJson = responseJson.getJSONObject("result");
        	JSONObject contactJson = resultJson.getJSONObject("Potentials");
        	JSONObject rowJson = null;
        	Object rowObj = contactJson.get("row");
        	if(rowObj instanceof JSONArray)
        	{
        		rowJson = ((JSONArray)rowObj).getJSONObject(0);
        	}
        	else
        	{
        		rowJson = (JSONObject)rowObj;
        	}
        	JSONObject jsonObj = rowJson.getJSONObject("FL");  //No I18N
        	String potentialId = jsonObj.getString("content");
        	LOGGER.log(Level.INFO, "Potential Id for {0} is {1}",new String[]{emailAddr,potentialId});
        	
        	String potentialTemplate = "<Potentials><row no=\"1\"><FL val=\"ORG ID\">${zsoid}</FL></row></Potentials>"; //No I18N
        	potentialTemplate = potentialTemplate.replace("${zsoid}", zsoid.toString()); // No I18N
        	String updateURL = "https://crm.zoho.com/crm/private/xml/Potentials/updateRecords";  //No I18N
			HashMap<String, String> updateParams = new HashMap<String, String>();
			potentialTemplate = URLEncoder.encode(potentialTemplate.toString(), "UTF-8");   //No I18N
			updateParams.put("id", potentialId);
			updateParams.put("xmlData", potentialTemplate);
	        String updateResp = ZABUtil.getCRMHttpResponse(updateURL, updateParams);
	        
	        DocumentBuilder documentBuilder = SecurityUtil.getDocumentBuilder();
	        InputSource is = new InputSource(new StringReader(updateResp));
			Document document = documentBuilder.parse(is);
			if(document.getElementsByTagName("result").getLength() > 0)
			{
				LOGGER.log(Level.INFO, "Pushed ZSOID in CRM request for {0}",new String[]{emailAddr});
			}
			else
			{
				LOGGER.log(Level.INFO, "Pushed ZSOID in CRM request failed for {0}",new String[]{emailAddr});
			}
        }
        else
        {
        	LOGGER.log(Level.INFO, "No Potentials found for {0} ",new String[]{emailAddr});
        }
	}
	
	public static boolean isAlreadyRegisteredPotential(String emailAddr)
	{
		boolean isAlreadyRegistered = false;
		try
		{
			String criteria = "((Zoho Service:PageSense)AND(Email:${emailadddr}))"; //No I18N
			criteria = criteria.replace("${emailadddr}", emailAddr);  //No I18N
			String targetURL = "https://crm.zoho.com/crm/private/json/Potentials/searchRecords";  //No I18N
			HashMap<String, String> parameters = new HashMap<String, String>();
			criteria = URLEncoder.encode(criteria.toString(), "UTF-8");    //No I18N
			parameters.put("criteria",criteria);
			String selectColumns = "Potentials(Email)";    //No I18N
			selectColumns = URLEncoder.encode(selectColumns.toString(), "UTF-8");    //No I18N
			parameters.put("selectColumns",selectColumns);
	        String postResp = ZABUtil.getCRMHttpResponse(targetURL, parameters);
	        JSONObject postRespJson = new JSONObject(postResp);
	        JSONObject responseJson = postRespJson.getJSONObject("response");
	        if(responseJson.has("result"))
	        {
	        	isAlreadyRegistered = true;
	        }
		}
		catch(Exception ex)
		{
			isAlreadyRegistered = false;
			LOGGER.log(Level.SEVERE, "Exception occurred in isAlreadyRegisteredPotential - {0}",new String[]{emailAddr});
			LOGGER.log(Level.SEVERE, "Exception occurred in isAlreadyRegisteredPotential",ex);
		}
		return isAlreadyRegistered;
	}
	
	public static String getCRMContactId(String emailAddr)
	{
		String contactId = null;
		try
		{
			String criteria = "(Email:${emailadddr})"; //No I18N
			criteria = criteria.replace("${emailadddr}", emailAddr);  //No I18N
			String targetURL = "https://crm.zoho.com/crm/private/json/Contacts/searchRecords";  //No I18N
			HashMap<String, String> parameters = new HashMap<String, String>();
			criteria = URLEncoder.encode(criteria.toString(), "UTF-8");    //No I18N
			parameters.put("criteria", criteria);
			String selectColumns = "Contacts(CONTACTID)";    //No I18N
			selectColumns = URLEncoder.encode(selectColumns.toString(), "UTF-8");    //No I18N
			parameters.put("selectColumns", selectColumns);
	        String postResp = ZABUtil.getCRMHttpResponse(targetURL, parameters);
	        JSONObject postRespJson = new JSONObject(postResp);
	        JSONObject responseJson = postRespJson.getJSONObject("response");
	        if(responseJson.has("result"))
	        {
	        	JSONObject resultJson = responseJson.getJSONObject("result");
	        	JSONObject contactJson = resultJson.getJSONObject("Contacts");
	        	//TODO - also handle if the user is registered many times for early access - then it will be arr
	        	JSONObject rowJson = null;
	        	Object rowObj = contactJson.get("row");
	        	if(rowObj instanceof JSONArray)
	        	{
	        		rowJson = ((JSONArray)rowObj).getJSONObject(0);
	        	}
	        	else
	        	{
	        		rowJson = (JSONObject)rowObj;
	        	}
	        	JSONObject jsonObj = rowJson.getJSONObject("FL");  //No I18N
	        	contactId = jsonObj.getString("content");
	        	LOGGER.log(Level.INFO, "Contact Id for {0} is {1}",new String[]{emailAddr,contactId});
	        }
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in getCRMContactId - {0}",new String[]{emailAddr});
			LOGGER.log(Level.SEVERE, "Exception occurred in getCRMContactId}",ex);
		}
		return contactId;
	}
	
	public static String pushContactsIntoCRM(String emailAddr, String name, String countryName,String addressCountry,Boolean newsletterFlag)
	{
		String contactId = null;
		try
		{
			//Push into CRM Contacts
			String templatePath = "/../../crmtemplate/contact.xml"; //No I18N
			String url = PageSenseOrgFilter.class.getResource(templatePath).getPath();
			String contactTemplate = new String(Files.readAllBytes(Paths.get(url)));
			contactTemplate = contactTemplate.replace("${contactName}", name);  //No I18N
			contactTemplate = contactTemplate.replace("${contactemail}", emailAddr);  //No I18N
			contactTemplate = contactTemplate.replace("${country}", countryName);  //No I18N
			contactTemplate = contactTemplate.replace("${mailingCountry}", addressCountry);  //No I18N
			contactTemplate = contactTemplate.replace("${newsletterFlag}", newsletterFlag.toString());  //No I18N
			//potentialTemplate = URLEncoder.encode(potentialTemplate, "UTF-8");  //No I18N
			
			String targetURL = "https://crm.zoho.com/crm/private/xml/Contacts/insertRecords";  //No I18N
			HashMap<String, String> parameters = new HashMap<String, String>();
			contactTemplate = URLEncoder.encode(contactTemplate.toString(), "UTF-8");    //No I18N
			parameters.put("xmlData", contactTemplate);
	        String postResp = ZABUtil.getCRMHttpResponse(targetURL, parameters);
	        
	        DocumentBuilder documentBuilder = SecurityUtil.getDocumentBuilder();
	        InputSource is = new InputSource(new StringReader(postResp));
			Document document = documentBuilder.parse(is);
			if(document.getElementsByTagName("result").getLength() > 0)
			{
				Node node = document.getElementsByTagName("recorddetail").item(0);
				contactId = node.getFirstChild().getTextContent();
				//NodeList flNodeList = document.getElementsByTagName("fl");
				//contactId = flNodeList.item(0).getTextContent();
				LOGGER.log(Level.INFO, "pushContactsIntoCRM request for {0} - {1}",new String[]{emailAddr,contactId});
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in pushContactsIntoCRM - {0}",new String[]{emailAddr});
			LOGGER.log(Level.SEVERE, "Exception occurred in pushContactsIntoCRM",ex);
		}
		return contactId;
	}
	
	public static HashMap<String, String> getSignUpRequestCookiesForCrmPotentials(HttpServletRequest request)
	{
		HashMap<String, String> hs = new HashMap<String, String>();
		try
		{
			Cookie[] cookieArr = request.getCookies();
			if(cookieArr != null && cookieArr.length > 0)
			{
				for(Cookie cookieObj:cookieArr)
				{
					String cookieName = cookieObj.getName();
					String cookieValue = cookieObj.getValue();
					if(cookieName != null && cookieValue != null)
					{
						switch(cookieName)
						{
						case COOKIE_ZOHOMARK_SRC:
							String[] zohoMarkSrcArr = cookieValue.split(Pattern.quote("|")); // Split by special character pipe symbol
							try
							{
								LOGGER.log(Level.INFO, "Potential Cookie value {0} - {1}", new String[]{cookieName,cookieValue});
								if(cookieValue.contains("producthunt"))
								{
									hs.put(FROM_PRODUCT_HUNT, Boolean.TRUE.toString());
								}
								hs.put(COOKIE_MARKETING_SOURCE, zohoMarkSrcArr[0]);
								hs.put(COOKIE_LEAD_SOURCE, zohoMarkSrcArr[1]);
								hs.put(COOKIE_LAST_SOURCE, zohoMarkSrcArr[2]);
							}
							catch(Exception ex)
							{
								LOGGER.log(Level.SEVERE, "Exception occurred in COOKIE_ZOHOMARK_SRC getSignUpRequestCookies",ex);
							}
							break;
						case COOKIE_ZOHOMARK_REF:
							if(cookieValue.contains("ref=producthunt"))
							{
								hs.put(FROM_PRODUCT_HUNT, Boolean.TRUE.toString());
							}
							else if(cookieValue.contains("switch-from-optimizely"))
							{
								hs.put(SWITCH_FROM_OPTIMIZELY, Boolean.TRUE.toString());
							}
							hs.put(COOKIE_REFERRAL_URL, cookieValue);
							LOGGER.log(Level.INFO, "Potential Cookie value {0} - {1}", new String[]{cookieName,cookieValue});
							break;
						case COOKIE_COOKIE_UID:
							hs.put(COOKIE_USER_ID, cookieValue);
							LOGGER.log(Level.INFO, "Potential Cookie value {0} - {1}", new String[]{cookieName,cookieValue});
							break;	
						}
					}
				}
			}
			
			String referer = request.getHeader("referer");
			if(StringUtils.isNotEmpty(referer))
			{
				hs.put(SIGNUP_URL, referer);
			}
			LOGGER.log(Level.INFO, "Cookie values - {0}", new String[]{hs.toString()});
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in getSignUpRequestCookies",ex);
		}
		return hs;
	}
	
	public static void copyPotentialValuesIntoACHs(HashMap<String, String> potentialHs, HashMap<String, String> acHs)
	{
		try
		{
			for(Map.Entry<String, String> potentialEntry:potentialHs.entrySet())
			{
				acHs.put(potentialEntry.getKey(), potentialEntry.getValue());
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occurred in copyPotentialValuesIntoACHs",ex);
		}
	}
	
	@Override
	public Logger getLogger() {
		// TODO Auto-generated method stub
		return LOGGER;
	}
	
}
