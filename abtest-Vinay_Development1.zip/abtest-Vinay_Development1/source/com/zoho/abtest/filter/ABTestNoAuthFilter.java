//$Id$
package com.zoho.abtest.filter;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zoho.abtest.utility.ZABFilter;
import com.zoho.abtest.utility.ZABUtil;

public class ABTestNoAuthFilter extends ZABFilter{
	
	private static final Logger LOGGER = Logger.getLogger(ABTestNoAuthFilter.class.getName());

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws IOException, ServletException
	{
		HttpServletRequest request = (HttpServletRequest)req;
		HttpServletResponse response =(HttpServletResponse) resp;
		LOGGER.log(Level.INFO, "Entered into ABTestNoAuthFilter");
		ZABUtil.setCurrentRequest(request);
	
		LOGGER.log(Level.INFO, "Completed ABTestNoAuthFilter");
		chain.doFilter(request, response);
	}

	@Override
	public Logger getLogger() {
		// TODO Auto-generated method stub
		return null;
	}

}
