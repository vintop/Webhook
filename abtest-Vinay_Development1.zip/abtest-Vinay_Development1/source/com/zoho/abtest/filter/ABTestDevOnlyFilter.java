//$Id$
package com.zoho.abtest.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;

import com.adventnet.collaboration.Collaboration;
import com.adventnet.iam.IAMUtil;
import com.adventnet.iam.ServiceOrg;
import com.adventnet.iam.User;
import com.adventnet.mfw.bean.BeanUtil;
import com.zoho.abtest.adminconsole.AdminConsoleConstants;
import com.zoho.abtest.adminconsole.AdminConsoleWrapper;
import com.zoho.abtest.adminconsole.AdminConsoleConstants.AcOperationType;
import com.zoho.abtest.license.LicenseConstants;
import com.zoho.abtest.license.PortalLicenseMapping;
import com.zoho.abtest.license.LicenseConstants.License;
import com.zoho.abtest.listener.ZABNotifier;
import com.zoho.abtest.portal.PortalAction;
import com.zoho.abtest.tour.ZABTour;
import com.zoho.abtest.utility.ApplicationProperty;
import com.zoho.abtest.utility.ZABFilter;
import com.zoho.abtest.utility.ZABServiceOrgUtil;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.conf.Configuration;

public class ABTestDevOnlyFilter extends ZABFilter {
	private static final Logger LOGGER = Logger.getLogger(ABTestDevOnlyFilter.class.getName());

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		HttpServletRequest request = (HttpServletRequest)req;
		HttpServletResponse response =(HttpServletResponse) resp;
		boolean isDevMode = Boolean.parseBoolean(ApplicationProperty.getString("com.abtest.portaldevmode"));
		if(isDevMode)
		{
			LOGGER.log(Level.INFO, "ABTestDevOnlyFilter started");
			
			User iamUser = IAMUtil.getCurrentUser();
			if(skipUrl(request)) {
				chain.doFilter(req, resp);
				return;
			}
			ZABTour.populateDefaultTourData();
			if(iamUser!=null)
			{
				try
				{
					Long zsoid = null;
					
					//have to use IAMHandler to get the current service org
					ServiceOrg currentServiceOrg = IAMUtil.getCurrentServiceOrg();
					
					if(currentServiceOrg != null)
					{
						zsoid = currentServiceOrg.getZSOID();
						ZABUtil.setPortaldomain(currentServiceOrg.getDomains().get(0).getDomain());
					}
					
					if(zsoid != null)
					{
						boolean isServiceOrgMember = ZABServiceOrgUtil.isServiceOrgMember(zsoid, iamUser.getZUID());
						if(isServiceOrgMember)
						{
							String dbSpaceId = zsoid.toString();
							Collaboration c = (Collaboration)BeanUtil.lookup("CollaborationBean");	
							if(!(c.dataSpaceExists(dbSpaceId))){
								synchronized(this)
								{
									if(!(c.dataSpaceExists(dbSpaceId))){
										//Admin console record - portal add workaround for dev
										ServiceOrg serviceOrg = ZABServiceOrgUtil.getServiceOrg(zsoid);
										HashMap<String, String> acHs = new HashMap<String, String>();
										acHs.put(AdminConsoleConstants.ZSOID, dbSpaceId.toString());
										acHs.put(AdminConsoleConstants.PORTAL_NAME, serviceOrg.getOrgName());
										acHs.put(AdminConsoleConstants.PORTAL_DOMAIN, serviceOrg.getDomains().get(0).getDomain());
										acHs.put(AdminConsoleConstants.CREATED_ZUID, String.valueOf(serviceOrg.getCreatedBy()));
										acHs.put(AdminConsoleConstants.CREATED_TIME,  String.valueOf(serviceOrg.getCreatedTime()));
										AdminConsoleWrapper acWrapper = new AdminConsoleWrapper();
										acWrapper.setValueHs(acHs);
										acWrapper.setOperationType(AcOperationType.PORTAL_CREATE);
										ZABNotifier.notifyListeners(AdminConsoleConstants.ADMIN_CONSOLE_MODULE_NAME,acWrapper);
										
										new PortalAction().dbSpaceCreation(iamUser, dbSpaceId, request,"");
										//Assigning trial license
										Integer licenseTimespan = LicenseConstants.MONTH_DAYS_COUNT;
										Long startTime = ZABUtil.getCurrentTimeInMilliSeconds();
										Long endTime = ZABUtil.getNthServerDayInLong(startTime, licenseTimespan) - 1;
										
										ArrayList<HashMap<String, String>> addonList = new ArrayList<HashMap<String,String>>();
										Long storeAddonId = 0l;
						                Integer totalCount = LicenseConstants.TRIAL_VISITOR_COUNT;
						                HashMap<String,String> hs = new HashMap<String, String>();
						                hs.put(LicenseConstants.STORE_ADDON_ID, storeAddonId.toString());
						                hs.put(LicenseConstants.TOTAL_COUNT, totalCount.toString());
						                addonList.add(hs);
										PortalLicenseMapping.assignLicenseToPortal(License.TRIAL.getLicenseType(), zsoid, false,startTime,endTime,null,null, addonList);
									}
								}
							}
						}
					}
				}
				catch(Exception e)
				{
					LOGGER.log(Level.SEVERE,e.toString(),e);
				}
			}
			LOGGER.log(Level.INFO, "ABTestDevOnlyFilter completed");
		}
		
		
		chain.doFilter(request, response);
	}

	@Override
	public Logger getLogger() {
		// TODO Auto-generated method stub
		return LOGGER;
	}

}
