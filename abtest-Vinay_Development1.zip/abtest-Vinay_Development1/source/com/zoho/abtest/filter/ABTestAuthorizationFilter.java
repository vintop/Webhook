//$Id$
package com.zoho.abtest.filter;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;

import com.adventnet.iam.security.ActionRule;
import com.adventnet.iam.security.IAMSecurityException;
import com.adventnet.iam.security.SecurityRequestWrapper;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABConstants;
import com.zoho.abtest.user.Feature;
import com.zoho.abtest.user.FeatureConstants;
import com.zoho.abtest.user.FeatureConstants.AppFeatures;
import com.zoho.abtest.user.ProjectUserRoleConstants;
import com.zoho.abtest.user.ZABUser;
import com.zoho.abtest.utility.AuthorizationFilterUtil;
import com.zoho.abtest.utility.ZABFilter;
import com.zoho.abtest.utility.ZABUtil;

public class ABTestAuthorizationFilter extends ZABFilter {

	private static final Logger LOGGER = Logger.getLogger(ABTestAuthorizationFilter.class.getName());

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse resp, FilterChain filterChain) throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest)req;
		HttpServletResponse response =(HttpServletResponse) resp;
		try
		{
			if(skipUrl(request)) {
				filterChain.doFilter(req, resp);
				return;
			}
			
			LOGGER.log(Level.INFO,"Entered into Authorisation filter");
			ZABUser zabUser = ZABUtil.getCurrentUser();
			if(zabUser != null)
			{
				if(!checkUserPermission(request, response)) {
					return;
				}
			}
			LOGGER.log(Level.INFO,"Authorisation completed successfully");
		}
		catch(Exception e)
		{
			LOGGER.log(Level.INFO,"Authorisation failed");
			LOGGER.log(Level.SEVERE,e.toString(),e);
		}
		filterChain.doFilter(req, resp);
	}

	public Boolean checkUserPermission(HttpServletRequest request, HttpServletResponse response) throws IOException
	{
		SecurityRequestWrapper secureWrapper = null;
		try
		{
			secureWrapper = SecurityRequestWrapper.getInstance(request);
		}
		catch (IAMSecurityException e)
		{
			LOGGER.log(Level.SEVERE,e.toString(),e);
		}
		if (secureWrapper == null)
		{
			LOGGER.log(Level.INFO, "Skipping Role Check as the URL {0} is skipped by SecurityFilter", request);
			return true;
		}else{
			ActionRule actionRule = secureWrapper.getURLActionRule();
			Boolean canAccess = isAllowedToAccess(request, response, actionRule);
			if(canAccess == null)
			{
				return false;
			}
			if (!canAccess)
			{
				String errorString = ZABAction.getResponseProvider(request).getAccessDeniedResponse();
				ZABAction.sendResponse(request, response, errorString);
			}
			return canAccess;
		}
	}
	
	public Boolean isAllowedToAccess(HttpServletRequest request, HttpServletResponse response, ActionRule actionRule)
	{		
		String urlPermission = actionRule.getCustomAttribute("permissions");//No I18N
		
		if(urlPermission==null) {
			return true;
		}
		
		//Special cases - START
		//Same Api for portal level and project level
		String moduleIdentifier = actionRule.getCustomAttribute("moduleidentifier");//No I18N
		if(moduleIdentifier.equals("projectuserrole"))
		{
			String projectLinkName = request.getParameter(ProjectUserRoleConstants.PROJECT_LINK_NAME);
			if(StringUtils.isEmpty(projectLinkName))
			{
				if(ZABUtil.getCurrentUser().getIsAdmin() || urlPermission.equals(AppFeatures.GETPROJECTUSERROLE.getFeature()))
				{
					return true;
				}
				else
				{
					return false;
				}
			}
		}
		//Create project can be done by Admin only
		if(urlPermission.equals(FeatureConstants.AppFeatures.CREATEPROJECT.getFeature()))
		{
			if(ZABUtil.getCurrentUser().getIsAdmin())
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		//Special cases END
		
		String method = actionRule.getCustomAttribute("method");//No I18N
		if(method!=null&&method.equals("POST") && urlPermission!=null)
		{
			String finalmethod = request.getParameter("method");
			String[] featName = urlPermission.split("_");
			if(finalmethod!=null) {
				
				if(finalmethod.equalsIgnoreCase("GET")){
					featName[0] = "get"; //No I18N
				}
				if(finalmethod.equalsIgnoreCase("DELETE")){
					featName[0] = "delete"; //No I18N
				}
				urlPermission = StringUtils.join(featName, "_");
			}
		}
		
		try{
			HashMap<String, String> hs = AuthorizationFilterUtil.getProjectDetailsFromApi(request, actionRule);
			
			boolean canAccess = Boolean.parseBoolean(hs.get(ZABConstants.CAN_ACCESS));
			
			if(canAccess)
			{
				return true;
			}
			
			String projectIdStr = hs.get(ZABConstants.PROJECT_ID);
			if(StringUtils.isEmpty(projectIdStr))
			{
				String errorString = ZABAction.getResponseProvider(request).getNoSuchResourceResponse();
				ZABAction.sendResponse(request, response, errorString);
				return null;
			}
			else
			{
				Long projectId = Long.parseLong(projectIdStr);
				Long userId = ZABUtil.getCurrentUser().getUserId();
				List<String> featuresList = Feature.getFeatureNameList(projectId, userId);
				if(featuresList.contains(urlPermission))
				{
					return true;
				}
			}
			
		}catch(Exception ex){
			LOGGER.log(Level.SEVERE,ex.toString(),ex);
		}		 
		return false;
	}
	
	@Override
	public Logger getLogger() {
		return LOGGER;
	}
}
