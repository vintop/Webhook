//$Id$
package com.zoho.abtest.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.iam.IAMUtil;
import com.adventnet.iam.ServiceOrg;
import com.adventnet.iam.User;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.sas.ds.SASThreadLocal;
import com.adventnet.sas.security.filter.DBAssociator;
import com.zoho.abtest.APP_USER;
import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABModel;
import com.zoho.abtest.user.ZABUser;
import com.zoho.abtest.utility.ZABFilter;
import com.zoho.abtest.utility.ZABUtil;
import com.zoho.zohoone.ZohoOneUtil;
import com.zoho.zohoone.vo.ZohoOneOrg;

public class ABTestAccessFilter extends ZABFilter{
	private static final Logger LOGGER = Logger.getLogger(ABTestAccessFilter.class.getName());
	public void destroy(){}
	public void doFilter(ServletRequest req,ServletResponse resp,FilterChain chain) throws IOException,ServletException{
		HttpServletRequest request = (HttpServletRequest)req;
		HttpServletResponse response =(HttpServletResponse) resp;
		LOGGER.log(Level.INFO, "ABTest Access started");
		ZABUtil.setCurrentRequest(request); 
		startCountingDBCalls();
		if(skipUrl(request)) {
			chain.doFilter(req, resp);
			return;
		}
		User iamUser = IAMUtil.getCurrentUser();
		//iamUser.getTimezone();
	
//		ZABTableCreationBean userAction;
//		try {
//			userAction = (ZABTableCreationBean)BeanUtil.lookup("ZABTableCreationBean",ZABUtil.getCurrentUserDbSpace());
//			userAction.createHeatmapCumulativeHourTable();
//			userAction.createHeatmapDataTable();
//		} catch (Exception e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
		//userAction.createProjectJSONTable();
		
		if(iamUser!=null){
			try{		
				//String uName = request.getUserPrincipal().getName();
				//startIntrumentation(iamUser, request);
				//Long userId = SASThreadLocal.getUserId();
				//String loginName = SASThreadLocal.getLoginName();
				//String schemaName = SASThreadLocal.getSchemaName();
				//DBAssociator dbAssociator;
				Long zsoid = null;
				String domain =  ZABUtil.getDomainFromPortalRequest(request);
				
				//have to use IAMHandler to get the current service org
				ServiceOrg currentServiceOrg = IAMUtil.getCurrentServiceOrg();
				
				if(currentServiceOrg != null)
				{
					zsoid = currentServiceOrg.getZSOID();
				}
				
				if(zsoid != null)
				{
					String dbSpaceId = zsoid.toString();
					
					ZABUtil.setPortaldomain(currentServiceOrg.getDomains().get(0).getDomain());
					ZABUtil.setDBSpace(dbSpaceId);
					
					//Check if zoho one andif the trial expires
					ZohoOneOrg zoOrg = ZohoOneUtil.getCurrentZohoOneOrg();
					if (zoOrg != null)
					{ 
						// ServiceOrg is associated with Zoho ONE
					    if (zoOrg.getRedirectURL() != null)
					    { 
					    	// Blindly redirect to the URL If Redirect URL has any value. At present, RedirectURL will contain 
					    	// value only when the trail is expired.
					    	String errorString = ZABAction.getResponseProvider(request).getZohoOneTrialExpiredException(zoOrg.getRedirectURL());
							ZABAction.sendResponse(request, response, errorString);
							return;
					    }
					} 
					
					boolean isDeactivatedUser = isDeactivatedUser(iamUser);
					if(isDeactivatedUser)
					{
						//TODO check with IAM ZOho one team and redirect to their page
						String errorString = ZABAction.getResponseProvider(request).getZohoOneUserDeactivatedException();
						ZABAction.sendResponse(request, response, errorString);
						return;
					}
					setCurrentUserAndDBSpace(iamUser, request, response);
					if(ZABUtil.getCurrentUser() == null || ZABUtil.getCurrentUser().getUserId() == null)
					{
						String errorString = ZABAction.getResponseProvider(request).getUserNotPortalMemberException(domain);
						ZABAction.sendResponse(request, response, errorString);
						return;
					}
					ZABUtil.setCurrentRequest(request);
					setInputBodyString(request);
				}
				else
				{
					String errorString = ZABAction.getResponseProvider(request).getPortalNotExistsException(domain);
					ZABAction.sendResponse(request, response, errorString);
					return;
				}
			}catch(Exception e){
				LOGGER.log(Level.SEVERE,e.toString(),e);
			}
		}	
		LOGGER.log(Level.INFO, "ABTest Access completed");
		chain.doFilter(request, response);
	}
	
	public void setInputBodyString(HttpServletRequest request)
	{
		try
		{
			String inputString = ZABAction.getInputString(request);
			ZABUtil.setCurrentInputString(inputString);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,ex.toString(),ex);
			ZABUtil.setCurrentInputString("");
		}
	}
	public void startCountingDBCalls()
	{
		ZABUtil.setDBCallCountMap(null);
		Long startTime = ZABUtil.getCurrentTimeInMilliSeconds();
		ZABUtil.getCurrentRequest().setAttribute("RequestStartTime", startTime);
	}
	
	public boolean isDeactivatedUser(User iamUser)
	{
		boolean isDeactivatedUser = false;
		try
		{
			Long zuid = iamUser.getZUID();
			Criteria cri1 = new Criteria(new Column(APP_USER.TABLE, APP_USER.ZUID), zuid, QueryConstants.EQUAL);
			Criteria cri2 = new Criteria(new Column(APP_USER.TABLE, APP_USER.EMAIL_ADDRESS), IAMUtil.getCurrentUser().getPrimaryEmail(), QueryConstants.EQUAL);
			Criteria cri3 = new Criteria(new Column(APP_USER.TABLE, APP_USER.ACTIVATED), Boolean.FALSE, QueryConstants.EQUAL);
			DataObject dataObj = ZABModel.getRow(APP_USER.TABLE, cri3.and(cri1.or(cri2)));
			if(!dataObj.isEmpty())
			{
				isDeactivatedUser = true;
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
		return isDeactivatedUser;
	}
	
	public void setCurrentUserAndDBSpace(User iamUser, HttpServletRequest request, HttpServletResponse response) throws DataAccessException, Exception
	{
		Long zuid = iamUser.getZUID();
		Criteria cri1 = new Criteria(new Column(APP_USER.TABLE, APP_USER.ZUID), zuid, QueryConstants.EQUAL);
		Criteria cri2 = new Criteria(new Column(APP_USER.TABLE, APP_USER.EMAIL_ADDRESS), IAMUtil.getCurrentUser().getPrimaryEmail(), QueryConstants.EQUAL);
		Criteria cri3 = new Criteria(new Column(APP_USER.TABLE, APP_USER.IS_ACTIVE), Boolean.TRUE, QueryConstants.EQUAL);
		Criteria cri4 = new Criteria(new Column(APP_USER.TABLE, APP_USER.ACTIVATED), Boolean.TRUE, QueryConstants.EQUAL);
		ArrayList<ZABUser> users = ZABUser.getUserWithCriteria(cri3.and(cri4).and(cri1.or(cri2)));
		if(users.size() > 0 && users.get(0).getUserId() != null)
		{
			ZABUser user = users.get(0);
			user.setName(iamUser.getFirstName());
			user.setLastName(iamUser.getLastName());
			user.setFirstName(iamUser.getFirstName());
			user.setEmailAddress(iamUser.getPrimaryEmail());
			user.setZuId(zuid);
			ZABUtil.setCurrentUser(user); 
		}
		else
		{
			ZABUtil.setCurrentUser(null); 
		}
	}
	
	/*
	 
	public Boolean dbSpaceCreation(User iamUser, HttpServletRequest request, HttpServletResponse response, String dbSpaceId) throws DataAccessException, Exception
	{
		Collaboration c = (Collaboration)BeanUtil.lookup("CollaborationBean");		
		if(!c.dataSpaceExists("public")){
			synchronized(this){
				if(!c.dataSpaceExists("public")){
					c.reserveDataSpace("public");	//No I18N
				}
			}
		}		    
		if(!(c.dataSpaceExists(dbSpaceId))){
			synchronized(this){
				if(!c.dataSpaceExists(dbSpaceId)) {
					//ZMUtil.startDataPatch(dbSpaceId);
					c.reserveDataSpace(dbSpaceId);
					ZABUtil.setDBSpace(dbSpaceId);
					ZABUtil.setCurrentUser(ZABUser.createAdminUser(iamUser));  	
					ZABUtil.setCurrentRequest(request); 
					dataSpacePatchUp(dbSpaceId, request);
					ElasticSearchUtil.createIndex(dbSpaceId);
					//ZMUtil.stopDataPatch(dbSpaceId);
				}
			}	
			return false;
		}else{
			return true;
		}
	}
	
	public void dataSpacePatchUp(String dbSpaceId,HttpServletRequest request) throws Exception
	{
		ZABUtil.setDBSpace("admin"); //NO I18N
		Criteria  cri = new Criteria(new Column(SASACCOUNTS.TABLE,SASACCOUNTS.LOGINNAME),dbSpaceId,QueryConstants.EQUAL);
		Join join = new Join(USERDOMAINS.TABLE,SASACCOUNTS.TABLE,new String[]{USERDOMAINS.ID},new String[]{SASACCOUNTS.ID},Join.INNER_JOIN);
		Join join2 = new Join(USERDOMAINS.TABLE,CUSTOMERDATABASE.TABLE,new String[]{USERDOMAINS.CUSTOMERID},new String[]{CUSTOMERDATABASE.CUSTOMERID},Join.INNER_JOIN);
		DataObject dobj = ZABModel.getRow(USERDOMAINS.TABLE, cri, new Join[]{join,join2});
		String schemaname = (String) dobj.getFirstValue(CUSTOMERDATABASE.TABLE, CUSTOMERDATABASE.SCHEMANAME);		
		ZABUtil.setDBSpace(dbSpaceId);
		
		ZABTableCreationBean userAction = (ZABTableCreationBean)BeanUtil.lookup("ZABTableCreationBean",ZABUtil.getCurrentUserDbSpace());
		userAction.createProjectJSONTable(schemaname);
		userAction.createReportRawDataTables();
		userAction.createHeatmapDataTable();
		userAction.createCombinationJsonTables();
		userAction.createReportArchiveVisitorIdsTables();
		
//		ZMUserBean userAction = (ZMUserBean)BeanUtil.lookup("ZMUserBean",ZMUtil.getCurrentUserDbSpace());
//		userAction.createTrigger(schemaname);
		
		
//		LOGGER.log(Level.INFO,"Started loading default templates for Email Builder in the database",request);
		dataPopulation();
//		LOGGER.log(Level.INFO,"Completed loading default templates for Email Builder in the database",request);
	}
	
	public void dataPopulation()
	{
		try
		{
			populateDefaultValuesForStandardDimensions();
			populateArchieveTableMetaValues();
			populateUserRolesAndFeatures();
			
			audienceAttributeDataPopulation();			
			audienceAttributeMatchTypeDataPopulation();
			audienceMatchTypeAttributeMappingDataPopulation();
			
			integrationDataPopulation();
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Error occurred during data population");
		}
	}
	
	public void populateArchieveTableMetaValues() throws Exception
	{
		try
		{
			ArrayList<HashMap<String, String>> hsList = new ArrayList<HashMap<String, String>>();
			HashMap<String, String> hs = null;
			ArchieveTableMetaValues[] archieveTableMetaValues = ArchieveTableMetaValues.values(); 
			
			for(ArchieveTableMetaValues archieveTableMetaValue:archieveTableMetaValues)
			{
				String columnName = archieveTableMetaValue.getColumnName();
				String groupByColumns = archieveTableMetaValue.getGroupByColumns();
				String resultArchiveTable = archieveTableMetaValue.getResultArchieveTable();
				String visitorIdsTable = archieveTableMetaValue.getVisitorIdsTable();
				Integer durationType = archieveTableMetaValue.getDurationType();
				Integer moduleType = archieveTableMetaValue.getModuleType();
				Boolean isStandardDimension = archieveTableMetaValue.getIsStandardDimension();
				
				hs = new HashMap<String, String>();
				hs.put(ReportArchieveDimensionConstants.COLUMN_NAME, columnName);
				hs.put(ReportArchieveDimensionConstants.GROUP_BY_COLUMNS, groupByColumns);
				hs.put(ReportArchieveDimensionConstants.RESULT_ARCHIEVE_TABLE, resultArchiveTable);
				hs.put(ReportArchieveDimensionConstants.VISITOR_IDS_TABLE, visitorIdsTable);
				hs.put(ReportArchieveDimensionConstants.DURATION_TYPE, durationType.toString());
				hs.put(ReportArchieveDimensionConstants.MODULE_TYPE, moduleType.toString());
				hs.put(ReportArchieveDimensionConstants.LAST_ARCHIEVED_TIME, "0");
				hs.put(ReportArchieveDimensionConstants.IS_STANDARD_DIMENSION, isStandardDimension.toString());
				
				hsList.add(hs);
			}
			
			ArchieveTableMeta.createArchieveTableMeta(hsList);
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Error occurred during ArchieveTableMetaValues data population");
		}
	}
	
	public void populateDefaultValuesForStandardDimensions() throws Exception
	{
		try
		{
			//HashMap<String,String> browserHs = new HashMap<String,String>(); 
			//browserHs.put(DimensionConstants.BROWSER_VALUE, ReportRawDataConstants.UNKNOWN_VALUE); //TODO
			//Dimension.createDimensionCodeValue(BROWSER_DETAIL.TABLE, BROWSER_DETAIL.BROWSER_CODE, DimensionConstants.BROWSER_CODE, browserHs, DimensionConstants.BROWSER_DETAIL_CONSTANTS);
			browserDataPopulation();
			
			
			//HashMap<String,String> deviceHs = new HashMap<String,String>(); 
			//deviceHs.put(DimensionConstants.DEVICE_VALUE, ReportRawDataConstants.UNKNOWN_VALUE); //TODO
			//Dimension.createDimensionCodeValue(DEVICE_DETAIL.TABLE, DEVICE_DETAIL.DEVICE_CODE, DimensionConstants.DEVICE_CODE, deviceHs, DimensionConstants.DEVICE_DETAIL_CONSTANTS);
			deviceDataPopulation();
			
			mobileDeviceDataPopulation();
			//HashMap<String,String> countryHs = new HashMap<String,String>(); 
			//countryHs.put(DimensionConstants.COUNTRY_VALUE, ReportRawDataConstants.UNKNOWN_COUNTRY_CODE); //TODO
			//countryHs.put(DimensionConstants.COUNTRY_DISPLAY_NAME, ReportRawDataConstants.UNKNOWN_VALUE); //TODO
			//Dimension.createDimensionCodeValue(COUNTRY_DETAIL.TABLE, COUNTRY_DETAIL.COUNTRY_CODE, DimensionConstants.COUNTRY_CODE, countryHs, DimensionConstants.COUNTRY_DETAIL_CONSTANTS);
			countryDataPopulation();
			
			//HashMap<String,String> languageHs = new HashMap<String,String>(); 
			//languageHs.put(DimensionConstants.LANGUAGE_VALUE, ReportRawDataConstants.UNKNOWN_LANGUAGE_CODE); //TODO
			//languageHs.put(DimensionConstants.LANGUAGE_DISPLAY_NAME, ReportRawDataConstants.UNKNOWN_VALUE); //TODO
			//Dimension.createDimensionCodeValue(LANGUAGE_DETAIL.TABLE, LANGUAGE_DETAIL.LANGUAGE_CODE, DimensionConstants.LANGUAGE_CODE, languageHs, DimensionConstants.LANGUAGE_DETAIL_CONSTANTS);
			languageDataPopulation();
			
			//user type is maintained in ENUM
			
			//HashMap<String,String> usertypeHs = new HashMap<String,String>(); 
			//usertypeHs.put(DimensionConstants.USERTYPE_VALUE, ReportRawDataConstants.UNKNOWN_VALUE); //TODO
			//Dimension.createDimensionCodeValue(USERTYPE_DETAIL.TABLE, USERTYPE_DETAIL.USERTYPE_CODE, DimensionConstants.USERTYPE_CODE, usertypeHs, DimensionConstants.USERTYPE_DETAIL_CONSTANTS);
			
			
			//HashMap<String,String> osHs = new HashMap<String,String>(); 
			//osHs.put(DimensionConstants.OS_VALUE, ReportRawDataConstants.UNKNOWN_VALUE); //TODO
			//Dimension.createDimensionCodeValue(OS_DETAIL.TABLE, OS_DETAIL.OS_CODE, DimensionConstants.OS_CODE, osHs, DimensionConstants.OS_DETAIL_CONSTANTS);
			platformDataPopulation();
			
			
			HashMap<String,String> trafficsourceHs = new HashMap<String,String>(); 
			trafficsourceHs.put(DimensionConstants.TRAFFICSOURCE_VALUE, ReportRawDataConstants.UNKNOWN_VALUE); //TODO
			Dimension.createDimensionCodeValue(TRAFFICSOURCE_DETAIL.TABLE, TRAFFICSOURCE_DETAIL.TRAFFICSOURCE_CODE, DimensionConstants.TRAFFICSOURCE_CODE, trafficsourceHs, DimensionConstants.TRAFFICSOURCE_DETAIL_CONSTANTS);
			
			HashMap<String,String> reffererurlHs = new HashMap<String,String>(); 
			reffererurlHs.put(DimensionConstants.REFFERERURL_VALUE, ReportRawDataConstants.UNKNOWN_VALUE); //TODO
			Dimension.createDimensionCodeValue(REFFERERURL_DETAIL.TABLE, REFFERERURL_DETAIL.REFFERERURL_CODE, DimensionConstants.REFFERERURL_CODE, reffererurlHs, DimensionConstants.REFFERERURL_DETAIL_CONSTANTS);
			
			HashMap<String,String> currenturlHs = new HashMap<String,String>(); 
			currenturlHs.put(DimensionConstants.CURRENTURL_VALUE, ReportRawDataConstants.UNKNOWN_VALUE); //TODO
			Dimension.createDimensionCodeValue(CURRENTURL_DETAIL.TABLE, CURRENTURL_DETAIL.CURRENTURL_CODE, DimensionConstants.CURRENTURL_CODE, currenturlHs, DimensionConstants.CURRENTURL_DETAIL_CONSTANTS);
			
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Error occurred during data population for standard dimensions");
		}
	}
	
	public void populateUserRolesAndFeatures()
	{
		try
		{
			//Populate Roles
			List<Role> rolesList = new ArrayList<Role>();
			UserRoles[] userRoles = UserRoles.values();
			for(UserRoles userRole:userRoles)
			{
				HashMap<String, String> hs = new HashMap<String, String>();
				hs.put(RoleConstants.ROLE_NAME, userRole.getRole());
				hs.put(RoleConstants.ROLE_DESCRIPTION, userRole.getRoleDescription());
				hs.put(RoleConstants.ROLE_VALUE, userRole.getRoleValue().toString());
				rolesList.add(Role.createRole(hs));
			}
			
			//Populate Features
			List<Feature> featureList = new ArrayList<Feature>();
			AppFeatures[] features = AppFeatures.values();
			for(AppFeatures feature:features)
			{
				HashMap<String, String> hs = new HashMap<String, String>();
				hs.put(FeatureConstants.FEATURE_NAME, feature.getFeature());
				hs.put(FeatureConstants.FEATURE_DESCRIPTION, feature.getFeatureDescription());
				hs.put(FeatureConstants.ROLE_VALUE, feature.getRoleValue().toString());
				featureList.add(Feature.createFeature(hs));
			}
			
			//Mapping of Features with its Roles
			for(Role role:rolesList)
			{
				ArrayList<HashMap<String, String>> hsArray = new ArrayList<HashMap<String, String>>();
				for(Feature feature:featureList)
				{
					Integer featureRoleValue = feature.getRoleValue();
					HashMap<String, String> hs = new HashMap<String, String>();
					switch(role.getRoleName())
					{
					//Admin has access to all features
					case "ADMIN": //No I18N 
						hs.put(RoleFeatureConstants.ROLE_ID, role.getRoleId().toString());
						hs.put(RoleFeatureConstants.FEATURE_ID, feature.getFeatureId().toString());
						hsArray.add(hs);
						break;
					case "PROJECTADMIN": //No I18N 
						//Project admin can have access to editor features and spectator features and additional specific features
						if(featureRoleValue.equals(UserRoles.PROJECTADMIN.getRoleValue()) || featureRoleValue.equals(UserRoles.EDITOR.getRoleValue()) || featureRoleValue.equals(UserRoles.SPECTATOR.getRoleValue()))
						{
							hs.put(RoleFeatureConstants.ROLE_ID, role.getRoleId().toString());
							hs.put(RoleFeatureConstants.FEATURE_ID, feature.getFeatureId().toString());
							hsArray.add(hs);
						}
						break;
					case "EDITOR": //No I18N 
						//Editor can have access to spectator features and additional specific features
						if(featureRoleValue.equals(UserRoles.EDITOR.getRoleValue()) || featureRoleValue.equals(UserRoles.SPECTATOR.getRoleValue()))
						{
							hs.put(RoleFeatureConstants.ROLE_ID, role.getRoleId().toString());
							hs.put(RoleFeatureConstants.FEATURE_ID, feature.getFeatureId().toString());
							hsArray.add(hs);
						}
						break;
					case "SPECTATOR": //No I18N 
						//Spectator can have access to spectator features
						if(featureRoleValue.equals(UserRoles.SPECTATOR.getRoleValue()))
						{
							hs.put(RoleFeatureConstants.ROLE_ID, role.getRoleId().toString());
							hs.put(RoleFeatureConstants.FEATURE_ID, feature.getFeatureId().toString());
							hsArray.add(hs);
						}
						break;
					}
				}
				RoleFeature.createRoleFeature(hsArray);
			}
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE,"Error occurred during data population for User Roles and Features");
		}
	}
	
	public Boolean isPersonalUser(User iamUser)
	{
		Long zoId = iamUser.getZOID();
		if(zoId==null||(zoId!=null&&zoId==-1))
		{
			return true;
		}
		else{
			return false;
		}
	}
	
	public static void startIntrumentation(User iamUser, HttpServletRequest request)
	{
		Request instrumentationRequest = InstrumentManager.getCurrentRequest();
		if(instrumentationRequest!=null){
				//instrumentationRequest.setIAMId(iamUser.getZUID());
		}
		if( request instanceof SecurityRequestWrapper)
		{
			SecurityRequestWrapper securityWrapper = (SecurityRequestWrapper)request;	     
			String actionParam = securityWrapper.getURLActionRule().getOperationValue();
			String url = securityWrapper.getURLActionRule().getPath(); 
			if(actionParam != null){
				url = url+""+actionParam;   // appending action param at the end
			}     
			Request intrumentationRequest = InstrumentManager.getCurrentRequest();
			if(instrumentationRequest !=null){
				//intrumentationRequest.setURL(url);
			}
		}
	}
	
	public static void browserDataPopulation(){
		try{
			
			ArrayList<HashMap<String, String>> myList = new ArrayList<HashMap<String, String>>();

			String browserData[] = {"Firefox","Chrome","Internet Explorer","Safari","Microsoft Edge","UC Browser","Netscape"}; //No I18N
			for(int i=0;i<browserData.length;i++){
				HashMap<String, String> data = new HashMap<String, String>();
				data.put(DimensionConstants.BROWSER_VALUE, browserData[i]); //TODO
				//data.put(DimensionConstants.BROWSER_CODE, i+"");
				myList.add(data);
			}
			
			ZABModel.createRow(DimensionConstants.BROWSER_DETAIL_CONSTANTS, BROWSER_DETAIL.TABLE, myList);

		}catch(Exception ex){
			ex.printStackTrace();
		}
		
	}
	

	public static void platformDataPopulation(){
		try{
			
			ArrayList<HashMap<String, String>> myList = new ArrayList<HashMap<String, String>>();
			
			String osData[] = {"Android","Blackberry","EI Capitan","Linux","Unix","IOS","MAC OS","Windows OS","Windows Phone"}; //No I18N
			for(int i=0;i<osData.length;i++){
				HashMap<String, String> data = new HashMap<String, String>();
				data.put(DimensionConstants.OS_VALUE, osData[i]); //TODO
				//data.put(DimensionConstants.OS_CODE, i+"");
				myList.add(data);
			}
			
			ZABModel.createRow(DimensionConstants.OS_DETAIL_CONSTANTS, OS_DETAIL.TABLE, myList);

		}catch(Exception ex){
			ex.printStackTrace();
		}
		
	}
	
	public static void deviceDataPopulation(){
		try{
			
			ArrayList<HashMap<String, String>> myList = new ArrayList<HashMap<String, String>>();
			
			String deviceData[] = {"Desktop","Laptop","iPad","iPhone","Other Mobile Phone","Other Tablet"}; //No I18N
			for(int i=0;i<deviceData.length;i++){
				HashMap<String, String> data = new HashMap<String, String>();
				data.put(DimensionConstants.DEVICE_VALUE, deviceData[i]); //TODO
				//data.put(DimensionConstants.DEVICE_CODE, i+"");
				myList.add(data);
			}
			
			ZABModel.createRow(DimensionConstants.DEVICE_DETAIL_CONSTANTS, DEVICE_DETAIL.TABLE, myList);

		}catch(Exception ex){
			ex.printStackTrace();
		}
	
	}
	
	public static void mobileDeviceDataPopulation(){
		try{
			
			ArrayList<HashMap<String, String>> myList = new ArrayList<HashMap<String, String>>();
			
			String mobileDeviceData[] = {"Android","IOS","Blackberry","iPhone","Opera Mini","Windows Phone"};  //No I18N
			for(int i=0;i<mobileDeviceData.length;i++){
				HashMap<String, String> data = new HashMap<String, String>();
				data.put(DimensionConstants.MOBILE_DEVICE_VALUE, mobileDeviceData[i]); //TODO
				//data.put(DimensionConstants.MOBILE_DEVICE_CODE, i+"");
				myList.add(data);
			}
			
			ZABModel.createRow(DimensionConstants.MOBILE_DEVICE_DETAIL_CONSTANTS, MOBILE_DEVICE_DETAIL.TABLE, myList);

		}catch(Exception ex){
			ex.printStackTrace();
		}
	
	}
	
	public static void countryDataPopulation(){
		try{
			
			ArrayList<HashMap<String, String>> myList = new ArrayList<HashMap<String, String>>();
			
			HashMap<String, String> data = new HashMap<String, String>();
			data.put(DimensionConstants.COUNTRY_VALUE , ReportRawDataConstants.UNKNOWN_COUNTRY_CODE); //TODO
			data.put(DimensionConstants.COUNTRY_DISPLAY_NAME, ReportRawDataConstants.UNKNOWN_VALUE);
			//data.put(DimensionConstants.COUNTRY_CODE, "0");
			myList.add(data);
			
			String[] locales = Locale.getISOCountries();
			int i = 1;
			for (String countryCode : locales) {
				Locale obj = new Locale("", countryCode);
				HashMap<String, String> data1 = new HashMap<String, String>();
				data1.put(DimensionConstants.COUNTRY_VALUE , obj.getCountry()); //TODO
				data1.put(DimensionConstants.COUNTRY_DISPLAY_NAME, obj.getDisplayCountry());
				//data1.put(DimensionConstants.COUNTRY_CODE, ""+i++);
				myList.add(data1);
				
			}
	
			
			ZABModel.createRow(DimensionConstants.COUNTRY_DETAIL_CONSTANTS, COUNTRY_DETAIL.TABLE, myList);

		}catch(Exception ex){
			ex.printStackTrace();
		}
	
	}
	
	public static void languageDataPopulation(){
		try{
			
			ArrayList<HashMap<String, String>> myList = new ArrayList<HashMap<String, String>>();
			
			HashMap<String, String> data = new HashMap<String, String>();
			data.put(DimensionConstants.LANGUAGE_VALUE , ReportRawDataConstants.UNKNOWN_LANGUAGE_CODE); //TODO
			data.put(DimensionConstants.LANGUAGE_DISPLAY_NAME, ReportRawDataConstants.UNKNOWN_VALUE);
			//data.put(DimensionConstants.LANGUAGE_CODE, "0");
			myList.add(data);
			
			String[] languages = Locale.getISOLanguages();
			Locale obj = null;
			int i = 1;
			for (String languageCode : languages) {
				
				obj = new Locale(languageCode);
				
				HashMap<String, String> data1 = new HashMap<String, String>();
				data1.put(DimensionConstants.LANGUAGE_VALUE , obj.getLanguage());
				data1.put(DimensionConstants.LANGUAGE_DISPLAY_NAME, obj.getDisplayLanguage());
				//data1.put(DimensionConstants.LANGUAGE_CODE, ""+i++);
				myList.add(data1);
				
			}
			
			ZABModel.createRow(DimensionConstants.LANGUAGE_DETAIL_CONSTANTS, LANGUAGE_DETAIL.TABLE, myList);

		}catch(Exception ex){
			ex.printStackTrace();
		}
	
	}
	
	public static void audienceAttributeDataPopulation(){
		try{
			
			ArrayList<HashMap<String, String>> myList = new ArrayList<HashMap<String, String>>();
			
			HashMap<String, String> data1 = new HashMap<String, String>();
			data1.put(AudienceAttributeConstants.ATTRIBUTE_ID, "1");
			data1.put(AudienceAttributeConstants.ATTRIBUTE_DISPLAYNAME, "Current URL");
			data1.put(AudienceAttributeConstants.ATTRIBUTE_DESCRIPTION, " ");
			data1.put(AudienceAttributeConstants.IS_DYNAMIC_ATTRIBUTE, Boolean.FALSE.toString());
			
			HashMap<String, String> data2 = new HashMap<String, String>();
			data2.put(AudienceAttributeConstants.ATTRIBUTE_ID, "2");
			data2.put(AudienceAttributeConstants.ATTRIBUTE_DISPLAYNAME, "Referral URL");
			data2.put(AudienceAttributeConstants.ATTRIBUTE_DESCRIPTION, " ");
			data2.put(AudienceAttributeConstants.IS_DYNAMIC_ATTRIBUTE, Boolean.FALSE.toString());
			
			HashMap<String, String> data3 = new HashMap<String, String>();
			data3.put(AudienceAttributeConstants.ATTRIBUTE_ID, "3");
			data3.put(AudienceAttributeConstants.ATTRIBUTE_DISPLAYNAME, "Visitor Type");
			data3.put(AudienceAttributeConstants.ATTRIBUTE_DESCRIPTION, " ");
			data3.put(AudienceAttributeConstants.IS_DYNAMIC_ATTRIBUTE, Boolean.FALSE.toString());
			
			HashMap<String, String> data4 = new HashMap<String, String>();
			data4.put(AudienceAttributeConstants.ATTRIBUTE_ID, "4");
			data4.put(AudienceAttributeConstants.ATTRIBUTE_DISPLAYNAME, "Cookie Value");
			data4.put(AudienceAttributeConstants.ATTRIBUTE_DESCRIPTION, " ");
			data4.put(AudienceAttributeConstants.IS_DYNAMIC_ATTRIBUTE, Boolean.TRUE.toString());
			
			HashMap<String, String> data5 = new HashMap<String, String>();
			data5.put(AudienceAttributeConstants.ATTRIBUTE_ID, "5");
			data5.put(AudienceAttributeConstants.ATTRIBUTE_DISPLAYNAME, "Query Parameter");
			data5.put(AudienceAttributeConstants.ATTRIBUTE_DESCRIPTION, " ");
			data5.put(AudienceAttributeConstants.IS_DYNAMIC_ATTRIBUTE, Boolean.TRUE.toString());
			
			HashMap<String, String> data6 = new HashMap<String, String>();
			data6.put(AudienceAttributeConstants.ATTRIBUTE_ID, "6");
			data6.put(AudienceAttributeConstants.ATTRIBUTE_DISPLAYNAME, "Operating System");
			data6.put(AudienceAttributeConstants.ATTRIBUTE_DESCRIPTION, " ");
			data6.put(AudienceAttributeConstants.IS_DYNAMIC_ATTRIBUTE, Boolean.FALSE.toString());
			
			HashMap<String, String> data7 = new HashMap<String, String>();
			data7.put(AudienceAttributeConstants.ATTRIBUTE_ID, "7");
			data7.put(AudienceAttributeConstants.ATTRIBUTE_DISPLAYNAME, "Device Type");
			data7.put(AudienceAttributeConstants.ATTRIBUTE_DESCRIPTION, " ");
			data7.put(AudienceAttributeConstants.IS_DYNAMIC_ATTRIBUTE, Boolean.FALSE.toString());
			
			HashMap<String, String> data8 = new HashMap<String, String>();
			data8.put(AudienceAttributeConstants.ATTRIBUTE_ID, "8");
			data8.put(AudienceAttributeConstants.ATTRIBUTE_DISPLAYNAME, "Mobile Device");
			data8.put(AudienceAttributeConstants.ATTRIBUTE_DESCRIPTION, " ");
			data8.put(AudienceAttributeConstants.IS_DYNAMIC_ATTRIBUTE, Boolean.FALSE.toString());
			
			HashMap<String, String> data9 = new HashMap<String, String>();
			data9.put(AudienceAttributeConstants.ATTRIBUTE_ID, "9");
			data9.put(AudienceAttributeConstants.ATTRIBUTE_DISPLAYNAME, "Browser");
			data9.put(AudienceAttributeConstants.ATTRIBUTE_DESCRIPTION, " ");
			data9.put(AudienceAttributeConstants.IS_DYNAMIC_ATTRIBUTE, Boolean.FALSE.toString());
			
			HashMap<String, String> data10 = new HashMap<String, String>();
			data10.put(AudienceAttributeConstants.ATTRIBUTE_ID, "10");
			data10.put(AudienceAttributeConstants.ATTRIBUTE_DISPLAYNAME, "User Agent");
			data10.put(AudienceAttributeConstants.ATTRIBUTE_DESCRIPTION, " ");
			data10.put(AudienceAttributeConstants.IS_DYNAMIC_ATTRIBUTE, Boolean.FALSE.toString());
			
			HashMap<String, String> data11 = new HashMap<String, String>();
			data11.put(AudienceAttributeConstants.ATTRIBUTE_ID, "11");
			data11.put(AudienceAttributeConstants.ATTRIBUTE_DISPLAYNAME, "Location");
			data11.put(AudienceAttributeConstants.ATTRIBUTE_DESCRIPTION, " ");
			data11.put(AudienceAttributeConstants.IS_DYNAMIC_ATTRIBUTE, Boolean.FALSE.toString());
			
			HashMap<String, String> data12 = new HashMap<String, String>();
			data12.put(AudienceAttributeConstants.ATTRIBUTE_ID, "12");
			data12.put(AudienceAttributeConstants.ATTRIBUTE_DISPLAYNAME, "Day of week");
			data12.put(AudienceAttributeConstants.ATTRIBUTE_DESCRIPTION, " ");
			data12.put(AudienceAttributeConstants.IS_DYNAMIC_ATTRIBUTE, Boolean.FALSE.toString());
			
			HashMap<String, String> data13 = new HashMap<String, String>();
			data13.put(AudienceAttributeConstants.ATTRIBUTE_ID, "13");
			data13.put(AudienceAttributeConstants.ATTRIBUTE_DISPLAYNAME, "Hour of the day");
			data13.put(AudienceAttributeConstants.ATTRIBUTE_DESCRIPTION, " ");
			data13.put(AudienceAttributeConstants.IS_DYNAMIC_ATTRIBUTE, Boolean.FALSE.toString());
			
			HashMap<String, String> data14 = new HashMap<String, String>();
			data14.put(AudienceAttributeConstants.ATTRIBUTE_ID, "14");
			data14.put(AudienceAttributeConstants.ATTRIBUTE_DISPLAYNAME, "JS Variable");
			data14.put(AudienceAttributeConstants.ATTRIBUTE_DESCRIPTION, " ");
			data14.put(AudienceAttributeConstants.IS_DYNAMIC_ATTRIBUTE, Boolean.TRUE.toString());
			
			HashMap<String, String> data15 = new HashMap<String, String>();
			data15.put(AudienceAttributeConstants.ATTRIBUTE_ID, "15");
			data15.put(AudienceAttributeConstants.ATTRIBUTE_DISPLAYNAME, "Custom Dimension");
			data15.put(AudienceAttributeConstants.ATTRIBUTE_DESCRIPTION, " ");
			data15.put(AudienceAttributeConstants.IS_DYNAMIC_ATTRIBUTE, Boolean.TRUE.toString());
			
			myList.add(data1);
			myList.add(data2);
			myList.add(data3);
			myList.add(data4);
			myList.add(data5);
			myList.add(data6);
			myList.add(data7);
			myList.add(data8);
			myList.add(data9);
			myList.add(data10);
			myList.add(data11);
			myList.add(data12);
			myList.add(data13);
			myList.add(data14);
			myList.add(data15);
			
			
			ZABModel.createRow(AudienceAttributeConstants.AUDIENCE_ATTRIBUTE_TABLE, AUDIENCE_ATTRIBUTE.TABLE, myList);

		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	public static void audienceAttributeMatchTypeDataPopulation(){
		try{
			
			ArrayList<HashMap<String, String>> myList = new ArrayList<HashMap<String, String>>();
			
			HashMap<String, String> data1 = new HashMap<String, String>();
			data1.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");
			data1.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_NAME, "equals");

			HashMap<String, String> data2 = new HashMap<String, String>();
			data2.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");
			data2.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_NAME, "not equals");
			
			HashMap<String, String> data3 = new HashMap<String, String>();
			data3.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "3");
			data3.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_NAME, "contains");
			
			HashMap<String, String> data4 = new HashMap<String, String>();
			data4.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "4");
			data4.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_NAME, "does not contains");
			
	
			myList.add(data1);
			myList.add(data2);
			myList.add(data3);
			myList.add(data4);
			
			
			ZABModel.createRow(AudienceAttributeConstants.AUDIENCE_ATTRIBUTE_MATCHTYPE_TABLE, AUDIENCE_ATTRIBUTE_MATCHTYPE.TABLE, myList);

		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	public static void audienceMatchTypeAttributeMappingDataPopulation(){
		try{
			
			ArrayList<HashMap<String, String>> myList = new ArrayList<HashMap<String, String>>();
			
			HashMap<String, String> data1 = new HashMap<String, String>();
			data1.put(AudienceAttributeConstants.ATTRIBUTE_ID, "1");
			data1.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

			HashMap<String, String> data2 = new HashMap<String, String>();
			data2.put(AudienceAttributeConstants.ATTRIBUTE_ID, "1");
			data2.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");

			HashMap<String, String> data3 = new HashMap<String, String>();
			data3.put(AudienceAttributeConstants.ATTRIBUTE_ID, "2");
			data3.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

			HashMap<String, String> data4 = new HashMap<String, String>();
			data4.put(AudienceAttributeConstants.ATTRIBUTE_ID, "2");
			data4.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");

			HashMap<String, String> data5 = new HashMap<String, String>();
			data5.put(AudienceAttributeConstants.ATTRIBUTE_ID, "3");
			data5.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

			HashMap<String, String> data6 = new HashMap<String, String>();
			data6.put(AudienceAttributeConstants.ATTRIBUTE_ID, "3");
			data6.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");

			HashMap<String, String> data7 = new HashMap<String, String>();
			data7.put(AudienceAttributeConstants.ATTRIBUTE_ID, "4");
			data7.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

			HashMap<String, String> data8 = new HashMap<String, String>();
			data8.put(AudienceAttributeConstants.ATTRIBUTE_ID, "4");
			data8.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");

			HashMap<String, String> data9 = new HashMap<String, String>();
			data9.put(AudienceAttributeConstants.ATTRIBUTE_ID, "4");
			data9.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "3");

			HashMap<String, String> data10 = new HashMap<String, String>();
			data10.put(AudienceAttributeConstants.ATTRIBUTE_ID, "4");
			data10.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "4");

			HashMap<String, String> data11 = new HashMap<String, String>();
			data11.put(AudienceAttributeConstants.ATTRIBUTE_ID, "5");
			data11.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

			HashMap<String, String> data12 = new HashMap<String, String>();
			data12.put(AudienceAttributeConstants.ATTRIBUTE_ID, "5");
			data12.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");

			HashMap<String, String> data13 = new HashMap<String, String>();
			data13.put(AudienceAttributeConstants.ATTRIBUTE_ID, "5");
			data13.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "3");

			HashMap<String, String> data14 = new HashMap<String, String>();
			data14.put(AudienceAttributeConstants.ATTRIBUTE_ID, "5");
			data14.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "4");

			HashMap<String, String> data15 = new HashMap<String, String>();
			data15.put(AudienceAttributeConstants.ATTRIBUTE_ID, "6");
			data15.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

			HashMap<String, String> data16 = new HashMap<String, String>();
			data16.put(AudienceAttributeConstants.ATTRIBUTE_ID, "6");
			data16.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");

			HashMap<String, String> data17 = new HashMap<String, String>();
			data17.put(AudienceAttributeConstants.ATTRIBUTE_ID, "7");
			data17.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

			HashMap<String, String> data18 = new HashMap<String, String>();
			data18.put(AudienceAttributeConstants.ATTRIBUTE_ID, "7");
			data18.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");

			HashMap<String, String> data19 = new HashMap<String, String>();
			data19.put(AudienceAttributeConstants.ATTRIBUTE_ID, "8");
			data19.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

			HashMap<String, String> data20 = new HashMap<String, String>();
			data20.put(AudienceAttributeConstants.ATTRIBUTE_ID, "8");
			data20.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");

			HashMap<String, String> data21 = new HashMap<String, String>();
			data21.put(AudienceAttributeConstants.ATTRIBUTE_ID, "9");
			data21.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

			HashMap<String, String> data22 = new HashMap<String, String>();
			data22.put(AudienceAttributeConstants.ATTRIBUTE_ID, "9");
			data22.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");

			HashMap<String, String> data23 = new HashMap<String, String>();
			data23.put(AudienceAttributeConstants.ATTRIBUTE_ID, "10");
			data23.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

			HashMap<String, String> data24 = new HashMap<String, String>();
			data24.put(AudienceAttributeConstants.ATTRIBUTE_ID, "10");
			data24.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");

			HashMap<String, String> data25 = new HashMap<String, String>();
			data25.put(AudienceAttributeConstants.ATTRIBUTE_ID, "10");
			data25.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "3");

			HashMap<String, String> data26 = new HashMap<String, String>();
			data26.put(AudienceAttributeConstants.ATTRIBUTE_ID, "10");
			data26.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "4");

			HashMap<String, String> data27 = new HashMap<String, String>();
			data27.put(AudienceAttributeConstants.ATTRIBUTE_ID, "11");
			data27.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

			HashMap<String, String> data28 = new HashMap<String, String>();
			data28.put(AudienceAttributeConstants.ATTRIBUTE_ID, "11");
			data28.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");

			HashMap<String, String> data29 = new HashMap<String, String>();
			data29.put(AudienceAttributeConstants.ATTRIBUTE_ID, "12");
			data29.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

			HashMap<String, String> data30 = new HashMap<String, String>();
			data30.put(AudienceAttributeConstants.ATTRIBUTE_ID, "12");
			data30.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");

			HashMap<String, String> data31 = new HashMap<String, String>();
			data31.put(AudienceAttributeConstants.ATTRIBUTE_ID, "13");
			data31.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

			HashMap<String, String> data32 = new HashMap<String, String>();
			data32.put(AudienceAttributeConstants.ATTRIBUTE_ID, "13");
			data32.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");
			
			HashMap<String, String> data33 = new HashMap<String, String>();
			data33.put(AudienceAttributeConstants.ATTRIBUTE_ID, "14");
			data33.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

			HashMap<String, String> data34 = new HashMap<String, String>();
			data34.put(AudienceAttributeConstants.ATTRIBUTE_ID, "14");
			data34.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");
			
			HashMap<String, String> data35 = new HashMap<String, String>();
			data35.put(AudienceAttributeConstants.ATTRIBUTE_ID, "14");
			data35.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "3");
			
			HashMap<String, String> data36 = new HashMap<String, String>();
			data36.put(AudienceAttributeConstants.ATTRIBUTE_ID, "14");
			data36.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "4");
			
			HashMap<String, String> data37 = new HashMap<String, String>();
			data37.put(AudienceAttributeConstants.ATTRIBUTE_ID, "15");
			data37.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "1");

			HashMap<String, String> data38 = new HashMap<String, String>();
			data38.put(AudienceAttributeConstants.ATTRIBUTE_ID, "15");
			data38.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "2");
			
			HashMap<String, String> data39 = new HashMap<String, String>();
			data39.put(AudienceAttributeConstants.ATTRIBUTE_ID, "15");
			data39.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "3");
			
			HashMap<String, String> data40 = new HashMap<String, String>();
			data40.put(AudienceAttributeConstants.ATTRIBUTE_ID, "15");
			data40.put(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_ID, "4");
			
			myList.add(data1);
			myList.add(data2);
			myList.add(data3);
			myList.add(data4);
			myList.add(data5);
			myList.add(data6);
			myList.add(data7);
			myList.add(data8);
			myList.add(data9);
			myList.add(data10);
			myList.add(data11);
			myList.add(data12);
			myList.add(data13);
			myList.add(data14);
			myList.add(data15);
			myList.add(data16);
			myList.add(data17);
			myList.add(data18);
			myList.add(data19);
			myList.add(data20);
			myList.add(data21);
			myList.add(data22);
			myList.add(data23);
			myList.add(data24);
			myList.add(data25);
			myList.add(data26);
			myList.add(data27);
			myList.add(data28);
			myList.add(data29);
			myList.add(data30);
			myList.add(data31);
			myList.add(data32);
			myList.add(data33);
			myList.add(data34);
			myList.add(data35);
			myList.add(data36);
			myList.add(data37);
			myList.add(data38);
			myList.add(data39);
			myList.add(data40);
			
			
			ZABModel.createRow(AudienceAttributeConstants.ATTRIBUTE_MATCHTYPE_MAPPING_TABLE, ATTRIBUTE_MATCHTYPE_MAPPING.TABLE, myList);

		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	public static void integrationDataPopulation(){
		try{
			
			ArrayList<HashMap<String, String>> myList = new ArrayList<HashMap<String, String>>();
			
			HashMap<String, String> data1 = new HashMap<String, String>();
			data1.put(IntegrationConstants.INTEGRATION_ID, "1");
			data1.put(IntegrationConstants.INTEGRATION_NAME, "Google Analytics");
			data1.put(IntegrationConstants.INTEGRATION_DESCRIPTION, " ");

			HashMap<String, String> data2 = new HashMap<String, String>();
			data2.put(IntegrationConstants.INTEGRATION_ID, "2");
			data2.put(IntegrationConstants.INTEGRATION_NAME, "Kissmetrics");
			data2.put(IntegrationConstants.INTEGRATION_DESCRIPTION, " ");
			
			HashMap<String, String> data3 = new HashMap<String, String>();
			data3.put(IntegrationConstants.INTEGRATION_ID, "3");
			data3.put(IntegrationConstants.INTEGRATION_NAME, "Mixpanel");
			data3.put(IntegrationConstants.INTEGRATION_DESCRIPTION, " ");
			
			HashMap<String, String> data4 = new HashMap<String, String>();
			data4.put(IntegrationConstants.INTEGRATION_ID, "4");
			data4.put(IntegrationConstants.INTEGRATION_NAME, "Google Adwords");
			data4.put(IntegrationConstants.INTEGRATION_DESCRIPTION, " ");
			
	
			myList.add(data1);
			myList.add(data2);
			myList.add(data3);
			myList.add(data4);
			
			
			ZABModel.createRow(IntegrationConstants.INTEGRATION_TABLE, INTEGRATION.TABLE, myList);

		}catch(Exception ex){
			ex.printStackTrace();
		}
	}*/
	
	@Override
	public Logger getLogger() {
		return LOGGER;
	} 
}
