//$Id$
package com.zoho.abtest.filter;

import java.io.IOException;
import java.util.logging.Logger;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zoho.abtest.common.ZABAction;
import com.zoho.abtest.common.ZABAction.HTTPMethod;
import com.zoho.abtest.utility.ApplicationProperty;
import com.zoho.conf.Configuration;

public class ABTestCORSFilter implements Filter{
	private static final Logger LOGGER = Logger.getLogger(ABTestCORSFilter.class.getName());
	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse,FilterChain filterChain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		
		HttpServletRequest request = (HttpServletRequest)servletRequest;
		HttpServletResponse response =(HttpServletResponse) servletResponse;
        
		String origin = request.getHeader("Origin");
		String request_method = request.getMethod();
			
		if(request_method.equals("GET")) {

		   response.setHeader("Content-Type:","text/plain");
		    	
		}else if(request_method.equals("OPTIONS")) {
				    	
			if(origin.equals("https://d1iw0d9rifrdkx.cloudfront.net") || origin.equals("http://d1iw0d9rifrdkx.cloudfront.net")) {
			    		 
				response.setHeader("Access-Control-Allow-Origin","*"); //NO I18N
			 	response.setHeader("Access-Control-Allow-Credentials", "false"); //NO I18N
			 	response.setHeader("Access-Control-Allow-Methods", "POST"); //NO I18N
			 	response.setHeader("Access-Control-Allow-Headers", "Origin, Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers"); //NO I18N
			 	
			} else {
			    		  
				response.setStatus(HttpServletResponse.SC_FORBIDDEN);
			    response.setHeader("Content-Type:","text/plain");		  
			}

	   } else if(request_method.equals("POST")) {
		    	
		    if(origin.equals("https://d1iw0d9rifrdkx.cloudfront.net")||origin.equals("http://d1iw0d9rifrdkx.cloudfront.net")) {
		    	        
		    	response.setHeader("Access-Control-Allow-Origin","*"); //NO I18N
		    	response.setHeader("Content-Type:","text/plain");		  
		    	filterChain.doFilter(servletRequest, servletResponse);  
		    	return;
		    }
		    
		    boolean isDevMode = Boolean.parseBoolean(ApplicationProperty.getString("com.abtest.devmode").trim());
		    if(isDevMode)
		    {
		    	filterChain.doFilter(servletRequest, servletResponse);
		    }
		    
	  } 
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		
	}

}
