#/bin/sh

getClientBuildURL() {
   
    homedir = "/home/test/aws-ci/"
   
    file="${homedir}ant.properties"

    clientzip="${homedir}PageSenseClient.zip"

    extzipdest="${homedir}"

    echo "Removing objects"	
    rm -rf /home/test/aws-ci/ant.properties
    rm -rf /home/test/aws-ci/PageSenseClient.zip
    rm -rf /home/test/aws-ci/dist
    echo "Fetchig ant.properties"

    curl -o "${file}" "https://git.csez.zohocorpin.com/abtest/abtest/raw/master/build/ant.properties"

    clienturl_key="url_clientbuild_url"
    client_build_url="";

    if [ -f "$file" ]
    then
    echo "$file found."

    while IFS='=' read -r key value
    do
        key=$(echo $key | tr '.' '_')
       echo "$key"
        if [ $key = $clienturl_key ] 
        then
            echo "Client build url:${value}"
            eval client_build_url="$value"
        fi
    done < "$file"
    else
    echo "$file not found."
    fi
    
    curl -o "${clientzip}" "${client_build_url}"
    unzip "$clientzip" -d "/home/test/aws-ci/dist"

export https_proxy=http://192.168.100.100:3128

echo "Uploading to IDC"    
/root/bin/aws s3 cp "/home/test/aws-ci/dist/assets" s3://pagesense-assets --recursive --grants read=uri=http://acs.amazonaws.com/groups/global/AllUsers full=emailaddress=abtest@zohocorp.com

echo "Uploading to LocalZOHO" 
/root/bin/aws s3 cp "/home/test/aws-ci/dist/assets" s3://pagesense-assets/local --recursive --grants read=uri=http://acs.amazonaws.com/groups/global/AllUsers full=emailaddress=abtest@zohocorp.com
}

main() {
    getClientBuildURL
}
main $@