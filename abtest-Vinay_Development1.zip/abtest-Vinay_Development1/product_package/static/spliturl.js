//$Id: $ 

(function(window, document, navigator) {

    //not completed js
    /*
        Known Paramenters - 
        1.Experiment ID.
        2.Variation IDs
        3.Variation Paths 
        4.Percentage of each Variation - By default equal % to each.
        5.% of visitors to be included in the experiment - by default it is 100; 
        6.Audiences/Conditions specified to include the user.
    */

    /*returning visitor or not :
     YES: 
         - check expId and VariationId 
         - If variationId is null , ignore else direct to the variation path.
      NO:
         - set ruser cookie as true
         - indicate whether he will be included in the exp or not based on %
            - if no :  set cookie {expid:null} 
            - If yes :
                -  check if the audiences specified are satisfied.
                    -if yes, determine the variation to which he should be added based on %
                    - set cookie  {expId : varId} 
    */

    var ZAB = ZAB || {};

    getBrowserUA = function() {
        return navigator.userAgent;
    }

    getBrowserAppName = function() {
        return navigator.appName;
    }

    getBrowserAppVersion = function() {
        return navigator.appVersion;
    }

    getVisitorBrowserDetails = function(userAgent, appName, appVersion) {

        var browserName = appName;
        var browserVersion = '' + parseFloat(appVersion);
        var majorBV = parseInt(appVersion, 10);
        var nameOffset, versionOffset, pos;

        if ((versionOffset = userAgent.indexOf("Opera")) != -1) {

            browserName = "Opera"; //No I18N
            browserVersion = userAgent.substring(versionOffset + 6);

            if ((versionOffset = userAgent.indexOf("Version")) != -1) {
                browserVersion = userAgent.substring(versionOffset + 8);
            }

        } else if ((versionOffset = userAgent.indexOf("MSIE")) != -1) {

            browserName = "Microsoft Internet Explorer"; //No I18N
            browserVersion = userAgent.substring(versionOffset + 5);

        } else if ((versionOffset = userAgent.indexOf("Chrome")) != -1) {

            browserName = "Chrome"; //No I18N
            browserVersion = userAgent.substring(versionOffset + 7);

        } else if ((versionOffset = userAgent.indexOf("Safari")) != -1) {

            browserName = "Safari"; //No I18N
            browserVersion = userAgent.substring(versionOffset + 7);

            if ((versionOffset = userAgent.indexOf("Version")) != -1) {
                browserVersion = userAgent.substring(versionOffset + 8);
            }

        } else if ((versionOffset = userAgent.indexOf("Firefox")) != -1) {

            browserName = "Firefox"; //No I18N
            browserVersion = userAgent.substring(versionOffset + 8);

        } else if ((nameOffset = userAgent.lastIndexOf(' ') + 1) < (versionOffset = userAgent.lastIndexOf('/'))) {

            browserName = userAgent.substring(nameOffset, versionOffset);
            browserVersion = userAgent.substring(versionOffset + 1);

            if (browserName.toLowerCase() == browserName.toUpperCase()) {
                browserName = navigator.appName;
            }
        }

        if ((pos = browserVersion.indexOf(";")) != -1){
        	browserVersion = browserVersion.substring(0, pos);
        }
            
        if ((pos = browserVersion.indexOf(" ")) != -1){
            browserVersion = browserVersion.substring(0, pos);
        }
        
        majorBV = parseInt('' + browserVersion, 10);
        if (isNaN(majorBV)) {
            browserVersion = '' + parseFloat(appVersion);
            majorBV = parseInt(appVersion, 10);
        }

        ZAB.browserVersion = browserVersion;
        ZAB.browserName = browserName;
        ZAB.majorBV = majorBV;
    }


    getBrowserLang = function() {
        return navigator.languages;
    }

    jsonCallback = function() {
        //handling the json object
    }

    getVisitorLocation = function() {
        var src = "..?callback=jsonCallback"; //No I18N 
        // url with callback to send request to funtion that finds ip address and sends the location as json object
        addScript(src);
    }

    getVisitorOSDetails = function(appVersion) {

        var OSType;

        if (appVersion.indexOf("Win") != -1) {
            OSType = "Windows"; //No I18N
        } else if (appVersion.indexOf("Mac") != -1) {
            OSType = "MacOS"; //No I18N
        } else if (appVersion.indexOf("X11") != -1) {
            OSType = "UNIX"; //No I18N
        } else if (appVersion.indexOf("Linux") != -1) {
            OSType = "Linux"; //No I18N
        }

        return OSType;
    }

    isDeviceMobile = function(userAgent) {

        var retVal = false;

        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(userAgent)) {
            retVal = true;
        }

        return retVal;
    }



    addProtocol = function(src) {

        var s = ('https:' == document.location.protocol ? 'https' : 'http'); //No I18N
        s = s + src;
        return s;
    }

    createParams = function(data) {

        var p = "?";
        var first = true;

        for (key in data) {
            if (data.hasOwnProperty(key)) {
                if (first) {
                    p += key + "=" + data[key];
                    first = false;
                } else {
                    p += "&" + key + "=" + data[key];
                }

            }
        }

        return p;
    }

    addScript = function(s, jsonParam) {

        var params = "";
        if (jsonParam) {
            params = createParams(jsonParam);
        }

        var s = s + param;
        var src = addProtocol(s);

        var scriptElement = document.createElement('script');
        scriptElement.async = true;
        scriptElement.src = src;

        var ele = document.getElementsByTagName('script')[0];
        ele.parentNode.insertBefore(scriptElement, ele);
    }

    setCookie = function(cname, cvalue, exp) {

        if (exp) {

            var date = new Date();
            date.setTime(date.getTime() + (exp * 24 * 60 * 60 * 1000));
            var expires = ";expires=" + date.toUTCString(); //No I18N
        }
        var expires = "";
        document.cookie = cname + "=" + cvalue + expires + ";path=/";

    }

    getCookieValue = function(cname) {

        var name = cname + "=";
        var cookies = document.cookie;
        var carray = cookies.split(';');

        for (var i = 0; i < carray.length; i++) {

            var cookie = carray[i];
            while (cookie.charAt(0) == ' ') {
                cookie = cookie.substring(1);
            }
            if (cookie.indexOf(name) == 0) {
                return cookie.substring(name.length, cookie.length);
            }
        }
        return "";
    }

    checkCookieExists = function(cname) {

        var cvalue = getCookieValue(cname);
        if (cvalue == "") {
            return false;
        }
        return true;
    }

    scriptEntryPoint = function() {

        ZAB.userAgent = getBrowserUA();
        ZAB.appName = getBrowserAppName();
        var appVersion = getBrowserAppVersion();
        ZAB.languages = getBrowserLang();
        ZAB.OS = getVisitorOSDetails(appVersion);
        ZAB.isMobile = isDeviceMobile(ZAB.userAgent);

    }

    scriptEntryPoint();

    /* to dermine the variation to which the visitor will be directed
    
        function splitURL(){
         
         var totalVar=2;
         var includePerc = 20;
         var percent = [20,80];
         var variations = [];
         var totalPerc = 0;
         var selected = 0;
         var done = 0;
         var include = false;
         var param ="";
         var r = Math.random();
         
         if(r<=(includePerc/100)){
            include = true; 
         }

         if(include){

             var random = Math.random();
             var checkPerc = 0;
             
              for(var i=0;i<percent.length;i++){
                 
                 checkPerc += percent[i];
                 if(random <= (checkPerc/100)){
                     selected = (i+1);
                     break;
                 }
                 
             }  
        
        param = "?totalVar=" + totalVar + "&selected=" + selected + "&random=" + random + "&included=1";
    } else {
        param = "?included=0";
    }
} */

}(window, document, navigator));
